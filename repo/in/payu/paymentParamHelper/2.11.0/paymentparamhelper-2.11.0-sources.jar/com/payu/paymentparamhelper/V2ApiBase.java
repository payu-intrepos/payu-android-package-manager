package com.payu.paymentparamhelper;

abstract public  class V2ApiBase  {
    abstract public String getJson();
}
