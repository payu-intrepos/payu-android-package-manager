package com.payu.paymentparamhelper.siparams.enums;

public enum BillingLimit {
    ON,
    BEFORE,
    AFTER
}
