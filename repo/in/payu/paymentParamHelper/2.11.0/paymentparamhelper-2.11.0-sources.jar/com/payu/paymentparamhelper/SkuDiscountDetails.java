package com.payu.paymentparamhelper;

import android.os.Parcel;
import android.os.Parcelable;

public class SkuDiscountDetails implements Parcelable {
    private double cashBack;
    private double instant;
    private double discountedAmount;

    public SkuDiscountDetails(){

    }

    protected SkuDiscountDetails(Parcel in) {
        cashBack = in.readDouble();
        instant = in.readDouble();
        discountedAmount = in.readDouble();
    }

    public static final Creator<SkuDiscountDetails> CREATOR = new Creator<SkuDiscountDetails>() {
        @Override
        public SkuDiscountDetails createFromParcel(Parcel in) {
            return new SkuDiscountDetails(in);
        }

        @Override
        public SkuDiscountDetails[] newArray(int size) {
            return new SkuDiscountDetails[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeDouble(cashBack);
        parcel.writeDouble(instant);
        parcel.writeDouble(discountedAmount);
    }

    public double getCashBack() {
        return cashBack;
    }

    public void setCashBack(double cashBack) {
        this.cashBack = cashBack;
    }

    public double getInstant() {
        return instant;
    }

    public void setInstant(double instant) {
        this.instant = instant;
    }

    public double getDiscountedAmount() {
        return discountedAmount;
    }

    public void setDiscountedAmount(double discountedAmount) {
        this.discountedAmount = discountedAmount;
    }
}
