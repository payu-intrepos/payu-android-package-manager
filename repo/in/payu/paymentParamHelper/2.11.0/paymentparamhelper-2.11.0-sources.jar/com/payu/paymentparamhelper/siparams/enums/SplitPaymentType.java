package com.payu.paymentparamhelper.siparams.enums;

public enum SplitPaymentType {
    absolute,
    percentage
}
