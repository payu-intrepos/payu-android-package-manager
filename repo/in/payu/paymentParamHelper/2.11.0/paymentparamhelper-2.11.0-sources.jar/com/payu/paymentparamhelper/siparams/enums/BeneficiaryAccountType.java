package com.payu.paymentparamhelper.siparams.enums;

public enum BeneficiaryAccountType {
    CURRENT,
    SAVINGS
}
