package com.payu.paymentparamhelper;

import android.os.Parcel;
import android.os.Parcelable;

public class OlwParams implements Parcelable {

    private String otp;
    private String token;
    private String deviceId;
    private String mPin;

    public OlwParams(){

    }

    protected OlwParams(Parcel in) {
        otp = in.readString();
        token = in.readString();
        deviceId = in.readString();
        mPin = in.readString();
    }

    public static final Creator<OlwParams> CREATOR = new Creator<OlwParams>() {
        @Override
        public OlwParams createFromParcel(Parcel in) {
            return new OlwParams(in);
        }

        @Override
        public OlwParams[] newArray(int size) {
            return new OlwParams[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(otp);
        parcel.writeString(token);
        parcel.writeString(deviceId);
        parcel.writeString(mPin);
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getMPin() {
        return mPin;
    }

    public void setMPin(String mPin) {
        this.mPin = mPin;
    }
}
