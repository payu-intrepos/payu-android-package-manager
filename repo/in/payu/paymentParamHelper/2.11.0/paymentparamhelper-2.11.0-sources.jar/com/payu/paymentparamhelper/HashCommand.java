package com.payu.paymentparamhelper;

public enum HashCommand {
    PaymentHash("payment_source"),
    SIPaymentHash("si_payment_source"),
    AuthorizePaymentHash("auth_payment"),
    BinInfoHash("getBinInfo"),
    AuthenticatePaymentHash("authenticate_payment_hash");

    public final String hashName;

    HashCommand(String hashName) {
        this.hashName = hashName;
    }
}
