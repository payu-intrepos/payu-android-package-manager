package com.payu.paymentparamhelper.parser;

public class ParserConstants {
  public static final String KEY = "key";
  public static final String PRODUCT_INFO = "product_info";
  public static final String FIRST_NAME = "first_name";
  public static final String EMAIL = "email";
  public static final String TRANSACTION_ID = "transaction_id";
  public static final String AMOUNT = "amount";
  public static final String PHONE = "phone";
  public static final String ANDROID_SURL = "android_surl";
  public static final String ANDROID_FURL = "android_furl";
  public static final String HASHES = "hashes";
  public static final String PAYMENT = "payment";
  public static final String ADDITIONAL_PARAMS = "additional_param";
  public static final String UDF_1 = "udf1";
  public static final String UDF_2 = "udf2";
  public static final String UDF_3 = "udf3";
  public static final String UDF_4 = "udf4";
  public static final String UDF_5 = "udf5";
  public static final String AFTER = "AFTER";
  public static final String ADHOC = "ADHOC";
  public static final String BEFORE = "BEFORE";
  public static final String DAILY = "DAILY";
  public static final String WEEKLY = "WEEKLY";
  public static final String MONTHLY = "MONTHLY";
  public static final String YEARLY = "YEARLY";
}
