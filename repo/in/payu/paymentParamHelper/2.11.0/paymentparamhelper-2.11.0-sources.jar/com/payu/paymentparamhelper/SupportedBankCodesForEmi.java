package com.payu.paymentparamhelper;


public class SupportedBankCodesForEmi {
    public enum SupportedBankCodesDCEmi {
        BOBD,
        CITID,
        HDFCD,
        KOTAKD,
        SBID,
        FEDED

    }

    public enum SupportedBankCodesCardlessEmi {
        ZEST,
        HDFCCL,
        ICICIC

    }
}
