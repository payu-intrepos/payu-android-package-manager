package com.payu.paymentparamhelper.siparams.enums;

public enum BillingRule {
    MAX,
    EXACT
}
