package com.payu.paymentparamhelper.threeDS2Params;

import android.os.Parcel;
import android.os.Parcelable;

public class SDKEphemParams  implements Parcelable {
    private String crv;
    private String kty;
    private String x;
    private String y;

    public SDKEphemParams() {
    }

    protected SDKEphemParams(Parcel in) {
        crv = in.readString();
        kty = in.readString();
        x = in.readString();
        y = in.readString();
    }

    public static final Creator<SDKEphemParams> CREATOR = new Creator<SDKEphemParams>() {
        @Override
        public SDKEphemParams createFromParcel(Parcel in) {
            return new SDKEphemParams(in);
        }

        @Override
        public SDKEphemParams[] newArray(int size) {
            return new SDKEphemParams[size];
        }
    };

    public String getCrv() {
        return crv;
    }

    public void setCrv(String crv) {
        this.crv = crv;
    }

    public String getKty() {
        return kty;
    }

    public void setKty(String kty) {
        this.kty = kty;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(crv);
        dest.writeString(kty);
        dest.writeString(x);
        dest.writeString(y);
    }
}
