package com.payu.paymentparamhelper;

import android.os.Parcel;
import android.os.Parcelable;

public class Products implements Parcelable {
  private String mfInvestmentType;

  private String mfAmcCode;

  private String amount;

  private String scheme;

  private String mfPartner;

  private String folio;

  private String receipt;

  private String mfUserId;

  private String type;

  private String plan;

  private String mfMemberId;

  private String option;

  public Products() {

  }

  protected Products(Parcel in) {
    mfInvestmentType = in.readString();
    mfAmcCode = in.readString();
    amount = in.readString();
    scheme = in.readString();
    mfPartner = in.readString();
    folio = in.readString();
    receipt = in.readString();
    mfUserId = in.readString();
    type = in.readString();
    plan = in.readString();
    mfMemberId = in.readString();
    option = in.readString();
  }

  public static final Creator<Products> CREATOR = new Creator<Products>() {
    @Override
    public Products createFromParcel(Parcel in) {
      return new Products(in);
    }

    @Override
    public Products[] newArray(int size) {
      return new Products[size];
    }
  };

  public String getMfInvestmentType() {
    return this.mfInvestmentType;
  }

  public void setMfInvestmentType(String mfInvestmentType) {
    this.mfInvestmentType = mfInvestmentType;
  }

  public String getMfAmcCode() {
    return this.mfAmcCode;
  }

  public void setMfAmcCode(String mfAmcCode) {
    this.mfAmcCode = mfAmcCode;
  }

  public String getAmount() {
    return this.amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getScheme() {
    return this.scheme;
  }

  public void setScheme(String scheme) {
    this.scheme = scheme;
  }

  public String getMfPartner() {
    return this.mfPartner;
  }

  public void setMfPartner(String mfPartner) {
    this.mfPartner = mfPartner;
  }

  public String getFolio() {
    return this.folio;
  }

  public void setFolio(String folio) {
    this.folio = folio;
  }

  public String getReceipt() {
    return this.receipt;
  }

  public void setReceipt(String receipt) {
    this.receipt = receipt;
  }

  public String getMfUserId() {
    return this.mfUserId;
  }

  public void setMfUserId(String mfUserId) {
    this.mfUserId = mfUserId;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getPlan() {
    return this.plan;
  }

  public void setPlan(String plan) {
    this.plan = plan;
  }

  public String getMfMemberId() {
    return this.mfMemberId;
  }

  public void setMfMemberId(String mfMemberId) {
    this.mfMemberId = mfMemberId;
  }

  public String getOption() {
    return this.option;
  }

  public void setOption(String option) {
    this.option = option;
  }

  @Override
  public int describeContents() {
    return 0;
  }

  @Override
  public void writeToParcel(Parcel parcel, int i) {
    parcel.writeString(mfInvestmentType);
    parcel.writeString(mfAmcCode);
    parcel.writeString(amount);
    parcel.writeString(scheme);
    parcel.writeString(mfPartner);
    parcel.writeString(folio);
    parcel.writeString(receipt);
    parcel.writeString(mfUserId);
    parcel.writeString(type);
    parcel.writeString(plan);
    parcel.writeString(mfMemberId);
    parcel.writeString(option);
  }
}
