package com.payu.paymentparamhelper.threeDS2Params;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class SDKDeviceRenderOptions implements Parcelable {
    private String sdkInterface;
    private List<String> sdkUiType ;

    public SDKDeviceRenderOptions() {
    }

    protected SDKDeviceRenderOptions(Parcel in) {
        sdkInterface = in.readString();
        sdkUiType = in.createStringArrayList();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(sdkInterface);
        dest.writeStringList(sdkUiType);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SDKDeviceRenderOptions> CREATOR = new Creator<SDKDeviceRenderOptions>() {
        @Override
        public SDKDeviceRenderOptions createFromParcel(Parcel in) {
            return new SDKDeviceRenderOptions(in);
        }

        @Override
        public SDKDeviceRenderOptions[] newArray(int size) {
            return new SDKDeviceRenderOptions[size];
        }
    };

    public String getSdkInterface() {
        return sdkInterface;
    }

    public void setSdkInterface(String sdkInterface) {
        this.sdkInterface = sdkInterface;
    }

    public List<String> getSdkUiType() {
        return sdkUiType;
    }

    public void setSdkUiType(List<String> sdkUiType) {

        this.sdkUiType = sdkUiType;
    }
}
