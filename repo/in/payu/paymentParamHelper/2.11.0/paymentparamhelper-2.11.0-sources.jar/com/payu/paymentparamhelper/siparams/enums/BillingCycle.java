package com.payu.paymentparamhelper.siparams.enums;

public enum BillingCycle {
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY,
    ONCE,
    ADHOC
}
