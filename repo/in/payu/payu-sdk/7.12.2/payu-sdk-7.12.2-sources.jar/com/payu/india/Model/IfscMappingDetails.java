package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class IfscMappingDetails implements Parcelable {
    private String ifscCode;
    private String bankName;
    private String ibiboCode;
    private String imageUrl;
    private String imageUpdateOn;

    public IfscMappingDetails(Parcel in) {
        ifscCode = in.readString();
        bankName = in.readString();
        ibiboCode = in.readString();
        imageUrl = in.readString();
        imageUpdateOn = in.readString();
    }

    public static final Creator<IfscMappingDetails> CREATOR = new Creator<IfscMappingDetails>() {
        @Override
        public IfscMappingDetails createFromParcel(Parcel in) {
            return new IfscMappingDetails(in);
        }

        @Override
        public IfscMappingDetails[] newArray(int size) {
            return new IfscMappingDetails[size];
        }
    };

    public IfscMappingDetails() {

    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getIbiboCode() {
        return ibiboCode;
    }

    public void setIbiboCode(String ibiboCode) {
        this.ibiboCode = ibiboCode;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUpdateOn() {
        return imageUpdateOn;
    }

    public void setImageUpdateOn(String imageUpdateOn) {
        this.imageUpdateOn = imageUpdateOn;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(ifscCode);
        parcel.writeString(bankName);
        parcel.writeString(ibiboCode);
        parcel.writeString(imageUrl);
        parcel.writeString(imageUpdateOn);
    }
}
