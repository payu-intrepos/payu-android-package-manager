package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface CheckoutDetailsListener {
    /**
     * As soon as we receive data in {@link com.payu.india.Tasks.GetCheckoutDetailsTask}
     * {@link com.payu.india.Interfaces.CheckoutDetailsListener#onCheckoutDetailsResponse(PayuResponse)} will be notified with response
     *
     * @param payuResponse {@link PayuResponse#getResponseStatus()}
     */
    void onCheckoutDetailsResponse(PayuResponse payuResponse);
}
