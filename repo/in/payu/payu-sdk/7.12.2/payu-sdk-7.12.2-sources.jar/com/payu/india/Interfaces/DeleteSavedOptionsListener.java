package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface DeleteSavedOptionsListener {

    void onDeleteSavedOptionResponse(PayuResponse payuResponse);
}
