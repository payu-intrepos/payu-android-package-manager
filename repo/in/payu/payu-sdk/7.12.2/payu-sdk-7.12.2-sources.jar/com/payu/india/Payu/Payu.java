package com.payu.india.Payu;

import android.content.Context;

/**
 * Created by franklin on 12/01/16.
 */
public class Payu {


    private static Payu mInstance = null;
    private Context mContext = null;

    private Payu(Context context) {
        this.mContext = context;
    }

    public static Payu getInstance() {
        return mInstance;
    }

    public static Payu setInstance(Context context) {
        if (null == mInstance) {
            synchronized (Payu.class) {
                if (null == mInstance)
                    mInstance = new Payu(context);
            }
        }
        return mInstance;
    }

    public Context getCallingAppContext() {
        return this.mContext;
    }
}
