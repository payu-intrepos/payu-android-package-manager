package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import org.json.JSONObject;

public class V2ApiResponse implements Parcelable {
    private PostData postData;
    private JSONObject rawResponse;


    public V2ApiResponse(){

    }

    protected V2ApiResponse(Parcel in) {
        postData = in.readParcelable(PostData.class.getClassLoader());
    }

    public static final Creator<V2ApiResponse> CREATOR = new Creator<V2ApiResponse>() {
        @Override
        public V2ApiResponse createFromParcel(Parcel in) {
            return new V2ApiResponse(in);
        }

        @Override
        public V2ApiResponse[] newArray(int size) {
            return new V2ApiResponse[size];
        }
    };

    public PostData getPostData() {
        return postData;
    }

    public void setPostData(PostData postData) {
        this.postData = postData;
    }

    public JSONObject getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(JSONObject rawResponse) {
        this.rawResponse = rawResponse;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeParcelable(postData, i);
    }
}
