package com.payu.india.Model.Olw;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;


/**
 * This class is for olw fetchBalance response mPinSet status and customer info 
 * */
public class OlwSDKInfo implements Parcelable {

    private  boolean isMPinSet;
    private  boolean customerRegistered;

    protected OlwSDKInfo(Parcel in) {
        isMPinSet = in.readByte() != 0;
        customerRegistered = in.readByte() != 0;
    }

    public OlwSDKInfo(){}

    public static final Creator<OlwSDKInfo> CREATOR = new Creator<OlwSDKInfo>() {
        @Override
        public OlwSDKInfo createFromParcel(Parcel in) {
            return new OlwSDKInfo(in);
        }

        @Override
        public OlwSDKInfo[] newArray(int size) {
            return new OlwSDKInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeByte((byte) (isMPinSet ? 1 : 0));
        parcel.writeByte((byte) (customerRegistered ? 1 : 0));
    }

    public boolean isMPinSet() {
        return isMPinSet;
    }

    public void setMPinSet(boolean MPinSet) {
        isMPinSet = MPinSet;
    }

    public boolean isCustomerRegistered() {
        return customerRegistered;
    }

    public void setCustomerRegistered(boolean customerRegistered) {
        this.customerRegistered = customerRegistered;
    }
}
