package com.payu.india.Model;

import com.payu.india.Payu.PayuConstants;
import com.payu.paymentparamhelper.V2ApiBase;

import org.json.JSONObject;

public class DeleteSavedOptionsRequest extends V2ApiBase {

    private String phone;
    private String deviceId;
    private String consent;

    private String paymentMode;
    private String pgTitle;
    private String pgDetails;
    private String ibiboCode;
    private String userCredential;

    private DeleteSavedOptionsRequest(Builder builder) {
        this.phone = builder.phone;
        this.deviceId = builder.deviceId;
        this.consent = builder.consent;
        this.paymentMode = builder.paymentMode;
        this.pgTitle = builder.pgTitle;
        this.pgDetails = builder.pgDetails;
        this.ibiboCode = builder.ibiboCode;
        this.userCredential = builder.userCredential;
    }

    @Override
    public String getJson() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(PayuConstants.PHONE,phone);
            jsonObject.put(PayuConstants.PAYU_DEVICE_ID, deviceId);
            jsonObject.put(PayuConstants.PAYU_CONSENT,consent);
            jsonObject.put(PayuConstants.GV_PAYMODE, paymentMode);
            jsonObject.put(PayuConstants.PAYU_PGTITLE,pgTitle);
            jsonObject.put(PayuConstants.PAYU_PGDETAILS, pgDetails);
            jsonObject.put(PayuConstants.IBIBOCODE,ibiboCode);
            jsonObject.put(PayuConstants.GV_USER_CREDENTIAL,userCredential);
            return jsonObject.toString();
        }catch (Exception e){

        }

        return null;
    }

    public static class Builder {
        private String phone;
        private String deviceId;
        private String consent;

        private String paymentMode;
        private String pgTitle;
        private String pgDetails;
        private String ibiboCode;
        private String userCredential;

        public Builder setPhone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder setDeviceId(String deviceId) {
            this.deviceId = deviceId;
            return this;
        }

        public Builder setConsent(String consent) {
            this.consent = consent;
            return this;
        }

        public Builder setPaymentMode(String paymentMode) {
            this.paymentMode = paymentMode;
            return this;
        }

        public Builder setPgTitle(String pgTitle) {
            this.pgTitle = pgTitle;
            return this;
        }

        public Builder setPgDetails(String pgDetails) {
            this.pgDetails = pgDetails;
            return this;
        }

        public Builder setIbiboCode(String ibiboCode) {
            this.ibiboCode = ibiboCode;
            return this;
        }

        public Builder setUserCredential(String userCredential) {
            this.userCredential = userCredential;
            return this;
        }

        public DeleteSavedOptionsRequest build(){
            return new DeleteSavedOptionsRequest(this);
        }
    }
}
