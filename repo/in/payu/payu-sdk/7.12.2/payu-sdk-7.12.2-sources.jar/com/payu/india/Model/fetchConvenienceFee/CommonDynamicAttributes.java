package com.payu.india.Model.fetchConvenienceFee;

public class CommonDynamicAttributes {
    private final String mode;
    private final String action;
    private boolean disableConvFeeCompounding;
    private String compoundingPercentage;

    public CommonDynamicAttributes(String mode, String action) {
        this.mode = mode;
        this.action = action;
    }

    public String getMode() {
        return mode;
    }

    public String getAction() {
        return action;
    }

    public boolean isDisableConvFeeCompounding() {
        return disableConvFeeCompounding;
    }

    public void setDisableConvFeeCompounding(boolean disableConvFeeCompounding) {
        this.disableConvFeeCompounding = disableConvFeeCompounding;
    }

    public String getCompoundingPercentage() {
        return compoundingPercentage;
    }

    public void setCompoundingPercentage(String compoundingPercentage) {
        this.compoundingPercentage = compoundingPercentage;
    }
}
