package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class PayUUserDetails implements Parcelable {
    private String firstName;
    private String phoneNo;
    private String email;

    public PayUUserDetails() {

    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    protected PayUUserDetails(Parcel in) {
        firstName = in.readString();
        phoneNo = in.readString();
        email = in.readString();
    }


    public static final Creator<PayUUserDetails> CREATOR = new Creator<PayUUserDetails>() {
        @Override
        public PayUUserDetails createFromParcel(Parcel in) {
            return new PayUUserDetails(in);
        }

        @Override
        public PayUUserDetails[] newArray(int size) {
            return new PayUUserDetails[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(firstName);
        parcel.writeString(phoneNo);
        parcel.writeString(email);
    }
}
