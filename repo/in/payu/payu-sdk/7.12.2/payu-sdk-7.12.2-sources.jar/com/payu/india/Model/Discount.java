package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Discount implements Parcelable {
    private String discountType;
    private double discount;
    private double discountedAmount;

    public Discount() {
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getDiscountedAmount() {
        return discountedAmount;
    }

    public void setDiscountedAmount(double discountedAmount) {
        this.discountedAmount = discountedAmount;
    }

    protected Discount(Parcel in) {
        discountType = in.readString();
        discount = in.readDouble();
        discountedAmount = in.readDouble();
    }

    public static final Creator<Discount> CREATOR = new Creator<Discount>() {
        @Override
        public Discount createFromParcel(Parcel in) {
            return new Discount(in);
        }

        @Override
        public Discount[] newArray(int size) {
            return new Discount[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(discountType);
        parcel.writeDouble(discount);
        parcel.writeDouble(discountedAmount);
    }
}
