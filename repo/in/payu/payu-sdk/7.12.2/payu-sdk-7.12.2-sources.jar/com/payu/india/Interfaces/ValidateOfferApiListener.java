package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface ValidateOfferApiListener {

    void onValiDateOfferResponse(PayuResponse payuResponse);
}
