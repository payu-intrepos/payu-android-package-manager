package com.payu.india.Model.fetchConvenienceFee;


public class VariableDynamicAttributes {
    private final String combinationKey;
    private final String ibiboCode;

    public VariableDynamicAttributes(String combinationKey, String ibiboCode) {
        this.combinationKey = combinationKey;
        this.ibiboCode = ibiboCode;
    }

    public String getCombinationKey() {
        return combinationKey;
    }

    public String getIbiboCode() {
        return ibiboCode;
    }

}
