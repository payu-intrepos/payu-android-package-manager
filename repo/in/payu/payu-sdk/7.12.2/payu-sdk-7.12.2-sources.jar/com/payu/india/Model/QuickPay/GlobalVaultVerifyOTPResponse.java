package com.payu.india.Model.QuickPay;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Purpose of the class to perform construction of the Response Params to Verify Authentication
 */
public class GlobalVaultVerifyOTPResponse extends GlobalVaultOTPResponse implements Parcelable {

    private String token;

    public GlobalVaultVerifyOTPResponse() {
    }

    protected GlobalVaultVerifyOTPResponse(Parcel in) {
        token = in.readString();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public static final Creator<GlobalVaultVerifyOTPResponse> CREATOR = new Creator<GlobalVaultVerifyOTPResponse>() {
        @Override
        public GlobalVaultVerifyOTPResponse createFromParcel(Parcel in) {
            return new GlobalVaultVerifyOTPResponse(in);
        }

        @Override
        public GlobalVaultVerifyOTPResponse[] newArray(int size) {
            return new GlobalVaultVerifyOTPResponse[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(token);
    }
}
