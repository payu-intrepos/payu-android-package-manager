package com.payu.india.Tasks;

import static com.payu.paymentparamhelper.PayuConstants.DATA;

import com.payu.india.Interfaces.OnEmiCalculaterListener;
import com.payu.india.Model.PayuConfig;
import com.payu.india.Model.PayuResponse;
import com.payu.india.Model.PostData;
import com.payu.india.Model.fetchConvenienceFee.FetchConvFeeCombinations;
import com.payu.india.Model.validateOffer.ValidateOfferDetails;
import com.payu.india.Payu.HttpRequest;
import com.payu.india.Payu.PayuConstants;
import com.payu.india.Payu.PayuErrors;
import com.payu.india.Payu.PayuUtils;
import com.payu.india.Payu.V2ApiHelper;
import com.payu.india.Payu.v2ApiResponseParser.V2ApiResponseParser;
import com.payu.india.Tasks.base.PayUAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;

public class EmiCalculatorTask extends PayUAsyncTask<PayuConfig, String, PayuResponse> {

    private OnEmiCalculaterListener onEmiCalculaterListener;

    public EmiCalculatorTask(OnEmiCalculaterListener onEmiCalculaterListener) {
        this.onEmiCalculaterListener = onEmiCalculaterListener;
    }

    @Override
    protected PayuResponse doInBackground(PayuConfig... params) {
        PayuResponse payuResponse = new PayuResponse();
        PostData postData = new PostData();

        try {
            URL url = null;
            // get the payuConfig first
            PayuConfig payuConfig = params[0];

            // set the environment
            switch (payuConfig.getEnvironment()) {
                case PayuConstants.PRODUCTION_ENV:
                    url = new URL(PayuConstants.APIV2_URL);
                    break;
                case PayuConstants.STAGING_ENV:
                    url = new URL(PayuConstants.TEST_APIV2_URL);
                    break;
                default:
                    url = new URL(PayuConstants.APIV2_URL);
                    break;
            }

            HttpRequest request = new HttpRequest.Builder().setMethod(HttpRequest.Method.POST).
                    setURL(url + PayuConstants.CALCULATE_EMI).setPostData(payuConfig.getData()).setHeaders(V2ApiHelper.getInstance().getAuthHeader(PayuConstants.PAYU_CALCULATE_EMI)).
                    setRequestType(PayuConstants.REQUEST_APPLICATION_JSON).build();
            HttpsURLConnection conn = PayuUtils.getHttpsConn(request);
            if (null != conn) {
                StringBuffer responseStringBuffer = PayuUtils.getStringBuffer(conn, false);
                JSONObject response1 = new JSONObject(responseStringBuffer.toString());
                payuResponse.setRawResponse(response1);
                if (response1.has(DATA) && response1.optJSONObject(DATA) != null) {
                    JSONObject response = response1.optJSONObject(DATA);
                    JSONObject emiCalculatorData = response.optJSONObject(PayuConstants.PAYU_EMI_CALCULATOR_DATA);
                    payuResponse.setRawResponse(emiCalculatorData);

                    V2ApiResponseParser v2ApiResponseParser = new V2ApiResponseParser();
                    JSONObject pricingCfJson = response.optJSONObject(PayuConstants.PAYU_PRICING_CF_DATA);
                    if (pricingCfJson != null) {
                        JSONObject data = pricingCfJson.optJSONObject(DATA);
                        HashMap<String, FetchConvFeeCombinations> convFeeMap = v2ApiResponseParser.parseFetchConvFeeRespToMap(data);
                        payuResponse.setCurrentCfCharge(convFeeMap);
                    }

                    JSONObject validateJson = response.optJSONObject(PayuConstants.PAYU_VALIDATE_OFFER_DATA);
                    if (validateJson != null) {
                        ValidateOfferDetails validateOfferDetails = new ValidateOfferDetails();
                        JSONObject validateOfferJsonResult = validateJson.optJSONObject(PayuConstants.P_RESULT);
                        if (validateOfferJsonResult != null) {
                            v2ApiResponseParser.parseValidateOfferResponse(validateOfferJsonResult, validateOfferDetails);
                            payuResponse.setValidateOfferDetails(validateOfferDetails);
                        }
                    }
                }
            }
        } catch (MalformedURLException e) {
            postData.setCode(PayuErrors.MALFORMED_URL_EXCEPTION);
            postData.setStatus(PayuConstants.ERROR);
            postData.setResult(e.getMessage());
        } catch (JSONException e) {
            postData.setCode(PayuErrors.JSON_EXCEPTION);
            postData.setStatus(PayuConstants.ERROR);
            postData.setResult(e.getMessage());
        } catch (IOException e) {
            postData.setCode(PayuErrors.IO_EXCEPTION);
            postData.setStatus(PayuConstants.ERROR);
            postData.setResult(e.getMessage());
        }
        payuResponse.setResponseStatus(postData);
        return payuResponse;

    }

    @Override
    protected void onPostExecute(PayuResponse payuResponse) {
        super.onPostExecute(payuResponse);
        onEmiCalculaterListener.onEmiCalculatorResponse(payuResponse);
    }

}
