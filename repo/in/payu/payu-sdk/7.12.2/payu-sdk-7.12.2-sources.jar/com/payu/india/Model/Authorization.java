package com.payu.india.Model;

import java.util.HashMap;
import java.util.Map;

public class Authorization {
    private String date;
    private String digest;
    private HashMap<String,String> signature = new HashMap<>();

    public String getMerchantkey() {
        return merchantkey;
    }

    public void setMerchantkey(String merchantkey) {
        this.merchantkey = merchantkey;
    }

    private String merchantkey;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public String getSignature(String key) {
        return signature.get(key);
    }

    public void setSignature(HashMap<String,String> signature) {
        this.signature.putAll(signature);
    }
}
