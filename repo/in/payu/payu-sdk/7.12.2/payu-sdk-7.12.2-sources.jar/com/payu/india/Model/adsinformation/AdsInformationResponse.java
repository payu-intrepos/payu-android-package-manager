package com.payu.india.Model.adsinformation;

import android.os.Parcel;
import android.os.Parcelable;

public class AdsInformationResponse implements Parcelable {
    private String imagePath;
    private String requestId;
    private String adsSource;

    public AdsInformationResponse() {
    }

    protected AdsInformationResponse(Parcel in) {
        imagePath = in.readString();
        requestId = in.readString();
        adsSource = in.readString();
    }


    public String getImage() {
        return imagePath;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setImage(String imagePath) {
        this.imagePath = imagePath;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public void setAdsSource(String adsSource) {
        this.adsSource = adsSource;
    }

    public String getAdsSource() {
        return adsSource;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(imagePath);
        parcel.writeString(requestId);
        parcel.writeString(adsSource);
    }

    public static final Creator<AdsInformationResponse> CREATOR = new Creator<AdsInformationResponse>() {
        @Override
        public AdsInformationResponse createFromParcel(Parcel in) {
            return new AdsInformationResponse(in);
        }

        @Override
        public AdsInformationResponse[] newArray(int size) {
            return new AdsInformationResponse[size];
        }
    };
}