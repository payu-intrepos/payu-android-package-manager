package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

/**
 * Created by franklin.michael on 08/03/16.
 */
public interface CheckOfferDetailsApiListener {
    void onCheckOfferDetailsApiResponse(PayuResponse payuResponse);
}
