//    Copyright (c) 2014 - 2015 payu@india.com
//
//    Permission is hereby granted, free of charge, to any person obtaining a copy
//    of this software and associated documentation files (the "Software"), to deal
//    in the Software without restriction, including without limitation the rights
//    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//    copies of the Software, and to permit persons to whom the Software is
//    furnished to do so, subject to the following conditions:
//
//    The above copyright notice and this permission notice shall be included in
//    all copies or substantial portions of the Software.
//
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//    THE SOFTWARE.

package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import com.payu.india.Model.QuickPay.QuickPaySavedOption;

import com.payu.india.Model.QuickPay.RecommendedOptions;
import com.payu.india.Model.adsinformation.AdsInformationResponse;
import com.payu.india.Model.binBaseDetails.BinBaseDetailsResponse;
import com.payu.india.Model.fetchConvenienceFee.FetchConvFeeCombinations;
import com.payu.india.Model.validateOffer.ValidateOfferDetails;
import com.payu.india.Payu.PayuConstants;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by franklin on 5/26/15.
 * Simple Bean implementation of PayuResponse.
 * Everytime Task talks to payu server, the responses will be filled in {@link PayuResponse}
 * {@link PayuResponse#storedCards} is a collection (ArrayList) of {@link StoredCard}
 * {@link PayuResponse#emi} is a collection (ArrayList) of {@link Emi}
 * {@link PayuResponse#noCostEMI} is a collection (ArrayList) of {@link Emi}
 * {@link PayuResponse#creditCard} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#debitCard} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#cashCard} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#netBanks} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#ivr} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#ivrdc} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#paisaWallet} is a collection (ArrayList) of {@link PaymentDetails}
 * {@link PayuResponse#responseStatus} is {@link PostData}
 * {@link PayuResponse#netBankingDownStatus} is a hashmap  key(string) - bank code, value(string) - status TODO set the status value in constants.
 * {@link PayuResponse#cardInformation} is  {@link CardInformation}
 * * {@link PayuResponse#ifscCodeDetails} is  {@link IFSCCodeDetails}
 * {@link PayuResponse#lookupDetails} is  {@link LookupDetails}
 * {@link PayuResponse#issuingBankStatus} is a hash map - key -(string) - card bin(first 6 digit of cardno), value({@link CardStatus}) - holds the name of the issuing bank and status.
 * {@link PayuResponse#payuOffer} is {@link PayuOffer}
 * {@link PayuResponse#transactionDetailsList} is collection of (ArrayList) of {@link TransactionDetails}
 */

public class PayuResponse implements Parcelable {

    public static final Creator<PayuResponse> CREATOR = new Creator<PayuResponse>() {
        @Override
        public PayuResponse createFromParcel(Parcel in) {
            return new PayuResponse(in);
        }

        @Override
        public PayuResponse[] newArray(int size) {
            return new PayuResponse[size];
        }
    };
    private ArrayList<StoredCard> storedCards;
    private ArrayList<Emi> emi;
    private ArrayList<Emi> noCostEMI;
    private ArrayList<PaymentDetails> creditCard;
    private ArrayList<PaymentDetails> debitCard;
    private ArrayList<PaymentDetails> netBanks;
    private ArrayList<PaymentDetails> cashCard;
    private ArrayList<PaymentDetails> ivr;
    private ArrayList<PaymentDetails> ivrdc;
    private ArrayList<PaymentDetails> paisaWallet;
    private ArrayList<PaymentDetails> lazyPay;

    public ArrayList<Bnpl> getBnpl() {
        return bnpl;
    }

    public void setBnpl(ArrayList<Bnpl> bnpl) {
        this.bnpl = bnpl;
    }

    public Boolean isBnplAvailable() {
        return this.bnpl != null && this.bnpl.size() > 0;
    }

    private ArrayList<EligibleEmiBins> eligibleEmiBins;
    private ArrayList<PaymentDetails> standingInstructions;
    private ArrayList<PaymentDetails> neftRtgs;
    private ArrayList<PaymentDetails> siBankList;

    public FetchofferDetails getFetchofferDetails() {
        return fetchofferDetails;
    }

    public void setFetchofferDetails(FetchofferDetails fetchofferDetails) {
        this.fetchofferDetails = fetchofferDetails;
    }

    public ValidateOfferDetails getValidateOfferDetails() {
        return validateOfferDetails;
    }

    public void setValidateOfferDetails(ValidateOfferDetails validateOfferDetails) {
        this.validateOfferDetails = validateOfferDetails;
    }

    public ArrayList<PaymentDetails> getMealCard() {
        return mealCard;
    }

    public void setMealCard(ArrayList<PaymentDetails> mealCard) {
        this.mealCard = mealCard;
    }

    private ArrayList<PaymentDetails> mealCard;

    private ArrayList<Emi> ccemi;
    private ArrayList<Emi> dcemi;
    private ArrayList<Emi> cardlessemi;
    private JSONObject rawResponse;
    private TokenisedCardDetail tokenisedCardDetail;
    private FetchofferDetails fetchofferDetails;
    private ValidateOfferDetails validateOfferDetails;
    private BinBaseDetailsResponse binBaseDetailsResponse;

    public ArrayList<EligibleEmiBins> getEligibleEmiBins() {
        return eligibleEmiBins;
    }

    public void setEligibleEmiBins(ArrayList<EligibleEmiBins> eligibleEmiBins) {
        this.eligibleEmiBins = eligibleEmiBins;
    }

    public Upi getUpi() {
        return upi;
    }

    public void setUpi(Upi upi) {
        this.upi = upi;
    }

    private Upi upi;

    private Upi googleTez;

    private Upi googleTezOmni;

    private Upi genericIntent;

    private PaymentDetails phonePe;
    private PaymentDetails twid;

    public Upi getGoogleTez() {
        return googleTez;
    }

    public void setGoogleTez(Upi googleTez) {
        this.googleTez = googleTez;
    }

    public Upi getGoogleTezOmni() {
        return googleTezOmni;
    }

    public void setGoogleTezOmni(Upi googleTezOmni) {
        this.googleTezOmni = googleTezOmni;
    }

    private PostData responseStatus;
    private CardInformation cardInformation;

    private IFSCCodeDetails ifscCodeDetails;
    private LookupDetails lookupDetails;
    private TaxSpecification taxSpecification;
    private MerchantInfo merchantInfo;
    private SodexoCardInfo sodexoCardInfo;

    private HashMap<String, Integer> netBankingDownStatus;
    private HashMap<String, CardStatus> issuingBankStatus;
    private PayuOffer payuOffer;
    private ArrayList<TransactionDetails> transactionDetailsList;
    private ArrayList<String> downIssuingBanks;
    private ArrayList<PayuOffer> offerDetailsList;
    private PayuOfferDetails payuOfferDetails;
    // PayU Response for API getEmiAmountAccordingToInterest
    private HashMap<String, HashMap<String, PayuEmiAmountAccordingToInterest>> payuEmiAmountAccordingToInterest;
    private ArrayList<String> upiSISupportedApps;
    private ArrayList<String> upiSISupportedHandles;
    private AdsInformationResponse adsInformationResponse;
    private ArrayList<Bnpl> bnpl;
    private ArrayList<QuickPaySavedOption> quickPaySavedOption;
    private ArrayList<RecommendedOptions> recommendedOptions;
    private ArrayList<PaymentDetails> closedLoopWallet;
    private boolean isUpiOtm;
    private boolean isIntentOtm;
    private HashMap<String, FetchConvFeeCombinations> recurringAmtCFCharge;
    private HashMap<String, FetchConvFeeCombinations> regAmtCFCharges;
    private HashMap<String, FetchConvFeeCombinations> currentCfCharge;

    public ArrayList<QuickPaySavedOption> getSavedOption() {
        return quickPaySavedOption;
    }

    public void setSavedOption(ArrayList<QuickPaySavedOption> quickPaySavedOption) {
        this.quickPaySavedOption = quickPaySavedOption;
    }

    public MerchantInfo getMerchantInfo() {
        return merchantInfo;
    }

    public void setMerchantInfo(MerchantInfo merchantInfo) {
        this.merchantInfo = merchantInfo;
    }


    public SodexoCardInfo getSodexoCardInfo() {
        return sodexoCardInfo;
    }

    public void setSodexoCardInfo(SodexoCardInfo sodexoCardInfo) {
        this.sodexoCardInfo = sodexoCardInfo;
    }

    public ArrayList<String> getDownIssuingBanks() {
        return downIssuingBanks;
    }

    public void setDownIssuingBanks(ArrayList<String> downIssuingBanks) {
        this.downIssuingBanks = downIssuingBanks;
    }

    public TaxSpecification getTaxSpecification() {
        return taxSpecification;
    }

    public void setTaxSpecification(TaxSpecification taxSpecification) {
        this.taxSpecification = taxSpecification;
    }

    public ArrayList<PayuOffer> getOfferDetailsList() {
        return offerDetailsList;
    }

    public void setOfferDetailsList(ArrayList<PayuOffer> offerDetailsList) {
        this.offerDetailsList = offerDetailsList;
    }


    public PayuOfferDetails getPayuOfferDetails() {
        return payuOfferDetails;
    }

    public void setPayuOfferDetails(PayuOfferDetails payuOfferDetails) {
        this.payuOfferDetails = payuOfferDetails;
    }

    public ArrayList<PaymentDetails> getClosedLoopWallet() {
        return closedLoopWallet;
    }

    public void setClosedLoopWallet(ArrayList<PaymentDetails> closedLoopWallet) {
        this.closedLoopWallet = closedLoopWallet;
    }

    public HashMap<String, FetchConvFeeCombinations> getRecurringAmtCFCharge() {
        return recurringAmtCFCharge;
    }

    public void setRecurringAmtCFCharge(HashMap<String, FetchConvFeeCombinations> recurringAmtCFCharge) {
        this.recurringAmtCFCharge = recurringAmtCFCharge;
    }

    public HashMap<String, FetchConvFeeCombinations> getRegAmtCFCharges() {
        return regAmtCFCharges;
    }

    public void setRegAmtCFCharges(HashMap<String, FetchConvFeeCombinations> regAmtCFCharges) {
        this.regAmtCFCharges = regAmtCFCharges;
    }

    protected PayuResponse(Parcel in) {
        storedCards = in.createTypedArrayList(StoredCard.CREATOR);
        emi = in.createTypedArrayList(Emi.CREATOR);
        ccemi = in.createTypedArrayList(Emi.CREATOR);
        dcemi = in.createTypedArrayList(Emi.CREATOR);
        cardlessemi = in.createTypedArrayList(Emi.CREATOR);
        noCostEMI = in.createTypedArrayList(Emi.CREATOR);
        creditCard = in.createTypedArrayList(PaymentDetails.CREATOR);
        debitCard = in.createTypedArrayList(PaymentDetails.CREATOR);
        netBanks = in.createTypedArrayList(PaymentDetails.CREATOR);
        cashCard = in.createTypedArrayList(PaymentDetails.CREATOR);
        ivr = in.createTypedArrayList(PaymentDetails.CREATOR);
        ivrdc = in.createTypedArrayList(PaymentDetails.CREATOR);
        paisaWallet = in.createTypedArrayList(PaymentDetails.CREATOR);
        lazyPay = in.createTypedArrayList(PaymentDetails.CREATOR);
        mealCard = in.createTypedArrayList(PaymentDetails.CREATOR);
        responseStatus = in.readParcelable(PostData.class.getClassLoader());
        cardInformation = in.readParcelable(CardInformation.class.getClassLoader());
        ifscCodeDetails = in.readParcelable(IFSCCodeDetails.class.getClassLoader());
        lookupDetails = in.readParcelable(LookupDetails.class.getClassLoader());
        taxSpecification = in.readParcelable(TaxSpecification.class.getClassLoader());
        payuOffer = in.readParcelable(PayuOffer.class.getClassLoader());
        transactionDetailsList = in.createTypedArrayList(TransactionDetails.CREATOR);
        offerDetailsList = in.createTypedArrayList(PayuOffer.CREATOR);
        payuOfferDetails = in.readParcelable(PayuOfferDetails.class.getClassLoader());
        payuEmiAmountAccordingToInterest = in.readHashMap(PayuEmiAmountAccordingToInterest.class.getClassLoader());
        eligibleEmiBins = in.createTypedArrayList(EligibleEmiBins.CREATOR);
        standingInstructions = in.createTypedArrayList(PaymentDetails.CREATOR);
        siBankList = in.createTypedArrayList(PaymentDetails.CREATOR);
        downIssuingBanks = in.createStringArrayList();
        neftRtgs = in.createTypedArrayList(PaymentDetails.CREATOR);
        tokenisedCardDetail = in.readParcelable(TokenisedCardDetail.class.getClassLoader());
        sodexoCardInfo = in.readParcelable(SodexoCardInfo.class.getClassLoader());
        merchantInfo = in.readParcelable(MerchantInfo.class.getClassLoader());
        upiSISupportedApps = in.createStringArrayList();
        upiSISupportedHandles = in.createStringArrayList();
        fetchofferDetails = in.readParcelable(FetchofferDetails.class.getClassLoader());
        validateOfferDetails = in.readParcelable(ValidateOfferDetails.class.getClassLoader());
        adsInformationResponse = in.readParcelable((AdsInformationResponse.class.getClassLoader()));
        bnpl = in.createTypedArrayList(Bnpl.CREATOR);
        quickPaySavedOption = in.createTypedArrayList(QuickPaySavedOption.CREATOR);
        recommendedOptions = in.createTypedArrayList(RecommendedOptions.CREATOR);
        closedLoopWallet = in.createTypedArrayList(PaymentDetails.CREATOR);
        isUpiOtm = in.readByte() != 0;
        isIntentOtm = in.readByte() != 0;
        binBaseDetailsResponse = in.readParcelable(BinBaseDetailsResponse.class.getClassLoader());
        recurringAmtCFCharge = (HashMap<String, FetchConvFeeCombinations>) (in.readSerializable());
        regAmtCFCharges = (HashMap<String, FetchConvFeeCombinations>) (in.readSerializable());
        currentCfCharge = (HashMap<String, FetchConvFeeCombinations>) (in.readSerializable());
    }

    public PayuResponse() {
    }

    public ArrayList<StoredCard> getStoredCards() {
        return storedCards;
    }

    public void setStoredCards(ArrayList<StoredCard> storedCards) {
        this.storedCards = storedCards;
    }

    public ArrayList<Emi> getEmi() {
        return emi;
    }

    public void setEmi(ArrayList<Emi> emi) {
        this.emi = emi;
    }

    public JSONObject getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(JSONObject rawResponse) {
        this.rawResponse = rawResponse;
    }

    public ArrayList<Emi> getNoCostEMI() {
        return noCostEMI;
    }

    public void setNoCostEMI(ArrayList<Emi> noCostEMI) {
        this.noCostEMI = noCostEMI;
    }

    public ArrayList<PaymentDetails> getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(ArrayList<PaymentDetails> creditCard) {
        this.creditCard = creditCard;
    }

    public ArrayList<PaymentDetails> getDebitCard() {
        return debitCard;
    }

    public void setDebitCard(ArrayList<PaymentDetails> debitCard) {
        this.debitCard = debitCard;
    }

    public ArrayList<PaymentDetails> getNetBanks() {
        return netBanks;
    }

    public void setNetBanks(ArrayList<PaymentDetails> netBanks) {
        this.netBanks = netBanks;
    }

    public ArrayList<PaymentDetails> getCashCard() {
        return cashCard;
    }

    public void setCashCard(ArrayList<PaymentDetails> cashCard) {
        this.cashCard = cashCard;
    }

    public ArrayList<PaymentDetails> getIvr() {
        return ivr;
    }

    public void setIvr(ArrayList<PaymentDetails> ivr) {
        this.ivr = ivr;
    }

    public ArrayList<PaymentDetails> getIvrdc() {
        return ivrdc;
    }

    public void setIvrdc(ArrayList<PaymentDetails> ivrdc) {
        this.ivrdc = ivrdc;
    }

    public ArrayList<PaymentDetails> getPaisaWallet() {
        return paisaWallet;
    }

    public void setPaisaWallet(ArrayList<PaymentDetails> paisaWallet) {
        this.paisaWallet = paisaWallet;
    }

    public ArrayList<PaymentDetails> getLazyPay() {
        return lazyPay;
    }

    public void setLazyPay(ArrayList<PaymentDetails> lazyPay) {
        this.lazyPay = lazyPay;
    }

    public PostData getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(PostData responseStatus) {
        this.responseStatus = responseStatus;
    }

    public CardInformation getCardInformation() {
        return cardInformation;
    }

    public void setCardInformation(CardInformation cardInformation) {
        this.cardInformation = cardInformation;
    }

    public IFSCCodeDetails getIfscCodeDetails() {
        return ifscCodeDetails;
    }

    public void setIfscCodeDetails(IFSCCodeDetails ifscCodeDetails) {
        this.ifscCodeDetails = ifscCodeDetails;
    }

    public LookupDetails getLookupDetails() {
        return lookupDetails;
    }

    public void setLookupDetails(LookupDetails lookupDetails) {
        this.lookupDetails = lookupDetails;
    }

    public HashMap<String, Integer> getNetBankingDownStatus() {
        return netBankingDownStatus;
    }

    public void setNetBankingDownStatus(HashMap<String, Integer> netBankingDownStatus) {
        this.netBankingDownStatus = netBankingDownStatus;
    }

    public HashMap<String, CardStatus> getIssuingBankStatus() {
        return issuingBankStatus;
    }

    public void setIssuingBankStatus(HashMap<String, CardStatus> issuingBankStatus) {
        this.issuingBankStatus = issuingBankStatus;
    }

    public PayuOffer getPayuOffer() {
        return payuOffer;
    }

    public void setPayuOffer(PayuOffer payuOffer) {
        this.payuOffer = payuOffer;
    }

    public HashMap<String, HashMap<String, PayuEmiAmountAccordingToInterest>> getPayuEmiAmountAccordingToInterest() {
        return payuEmiAmountAccordingToInterest;
    }

    public void setPayuEmiAmountAccordingToInterest(HashMap<String, HashMap<String, PayuEmiAmountAccordingToInterest>> payuEmiAmountAccordingToInterest) {
        this.payuEmiAmountAccordingToInterest = payuEmiAmountAccordingToInterest;
    }


    public ArrayList<TransactionDetails> getTransactionDetailsList() {
        return transactionDetailsList;
    }

    public void setTransactionDetailsList(ArrayList<TransactionDetails> transactionDetailsList) {
        this.transactionDetailsList = transactionDetailsList;
    }

    public void setPhonePe(PaymentDetails phonePe) {
        this.phonePe = phonePe;
    }


    public void setTwid(PaymentDetails twid) {
        this.twid = twid;
    }

    public Upi getGenericIntent() {
        return genericIntent;
    }

    public void setGenericIntent(Upi genericIntent) {
        this.genericIntent = genericIntent;
    }

    // to avoid null pointer exception lets define isAvailable method.
    public Boolean isStoredCardsAvailable() {
        return this.storedCards != null && this.storedCards.size() > 0;
    }

    public Boolean isEligibleEmiBinsAvailable() {
        return this.eligibleEmiBins != null && this.eligibleEmiBins.size() > 0;
    }

    public Boolean isPhonePeIntentAvailable() {
        return this.phonePe != null;
    }

    public Boolean isTwidAvailable() {
        return this.twid != null;
    }

    public Boolean isGenericIntentAvailable() {
        return this.genericIntent != null;
    }

    public Boolean isEmiAvailable() {
        return this.emi != null && this.emi.size() > 0;
    }

    public Boolean isCCEmiAvailable() {
        return this.ccemi != null && this.ccemi.size() > 0;
    }

    public Boolean isDCEmiAvailable() {
        return this.dcemi != null && this.dcemi.size() > 0;
    }

    public Boolean isCardLessEmiAvailable() {
        return this.cardlessemi != null && this.cardlessemi.size() > 0;
    }

    public Boolean isNoCostEmiAvailable() {
        return this.noCostEMI != null && this.noCostEMI.size() > 0;
    }

    public Boolean isUpiAvailable() {
        return this.upi != null;
    }

    public Boolean isGoogleTezAvailable() {
        return this.googleTez != null;
    }

    public Boolean isGoogleTezOmniAvailable() {
        return this.googleTezOmni != null;
    }

    public Boolean isLazyPayAvailable() {
        return this.lazyPay != null && this.lazyPay.size() > 0;
    }

    public Boolean isCreditCardAvailable() {
        return this.creditCard != null && this.creditCard.size() > 0;
    }

    public Boolean isDebitCardAvailable() {
        return this.debitCard != null && this.debitCard.size() > 0;
    }

    public Boolean isNetBanksAvailable() {
        return this.netBanks != null && this.netBanks.size() > 0;
    }

    public Boolean isCashCardAvailable() {
        return this.cashCard != null && this.cashCard.size() > 0;
    }

    public Boolean isNEFTRTGSAvailable() {
        return this.neftRtgs != null && this.neftRtgs.size() > 0;
    }

    public Boolean isIVRAvailable() {
        return this.ivr != null && this.ivr.size() > 0;
    }

    public Boolean isIVRDCAvailable() {
        return this.ivrdc != null && this.ivrdc.size() > 0;
    }

    public Boolean isPaisaWalletAvailable() {
        return this.paisaWallet != null && this.paisaWallet.size() > 0;
    }

    public Boolean isResponseAvailable() {
        return this.responseStatus != null;
    }

    public Boolean isCardInformationAvailable() {
        return this.cardInformation != null;
    }

    public Boolean isIFSCDetailsAvailable() {
        return this.ifscCodeDetails != null;
    }

    public Boolean isTaxSpecificationAvailable() {
        return this.taxSpecification != null;
    }

    public Boolean isNetBankingStatusAvailable() {
        return this.netBankingDownStatus != null;
    }

    public Boolean isIssuingBankStatusAvailable() {
        return this.issuingBankStatus != null;
    }

    public Boolean isPayuOfferAvailable() {
        return this.payuOffer != null;
    }

    public Boolean isOfferDetailsAvailable() {
        return this.offerDetailsList != null;
    }

    public Boolean isPayuEmiAmountAccordingToInterestAvailable() {
        return this.payuEmiAmountAccordingToInterest != null;
    }

    public boolean isOfferAllowedOn(String bankCode, ArrayList<String> allowedOnList) {
        Set<String> offerAllowedOnSet = new HashSet<>(allowedOnList);
        return offerAllowedOnSet.contains(bankCode);
    }

    public ArrayList<PaymentDetails> getStandingInstructions() {
        return standingInstructions;
    }

    public void setStandingInstructions(ArrayList<PaymentDetails> standingInstructions) {
        this.standingInstructions = standingInstructions;
    }

    public void setNeftRtgs(ArrayList<PaymentDetails> neftRtgs) {
        this.neftRtgs = neftRtgs;
    }

    public ArrayList<PaymentDetails> getNeftRtgs() {
        return neftRtgs;
    }

    public Boolean isStandingInstructionsAvailable() {
        return this.standingInstructions != null && this.standingInstructions.size() > 0;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(storedCards);
        dest.writeTypedList(emi);
        dest.writeTypedList(noCostEMI);
        dest.writeTypedList(creditCard);
        dest.writeTypedList(debitCard);
        dest.writeTypedList(netBanks);
        dest.writeTypedList(cashCard);
        dest.writeTypedList(ivr);
        dest.writeTypedList(ivrdc);
        dest.writeTypedList(paisaWallet);
        dest.writeTypedList(lazyPay);
        dest.writeTypedList(mealCard);
        dest.writeParcelable(responseStatus, flags);
        dest.writeParcelable(cardInformation, flags);
        dest.writeParcelable(ifscCodeDetails, flags);
        dest.writeParcelable(lookupDetails, flags);
        dest.writeParcelable(taxSpecification, flags);
        dest.writeParcelable(payuOffer, flags);
        dest.writeTypedList(transactionDetailsList);
        dest.writeTypedList(offerDetailsList);
        dest.writeParcelable(payuOfferDetails, flags);
        dest.writeMap(payuEmiAmountAccordingToInterest);
        dest.writeTypedList(eligibleEmiBins);
        dest.writeTypedList(standingInstructions);
        dest.writeTypedList(siBankList);
        dest.writeStringList(downIssuingBanks);
        dest.writeTypedList(neftRtgs);
        dest.writeParcelable(tokenisedCardDetail, flags);
        dest.writeParcelable(sodexoCardInfo, flags);
        dest.writeParcelable(merchantInfo, flags);
        dest.writeStringList(upiSISupportedApps);
        dest.writeStringList(upiSISupportedHandles);
        dest.writeParcelable(fetchofferDetails, flags);
        dest.writeParcelable(validateOfferDetails, flags);
        dest.writeParcelable(adsInformationResponse, flags);
        dest.writeTypedList(bnpl);
        dest.writeTypedList(quickPaySavedOption);
        dest.writeTypedList(recommendedOptions);
        dest.writeTypedList(closedLoopWallet);
        dest.writeParcelable(binBaseDetailsResponse, flags);
        dest.writeByte((byte) (isUpiOtm ? 1 : 0));
        dest.writeByte((byte) (isIntentOtm ? 1 : 0));
        dest.writeSerializable(recurringAmtCFCharge);
        dest.writeSerializable(regAmtCFCharges);
        dest.writeSerializable(currentCfCharge);
    }

    public ArrayList<PaymentDetails> getSiBankList() {
        return siBankList;
    }

    public void setSiBankList(ArrayList<PaymentDetails> siBankList) {
        this.siBankList = siBankList;
    }

    public Boolean isSIBankListAvailable() {
        return this.siBankList != null && this.siBankList.size() > 0;
    }

    public Boolean isCreditCardAvailableFoSI() {
        if (standingInstructions != null) {
            for (PaymentDetails payment : standingInstructions) {
                if (payment.getBankCode().equalsIgnoreCase(PayuConstants.CCSI))
                    return true;
            }
        }
        return false;
    }

    public Boolean isDebitCardAvailableFoSI() {
        if (standingInstructions != null) {
            for (PaymentDetails payment : standingInstructions) {
                if (payment.getBankCode().equalsIgnoreCase(PayuConstants.DCSI) ||
                        payment.getBankCode().equalsIgnoreCase(PayuConstants.HDFCDCSI))
                    return true;
            }
        }
        return false;
    }

    public Boolean isNBAvailableFoSI() {
        return siBankList != null && siBankList.size() > 0;
    }

    public ArrayList<Emi> getCcemi() {
        return ccemi;
    }

    public void setCcemi(ArrayList<Emi> ccemi) {
        this.ccemi = ccemi;
    }

    public ArrayList<Emi> getDcemi() {
        return dcemi;
    }

    public void setDcemi(ArrayList<Emi> dcemi) {
        this.dcemi = dcemi;
    }

    public ArrayList<Emi> getCardlessemi() {
        return cardlessemi;
    }

    public void setCardlessemi(ArrayList<Emi> cardlessemi) {
        this.cardlessemi = cardlessemi;
    }

    public Boolean isUPIAvailableFoSI() {
        if (standingInstructions != null) {
            for (PaymentDetails payment : standingInstructions) {
                if (payment.getBankCode().equalsIgnoreCase(PayuConstants.UPISI))
                    return true;
            }
        }
        return false;
    }

    public Boolean isUPIIntentAvailableForSI() {
        if (standingInstructions != null) {
            for (PaymentDetails payment : standingInstructions) {
                if (payment.getBankCode().equalsIgnoreCase(PayuConstants.INTENTSI))
                    return true;
            }
        }
        return false;
    }

    public TokenisedCardDetail getTokenisedCardDetail() {
        return tokenisedCardDetail;
    }

    public Boolean isSodexoAvailable() {
        if (mealCard != null && !mealCard.isEmpty()) {
            for (PaymentDetails mealCard : mealCard) {
                if (mealCard.getBankCode().equalsIgnoreCase(PayuConstants.SODEXO))
                    return true;
            }
        }
        return false;
    }

    public void setTokenisedCardDetail(TokenisedCardDetail tokenisedCardDetail) {
        this.tokenisedCardDetail = tokenisedCardDetail;
    }

    public ArrayList<String> getUpiSISupportedApps() {
        return upiSISupportedApps;
    }

    public void setUpiSISupportedApps(ArrayList<String> upiSISupportedApps) {
        this.upiSISupportedApps = upiSISupportedApps;
    }

    public ArrayList<String> getUpiSISupportedHandles() {
        return upiSISupportedHandles;
    }

    public void setUpiSISupportedHandles(ArrayList<String> upiSISupportedHandles) {
        this.upiSISupportedHandles = upiSISupportedHandles;
    }

    public AdsInformationResponse getAdsInformation() {
        return adsInformationResponse;
    }

    public void setAdsInformation(AdsInformationResponse adsInformationResponse) {
        this.adsInformationResponse = adsInformationResponse;
    }

    public ArrayList<RecommendedOptions> getRecommendedOptions() {
        return recommendedOptions;
    }

    public void setRecommendedOptions(ArrayList<RecommendedOptions> recommendedOptions) {
        this.recommendedOptions = recommendedOptions;
    }

    public boolean isClosedLoopWalletPayAvailable() {
        return (closedLoopWallet != null &&  !closedLoopWallet.isEmpty());
    }

    public BinBaseDetailsResponse getBinBaseDetailsResponse() {
        return binBaseDetailsResponse;
    }

    public void setBinBaseDetailsResponse(BinBaseDetailsResponse binBaseDetailsResponse) {
        this.binBaseDetailsResponse = binBaseDetailsResponse;
    }

    public boolean isUpiAvailableForOtm() {
        return isUpiOtm;
    }

    public void setIsUpiAvailableForOtm(boolean isUpiOtm) {
        this.isUpiOtm = isUpiOtm;
    }

    public boolean isUpiIntentAvailableForOtm() {
        return isIntentOtm;
    }

    public void setIsIntentAvailableForOtm(boolean isIntentOtm) {
        this.isIntentOtm = isIntentOtm;
    }

    public HashMap<String, FetchConvFeeCombinations> getCurrentCfCharge() {
        return currentCfCharge;
    }

    public void setCurrentCfCharge(HashMap<String, FetchConvFeeCombinations> currentCfCharge) {
        this.currentCfCharge = currentCfCharge;
    }
}
