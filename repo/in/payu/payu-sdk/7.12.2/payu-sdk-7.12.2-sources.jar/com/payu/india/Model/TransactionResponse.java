package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by harmeet on 2/9/16.
 */
public class TransactionResponse implements Parcelable {

    private String transactionResponse;

    private String id;
    private String mode;
    private String status;
    private String unMappedStatus;
    private String key;
    private String txnid;
    private String transactionFee;
    private String cardCategory;
    private String discount;
    private String additionalCharges;
    private String addedOn;
    private String productInfo;
    private String firstName;
    private String email;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String hash;
    private String field1;
    private String field2;
    private String field3;
    private String field4;
    private String field9;
    private String paymentSource;
    private String pgType;
    private String bankRefNo;
    private String ibiboCode;
    private String errorCode;
    private String errorMessage;
    private String cardToken;
    private String nameOnCard;
    private String cardNumber;
    private String issuingBank;
    private String cardType;
    private String isSeamless;
    private String surl;
    private String furl;
    private String merchantHash;


    public TransactionResponse() {
//        this.transactionResponse = response;
//
//        try {
//            mJSONObject = new JSONObject(transactionResponse);
//            setValues();
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }


    }


//    public void setValues(){
//        if(mJSONObject == null)
//            return;
//        try {
//            Iterator<String> keysIterator = mJSONObject.keys();
//
//            while (keysIterator.hasNext()) {
//                switch (keysIterator.next()) {
//                    case PayuConstants.ID:
//                        if (mJSONObject.has(PayuConstants.ID)) {
//                            setId(mJSONObject.getString(PayuConstants.ID));
//                        }
//                        break;
//
//                    case PayuConstants.MODE:
//                        if (mJSONObject.has(PayuConstants.MODE)) {
//                            setId(mJSONObject.getString(PayuConstants.MODE));
//                        }
//                        break;
//
//                    case PayuConstants.STATUS:
//                        if (mJSONObject.has(PayuConstants.STATUS)) {
//                            setId(mJSONObject.getString(PayuConstants.STATUS));
//                        }
//                        break;
//
//                    case PayuConstants.UNMAPPED_STATUS:
//                        if (mJSONObject.has(PayuConstants.UNMAPPED_STATUS)) {
//                            setId(mJSONObject.getString(PayuConstants.UNMAPPED_STATUS));
//                        }
//                        break;
//
//                    case PayuConstants.KEY:
//                        if (mJSONObject.has(PayuConstants.KEY)) {
//                            setId(mJSONObject.getString(PayuConstants.KEY));
//                        }
//                        break;
//
//                    case PayuConstants.TXNID:
//                        if (mJSONObject.has(PayuConstants.TXNID)) {
//                            setId(mJSONObject.getString(PayuConstants.TXNID));
//                        }
//                        break;
//
//                    case PayuConstants.TRANSACTION_FEE:
//                        if (mJSONObject.has(PayuConstants.TRANSACTION_FEE)) {
//                            setId(mJSONObject.getString(PayuConstants.TRANSACTION_FEE));
//                        }
//                        break;
//
//                    case PayuConstants.CARDCATEGORY:
//                        if (mJSONObject.has(PayuConstants.CARDCATEGORY)) {
//                            setId(mJSONObject.getString(PayuConstants.CARDCATEGORY));
//                        }
//                        break;
//
//                    case PayuConstants.DISCOUNT:
//                        if (mJSONObject.has(PayuConstants.DISCOUNT)) {
//                            setId(mJSONObject.getString(PayuConstants.DISCOUNT));
//                        }
//                        break;
//
//                    case PayuConstants.ADDITIONAL_CHARGES:
//                        if (mJSONObject.has(PayuConstants.ADDITIONAL_CHARGES)) {
//                            setId(mJSONObject.getString(PayuConstants.ADDITIONAL_CHARGES));
//                        }
//                        break;
//
//                    case PayuConstants.ADDED_ON:
//                        if (mJSONObject.has(PayuConstants.ADDED_ON)) {
//                            setId(mJSONObject.getString(PayuConstants.ADDED_ON));
//                        }
//                        break;
//
//                    case PayuConstants.PRODUCT_INFO:
//                        if (mJSONObject.has(PayuConstants.PRODUCT_INFO)) {
//                            setId(mJSONObject.getString(PayuConstants.PRODUCT_INFO));
//                        }
//                        break;
//
//                    case PayuConstants.FIRST_NAME:
//                        if (mJSONObject.has(PayuConstants.FIRST_NAME)) {
//                            setId(mJSONObject.getString(PayuConstants.FIRST_NAME));
//                        }
//                        break;
//
//                    case PayuConstants.EMAIL:
//                        if (mJSONObject.has(PayuConstants.EMAIL)) {
//                            setId(mJSONObject.getString(PayuConstants.EMAIL));
//                        }
//                        break;
//
//                    case PayuConstants.UDF1:
//                        if (mJSONObject.has(PayuConstants.UDF1)) {
//                            setId(mJSONObject.getString(PayuConstants.UDF1));
//                        }
//                        break;
//
//                    case PayuConstants.UDF2:
//                        if (mJSONObject.has(PayuConstants.UDF2)) {
//                            setId(mJSONObject.getString(PayuConstants.UDF2));
//                        }
//                        break;
//
//                    case PayuConstants.UDF3:
//                        if (mJSONObject.has(PayuConstants.UDF3)) {
//                            setId(mJSONObject.getString(PayuConstants.UDF3));
//                        }
//                        break;
//
//                    case PayuConstants.UDF4:
//                        if (mJSONObject.has(PayuConstants.UDF4)) {
//                            setId(mJSONObject.getString(PayuConstants.UDF4));
//                        }
//                        break;
//
//                    case PayuConstants.UDF5:
//                        if (mJSONObject.has(PayuConstants.UDF5)) {
//                            setId(mJSONObject.getString(PayuConstants.UDF5));
//                        }
//                        break;
//
//                    case PayuConstants.HASH:
//                        if (mJSONObject.has(PayuConstants.HASH)) {
//                            setId(mJSONObject.getString(PayuConstants.HASH));
//                        }
//                        break;
//
//                    case PayuConstants.FIELD1:
//                        if (mJSONObject.has(PayuConstants.FIELD1)) {
//                            setId(mJSONObject.getString(PayuConstants.FIELD1));
//                        }
//                        break;
//
//                    case PayuConstants.FIELD2:
//                        if (mJSONObject.has(PayuConstants.FIELD2)) {
//                            setId(mJSONObject.getString(PayuConstants.FIELD2));
//                        }
//                        break;
//
//                    case PayuConstants.FIELD3:
//                        if (mJSONObject.has(PayuConstants.FIELD3)) {
//                            setId(mJSONObject.getString(PayuConstants.FIELD3));
//                        }
//                        break;
//
//                    case PayuConstants.FIELD4:
//                        if (mJSONObject.has(PayuConstants.FIELD4)) {
//                            setId(mJSONObject.getString(PayuConstants.FIELD4));
//                        }
//                        break;
//
//                    case PayuConstants.FIELD9:
//                        if (mJSONObject.has(PayuConstants.FIELD9)) {
//                            setId(mJSONObject.getString(PayuConstants.FIELD9));
//                        }
//                        break;
//
//                    case PayuConstants.PAYMENT_SOURCE:
//                        if (mJSONObject.has(PayuConstants.PAYMENT_SOURCE)) {
//                            setId(mJSONObject.getString(PayuConstants.PAYMENT_SOURCE));
//                        }
//                        break;
//
//                    case PayuConstants.PG_TYPE:
//                        if (mJSONObject.has(PayuConstants.PG_TYPE)) {
//                            setId(mJSONObject.getString(PayuConstants.PG_TYPE));
//                        }
//                        break;
//
//                    case PayuConstants.BANK_REF_NUM:
//                        if (mJSONObject.has(PayuConstants.BANK_REF_NUM)) {
//                            setId(mJSONObject.getString(PayuConstants.BANK_REF_NUM));
//                        }
//                        break;
//
//                    case PayuConstants.IBIBO_CODE:
//                        if (mJSONObject.has(PayuConstants.IBIBO_CODE)) {
//                            setId(mJSONObject.getString(PayuConstants.IBIBO_CODE));
//                        }
//                        break;
//
//                    case PayuConstants.ERROR_CODE:
//                        if (mJSONObject.has(PayuConstants.ERROR_CODE)) {
//                            setErrorCode(mJSONObject.getString(PayuConstants.ERROR_CODE));
//                        }
//                        break;
//
//                    case PayuConstants.ERROR_MESSAGE2:
//                        if (mJSONObject.has(PayuConstants.ERROR_MESSAGE2)) {
//                            setErrorMessage(mJSONObject.getString(PayuConstants.ERROR_MESSAGE2));
//                        }
//                        break;
//
//                    case PayuConstants.CARD_TOKEN:
//                        if (mJSONObject.has(PayuConstants.CARD_TOKEN)) {
//                            setCardToken(mJSONObject.getString(PayuConstants.CARD_TOKEN));
//                        }
//                        break;
//
//                    case PayuConstants.NAME_ON_CARD:
//                        if (mJSONObject.has(PayuConstants.NAME_ON_CARD)) {
//                            setNameOnCard(mJSONObject.getString(PayuConstants.NAME_ON_CARD));
//                        }
//                        break;
//
//                    case PayuConstants.CARD_NO:
//                        if (mJSONObject.has(PayuConstants.CARD_NO)) {
//                            setCardNumber(mJSONObject.getString(PayuConstants.CARD_NO));
//                        }
//                        break;
//
//                    case PayuConstants.ISSUINGBANK:
//                        if (mJSONObject.has(PayuConstants.ISSUINGBANK)) {
//                            setIssuingBank(mJSONObject.getString(PayuConstants.ISSUINGBANK));
//                        }
//                        break;
//
//                    case PayuConstants.CARD_TYPE:
//                        if (mJSONObject.has(PayuConstants.CARD_TYPE)) {
//                            setCardType(mJSONObject.getString(PayuConstants.CARD_TYPE));
//                        }
//                        break;
//
//                    case PayuConstants.IS_SEAMLESS:
//                        if (mJSONObject.has(PayuConstants.IS_SEAMLESS)) {
//                            setIsSeamless(mJSONObject.getString(PayuConstants.IS_SEAMLESS));
//                        }
//                        break;
//
//                    case PayuConstants.SURL:
//                        if (mJSONObject.has(PayuConstants.SURL)) {
//                            setSurl(mJSONObject.getString(PayuConstants.SURL));
//                        }
//                        break;
//
//                    case PayuConstants.FURL:
//                        if (mJSONObject.has(PayuConstants.FURL)) {
//                            setFurl(mJSONObject.getString(PayuConstants.FURL));
//                        }
//                        break;
//
//
//                    case PayuConstants.MERCHANT_HASH:
//                        if (mJSONObject.has(PayuConstants.MERCHANT_HASH)) {
//                            setMerchantHash(mJSONObject.getString(PayuConstants.MERCHANT_HASH));
//                        }
//                        break;
//
//                }
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }

    protected TransactionResponse(Parcel in) {
        id = in.readString();
        mode = in.readString();
        status = in.readString();
        unMappedStatus = in.readString();
        key = in.readString();
        txnid = in.readString();
        transactionFee = in.readString();
        cardCategory = in.readString();
        discount = in.readString();
        additionalCharges = in.readString();
        addedOn = in.readString();
        productInfo = in.readString();
        firstName = in.readString();
        email = in.readString();
        udf1 = in.readString();
        udf2 = in.readString();
        udf3 = in.readString();
        udf4 = in.readString();
        udf5 = in.readString();
        hash = in.readString();
        field1 = in.readString();
        field2 = in.readString();
        field3 = in.readString();
        field4 = in.readString();
        field9 = in.readString();
        paymentSource = in.readString();
        pgType = in.readString();
        bankRefNo = in.readString();
        ibiboCode = in.readString();
        errorCode = in.readString();
        errorMessage = in.readString();
        cardToken = in.readString();
        nameOnCard = in.readString();
        cardNumber = in.readString();
        issuingBank = in.readString();
        cardType = in.readString();
        isSeamless = in.readString();
        surl = in.readString();
        furl = in.readString();
        merchantHash = in.readString();
    }

    public static final Creator<TransactionResponse> CREATOR = new Creator<TransactionResponse>() {
        @Override
        public TransactionResponse createFromParcel(Parcel in) {
            return new TransactionResponse(in);
        }

        @Override
        public TransactionResponse[] newArray(int size) {
            return new TransactionResponse[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUnMappedStatus() {
        return unMappedStatus;
    }

    public void setUnMappedStatus(String unMappedStatus) {
        this.unMappedStatus = unMappedStatus;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTxnid() {
        return txnid;
    }

    public void setTxnid(String txnid) {
        this.txnid = txnid;
    }

    public String getTransactionFee() {
        return transactionFee;
    }

    public void setTransactionFee(String transactionFee) {
        this.transactionFee = transactionFee;
    }

    public String getCardCategory() {
        return cardCategory;
    }

    public void setCardCategory(String cardCategory) {
        this.cardCategory = cardCategory;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getAdditionalCharges() {
        return additionalCharges;
    }

    public void setAdditionalCharges(String additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    public String getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(String addedOn) {
        this.addedOn = addedOn;
    }

    public String getProductInfo() {
        return productInfo;
    }

    public void setProductInfo(String productInfo) {
        this.productInfo = productInfo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUdf1() {
        return udf1;
    }

    public void setUdf1(String udf1) {
        this.udf1 = udf1;
    }

    public String getUdf2() {
        return udf2;
    }

    public void setUdf2(String udf2) {
        this.udf2 = udf2;
    }

    public String getUdf3() {
        return udf3;
    }

    public void setUdf3(String udf3) {
        this.udf3 = udf3;
    }

    public String getUdf4() {
        return udf4;
    }

    public void setUdf4(String udf4) {
        this.udf4 = udf4;
    }

    public String getUdf5() {
        return udf5;
    }

    public void setUdf5(String udf5) {
        this.udf5 = udf5;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getField1() {
        return field1;
    }

    public void setField1(String field1) {
        this.field1 = field1;
    }

    public String getField2() {
        return field2;
    }

    public void setField2(String field2) {
        this.field2 = field2;
    }

    public String getField3() {
        return field3;
    }

    public void setField3(String field3) {
        this.field3 = field3;
    }

    public String getField4() {
        return field4;
    }

    public void setField4(String field4) {
        this.field4 = field4;
    }

    public String getField9() {
        return field9;
    }

    public void setField9(String field9) {
        this.field9 = field9;
    }

    public String getPaymentSource() {
        return paymentSource;
    }

    public void setPaymentSource(String paymentSource) {
        this.paymentSource = paymentSource;
    }

    public String getPgType() {
        return pgType;
    }

    public void setPgType(String pgType) {
        this.pgType = pgType;
    }

    public String getBankRefNo() {
        return bankRefNo;
    }

    public void setBankRefNo(String bankRefNo) {
        this.bankRefNo = bankRefNo;
    }

    public String getIbiboCode() {
        return ibiboCode;
    }

    public void setIbiboCode(String ibiboCode) {
        this.ibiboCode = ibiboCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getCardToken() {
        return cardToken;
    }

    public void setCardToken(String cardToken) {
        this.cardToken = cardToken;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getIssuingBank() {
        return issuingBank;
    }

    public void setIssuingBank(String issuingBank) {
        this.issuingBank = issuingBank;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getIsSeamless() {
        return isSeamless;
    }

    public void setIsSeamless(String isSeamless) {
        this.isSeamless = isSeamless;
    }

    public String getSurl() {
        return surl;
    }

    public void setSurl(String surl) {
        this.surl = surl;
    }

    public String getFurl() {
        return furl;
    }

    public void setFurl(String furl) {
        this.furl = furl;
    }

    public String getMerchantHash() {
        return merchantHash;
    }

    public void setMerchantHash(String merchantHash) {
        this.merchantHash = merchantHash;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(mode);
        dest.writeString(status);
        dest.writeString(unMappedStatus);
        dest.writeString(key);
        dest.writeString(txnid);
        dest.writeString(transactionFee);
        dest.writeString(cardCategory);
        dest.writeString(discount);
        dest.writeString(additionalCharges);
        dest.writeString(addedOn);
        dest.writeString(productInfo);
        dest.writeString(firstName);
        dest.writeString(email);
        dest.writeString(udf1);
        dest.writeString(udf2);
        dest.writeString(udf3);
        dest.writeString(udf4);
        dest.writeString(udf5);
        dest.writeString(hash);
        dest.writeString(field1);
        dest.writeString(field2);
        dest.writeString(field3);
        dest.writeString(field4);
        dest.writeString(field9);
        dest.writeString(paymentSource);
        dest.writeString(pgType);
        dest.writeString(bankRefNo);
        dest.writeString(ibiboCode);
        dest.writeString(errorCode);
        dest.writeString(errorMessage);
        dest.writeString(cardToken);
        dest.writeString(nameOnCard);
        dest.writeString(cardNumber);
        dest.writeString(issuingBank);
        dest.writeString(cardType);
        dest.writeString(isSeamless);
        dest.writeString(surl);
        dest.writeString(furl);
        dest.writeString(merchantHash);
    }
}
