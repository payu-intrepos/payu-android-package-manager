package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface LookupApiListener {
    void onLookupApiResponse(PayuResponse payuResponse);
}
