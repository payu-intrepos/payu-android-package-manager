package com.payu.india.Model;

public class CheckBalanceRequest {
    private String sodexoSourceId;

    private CheckBalanceRequest(Builder builder) {
        this.sodexoSourceId = builder.sodexoSourceId;
    }

    public static class Builder {
        private String sodexoSourceId;

        public Builder setsodexoSourceId(String sodexoSourceId) {
            this.sodexoSourceId = sodexoSourceId;
            return this;
        }

        public CheckBalanceRequest build() {
            return new CheckBalanceRequest(this);
        }
    }
}
