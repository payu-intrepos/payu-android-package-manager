package com.payu.india.Interfaces;

public interface V2ApiResponseListener<T> {
    void onApiResponse(T t);
}
