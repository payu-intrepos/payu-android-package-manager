package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class DiscountDetailsofOffers extends Discount implements Parcelable {
    private String discountPercentage;
    private double maxDiscount;

    public DiscountDetailsofOffers() {
    }

    public String getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(String discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public double getMaxDiscount() {
        return maxDiscount;
    }

    public void setMaxDiscount(double maxDiscount) {
        this.maxDiscount = maxDiscount;
    }

    protected DiscountDetailsofOffers(Parcel in) {
        super(in);
        discountPercentage = in.readString();
        maxDiscount = in.readDouble();
    }


    public static final Creator<DiscountDetailsofOffers> CREATOR = new Creator<DiscountDetailsofOffers>() {
        @Override
        public DiscountDetailsofOffers createFromParcel(Parcel in) {
            return new DiscountDetailsofOffers(in);
        }

        @Override
        public DiscountDetailsofOffers[] newArray(int size) {
            return new DiscountDetailsofOffers[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(discountPercentage);
        parcel.writeDouble(maxDiscount);
    }
}
