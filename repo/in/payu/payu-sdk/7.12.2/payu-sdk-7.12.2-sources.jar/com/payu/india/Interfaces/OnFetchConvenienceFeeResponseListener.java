package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface OnFetchConvenienceFeeResponseListener {
    void onFetchConvenienceFeeResponse(PayuResponse payuResponse);
}