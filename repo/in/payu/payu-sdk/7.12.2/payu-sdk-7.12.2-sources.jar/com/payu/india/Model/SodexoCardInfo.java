package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import com.payu.india.Model.Olw.OlwSDKInfo;

public class SodexoCardInfo implements Parcelable {

    private String cardNo;
    private String cardBalance;
    private String cardName;
    private String msg;
    private OlwSDKInfo olwSDKInfo;

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardBalance() {
        return cardBalance;
    }

    public void setCardBalance(String cardBalance) {
        this.cardBalance = cardBalance;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public OlwSDKInfo getOlwSDKInfo() {
        return olwSDKInfo;
    }

    public void setOlwSDKInfo(OlwSDKInfo olwSDKInfo) {
        this.olwSDKInfo = olwSDKInfo;
    }

    public SodexoCardInfo() {

    }

    protected SodexoCardInfo(Parcel in) {
        cardNo = in.readString();
        cardBalance = in.readString();
        cardName = in.readString();
        msg = in.readString();
        olwSDKInfo = in.readParcelable(OlwSDKInfo.class.getClassLoader());
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(cardNo);
        parcel.writeString(cardBalance);
        parcel.writeString(cardName);
        parcel.writeString(msg);
        parcel.writeParcelable(olwSDKInfo, i);
    }

    public static final Creator<SodexoCardInfo> CREATOR = new Creator<SodexoCardInfo>() {
        @Override
        public SodexoCardInfo createFromParcel(Parcel in) {
            return new SodexoCardInfo(in);
        }

        @Override
        public SodexoCardInfo[] newArray(int size) {
            return new SodexoCardInfo[size];
        }
    };
}
