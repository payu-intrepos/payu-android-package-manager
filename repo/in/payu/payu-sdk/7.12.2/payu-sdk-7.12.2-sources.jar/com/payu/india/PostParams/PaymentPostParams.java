package com.payu.india.PostParams;

import com.payu.india.Payu.PayuUtils;
import com.payu.paymentparamhelper.PaymentParams;

public class PaymentPostParams extends com.payu.paymentparamhelper.PaymentPostParams {

    public PaymentPostParams(PaymentParams paymentParams, String paymentMode) {
        super(paymentParams, paymentMode);
        paymentParams.setSdkPlatformData(PayuUtils.getAnalyticsString(paymentParams.getSdkPlatformData()));
    }
}
