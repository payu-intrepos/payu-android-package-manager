package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class TaxSpecification implements Parcelable {

    private String ccTaxValue;
    private String dcTaxValue;
    private String nbTaxValue;
    private String emiTaxValue;
    private String cashTaxValue;
    private String upiTaxValue;
    private String lazypayTaxValue;
    private String enachTaxValue;
    private String siTaxValue;
    private String neftRtgsTaxValue;
    private String mealCardTaxValue;
    private String bnplTaxValue;
    private String clwTaxValue;

    public String getMealCardTaxValue() {
        return mealCardTaxValue;
    }

    public void setMealCardTaxValue(String mealCardTaxValue) {
        this.mealCardTaxValue = mealCardTaxValue;
    }


    public String getSiTaxValue() {
        return siTaxValue;
    }

    public void setSiTaxValue(String siTaxValue) {
        this.siTaxValue = siTaxValue;
    }

    public String getLazypayTaxValue() {
        return lazypayTaxValue;
    }

    public void setLazypayTaxValue(String lazypayTaxValue) {
        this.lazypayTaxValue = lazypayTaxValue;
    }

    public String getEnachTaxValue() {
        return enachTaxValue;
    }

    public void setEnachTaxValue(String enachTaxValue) {
        this.enachTaxValue = enachTaxValue;
    }

    public String getCcTaxValue() {
        return ccTaxValue;
    }

    public void setCcTaxValue(String ccTaxValue) {
        this.ccTaxValue = ccTaxValue;
    }

    public String getDcTaxValue() {
        return dcTaxValue;
    }

    public void setDcTaxValue(String dcTaxValue) {
        this.dcTaxValue = dcTaxValue;
    }

    public String getNbTaxValue() {
        return nbTaxValue;
    }

    public void setNbTaxValue(String nbTaxValue) {
        this.nbTaxValue = nbTaxValue;
    }

    public String getEmiTaxValue() {
        return emiTaxValue;
    }

    public void setEmiTaxValue(String emiTaxValue) {
        this.emiTaxValue = emiTaxValue;
    }

    public String getCashTaxValue() {
        return cashTaxValue;
    }

    public void setCashTaxValue(String cashTaxValue) {
        this.cashTaxValue = cashTaxValue;
    }

    public String getUpiTaxValue() {
        return upiTaxValue;
    }

    public void setUpiTaxValue(String upiTaxValue) {
        this.upiTaxValue = upiTaxValue;
    }

    public String getNeftRtgsTaxValue() {
        return neftRtgsTaxValue;
    }

    public void setNeftRtgsTaxValue(String neftRtgsTaxValue) {
        this.neftRtgsTaxValue = neftRtgsTaxValue;
    }

    public String getBnplTaxValue() {
        return bnplTaxValue;
    }

    public void setBnplTaxValue(String bnplTaxValue) {
        this.bnplTaxValue = bnplTaxValue;
    }

    public String getClwTaxValue() {
        return clwTaxValue;
    }

    public void setClwTaxValue(String clwTaxValue) {
        this.clwTaxValue = clwTaxValue;
    }

    public TaxSpecification() {
    }

    protected TaxSpecification(Parcel in) {
        ccTaxValue = in.readString();
        dcTaxValue = in.readString();
        nbTaxValue = in.readString();
        emiTaxValue = in.readString();
        cashTaxValue = in.readString();
        upiTaxValue = in.readString();
        lazypayTaxValue = in.readString();
        enachTaxValue = in.readString();
        siTaxValue = in.readString();
        neftRtgsTaxValue = in.readString();
        mealCardTaxValue = in.readString();
        clwTaxValue = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ccTaxValue);
        dest.writeString(dcTaxValue);
        dest.writeString(nbTaxValue);
        dest.writeString(emiTaxValue);
        dest.writeString(cashTaxValue);
        dest.writeString(upiTaxValue);
        dest.writeString(lazypayTaxValue);
        dest.writeString(enachTaxValue);
        dest.writeString(siTaxValue);
        dest.writeString(neftRtgsTaxValue);
        dest.writeString(mealCardTaxValue);
        dest.writeString(clwTaxValue);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TaxSpecification> CREATOR = new Creator<TaxSpecification>() {
        @Override
        public TaxSpecification createFromParcel(Parcel in) {
            return new TaxSpecification(in);
        }

        @Override
        public TaxSpecification[] newArray(int size) {
            return new TaxSpecification[size];
        }
    };
}
