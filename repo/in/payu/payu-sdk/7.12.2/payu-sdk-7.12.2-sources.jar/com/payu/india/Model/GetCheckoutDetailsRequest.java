package com.payu.india.Model;

import android.util.Log;

import com.payu.india.Payu.PayuConstants;
import com.payu.paymentparamhelper.siparams.SIParamsDetails;

import org.json.JSONException;
import org.json.JSONObject;

public class GetCheckoutDetailsRequest {
    private final String requestId;
    private CheckoutFilter checkoutFilter;
    private CustomerDetails customerDetails;
    private Usecase usecase;
    private GetTransactionDetails transactionDetails;
    private Boolean isSiTxn;
    private SIParamsDetails siDetails;
    private Boolean freeTrial;

    private GetCheckoutDetailsRequest(Builder builder) {
        this.requestId = builder.requestId;
        this.checkoutFilter = builder.checkoutFilter;
        this.usecase = builder.usecase;
        this.customerDetails = builder.customerDetails;
        this.transactionDetails = builder.transactionDetails;
        this.isSiTxn = builder.isSiTxn;
        this.siDetails = builder.siDetails;
        this.freeTrial = builder.freeTrial;
    }

    public String prepareJSON() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(PayuConstants.P_REQUEST_ID, requestId);

            if (transactionDetails != null) {
                jsonObject.put(PayuConstants.P_TRANSACTION_DETAILS, transactionDetails.prepareTransactionDetailsJson());
            }
            if (customerDetails != null) {
                jsonObject.put(PayuConstants.P_CUSTOMER_DETAILS, customerDetails.prepareCustomerDetailsObject());
            }
            if (checkoutFilter != null) {
                jsonObject.put(PayuConstants.P_FILTERS, checkoutFilter.prepareFilterJson());
            }
            if (usecase != null) {
                jsonObject.put(PayuConstants.P_USE_CASE, usecase.prepareUseCaseJson());
            }
            if (isSiTxn != null) {
                jsonObject.put(PayuConstants.PAYU_IS_SI_TXN, isSiTxn);
            }
            if(siDetails != null) {
                jsonObject.put(PayuConstants.SI_DETAILS, siDetails.prepareSIParamsJson());
            }
            if (freeTrial != null) {
                int isFreeTrial = freeTrial ? 1 : 0;
                jsonObject.put(PayuConstants.PAYU_FREE_TRIAL, isFreeTrial);
            }
        } catch (JSONException e) {
            Log.d(getClass().getSimpleName(),"JSONException " + e.getMessage());
        }
        return jsonObject.toString();
    }

    public static class Builder {
        private String requestId = String.valueOf(System.currentTimeMillis());
        private CheckoutFilter checkoutFilter = null;
        private CustomerDetails customerDetails = null;
        private Usecase usecase = null;
        private GetTransactionDetails transactionDetails = null;
        private Boolean isSiTxn;
        private SIParamsDetails siDetails;
        private Boolean freeTrial;

        public Builder setRequestId(String requestId) {
            this.requestId = requestId;
            return this;
        }


        public Builder setCheckoutFilter(CheckoutFilter checkoutFilter) {
            this.checkoutFilter = checkoutFilter;
            return this;
        }

        public Builder setCustomerDetails(CustomerDetails customerDetails) {
            this.customerDetails = customerDetails;
            return this;
        }

        public Builder setUsecase(Usecase usecase) {
            this.usecase = usecase;
            return this;
        }

        public Builder setTransactionDetails(GetTransactionDetails transactionDetails) {
            this.transactionDetails = transactionDetails;
            return this;
        }

        public Builder setSiTxn(Boolean siTxn) {
            isSiTxn = siTxn;
            return this;
        }

        public Builder setSiDetails(SIParamsDetails siDetails) {
            this.siDetails = siDetails;
            return this;
        }

        public Builder setFreeTrial(Boolean freeTrial) {
            this.freeTrial = freeTrial;
            return this;
        }

        public GetCheckoutDetailsRequest build() {
            return new GetCheckoutDetailsRequest(this);
        }
    }
}
