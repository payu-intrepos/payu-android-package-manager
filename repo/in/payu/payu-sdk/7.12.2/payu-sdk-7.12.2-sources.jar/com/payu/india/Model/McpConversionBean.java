package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class McpConversionBean implements Parcelable {

    String offerAmount;
    String offerCurrency;
    String offerExchangeRate;
    String merchantOrderId;
    String lookupId;

    public McpConversionBean(Parcel in) {
        offerAmount = in.readString();
        offerCurrency = in.readString();
        offerExchangeRate = in.readString();
        merchantOrderId = in.readString();
        lookupId = in.readString();
    }

    public McpConversionBean() {
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(offerAmount);
        dest.writeString(offerCurrency);
        dest.writeString(offerExchangeRate);
        dest.writeString(merchantOrderId);
        dest.writeString(lookupId);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<McpConversionBean> CREATOR = new Creator<McpConversionBean>() {
        @Override
        public McpConversionBean createFromParcel(Parcel in) {
            return new McpConversionBean(in);
        }

        @Override
        public McpConversionBean[] newArray(int size) {
            return new McpConversionBean[size];
        }
    };

    public String getOfferAmount() {
        return offerAmount;
    }

    public void setOfferAmount(String offerAmount) {
        this.offerAmount = offerAmount;
    }

    public String getOfferCurrency() {
        return offerCurrency;
    }

    public void setOfferCurrency(String offerCurrency) {
        this.offerCurrency = offerCurrency;
    }

    public String getOfferExchangeRate() {
        return offerExchangeRate;
    }

    public void setOfferExchangeRate(String offerExchangeRate) {
        this.offerExchangeRate = offerExchangeRate;
    }

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }

    public String getLookupId() {
        return lookupId;
    }

    public void setLookupId(String lookupId) {
        this.lookupId = lookupId;
    }
}
