package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface OnEmiCalculaterListener {
    void onEmiCalculatorResponse(PayuResponse payuResponse);
}
