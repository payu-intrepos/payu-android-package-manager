package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by Minie on 29/11/16.
 */

public class Upi extends PaymentProductDetails implements Parcelable {

    String title;

    public String getPgID() {
        return pgID;
    }

    public void setPgID(String pgID) {
        this.pgID = pgID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBankID() {
        return bankID;
    }

    public void setBankID(String bankID) {
        this.bankID = bankID;
    }

    public String getShowForm() {
        return showForm;
    }

    public void setShowForm(String showForm) {
        this.showForm = showForm;
    }

    public String getAdditionalCharge() {
        return additionalCharge;
    }

    public void setAdditionalCharge(String additionalCharge) {
        this.additionalCharge = additionalCharge;
    }

    public boolean isBankDown() {
        return isBankDown;
    }

    public void setBankDown(boolean bankDown) {
        isBankDown = bankDown;
    }

    public ArrayList<PayuOffer> getOfferDetailsList() {
        return offerDetailsList;
    }

    public void setOfferDetailsList(ArrayList<PayuOffer> offerDetailsList) {
        this.offerDetailsList = offerDetailsList;
    }

    String pgID;
    String showForm;
    String bankID;
    String additionalCharge;
    private boolean isBankDown;
    private ArrayList<PayuOffer> offerDetailsList;

    public Upi() {

    }

    protected Upi(Parcel in) {
        title = in.readString();
        pgID = in.readString();
        showForm = in.readString();
        bankID = in.readString();
        additionalCharge = in.readString();
        isBankDown = in.readByte() != 0;
        offerDetailsList = in.createTypedArrayList(PayuOffer.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(pgID);
        dest.writeString(showForm);
        dest.writeString(bankID);
        dest.writeString(additionalCharge);
        dest.writeByte((byte) (isBankDown ? 1 : 0));
        dest.writeTypedList(offerDetailsList);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Upi> CREATOR = new Creator<Upi>() {
        @Override
        public Upi createFromParcel(Parcel in) {
            return new Upi(in);
        }

        @Override
        public Upi[] newArray(int size) {
            return new Upi[size];
        }
    };
}
