package com.payu.india.Model;

public class PaymentParams extends com.payu.paymentparamhelper.PaymentParams {
}
