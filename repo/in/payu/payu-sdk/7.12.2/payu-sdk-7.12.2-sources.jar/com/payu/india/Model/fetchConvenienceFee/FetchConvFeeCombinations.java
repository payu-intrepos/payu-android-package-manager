package com.payu.india.Model.fetchConvenienceFee;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class FetchConvFeeCombinations implements Parcelable {

    private String combinationUUID;
    private String combinationKey;
    private String requestUuid;
    private ArrayList<Charges> charges;

    public FetchConvFeeCombinations(){

    }

    protected FetchConvFeeCombinations(Parcel in){
        combinationUUID = in.readString();
        combinationKey = in.readString();
        requestUuid = in.readString();
        charges = in.createTypedArrayList(Charges.CREATOR);
    }

    public static final Creator<FetchConvFeeCombinations> CREATOR = new Creator<FetchConvFeeCombinations>() {
        @Override
        public FetchConvFeeCombinations createFromParcel(Parcel in) {
            return new FetchConvFeeCombinations(in);
        }

        @Override
        public FetchConvFeeCombinations[] newArray(int size) {
            return new FetchConvFeeCombinations[size];
        }
    };
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(combinationUUID);
        parcel.writeString(combinationKey);
        parcel.writeString(requestUuid);
        parcel.writeTypedList(charges);
    }

    public String getCombinationUUID() {
        return combinationUUID;
    }

    public void setCombinationUUID(String combinationUUID) {
        this.combinationUUID = combinationUUID;
    }

    public String getCombinationKey() {
        return combinationKey;
    }

    public void setCombinationKey(String combinationKey) {
        this.combinationKey = combinationKey;
    }

    public String getRequestUuid() {
        return requestUuid;
    }

    public void setRequestUuid(String requestUuid) {
        this.requestUuid = requestUuid;
    }

    public ArrayList<Charges> getConvFeeCharges() {
        return charges;
    }

    public void setCharges(ArrayList<Charges> chargesArrayList) {
        this.charges = chargesArrayList;
    }
}
