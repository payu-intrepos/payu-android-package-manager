package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface CheckBalanceListener {
    void onCheckBalanceResponse(PayuResponse payuResponse);
}
