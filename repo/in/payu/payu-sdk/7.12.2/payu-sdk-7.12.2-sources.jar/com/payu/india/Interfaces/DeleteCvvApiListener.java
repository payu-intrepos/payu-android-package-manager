package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

/**
 * Created by franklin on 08/10/15.
 */
public interface DeleteCvvApiListener {
    void onDeleteCvvApiResponse(PayuResponse payuResponse);
}
