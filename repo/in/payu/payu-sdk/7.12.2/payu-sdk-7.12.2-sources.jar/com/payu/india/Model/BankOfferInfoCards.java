package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class BankOfferInfoCards implements Parcelable {
    private ArrayList<PaymentOptionOfferinfo> banksListForCCCards;
    private ArrayList<PaymentOptionOfferinfo> banksListForDCCards;

    public BankOfferInfoCards(){

    }

    protected BankOfferInfoCards(Parcel in) {
        banksListForCCCards = in.createTypedArrayList(PaymentOptionOfferinfo.CREATOR);
        banksListForDCCards = in.createTypedArrayList(PaymentOptionOfferinfo.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(banksListForCCCards);
        dest.writeTypedList(banksListForDCCards);
    }

    public ArrayList<PaymentOptionOfferinfo> getBanksListForCCCards() {
        return banksListForCCCards;
    }

    public void setBanksListForCCCards(ArrayList<PaymentOptionOfferinfo> banksListForCCCards) {
        this.banksListForCCCards = banksListForCCCards;
    }

    public ArrayList<PaymentOptionOfferinfo> getBanksListForDCCards() {
        return banksListForDCCards;
    }

    public void setBanksListForDCCards(ArrayList<PaymentOptionOfferinfo> banksListForDCCards) {
        this.banksListForDCCards = banksListForDCCards;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<BankOfferInfoCards> CREATOR = new Creator<BankOfferInfoCards>() {
        @Override
        public BankOfferInfoCards createFromParcel(Parcel in) {
            return new BankOfferInfoCards(in);
        }

        @Override
        public BankOfferInfoCards[] newArray(int size) {
            return new BankOfferInfoCards[size];
        }
    };
}
