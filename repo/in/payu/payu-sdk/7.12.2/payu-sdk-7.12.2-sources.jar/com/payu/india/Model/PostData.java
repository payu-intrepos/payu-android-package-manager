package com.payu.india.Model;

public class PostData extends com.payu.paymentparamhelper.PostData {
}
