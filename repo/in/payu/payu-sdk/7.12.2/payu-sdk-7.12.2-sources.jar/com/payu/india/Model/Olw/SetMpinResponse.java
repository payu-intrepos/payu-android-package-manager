package com.payu.india.Model.Olw;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class SetMpinResponse implements Parcelable {
  private String responseDateTime;

  private String clientTxnId;

  private String mpinExpiryTime;

  private Integer messageCode;

  private String tokenExpiryTime;

  private String responseMessage;

  private String deviceId;

  private String responseCode;

  private String token;

  protected SetMpinResponse(Parcel in) {
    responseDateTime = in.readString();
    clientTxnId = in.readString();
    mpinExpiryTime = in.readString();
    if (in.readByte() == 0) {
      messageCode = null;
    } else {
      messageCode = in.readInt();
    }
    tokenExpiryTime = in.readString();
    responseMessage = in.readString();
    deviceId = in.readString();
    responseCode = in.readString();
    token = in.readString();
  }

  public static final Creator<SetMpinResponse> CREATOR = new Creator<SetMpinResponse>() {
    @Override
    public SetMpinResponse createFromParcel(Parcel in) {
      return new SetMpinResponse(in);
    }

    @Override
    public SetMpinResponse[] newArray(int size) {
      return new SetMpinResponse[size];
    }
  };

  public String getResponseDateTime() {
    return this.responseDateTime;
  }

  public void setResponseDateTime(String responseDateTime) {
    this.responseDateTime = responseDateTime;
  }

  public String getClientTxnId() {
    return this.clientTxnId;
  }

  public void setClientTxnId(String clientTxnId) {
    this.clientTxnId = clientTxnId;
  }

  public String getMpinExpiryTime() {
    return this.mpinExpiryTime;
  }

  public void setMpinExpiryTime(String mpinExpiryTime) {
    this.mpinExpiryTime = mpinExpiryTime;
  }

  public Integer getMessageCode() {
    return this.messageCode;
  }

  public void setMessageCode(Integer messageCode) {
    this.messageCode = messageCode;
  }

  public String getTokenExpiryTime() {
    return this.tokenExpiryTime;
  }

  public void setTokenExpiryTime(String tokenExpiryTime) {
    this.tokenExpiryTime = tokenExpiryTime;
  }

  public String getResponseMessage() {
    return this.responseMessage;
  }

  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }

  public String getDeviceId() {
    return this.deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }

  public String getResponseCode() {
    return this.responseCode;
  }

  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }

  public String getToken() {
    return this.token;
  }

  public void setToken(String token) {
    this.token = token;
  }

  @Override
  public int describeContents() {
    return 0;
  }

  @Override
  public void writeToParcel(@NonNull Parcel parcel, int i) {
    parcel.writeString(responseDateTime);
    parcel.writeString(clientTxnId);
    parcel.writeString(mpinExpiryTime);
    if (messageCode == null) {
      parcel.writeByte((byte) 0);
    } else {
      parcel.writeByte((byte) 1);
      parcel.writeInt(messageCode);
    }
    parcel.writeString(tokenExpiryTime);
    parcel.writeString(responseMessage);
    parcel.writeString(deviceId);
    parcel.writeString(responseCode);
    parcel.writeString(token);
  }
}
