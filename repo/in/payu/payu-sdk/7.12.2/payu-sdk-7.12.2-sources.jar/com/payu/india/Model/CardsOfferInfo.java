package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class CardsOfferInfo implements Parcelable {

    private BankOfferInfoCards bankOfferInfoCards;
    private NetworkOfferInfoCards networkOfferInfoCards;

    public CardsOfferInfo(){

    }

    protected CardsOfferInfo(Parcel in) {
        bankOfferInfoCards = in.readParcelable(BankOfferInfoCards.class.getClassLoader());
        networkOfferInfoCards = in.readParcelable(NetworkOfferInfoCards.class.getClassLoader());
    }

    public static final Creator<CardsOfferInfo> CREATOR = new Creator<CardsOfferInfo>() {
        @Override
        public CardsOfferInfo createFromParcel(Parcel in) {
            return new CardsOfferInfo(in);
        }

        @Override
        public CardsOfferInfo[] newArray(int size) {
            return new CardsOfferInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(bankOfferInfoCards, i);
        parcel.writeParcelable(networkOfferInfoCards, i);
    }

    public BankOfferInfoCards getBankOfferInfoCards() {
        return bankOfferInfoCards;
    }

    public void setBankOfferInfoCards(BankOfferInfoCards bankOfferInfoCards) {
        this.bankOfferInfoCards = bankOfferInfoCards;
    }

    public NetworkOfferInfoCards getNetworkOfferInfoCards() {
        return networkOfferInfoCards;
    }

    public void setNetworkOfferInfoCards(NetworkOfferInfoCards networkOfferInfoCards) {
        this.networkOfferInfoCards = networkOfferInfoCards;
    }
}
