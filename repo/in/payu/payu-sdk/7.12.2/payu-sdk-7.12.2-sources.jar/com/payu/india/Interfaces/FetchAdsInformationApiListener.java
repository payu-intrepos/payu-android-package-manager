package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;
import com.payu.india.Tasks.FetchAdsInformationTask;

/**
 * An Interface to Make a communication between {@link FetchAdsInformationTask} and Calling Activity
 * Calling Activity should implement {@link com.payu.india.Tasks.FetchAdsInformationTask}
 */
public interface FetchAdsInformationApiListener {
    void onGetAdsInformationResponse(PayuResponse payuResponse);
}