package com.payu.india.Model;


import com.payu.india.Model.validateOffer.ValidateOfferRequest;
import com.payu.india.Payu.PayuConstants;
import com.payu.india.Payu.PayuUtils;
import com.payu.paymentparamhelper.V2ApiBase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class CalculateEmiRequest extends V2ApiBase {

    private long txnAmount;
    private long additionalCharges;
    private JSONArray offerKeys;
    private boolean autoApplyOffer;
    private List<String> bankCodes;
    private List<String> emiCodes;
    private String skuDetails;

    private JSONObject validateSku;
    private final String percentageAdditionalCharges;
    private final String additionalCharge;
    private final String txnId;
    private final String cardBin;

    /**
     * The offer validation request containing offer details.
     */
    private final ValidateOfferRequest validateOfferRequest;

    /**
     * Flag indicating whether custom feature pricing is enabled.
     */
    private final boolean isPricingCFEnable;

    private final String source;


    private final String merchantKey;

    private final Boolean disableConvFeeCompounding;
    private final String compoundingPercentage;

    private CalculateEmiRequest(Builder builder) {
        this.txnAmount = builder.txnAmount;
        this.additionalCharges = builder.additionalCharges;
        this.offerKeys = builder.offerKeys;
        this.autoApplyOffer = builder.autoApplyOffer;
        this.bankCodes = builder.bankCodes;
        this.emiCodes = builder.emiCodes;
        this.skuDetails = builder.skuDetails;
        this.percentageAdditionalCharges = builder.percentageAdditionalCharges;
        this.additionalCharge = builder.additionalCharge;
        this.txnId = builder.txnId;
        this.cardBin = builder.cardBin;
        this.validateOfferRequest = builder.validateOfferRequest;
        this.isPricingCFEnable = builder.isPricingCFEnable;
        this.source = builder.source;
        this.merchantKey = builder.merchantKey;
        this.disableConvFeeCompounding = builder.disableConvFeeCompounding;
        this.compoundingPercentage = builder.compoundingPercentage;
    }

    public static class Builder {
        private long txnAmount;
        private long additionalCharges;
        private JSONArray offerKeys;
        private boolean autoApplyOffer;
        private List<String> bankCodes;
        private List<String> emiCodes;
        private String skuDetails;
        private String percentageAdditionalCharges;
        private String additionalCharge;
        private String txnId;
        private String cardBin;
        private ValidateOfferRequest validateOfferRequest;
        private boolean isPricingCFEnable;

        private String source;
        private String merchantKey;

        private boolean disableConvFeeCompounding;
        private String compoundingPercentage;

        public long getTxnAmount() {
            return txnAmount;
        }

        public Builder setTxnAmount(long txnAmount) {
            this.txnAmount = txnAmount;
            return this;
        }

        public Builder setAdditionalCharges(long additionalCharges) {
            this.additionalCharges = additionalCharges;
            return this;
        }

        public Builder setOfferKeys(JSONArray offerKeys) {
            this.offerKeys = offerKeys;
            return this;
        }

        public Builder setAutoApplyOffer(boolean autoApplyOffer) {
            this.autoApplyOffer = autoApplyOffer;
            return this;
        }

        public Builder setBankCodes(List<String> bankCodes) {
            this.bankCodes = bankCodes;
            return this;
        }

        public Builder setEmiCodes(List<String> emiCodes) {
            this.emiCodes = emiCodes;
            return this;
        }

        public Builder setSkus(String skuDetails) {
            this.skuDetails = skuDetails;
            return this;
        }

        public Builder setPercentageAdditionalCharges(String percentageAdditionalCharges){
            this.percentageAdditionalCharges = percentageAdditionalCharges;
            return this;
        }

        public Builder setAdditionalCharge(String additionalCharge){
            this.additionalCharge = additionalCharge;
            return this;
        }

        public Builder setTxnId(String txnId){
            this.txnId = txnId;
            return this;
        }
        public Builder setCardBin(String cardBin){
            this.cardBin = cardBin;
            return this;
        }

        /**
         * Sets the offer validation request for the transaction.
         *
         * @param validateOfferRequest The offer validation request.
         * @return The Builder instance.
         */
        public Builder setValidateOfferRequest(ValidateOfferRequest validateOfferRequest) {
            this.validateOfferRequest = validateOfferRequest;
            return this;
        }

        /**
         * Sets whether custom feature pricing is enabled.
         *
         * @param pricingCFEnable The flag for custom feature pricing.
         * @return The Builder instance.
         */
        public Builder setPricingCFEnable(boolean pricingCFEnable) {
            isPricingCFEnable = pricingCFEnable;
            return this;
        }

        public Builder setSource(String source) {
            this.source = source;
            return this;
        }

        public Builder setMerchantKey(String merchantKey) {
            this.merchantKey = merchantKey;
            return this;
        }

        public Builder setDisableConvFeeCompounding(Boolean disableConvFeeCompounding) {
            this.disableConvFeeCompounding = disableConvFeeCompounding;
            return this;
        }

        public Builder setCompoundingPercentage(String compoundingPercentage) {
            this.compoundingPercentage = compoundingPercentage;
            return this;
        }

        public CalculateEmiRequest build() {
            return new CalculateEmiRequest(this);
        }

    }

    @Override
    public String getJson() {
        try {
            JSONObject jsonObject = new JSONObject();
            if (skuDetails != null) {
                jsonObject = getSkuJson(skuDetails);
            }
            jsonObject.put(PayuConstants.P_TXN_AMOUNT, txnAmount);
            jsonObject.put(PayuConstants.P_ADDITIONAL_CHARGE, additionalCharges);
            if (offerKeys != null && offerKeys.length() > 0) {
                jsonObject.put(PayuConstants.P_OFFER_KEYS, offerKeys);
            }
            jsonObject.put(PayuConstants.P_AUTO_APPLY_OFFER, autoApplyOffer);
            jsonObject.put(PayuConstants.P_BANK_CODES, bankCodes);
            JSONArray emiCodesArray = new JSONArray();
            for (String emiCode : emiCodes) {
                emiCodesArray.put(emiCode);
            }
            jsonObject.put(PayuConstants.P_EMI_CODES, emiCodesArray);
            jsonObject.put(PayuConstants.P_DISABLE_OVERRIDE_NCE_CONFIG, true);
            jsonObject.put(PayuConstants.PAYU_PERCENTAGE_ADDITIONAL_CHARGES, percentageAdditionalCharges);
            jsonObject.put(PayuConstants.MERCHANT_ADDITIONAL_CHARGES, additionalCharge);
            jsonObject.put(PayuConstants.PAYU_TXN_ID, txnId);
            jsonObject.put(PayuConstants.BIN, cardBin);
            if (validateOfferRequest != null)
                jsonObject.put(PayuConstants.PAYU_VALIDATE_OFFER_REQUEST_JSON, validateOfferRequest.getJsonValue());
            jsonObject.put(PayuConstants.PAYU_IS_PRICING_CF_ENABLED, isPricingCFEnable);
            if (source != null)
                jsonObject.put(PayuConstants.PAYU_SOURCE, source);
            if (merchantKey != null)
                jsonObject.put(PayuConstants.PAYU_MERCHANT_KEY, merchantKey);
            jsonObject.put(PayuConstants.PAYU_DISABLE_CF_COMPOUNDING, disableConvFeeCompounding);
            if(compoundingPercentage != null && !compoundingPercentage.isEmpty())
                jsonObject.put(PayuConstants.PAYU_COMPOUNDING_PERCENTAGE, compoundingPercentage);
            return jsonObject.toString();
        } catch (JSONException e) {
            return null;
        }
    }

    public JSONObject getSkuJson(String skuDetails) {
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.P_SKU_M_ID, PayuConstants.P_SKU_ID);
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.P_SKU_M_AMOUNT, PayuConstants.P_SKU_AMOUNT);
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.P_SKU_M_AMOUNT, PayuConstants.P_SKU_AMOUNT);
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.OFFER_KEY, PayuConstants.P_OFFER_KEYS);
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.P_AUTO_APPLY_M_OFFER, PayuConstants.P_AUTO_APPLY);
        skuDetails = PayuUtils.replaceString(skuDetails, PayuConstants.P_SKU_DETAILS, PayuConstants.P_SKUS);
        try {
            return new JSONObject(skuDetails);
        } catch (JSONException exception) {
            return new JSONObject();
        }
    }
}
