package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public class EmiOfferInfo implements Parcelable {

    private ArrayList<EMIOptionInOffers> eMiCCOffersArrayList;
    private ArrayList<EMIOptionInOffers> eMiDCOffersArrayList;

    private ArrayList<EMIOptionInOffers> eMiCardLessOffersArrayList;

    public EmiOfferInfo(){

    }

    protected EmiOfferInfo(Parcel in) {
        eMiCCOffersArrayList = in.createTypedArrayList(EMIOptionInOffers.CREATOR);
        eMiDCOffersArrayList = in.createTypedArrayList(EMIOptionInOffers.CREATOR);
        eMiCardLessOffersArrayList = in.createTypedArrayList(EMIOptionInOffers.CREATOR);
    }

    public static final Creator<EmiOfferInfo> CREATOR = new Creator<EmiOfferInfo>() {
        @Override
        public EmiOfferInfo createFromParcel(Parcel in) {
            return new EmiOfferInfo(in);
        }

        @Override
        public EmiOfferInfo[] newArray(int size) {
            return new EmiOfferInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(eMiCCOffersArrayList);
        parcel.writeTypedList(eMiDCOffersArrayList);
        parcel.writeTypedList(eMiCardLessOffersArrayList);
    }

    public ArrayList<EMIOptionInOffers> getEmiCCOffersArrayList() {
        return eMiCCOffersArrayList;
    }

    public void setEmiCCOffersArrayList(ArrayList<EMIOptionInOffers> eMiCCOffersArrayList) {
        this.eMiCCOffersArrayList = eMiCCOffersArrayList;
    }

    public ArrayList<EMIOptionInOffers> getEmiDCOffersArrayList() {
        return eMiDCOffersArrayList;
    }

    public void setEmiDCOffersArrayList(ArrayList<EMIOptionInOffers> eMiDCOffersArrayList) {
        this.eMiDCOffersArrayList = eMiDCOffersArrayList;
    }

    public ArrayList<EMIOptionInOffers> getEmiCardLessOffersArrayList() {
        return eMiCardLessOffersArrayList;
    }

    public void setEmiCardLessOffersArrayList(ArrayList<EMIOptionInOffers> eMiCardLessOffersArrayList) {
        this.eMiCardLessOffersArrayList = eMiCardLessOffersArrayList;
    }
}
