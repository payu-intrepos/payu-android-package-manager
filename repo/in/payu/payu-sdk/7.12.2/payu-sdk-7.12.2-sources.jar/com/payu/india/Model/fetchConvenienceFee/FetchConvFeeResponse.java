package com.payu.india.Model.fetchConvenienceFee;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.payu.india.Model.validateOffer.ValidateOfferDetails;

import java.util.HashMap;
import java.util.List;

public class FetchConvFeeResponse  implements Parcelable {

    private ValidateOfferDetails validateOfferDetails;
    private  HashMap<String, FetchConvFeeCombinations> convFeeChargesMap;
    private  HashMap<String, FetchConvFeeCombinations> convFeeSIChargesMap;
    private String convenienceFee;
    private String gst;
    public FetchConvFeeResponse() {

    }

    protected FetchConvFeeResponse(Parcel in) {
        validateOfferDetails = in.readParcelable(ValidateOfferDetails.class.getClassLoader());
        convFeeChargesMap = (HashMap<String, FetchConvFeeCombinations>) (in.readSerializable());
        convFeeSIChargesMap = (HashMap<String, FetchConvFeeCombinations>) (in.readSerializable());
        convenienceFee = in.readString();
        gst = in.readString();
    }

    public static final Creator<FetchConvFeeResponse> CREATOR = new Creator<FetchConvFeeResponse>() {
        @Override
        public FetchConvFeeResponse createFromParcel(Parcel in) {
            return new FetchConvFeeResponse(in);
        }

        @Override
        public FetchConvFeeResponse[] newArray(int size) {
            return new FetchConvFeeResponse[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeParcelable(validateOfferDetails, i);
        parcel.writeSerializable(convFeeChargesMap);
        parcel.writeSerializable(convFeeSIChargesMap);
        parcel.writeString(convenienceFee);
        parcel.writeString(gst);
    }

    public HashMap<String, FetchConvFeeCombinations> getConvFeeChargesMap() {
        return convFeeChargesMap;
    }

    public void setConvFeeChargesMap(HashMap<String, FetchConvFeeCombinations> convFeeChargesMap) {
        this.convFeeChargesMap = convFeeChargesMap;
    }

    public ValidateOfferDetails getValidateOfferDetails() {
        return validateOfferDetails;
    }

    public void setValidateOfferDetails(ValidateOfferDetails validateOfferDetails) {
        this.validateOfferDetails = validateOfferDetails;
    }

    public String getConvenienceFee() {
        return convenienceFee;
    }

    public void setConvenienceFee(String convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    public String getGst() {
        return gst;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }

    public HashMap<String, FetchConvFeeCombinations> getConvFeeSIChargesMap() {
        return convFeeSIChargesMap;
    }

    public void setConvFeeSIChargesMap(HashMap<String, FetchConvFeeCombinations> convFeeSIChargesMap) {
        this.convFeeSIChargesMap = convFeeSIChargesMap;
    }
}
