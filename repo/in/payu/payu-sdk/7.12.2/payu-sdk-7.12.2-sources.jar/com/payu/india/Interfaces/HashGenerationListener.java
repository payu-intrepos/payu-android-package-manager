package com.payu.india.Interfaces;

import java.util.HashMap;

public interface HashGenerationListener {
    void generateSignature(HashMap<String, String> map, HashCompletionListener hashCompletionListener);
}
