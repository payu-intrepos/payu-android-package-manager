package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;


public class UpiApp implements Parcelable {
    String appName;
    String handlers;
    String iOSSchemaHandler;
    String androidBundleIdentifier;

    public UpiApp() {

    }

    protected UpiApp(Parcel in) {
        appName = in.readString();
        handlers = in.readString();
        iOSSchemaHandler = in.readString();
        androidBundleIdentifier = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(appName);
        dest.writeString(handlers);
        dest.writeString(iOSSchemaHandler);
        dest.writeString(androidBundleIdentifier);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<UpiApp> CREATOR = new Creator<UpiApp>() {
        @Override
        public UpiApp createFromParcel(Parcel in) {
            return new UpiApp(in);
        }

        @Override
        public UpiApp[] newArray(int size) {
            return new UpiApp[size];
        }
    };

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getHandlers() {
        return handlers;
    }

    public void setHandlers(String handlers) {
        this.handlers = handlers;
    }

    public String getiOSSchemaHandler() {
        return iOSSchemaHandler;
    }

    public void setiOSSchemaHandler(String iOSSchemaHandler) {
        this.iOSSchemaHandler = iOSSchemaHandler;
    }

    public String getAndroidBundleIdentifier() {
        return androidBundleIdentifier;
    }

    public void setAndroidBundleIdentifier(String androidBundleIdentifier) {
        this.androidBundleIdentifier = androidBundleIdentifier;
    }
}
