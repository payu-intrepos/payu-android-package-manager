package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class PaymentProductDetails implements Parcelable {

    private String imageURL;
    private String category;
    private Long imageUpdatedOn;

    public static final Creator<PaymentProductDetails> CREATOR
            = new Creator<PaymentProductDetails>() {
        public PaymentProductDetails createFromParcel(Parcel in) {
            return new PaymentProductDetails(in);
        }

        public PaymentProductDetails[] newArray(int size) {
            return new PaymentProductDetails[size];
        }
    };

    public PaymentProductDetails() {
    }

    private PaymentProductDetails(Parcel in) {
        imageURL = in.readString();
        category = in.readString();
        imageUpdatedOn = in.readLong();
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Long getImageUpdatedOn() {
        return imageUpdatedOn;
    }

    public void setImageUpdatedOn(Long imageUpdatedOn) {
        this.imageUpdatedOn = imageUpdatedOn;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(imageURL);
        dest.writeString(category);
        dest.writeLong(imageUpdatedOn);
    }
}
