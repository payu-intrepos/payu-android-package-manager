package com.payu.india.Interfaces;

import java.util.HashMap;

public interface HashCompletionListener {
    void onSignatureGenerated(HashMap<String, String> map);
}
