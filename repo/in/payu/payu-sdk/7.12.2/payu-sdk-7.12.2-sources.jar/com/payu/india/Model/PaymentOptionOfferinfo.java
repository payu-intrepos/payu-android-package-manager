package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class PaymentOptionOfferinfo implements Parcelable {

    public PaymentOptionOfferinfo() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }

    public String getPaymentOptionName() {
        return paymentOptionName;
    }

    public void setPaymentOptionName(String paymentOptionName) {
        this.paymentOptionName = paymentOptionName;
    }

    protected PaymentOptionOfferinfo(Parcel in) {
        title = in.readString();
        paymentCode = in.readString();
        paymentOptionName = in.readString();
    }

    private String title;
    private String paymentCode;
    private String paymentOptionName;
    public static final Creator<PaymentOptionOfferinfo> CREATOR = new Creator<PaymentOptionOfferinfo>() {
        @Override
        public PaymentOptionOfferinfo createFromParcel(Parcel in) {
            return new PaymentOptionOfferinfo(in);
        }

        @Override
        public PaymentOptionOfferinfo[] newArray(int size) {
            return new PaymentOptionOfferinfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeString(paymentCode);
        parcel.writeString(paymentOptionName);
    }
}
