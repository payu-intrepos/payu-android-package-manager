package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface GlobalVaultListener {

    void onQuickPayResponse(PayuResponse payuResponse);

}
