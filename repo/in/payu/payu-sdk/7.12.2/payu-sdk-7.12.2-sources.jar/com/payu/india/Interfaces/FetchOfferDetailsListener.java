package com.payu.india.Interfaces;

import com.payu.india.Model.PayuResponse;

public interface FetchOfferDetailsListener {

    void onFetchOfferDetailsResponse(PayuResponse payuResponse);
}
