package com.payu.india.Model.adsinformation;

import android.os.Parcel;
import android.os.Parcelable;

public class AdsInformationResponseModel implements Parcelable {
    private String imagePath;
    private String requestId;
    private String adsSource;

    public AdsInformationResponseModel() {
    }

    protected AdsInformationResponseModel(Parcel in) {
        imagePath = in.readString();
        requestId = in.readString();
        adsSource = in.readString();
    }


    public String getImage() {
        return imagePath;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setImage(String imagePath) {
        this.imagePath = imagePath;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public void setAdsSource(String adsSource) {
        this.adsSource = adsSource;
    }

    public String getAdsSource() {
        return adsSource;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(imagePath);
        parcel.writeString(requestId);
        parcel.writeString(adsSource);
    }

    public static final Creator<AdsInformationResponseModel> CREATOR = new Creator<AdsInformationResponseModel>() {
        @Override
        public AdsInformationResponseModel createFromParcel(Parcel in) {
            return new AdsInformationResponseModel(in);
        }

        @Override
        public AdsInformationResponseModel[] newArray(int size) {
            return new AdsInformationResponseModel[size];
        }
    };
}