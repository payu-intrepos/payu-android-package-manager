package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class IssuerToken implements Parcelable {
    public String tokenValue;
    public String tokenExpMon;
    public String tokenExpYr;


    public IssuerToken() {
    }

    protected IssuerToken(Parcel in) {
        tokenValue = in.readString();
        tokenExpMon = in.readString();
        tokenExpYr = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(tokenValue);
        dest.writeString(tokenExpMon);
        dest.writeString(tokenExpYr);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<IssuerToken> CREATOR = new Creator<IssuerToken>() {
        @Override
        public IssuerToken createFromParcel(Parcel in) {
            return new IssuerToken(in);
        }

        @Override
        public IssuerToken[] newArray(int size) {
            return new IssuerToken[size];
        }
    };

    public String getTokenValue() {
        return tokenValue;
    }

    public void setTokenValue(String tokenValue) {
        this.tokenValue = tokenValue;
    }

    public String getTokenExpMon() {
        return tokenExpMon;
    }

    public void setTokenExpMon(String tokenExpMon) {
        this.tokenExpMon = tokenExpMon;
    }

    public String getTokenExpYr() {
        return tokenExpYr;
    }

    public void setTokenExpYr(String tokenExpYr) {
        this.tokenExpYr = tokenExpYr;
    }
}
