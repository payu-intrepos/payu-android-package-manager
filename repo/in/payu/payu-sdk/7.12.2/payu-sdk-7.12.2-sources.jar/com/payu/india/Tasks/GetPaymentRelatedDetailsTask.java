//    Copyright (c) 2014 - 2015 payu@india.com
//
//    Permission is hereby granted, free of charge, to any person obtaining a copy
//    of this software and associated documentation files (the "Software"), to deal
//    in the Software without restriction, including without limitation the rights
//    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//    copies of the Software, and to permit persons to whom the Software is
//    furnished to do so, subject to the following conditions:
//
//    The above copyright notice and this permission notice shall be included in
//    all copies or substantial portions of the Software.
//
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//    THE SOFTWARE.

package com.payu.india.Tasks;

import com.payu.india.Interfaces.PaymentRelatedDetailsListener;
import com.payu.india.Model.Emi;
import com.payu.india.Model.NetworkToken;
import com.payu.india.Model.PaymentDetails;
import com.payu.india.Model.PayuConfig;
import com.payu.india.Model.PayuResponse;
import com.payu.india.Model.PostData;
import com.payu.india.Model.StoredCard;
import com.payu.india.Model.Upi;
import com.payu.india.Payu.PayuConstants;
import com.payu.india.Payu.PayuErrors;
import com.payu.india.Payu.PayuUtils;
import com.payu.india.Tasks.base.PayUAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;


/**
 * Created by franklin on 5/28/15.
 * Async task which takes care of Getting all the payment releated details for a merchant
 * Takes PayuConfig as input and sends PayuResponse to the calling activity
 * Activity which calls {@link GetPaymentRelatedDetailsTask} should implement {@link PaymentRelatedDetailsListener}
 */
public class GetPaymentRelatedDetailsTask extends PayUAsyncTask<PayuConfig, Void, HashMap<String, String>> {


    PayuConfig payuConfig;
    PaymentRelatedDetailsListener mPaymentRelatedDetailsListener;

    public GetPaymentRelatedDetailsTask(PaymentRelatedDetailsListener paymentRelatedDetailsListener) {
        this.mPaymentRelatedDetailsListener = paymentRelatedDetailsListener;
    }

    @Override
    protected HashMap<String, String> doInBackground(PayuConfig... params) {

        // Here we try to get the userCredentials from payuConfig , which is passed as var1 parameter.

        payuConfig = params[0];
        String mUserCredentials = "";
        String patternText = "var1=([^&]*)";
        String searchString = payuConfig.getData();
        Pattern pattern = Pattern.compile(patternText);
        Matcher matcher = pattern.matcher(searchString);
        while (matcher.find()) {
            mUserCredentials = matcher.group(1);
        }

        return null;
    }

    @Override
    protected void onPostExecute(HashMap<String, String> oneClickCardTokens) {
        super.onPostExecute(oneClickCardTokens);
        FetchPaymentDetailsTask mTask = new FetchPaymentDetailsTask();
        mTask.execute(payuConfig);
//        mPaymentRelatedDetailsListener.onPaymentRelatedDetailsResponse(payuResponse);
    }

    class FetchPaymentDetailsTask extends PayUAsyncTask<PayuConfig, String, PayuResponse> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected PayuResponse doInBackground(PayuConfig... params) {

            PayuResponse payuResponse = new PayuResponse();
            PostData postData = new PostData();
            try {
                URL url = null;
                // get the payuConfig first
                PayuConfig payuConfig = params[0];

                // set the environment
                switch (payuConfig.getEnvironment()) {
                    case PayuConstants.PRODUCTION_ENV:
                        url = new URL(PayuConstants.PRODUCTION_FETCH_DATA_URL);
                        break;
                    case PayuConstants.MOBILE_STAGING_ENV:
                        url = new URL(PayuConstants.MOBILE_TEST_FETCH_DATA_URL);
                        break;
                    case PayuConstants.STAGING_ENV:
                        url = new URL(PayuConstants.TEST_FETCH_DATA_URL);
                        break;
                    case PayuConstants.MOBILE_DEV_ENV:
                        url = new URL(PayuConstants.MOBILE_DEV_FETCH_DATA_URL);
                        break;
                    case PayuConstants.BIZCHECKOUT_TEST_ENV:
                        url = new URL(PayuConstants.BIZ_CHECKOUT_TEST_FETCH_DATA_URL);
                        break;
                    default:
                        url = new URL(PayuConstants.PRODUCTION_FETCH_DATA_URL);
                        break;
                }

                byte[] postParamsByte = payuConfig.getData().getBytes("UTF-8");

                HttpsURLConnection conn = PayuUtils.getHttpsConn(url.toString(), payuConfig.getData());
                if (null != conn) {
                    StringBuffer responseStringBuffer = PayuUtils.getStringBuffer(conn, false);

                    JSONObject response = new JSONObject(responseStringBuffer.toString());
                    payuResponse.setRawResponse(response);
                    if (response.has(PayuConstants.IBIBO_CODES)) { // okay we have ibibo codes now
                        JSONObject ibiboCodes = response.getJSONObject(PayuConstants.IBIBO_CODES);
                        if (ibiboCodes.has(PayuConstants.CREDITCARD)) {
                            JSONObject creditCardCollections = ibiboCodes.getJSONObject(PayuConstants.CREDITCARD);
                            ArrayList<PaymentDetails> ccList = new ArrayList<PaymentDetails>();
                            Iterator<String> keysIterator = creditCardCollections.keys();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject ccObject = creditCardCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(ccObject.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(ccObject.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(ccObject.getString(PayuConstants.PGID));
                                ccList.add(paymentDetails);
                            }
                            payuResponse.setCreditCard(ccList);
                        }

                        if (ibiboCodes.has(PayuConstants.DEBITCARD)) {
                            JSONObject debitCardCollections = ibiboCodes.getJSONObject(PayuConstants.DEBITCARD);
                            ArrayList<PaymentDetails> dbList = new ArrayList<PaymentDetails>();
                            Iterator<String> keysIterator = debitCardCollections.keys();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                PaymentDetails paymentDetails = new PaymentDetails();
                                JSONObject dcObject = debitCardCollections.getJSONObject(bankCode);
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(dcObject.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(dcObject.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(dcObject.getString(PayuConstants.PGID));
                                dbList.add(paymentDetails);
                            }
                            payuResponse.setDebitCard(dbList);
                        }
                        if (ibiboCodes.has(PayuConstants.NETBANKING)) {
                            JSONObject netBanksCollections = ibiboCodes.getJSONObject(PayuConstants.NETBANKING);
                            Iterator<String> keysIterator = netBanksCollections.keys();
                            ArrayList<PaymentDetails> nbList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject netBank = netBanksCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(netBank.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(netBank.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(netBank.getString(PayuConstants.PGID));
                                nbList.add(paymentDetails);
                            }
                            Collections.sort(nbList, new PaymentDetailsComparator());
                            payuResponse.setNetBanks(nbList);
                        }
                        if (ibiboCodes.has(PayuConstants.CASHCARD)) {
                            JSONObject cashCardCollections = ibiboCodes.getJSONObject(PayuConstants.CASHCARD);
                            Iterator<String> keysIterator = cashCardCollections.keys();
                            ArrayList<PaymentDetails> cashCardList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject cashCardJson = cashCardCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(cashCardJson.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(cashCardJson.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(cashCardJson.getString(PayuConstants.PGID));
                                cashCardList.add(paymentDetails);
                                if (bankCode.equalsIgnoreCase(PayuConstants.PHONEPE_INTENT))
                                    payuResponse.setPhonePe(paymentDetails);
                                if (bankCode.equalsIgnoreCase(PayuConstants.TWID))
                                    payuResponse.setTwid(paymentDetails);
                            }
                            Collections.sort(cashCardList, new PaymentDetailsComparator());
                            payuResponse.setCashCard(cashCardList);
                        }
                        if (ibiboCodes.has(PayuConstants.IVR)) {
                            JSONObject ivrCCCollections = ibiboCodes.getJSONObject(PayuConstants.IVR);
                            Iterator<String> keysIterator = ivrCCCollections.keys();
                            ArrayList<PaymentDetails> ivrCCList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject ivrccObject = ivrCCCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(ivrccObject.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(ivrccObject.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(ivrccObject.getString(PayuConstants.PGID));
                                ivrCCList.add(paymentDetails);
                            }
                            payuResponse.setIvr(ivrCCList);
                        }

                        if (ibiboCodes.has(PayuConstants.IVRDC)) {
                            JSONObject ivrDCCollections = ibiboCodes.getJSONObject(PayuConstants.IVRDC);
                            Iterator<String> keysIterator = ivrDCCollections.keys();
                            ArrayList<PaymentDetails> ivrDCList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject ivrdcObject = ivrDCCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(ivrdcObject.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(ivrdcObject.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(ivrdcObject.getString(PayuConstants.PGID));
                                ivrDCList.add(paymentDetails);
                            }
                            payuResponse.setIvrdc(ivrDCList);
                        }

                        if (ibiboCodes.has(PayuConstants.PAISAWALLET)) {
                            JSONObject paisaWalletCollections = ibiboCodes.getJSONObject(PayuConstants.PAISAWALLET);
                            Iterator<String> keysIterator = paisaWalletCollections.keys();
                            ArrayList<PaymentDetails> paisaWalletList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject paisaWallet = paisaWalletCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(paisaWallet.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(paisaWallet.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(paisaWallet.getString(PayuConstants.PGID));
                                paisaWalletList.add(paymentDetails);
                            }
                            payuResponse.setPaisaWallet(paisaWalletList);
                        }

                        if (ibiboCodes.has(PayuConstants.LAZYPAY)) {
                            JSONObject lazypayCollections = ibiboCodes.getJSONObject(PayuConstants.LAZYPAY);
                            Iterator<String> keysIterator = lazypayCollections.keys();
                            ArrayList<PaymentDetails> lazypayList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject lazypay = lazypayCollections.getJSONObject(bankCode);
                                PaymentDetails paymentDetails = new PaymentDetails();
                                paymentDetails.setBankCode(bankCode);
                                paymentDetails.setBankId(lazypay.getString(PayuConstants.BANK_ID));
                                paymentDetails.setBankName(lazypay.getString(PayuConstants.TITLE));
                                paymentDetails.setPgId(lazypay.getString(PayuConstants.PGID));
                                lazypayList.add(paymentDetails);
                            }
                            payuResponse.setLazyPay(lazypayList);
                        }

                        if (ibiboCodes.has(PayuConstants.EMI_IN_RESPONSE)) {
                            ArrayList<Emi> emiList = getEmiList(ibiboCodes, PayuConstants.EMI_IN_RESPONSE);
                            payuResponse.setEmi(emiList);
                        }

                        if (ibiboCodes.has(PayuConstants.NO_COST_EMI)) {
                            ArrayList<Emi> emiList = getEmiList(ibiboCodes, PayuConstants.NO_COST_EMI);
                            payuResponse.setNoCostEMI(emiList);
                        }

                        // UPI Object
                        if (ibiboCodes.has(PayuConstants.UPI)) {
                            JSONObject upiObject = ibiboCodes.getJSONObject(PayuConstants.UPI);
                            if (upiObject.has((PayuConstants.UPI).toUpperCase())) {
                                JSONObject upiCollections = upiObject.getJSONObject((PayuConstants.UPI).toUpperCase());
                                Upi upi = new Upi();
                                upi.setTitle(upiCollections.getString(PayuConstants.TITLE));
                                upi.setBankID(upiCollections.getString(PayuConstants.BANK_ID));
                                upi.setPgID(upiCollections.getString(PayuConstants.PGID));
                                upi.setShowForm(upiCollections.getString(PayuConstants.SHOW_FORM));
                                payuResponse.setUpi(upi);
                            }
                            if (upiObject.has((PayuConstants.TEZ).toUpperCase())) {
                                JSONObject upiCollections = upiObject.getJSONObject((PayuConstants.TEZ).toUpperCase());
                                Upi upi = new Upi();
                                upi.setTitle(upiCollections.getString(PayuConstants.TITLE));
                                upi.setBankID(upiCollections.getString(PayuConstants.BANK_ID));
                                upi.setPgID(upiCollections.getString(PayuConstants.PGID));
                                upi.setShowForm(upiCollections.getString(PayuConstants.SHOW_FORM));
                                payuResponse.setGoogleTez(upi);
                            }
                            if (upiObject.has((PayuConstants.UPI_INTENT).toUpperCase())) {
                                JSONObject upiCollections = upiObject.getJSONObject((PayuConstants.UPI_INTENT).toUpperCase());
                                Upi upi = new Upi();
                                upi.setTitle(upiCollections.getString(PayuConstants.TITLE));
                                upi.setBankID(upiCollections.getString(PayuConstants.BANK_ID));
                                upi.setPgID(upiCollections.getString(PayuConstants.PGID));
                                upi.setShowForm(upiCollections.getString(PayuConstants.SHOW_FORM));
                                payuResponse.setGenericIntent(upi);
                            }
                        }

                        //SI: Parsing added for SI and added in payuresponse
                        if (ibiboCodes.has(PayuConstants.SI_IN_RESPONSE)) {
                            JSONObject siObjectCollections = ibiboCodes.getJSONObject(PayuConstants.SI_IN_RESPONSE);
                            Iterator<String> keysIterator = siObjectCollections.keys();
                            ArrayList<PaymentDetails> siList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject siObject = siObjectCollections.getJSONObject(bankCode);
                                PaymentDetails siDetails = new PaymentDetails();
                                siDetails.setBankCode(bankCode);
                                siDetails.setBankId(siObject.getString(PayuConstants.BANK_ID));
                                siDetails.setBankName(siObject.getString(PayuConstants.TITLE));
                                siDetails.setPgId(siObject.getString(PayuConstants.PGID));

                                siList.add(siDetails);
                            }
                            payuResponse.setStandingInstructions(siList);
                        }


                        if (ibiboCodes.has(PayuConstants.ENACH)) {
                            JSONObject enachObjectCollections = ibiboCodes.getJSONObject(PayuConstants.ENACH);
                            Iterator<String> keysIterator = enachObjectCollections.keys();
                            ArrayList<PaymentDetails> siBankList = new ArrayList<PaymentDetails>();
                            while (keysIterator.hasNext()) {
                                String bankCode = keysIterator.next();
                                JSONObject enachObject = enachObjectCollections.getJSONObject(bankCode);
                                PaymentDetails siBankDetails = new PaymentDetails();
                                siBankDetails.setBankCode(bankCode);
                                siBankDetails.setBankId(enachObject.getString(PayuConstants.BANK_ID));
                                siBankDetails.setBankName(enachObject.getString(PayuConstants.TITLE));
                                siBankDetails.setPgId(enachObject.getString(PayuConstants.PGID));
                                siBankList.add(siBankDetails);
                            }

                            payuResponse.setSiBankList(siBankList);
                        }
                    }

                    if (response.has(PayuConstants.USERCARDS)) { //  we have user cards also
                        if (response.getJSONObject(PayuConstants.USERCARDS).has(PayuConstants.USER_CARD)) { // yey! we have stored cards..
                            JSONObject cardsList = response.getJSONObject(PayuConstants.USERCARDS).getJSONObject(PayuConstants.USER_CARD);
                            Iterator<String> keysIterator = cardsList.keys();
                            ArrayList<StoredCard> userCardArrayList = new ArrayList<StoredCard>();

                            while (keysIterator.hasNext()) {
                                String cardToken = (String) keysIterator.next();
                                StoredCard userCard = new StoredCard();
                                JSONObject card = cardsList.getJSONObject(cardToken);
                                userCard.setNameOnCard(card.getString(PayuConstants.CARD_NAME));
                                userCard.setCardName(card.getString(PayuConstants.CARD_NAME));
                                userCard.setCardMode(card.getString(PayuConstants.CARD_MODE));
                                userCard.setMaskedCardNumber(card.getString(PayuConstants.CARD_NO));
                                userCard.setCardBrand(card.getString(PayuConstants.CARD_BRAND));
                                userCard.setCardBin(card.getString(PayuConstants.CARD_BIN));
                                userCard.setIsDomestic(card.getString(PayuConstants.IS_DOMESTIC));
                                userCard.setIssuingBank(card.getString(PayuConstants.ISSUINGBANK));
                                userCard.setCardType(card.getString(PayuConstants.CARD_TYPE));
                                userCard.setCardToken(card.getString(PayuConstants.CARD_TOKEN));
                                userCard.setExpiryYear(card.optString(PayuConstants.EXPIRY_YEAR));
                                userCard.setExpiryMonth(card.optString(PayuConstants.EXPIRY_MONTY));
                                userCard.setIsExpired(card.optInt(PayuConstants.IS_EXPIRED) == 0 ? false : true);
                                if (card.has(PayuConstants.TOKENISED_CARD_NETWORK_TOKEN)) {
                                    JSONObject networkJson = card.getJSONObject(PayuConstants.TOKENISED_CARD_NETWORK_TOKEN);
                                    NetworkToken networkToken = new NetworkToken();
                                    networkToken.setTokenValue(networkJson.optString(PayuConstants.TOKENISED_CARD_TOKEN_VALUE));
                                    networkToken.setExpired(networkJson.optBoolean(PayuConstants.IS_EXPIRED));
                                    networkToken.setTokenExpMon(networkJson.optString(PayuConstants.TOKENISED_CARD_TOKEN_EXP_MON));
                                    networkToken.setTokenExpYr(networkJson.optString(PayuConstants.TOKENISED_CARD_TOKEN_EXP_YR));
                                    userCard.setNetworkToken(networkToken);
                                }
                                // TODO : getridof card_cvv name.
//                                if (card.has(PayuConstants.CARD_CVV)) {// it may or may not come with response.
//                                    userCard.setEnableOneClickPayment(card.getInt(PayuConstants.CARD_CVV));
//                                    if (mOneClickCardTokens != null && mOneClickCardTokens.get(userCard.getCardToken()) != null) { // this means we found a merchant hash corresponding to the card token
//                                        userCard.setOneTapCard(card.getInt(PayuConstants.CARD_CVV));
//                                        userCard.setMerchantHash(mOneClickCardTokens.get(userCard.getCardToken()));
//                                    } else {
//                                        userCard.setOneTapCard(0);
//                                        userCard.setMerchantHash(null);
//                                    }
//                                }
                                userCardArrayList.add(userCard);
                                userCard = null;
                            }
                            payuResponse.setStoredCards(userCardArrayList);
                        }
                    }

                    if (response.has(PayuConstants.STATUS) && response.getString(PayuConstants.STATUS).contentEquals("0")) {
                        postData = new PostData();
                        postData.setCode(PayuErrors.INVALID_HASH);
                        postData.setStatus(PayuConstants.ERROR);
                        postData.setResult(response.getString(PayuConstants.MSG));
                    } else {
                        postData.setCode(PayuErrors.NO_ERROR);
                        // Result status should be success and the status of user cards
                        postData.setResult(PayuErrors.SDK_DETAILS_FETCHED_SUCCESSFULLY);
                        if (response.has(PayuConstants.USERCARDS) && response.getJSONObject(PayuConstants.USERCARDS).has(PayuConstants.MSG)) {
                            postData.setResult(postData.getResult() + " " + response.getJSONObject(PayuConstants.USERCARDS).get(PayuConstants.MSG).toString());
                        }
                        postData.setStatus(PayuConstants.SUCCESS);
                    }
                }
            } catch (ProtocolException e) {
                postData.setCode(PayuErrors.PROTOCOL_EXCEPTION);
                postData.setStatus(PayuConstants.ERROR);
                postData.setResult(e.getMessage());
            } catch (UnsupportedEncodingException e) {
                postData.setCode(PayuErrors.UN_SUPPORTED_ENCODING_EXCEPTION);
                postData.setStatus(PayuConstants.ERROR);
                postData.setResult(e.getMessage());
            } catch (JSONException e) {
                postData.setCode(PayuErrors.JSON_EXCEPTION);
                postData.setStatus(PayuConstants.ERROR);
                postData.setResult(e.getMessage());
            } catch (IOException e) {
                postData.setCode(PayuErrors.IO_EXCEPTION);
                postData.setStatus(PayuConstants.ERROR);
                postData.setResult(e.getMessage());
            }

            payuResponse.setResponseStatus(postData);
            return payuResponse;
        }

        private ArrayList<Emi> getEmiList(JSONObject ibiboCodes, String key) throws JSONException {
            JSONObject emiObjectCollections = ibiboCodes.getJSONObject(key);
            Iterator<String> keysIterator = emiObjectCollections.keys();
            ArrayList<Emi> emiList = new ArrayList<Emi>();
            while (keysIterator.hasNext()) {
                String bankCode = keysIterator.next();
                JSONObject emiObject = emiObjectCollections.getJSONObject(bankCode);
                Emi emi = new Emi();
                emi.setBankCode(bankCode);
                emi.setBankName(emiObject.getString(PayuConstants.BANK));
                emi.setBankTitle(emiObject.getString(PayuConstants.TITLE));
                emi.setPgId(emiObject.getString(PayuConstants.PGID));
                emi.setMinAmount(emiObject.optString(PayuConstants.EMI_MIN_AMOUNT));
                emiList.add(emi);
            }
            Collections.sort(emiList, new EmiComparator());
            return emiList;
        }

        @Override
        protected void onPostExecute(PayuResponse payuResponse) {
            super.onPostExecute(payuResponse);
            mPaymentRelatedDetailsListener.onPaymentRelatedDetailsResponse(payuResponse);
        }

        class EmiComparator implements Comparator<Emi> {

            @Override
            public int compare(Emi p1, Emi p2) {

                return p1.getBankName().compareTo(p2.getBankName());

            }
        }

        class PaymentDetailsComparator implements Comparator<PaymentDetails> {

            @Override
            public int compare(PaymentDetails p1, PaymentDetails p2) {

                return p1.getBankName().compareTo(p2.getBankName());

            }
        }

    }
}
