package com.payu.india.Tasks;

import com.payu.india.Interfaces.SaveCardApiListener;
import com.payu.india.Model.PayuConfig;
import com.payu.india.Model.PayuResponse;
import com.payu.india.Model.PostData;
import com.payu.india.Payu.PayuConstants;
import com.payu.india.Payu.PayuErrors;
import com.payu.india.Tasks.base.PayUAsyncTask;

/**
 * Created by franklin on 6/26/15.
 * Async task which takes care of saving a card
 * Takes PayuConfig as input and sends PayuResponse to the calling activity
 * Activity which calls {@link SaveCardTask } should implement {@link SaveCardApiListener}
 */
@Deprecated
public class SaveCardTask extends PayUAsyncTask<PayuConfig, String, PayuResponse> {

    private SaveCardApiListener mSaveCardApiListener;

    public SaveCardTask(SaveCardApiListener saveCardApiListener) {
        mSaveCardApiListener = saveCardApiListener;
    }

    @Override
    protected PayuResponse doInBackground(PayuConfig... params) {
        PayuResponse payuResponse = new PayuResponse();
        PostData postData = new PostData();
//        StoredCard storedCard = new StoredCard();
//        ArrayList<StoredCard> userCardArrayList = new ArrayList<StoredCard>();
//
//        try {
//            URL url = null;
//            // get the payuConfig first
//            PayuConfig payuConfig = params[0];
//
//            // set the environment
//            switch (payuConfig.getEnvironment()) {
//                case PayuConstants.PRODUCTION_ENV:
//                    url = new URL(PayuConstants.PRODUCTION_FETCH_DATA_URL);
//                    break;
//                case PayuConstants.MOBILE_STAGING_ENV:
//                    url = new URL(PayuConstants.MOBILE_TEST_FETCH_DATA_URL);
//                    break;
//                case PayuConstants.STAGING_ENV:
//                    url = new URL(PayuConstants.TEST_FETCH_DATA_URL);
//                    break;
//                case PayuConstants.MOBILE_DEV_ENV:
//                    url = new URL(PayuConstants.MOBILE_DEV_FETCH_DATA_URL);
//                    break;
//                default:
//                    url = new URL(PayuConstants.PRODUCTION_FETCH_DATA_URL);
//                    break;
//            }
//
//            HttpsURLConnection conn = PayuUtils.getHttpsConn(url.toString(),payuConfig.getData());
//            if(null!=conn) {
//                InputStream responseInputStream = conn.getInputStream();
//                StringBuffer responseStringBuffer = new StringBuffer();
//                byte[] byteContainer = new byte[1024];
//                for (int i; (i = responseInputStream.read(byteContainer)) != -1; ) {
//                    responseStringBuffer.append(new String(byteContainer, 0, i));
//                }
//
//                JSONObject response = new JSONObject(responseStringBuffer.toString());
//                payuResponse.setRawResponse(response);
//                if (response.has(PayuConstants.STATUS) && response.getString(PayuConstants.STATUS).contentEquals("0")) { // hash mismatch
//                    postData.setCode(PayuErrors.INVALID_HASH);
//                    postData.setStatus(PayuConstants.ERROR);
//                }
//                if (response.has(PayuConstants.STATUS) && response.getString(PayuConstants.STATUS).contentEquals("1")) {
//                    postData.setStatus(PayuConstants.SUCCESS);
//                    postData.setCode(PayuErrors.NO_ERROR);
//                    storedCard.setCardToken(response.getString("cardToken"));
//                    storedCard.setMaskedCardNumber(response.getString("card_number"));
//                    storedCard.setCardName(response.getString("card_label"));
//                    if (response.has(PayuConstants.DUPLICATE_CARDS_COUNT)) { // number of duplicate cards found for the merchant key
//                        try {
//                            int count = Integer.parseInt(response.get(PayuConstants.DUPLICATE_CARDS_COUNT).toString());
//                            storedCard.setDuplicateCardCount(count);
//                        } catch (NumberFormatException e) {
//                            e.printStackTrace();
//                        }
//                    } else { // setting default value of duplicate card as -1, since int has default value as 0 - in case of duplicate card count not found in response.
//                        storedCard.setDuplicateCardCount(-1);
//                    }
//                    userCardArrayList.add(0, storedCard);
//
//                }
//                if (response.has(PayuConstants.MSG)) {
//                    postData.setResult(response.getString(PayuConstants.MSG));
//                }
//            }
//        } catch (MalformedURLException | ProtocolException e) {
//            e.printStackTrace();
//        } catch (IOException | JSONException e) {
//            e.printStackTrace();
//        }

        // gotta return payuResponse
        postData.setCode(PayuErrors.METHOD_NOT_SUPPORTED);
        postData.setStatus(PayuConstants.METHOD_NOT_SUPPORTED);
        postData.setResult(PayuConstants.DEPRECATED_SAVE_CARD_TASK_MESSAGE);
        payuResponse.setResponseStatus(postData);
        return payuResponse;
    }

    @Override
    protected void onPostExecute(PayuResponse payuResponse) {
        super.onPostExecute(payuResponse);
        mSaveCardApiListener.onSaveCardResponse(payuResponse);
    }
}
