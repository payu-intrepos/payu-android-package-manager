package com.payu.india.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class NetworkOfferInfoCards implements Parcelable {
    private ArrayList<PaymentOptionOfferinfo> networkListForCCCards;
    private ArrayList<PaymentOptionOfferinfo> networkListForDCCards;

    public NetworkOfferInfoCards(){

    }

    protected NetworkOfferInfoCards(Parcel in) {
        networkListForCCCards = in.createTypedArrayList(PaymentOptionOfferinfo.CREATOR);
        networkListForDCCards = in.createTypedArrayList(PaymentOptionOfferinfo.CREATOR);
    }

    public static final Creator<NetworkOfferInfoCards> CREATOR = new Creator<NetworkOfferInfoCards>() {
        @Override
        public NetworkOfferInfoCards createFromParcel(Parcel in) {
            return new NetworkOfferInfoCards(in);
        }

        @Override
        public NetworkOfferInfoCards[] newArray(int size) {
            return new NetworkOfferInfoCards[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(networkListForCCCards);
        parcel.writeTypedList(networkListForDCCards);
    }

    public ArrayList<PaymentOptionOfferinfo> getNetworkListForCCCards() {
        return networkListForCCCards;
    }

    public void setNetworkListForCCCards(ArrayList<PaymentOptionOfferinfo> networkListForCCCards) {
        this.networkListForCCCards = networkListForCCCards;
    }

    public ArrayList<PaymentOptionOfferinfo> getNetworkListForDCCards() {
        return networkListForDCCards;
    }

    public void setNetworkListForDCCards(ArrayList<PaymentOptionOfferinfo> networkListForDCCards) {
        this.networkListForDCCards = networkListForDCCards;
    }
}
