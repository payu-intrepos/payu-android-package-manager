/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.india;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.india";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final String APPLICATION_ID = "appRelease";
  // Field from build type: release
  public static final String FLAVOR = "release";
  // Field from default config.
  public static final int VERSION_CODE = 87;
  // Field from default config.
  public static final String VERSION_NAME = "7.12.9";
}
