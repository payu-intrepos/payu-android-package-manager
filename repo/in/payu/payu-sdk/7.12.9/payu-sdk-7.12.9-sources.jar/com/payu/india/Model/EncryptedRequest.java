package com.payu.india.Model;

import android.util.Log;

import com.payu.paymentparamhelper.V2ApiBase;
import com.payu.india.Payu.PayuConstants;

import org.json.JSONException;
import org.json.JSONObject;

public class EncryptedRequest extends V2ApiBase {
    private final String data;

    public EncryptedRequest(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    @Override
    public String getJson() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("encryptedBody", data);
        } catch (JSONException e) {
            Log.v("EncryptedRequest", e.getMessage());
        }
        return jsonObject.toString();
    }

}