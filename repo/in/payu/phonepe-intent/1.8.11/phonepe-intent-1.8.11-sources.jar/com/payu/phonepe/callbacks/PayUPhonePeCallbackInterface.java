package com.payu.phonepe.callbacks;


public interface PayUPhonePeCallbackInterface {
    @Deprecated
    void onPaymentOptionSuccess(String payuResponse);

    void onPaymentOptionSuccess(String payuResponse,String merchantResponse);

    @Deprecated
    void onPaymentOptionFailure(String payuResponse);

    void onPaymentOptionFailure(String payuResponse,String merchantResponse);

    void onPaymentOptionInitialisationSuccess(boolean result);

    void onPaymentOptionInitialisationFailure(int errorCode, String description);
    void onBackApprove();
    void onPaymentTerminate();
    void onBackDismiss();
}
