package com.payu.phonepe;

public interface PhonePeConstants {
    String PAYMENT_URL = "/_payment";
    String FETCH_DATA_URL = "/merchant/postservice.php?form=2";
    String PRODUCTION_BASE_URL = "https://info.payu.in";
    String PRODUCTION_PAYMENT_BASE_URL = "https://secure.payu.in";
    String MAKE_PAYMENT = "make_payment";
    String CHECK_PAYMENT_OPTION = "check_payment_option";
    String VERFIY_PAYMENT = "verify_payment";
    String ENCODED_DATA = "encodedData";
    String CHECKSUM = "checksum";
    String CALLBACK_URL = "callbackUrl";
    String RETURN_URL = "returnUrl";
    String STATUS = "status";
    String UNMAPPEDSTATUS = "unmappedstatus";
    String FAILURE = "failure";
    String CANCELLED = "CANCELLED";
    String ANALYTICS_CANCELLED = "result_cancelled";
    String PAYMENT_REQUEST = "paymentRequest";
    String POST = "POST";
    String API_DEBIT = "/v3/debit";
    String IBIBO_CODES = "ibiboCodes";
    String CASH_CARD = "cashcard";
    String PPINTENT = "PPINTENT";
    String PAYMENT_RELATED_DETAILS_FOR_MOBILE_SDK = "payment_related_details_for_mobile_sdk";
    int MERCHANT_KEY_NOT_REGISTER_FOR_PHONEPE_CODE = 1;
    String MERCHANT_KEY_NOT_REGISTER_FOR_PHONEPE = "merchant_key_not_register_for_phonepe";
    String PAYU_PAYTXN = "paytxn";

    //Event Analyitcs
    String PAKAGE_NAME = "package_name";
    String KEY = "event_key";
    String VALUE = "event_value";
    String TIMESTAMP = "ts";
    String VERSION_CODE = "application_version";
    String MERCHANT_KEY = "merchant_key";
    String TRANSACTION_ID = "txnid";
    String KEY_ = "key";
    String PAYMENT_OPTION = "payment_option";


    //Keys for Device Tracking for transaction
    String SDK_VERSION_NAME = "phonepe_sdk_version";
    String UPI_SDK_VERSION_NAME = "upi_sdk_version";
    String CB_VERSION_NAME = "cb_version_name";
    String DEVICE_OS_VERSION = "os_version";
    String NETWORK_INFO = "network_info";
    String NETWORK_STRENGTH = "network_strength";
    String DEVICE_RESOLUTION = "resolution";
    String DEVICE_MANUFACTURE = "device_manufacturer";
    String DEVICE_MODEL = "device_model";
    String PHONE_PE = "PHONEPE";
    String PHONE_PE_SDK = "phonepe_sdk";
    String POST_DATA = "postdata";
    String SUCCESS = "success";
    String PHONE_PE_PAYMENT_APP_RESPONSE = "phonepe_payment_app_response";
    String RESULT_OK = "result_ok";
    String EXCEPTION_PHONEPE = "exception_phone_pe";
    String PHONE_PE_MAKE_PAYMENT_RESPONSE = "phonepe_make_payment_response";
    String SDK_NAME_ = "SDK_Name";
    String FAILURE_TRANSACTION = "failure_transaction";
    String SUCCESS_TRANSACTION = "success_transaction";
    String TRNX_STATUS = "trxn_status_phonepe_sdk";


    String PAYU_WEB_SERVICE_URL ="payu_web_service_url";
    String PAYU_POST_URL ="payu_post_url";
    String TRXN_STATUS = "trxn_status_phonepe_sdk";
    String PAYMENT_APP_RESPONSE = "_payment_app_response";
    String CANCEL_BACK_BUTTON = "cancel_back_button";
    String PAYMENT_TYPE = "payment_type";
    String PHONEPE_COLLECT_FLOW = "phonepe_collect";
    String PHONEPE_INTENT_FLOW = "phonepe_intent";
     int PHONEPE_INTENT = 1;
     int PHONEPE_COLLECT = 2;
    //Analytics
    String PLATFORM_KEY = "platform";
    String PLATFORM_VALUE = "android";
    String SDK_PLATFORM_KEY ="sdk_platform";
    String NAME_KEY ="name";
    String NAME_VALUE ="phonepe";
    String VERSION_KEY ="version";
}
