package com.payu.phonepe;

import java.io.Serializable;

/**
 * Model class for _payment response.
 */
public class PaymentRequest implements Serializable {
    private String encodedData;
    private String callbackUrl;
    private String checksum;
    private String returnUrl;
    private boolean isUserCacheEnabled;

    public String getEncodedData() {
        return encodedData;
    }

    public void setEncodedData(String encodedData) {
        this.encodedData = encodedData;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public boolean isUserCacheEnabled() {
        return isUserCacheEnabled;
    }

    public void setUserCacheEnabled(boolean userCacheEnabled) {
        isUserCacheEnabled = userCacheEnabled;
    }

    @Override
    public String toString() {
        return "encodedData=" + encodedData + "checksum=" + checksum + "callbackUrl=" + callbackUrl + "returnUrl=" + returnUrl + "isUserCacheEnabled=" + isUserCacheEnabled;
    }
}
