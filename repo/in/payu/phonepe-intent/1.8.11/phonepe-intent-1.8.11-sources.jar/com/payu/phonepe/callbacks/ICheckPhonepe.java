package com.payu.phonepe.callbacks;

public interface ICheckPhonepe {
    void isPhonepeAvailable(boolean showPhonepe);
}
