package com.payu.phonepe.callbacks;

/**
 * Created by himanshu.gupta on 30/10/17.
 */

public class PayUPhonePeCallback implements PayUPhonePeCallbackInterface {

    @Deprecated
    public void onPaymentOptionSuccess(String payuResponse) {

    }
    @Deprecated
    public void onPaymentOptionFailure(String payuResponse) {

    }

    @Override
    public void onPaymentOptionSuccess(String payuResponse, String merchantResponse) {

    }

    @Override
    public void onPaymentOptionFailure(String payuResponse, String merchantResponse) {

    }

    public void onPaymentOptionInitialisationSuccess(boolean result) {

    }

    public void onPaymentOptionInitialisationFailure(int errorCode, String description) {

    }

    @Override
    public void onBackApprove() {

    }

    @Override
    public void onPaymentTerminate() {

    }

    @Override
    public void onBackDismiss() {

    }
}
