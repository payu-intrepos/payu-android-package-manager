package com.payu.phonepe;

import android.view.View;

import com.payu.phonepe.callbacks.PayUPhonePeCallback;

public enum PhonePeData {
    SINGLETON;
    private PayUPhonePeCallback payUPhonePeCallback;

    private View payUCustomDialogView;

    private String webServiceUrl = "";
    private String postUrl;

    public String getWebServiceUrl() {
        return webServiceUrl;
    }

    public void setWebServiceUrl(String webServiceUrl) {
        this.webServiceUrl = webServiceUrl;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }


    public View getPayUCustomDialogView() {
        return payUCustomDialogView;
    }

    public void setPayUCustomDialogView(View payUCustomDialogView) {
        this.payUCustomDialogView = payUCustomDialogView;
    }

    /**
     * Getter of PayU CustomBrowser Callback
     *
     * @return {@link PayUPhonePeCallback}
     */
    public PayUPhonePeCallback getPayUPhonePeCallback() {
        return payUPhonePeCallback;
    }

    /**
     * Setter of PayU PhonePe Callback
     *
     * @param payUPhonePeCallback {@link PayUPhonePeCallback}
     */
    public void setPayUPhonePeCallback(PayUPhonePeCallback payUPhonePeCallback) {
        this.payUPhonePeCallback = payUPhonePeCallback;
    }
}
