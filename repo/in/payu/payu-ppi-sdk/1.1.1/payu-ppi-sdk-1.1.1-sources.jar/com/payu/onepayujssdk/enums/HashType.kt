package com.payu.onepayujssdk.enums

enum class HashType {
    CARD, WALLET, KYC
}