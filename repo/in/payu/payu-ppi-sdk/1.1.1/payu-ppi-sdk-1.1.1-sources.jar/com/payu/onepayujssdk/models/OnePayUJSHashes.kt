package com.payu.onepayujssdk.models

data class OnePayUJSHashes(val cardHash: String? = null)
