package com.payu.onepayujssdk.listeners

interface OnePayUJSListener {
    fun onCancel()
    fun onError(code: Int, message: String)
    fun generateHash(
        map: HashMap<String, String?>,
        hashGenerationOnePayUJKListener: OnePayUJSHashGenerationListener
    )
    
    // Optional KYC completion callback with default implementation
    fun onKYCCompletion(status: String, message: String, docId: String) {
        // Default implementation - can be overridden
    }
}