package com.payu.onepayujssdk.models

import com.payu.onepayujssdk.listeners.OnePayUJSListener

object InternalConfig {
    var onePayUJSParams: OnePayUJSParams? = null
    var onePayUJSKYCParams: OnePayUJSKYCParams? = null
    var onePayUJSListener: OnePayUJSListener? = null

    internal fun reset(){
        onePayUJSListener = null
        onePayUJSParams = null
        onePayUJSKYCParams = null
    }
}