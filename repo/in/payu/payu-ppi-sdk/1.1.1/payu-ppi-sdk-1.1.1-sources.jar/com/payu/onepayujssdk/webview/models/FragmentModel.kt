package com.payu.onepayujssdk.webview.models

import androidx.fragment.app.Fragment

class FragmentModel {
    var fragment: Fragment? = null
    var tag: String? = null
}
