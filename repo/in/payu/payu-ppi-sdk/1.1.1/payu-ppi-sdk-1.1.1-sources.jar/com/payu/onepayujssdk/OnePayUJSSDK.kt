package com.payu.onepayujssdk


import androidx.fragment.app.FragmentActivity
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.models.OnePayUJSParams
import com.payu.onepayujssdk.models.OnePayUJSKYCParams
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMETERS_CODE
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMS
import com.payu.onepayujssdk.listeners.OnePayUJSListener
import com.payu.onepayujssdk.utils.AnalyticsUtils
import com.payu.onepayujssdk.utils.CommonUtils
import com.payu.onepayujssdk.utils.CommonUtils.extractOnePayuParams
import com.payu.onepayujssdk.webview.OnePayUBaseCoordinator

object OnePayUJSSDK {

    @JvmStatic
    fun showCards(
        activity: FragmentActivity,
        onePayUJSParams: OnePayUJSParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        OnePayUBaseCoordinator.openCards(activity, onePayUJSParams, onePayUJSListener)
    }

    @JvmStatic
    fun showCards(
        activity: FragmentActivity,
        params: HashMap<String, Any>,
        onePayUJSListener: OnePayUJSListener
    ) {
        val onePayUJSParams = extractOnePayuParams(params)
        if (onePayUJSParams != null) {
            showCards(activity, onePayUJSParams, onePayUJSListener)
        } else {
            AnalyticsUtils.logKibanaData(
                activity,
                OnePayUJSConstants.PAYU_PPI_SDK_INIT,
                INVALID_PARAMETERS_CODE.toString() + "_" + INVALID_PARAMS + "_" + CommonUtils.convertMapToJson(
                    params
                ),
                OnePayUJSConstants.PAYU_ERROR_TYPE,
                OnePayUJSConstants.PAYU_HIGH
            )
            onePayUJSListener.onError(INVALID_PARAMETERS_CODE, INVALID_PARAMS)
        }
    }

    @JvmStatic
    fun initiateKYC(
        activity: FragmentActivity,
        kycParams: OnePayUJSKYCParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        OnePayUBaseCoordinator.openKYC(activity, kycParams, onePayUJSListener)
    }

}