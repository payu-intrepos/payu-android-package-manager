package com.payu.onepayujssdk.models

import com.payu.onepayujssdk.constant.OnePayUJSConstants

data class OnePayUJSParams(
    val environment: String,
    val merchantKey: String,
    val mobileNumber: String,
    val walletIdentifier: String,
    val walletUrn: String,
    val referenceId: String,
    val redirectUrl: String = OnePayUJSConstants.PAYU_DEFAULT_REDIRECT_URL,
    val additionalParams: HashMap<String, Any?>? = HashMap(),
    val hashes: OnePayUJSHashes? = null
)
