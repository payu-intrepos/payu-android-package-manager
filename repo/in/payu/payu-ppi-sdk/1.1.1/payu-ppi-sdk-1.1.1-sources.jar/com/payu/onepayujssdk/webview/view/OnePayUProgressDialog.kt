package com.payu.onepayujssdk.webview.view

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.payu.onepayujssdk.R

class OnePayUProgressDialog(
    context: Context,
    view: View?
) : Dialog(
    context, R.style.Theme_AppCompat_Light_NoActionBar
) {
    private var tvMessage: AppCompatTextView? = null
    private val mActivity: Activity?
    private var layout: View
    private var ivProgress: AppCompatImageView? = null

    init {
        mActivity = context as Activity?
        val mInflater = LayoutInflater.from(context)
        if (null != view) {
            layout = view
            if (view.parent != null) {
                val parent = view.parent as ViewGroup
                parent.removeView(view)
            }
            setContentView(layout)
        } else {
            layout = mInflater.inflate(R.layout.one_payu_loader_layout, null, false)
            setContentView(layout)
            ivProgress = layout.findViewById(R.id.payu_loader)
            if (mActivity != null) {
                setPayUDialogSettings(ivProgress, mActivity)
            }
        }
        setCancelable(true)
        setCanceledOnTouchOutside(false)
    }

    private fun setPayUDialogSettings(imageView: AppCompatImageView?, activity: Activity) {
        imageView?.applyLoopingAnimatedVectorDrawable(R.drawable.payu_loader, activity);
    }

    fun setText(text: String?) {
        tvMessage?.text = text
    }

    internal fun AppCompatImageView.applyLoopingAnimatedVectorDrawable(
        @DrawableRes avdResId: Int,
        activity: Activity
    ) {
        val animated = AnimatedVectorDrawableCompat.create(activity, avdResId)
        animated?.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                this@applyLoopingAnimatedVectorDrawable.post { animated.start() }
            }
        })
        this.setImageDrawable(animated)
        animated?.start()
    }
}