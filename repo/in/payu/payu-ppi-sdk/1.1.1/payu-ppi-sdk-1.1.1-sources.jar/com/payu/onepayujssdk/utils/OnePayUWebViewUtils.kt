package com.payu.onepayujssdk.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.provider.Settings
import android.provider.Settings.Secure.ANDROID_ID
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import com.payu.onepayujssdk.BuildConfig
import com.payu.onepayujssdk.R
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSConstants.DATE_FORMAT
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OnePayUWebViewUtils {

    fun hideKeyboard(activity: Activity) {
        val imm: InputMethodManager =
            activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        var view: View? = activity.currentFocus
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun isNetworkAvailable(context: Context?): Boolean {
        val connectivityManager =
            context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isAvailable && networkInfo.isConnected
    }

    fun getDeviceDetails(activity: Activity): String {
        try {
            val deviceTotalMemory = getTotalMemoryInfo(activity)
            val availMemory = getAvailableMemoryInfo(activity)
            val memoryInfo = ((availMemory ?: 1) * 100) / (deviceTotalMemory ?: 1)
            val deviceDetails =
                Build.MANUFACTURER.plus(" " + Build.MODEL) + "_" + getDeviceDensity(activity) + "_" + memoryInfo + "_" + getNetworkStatus(
                    activity
                )
            return deviceDetails
        } catch (e: Exception) {
            Log.e("Exception", "" + e.message)
        }
        return OnePayUJSConstants.BLANK
    }

    private fun getDeviceDensity(activity: Activity): String {
        val metrics = DisplayMetrics()
        activity.windowManager.defaultDisplay.getMetrics(metrics)
        return metrics.densityDpi.toString()
    }

    private fun getNetworkStatus(context: Context?): String {
        try {
            if (null != context) {
                val cm =
                    context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val info = cm.activeNetworkInfo
                if (info == null || !info.isConnected) return context.resources.getString(R.string.payu_not_connected)
                if (info.type == ConnectivityManager.TYPE_WIFI) return OnePayUJSConstants.NETWORK_STATUS_WIFI
                if (info.type == ConnectivityManager.TYPE_MOBILE) {
                    val networkType = info.subtype
                    return when (networkType) {
                        TelephonyManager.NETWORK_TYPE_GPRS -> OnePayUJSConstants.NETWORK_STATUS_GPRS
                        TelephonyManager.NETWORK_TYPE_EDGE -> OnePayUJSConstants.NETWORK_STATUS_EDGE
                        TelephonyManager.NETWORK_TYPE_CDMA -> OnePayUJSConstants.NETWORK_STATUS_CDMA
                        TelephonyManager.NETWORK_TYPE_1xRTT, TelephonyManager.NETWORK_TYPE_IDEN -> OnePayUJSConstants.NETWORK_STATUS_2G
                        TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSPA -> OnePayUJSConstants.NETWORK_STATUS_HSPA
                        TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_EHRPD, TelephonyManager.NETWORK_TYPE_HSPAP -> OnePayUJSConstants.NETWORK_STATUS_3G
                        TelephonyManager.NETWORK_TYPE_LTE -> OnePayUJSConstants.NETWORK_STATUS_4G
                        else -> OnePayUJSConstants.NETWORK_STATUS_NOT_DEFINED
                    }
                }
            }
        } catch (e: java.lang.Exception) {
            return OnePayUJSConstants.NETWORK_STATUS_NOT_DEFINED
        }
        return OnePayUJSConstants.NETWORK_STATUS_NOT_DEFINED
    }

    fun getPackageName(activity: Activity): String {
        return activity.packageName
    }

    fun getSdkVersion(): String {
        return BuildConfig.VERSION_NAME
    }

    fun getApplicationVersionCode(context: Context): String {
        try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            return pInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return OnePayUJSConstants.BLANK
    }

    internal fun getTotalMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem / (1024 * 1024)
    }

    internal fun getAvailableMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024)
    }

    @SuppressLint("HardwareIds")
    fun getDeviceID(applicationContext: Context): String? {
        return Settings.Secure.getString(applicationContext.contentResolver, ANDROID_ID)
    }

    internal fun getSystemCurrentTime(): String? {
        try {
            val currentDate = Date(System.currentTimeMillis())
            val df: DateFormat = SimpleDateFormat(DATE_FORMAT, Locale.US)
            return df.format(currentDate)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
        return ""
    }

}