package com.payu.onepayujssdk.utils

import android.content.Context
import android.os.Build
import android.os.Build.VERSION
import com.payu.onepayujssdk.BuildConfig
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSConstants.PAYU_EVENTS_INDEX
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics
import org.json.JSONObject

object AnalyticsUtils {
    private var eventIndex = 0

    internal fun logKibanaData(
        context: Context,
        eventKey: String,
        eventName: String,
        eventType: String,
        eventSeverity: String
    ) {
        eventIndex++
        val analyticsJson = getAnalyticsJsonWithBasicProperties(
            context
        )
        analyticsJson.put(OnePayUJSConstants.PAYU_EVENT_KEY, eventKey)
        analyticsJson.put(OnePayUJSConstants.PAYU_EVENT_VALUE, eventName)
        analyticsJson.put(OnePayUJSConstants.PAYU_EVENT_TYPE, eventType)
        analyticsJson.put(OnePayUJSConstants.PAYU_EVENT_SEVERITY, eventSeverity)
        analyticsJson.put(PAYU_EVENTS_INDEX, eventIndex)
        val payuAnalytics =
            AnalyticsFactory(context).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
        payuAnalytics.log(analyticsJson.toString())
    }

    private fun getAnalyticsJsonWithBasicProperties(context: Context): JSONObject {
        val analyticsJson = JSONObject()
        analyticsJson.put(
            OnePayUJSConstants.PAYU_TIMESTAMP,
            OnePayUWebViewUtils.getSystemCurrentTime()
        )
        analyticsJson.put(OnePayUJSConstants.PAYU_SDK_VERSION, BuildConfig.VERSION_NAME)
        analyticsJson.put(
            OnePayUJSConstants.PAYU_LOGGING_SDK,
            BuildConfig.LIBRARY_PACKAGE_NAME + " " + BuildConfig.VERSION_NAME
        )
        analyticsJson.put(
            OnePayUJSConstants.PAYU_TXN_ID,
            InternalConfig.onePayUJSParams?.referenceId
        )
        analyticsJson.put(
            OnePayUJSConstants.PAYU_MERCHANT_KEY,
            InternalConfig.onePayUJSParams?.merchantKey
        )
        analyticsJson.put(
            OnePayUJSConstants.PAYU_MOBILE,
            InternalConfig.onePayUJSParams?.mobileNumber
        )
        analyticsJson.put(
            OnePayUJSConstants.WALLET_IDENTIFIRE,
            InternalConfig.onePayUJSParams?.walletIdentifier
        )
        val deviceName = Build.MANUFACTURER + " " + Build.MODEL
        val deviceOsVersion = VERSION.SDK_INT
        val deviceTotalMemory = OnePayUWebViewUtils.getTotalMemoryInfo(context)
        val availMemory = OnePayUWebViewUtils.getAvailableMemoryInfo(context)
        try {
            val memoryInfo = availMemory * 100 / deviceTotalMemory
            analyticsJson.put(
                OnePayUJSConstants.PAYU_DEVICE_DETAILS,
                deviceName + "_" + deviceOsVersion + "_" + memoryInfo + "%"
            )
        } catch (e: Exception) {
            analyticsJson.put(
                OnePayUJSConstants.PAYU_DEVICE_DETAILS,
                deviceName + "_" + deviceOsVersion + "_" + 0 + "%"
            )
        }

        return analyticsJson
    }

}