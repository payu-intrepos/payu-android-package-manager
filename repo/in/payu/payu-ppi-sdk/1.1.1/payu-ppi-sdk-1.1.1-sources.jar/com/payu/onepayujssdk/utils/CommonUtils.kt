package com.payu.onepayujssdk.utils

import android.app.Activity
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSConstants.MERCHANT_KEY
import com.payu.onepayujssdk.constant.OnePayUJSConstants.MOBILE_NUMBER
import com.payu.onepayujssdk.constant.OnePayUJSConstants.PAYU_MERCHANT_KEY
import com.payu.onepayujssdk.constant.OnePayUJSConstants.PAYU_MOBILE
import com.payu.onepayujssdk.constant.OnePayUJSConstants.REFERENCE_ID
import com.payu.onepayujssdk.constant.OnePayUJSConstants.WALLET_IDENTIFIRE
import com.payu.onepayujssdk.constant.OnePayUJSConstants.WALLET_URN
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMETERS_CODE
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMS
import com.payu.onepayujssdk.enums.EnvironmentType
import com.payu.onepayujssdk.models.OnePayUJSParams
import java.util.regex.Pattern

object CommonUtils {


    fun isValidPhoneNumber(phone: String): Boolean {
        val validateMobileNumberRegex = "[6789][0-9]{9}?"
        return isValidRegexValue(phone, validateMobileNumberRegex)
    }

    private fun isValidRegexValue(regexValue: String, regex: String): Boolean {
        val pattern = Pattern.compile(regex)
        val matcher = pattern.matcher(regexValue)
        return matcher.matches()
    }

    internal fun extractOnePayuParams(
        params: HashMap<String, Any>
    ): OnePayUJSParams? {
        if (params.contains(OnePayUJSConstants.ENVIRONMENT) && params.contains(MERCHANT_KEY) && params.contains(
                MOBILE_NUMBER
            ) && params.contains(REFERENCE_ID) && params.contains(
                WALLET_IDENTIFIRE
            )
        ) {
            val environmentValue =
                if (params[OnePayUJSConstants.ENVIRONMENT].toString() == "0") EnvironmentType.PROD.name else EnvironmentType.TEST.name
            return OnePayUJSParams(
                environmentValue,
                params[MERCHANT_KEY].toString(),
                params[MOBILE_NUMBER].toString(),
                params[WALLET_IDENTIFIRE].toString(),
                params[WALLET_URN].toString(),
                params[REFERENCE_ID].toString()
            )
        }
        return null
    }

    internal fun convertMapToJson(params: HashMap<String, Any>): String {
        val stringBuilder = StringBuilder("{")

        for ((key, value) in params) {
            // Add the key-value pair to the JSON string (handle the value type conversion as needed)
            stringBuilder.append("\"$key\":")
            when (value) {
                is String -> stringBuilder.append("\"$value\"")
                else -> stringBuilder.append(value.toString())
            }

            // Add a comma if it's not the last item
            if (params.entries.last() != (key to value)) {
                stringBuilder.append(", ")
            }
        }

        stringBuilder.append("}")
        return stringBuilder.toString()
    }

}