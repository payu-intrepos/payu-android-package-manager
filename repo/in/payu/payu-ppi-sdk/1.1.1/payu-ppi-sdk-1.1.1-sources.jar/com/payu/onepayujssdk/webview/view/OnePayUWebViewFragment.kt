package com.payu.onepayujssdk.webview.view

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.payu.onepayujssdk.R
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.NO_INTERNET_CODE
import com.payu.onepayujssdk.utils.OnePayUWebViewUtils
import com.payu.onepayujssdk.webview.OnePayUJSHandler
import com.payu.onepayujssdk.webview.OnePayUWebViewClient
import com.payu.onepayujssdk.webview.OnePayUWebChromeClient
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.onepayujssdk.models.InternalConfig.reset
import com.payu.onepayujssdk.utils.AnalyticsUtils
import com.payu.onepayujssdk.webview.viewmodel.OnePayUWebViewViewModel

class OnePayUWebViewFragment() : Fragment() {

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 200
        private const val TAG = "OnePayUWebViewFragment"
        
        fun newInstance(viewModel: OnePayUWebViewViewModel?): OnePayUWebViewFragment {
            val fragment = OnePayUWebViewFragment()
            fragment.onePayUWebViewViewModel = viewModel
            return fragment
        }
    }

    private var onePayUWebViewViewModel: OnePayUWebViewViewModel? = null
    private var cbWebView: WebView? = null
    private var rootView: LinearLayout? = null
    
    init {
        // Required empty constructor for Fragment state restoration
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Request permissions for KYC flow
        if (onePayUWebViewViewModel?.isKYC == true) {
            requestKYCPermissions()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // Clean up ViewModel reference
        onePayUWebViewViewModel = null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        if (requireActivity() is AppCompatActivity) (requireActivity() as? AppCompatActivity)?.supportActionBar?.hide()
        else requireActivity().actionBar?.hide()
        val view = inflater.inflate(R.layout.fragment_one_pay_u_web_view, container, false)
        initUI(view)
        return view
    }

    override fun onGetLayoutInflater(savedInstanceState: Bundle?): LayoutInflater {
        val inflater = super.onGetLayoutInflater(savedInstanceState)
        val contextThemeWrapper: Context =
            ContextThemeWrapper(requireContext(), R.style.Theme_AppCompat_Light_NoActionBar)
        return inflater.cloneInContext(contextThemeWrapper)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.isFocusableInTouchMode = true

        view.requestFocus();
        view.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                AnalyticsUtils.logKibanaData(
                    requireActivity(),
                    OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
                    OnePayUJSConstants.PAYU_ON_CANCEL + "_" + OnePayUJSConstants.PAYU_FRAG_INIT,
                    OnePayUJSConstants.PAYU_INFO_TYPE,
                    OnePayUJSConstants.PAYU_LOW
                )
                InternalConfig.onePayUJSListener?.onCancel()
                reset()
                return@OnKeyListener false
            }
            false
        })

    }

    private fun initUI(view: View?) {
        onePayUWebViewViewModel?.showLoaderDialog()
        rootView = view?.findViewById(R.id.rootView)
        cbWebView = view?.findViewById(R.id.webview)
        initSettings()

        if (OnePayUWebViewUtils.isNetworkAvailable(activity?.applicationContext)) {
            onePayUWebViewViewModel?.let {
                val postData = onePayUWebViewViewModel?.fetchCardRequest()
                val url = onePayUWebViewViewModel?.getURL()
                val fullUrl = url + onePayUWebViewViewModel?.getURLEndpoint()
                
                Log.d(TAG, "═══════════════════════════════════════════════")
                Log.d(TAG, "🌐 WEBVIEW POST REQUEST")
                Log.d(TAG, "═══════════════════════════════════════════════")
                
                AnalyticsUtils.logKibanaData(
                    requireContext(),
                    OnePayUJSConstants.PAYU_PPI_SDK_WEB_VIEW_POST,
                    url + "_" + postData,
                    OnePayUJSConstants.PAYU_INFO_TYPE,
                    OnePayUJSConstants.PAYU_LOW
                )
                
                cbWebView?.postUrl(
                    fullUrl,
                    (postData?:"").toByteArray()
                )
            }
        } else {
            AnalyticsUtils.logKibanaData(
                requireContext(),
                OnePayUJSConstants.PAYU_PPI_SDK_WEB_VIEW_POST,
                NO_INTERNET_CODE.toString() + NO_INTERNET_CODE,
                OnePayUJSConstants.PAYU_ERROR_TYPE,
                OnePayUJSConstants.PAYU_MEDIUM
            )
            onePayUWebViewViewModel?.let {
                it.hideLoaderDialog()
                it.noInternet()
                it.onBackPressed()
            }
        }
        onePayUWebViewViewModel?.let {
            cbWebView?.webViewClient = OnePayUWebViewClient(it.activity, onePayUWebViewViewModel)
            cbWebView?.webChromeClient = OnePayUWebChromeClient(it.activity)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface", "Deprecated")
    fun initSettings() {
        cbWebView?.isVerticalScrollBarEnabled = true
        cbWebView?.isHorizontalScrollBarEnabled = true
        cbWebView?.settings?.javaScriptEnabled = true
        cbWebView?.requestFocus()
        cbWebView?.addJavascriptInterface(
            OnePayUJSHandler(requireActivity()),
            OnePayUJSConstants.ONE_PAYU_JS_SDK
        )
        cbWebView?.settings?.setSupportMultipleWindows(true)
        cbWebView?.settings?.domStorageEnabled = true
        cbWebView?.settings?.useWideViewPort = true
        cbWebView?.settings?.loadWithOverviewMode = true
        cbWebView?.settings?.setRenderPriority(WebSettings.RenderPriority.HIGH)
        cbWebView?.settings?.cacheMode = WebSettings.LOAD_NO_CACHE
        cbWebView?.settings?.databaseEnabled = true
        
        // Enable geolocation and media capture for KYC
        cbWebView?.settings?.javaScriptCanOpenWindowsAutomatically = true
        cbWebView?.settings?.mediaPlaybackRequiresUserGesture = false
        
        // CRITICAL: Enable geolocation with all required settings
        cbWebView?.settings?.setGeolocationEnabled(true)
        
        // Set geolocation database path (deprecated but still required for many devices)
        @Suppress("DEPRECATION")
        cbWebView?.settings?.setGeolocationDatabasePath(requireContext().filesDir.path)
    }

    private fun requestKYCPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        
        // Check camera permission
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        
        // Check microphone permission
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        
        // Check location permissions
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        
        if (permissionsToRequest.isNotEmpty()) {
            Log.d(TAG, "Requesting KYC permissions")
            ActivityCompat.requestPermissions(
                requireActivity(),
                permissionsToRequest.toTypedArray(),
                REQUEST_CODE_PERMISSIONS
            )
        } else {
            Log.d(TAG, "All KYC permissions already granted")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            Log.d(TAG, "═══════════════════════════════════════════════")
            Log.d(TAG, "🔐 PERMISSION REQUEST RESULT")
            Log.d(TAG, "═══════════════════════════════════════════════")
            
            val granted = mutableListOf<String>()
            val denied = mutableListOf<String>()
            
            permissions.forEachIndexed { index, permission ->
                val permName = permission.substringAfterLast('.')
                if (grantResults[index] == PackageManager.PERMISSION_GRANTED) {
                    granted.add(permName)
                    Log.d(TAG, "✅ $permName: GRANTED")
                } else {
                    denied.add(permName)
                    Log.e(TAG, "❌ $permName: DENIED")
                }
            }
            Log.d(TAG, "═══════════════════════════════════════════════")
        }
    }

}