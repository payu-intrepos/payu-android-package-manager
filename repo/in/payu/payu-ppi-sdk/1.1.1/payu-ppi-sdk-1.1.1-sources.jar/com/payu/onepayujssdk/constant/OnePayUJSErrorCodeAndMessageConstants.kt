package com.payu.onepayujssdk.constant

object OnePayUJSErrorCodeAndMessageConstants {
    const val INVALID_HASH_CODE = 1
    const val INVALID_HASH = "Hash is invalid"
    const val INVALID_PARAMETERS_CODE = 3
    const val NO_INTERNET_CODE = 4
    const val NO_INTERNET = "No Internet!"
    const val INVALID_PARAMS = "Invalid params"
    const val PAYU_ERROR = "Something went wrong"
    const val IS_MISSING = " is missing, "
}