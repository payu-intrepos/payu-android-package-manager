package com.payu.onepayujssdk.enums

enum class EnvironmentType {
    PROD, TEST
}