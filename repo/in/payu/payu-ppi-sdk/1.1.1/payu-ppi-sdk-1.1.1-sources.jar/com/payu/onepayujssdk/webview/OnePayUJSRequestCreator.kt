package com.payu.onepayujssdk.webview

import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.models.OnePayUJSParams
import com.payu.onepayujssdk.models.OnePayUJSKYCParams
import org.json.JSONObject
import java.net.URLEncoder

object OnePayUJSRequestCreator {

    fun createFetchCardRequest(onePayUJSParams: OnePayUJSParams): String {
        val jsonObject = JSONObject()
        jsonObject.put(OnePayUJSConstants.MERCHANT_KEY, onePayUJSParams.merchantKey)
        jsonObject.put(OnePayUJSConstants.MOBILE_NUMBER, onePayUJSParams.mobileNumber)
        jsonObject.put(OnePayUJSConstants.REDIRECT_URL, onePayUJSParams.redirectUrl?:" ")
        jsonObject.put(OnePayUJSConstants.REFERENCE_ID, onePayUJSParams.referenceId)
        jsonObject.put(OnePayUJSConstants.WALLET_IDENTIFIRE, onePayUJSParams.walletIdentifier)
        jsonObject.put(OnePayUJSConstants.WALLET_URN, onePayUJSParams.walletUrn)
        return jsonObject.toString()
    }

    fun createFetchCardFormPostRequest(
        date: String?,
        signature: String?,
        onePayUJSParams: OnePayUJSParams
    ): String {
        val data = createFetchCardRequest(onePayUJSParams)
        val authorization = getAuthorizationToken(signature, onePayUJSParams.merchantKey)
        return OnePayUJSConstants.DATA_PARAM + data + OnePayUJSConstants.AMPERSAND_AUTHORIZATION_PARAM + authorization + OnePayUJSConstants.AMPERSAND_DATE_PARAM + date
    }

    private fun getAuthorizationToken(signature: String?, key: String): String {
        return "${OnePayUJSConstants.HMAC_USERNAME_PARAM}\"$key\", ${OnePayUJSConstants.ALGORITHM_PARAM}\"${OnePayUJSConstants.SHA512_PARAM}\", ${OnePayUJSConstants.HEADER_PARAM}\"${OnePayUJSConstants.DATE_PARAM}\", ${OnePayUJSConstants.SIGNATURE_PARAM}\"$signature\""
    }

    fun createKYCFormPostRequest(kycParams: OnePayUJSKYCParams): String {
        val formData = kycParams.getFormPostData()
        return formData.entries.joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, "UTF-8")}=${URLEncoder.encode(value, "UTF-8")}"
        }
    }
}
