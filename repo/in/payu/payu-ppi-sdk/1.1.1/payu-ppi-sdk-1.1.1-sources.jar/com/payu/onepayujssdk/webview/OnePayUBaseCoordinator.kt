package com.payu.onepayujssdk.webview

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.listeners.OnePayUJSListener
import com.payu.onepayujssdk.models.OnePayUJSParams
import com.payu.onepayujssdk.models.OnePayUJSKYCParams
import com.payu.onepayujssdk.enums.HashType
import com.payu.onepayujssdk.utils.OnePayUHashGeneratorUtils
import com.payu.onepayujssdk.constant.OnePayUJSConstants.CARD_FRAGMENT
import com.payu.onepayujssdk.constant.OnePayUJSConstants.KYC_FRAGMENT
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMETERS_CODE
import com.payu.onepayujssdk.webview.models.FragmentModel
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.onepayujssdk.utils.AnalyticsUtils
import com.payu.onepayujssdk.webview.view.OnePayUWebViewFragment
import com.payu.onepayujssdk.webview.viewmodel.OnePayUWebViewViewModel

object OnePayUBaseCoordinator {

    fun openCards(
        activity: FragmentActivity,
        onePayUJSParams: OnePayUJSParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        OnePayUHashGeneratorUtils.fetchHash(
            activity,
            HashType.CARD,
            onePayUJSParams,
            onePayUJSListener
        ) { hash: String, date: String ->
            val viewModel =
                OnePayUWebViewViewModel(activity, hash, date, onePayUJSParams, onePayUJSListener)
            val validateParamError = viewModel.validateParams()
            if (validateParamError.isNotEmpty()) {
                AnalyticsUtils.logKibanaData(
                    activity,
                    OnePayUJSConstants.PAYU_PPI_SDK_INIT,
                    INVALID_PARAMETERS_CODE.toString() + validateParamError.dropLast(2),
                    OnePayUJSConstants.PAYU_ERROR_TYPE,
                    OnePayUJSConstants.PAYU_HIGH
                )
                onePayUJSListener.onError(INVALID_PARAMETERS_CODE, validateParamError.dropLast(2))
            } else {
                InternalConfig.onePayUJSListener = onePayUJSListener
                InternalConfig.onePayUJSParams = onePayUJSParams
                val fragment = OnePayUWebViewFragment.newInstance(viewModel)
                val fragModel = loadFragment(fragment, CARD_FRAGMENT)
                dynamicFrag(activity, fragModel)
                AnalyticsUtils.logKibanaData(
                    activity,
                    OnePayUJSConstants.PAYU_PPI_SDK_INIT,
                    OnePayUJSConstants.PAYU_PPI_SDK_VALIDATION_SUCCESS,
                    OnePayUJSConstants.PAYU_INFO_TYPE,
                    OnePayUJSConstants.PAYU_LOW
                )
            }
        }
    }

    private fun dynamicFrag(activity: FragmentActivity, fragmentModel: FragmentModel) {
        val fragmentTransaction = activity.supportFragmentManager.beginTransaction()
        fragmentModel.fragment?.let {
            fragmentTransaction.add(
                android.R.id.content,
                it,
                fragmentModel.tag
            ).addToBackStack(null)
                .commit()
        }
        activity.supportFragmentManager.executePendingTransactions()
    }

    private fun loadFragment(fragment: Fragment, tag: String?): FragmentModel {
        val fragmentModel = FragmentModel()
        fragmentModel.fragment = fragment
        fragmentModel.tag = tag
        return fragmentModel
    }

    fun openKYC(
        activity: FragmentActivity,
        kycParams: OnePayUJSKYCParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        // KYC doesn't need hash generation, checksum is handled internally
        InternalConfig.onePayUJSListener = onePayUJSListener
        InternalConfig.onePayUJSKYCParams = kycParams
        
        val viewModel = OnePayUWebViewViewModel(activity, kycParams, onePayUJSListener)
        val fragment = OnePayUWebViewFragment.newInstance(viewModel)
        val fragModel = loadFragment(fragment, KYC_FRAGMENT)
        dynamicFrag(activity, fragModel)
        
        AnalyticsUtils.logKibanaData(
            activity,
            OnePayUJSConstants.PAYU_PPI_SDK_INIT,
            "KYC_INIT_SUCCESS",
            OnePayUJSConstants.PAYU_INFO_TYPE,
            OnePayUJSConstants.PAYU_LOW
        )
    }
}