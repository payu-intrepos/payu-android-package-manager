package com.payu.onepayujssdk.webview

import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class OnePayUWebChromeClient(
    private val activity: FragmentActivity
) : WebChromeClient() {

    companion object {
        private const val TAG = "OnePayUWebChromeClient"
        private const val REQUEST_CODE_CAMERA = 100
        private const val REQUEST_CODE_LOCATION = 101
        private const val REQUEST_CODE_AUDIO = 102
    }

    // Handle permission requests for camera, microphone
    override fun onPermissionRequest(request: PermissionRequest) {

        request.resources.forEach { resource ->
            Log.d(TAG, "   - $resource")
        }
        Log.d(TAG, "📸 Origin: ${request.origin}")
        
        // Check app permissions
        val hasCameraPermission = hasPermission(Manifest.permission.CAMERA)
        val hasAudioPermission = hasPermission(Manifest.permission.RECORD_AUDIO)
        
        Log.d(TAG, "")
        Log.d(TAG, "🔐 App Permission Status:")
        Log.d(TAG, "  ├─ CAMERA: ${if (hasCameraPermission) "✅ GRANTED" else "❌ DENIED"}")
        Log.d(TAG, "  └─ RECORD_AUDIO: ${if (hasAudioPermission) "✅ GRANTED" else "❌ DENIED"}")
        Log.d(TAG, "")
        
        // Only grant resources if APP has the corresponding permission
        // WebView cannot access camera/mic if the APP doesn't have permission
        val resourcesToGrant = mutableListOf<String>()
        val needToRequestPermissions = mutableListOf<String>()
        
        for (resource in request.resources) {
            when (resource) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> {
                    Log.d(TAG, "📸 Processing VIDEO_CAPTURE request")
                    
                    if (hasCameraPermission) {
                        resourcesToGrant.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                        Log.d(TAG, "   ✅ App has CAMERA permission - granting to webview")
                    } else {
                        Log.e(TAG, "   ❌ App does NOT have CAMERA permission")
                        needToRequestPermissions.add(Manifest.permission.CAMERA)
                    }
                }
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> {
                    Log.d(TAG, "🎤 Processing AUDIO_CAPTURE request")
                    
                    if (hasAudioPermission) {
                        resourcesToGrant.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                        Log.d(TAG, "   ✅ App has RECORD_AUDIO permission - granting to webview")
                    } else {
                        Log.e(TAG, "   ❌ App does NOT have RECORD_AUDIO permission")
                        needToRequestPermissions.add(Manifest.permission.RECORD_AUDIO)
                    }
                }
                else -> {
                    Log.w(TAG, "⚠️ Unknown resource type: $resource")
                }
            }
        }
        
        // If we need permissions, show error and deny
        if (needToRequestPermissions.isNotEmpty()) {
            Log.e(TAG, "App is missing required permissions:")
            needToRequestPermissions.forEach { perm ->
                Log.e(TAG, "  ❌ $perm")
            }
            Log.e(TAG, "💡 SOLUTION: Grant permissions when KYC fragment opens")
            request.deny()
            return
        }
        
        // Grant resources to webview
        try {
            if (resourcesToGrant.isEmpty()) {
                Log.w(TAG, "⚠️ No resources to grant")
                request.deny()
                return
            }
            
            Log.d(TAG, "")
            Log.d(TAG, "✅ Granting ${resourcesToGrant.size} resource(s) to webview:")
            resourcesToGrant.forEach { resource ->
                Log.d(TAG, "   ✓ $resource")
            }
            
            request.grant(resourcesToGrant.toTypedArray())
            Log.d(TAG, "✅ request.grant() executed successfully!")
        } catch (e: Exception) {
            Log.e(TAG, "Message: ${e.message}")
            request.deny()
        }
        
        Log.d(TAG, "═══════════════════════════════════════════════")
    }

    // Handle geolocation permission requests
    override fun onGeolocationPermissionsShowPrompt(
        origin: String,
        callback: GeolocationPermissions.Callback
    ) {
        
        val hasFineLocation = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        val hasCoarseLocation = hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        
        Log.d(TAG, "📍 Permission Status:")
        Log.d(TAG, "  ├─ ACCESS_FINE_LOCATION: ${if (hasFineLocation) "✅ GRANTED" else "❌ DENIED"}")
        Log.d(TAG, "  └─ ACCESS_COARSE_LOCATION: ${if (hasCoarseLocation) "✅ GRANTED" else "❌ DENIED"}")
        
        try {
            // Always grant to webview - let it request location
            // The Android system and app permissions will control actual access
            Log.d(TAG, "✅ Granting geolocation permission to WebView")
            callback.invoke(origin, true, false)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error invoking geolocation callback: ${e.message}", e)
        }
        
        // If we don't have permission yet, request it
        if (!hasFineLocation && !hasCoarseLocation) {
            Log.d(TAG, "💡 App doesn't have location permission yet")
            requestPermission(Manifest.permission.ACCESS_FINE_LOCATION, REQUEST_CODE_LOCATION)
        } else {
            Log.d(TAG, "✅ App already has location permission")
        }
        
    }

    override fun onProgressChanged(view: WebView?, newProgress: Int) {
        super.onProgressChanged(view, newProgress)
    }
    
    override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage): Boolean {
        Log.d(TAG, "🌐 Console [${consoleMessage.messageLevel()}]: ${consoleMessage.message()} " +
                "-- From line ${consoleMessage.lineNumber()} of ${consoleMessage.sourceId()}")
        return true
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            activity,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission(permission: String, requestCode: Int) {
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(permission),
            requestCode
        )
    }
}

