package com.payu.onepayujssdk.utils

import android.app.Activity
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSConstants.PAYU_HASH_DATA
import com.payu.onepayujssdk.constant.OnePayUJSConstants.PAYU_HASH_VALUE
import com.payu.onepayujssdk.enums.HashType
import com.payu.onepayujssdk.listeners.OnePayUJSHashGenerationListener
import com.payu.onepayujssdk.listeners.OnePayUJSListener
import com.payu.onepayujssdk.models.OnePayUJSParams
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_HASH
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_HASH_CODE
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMETERS_CODE
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.INVALID_PARAMS
import com.payu.onepayujssdk.webview.OnePayUJSRequestCreator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object OnePayUHashGeneratorUtils {

    @JvmStatic
    fun fetchHash(
        activity: Activity,
        hashType: HashType,
        onePayUJSParams: OnePayUJSParams,
        onePayUJSListener: OnePayUJSListener,
        hashGeneratedCallBack: (String, String) -> Unit
    ) {
        val date = getDate()
        val hashData = getHashData(onePayUJSParams, hashType, date)
        AnalyticsUtils.logKibanaData(
            activity,
            OnePayUJSConstants.PAYU_PPI_SDK_HASH,
            PAYU_HASH_DATA + hashData,
            OnePayUJSConstants.PAYU_INFO_TYPE,
            OnePayUJSConstants.PAYU_LOW
        )
        onePayUJSListener.generateHash(hashData, object : OnePayUJSHashGenerationListener {
            override fun onHashGenerated(map: HashMap<String, String>) {
                val hash = map[hashType.name]
                hash?.let {
                    AnalyticsUtils.logKibanaData(
                        activity,
                        OnePayUJSConstants.PAYU_PPI_SDK_HASH,
                        PAYU_HASH_VALUE + hash,
                        OnePayUJSConstants.PAYU_INFO_TYPE,
                        OnePayUJSConstants.PAYU_LOW
                    )
                    hashGeneratedCallBack(it, date)
                } ?: run {

                    AnalyticsUtils.logKibanaData(
                        activity,
                        OnePayUJSConstants.PAYU_PPI_SDK_HASH,
                        INVALID_HASH_CODE.toString() + "_" + INVALID_HASH,
                        OnePayUJSConstants.PAYU_ERROR_TYPE,
                        OnePayUJSConstants.PAYU_HIGH
                    )
                    onePayUJSListener.onError(INVALID_HASH_CODE, INVALID_HASH)
                }
            }
        })
    }

    private fun getHashData(
        onePayUJSParams: OnePayUJSParams,
        hashType: HashType,
        date: String
    ): HashMap<String, String?> {
        val map = HashMap<String, String?>()
        val command = hashType.name
        map[OnePayUJSConstants.HASH_NAME] = command
        val body = getBody(onePayUJSParams, hashType)
        map[OnePayUJSConstants.HASH_STRING] = generateSigningString(body, date)
        return map
    }

    private fun getBody(onePayUJSParams: OnePayUJSParams, hashType: HashType): String {
        return when (hashType) {
            HashType.CARD -> OnePayUJSRequestCreator.createFetchCardRequest(onePayUJSParams)
            else -> { // Note the block
                OnePayUJSConstants.BLANK
            }
        }
    }

    private fun getDate(): String {
        val myDate = Date()
        val calendar = Calendar.getInstance()
        calendar.timeZone = TimeZone.getTimeZone(OnePayUJSConstants.UTC)
        calendar.time = myDate
        calendar.add(Calendar.MINUTE, -330)
        val time = calendar.time
        val outputFmt = SimpleDateFormat(OnePayUJSConstants.V2_API_TIME_FORMAT, Locale.US)
        return outputFmt.format(time)
    }

    private fun generateSigningString(body: String, date: String): String {
        return StringBuilder()
            .append(body).append(OnePayUJSConstants.PIPE_SEPARATOR).append(date)
            .append(OnePayUJSConstants.PIPE_SEPARATOR).toString()
    }
}