package com.payu.onepayujssdk.webview.viewmodel

import androidx.fragment.app.FragmentActivity
import com.payu.onepayujssdk.enums.EnvironmentType
import com.payu.onepayujssdk.listeners.OnePayUJSListener
import com.payu.onepayujssdk.models.OnePayUJSParams
import com.payu.onepayujssdk.models.OnePayUJSKYCParams
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.IS_MISSING
import com.payu.onepayujssdk.webview.OnePayUJSRequestCreator
import com.payu.onepayujssdk.webview.view.OnePayUProgressDialog
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.onepayujssdk.utils.CommonUtils.isValidPhoneNumber

class OnePayUWebViewViewModel {
    val activity: FragmentActivity
    private val hash: String?
    private val date: String
    private val onePayUJSParams: OnePayUJSParams?
    private val kycParams: OnePayUJSKYCParams?
    private val onePayUJSListener: OnePayUJSListener
    private var onePayUProgressDialog: OnePayUProgressDialog? = null
    val isKYC: Boolean

    // Constructor for Cards
    constructor(
        activity: FragmentActivity,
        hash: String?,
        date: String,
        onePayUJSParams: OnePayUJSParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        this.activity = activity
        this.hash = hash
        this.date = date
        this.onePayUJSParams = onePayUJSParams
        this.kycParams = null
        this.onePayUJSListener = onePayUJSListener
        this.isKYC = false
    }

    // Constructor for KYC
    constructor(
        activity: FragmentActivity,
        kycParams: OnePayUJSKYCParams,
        onePayUJSListener: OnePayUJSListener
    ) {
        this.activity = activity
        this.hash = null
        this.date = ""
        this.onePayUJSParams = null
        this.kycParams = kycParams
        this.onePayUJSListener = onePayUJSListener
        this.isKYC = true
    }
    fun validateParams(): String {
        if (isKYC) {
            // No validation needed for KYC, params are already validated
            return OnePayUJSConstants.BLANK
        }
        
        var error = OnePayUJSConstants.BLANK
        onePayUJSParams?.let {
            if (it.environment.isEmpty() || (it.environment != EnvironmentType.PROD.name && it.environment != EnvironmentType.TEST.name)) {
                error += OnePayUJSConstants.ENVIRONMENT + IS_MISSING
            }
            if (it.merchantKey.isEmpty()) {
                error += OnePayUJSConstants.MERCHANT_KEY + IS_MISSING
            }
            if (it.walletUrn.isEmpty()) {
                error += OnePayUJSConstants.WALLET_URN + IS_MISSING
            }
            if (!isValidPhoneNumber(it.mobileNumber)) {
                error += OnePayUJSConstants.MOBILE_NUMBER + IS_MISSING
            }
            if (it.referenceId.isEmpty()) {
                error += OnePayUJSConstants.REFERENCE_ID + IS_MISSING
            }
            if (it.walletIdentifier.isEmpty()) {
                error += OnePayUJSConstants.WALLET_IDENTIFIRE + IS_MISSING
            }
            if (hash.isNullOrEmpty()) {
                error += OnePayUJSConstants.HASH + IS_MISSING
            }
        }
        return error
    }

    fun fetchCardRequest(): String {
        return if (isKYC) {
            OnePayUJSRequestCreator.createKYCFormPostRequest(kycParams!!)
        } else {
            OnePayUJSRequestCreator.createFetchCardFormPostRequest(date, hash, onePayUJSParams!!)
        }
    }

    fun getURL(): String {
        return if (isKYC) {
            // Select KYC URL based on environment
            if (kycParams?.environment == EnvironmentType.PROD)
                OnePayUJSConstants.PAYU_KYC_URL_PROD 
            else 
                OnePayUJSConstants.PAYU_KYC_URL_TEST
        } else {
            if (InternalConfig.onePayUJSParams?.environment == EnvironmentType.PROD.name)
                OnePayUJSConstants.PAYU_PROD_BASE_URL else OnePayUJSConstants.PAYU_TEST_BASE_URL
        }
    }
    
    fun getURLEndpoint(): String {
        return if (isKYC) {
            OnePayUJSConstants.BLANK
        } else {
            OnePayUJSConstants.PAYU_FE_VIRTUAL_CARD_END_POINTS
        }
    }

    fun noInternet() {
        onePayUJSListener.onError(
            OnePayUJSErrorCodeAndMessageConstants.NO_INTERNET_CODE,
            OnePayUJSErrorCodeAndMessageConstants.NO_INTERNET
        )
    }

    fun onBackPressed() {
        activity.supportFragmentManager.popBackStack()
        InternalConfig.onePayUJSListener?.onCancel()
    }

    fun showLoaderDialog() {
        if (onePayUProgressDialog == null) {
            onePayUProgressDialog = OnePayUProgressDialog(activity, null)
        }
        onePayUProgressDialog?.show()
    }

    fun hideLoaderDialog() {
        if ((onePayUProgressDialog != null) && (onePayUProgressDialog?.isShowing == true)) {
            onePayUProgressDialog?.dismiss()
            onePayUProgressDialog = null
        }
    }
}