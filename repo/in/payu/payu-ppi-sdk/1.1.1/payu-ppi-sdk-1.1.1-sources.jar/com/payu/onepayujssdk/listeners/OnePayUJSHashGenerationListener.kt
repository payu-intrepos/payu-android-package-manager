package com.payu.onepayujssdk.listeners

interface OnePayUJSHashGenerationListener {
    fun onHashGenerated(map: HashMap<String, String>)
}