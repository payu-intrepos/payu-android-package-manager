package com.payu.onepayujssdk.models

import com.payu.onepayujssdk.enums.EnvironmentType
import java.security.MessageDigest

data class OnePayUJSKYCParams(
    val clientTxnId: String,
    val customerMobile: String,
    val consent: String,
    val clientId: String,
    val entityId: String,
    val bankId: String,
    val modeId: String,
    val redirectionUrl: String,
    val secureCode: String,
    val environment: EnvironmentType
) {
    fun generateChecksum(): String {
        val concatenatedString = "$clientTxnId|$customerMobile|$clientId|$entityId|$bankId|$modeId|$redirectionUrl|$secureCode"
        return concatenatedString.toSHA256()
    }

    fun getFormPostData(): Map<String, String> {
        return mapOf(
            "clientTxnId" to clientTxnId,
            "customerMobile" to customerMobile,
            "consent" to consent,
            "clientId" to clientId,
            "entityId" to entityId,
            "bankId" to bankId,
            "modeId" to modeId,
            "redirectionUrl" to redirectionUrl,
            "checkSum" to generateChecksum()
        )
    }

    private fun String.toSHA256(): String {
        val bytes = this.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("") { str, it -> str + "%02x".format(it) }
    }
}


