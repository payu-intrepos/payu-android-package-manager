/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.onepayujssdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.onepayujssdk";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final long VERSION_CODE = 3L;
  // Field from build type: release
  public static final String VERSION_NAME = "1.1.1";
}
