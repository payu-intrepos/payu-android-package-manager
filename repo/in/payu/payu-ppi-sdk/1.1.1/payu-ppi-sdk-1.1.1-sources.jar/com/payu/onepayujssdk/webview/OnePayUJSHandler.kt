package com.payu.onepayujssdk.webview

import android.webkit.JavascriptInterface
import androidx.fragment.app.FragmentActivity
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.onepayujssdk.models.InternalConfig.reset
import com.payu.onepayujssdk.utils.AnalyticsUtils

class OnePayUJSHandler(private val activity: FragmentActivity) {

    @JavascriptInterface
    fun onCancel(message: String) {
        activity.supportFragmentManager.popBackStack()
        AnalyticsUtils.logKibanaData(
            activity,
            OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
            OnePayUJSConstants.PAYU_ON_CANCEL,
            OnePayUJSConstants.PAYU_INFO_TYPE,
            OnePayUJSConstants.PAYU_LOW
        )
        InternalConfig.onePayUJSListener?.onCancel()
        reset()
    }

}