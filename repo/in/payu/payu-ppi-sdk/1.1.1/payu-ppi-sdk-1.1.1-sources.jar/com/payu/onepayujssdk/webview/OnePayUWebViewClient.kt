package com.payu.onepayujssdk.webview


import android.graphics.Bitmap
import android.net.http.SslError
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.FragmentActivity
import com.payu.onepayujssdk.BuildConfig
import com.payu.onepayujssdk.constant.OnePayUJSConstants
import com.payu.onepayujssdk.constant.OnePayUJSErrorCodeAndMessageConstants.PAYU_ERROR
import com.payu.onepayujssdk.utils.OnePayUWebViewUtils
import com.payu.onepayujssdk.models.InternalConfig
import com.payu.onepayujssdk.utils.AnalyticsUtils
import com.payu.onepayujssdk.webview.viewmodel.OnePayUWebViewViewModel

class OnePayUWebViewClient(
    private val activity: FragmentActivity,
    private val onePayUWebViewViewModel: OnePayUWebViewViewModel?
) : WebViewClient() {
    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        activity.let { OnePayUWebViewUtils.hideKeyboard(it) }
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        onePayUWebViewViewModel?.hideLoaderDialog()
        
        // Handle KYC redirection URL in onPageFinished (for POST responses)
        Log.d("OnePayUWebViewClient", "📄 onPageFinished called")

        if (onePayUWebViewViewModel?.isKYC == true && url != null) {
            val currentUrl = android.net.Uri.parse(url)
            val redirectionUrl = InternalConfig.onePayUJSKYCParams?.redirectionUrl
            
            if (redirectionUrl != null) {
                val redirectUri = android.net.Uri.parse(redirectionUrl)

                // Check if the URL matches the redirection URL pattern (same host and path)
                // Handle both "/" and empty path as equivalent
                val pathsMatch = currentUrl.path == redirectUri.path || 
                                (currentUrl.path == "/" && redirectUri.path.isNullOrEmpty()) ||
                                (currentUrl.path.isNullOrEmpty() && redirectUri.path == "/")
                

                if (currentUrl.host == redirectUri.host && pathsMatch) {
                    Log.d("OnePayUWebViewClient", "🔵 KYC Redirection URL detected")
                    
                    // Parse query parameters
                    val responseMap = mutableMapOf<String, String>()
                    Log.d("OnePayUWebViewClient", "🔍 Query parameter names: ${currentUrl.queryParameterNames}")
                    currentUrl.queryParameterNames.forEach { param ->
                        val value = currentUrl.getQueryParameter(param) ?: ""
                        responseMap[param] = value
                        Log.d("OnePayUWebViewClient", "   $param = $value")
                    }
                    
                    Log.d("OnePayUWebViewClient", "🔵 KYC Response Parameters: $responseMap")
                    
                    // Close the fragment and call delegate
                    activity.runOnUiThread {
                        activity.supportFragmentManager.popBackStack()
                        
                        val status = responseMap["status"] ?: ""
                        val message = responseMap["message"] ?: ""
                        val docId = responseMap["digio_doc_id"] ?: ""
                        
                        Log.d("OnePayUWebViewClient", "✅ KYC Completed - Status: $status, Message: $message, DocID: $docId")
                        
                        // Call new KYC completion callback
                        InternalConfig.onePayUJSListener?.onKYCCompletion(status, message, docId)
                        
                        InternalConfig.onePayUJSKYCParams = null
                    }
                    
                    return
                }
            }
        }
        
        addSdkDetailsInSession(view)
        merchantParamsInSession(view)
        activity.let { OnePayUWebViewUtils.hideKeyboard(it) }
        
        // Inject geolocation debugging script for KYC
        if (onePayUWebViewViewModel?.isKYC == true) {
            injectGeolocationDebugScript(view)
        }
    }
    
    private fun injectGeolocationDebugScript(view: WebView?) {
        val script = """
            (function() {
                console.log('🔍 PayU SDK: Checking geolocation API availability...');
                
                if (navigator.geolocation) {
                    console.log('✅ PayU SDK: navigator.geolocation is available');
                    
                    // Override getCurrentPosition to add logging
                    const originalGetCurrentPosition = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
                    navigator.geolocation.getCurrentPosition = function(success, error, options) {
                        console.log('📍 PayU SDK: getCurrentPosition called', options);
                        
                        originalGetCurrentPosition(
                            function(position) {
                                console.log('✅ PayU SDK: Location success:', {
                                    latitude: position.coords.latitude,
                                    longitude: position.coords.longitude,
                                    accuracy: position.coords.accuracy
                                });
                                success(position);
                            },
                            function(err) {
                                console.error('❌ PayU SDK: Location error:', {
                                    code: err.code,
                                    message: err.message,
                                    PERMISSION_DENIED: err.code === 1,
                                    POSITION_UNAVAILABLE: err.code === 2,
                                    TIMEOUT: err.code === 3
                                });
                                if (error) error(err);
                            },
                            options
                        );
                    };
                    
                    // Test geolocation immediately with network location (faster)
                    console.log('🧪 PayU SDK: Testing geolocation...');
                    console.log('💡 PayU SDK: Using maximumAge=60000, timeout=30000, enableHighAccuracy=false');
                    navigator.geolocation.getCurrentPosition(
                        function(pos) {
                            console.log('✅ PayU SDK: Test location success!', {
                                lat: pos.coords.latitude,
                                lon: pos.coords.longitude,
                                accuracy: pos.coords.accuracy + 'm',
                                timestamp: new Date(pos.timestamp).toISOString()
                            });
                        },
                        function(err) {
                            console.error('❌ PayU SDK: Test location failed!', err.code, err.message);
                            console.error('💡 PayU SDK: Error details:', {
                                code: err.code,
                                message: err.message,
                                PERMISSION_DENIED: err.code === 1 ? 'User denied permission' : '',
                                POSITION_UNAVAILABLE: err.code === 2 ? 'Location not available' : '',
                                TIMEOUT: err.code === 3 ? 'Please enable Location Services in device settings' : ''
                            });
                        },
                        { 
                            timeout: 30000,              // 30 seconds (increased from 10)
                            enableHighAccuracy: false,   // Use network location (faster)
                            maximumAge: 60000            // Accept cached location up to 1 minute old
                        }
                    );
                } else {
                    console.error('❌ PayU SDK: navigator.geolocation is NOT available!');
                }
                
                // Log permissions API if available
                if (navigator.permissions) {
                    console.log('🔐 PayU SDK: Checking geolocation permission state...');
                    navigator.permissions.query({name: 'geolocation'}).then(function(result) {
                        console.log('🔐 PayU SDK: Geolocation permission state:', result.state);
                    }).catch(function(err) {
                        console.log('🔐 PayU SDK: Cannot query permission:', err);
                    });
                } else {
                    console.log('⚠️ PayU SDK: Permissions API not available');
                }
            })();
        """.trimIndent()
        
        view?.evaluateJavascript(script) { result ->
            Log.d("OnePayUWebViewClient", "📱 Geolocation debug script injected, result: $result")
        }
    }

    override fun onLoadResource(view: WebView?, url: String?) {
        super.onLoadResource(view, url)
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: WebResourceError?
    ) {
        super.onReceivedError(view, request, error)
    }

    override fun onReceivedHttpError(
        view: WebView?,
        request: WebResourceRequest?,
        errorResponse: WebResourceResponse?
    ) {
        super.onReceivedHttpError(view, request, errorResponse)
        val url = request?.url?.toString()?.lowercase()
        if (url?.contains(OnePayUJSConstants.PAYU_FE_VIRTUAL_CARD_END_POINTS) == true) {
            view?.context?.let {
                AnalyticsUtils.logKibanaData(
                    it,
                    OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
                    "HttpError" + errorResponse?.statusCode + "_" + PAYU_ERROR,
                    OnePayUJSConstants.PAYU_ERROR_TYPE,
                    OnePayUJSConstants.PAYU_HIGH
                )
            }
            activity.supportFragmentManager.popBackStack()
            InternalConfig.onePayUJSListener?.onError(
                errorResponse?.statusCode ?: -1,
                 PAYU_ERROR
            )
        }
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        view?.context?.let {
            AnalyticsUtils.logKibanaData(
                it,
                OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
                "SslError" + error?.primaryError,
                OnePayUJSConstants.PAYU_ERROR_TYPE,
                OnePayUJSConstants.PAYU_HIGH
            )
        }
        super.onReceivedSslError(view, handler, error)
    }

    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
        view?.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == MotionEvent.ACTION_UP) {
                if (view.canGoBack()) {
                    view.context?.let {
                        AnalyticsUtils.logKibanaData(
                            it,
                            OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
                            OnePayUJSConstants.PAYU_ON_BACK_PRESS_ON_JS_PAGE,
                            OnePayUJSConstants.PAYU_INFO_TYPE,
                            OnePayUJSConstants.PAYU_LOW
                        )
                    }
                    view.goBack()
                } else {
                    view.context?.let {
                        AnalyticsUtils.logKibanaData(
                            it,
                            OnePayUJSConstants.PAYU_PPI_SDK_CALLBACK,
                            OnePayUJSConstants.PAYU_ON_BACK_PRESSED,
                            OnePayUJSConstants.PAYU_INFO_TYPE,
                            OnePayUJSConstants.PAYU_LOW
                        )
                    }
                    onePayUWebViewViewModel?.onBackPressed()
                }
                return@OnKeyListener true
            }
            return@OnKeyListener false
        })
        super.doUpdateVisitedHistory(view, url, isReload)
    }


    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        // Handle KYC redirection URL
        if (onePayUWebViewViewModel?.isKYC == true) {
            val url = request?.url
            val redirectionUrl = InternalConfig.onePayUJSKYCParams?.redirectionUrl
            
            if (url != null && redirectionUrl != null) {
                val redirectUri = android.net.Uri.parse(redirectionUrl)
                
                // Check if the URL matches the redirection URL pattern (same host and path)
                // Handle both "/" and empty path as equivalent
                val pathsMatch = url.path == redirectUri.path || 
                                (url.path == "/" && redirectUri.path.isNullOrEmpty()) ||
                                (url.path.isNullOrEmpty() && redirectUri.path == "/")
                
                if (url.host == redirectUri.host && pathsMatch) {
                    Log.d("OnePayUWebViewClient", "🔵 KYC Redirection URL detected")
                    
                    // Parse query parameters
                    val responseMap = mutableMapOf<String, String>()
                    url.queryParameterNames.forEach { param ->
                        responseMap[param] = url.getQueryParameter(param) ?: ""
                    }

                    // Close the fragment and call delegate
                    activity.runOnUiThread {
                        activity.supportFragmentManager.popBackStack()
                        
                        val status = responseMap["status"] ?: ""
                        val message = responseMap["message"] ?: ""
                        val docId = responseMap["digio_doc_id"] ?: ""
                        
                        Log.d("OnePayUWebViewClient", "✅ KYC Completed - Status: $status, Message: $message, DocID: $docId")
                        
                        // Call new KYC completion callback
                        InternalConfig.onePayUJSListener?.onKYCCompletion(status, message, docId)
                        
                        InternalConfig.onePayUJSKYCParams = null
                    }
                    
                    return true
                }
            }
        }
        
        return super.shouldOverrideUrlLoading(view, request)
    }

    private fun addSdkDetailsInSession(view: WebView?) {
        val sdkVersion = BuildConfig.VERSION_NAME
        val deviceDetails = OnePayUWebViewUtils.getDeviceDetails(activity)
        val applicationPackage = view?.context?.applicationContext?.packageName
        val applicationVersion = OnePayUWebViewUtils.getApplicationVersionCode(activity)

        val script =
            "sessionStorage.setItem(\"androidSDK\", true);sessionStorage.setItem(\"sdkVersion\", \"${sdkVersion ?: ""}\");sessionStorage.setItem(\"applicationPackage\", \"${applicationPackage ?: ""}\");sessionStorage.setItem(\"applicationVersion\", \"${applicationVersion ?: ""}\");sessionStorage.setItem(\"deviceDetails\", \"${deviceDetails ?: ""}\");"

        view?.evaluateJavascript(script) { s ->
            Log.d("LogName", s!!) // Prints: "this"
        }

    }

    private fun merchantParamsInSession(view: WebView?) {
        val merchantKey = InternalConfig.onePayUJSParams?.merchantKey
        val referenceId = InternalConfig.onePayUJSParams?.referenceId
        val walletIdentifier = InternalConfig.onePayUJSParams?.walletIdentifier
        val redirectUrl = InternalConfig.onePayUJSParams?.redirectUrl
        val walletUrn = InternalConfig.onePayUJSParams?.walletUrn
        val environment = InternalConfig.onePayUJSParams?.environment
        val mobile = InternalConfig.onePayUJSParams?.mobileNumber
        val script =
            "sessionStorage.setItem(\"merchantKey\", \"${merchantKey ?: ""}\");sessionStorage.setItem(\"refernceID\", \"${referenceId ?: ""}\");sessionStorage.setItem(\"walletIdentifire\", \"${walletIdentifier ?: ""}\");sessionStorage.setItem(\"walletUrn\", \"${walletUrn ?: ""}\");sessionStorage.setItem(\"redirectUrl\", \"${redirectUrl ?: ""}\");sessionStorage.setItem(\"mobile\", \"${mobile ?: ""}\");sessionStorage.setItem(\"environment\", \"${environment ?: ""}\");"
        view?.evaluateJavascript(script) { s ->
            Log.d("LogName", s!!) // Prints: "this"
        }
    }

}