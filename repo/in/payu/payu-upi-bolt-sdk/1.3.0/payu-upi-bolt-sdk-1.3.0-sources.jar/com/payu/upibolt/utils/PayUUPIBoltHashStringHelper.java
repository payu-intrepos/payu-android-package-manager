package com.payu.upibolt.utils;

import com.payu.commonmodelssdk.PostDataManager;
import com.payu.commonmodelssdk.constants.PayUUpiConstant;
import com.payu.commonmodelssdk.enums.UpiHashCommand;
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams;


import java.util.HashMap;

//TODO: DD when we are using PaymentParamHelper then why we are re-writing this? Use HashStringHelper from PPH
public class PayUUPIBoltHashStringHelper {
    public HashMap<String, String> getHashString(UpiHashCommand command, PayUUPIBoltPaymentParams paymentParams, String merchantKey, String email) {
        HashMap map = new HashMap<String, String>();
        StringBuilder beneficiaryDetails = appendTpvDetails(paymentParams);
        switch (command) {
            case PaymentHash: {
                map.put(PayUUpiConstant.HASH_STRING,
                        merchantKey + "|" + paymentParams.getTxnId() + "|" + paymentParams.getAmount() + "|" + paymentParams.getProductInfo() + "|" +
                                paymentParams.getFirstName() + "|" + email + "|" + paymentParams.getUdf1() + "|" + paymentParams.getUdf2() + "|" +
                                paymentParams.getUdf3() + "|" + paymentParams.getUdf4() + "|" + paymentParams.getUdf5() + "|||||"+beneficiaryDetails);
                map.put(PayUUpiConstant.HASH_NAME, command.getHashName());
                return map;
            }
        }
        return map;

    }

    private StringBuilder appendTpvDetails(PayUUPIBoltPaymentParams paymentParams) {
        if (paymentParams.getBeneficiaryDetails() != null && !paymentParams.getBeneficiaryDetails().isEmpty()) {
            StringBuilder beneficiaryDetails = PostDataManager.INSTANCE.getPayUBeneficiaryDetails(paymentParams.getAccountDetail());
            return new StringBuilder("|" + beneficiaryDetails.append("|"));
        } else {
            return new StringBuilder("|");
        }
    }

}
