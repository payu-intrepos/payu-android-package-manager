package com.payu.upibolt.parser

object HybridConfigKeys {
    const val MERCHANT_NAME = "merchantName"
    const val MERCHANT_KEY = "merchantKey"
    const val PHONE = "phone"
    const val EMAIL = "email"
    const val REQUEST_ID = "requestId"
    const val PLUGIN_TYPES = "pluginTypes"
    const val IS_PRODUCTION = "isProduction"
    const val EXCLUDED_BANKS_IINS = "excludedBanksIINs"
    const val ISSUING_BANKS = "issuingBanks"
    const val API_FAILURE_CALLBACK = "apiFailureCallback"
    const val IS_PROTECTED_SCREEN = "IsProtectedScreen"
}