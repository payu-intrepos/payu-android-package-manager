package com.payu.upibolt.utils

import com.olive.upi.transport.api.UpiService
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant

val payUAxisResponseTypeMap = HashMap<Int, Int>().apply {
    put(UpiService.REQUEST_SDK_HANDSHAKE, PayUResponseTypes.REQUEST_SDK_HANDSHAKE)
    put(UpiService.REQUEST_LIST_BANKS, PayUResponseTypes.REQUEST_LIST_BANKS)
    put(UpiService.REQUEST_FETCH_ACCOUNT_V3, PayUResponseTypes.REQUEST_FETCH_ACCOUNT_V3)
    put(UpiService.REQUEST_SAVE_ACCOUNT_V3, PayUResponseTypes.REQUEST_SAVE_ACCOUNT_V3)
    put(UpiService.REQUEST_ACCOUNT_MOBILE_REG, PayUResponseTypes.REQUEST_ACCOUNT_MOBILE_REG)
    put(UpiService.REQUEST_ALL_ACCOUNTS_V3, PayUResponseTypes.REQUEST_ALL_ACCOUNTS_V3)
    put(UpiService.REQUEST_GET_BALANCE, PayUResponseTypes.REQUEST_GET_BALANCE)
    put(UpiService.REQUEST_PAY, PayUResponseTypes.REQUEST_PAY)
    put(UpiService.REQUEST_GET_CHANGE_MPIN, PayUResponseTypes.REQUEST_GET_CHANGE_MPIN)
    put(UpiService.REQUEST_GET_RAISE_QUERY_V3, PayUResponseTypes.REQUEST_GET_RAISE_QUERY_V3)
    put(UpiService.REQUEST_LIST_QUERIES_V3, PayUResponseTypes.REQUEST_LIST_QUERIES_V3)
    put(UpiService.REQUEST_GET_ACCOUNT_REMOVE_V3, PayUResponseTypes.REQUEST_GET_ACCOUNT_REMOVE_V3)
    put(UpiService.REQUEST_GET_VPA_REMOVE_V3, PayUResponseTypes.REQUEST_GET_VPA_REMOVE_V3)
    put(UpiService.REQUEST_GET_VPA_V3, PayUResponseTypes.REQUEST_GET_VPA_V3)
    put(UpiService.REQUEST_GET_CUSTOMER_deregister_V3, PayUResponseTypes.REQUEST_GET_CUSTOMER_deregister_V3)
    put(UpiService.REQUEST_GET_PROFilE_VPA_V3, PayUResponseTypes.REQUEST_GET_PROFilE_VPA_V3)
    put(UpiService.REQUEST_SAVE_VPA_V3, PayUResponseTypes.REQUEST_SAVE_VPA_V3)
    put(UpiService.REQUEST_GET_TRANSACTION_HISTORY_V3, PayUResponseTypes.REQUEST_GET_TRANSACTION_HISTORY_V3)
    put(PayUResponseTypes.CHANGE_PIN_USER_CANCELLED, PayUResponseTypes.REQUEST_GET_CHANGE_MPIN)
    put(PayUResponseTypes.CHECK_BALANCE_USER_CANCELLED, PayUResponseTypes.REQUEST_GET_BALANCE)
    put(PayUResponseTypes.RESET_PIN_USER_CANCELLED, PayUResponseTypes.REQUEST_ACCOUNT_MOBILE_REG)
    put(PayUResponseTypes.PAY_USER_CANCELLED, PayUResponseTypes.REQUEST_PAY)
}