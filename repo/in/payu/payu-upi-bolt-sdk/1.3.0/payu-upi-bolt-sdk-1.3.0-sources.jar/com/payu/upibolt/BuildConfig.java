/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.upibolt;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.upibolt";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final String AXIS_SECRET_KEY = "5CCA90F2BF966BC9D02EC3F4FF31C8D11EEAA8E52CDBC488416F2C8DDEF66788";
  // Field from build type: release
  public static final String AXIS_SECRET_KEY_UAT = "76BDC4F19EF934C8019807CEDA5B4002F075366C4F04C0E6B99AB22F75DF26BB";
  // Field from default config.
  public static final String VERSION_NAME = "1.3.0";
  // Field from build type: release
  public static final String ctAccountId = "WR7-R6W-646Z";
  // Field from build type: release
  public static final String ctPassCode = "IOQ-IIE-OAUL";
}
