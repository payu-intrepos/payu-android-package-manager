package com.payu.upibolt.listeners

/**
 * UpiInitiateCallback  class for callBack to internal for sdk initiation
 * */
interface UpiInitiateCallback {
    fun onSDKSuccess()
    fun onSdKError(errorCode: Int, errorMessage: String?)
}