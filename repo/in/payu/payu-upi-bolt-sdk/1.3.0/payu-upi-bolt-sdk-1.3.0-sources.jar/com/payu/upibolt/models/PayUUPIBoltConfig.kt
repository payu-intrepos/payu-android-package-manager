package com.payu.upibolt.models

import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.listeners.ApiFailedCallback

/**
 * SDKInitParams  class for params in sdk initialization
 * */
data class PayUUPIBoltConfig(
    val merchantKey:String,
    var email: String? = null,
    var isProduction: Boolean = true,
    val pluginTypes: List<PluginType>,
    var refId : String,
    val issuingBanks: List<String>? = null,
    val apiFailureCallback: ApiFailedCallback? = null
)