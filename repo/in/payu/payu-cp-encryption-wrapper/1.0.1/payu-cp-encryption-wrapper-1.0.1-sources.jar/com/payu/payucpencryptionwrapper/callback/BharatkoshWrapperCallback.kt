package com.payu.payucpencryptionwrapper.callback

/**
 * Callback interface for BharatkoshWrapper
 * Returns encrypted response to the merchant
 */
interface BharatkoshWrapperCallback {
    /**
     * Called when the payment flow completes successfully
     * @param encryptedResponse The encrypted response to be sent back to Bharatkosh
     */
    fun onSuccess(encryptedResponse: String)
    
    /**
     * Called when the payment flow fails
     * @param encryptedResponse The encrypted error response to be sent back to Bharatkosh
     */
    fun onFailure(encryptedResponse: String)
    
    /**
     * Called when the user cancels the payment
     * @param encryptedResponse The encrypted cancel response to be sent back to Bharatkosh
     */
    fun onCancel(encryptedResponse: String)
    
    /**
     * Called when an error occurs during the payment flow
     * @param encryptedResponse The encrypted error response to be sent back to Bharatkosh
     */
    fun onError(encryptedResponse: String)
}

