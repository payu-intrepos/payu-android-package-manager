package com.payu.payucpencryptionwrapper.checkoutpro

import android.app.Activity
import com.payu.payucpencryptionwrapper.hash.BharatkoshHashProvider

/**
 * Interface for CheckoutPro SDK integration
 * This allows the wrapper to work with different versions of CheckoutPro SDK
 */
interface CheckoutProIntegration {
    
    /**
     * Launch CheckoutPro SDK with payment parameters as HashMap (from API response)
     */
    fun launch(
        activity: Activity,
        paymentParamsMap: HashMap<String, Any>,
        hashProvider: BharatkoshHashProvider,
        callback: CheckoutProCallback
    )
}

/**
 * Callback interface for CheckoutPro SDK responses
 */
interface CheckoutProCallback {
    fun onSuccess(response: Any)
    fun onFailure(response: Any)
    fun onCancel()
    fun onError(error: String)
}

/**
 * Default implementation uses CheckoutProIntegrationImpl
 * This is the actual PayU CheckoutPro SDK integration
 */
typealias DefaultCheckoutProIntegration = CheckoutProIntegrationImpl

