package com.payu.payucpencryptionwrapper.checkoutpro

import android.app.Activity
import android.util.Log
import android.webkit.WebView
import com.payu.base.models.ErrorResponse
import com.payu.checkoutpro.PayUCheckoutPro
import com.payu.payucpencryptionwrapper.hash.BharatkoshHashProvider
import com.payu.ui.model.listeners.PayUCheckoutProListener
import com.payu.ui.model.listeners.PayUHashGenerationListener


/**
 * Actual implementation of CheckoutProIntegration using PayU CheckoutPro SDK
 * Based on React Native wrapper implementation
 */
class CheckoutProIntegrationImpl : CheckoutProIntegration, PayUCheckoutProListener {
    
    @Volatile
    private var currentCallback: CheckoutProCallback? = null
    
    @Volatile
    private var currentHashProvider: BharatkoshHashProvider? = null
    
    override fun launch(
        activity: Activity,
        paymentParamsMap: HashMap<String, Any>,
        hashProvider: BharatkoshHashProvider,
        callback: CheckoutProCallback
    ) {
        try {
            Log.d("CheckoutProIntegration", "Launching CheckoutPro SDK")
            
            // Store callback and hash provider for use in listener methods
            currentCallback = callback
            currentHashProvider = hashProvider

            // Launch CheckoutPro SDK with config and listener
            PayUCheckoutPro.open(activity, paymentParamsMap, this)
            
        } catch (e: Exception) {
            Log.e("CheckoutProIntegration", "Failed to launch CheckoutPro", e)
            callback.onError("Failed to launch CheckoutPro: ${e.message}")
        }
    }
    
    // PayUCheckoutProListener implementation
    override fun onPaymentSuccess(result: Any) {
        Log.d("CheckoutProIntegration", "Payment success")
        try {
            @Suppress("UNCHECKED_CAST")
            val resultMap = result as? HashMap<String, String> ?: HashMap<String, String>()
            currentCallback?.onSuccess(resultMap)
        } catch (e: Exception) {
            Log.e("CheckoutProIntegration", "Error handling payment success", e)
            currentCallback?.onSuccess(result)
        }
    }
    
    override fun onPaymentFailure(result: Any) {
        Log.d("CheckoutProIntegration", "Payment failure")
        try {
            @Suppress("UNCHECKED_CAST")
            val resultMap = result as? HashMap<String, String> ?: HashMap<String, String>()
            currentCallback?.onFailure(resultMap)
        } catch (e: Exception) {
            Log.e("CheckoutProIntegration", "Error handling payment failure", e)
            currentCallback?.onFailure(result)
        }
    }
    
    override fun onPaymentCancel(isTxnInitiated: Boolean) {
        Log.d("CheckoutProIntegration", "Payment cancelled, isTxnInitiated: $isTxnInitiated")
        currentCallback?.onCancel()
    }

    override fun generateHash(
        map: HashMap<String, String?>,
        hashGenerationListener: PayUHashGenerationListener
    ) {
        currentHashProvider?.getHash(map, hashGenerationListener, currentCallback)
    }

    override fun onError(errorResponse: ErrorResponse) {
        val errorMessage = errorResponse.errorMessage ?: "Unknown error"
        val errorCode = errorResponse.errorCode?.toString() ?: ""
        Log.e("CheckoutProIntegration", "Payment error: $errorMessage (Code: $errorCode)")
        currentCallback?.onError(errorMessage)
    }
    
    override fun setWebViewProperties(webView: WebView?, o: Any?) {
        // Optional: Implement WebView customization if needed
        Log.d("CheckoutProIntegration", "setWebViewProperties called")
    }
}
