package com.payu.payucpencryptionwrapper.data.model

/**
 * Cancel/Error response model
 */
data class CancelErrorResponse(
    val status: String, // "cancel" or "error"
    val message: String
)

