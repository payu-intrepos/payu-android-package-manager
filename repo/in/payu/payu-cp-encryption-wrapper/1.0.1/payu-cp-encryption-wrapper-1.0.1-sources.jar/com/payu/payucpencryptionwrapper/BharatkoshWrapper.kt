package com.payu.payucpencryptionwrapper

import android.app.Activity
import android.util.Log
import com.payu.payucpencryptionwrapper.callback.BharatkoshWrapperCallback
import com.payu.payucpencryptionwrapper.checkoutpro.CheckoutProCallback
import com.payu.payucpencryptionwrapper.checkoutpro.CheckoutProIntegration
import com.payu.payucpencryptionwrapper.checkoutpro.CheckoutProIntegrationImpl
import com.payu.payucpencryptionwrapper.data.api.HttpClient
import com.payu.payucpencryptionwrapper.data.model.CancelErrorResponse
import com.payu.payucpencryptionwrapper.hash.BharatkoshHashProvider
import com.payu.payucpencryptionwrapper.util.PayUHelper
import org.json.JSONObject

/**
 * Main wrapper class for Bharatkosh encryption/decryption
 * Wraps PayU CheckoutPro SDK and handles encryption/decryption
 * Uses callback-based approach (no coroutines dependency)
 */
class BharatkoshWrapper private constructor(
    private val checkoutProIntegration: CheckoutProIntegration = CheckoutProIntegrationImpl()
) {
    
    @Volatile
    private var paymentHash: String? = null
    @Volatile
    private var isHandlingError = false // Flag to prevent infinite loop in error handling
    @Volatile
    private var txnId: String? = null
    private var client: HttpClient? = null
    companion object {
        @Volatile
        private var instance: BharatkoshWrapper? = null
        
        /**
         * Get singleton instance of BharatkoshWrapper
         */
        fun getInstance(): BharatkoshWrapper {
            return instance ?: synchronized(this) {
                instance ?: BharatkoshWrapper().also { instance = it }
            }
        }
    }
    
    /**
     * Start payment flow with encrypted payload
     * @param activity The activity context
     * @param encrequestparameter The encrypted request parameter from Bharatkosh
     * @param reqdigitalsignature The digital signature from Bharatkosh
     * @param merchIdVal The merchant ID value
     * @param callback Callback to receive encrypted response
     */
    fun startPayment(
        activity: Activity,
        encrequestparameter: String,
        reqdigitalsignature: String,
        merchIdVal: String,
        isProduction: Boolean,
        callback: BharatkoshWrapperCallback
    ) {
        // Validate input parameters
        if (encrequestparameter.isBlank() || reqdigitalsignature.isBlank() || merchIdVal.isBlank()) {
            handleError("Invalid input parameters: all fields are required", callback)
            return
        }
        client = HttpClient(isProduction)
        // Step 1: Decrypt the incoming request
        client?.validateRequest(encrequestparameter, reqdigitalsignature, merchIdVal) { result ->
            result.fold(
                onSuccess = { json ->
                    try {
                        // Step 2: Parse decrypted response
                        // API response structure: {"status":"success","message":"ok","data":{"config":{...},"params":{...},"hash":"..."}}
                        val dataJson = json.optJSONObject("data")
                        if (dataJson == null) {
                            handleError("Invalid decrypted response: missing 'data' field", callback)
                            return@fold
                        }
                        
                        // Extract paymentHash from data.hash
                        val paymentHashValue = dataJson.optString("hash").takeIf { it.isNotEmpty() }
                        
                        // Validate paymentHash
                        if (paymentHashValue.isNullOrEmpty()) {
                            handleError("Invalid decrypted response: missing 'hash' field", callback)
                            return@fold
                        }
                        
                        // Step 3: Store paymentHash and convert payment params JSON to HashMap
                        paymentHash = paymentHashValue
                        val paymentParamsMap = PayUHelper.jsonObjectToHashMap(dataJson)
                        // Extract and store txnId safely
                        val paramsValue = paymentParamsMap["payUPaymentParams"]
                        @Suppress("UNCHECKED_CAST")
                        val paymentMap = when (paramsValue) {
                            is HashMap<*, *> -> paramsValue as? HashMap<String, Any>
                            else -> null
                        }
                        this.txnId = paymentMap?.get("transactionId")?.toString()
                        // Step 4: Create hash provider with stored paymentHash
                        val hashProvider = BharatkoshHashProvider(paymentHash, key = merchIdVal, client)
                        
                        // Step 5: Launch CheckoutPro SDK with HashMap directly from API
                        launchCheckoutPro(activity, paymentParamsMap, hashProvider, callback)
                        
                    } catch (e: Exception) {
                        Log.e("BharatkoshWrapper", "Exception parsing response", e)
                        handleError("Exception parsing response: ${e.message}", callback)
                    }
                },
                onFailure = { error ->
                    Log.e("BharatkoshWrapper", "Failed to decrypt request", error)
                    handleError("Failed to decrypt request: ${error.message}", callback)
                }
            )
        }
    }
    
    /**
     * Launch CheckoutPro SDK with HashMap directly from API
     */
    private fun launchCheckoutPro(
        activity: Activity,
        paymentParamsMap: HashMap<String, Any>,
        hashProvider: BharatkoshHashProvider,
        callback: BharatkoshWrapperCallback
    ) {
        try {
            checkoutProIntegration.launch(
                activity,
                paymentParamsMap,
                hashProvider,
                object : CheckoutProCallback {
                    override fun onSuccess(response: Any) {
                        handleCheckoutProSuccess(response, callback)
                    }
                    
                    override fun onFailure(response: Any) {
                        handleCheckoutProFailure(response, callback)
                    }
                    
                    override fun onCancel() {
                        handleCheckoutProCancel(callback)
                    }
                    
                    override fun onError(error: String) {
                        handleCheckoutProError(error, callback)
                    }
                }
            )
        } catch (e: Exception) {
            Log.e("BharatkoshWrapper", "Failed to launch CheckoutPro", e)
            handleError("Failed to launch CheckoutPro: ${e.message}", callback)
        }
    }
    
    /**
     * Handle CheckoutPro success response
     */
    private fun handleCheckoutProSuccess(response: Any, callback: BharatkoshWrapperCallback) {
        encryptAndSendResponse(response, callback, "success")
    }
    
    /**
     * Handle CheckoutPro failure response
     */
    private fun handleCheckoutProFailure(response: Any, callback: BharatkoshWrapperCallback) {
        encryptAndSendResponse(response, callback, "failure")
    }
    
    /**
     * Handle user cancel
     */
    private fun handleCheckoutProCancel(callback: BharatkoshWrapperCallback) {
        val cancelResponse = CancelErrorResponse(
            status = "cancel",
            message = "Canceled by user"
        )
        encryptAndSendResponse(cancelResponse, callback, "cancel")
    }
    
    /**
     * Handle error
     */
    private fun handleCheckoutProError(errorMessage: String, callback: BharatkoshWrapperCallback) {
        val errorResponse = CancelErrorResponse(
            status = "error",
            message = errorMessage
        )
        encryptAndSendResponse(errorResponse, callback, "error")
    }
    
    /**
     * Encrypt response and send to callback
     * Prevents infinite loop by checking isHandlingError flag
     * Only validate-response API failures bypass encryption
     */
    private fun encryptAndSendResponse(
        response: Any,
        callback: BharatkoshWrapperCallback,
        responseType: String
    ) {
        // Note: We don't check isHandlingError here because we want to encrypt all errors
        // The isHandlingError flag is only used in handleError to prevent recursive calls
        
        try {
            // Convert response to JSON
            val responseJson = convertResponseToJson(response)
            
            // Call validate-response API - send responseJson directly (not wrapped)
            // Based on curl: the API expects the response object directly, not wrapped in {"response": ...}
            if (client == null) {
                cleanup()
                isHandlingError = true
                callback.onError("Failed to encrypt response: HttpClient not initialized")
                return
            }
            
            client?.validateResponse(responseJson) { result ->
                result.fold(
                    onSuccess = { json ->
                        val encryptedResponse = json.optJSONObject("data")
                        if (encryptedResponse != null) {
                            // Cleanup before sending response
                            cleanup()
                            
                            // Reset error flag on success
                            isHandlingError = false
                            
                            // Send encrypted response to callback
                            val encryptedParams = encryptedResponse.optString("encryptedParams").takeIf { it.isNotEmpty() }
                            if (encryptedParams != null && encryptedParams.isNotEmpty()) {
                                sendEncryptedResponseToCallback(responseType, encryptedParams, callback)
                            } else {
                                handleMissingEncryptedParams(callback)
                            }
                        } else {
                            // validate-response API returned empty data - bypass encryption (this is the only exception)
                            cleanup()
                            isHandlingError = true // Set flag to prevent further encryption attempts
                            callback.onError("Failed to encrypt response: empty encryptedResponse")
                        }
                    },
                    onFailure = { error ->
                        Log.e("BharatkoshWrapper", "Failed to encrypt response", error)
                        // validate-response API failure - bypass encryption (this is the only exception)
                        cleanup()
                        isHandlingError = true // Set flag to prevent further encryption attempts
                        callback.onError("Failed to encrypt response: ${error.message}")
                    }
                )
            }
        } catch (e: Exception) {
            Log.e("BharatkoshWrapper", "Exception while encrypting response", e)
            // Exception during validate-response API call - bypass encryption (this is the only exception)
            cleanup()
            isHandlingError = true // Set flag to prevent further encryption attempts
            callback.onError("Exception while encrypting response: ${e.message}")
        }
    }

    /**
     * Handle error and send encrypted error response
     * All errors must be encrypted (except validate-response API failures)
     * If isHandlingError is true, it means validate-response API already failed, so bypass encryption
     */
    private fun handleError(
        errorMessage: String,
        callback: BharatkoshWrapperCallback
    ) {
        // If isHandlingError is true, it means validate-response API already failed
        // In this case, we bypass encryption to avoid infinite loop
        if (isHandlingError) {
            cleanup()
            callback.onError("Error: $errorMessage")
            return
        }
        
        // All other errors must be encrypted
        // Don't set isHandlingError here - only set it when validate-response API fails
        val errorResponse = CancelErrorResponse(
            status = "error",
            message = errorMessage
        )
        encryptAndSendResponse(errorResponse, callback, "error")
    }
    
    /**
     * Convert response object to JSONObject
     */
    private fun convertResponseToJson(response: Any): JSONObject {
        return when (response) {
            is CancelErrorResponse -> createCancelErrorJson(response)
            is HashMap<*, *> -> convertHashMapToJson(response)
            else -> convertGenericResponseToJson(response)
        }
    }
    
    /**
     * Create JSON for CancelErrorResponse
     */
    private fun createCancelErrorJson(response: CancelErrorResponse): JSONObject {
        return JSONObject().apply {
            put("status", response.status)
            put("message", response.message)
            put("txnId", txnId)
        }
    }
    
    /**
     * Convert HashMap response to JSONObject
     */
    private fun convertHashMapToJson(response: HashMap<*, *>): JSONObject {
        val payUResponse = response["payuResponse"]
        return when {
            payUResponse is HashMap<*, *> -> convertHashMapToJsonObject(payUResponse)
            payUResponse is String -> parseStringAsJson(payUResponse)
            else -> convertMapToJsonObject(response)
        }
    }
    
    /**
     * Convert HashMap to JSONObject
     */
    private fun convertHashMapToJsonObject(map: HashMap<*, *>): JSONObject {
        return try {
            JSONObject(map.toString())
        } catch (e: Exception) {
            JSONObject().apply {
                (map as? Map<*, *>)?.forEach { (k, v) ->
                    put(k?.toString() ?: "", v?.toString() ?: "")
                }
            }
        }
    }
    
    /**
     * Parse string as JSON with fallback
     */
    private fun parseStringAsJson(jsonString: String): JSONObject {
        return try {
            JSONObject(jsonString)
        } catch (e: Exception) {
            JSONObject().apply {
                put("response", jsonString)
            }
        }
    }
    
    /**
     * Convert generic Map to JSONObject
     */
    private fun convertMapToJsonObject(map: Map<*, *>): JSONObject {
        return JSONObject().apply {
            map.forEach { (k, v) ->
                put(k?.toString() ?: "", v?.toString() ?: "")
            }
        }
    }
    
    /**
     * Convert generic response to JSONObject
     */
    private fun convertGenericResponseToJson(response: Any): JSONObject {
        return try {
            JSONObject(response.toString())
        } catch (e: Exception) {
            JSONObject().apply {
                put("response", response.toString())
            }
        }
    }
    
    /**
     * Send encrypted response to appropriate callback based on type
     */
    private fun sendEncryptedResponseToCallback(
        responseType: String,
        encryptedParams: String,
        callback: BharatkoshWrapperCallback
    ) {
        when (responseType) {
            "success" -> callback.onSuccess(encryptedParams)
            "failure" -> callback.onFailure(encryptedParams)
            "cancel" -> callback.onCancel(encryptedParams)
            "error" -> callback.onError(encryptedParams)
            else -> callback.onError("Unknown response type: $responseType")
        }
    }
    
    /**
     * Handle missing encrypted params error
     */
    private fun handleMissingEncryptedParams(callback: BharatkoshWrapperCallback) {
        cleanup()
        isHandlingError = true
        callback.onError("Failed to encrypt response: missing encryptedParams")
    }
    
    /**
     * Cleanup all locally stored data
     */
    private fun cleanup() {
        paymentHash = null
        txnId = null
        client = null
    }

}
