package com.payu.payucpencryptionwrapper.util

import org.json.JSONArray
import org.json.JSONObject

class PayUHelper {
    companion object {
        /**
         * Convert JSONObject to HashMap (as received from API)
         * @param json The JSONObject to convert (can be null)
         * @return HashMap representation of the JSONObject, or empty HashMap if json is null
         */
        fun jsonObjectToHashMap(json: JSONObject?): HashMap<String, Any> {
            if (json == null) return HashMap()
            val map = HashMap<String, Any>()
            val keys = json.keys()
            while (keys.hasNext()) {
                var key = keys.next()
                var value = json.opt(key)
                if (value != null) {
                    key = transformKey(key)
                    value = transformValue(key, value)
                    map[key] = value
                }
            }
            return map
        }
        
        /**
         * Transform key name based on business rules
         */
        private fun transformKey(key: String): String {
            return when {
                key.contentEquals("config") -> "payUCheckoutProConfig"
                key.contentEquals("params") -> "payUPaymentParams"
                else -> key
            }
        }
        
        /**
         * Transform value based on type and key
         */
        private fun transformValue(key: String, value: Any): Any {
            return when {
                key.contentEquals("payUPaymentParams") && value is JSONObject -> transformParamsValue(value)
                key.contentEquals("environment") -> transformEnvironmentValue(value)
                value is JSONArray -> transformJsonArrayValue(value)
                value is JSONObject -> jsonObjectToHashMap(value)
                else -> value
            }
        }
        
        /**
         * Transform params JSONObject value
         */
        private fun transformParamsValue(value: JSONObject): HashMap<String, Any> {
            val jsonCopy = JSONObject(value.toString())
            if (jsonCopy.optString("userCredential").isNullOrEmpty()) {
                jsonCopy.put("userCredential", "")
            }
            return jsonObjectToHashMap(jsonCopy)
        }
        
        /**
         * Transform environment value
         */
        private fun transformEnvironmentValue(value: Any): String {
            return if (value.toString().contentEquals("uat")) "1" else "0"
        }
        
        /**
         * Transform JSONArray to ArrayList of HashMaps
         */
        private fun transformJsonArrayValue(value: JSONArray): ArrayList<HashMap<String, Any>> {
            val hashMapList = ArrayList<HashMap<String, Any>>()
            for (i in 0 until value.length()) {
                val jsonItem = value.optJSONObject(i)
                if (jsonItem != null) {
                    hashMapList.add(jsonObjectToHashMap(jsonItem))
                }
            }
            return hashMapList
        }
    }
}