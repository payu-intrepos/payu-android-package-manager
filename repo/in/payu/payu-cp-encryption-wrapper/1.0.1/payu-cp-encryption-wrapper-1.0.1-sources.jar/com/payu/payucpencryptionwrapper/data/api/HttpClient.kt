package com.payu.payucpencryptionwrapper.data.api

import android.util.Log
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.net.ssl.HttpsURLConnection
import com.payu.india.Payu.PayuUtils
import com.payu.india.Payu.PayuConstants

/**
 * Simple Result type for callbacks
 */
sealed class ApiResult<out T> {
    data class Success<out T>(val data: T) : ApiResult<T>()
    data class Failure(val error: Throwable) : ApiResult<Nothing>()
    
    inline fun <R> fold(
        onSuccess: (T) -> R,
        onFailure: (Throwable) -> R
    ): R = when (this) {
        is Success -> onSuccess(data)
        is Failure -> onFailure(error)
    }
}

/**
 * HTTP Client using PayU SDK's PayuUtils
 * Uses PayuUtils.getHttpsConn() and PayuUtils.getStringBuilder() for network calls
 */
class HttpClient(private val isProduction: Boolean) {
    
    private val BASE_URL = "https://compulsiveuat.payu.in/"
    private val BASE_URL_PROD = "https://compulsive.payu.in/"
    // Thread pool for async operations
    private val executor: ExecutorService = Executors.newCachedThreadPool()
    
    /**
     * POST request to validate-request API
     * Based on actual API structure: encrequestparameter, reqdigitalsignature, merchIdVal
     */
    fun validateRequest(
        encrequestparameter: String,
        reqdigitalsignature: String,
        merchIdVal: String,
        callback: (result: ApiResult<JSONObject>) -> Unit
    ) {
        val requestJson = createBharatKoshJsonManually(
            encRequestParam = encrequestparameter,
            reqDigitalSignature = reqdigitalsignature,
            merchIdVal = merchIdVal
        )
        validateRequestInternal(requestJson, callback)
    }

    /**
     * Internal method to make validate-request API call with JSON string
     */
    private fun validateRequestInternal(
        requestJsonString: String,
        callback: (result: ApiResult<JSONObject>) -> Unit
    ) {
        makeHttpRequest(
            endpoint = "api/bharatkosh/validate-request",
            requestBody = requestJsonString,
            callback = callback,
            logTag = "validateRequest"
        )
    }
    
    /**
     * Common method to make HTTP POST requests
     * Extracted to eliminate code duplication
     */
    private fun makeHttpRequest(
        endpoint: String,
        requestBody: String,
        callback: (result: ApiResult<JSONObject>) -> Unit,
        logTag: String
    ) {
        executor.execute {
            var connection: HttpsURLConnection? = null
            try {
                var baseURL = BASE_URL
                if (isProduction) {
                    baseURL = BASE_URL_PROD
                }
                val url = "${baseURL}$endpoint"
                connection = PayuUtils.getHttpsConn(url, requestBody, PayuConstants.REQUEST_APPLICATION_JSON)

                if (connection == null) {
                    Log.e("BharatKosh", "Failed to create connection for $logTag")
                    callback(ApiResult.Failure(Exception("Failed to create connection")))
                    return@execute
                }

                val responseCode = connection.responseCode
                Log.d("BharatKosh", "$logTag - Response Code: $responseCode")

                val responseBuilder = PayuUtils.getStringBuilder(connection, true)
                val responseBody = responseBuilder.toString()
                Log.d("HttpClient", "$logTag - Response Body: $responseBody")

                handleHttpResponse(responseCode, responseBody, callback, logTag)
            } catch (e: Exception) {
                Log.e("HttpClient", "Exception in $logTag", e)
                callback(ApiResult.Failure(e))
            } finally {
                closeConnection(connection, logTag)
            }
        }
    }
    
    /**
     * Handle HTTP response and parse JSON
     */
    private fun handleHttpResponse(
        responseCode: Int,
        responseBody: String,
        callback: (result: ApiResult<JSONObject>) -> Unit,
        logTag: String
    ) {
        if (isSuccessResponse(responseCode, responseBody)) {
            parseJsonResponse(responseBody, callback, logTag)
        } else {
            callback(ApiResult.Failure(
                Exception("HTTP Error: $responseCode\nResponse: $responseBody")
            ))
        }
    }
    
    /**
     * Check if response is successful
     */
    private fun isSuccessResponse(responseCode: Int, responseBody: String): Boolean {
        return responseCode >= 200 && responseCode < 300 && responseBody.isNotEmpty()
    }
    
    /**
     * Parse JSON response
     */
    private fun parseJsonResponse(
        responseBody: String,
        callback: (result: ApiResult<JSONObject>) -> Unit,
        logTag: String
    ) {
        try {
            val json = JSONObject(responseBody)
            callback(ApiResult.Success(json))
        } catch (e: Exception) {
            Log.e("HttpClient", "Failed to parse response in $logTag: ${e.message}", e)
            callback(ApiResult.Failure(
                Exception("Failed to parse response: ${e.message}\nResponse: $responseBody")
            ))
        }
    }
    
    /**
     * Close HTTP connection safely
     */
    private fun closeConnection(connection: HttpsURLConnection?, logTag: String) {
        try {
            connection?.disconnect()
        } catch (e: Exception) {
            Log.e("HttpClient", "Error closing connection in $logTag: ${e.message}", e)
        }
    }

    /**
     * Creates JSON string manually without using JSONObject
     * Escapes special characters in JSON string values
     */
    private fun createBharatKoshJsonManually(
        encRequestParam: String,
        reqDigitalSignature: String,
        merchIdVal: String
    ): String {
        // Escape JSON special characters in string values
        val escapedEncRequest = escapeJsonString(encRequestParam)
        val escapedSignature = escapeJsonString(reqDigitalSignature)
        val escapedMerchId = escapeJsonString(merchIdVal)
        
        // Build JSON string manually
        val jsonBuilder = StringBuilder()
        jsonBuilder.append("{")
        jsonBuilder.append("\"encrequestparameter\":\"").append(escapedEncRequest).append("\",")
        jsonBuilder.append("\"reqdigitalsignature\":\"").append(escapedSignature).append("\",")
        jsonBuilder.append("\"merchIdVal\":\"").append(escapedMerchId).append("\"")
        jsonBuilder.append("}")
        
        return jsonBuilder.toString()
    }
    
    /**
     * Escapes special characters in JSON string values
     * Escapes: backslash, double quote, newline, carriage return, tab, etc.
     */
    private fun escapeJsonString(value: String): String {
        val sb = StringBuilder()
        for (char in value) {
            when (char) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> {
                    // Escape control characters (0x00-0x1F)
                    if (char.code < 0x20) {
                        sb.append(String.format("\\u%04x", char.code))
                    } else {
                        sb.append(char)
                    }
                }
            }
        }
        return sb.toString()
    }
    
    /**
     * POST request to validate-response API
     */
    fun validateResponse(
        responseJson: JSONObject,
        callback: (result: ApiResult<JSONObject>) -> Unit
    ) {
        makeHttpRequest(
            endpoint = "api/bharatkosh/validate-response",
            requestBody = responseJson.toString(),
            callback = callback,
            logTag = "validateResponse"
        )
    }
    
    /**
     * POST request to generate-hash API
     */
    fun generateHash(
        hashJson: HashMap<String, String?>,
        callback: (result: ApiResult<JSONObject>) -> Unit
    ) {
        val jsonBody = createHashRequestJson(hashJson)
        makeHttpRequest(
            endpoint = "api/bharatkosh/generate-hash",
            requestBody = jsonBody.toString(),
            callback = callback,
            logTag = "generateHash"
        )
    }
    
    /**
     * Create JSON body for hash generation request
     */
    private fun createHashRequestJson(hashJson: HashMap<String, String?>): JSONObject {
        return JSONObject().apply {
            put("hashName", hashJson["hashName"])
            put("hashString", hashJson["hashString"])
            put("key", hashJson["key"])
            hashJson["postSalt"]?.let { put("postSalt", it) }
        }
    }
}
