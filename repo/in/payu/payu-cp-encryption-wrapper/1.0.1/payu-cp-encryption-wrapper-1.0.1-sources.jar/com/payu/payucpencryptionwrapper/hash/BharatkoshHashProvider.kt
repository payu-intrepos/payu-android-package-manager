package com.payu.payucpencryptionwrapper.hash

import com.payu.payucpencryptionwrapper.checkoutpro.CheckoutProCallback
import com.payu.payucpencryptionwrapper.data.api.HttpClient
import com.payu.payucpencryptionwrapper.util.PayUHelper
import com.payu.ui.model.listeners.PayUHashGenerationListener
import org.json.JSONObject

/**
 * Hash Provider implementation for CheckoutPro SDK
 * Handles hash generation for CheckoutPro SDK requests
 * Uses callback-based approach (no coroutines dependency)
 */
class BharatkoshHashProvider(
    private val paymentHash: String? = null,
    private val key: String,
    private val client: HttpClient?
) {
    @Volatile
    private var currentCallback: CheckoutProCallback? = null
    /**
     * Get hash value for a given hash name
     * For payment hash, returns the stored paymentHash via callback
     * For other hashes, calls the generate-hash API
     */
    fun getHash(
        hashJson: HashMap<String, String?>,
        hashGenerationListener: PayUHashGenerationListener,
        currentCallback: CheckoutProCallback? = null
    ) {
        this.currentCallback = currentCallback
        val hashName = hashJson["hashName"]
        // If it's payment hash, return the stored paymentHash
        if (hashName.equals("payment_source", ignoreCase = true) && paymentHash != null) {
            val map = hashMapOf<String, String?>(
                "payment_source" to paymentHash,
            )
            hashGenerationListener.onHashGenerated(map)
            return
        }
        
        // Create a copy to avoid mutating the input map
        val hashJsonCopy = HashMap(hashJson)
        hashJsonCopy["key"] = key
        
        // For other hashes, call the generate-hash API
        client?.generateHash(
            hashJson = hashJsonCopy
        ) { result ->
            result.fold(
                onSuccess = { json -> handleHashGenerationSuccess(json, hashGenerationListener) },
                onFailure = { error -> handleHashGenerationFailure(error) }
            )
        }
    }
    
    /**
     * Handle successful hash generation response
     */
    private fun handleHashGenerationSuccess(
        json: JSONObject,
        hashGenerationListener: PayUHashGenerationListener
    ) {
        val dataJson = json.optJSONObject("data") ?: run {
            currentCallback?.onError("Unable to fetch valid hash: missing data in response")
            return
        }
        
        val hashDataMap = PayUHelper.jsonObjectToHashMap(dataJson)
        val hashName = hashDataMap["hashName"]?.toString()
        val hashString = hashDataMap["hashString"]?.toString()
        
        if (hashName != null && hashString != null) {
            val map = hashMapOf<String, String?>(hashName to hashString)
            hashGenerationListener.onHashGenerated(map)
        } else {
            currentCallback?.onError("Unable to fetch valid hash: missing hashName or hashString")
        }
    }
    
    /**
     * Handle hash generation failure
     */
    private fun handleHashGenerationFailure(error: Throwable) {
        android.util.Log.e("BharatkoshHashProvider", "Failed to generate hash", error)
        currentCallback?.onError("Unable to fetch valid hash")
    }
}
