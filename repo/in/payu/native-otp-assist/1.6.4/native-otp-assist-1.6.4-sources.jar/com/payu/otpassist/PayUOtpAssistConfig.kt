package com.payu.otpassist

import android.graphics.drawable.Drawable
import androidx.annotation.ColorRes


class PayUOtpAssistConfig {
    var shouldAllowAutoSubmit: Boolean = true
    var webInterface: Any? = null
    var postData: String? = null
    var waitingTime: Long? = 30000
    var merchantResponseTimeout: Long? = 15000
    var merchantLogo: Drawable? = null
    var shouldVibrateAfterPaymentSuccess = true
    var paymentUrl = ""
    var shouldShowMerchantSummary: Boolean = true
    var shouldShowSecureWebView: Boolean = false
    var isSdkLessFlow: Boolean = false
    var isProduction: Boolean = true
    var isProtectedScreen: Boolean = true

    @ColorRes
    var primaryColor: Int? = null
}