package com.payu.otpassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.payu.otpassist.apis.CheckSecureTxnStatusApiManager

class CheckTxnStatusForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "CheckTxnStatusChannel"
        private const val NOTIFICATION_ID = 1
        const val ACTION_START_API_CALL = "com.payu.otpassist.START_API_CALL"
        const val ACTION_STOP_SERVICE = "com.payu.otpassist.STOP_SERVICE"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_API_CALL -> {
                startForeground(NOTIFICATION_ID, createNotification())
                // Call API directly in foreground service (not in background thread)
                try {
                    CheckSecureTxnStatusApiManager.callApi()
                } catch (e: Exception) {
                    android.util.Log.e("chekTxnApi", " chekTxnApi Error calling API: ${e.message}")
                }
                // Keep service running - don't stop immediately as API call starts a timer
                // Service will be stopped when Chrome Custom Tab closes or manually stopped
            }
            ACTION_STOP_SERVICE -> {
                stopForeground(true)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Transaction Status Check",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Checking transaction status"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, PayUOtpAssistActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.payu_processing_your_payment))
            .setContentText(getString(R.string.payu_please_wait))
            .setSmallIcon(R.drawable.payu_otp_pay_u_logo)
            .setContentIntent(pendingIntent)
            .setOngoing(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}

