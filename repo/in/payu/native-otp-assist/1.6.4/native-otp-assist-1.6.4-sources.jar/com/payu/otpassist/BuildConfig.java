/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.otpassist;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.otpassist";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_CODE = "35";
  // Field from default config.
  public static final String VERSION_NAME = "1.6.4";
}
