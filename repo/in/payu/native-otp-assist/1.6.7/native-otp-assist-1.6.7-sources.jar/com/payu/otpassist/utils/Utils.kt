package com.payu.otpassist.utils

import android.os.Bundle
import android.text.TextUtils
import android.util.Base64
import com.payu.otpassist.BuildConfig
import com.payu.otpassist.models.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

object Utils {

    fun getDataFromPostData(postData: String?): HashMap<String?, String?> {
        val postParamsMap =
            HashMap<String?, String?>()
        if (null != postData) {
            val tokens = StringTokenizer(postData, "&")
            while (tokens.hasMoreTokens()) {
                val keyValue: Array<String?> =
                    tokens.nextToken().split("=").toTypedArray()
                if (keyValue.isNotEmpty() && null != keyValue[0]) {
                    postParamsMap[keyValue[0]] = if (keyValue.size > 1) keyValue[1] else ""
                }
            }
        }
        return postParamsMap
    }

    fun isBackendError(response: String): Boolean {
        try {
            val jsonResponse = JSONObject(response)
            if (jsonResponse.has(Constants.GATEWAY_TIMEOUT_ERROR_MESSAGE))
                return true
        } catch (e: JSONException) {
            return true
        }

        return false
    }

    fun getInitiatePaymentModel(response: String): PayUInitiatePaymentResponse {
        val payUInitiatePaymentResponse = PayUInitiatePaymentResponse()

        val jsonResponse = JSONObject(response)

        if (jsonResponse.has(Constants.META_DATA)) {
            val metaDataJson = jsonResponse.optJSONObject(Constants.META_DATA)
            val metaData = MetaData()
            metaData.message = metaDataJson?.optString(Constants.MESSAGE)
            metaData.referenceId = metaDataJson?.optString(Constants.REFERENCE_ID)
            metaData.txnId = metaDataJson?.optString(Constants.TXNID)
            metaData.txnStatus = metaDataJson?.optString(Constants.TXN_STATUS)
            metaData.unmappedStatus = metaDataJson?.optString(Constants.UNMAPPED_STATUS)
            payUInitiatePaymentResponse.metaData = metaData
        }
        if (payUInitiatePaymentResponse.metaData?.unmappedStatus != Constants.FAILURE) {
            if (jsonResponse.has(Constants.BIN_DATA)) {

                val binData = BinData()
                val binDataJson = jsonResponse.optJSONObject(Constants.BIN_DATA)
                if (binDataJson != null) {
                    binData.pureS2SSupported = binDataJson.optBoolean(Constants.PURE_S2S_SUPPORTED)
                    binData.issuingBank = binDataJson.optString(Constants.ISSUING_BANK)
                    binData.category = binDataJson.optString(Constants.CATEGORY)
                    binData.cardType = binDataJson.optString(Constants.CARD_TYPE)
                    binData.isDomestic = binDataJson.optBoolean(Constants.IS_DOMESTIC)
                    payUInitiatePaymentResponse.binData = binData
                }
            } else if (payUInitiatePaymentResponse.metaData?.unmappedStatus == Constants.PENDING
                || payUInitiatePaymentResponse.metaData?.unmappedStatus != Constants.FAILED
            ) {
                payUInitiatePaymentResponse.binData = BinData()
            }
        }
        if (jsonResponse.has(Constants.RESULT)) {
            val resultJson = jsonResponse.optJSONObject(Constants.RESULT)
            val result = Result()
            if (null != resultJson) {
                result.otpPostUrl = resultJson.optString(Constants.OTP_POST_URL)
                result.issuerUrl = resultJson.optString(Constants.ISSUER_URL)
                result.acsTemplate = resultJson.optString(Constants.ACS_TEMPLATE)
                if (resultJson.has(Constants.POST_TO_BANK)) {
                    val postToBankJson = resultJson.optJSONObject(Constants.POST_TO_BANK)
                    val postToBank = PostToBank()
                    postToBank.MD = postToBankJson?.optString(Constants.MD)
                    postToBank.PaReq = postToBankJson?.optString(Constants.PAREQ)
                    postToBank.TermUrl = postToBankJson?.optString(Constants.TERM_URL)
                    result.postToBank = postToBank
                }
                payUInitiatePaymentResponse.result = result
            }
        }
        if (jsonResponse.has(Constants.PAYU_REDIRECT_URL)) {
            val redirectUrl = jsonResponse.getString(Constants.PAYU_REDIRECT_URL)
            val redirectType = jsonResponse.optString(Constants.PAYU_REDIRECT_TYPE)
            val sdkLessResponse = SdkLessResponse(redirectUrl, redirectType)
            payUInitiatePaymentResponse.sdkLessResponse = sdkLessResponse
        }
        return payUInitiatePaymentResponse
    }

    /**
     * Submit Otp Response
     * @param response, Json Response to create submit otp response bean.
     * @return [SubmitOtpResponse]
     */
    fun getSubmitOtpResponse(response: String): SubmitOtpResponse {
        val jsonResponse = JSONObject(response)
        var metaData: MetaData1? = null
        if (jsonResponse.has(Constants.META_DATA)) {
            var submitOtp: SubmitOtp? = null

            val metaDataJson = jsonResponse.optJSONObject(Constants.META_DATA)
            if (metaDataJson != null && metaDataJson.has(Constants.SUBMIT_OTP_WITHOUT_UNDERSCORE)) {
                val submitOtpWithoutUnderScore =
                    metaDataJson.getJSONObject(Constants.SUBMIT_OTP_WITHOUT_UNDERSCORE)
                //in case of BNPL we get retryAttemptCount key to check how many attempts left
                submitOtp =
                    if (submitOtpWithoutUnderScore.has(Constants.RETRY_ATTEMPT_COUNT)
                    ) {
                        val status = submitOtpWithoutUnderScore.optString(Constants.STATUS)
                        SubmitOtp(
                            if (status == Constants.IN_PROGRESS) Constants.FAILED else status,
                            submitOtpWithoutUnderScore.optInt(Constants.RETRY_ATTEMPT_COUNT)
                        )
                    } else {
                        val submitOtpWithoutUnderScoreOpted =
                            metaDataJson.optJSONObject(Constants.SUBMIT_OTP_WITHOUT_UNDERSCORE)
                        //in case of Card we get attemptsLeft key to check how many attempts left
                        SubmitOtp(
                            submitOtpWithoutUnderScoreOpted?.optString(Constants.STATUS),
                            submitOtpWithoutUnderScoreOpted?.optInt(Constants.ATTEMPTS_LEFT)
                        )
                    }
            }

            metaData = MetaData1(
                metaDataJson?.optString(Constants.MESSAGE),
                metaDataJson?.optString(Constants.REFERENCE_ID),
                metaDataJson?.optString(Constants.STATUS_CODE),
                submitOtp,
                metaDataJson?.optString(Constants.TXNID),
                metaDataJson?.optString(Constants.UNMAPPED_STATUS)
            )

        }

        return SubmitOtpResponse(metaData)
    }

    fun getResendOtpResponse(response: String): ResendOtpResponse {
        val jsonResponse = JSONObject(response)
        var metaData: MetaData2? = null
        if (jsonResponse.has(Constants.META_DATA)) {
            var resendOtp: ResendOtp? = null
            val metaDataJson = jsonResponse.optJSONObject(Constants.META_DATA)
            val resendOtpWithoutUnderscoreOpted =
                metaDataJson?.optJSONObject(Constants.RESEND_OTP_WITHOUT_UNDERSCORE)
            val submitOtpWithoutUnderscoreOpted =
                metaDataJson?.optJSONObject(Constants.SUBMIT_OTP_WITHOUT_UNDERSCORE)
            if (resendOtpWithoutUnderscoreOpted != null &&
                resendOtpWithoutUnderscoreOpted.has(Constants.ATTEMPTS_LEFT)
            ) {
                resendOtp = ResendOtp(
                    resendOtpWithoutUnderscoreOpted.optString(Constants.STATUS),
                    resendOtpWithoutUnderscoreOpted.optInt(Constants.ATTEMPTS_LEFT)
                )
            } else if (submitOtpWithoutUnderscoreOpted != null &&
                submitOtpWithoutUnderscoreOpted.has(Constants.RETRY_ATTEMPT_COUNT)
            ) {
                val status = submitOtpWithoutUnderscoreOpted.optString(Constants.STATUS)
                resendOtp = ResendOtp(
                    if (status == Constants.IN_PROGRESS) Constants.FAILED else status,
                    submitOtpWithoutUnderscoreOpted.optInt(Constants.RETRY_ATTEMPT_COUNT)
                )
            }
            metaData = MetaData2(
                metaDataJson?.optString(Constants.MESSAGE),
                metaDataJson?.optString(Constants.REFERENCE_ID),
                metaDataJson?.optString(Constants.STATUS_CODE),
                resendOtp,
                metaDataJson?.optString(Constants.TXNID),
                metaDataJson?.optString(Constants.UNMAPPED_STATUS)
            )
        }
        return ResendOtpResponse(metaData)
    }

    fun getAnalyticsAddedPostData(postData: String?): String {
        val jsonArray: JSONArray?
        var jsonArrayValue = ""
        val hashMap = getDataFromPostData(postData)
        if (hashMap.containsKey(Constants.SDK_PLATFORM_KEY)) {
            jsonArrayValue = hashMap[Constants.SDK_PLATFORM_KEY]!!
        }
        try {
            jsonArray = if (!TextUtils.isEmpty(jsonArrayValue)) {
                JSONArray(jsonArrayValue)
            } else {
                JSONArray()
            }
            val platformJson = JSONObject()
            platformJson.put(Constants.PLATFORM_KEY, Constants.PLATFORM_VALUE)
            platformJson.put(Constants.NAME_KEY, Constants.NAME_VALUE)
            platformJson.put(Constants.VERSION_KEY, BuildConfig.VERSION_NAME)
            jsonArray.put(platformJson)
        } catch (e: JSONException) {
            return convertHashMapToPostData(hashMap)
        }
        hashMap[Constants.SDK_PLATFORM_KEY] = jsonArray.toString()
        return convertHashMapToPostData(hashMap)
    }

    fun convertHashMapToPostData(hashMap: HashMap<String?, String?>): String {
        val stringBuilder = StringBuilder()
        if (hashMap.size > 0) {
            for (key in hashMap.keys) {
                stringBuilder.append(key)
                stringBuilder.append("=")
                stringBuilder.append(hashMap[key])
                stringBuilder.append("&")
            }
            return stringBuilder.toString().substring(0, stringBuilder.lastIndexOf("&"))
        }
        return ""
    }

    /**
     * @param color color, without alpha
     * @param alpha         from 0.0 to 1.0
     * @return
     */
    fun addAlpha(color: String, alpha: Double): String {
        var originalColor = color
        val alphaFixed = (alpha * 255).roundToInt().toLong()
        var alphaHex = java.lang.Long.toHexString(alphaFixed)
        if (alphaHex.length == 1) {
            alphaHex = "0$alphaHex"
        }
        originalColor = originalColor.replace("#", "#$alphaHex")
        return originalColor
    }

    fun createBundleForParserAnalytics(hashMap: HashMap<String?, String?>?): Bundle {
        val bundle = Bundle()
        bundle.putString(Constants.MERCHANT_KEY, hashMap?.get(Constants.KEY).toString())
        bundle.putString(Constants.TXNID, hashMap?.get(Constants.TXNID).toString())
        return bundle
    }

    fun concatParams(key: String, value: String): String {
        return "$key=$value&"
    }

    fun trimAmpersand(data: String): String {
        return if ((data.length) >= 1 && data[data.length - 1] == '&') data.substring(
            0,
            data.length - 1
        ) else data
    }

    fun extractUrlFromAcsTemplate(base64String: String): String {
        val input = UiUtils.getBase64DecodedString(base64String)

        val result = input?.split("action=\"")  ?: listOf()
        return if (result.size > 1) {
            result[1].split("\"")[0]
        } else {
            ""
        }
    }

    fun prepareUrl(environment: Boolean, baseUrl: BaseUrl, urlType: UrlType): String {

        var url = ""
        if (environment) {
            url += when (baseUrl) {
                BaseUrl.SECURE -> Constants.PROD_BASE_SECURE_URL
                else -> Constants.PROD_BASE_INFO_URL
            }
        } else {
            url += when (baseUrl) {
                BaseUrl.SECURE -> Constants.TEST_BASE_SECURE_URL
                else -> Constants.TEST_BASE_INFO_URL
            }
        }

        url += when (urlType) {
            UrlType.CHECK_SECURE_TXN -> Constants.CHECK_SECURE_TXN_PATH
            UrlType.PAYMENT_URL -> Constants.PAYMENT_URL_PATH
        }

        return url
    }

    fun getDate() : String {
        val myDate = Date()
        val calendar = Calendar.getInstance()
        calendar.timeZone = TimeZone.getTimeZone("UTC")
        calendar.time = myDate
        calendar.add(Calendar.MINUTE, -330)
        val time = calendar.time
        val outputFmt = SimpleDateFormat(Constants.V2_API_TIME_FORMATE)
        return outputFmt.format(time)
    }
}