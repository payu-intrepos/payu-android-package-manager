package com.payu.otpassist.models

class CheckTxnStatusModel {
    var status: Int? = null
    var msg: String? = null
    var result: String? = null
}