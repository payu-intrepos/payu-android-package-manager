package com.payu.otpassist.network


import android.os.Handler
import android.os.Looper
import com.payu.otpassist.BuildConfig
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.utils.Utils
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import java.io.IOException
import java.net.SocketException
import java.util.concurrent.TimeUnit

/**x
 * Utility class which manages all network releated operations.
 * @param _pinner : To be passed in case network handler instance requires SSL Pinning.
 * Can be [null] also if no SSL Pinning is required.
 */
class PayUNetworkHandler {

    fun executeApi(payUNetworkData: PayUNetworkData, payUAsyncTaskResponse: PayUAsyncTaskResponse) {

        networkCall(payUNetworkData, payUAsyncTaskResponse)
    }

    private var call: Call? = null
    private fun networkCall(
        payUNetworkData: PayUNetworkData,
        payUAsyncTaskResponse: PayUAsyncTaskResponse
    ) {

        val okHttpClientBuilder: OkHttpClient.Builder? = OkHttpClient.Builder()
        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor()
            logging.setLevel(HttpLoggingInterceptor.Level.BODY)
            okHttpClientBuilder?.addInterceptor(logging)
        }

        okHttpClientBuilder?.callTimeout(payUNetworkData.timeOut, TimeUnit.SECONDS)

        val client = okHttpClientBuilder?.build()
        UiUtils.longLog("API networkCall")
        val mediaType: MediaType? = payUNetworkData.contentType.toMediaType()
        val body: RequestBody = payUNetworkData.request.toRequestBody(mediaType)
        val request: Request.Builder = Request.Builder()

        request.addHeader("Accept", "application/json")
            .url(payUNetworkData.url)

        payUNetworkData.headers.forEach { entry ->
            request.addHeader(entry.key, entry.value)
        }

        if (payUNetworkData.cookiesList.isNotEmpty())
            request.addHeader("Cookie", payUNetworkData.cookiesList)


        if (payUNetworkData.requestType == "POST") {
            request.post(body)
        } else if (payUNetworkData.requestType == "PUT") {
            request.put(body)
        }
        call = client?.newCall(request.build())
        call?.enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                if (e is SocketException)
                    UiUtils.longLog("fail >>>>>>>>>>>>>>>>>>>>>>>>>>>>" + e.printStackTrace())
                val handler = Handler(Looper.getMainLooper())
                val runnable = Runnable {
                    val json = JSONObject()
                    json.put(Constants.OTP_ASSIST_NETWORK_ERROR, "Network timeout")
                    payUAsyncTaskResponse.onPayUAsyncTaskResponse(
                        payUNetworkData.type,
                        json.toString(),
                        null,
                        0
                    )
                }
                handler.post(runnable)
            }

            override fun onResponse(call: Call, response: Response) {
                val respo = response.body?.string()
                val handler = Handler(Looper.getMainLooper())
                val runnable = Runnable {
                    if (response.code == Constants.GATEWAY_TIMEOUT) {
                        val jsonResponse = JSONObject()
                        jsonResponse.put(Constants.GATEWAY_TIMEOUT_ERROR_MESSAGE, "Gateway timeout")
                        payUAsyncTaskResponse.onPayUAsyncTaskResponse(
                            payUNetworkData.type,
                            jsonResponse.toString(),
                            response.headers,
                            response.code
                        )
                    } else {

                        payUAsyncTaskResponse.onPayUAsyncTaskResponse(
                            payUNetworkData.type,
                            if (respo.isNullOrEmpty()) "" else respo,
                            response.headers,
                            response.code
                        )
                    }
                }
                handler.post(runnable)

            }
        })
    }

    fun cancel() {
        call?.cancel()
    }
    /* private fun networkCall(
         payUNetworkData: PayUNetworkData,
         payUAsyncTaskResponse: PayUAsyncTaskResponse
     ) {
         executorService.execute {
             val ignoredResponse = makeSynchronousLoginRequest(url, jsonBody)


         }


     }*/
}
