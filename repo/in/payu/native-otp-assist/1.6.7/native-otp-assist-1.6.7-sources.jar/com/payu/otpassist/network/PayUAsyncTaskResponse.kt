package com.payu.otpassist.network

import okhttp3.Headers

interface PayUAsyncTaskResponse {
    fun onPayUAsyncTaskResponse(
        requestType: String,
        response: String,
        headers: Headers?,
        responseCode: Int
    )
}