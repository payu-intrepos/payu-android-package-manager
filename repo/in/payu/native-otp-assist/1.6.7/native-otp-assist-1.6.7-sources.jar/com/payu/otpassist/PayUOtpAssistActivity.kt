package com.payu.otpassist

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.payu.otpassist.javascriptinterface.PayUOtpAssistWebInterface
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.viewmodel.PayUOtpAssistViewModel
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics


class PayUOtpAssistActivity : AppCompatActivity() {
    private var otpAssistWebView: WebView? = null
    private var viewModel: PayUOtpAssistViewModel? = null
    private var bottomSheet: PayUOtpAssistDialogFragment? = null
    private var isWebFlow = false
    private var payUAnalytics: PayUAnalytics? = null
    private var alertDialog: AlertDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_u_otp_assist)
        if (null != intent && null != intent?.extras && null != intent?.extras?.get(Constants.POST_DATA)) {
            payUAnalytics =
                AnalyticsFactory(applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
//                PayUAnalytics.getInstance(applicationContext, "local_cache_analytics")
            viewModel = PayUOtpAssistViewModel(this.application, payUAnalytics!!)
            viewModel?.startPayment(intent?.extras?.getString(Constants.POST_DATA)!!)
            addObserver()
            bottomSheet =
                PayUOtpAssistDialogFragment.newInstance(viewModel!!)
            bottomSheet?.isCancelable = false
            bottomSheet?.show(
                supportFragmentManager,
                "OtpAssistBottomSheet"
            )
        }
        UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
        UiUtils.updateLayoutSecurity(
            this,
            PayUOtpAssistCurrentState.payUOtpAssistConfig?.isProtectedScreen ?: false
        )

        setCollectWebViewSettings()

    }

    @SuppressLint("JavascriptInterface")
    private fun setCollectWebViewSettings() {
        otpAssistWebView = findViewById(R.id.otpAssistWebView)
        if (otpAssistWebView != null) {
            otpAssistWebView?.settings?.javaScriptEnabled = true
            if (null != PayUOtpAssistCurrentState?.payUOtpAssistConfig && null != PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface) {
                val customWebInterface: Any?
                if (PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface is PayUOtpAssistWebInterface) {
                    customWebInterface =
                        PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface as PayUOtpAssistWebInterface
                    customWebInterface.setActivity(this)
                } else {
                    customWebInterface =
                        PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface
                }
                otpAssistWebView?.addJavascriptInterface(
                    customWebInterface!!,
                    "PayU"
                )

            } else {
                val payUOtpAssistWebInterface = PayUOtpAssistWebInterface()
                payUOtpAssistWebInterface.setViewModel(viewModel)
                payUOtpAssistWebInterface.setActivity(this)
                otpAssistWebView?.addJavascriptInterface(
                    payUOtpAssistWebInterface,
                    "PayU"
                )
            }
            otpAssistWebView?.visibility = View.GONE
            otpAssistWebView?.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
                }
            }
        }
    }

    private var postDataForIssuer: String? = null
    private fun addObserver() {


        viewModel?.postDataForIssuerUrl?.observe(this, Observer {
            postDataForIssuer = it
        })

        viewModel?.issuerUrlLoad?.observe(this, Observer {
            isWebFlow = true
//            toggleKeyboard()
            makeActivityOpaqueFor3ds()
            postUrlWebView(it)
        })

        viewModel?.acsTemplateToLoad?.observe(this, Observer {
            isWebFlow = true
//            toggleKeyboard()
            makeActivityOpaqueFor3ds()
            postDataToWebView(it)
        })

        viewModel?.errorResponse?.observe(this, Observer {
            viewModel?.onError(
                Constants.UN_EXPECTED_RESPONSE_ERROR_CODE,
                it,
                Constants.ERROR_REPONSE_VIEW_MODEL
            )

        })


        viewModel?.shouldCloseBottomSheet?.observe(this, Observer {
            if (it) {
                UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
                bottomSheet?.dismiss()
            }

        })

        viewModel?.shouldFinishActivity?.observe(this, Observer {
            if (it) {
                UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
                bottomSheet?.dismiss()
                finish()
            }

        })


    }


    private fun postUrlWebView(url: String) {

        if (otpAssistWebView != null) {
            otpAssistWebView?.visibility = View.VISIBLE
//            otpAssistWebView?.loadUrl("https://w3schools.com")
            otpAssistWebView?.postUrl(url, postDataForIssuer?.toByteArray()!!)
        }
    }

    private fun postDataToWebView(acsTemplate: String) {

        if (otpAssistWebView != null) {
            otpAssistWebView?.visibility = View.VISIBLE
            otpAssistWebView?.loadData(acsTemplate, "text/html; charset=utf-8", "UTF-8")
//            otpAssistWebView?.loadUrl("https://w3schools.com")
        }
    }

    private fun makeActivityOpaqueFor3ds() {
        window.setLayout(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT)
        setTheme(R.style.PayU_Otp_Assist_Opaque_Screen)

    }

    override fun onBackPressed() {
        if (isWebFlow)
            confirmationDialog()
        else {
            UiUtils.hideKeyboard(this@PayUOtpAssistActivity)
            PayUOtpAssistDialogFragment.getPayUOtpAssistViewModel()?.onCloseBottomSheet()
        }
    }

    private fun confirmationDialog() {
        val onClickListener: DialogInterface.OnClickListener =
            DialogInterface.OnClickListener { dialogInterface, i ->
                if (i == -1) {
                    viewModel?.cancelTransactionPayTxn()
                } else if (i == -2) {
                    dialogInterface.dismiss()

                }
            }
        if (!isFinishing && !isDestroyed) {
            val builder = UiUtils.getAlertDialog(
                this@PayUOtpAssistActivity,
                onClickListener,
                getString(R.string.payu_yes),
                getString(R.string.payu_no),
                null,
                getString(R.string.payu_do_you_really_want_to_cancel_the_payment)
            )

            alertDialog = builder?.create()
            alertDialog?.show()

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        for (fragment in supportFragmentManager.fragments) {
            if (null != fragment && fragment is PayUOtpAssistDialogFragment) {
                fragment.onActivityResult(requestCode, resultCode, data)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        for (fragment in supportFragmentManager.fragments) {
            if (null != fragment && fragment is PayUOtpAssistDialogFragment) {
                fragment.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        UiUtils.updateLayoutSecurity(this, false)
    }

}