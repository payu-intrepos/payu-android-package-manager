package com.payu.otpassist.utils

object Constants {
    const val AMOUNT = "amount"
    const val CCNUM = "ccnum"
    const val ENROLLED = "Enrolled"
    const val APPLICATION_JSON = "application/json"
    const val APPLICATION_FORM_URL_ENCODED = "application/x-www-form-urlencoded"
    const val INITATE_PAYMENT_RESPONSE = "initiate_payment_response"
    const val SUBMIT_OTP = "submit_otp"
    const val RESEND_OTP = "resend_otp"
    const val POST_DATA = "post_data"
    const val BIN_DATA = "binData"
    const val PURE_S2S_SUPPORTED = "pureS2SSupported"
    const val RESULT = "result"
    const val OTP_POST_URL = "otpPostUrl"
    const val META_DATA = "metaData"
    const val REFERENCE_ID = "referenceId"
    const val PAYU_PAYTXN = "paytxn"
    const val USER_CANCEL_TRANSACTION = "userCancelTransaction"
    const val CANCEL_TRANSACTION = "cancelTransaction"
    const val POSTDATA_MISSING = "Postdata mandatory param missing."

    const val PACKAGE_NAME = "package_name"
    const val MERCHANT_KEY = "merchant_key"
    const val SDK_VERSION_NAME = "otp_assist_sdk_version"
    const val DEVICE_MANUFACTURE = "device_manufacturer"
    const val DEVICE_MODEL = "device_model"
    const val DEVICE_OS_VERSION = "os_version"
    const val TXNID = "txnid"
    const val KEY = "key"
    var EVENT_KEY = "event_key"
    var VALUE = "event_value"
    var TIMESTAMP = "ts"
    var VERSION_CODE = "application_version"
    var PAYMENT_OPTION = "otp_payment_option"
    var OTP_EVENT = "otp_event"
    var NATIVE_FLOW = "native_flow"
    var OTP_SUBMIT_MANUALLY = "otp_submit_manually"
    var OTP_SUBMIT_AUTO = "otp_submit_auto"
    var OTP_RESEND = "otp_resend"
    var OTP_FETCHED = "otp_fetched"
    var WEB_FLOW_THROUGH_ISSUER_URL = "web_flow_through_issuer_url"
    var WEB_FLOW_THROUGH_ACS_TEMPLATE = "web_flow_through_acs_template"
    var OTP_ASSIST_SHOULD_HANDLE_FALLBACK = "should_handle_fallback"
    var CREDIT_CARD = "creditcard"
    var DEBIT_CARD = "debitcard"
    const val SOMETHING_WENT_WRONG_ERROR_CODE = "1000"
    const val SOMETHING_WENT_WRONG_ERROR = "Something went wong."
    const val NO_INTERNET_ERROR_CODE = "1001"
    const val NETWORK_TIMEOUT_ERROR_CODE = "1002"
    const val GATEWAY_TIMEOUT_ERROR_CODE = "1003"
    const val CANCEL_TRANSACTION_ERROR_CODE = "1004"
    const val UN_EXPECTED_RESPONSE_ERROR_CODE = "1005"
    const val BANK_PAGE_TIME_OUT_ERROR_CODE = "1006"
    const val NETWORK_TIMEOUT_ERROR_MESSAGE = "Network timeout, please verify with your server."
    const val GATEWAY_TIMEOUT_ERROR_MESSAGE = "Gateway timeout, please verify with your server."
    const val CANCEL_TRANSACTION_ERROR_MESSAGE =
        "User cancelled it, please verify with your server."
    const val BANK_PAGE_TIME_OUT_ERROR_MESSAGE =
        "Bank page timed out, please verify with your server."
    const val UN_EXPECTED_RESPONSE_ERROR_MESSAGE =
        "Something went wrong , please verify with your server."
    const val NO_INTERNET_ERROR = "No Internet"
    const val SDK_PLATFORM_KEY = "sdk_platform"
    const val PLATFORM_KEY = "platform"
    const val PLATFORM_VALUE = "android"
    const val NAME_KEY = "name"
    const val NAME_VALUE = "otp_assist"
    const val VERSION_KEY = "version"
    const val OTP_ASSIST_EVENT = "otp_assist_event"
    const val TRNX_STATUS = "trxn_status_otp_assist_sdk"
    const val SUCCESS = "success"
    const val FAILURE = "failure"
    const val OTP_ASSIST_NETWORK_ERROR = "otp_assist_network_error"
    const val RESULT_OK = 200
    const val GATEWAY_TIMEOUT = 504
    const val NETWORK_TIMEOUT = 0
    const val NETWORK_CALL_TIMEOUT: Long = 55
    const val RESEND_OTP_CLICKED = "resend_otp_clicked"
    const val BANK_REDIRECT_CONFIRM_NO = "bank_redirect_confirm_no"
    const val BANK_REDIRECT_CONFIRM_YES = "bank_redirect_confirm_yes"
    const val CANCEL_CONFIRM_YES = "cancel_confirm_yes"
    const val CANCEL_CONFIRM_NO = "cancel_confirm_no"
    const val FRAGMENT_INIT = "fragment_init"
    const val CANCEL_DIALOG_SHOWN = "cancel_dialog_shown"
    const val CONFIRMATION_DIALOG_SHOWN = "confirmation_dialog_shown"
    const val CANCEL_TRANSACTION_PAY_TXN = "cancelTransactionPayTxn"
    const val CHECK_SUBMIT_OTP_RESPONSE = "checkSubmitOtpResponse"
    const val CHECK_INITIATE_RESPONSE = "checkInitiateResponse"
    const val HANDLE_RESEND_OTP_RESPONSE = "handleResendOtpResponse"
    const val HANDLE_SUBMIT_OTP_RESPONSE = "handleSubmitOtpResponse"
    const val SHOW_WAIT_OTP_TIMER_TRANSACTION_VALIDITY = "showWaitOtpTimerTransactionValidity"
    const val START_PAYMENT = "startPayment"
    const val ERROR_REPONSE_VIEW_MODEL = "errorResponseViewModel"
    const val MESSAGE = "message"
    const val TXN_STATUS = "txnStatus"
    const val UNMAPPED_STATUS = "unmappedStatus"
    const val ISSUING_BANK = "issuingBank"
    const val CATEGORY = "category"
    const val CARD_TYPE = "cardType"
    const val IS_DOMESTIC = "isDomestic"

    const val PENDING = "pending"
    const val FAILED = "failed"
    const val ISSUER_URL = "issuerUrl"
    const val ACS_TEMPLATE = "acsTemplate"
    const val POST_TO_BANK = "postToBank"
    const val MD = "MD"
    const val PAREQ = "PaReq"
    const val TERM_URL = "TermUrl"
    const val SUBMIT_OTP_WITHOUT_UNDERSCORE = "submitOtp"
    const val RETRY_ATTEMPT_COUNT = "retryAttemptCount"
    const val STATUS = "status"
    const val ATTEMPTS_LEFT = "attemptsLeft"
    const val STATUS_CODE = "statusCode"
    const val RESEND_OTP_WITHOUT_UNDERSCORE = "resendOtp"
    const val IN_PROGRESS = "in progress"

    const val CHECK_STATUS_NETWORK_CALL_TIMEOUT: Long = 5
    const val CHECK_STATUS_TIME_INTERVAL: Long = 10000
    const val NEW_HASH_TIME_INTERVAL: Long = 500

    const val INVALID_HASH_ERROR_CODE = 1001
    const val INVALID_MERCHANT_KEY_ERROR_CODE = 1002
    const val INVALID_TRANSACTION_ID_ERROR_CODE = 1003
    const val INVALID_URL_ERROR_CODE = 1004
    const val API_CALL_TIMEOUT_ERROR_CODE = 1005
    const val INVALID_HASH_ERROR_MESSAGE = "Hash is null or empty, please verify."
    const val INVALID_MERCHANT_KEY_ERROR_MESSAGE = "Merchant key is null or empty, please verify."
    const val INVALID_TRANSACTION_ID_ERROR_MESSAGE = "TxnId is null or empty, please verify."
    const val INVALID_URL_ERROR_MESSAGE = "Acs Template url is null or empty, please verify."

    const val API_CALL_TIMEOUT_ERROR_MESSAGE = "Api is timed-out"
    const val AMPERSAND = "&"
    const val EQUALS = "="
    const val TXN_S2S_FLOW = "txn_s2s_flow"
    const val FOUR = "4"
    const val ADDITIONAL_PARAM = "additional_param"
    const val SEAMLESS_SDK_ZERO = "{\"seamless_sdk\":\"0\"}"
    const val OPEN_IN_BROWSER = "onOpenInBrowser"
    const val HASH_TIMOUT_COUNT = 5
    //Timeout is of 300 seconds. Every 10 seconds we make 1 hit.
    // So 230 seconds + 60 seconds of hash retry timeout = 290 seconds is the worst case scenario.
    const val HASH_RETRY_COUNT = 23
    const val API_CALL_TIMOUT_COUNT = 90
    const val RESPONSE = "response"
    const val CANCELLED = "cancelled"
    const val SECURE_WEB_VIEW_FLOW = "secure_webview_flow"
    const val API = "api"
    const val REQUEST_URL = "Request URL: "
    const val REQUEST_BODY = " Request Body: "
    const val REQUEST_METHOD = " Request Method: "
    const val API_RESPONSE = "Response: "
    const val USER_INTERACTION = "UserInteraction"
    const val ERROR = "error"
    const val POST = "POST"

    //Url
    const val PROD_BASE_SECURE_URL = "https://secure.payu.in/"
    const val PROD_BASE_INFO_URL = "https://info.payu.in/"
    const val TEST_BASE_SECURE_URL = "https://test.payu.in/"
    const val TEST_BASE_INFO_URL = "https://test.payu.in/"
    const val CHECK_SECURE_TXN_PATH = "sdk/transaction"
    const val PAYMENT_URL_PATH = "_payment"

    const val V2_API_TIME_FORMATE = "EEE, dd MMM yyyy HH:mm:ss 'GMT'"
    const val CP_HASH_STRING = "hashString"
    const val CP_HASH_NAME = "hashName"
    const val DATE = "date"
    const val AUTHORISATION = "authorization"
    const val CANCEL = "CANCEL"
    const val ALERT_DIALOG_STRING = "Please proceed your transaction on chrome browser. If you want to cancel transaction press CANCEL."
    const val CCT_OPENED = "CCT opened"
    const val CLOSE_BUTTON_CLICKED = "Close Button Clicked"
    const val USER_RETURNED_FROM_SDK = "User returned from browser to sdk"

    const val PAYU_REDIRECT_URL = "redirectURL"
    const val PAYU_REDIRECT_TYPE = "redirectType"
    const val PAYMENT_REQUEST_CODE = 102
    const val CHROME_TAB_REQUEST_CODE = 1121
    const val PHONEPE_PACKAGE = "com.phonepe.app"
    const val PP_SDK_LESS_ALERT_DIALOG_STRING = "User cancelled the transaction, please tap OK below to go back."
    const val PAYU_OK = "Ok"

    const val PAYU_FOREGROUND_SERVICE_STARTED = "Foreground Service Started"
    const val PAYU_FOREGROUND_SERVICE_STOPED = "Foreground Service Stoped"
    const val PAYU_FOREGROUND_SERVICE_STARTED_EXCEPTION = "Foreground Service Started Exception"
    const val PAYU_FOREGROUND_SERVICE_STOPED_EXCEPTION = "Foreground Service Stop Exception"

}

