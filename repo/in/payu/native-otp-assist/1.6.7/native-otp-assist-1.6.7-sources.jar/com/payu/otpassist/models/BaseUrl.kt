package com.payu.otpassist.models

enum class BaseUrl {
    SECURE,
    INFO
}