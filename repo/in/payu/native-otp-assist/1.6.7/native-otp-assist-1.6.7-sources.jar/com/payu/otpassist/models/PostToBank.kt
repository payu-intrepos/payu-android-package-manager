package com.payu.otpassist.models

class PostToBank {
    var MD: String? = null
    var PaReq: String? = null
    var TermUrl: String? = null
}