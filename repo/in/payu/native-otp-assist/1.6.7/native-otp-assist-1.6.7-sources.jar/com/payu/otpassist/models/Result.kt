package com.payu.otpassist.models

class Result {
    var otpPostUrl: String? = ""
    var issuerUrl: String? = ""
    var acsTemplate: String? = ""
    var postToBank: PostToBank? = null
}