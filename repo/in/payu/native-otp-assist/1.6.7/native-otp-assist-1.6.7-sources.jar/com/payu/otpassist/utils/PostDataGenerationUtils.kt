package com.payu.otpassist.utils

import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.apis.CheckSecureTxnStatusApiManager
import com.payu.otpassist.models.HashCommand

object PostDataGenerationUtils {
    /**
     * This method helps in generating POSTDATA which we pass to backend in API requests
     */
    internal fun generatePostData(
        command: String
    ): String? {
        when (command) {
            HashCommand.CheckTxnStatusHash.hashName -> {
                return getCheckTxnBody()
            }
        }

        return null
    }

    private fun getCheckTxnBody(): String {
        val hashMapPostData = Utils.getDataFromPostData(
            PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData ?: ""
        )
        CheckSecureTxnStatusApiManager.checkTxnStatusKey = if (hashMapPostData.containsKey(Constants.KEY)) hashMapPostData[Constants.KEY].toString() else ""
        val txnId = if (hashMapPostData.containsKey(Constants.TXNID)) hashMapPostData[Constants.TXNID].toString() else ""
        return "{\"txnId\":[\"$txnId\"]}"
    }
}