package com.payu.otpassist.listeners

import com.payu.otpassist.models.CheckTxnStatusModel

interface OnCheckSecureTxnStatusListener {
    fun onSuccess(checkTxnStatusModel: CheckTxnStatusModel)
    fun onError(errorCode: Int, errorMessage: String)
}