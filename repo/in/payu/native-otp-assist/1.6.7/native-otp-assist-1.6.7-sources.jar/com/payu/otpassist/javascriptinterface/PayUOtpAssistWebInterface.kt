package com.payu.otpassist.javascriptinterface

import android.app.Activity
import android.content.Intent
import android.os.CountDownTimer
import android.text.TextUtils
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.viewmodel.PayUOtpAssistViewModel

/**
 * '
 * Here we are handing the 3ds bank flow
 * This class has all the @JavascriptInterface methods.
 */
open class PayUOtpAssistWebInterface {
    private var countDownTimer: CountDownTimer? = null
    var payuReponse: String? = null
    var isSuccessTransaction = false
    private var merchantResponse: String? = null
    private var payUOtpAssistViewModel: PayUOtpAssistViewModel? = null
    private var activity: Activity? = null

    fun setViewModel(payUOtpAssistViewModel: PayUOtpAssistViewModel?) {
        this.payUOtpAssistViewModel = payUOtpAssistViewModel
    }

    fun setActivity(activity: Activity?) {
        this.activity = activity
    }

//    private var payUOtpAssistViewModel: PayUOtpAssistViewModel? = null

    /**
     * @param result json data of post param.
     * call back function from furl - failure transaction.
     * keep the value in [.merchantResponse]
     * set result ok, and send the received data.
     * @param result json string
     */
    @JavascriptInterface
    open fun onFailure(result: String?) {
        merchantResponse = result
        onMerchantUrlFinished()
    }

    /**
     * Attempt to deprecate furl.
     * Javascript call from payu server.
     * Lets keep the data in local variable and pass it to calling activity.
     *
     * @param result json string result of failure transaction
     */
    @JavascriptInterface
    open fun onPayuFailure(result: String) {
        UiUtils.longLog("Class Name: " + javaClass.canonicalName + "onPayuFailure " + result)
        addEventAnalytics(
            Constants.TRNX_STATUS,
            Constants.FAILURE
        )
        if (activity != null) {
            isSuccessTransaction = false
            payuReponse = result
        }
        createTimer()
        // cancelTransactionNotification();
    }

    private fun createTimer() {
//        if (null != UpiData.SINGLETON.getUpiConfig()) {
        callTimer()
        /*  } else {
              if (null != UpiData.SINGLETON.getPayUPICallback()) UpiData.SINGLETON.getPayUPICallback()
                  .onUpiErrorReceived(
                      UpiConstant.NOT_PROVIDED_COMPLETE_INFO,
                      UpiConstant.PROVIDED_UPI_CONFIG_NULL.toString() + javaClass.simpleName
                  )
          }*/
    }

    /**
     * Call back from surl - sucess transaction
     * with no argument.
     * just send empty string back to calling activity
     */
    @JavascriptInterface
    open fun onSuccess() {
        onSuccess("")
    }

    /**
     * Attempt to deprecate surl.
     * Javascript interface call from payu server.
     * Lets keep the data in local variable and pass it to main activity.
     *
     * @param result json data of post param.
     */
    @JavascriptInterface
    open fun onPayuSuccess(result: String) {
        isSuccessTransaction = true
        addEventAnalytics(
            Constants.TRNX_STATUS,
            Constants.SUCCESS
        )
        payuReponse = result

        UiUtils.longLog("Class Name: " + javaClass.canonicalName + "onPayUSucess " + result)
        createTimer()
    }

    /**
     * Logging events with txnid and package name.
     * Mixpannel used only in debug mode.
     *
     * @param key   analytics event key
     * @param value analytics event value
     */
    private fun addEventAnalytics(key: String, value: String) {
        try {
            if (!TextUtils.isEmpty(value)) {
                payUOtpAssistViewModel?.addAnalytics(key, value)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * call back function from surl - success transaction.
     * keep the data in [.merchantResponse]
     * set result ok, and send the received data.
     *
     * @param result success result received from surl
     */
    @JavascriptInterface
    open fun onSuccess(result: String) {
        UiUtils.longLog("Class Name: " + javaClass.canonicalName + "onSuccess " + result)
        merchantResponse = result
        onMerchantUrlFinished()
    }

    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    open fun onCancel() {
        UiUtils.longLog("Class Name: " + javaClass.canonicalName + "onCancel ")
        onCancel("")
    }

    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    open fun onCancel(result: String) {
        UiUtils.longLog("Class Name: " + javaClass.canonicalName + "onCancel " + result)
        if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
            activity?.runOnUiThread {
                if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                    val intent = Intent()
                    //                    intent.putExtra(activity.getString(R.string.cb_result), result)
                    Toast.makeText(activity?.applicationContext, "OnCancel", Toast.LENGTH_SHORT).show()
                    activity?.setResult(Activity.RESULT_CANCELED, intent)
                    activity?.finish()
                }
            }
        }
    }

    /**
     * Just to make sure we finish activity even if the merchant's url got into trouble,
     * should be called from
     */
    private fun callTimer() {
        countDownTimer = object : CountDownTimer(
            PayUOtpAssistCurrentState.payUOtpAssistConfig?.merchantResponseTimeout!!,
            1000
        ) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                    activity?.runOnUiThread(Runnable {
                        if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                            onMerchantUrlFinished()
                        }
                    })
                }
            }
        }.start()
    }

    /**
     * This function takes care of sending the data back to calling activity with the status, merchantResponse, payuresponse.
     */
    private fun onMerchantUrlFinished() {
        if (null != countDownTimer) countDownTimer!!.cancel()
        if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
            activity?.runOnUiThread(object : Runnable {
                override fun run() {
                    if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                        if (isSuccessTransaction) {
                            if (PayUOtpAssistCurrentState.payUOtpAssistCallback != null) {
                                PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentSuccess(
                                    merchantResponse,
                                    payuReponse
                                )
                            } else {
                                UiUtils.longLog("Class Name: " + javaClass.canonicalName + "PayUOtpAssistCallback is null, Please provide a non-null callback object")
                            }
                        } else {
                            if (PayUOtpAssistCurrentState.payUOtpAssistCallback != null) {
                                PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentFailure(
                                    merchantResponse,
                                    payuReponse
                                )
                            } else {
                                UiUtils.longLog("Class Name: " + javaClass.canonicalName + "PayUOtpAssistCallback is null, Please provide a non-null callback object")
                            }
                        }
                        activity?.finish()
                    }
                }
            })
        }
    }

}