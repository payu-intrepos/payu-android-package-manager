package com.payu.otpassist.listeners

import android.content.Context
import com.payu.otpassist.models.PayUAcsRequest

abstract class PayUOtpAssistCallback {
    abstract fun onPaymentSuccess(merchantResponse: String?, payUResponse: String?)
    abstract fun onPaymentFailure(merchantResponse: String?, payUResponse: String?)
    abstract fun onError(errorCode: String?, errorMessage: String?)
    open fun onPaymentInitiate(response: String?) {}
    open fun shouldHandleFallback(payUAcsRequest: PayUAcsRequest): Boolean {
        return true
    }
    open fun generateHash(
        map: HashMap<String, String?>,
        hashGenerationListener: PayUHashGenerationListener
    ) {}
}