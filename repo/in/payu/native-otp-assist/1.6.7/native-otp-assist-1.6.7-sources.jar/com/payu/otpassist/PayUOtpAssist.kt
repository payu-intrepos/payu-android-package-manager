package com.payu.otpassist

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.payu.otpassist.listeners.PayUOtpAssistCallback
import com.payu.otpassist.models.BaseUrl
import com.payu.otpassist.models.UrlType
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.utils.Utils

object PayUOtpAssist {

    @JvmStatic
    fun open(
        context: Context,
        payUOtpAssistCallback: PayUOtpAssistCallback,
        payUOtpAssistConfig: PayUOtpAssistConfig
    ) {
        if (!payUOtpAssistConfig.postData.isNullOrEmpty()) {
            PayUOtpAssistCurrentState.payUOtpAssistCallback = payUOtpAssistCallback
            payUOtpAssistConfig.paymentUrl = Utils.prepareUrl(
                payUOtpAssistConfig.isProduction,
                BaseUrl.SECURE, UrlType.PAYMENT_URL
            )
            PayUOtpAssistCurrentState.payUOtpAssistConfig = payUOtpAssistConfig
            if (null == payUOtpAssistConfig.merchantLogo)
                payUOtpAssistConfig.merchantLogo = UiUtils.getAppIcon(context)

            val intent = Intent(context, PayUOtpAssistActivity::class.java)
            intent.putExtra(Constants.POST_DATA, payUOtpAssistConfig?.postData!!)
            context.startActivity(intent)
        } else
            throw Exception(Constants.POSTDATA_MISSING)
    }

    fun openSeamless(
        context: Context,
        payUOtpAssistCallback: PayUOtpAssistCallback,
        payUOtpAssistConfig: PayUOtpAssistConfig
    ):Fragment {
        if (!payUOtpAssistConfig.postData.isNullOrEmpty()) {
            PayUOtpAssistCurrentState.payUOtpAssistCallback = payUOtpAssistCallback
            payUOtpAssistConfig.paymentUrl = Utils.prepareUrl(
                payUOtpAssistConfig.isProduction,
                BaseUrl.SECURE, UrlType.PAYMENT_URL
            )
            PayUOtpAssistCurrentState.payUOtpAssistConfig = payUOtpAssistConfig
            if (null == payUOtpAssistConfig.merchantLogo)
                payUOtpAssistConfig.merchantLogo = UiUtils.getAppIcon(context)

            val bundle = Bundle()
            bundle.putString(Constants.POST_DATA, payUOtpAssistConfig.postData)
            return OtpAssistFragment.newInstance(bundle)
        } else
            throw Exception(Constants.POSTDATA_MISSING)
    }


}