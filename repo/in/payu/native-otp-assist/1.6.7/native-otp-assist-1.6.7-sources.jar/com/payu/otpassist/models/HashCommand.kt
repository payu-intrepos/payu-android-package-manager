package com.payu.otpassist.models

enum class HashCommand(val hashName: String) {
    CheckTxnStatusHash("check_secure_txn_status")
}