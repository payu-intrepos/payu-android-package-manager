package com.payu.otpassist.listeners

interface OnBackButtonListener {
    fun onBackButtonClicked()
}