package com.payu.otpassist.apis

import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.listeners.OnCheckSecureTxnStatusListener
import com.payu.otpassist.models.BaseApiObject
import com.payu.otpassist.models.BaseUrl
import com.payu.otpassist.models.CheckTxnStatusModel
import com.payu.otpassist.models.ErrorResponse
import com.payu.otpassist.models.UrlType
import com.payu.otpassist.network.PayUAsyncTaskResponse
import com.payu.otpassist.network.PayUNetworkData
import com.payu.otpassist.network.PayUNetworkHandler
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.HashGenerationUtils
import com.payu.otpassist.utils.Utils
import okhttp3.Headers
import org.json.JSONObject

object CheckSecureTxnStatusApi : BaseApiObject {

    override fun callAPI(hash: String, callback: OnCheckSecureTxnStatusListener) {

        val validationError = validateMandatoryRequestParams()
        if (validationError != null ) {
            callback.onError(validationError.errorCode!!, validationError.errorMessage!!)
        } else if (PayUOtpAssistCurrentState.payUOtpAssistConfig != null) {

            val networkData = PayUNetworkData()
            networkData.url = Utils.prepareUrl(
                PayUOtpAssistCurrentState.payUOtpAssistConfig?.isProduction == true,
                BaseUrl.INFO, UrlType.CHECK_SECURE_TXN
            )
            networkData.request = CheckSecureTxnStatusApiManager.checkTxnStatusBody ?: ""
            networkData.timeOut = Constants.CHECK_STATUS_NETWORK_CALL_TIMEOUT
            networkData.contentType = Constants.APPLICATION_JSON
            networkData.requestType = Constants.POST

            val headersMap = HashMap<String, String> ()
            headersMap[Constants.DATE] = CheckSecureTxnStatusApiManager.checkTxnStatusDate ?: ""
            headersMap[Constants.AUTHORISATION] = HashGenerationUtils.generateSignature()
            networkData.headers = headersMap

            val payUNetworkHandler = PayUNetworkHandler()
            CheckSecureTxnStatusApiManager.payUOtpAssistViewModel?.logKibanaApiInfo(
                networkData.url,
                networkData.request,
                networkData.requestType
            )
            payUNetworkHandler.executeApi(networkData, object : PayUAsyncTaskResponse {
                override fun onPayUAsyncTaskResponse(
                    requestType: String,
                    response: String,
                    headers: Headers?,
                    responseCode: Int
                ) {
                    CheckSecureTxnStatusApiManager.payUOtpAssistViewModel?.logKibanaApiResponseInfo(
                        response
                    )
                    if (responseCode != 0 && responseCode != Constants.GATEWAY_TIMEOUT) {
                        val jsonObject = JSONObject(response)
                        val checkTxnStatusModel = CheckTxnStatusModel()
                        checkTxnStatusModel.status = jsonObject.optInt(Constants.STATUS)
                        checkTxnStatusModel.msg = jsonObject.optString(Constants.MESSAGE)
                        val result = jsonObject.optJSONArray(Constants.RESULT)
                        checkTxnStatusModel.result = result?.get(0)?.toString() ?: ""
                        callback.onSuccess(checkTxnStatusModel)
                    }
                }

            })
        }
    }

    override fun validateMandatoryRequestParams(): ErrorResponse? {
        val hashMapPostData = Utils.getDataFromPostData(
            PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData ?: ""
        )
        if (hashMapPostData[Constants.KEY].isNullOrEmpty()) {
            val errorResponse = ErrorResponse()
            errorResponse.errorCode = Constants.INVALID_MERCHANT_KEY_ERROR_CODE
            errorResponse.errorMessage = Constants.INVALID_MERCHANT_KEY_ERROR_MESSAGE
            return errorResponse
        } else if (hashMapPostData[Constants.TXNID].isNullOrEmpty()) {
            val errorResponse = ErrorResponse()
            errorResponse.errorCode = Constants.INVALID_TRANSACTION_ID_ERROR_CODE
            errorResponse.errorMessage = Constants.INVALID_TRANSACTION_ID_ERROR_MESSAGE
            return errorResponse
        }
        return null
    }
}