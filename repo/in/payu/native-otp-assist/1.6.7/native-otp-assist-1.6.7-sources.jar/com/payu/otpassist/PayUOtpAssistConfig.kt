package com.payu.otpassist

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.annotation.ColorRes


class PayUOtpAssistConfig {
    var shouldAllowAutoSubmit: Boolean = true
    var webInterface: Any? = null
    var postData: String? = null
    var waitingTime: Long? = 30000
    var merchantResponseTimeout: Long? = 15000
    var merchantLogo: Drawable? = null
    var shouldVibrateAfterPaymentSuccess = true
    var paymentUrl = ""
    var shouldShowMerchantSummary: Boolean = true
    var shouldShowSecureWebView: Boolean = false
    var isSdkLessFlow: Boolean = false
    var isProduction: Boolean = true
    var isProtectedScreen: Boolean = true

    fun isProtectedScreen (context: Context): Boolean {
        if(isReleaseBuild(context))
            return true
        return isProtectedScreen
    }

    fun isReleaseBuild(context: Context): Boolean {
        return try {
            val clazz = Class.forName("${context.packageName}.BuildConfig")
            val buildType = clazz.getField("BUILD_TYPE").get(null) as String
            buildType == "release"
        } catch (e: Exception) {
            true // safe default — treat unknown as release
        }
    }

    @ColorRes
    var primaryColor: Int? = null
}