package com.payu.otpassist.models

class PayUAcsRequest {
    var issuerUrl: String? = "";
    var issuerPostData: String? = ""
    var acsTemplate: String? = ""
}