package com.payu.otpassist.models

enum class UrlType {
    PAYMENT_URL,
    CHECK_SECURE_TXN
}