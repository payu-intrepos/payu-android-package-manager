package com.payu.otpassist.utils

import com.payu.otpassist.apis.CheckSecureTxnStatusApiManager
import com.payu.otpassist.models.HashCommand
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

object HashGenerationUtils {

    fun getHash(jsonString: String) : HashMap<String, String?> {
        val hashMap = HashMap<String, String?>()
        hashMap[Constants.CP_HASH_STRING] = generateSigningString(jsonString)
        hashMap[Constants.CP_HASH_NAME] = HashCommand.CheckTxnStatusHash.hashName

        return hashMap
    }

    private fun generateSigningString(jsonString: String): String {
        CheckSecureTxnStatusApiManager.checkTxnStatusDate = Utils.getDate()
        return StringBuilder().append(jsonString).append("|").append(CheckSecureTxnStatusApiManager.checkTxnStatusDate).append("|").toString()
    }

    internal fun generateSignature() : String {
        return "hmac username=\"${CheckSecureTxnStatusApiManager.checkTxnStatusKey}\", algorithm=\"sha512\", headers=\"date\", signature=\"${CheckSecureTxnStatusApiManager.checkTxnStatusHash}\""
    }
}