package com.payu.otpassist.models

data class ResendOtpResponse(
    val metaData: MetaData2?
)

data class MetaData2(
    var message: String? = "",
    var referenceId: String? = "",
    var statusCode: String? = "",
    var resendOtp: ResendOtp?,
    var txnId: String? = "",
    var unmappedStatus: String? = ""
)


data class ResendOtp(
    var status: String? = "",
    var attemptsLeft: Int?
)