package com.payu.otpassist.models

import com.payu.otpassist.listeners.OnCheckSecureTxnStatusListener


interface BaseApiObject {
    fun callAPI(hash: String, callback: OnCheckSecureTxnStatusListener)
    fun validateMandatoryRequestParams(): ErrorResponse?
}