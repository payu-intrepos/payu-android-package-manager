package com.payu.otpassist.models

class MetaData {
    var message: Any? = null
    var referenceId: String? = null
    var statusCode: Any? = null
    var txnId: String? = null
    var txnStatus: String? = null
    var unmappedStatus: String? = null

}