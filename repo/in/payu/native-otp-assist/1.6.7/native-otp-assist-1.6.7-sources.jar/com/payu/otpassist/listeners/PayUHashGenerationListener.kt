package com.payu.otpassist.listeners

interface PayUHashGenerationListener {
    fun onHashGenerated(map: HashMap<String, String?>)
}