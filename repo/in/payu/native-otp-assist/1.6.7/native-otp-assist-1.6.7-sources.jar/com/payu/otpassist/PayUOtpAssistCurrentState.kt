package com.payu.otpassist

import com.payu.otpassist.listeners.PayUOtpAssistCallback

object PayUOtpAssistCurrentState {
    var payUOtpAssistCallback: PayUOtpAssistCallback? = null
    var payUOtpAssistConfig: PayUOtpAssistConfig? = null
}