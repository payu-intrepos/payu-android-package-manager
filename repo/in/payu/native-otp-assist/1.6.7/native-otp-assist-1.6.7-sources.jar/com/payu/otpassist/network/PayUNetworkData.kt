package com.payu.otpassist.network

import com.payu.otpassist.utils.Constants


class PayUNetworkData {
    var url: String = ""
    var request: String = ""
    var contentType: String = Constants.APPLICATION_FORM_URL_ENCODED
    var accept: String = ""
    var requestType: String = Constants.POST
    var type: String = ""
    var cookiesList: String = ""
    var timeOut: Long = Constants.NETWORK_CALL_TIMEOUT
    var headers: HashMap<String, String> = HashMap()
}