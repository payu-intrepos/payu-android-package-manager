package com.payu.otpassist.models

class PayUInitiatePaymentResponse {
    var metaData: MetaData? = null
    var result: Result? = null
    var binData: BinData? = null
    var sdkLessResponse: SdkLessResponse ? = null
}