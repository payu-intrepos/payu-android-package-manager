package com.payu.otpassist

import android.annotation.SuppressLint
import android.app.Activity.RESULT_CANCELED
import android.app.AlertDialog
import android.app.ActivityManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.browser.customtabs.CustomTabsIntent
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import android.os.Handler
import android.os.Looper
import com.payu.otpassist.apis.CheckSecureTxnStatusApiManager
import com.payu.otpassist.javascriptinterface.PayUOtpAssistWebInterface
import com.payu.otpassist.listeners.OnBackButtonListener
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.viewmodel.PayUOtpAssistViewModel
import com.payu.otpassist.widgets.PayUProgressDialog
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics


class OtpAssistFragment private constructor() : Fragment(), OnBackButtonListener {
    private var otpAssistWebView: WebView? = null
    private var viewModel: PayUOtpAssistViewModel? = null
    private var bottomSheet: PayUOtpAssistDialogFragment? = null
    private var isWebFlow = false
    private var payUAnalytics: PayUAnalytics? = null
    private var alertDialog: AlertDialog? = null
    private var cctAlertDialog: AlertDialog? = null
    internal var payUProgressDialog: PayUProgressDialog? = null
    private var isPPSDKLESSTXN : Boolean = false // variable to check if it is Phonepe sdk less txn
    private val FOREGROUND_SERVICE_PERMISSION_REQUEST_CODE = 1001

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.activity_pay_u_otp_assist, container, false)
        otpAssistWebView = view.findViewById(R.id.otpAssistWebView)
        return view
    }

    companion object {
        fun newInstance(bundle: Bundle?): OtpAssistFragment {
            val fragment = OtpAssistFragment()
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val bundle = arguments
        super.onViewCreated(view, savedInstanceState)
        if (bundle?.getString(Constants.POST_DATA) != null) {
            payUAnalytics =
                context?.let { AnalyticsFactory(it).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) } as PayUAnalytics
//                PayUAnalytics.getInstance(applicationContext, "local_cache_analytics")
            viewModel = PayUOtpAssistViewModel(requireActivity().application, payUAnalytics!!)
            viewModel?.startPayment(bundle.getString(Constants.POST_DATA)!!)
            addObserver()
            bottomSheet =
                PayUOtpAssistDialogFragment.newInstance(viewModel!!)
            bottomSheet?.isCancelable = false
            bottomSheet?.show(
                requireActivity().supportFragmentManager,
                "OtpAssistBottomSheet"
            )
        }
        UiUtils.hideKeyboard(requireActivity())
        setCollectWebViewSettings()
        viewModel?.bindCustomTabService(requireContext())
    }


    @SuppressLint("JavascriptInterface")
    private fun setCollectWebViewSettings() {

        if (otpAssistWebView != null) {
            otpAssistWebView?.settings?.javaScriptEnabled = true
            if (null != PayUOtpAssistCurrentState?.payUOtpAssistConfig && null != PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface) {
                val customWebInterface: Any?
                if (PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface is PayUOtpAssistWebInterface) {
                    customWebInterface =
                        PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface as PayUOtpAssistWebInterface
                    customWebInterface.setActivity(requireActivity())
                } else {
                    customWebInterface =
                        PayUOtpAssistCurrentState?.payUOtpAssistConfig?.webInterface
                }
                otpAssistWebView?.addJavascriptInterface(
                    customWebInterface!!,
                    "PayU"
                )

            } else {
                val payUOtpAssistWebInterface = PayUOtpAssistWebInterface()
                payUOtpAssistWebInterface.setViewModel(viewModel)
                payUOtpAssistWebInterface.setActivity(requireActivity())
                otpAssistWebView?.addJavascriptInterface(
                    payUOtpAssistWebInterface,
                    "PayU"
                )
            }
            otpAssistWebView?.visibility = View.GONE
            otpAssistWebView?.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    UiUtils.hideKeyboard(requireActivity())
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    UiUtils.hideKeyboard(requireActivity())
                }
            }
        }
    }

    private var postDataForIssuer: String? = null
    private fun addObserver() {


        viewModel?.postDataForIssuerUrl?.observe(requireActivity(), Observer {
            postDataForIssuer = it
        })

        viewModel?.issuerUrlLoad?.observe(requireActivity(), Observer {
            isWebFlow = true
//            toggleKeyboard()
//            makeActivityOpaqueFor3ds()
            postUrlWebView(it)
        })

        viewModel?.acsTemplateToLoad?.observe(requireActivity(), Observer {
            isWebFlow = true
//            toggleKeyboard()
//            makeActivityOpaqueFor3ds()
            postDataToWebView(it)
        })

        viewModel?.errorResponse?.observe(requireActivity(), Observer {
            viewModel?.onError(
                Constants.UN_EXPECTED_RESPONSE_ERROR_CODE,
                it,
                Constants.ERROR_REPONSE_VIEW_MODEL
            )

        })


        viewModel?.shouldCloseBottomSheet?.observe(requireActivity(), Observer {
            if (it) {
                UiUtils.hideKeyboard(requireActivity())
                if (bottomSheet?.isVisible == true)
                    bottomSheet?.dismissAllowingStateLoss()
            }

        })

        viewModel?.shouldFinishActivity?.observe(requireActivity(), Observer {
            if (it) {
                UiUtils.hideKeyboard(requireActivity())
                if (bottomSheet?.isVisible == true)
                    bottomSheet?.dismissAllowingStateLoss()
                UiUtils.updateLayoutSecurity(requireActivity(), false)
            }

        })

        viewModel?.startChromeCustomTab?.observe(requireActivity(), Observer {
            if (it) {
                openChromeCustomTab(viewModel?.getCctUrl())
            }

        })

        viewModel?.closeChromeCustomTab?.observe(requireActivity(), Observer {
            if (it) {
                fragmentCloseCustomTab(viewModel?.getResponseString() ?: "")
            }

        })

        viewModel?.showAlertDialog?.observe(requireActivity(), Observer {
            if (it) {
                showAlertDialog()
            } else {
                hideAlertDialog()
            }
        })

        viewModel?.showProgressDialog?.observe(requireActivity(), Observer {
            if (it) {
                payUProgressDialogShow()
            } else {
                payUProgressDialogHide()
            }
        })
        viewModel?.showSDkLessIntent?.observe(viewLifecycleOwner) {
            if (it != null) {
                viewModel?.makePayment(Constants.PHONEPE_PACKAGE, it.redirectUrl, this)
            }
        }


    }

    private fun openChromeCustomTab(url: String?) {
        viewModel?.addAnalytics(Constants.USER_INTERACTION, Constants.CCT_OPENED)
        val builder = CustomTabsIntent.Builder(viewModel?.getSession())
        val customTabsIntent = builder.build()
        customTabsIntent.intent.data = Uri.parse(url)
        startActivity(customTabsIntent.intent)
        viewModel?.setActivity(activity)
        // Start foreground service to call API when Chrome Custom Tab opens
        // Add delay to ensure Chrome Custom Tab is fully opened
        Handler(Looper.getMainLooper()).postDelayed({
            startForegroundServiceForApiCall()
        }, 1000) // 1 seconds delay to ensure Chrome Custom Tab is fully opened
    }

    private fun startForegroundServiceForApiCall() {
        val ctx = context ?: activity ?: return

        val serviceIntent = Intent(ctx, CheckTxnStatusForegroundService::class.java).apply {
            action = CheckTxnStatusForegroundService.ACTION_START_API_CALL
        }

        try {
            // Android < O → no foreground service support
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                CheckSecureTxnStatusApiManager.callApi()
                return
            }

            // Check if foreground service is already running and stop it first
            if (isForegroundServiceRunning(ctx)) {
                Log.d("OtpAssistFragment", "Foreground service is already running, stopping it first")
                stopForegroundService()
                // Wait a bit for service to stop before starting new one
                Handler(Looper.getMainLooper()).postDelayed({
                    startNewForegroundService(ctx, serviceIntent)
                }, 500)
            } else {
                startNewForegroundService(ctx, serviceIntent)
            }

        } catch (e: Exception) {
            viewModel?.addAnalytics(
                Constants.OTP_ASSIST_EVENT,
                "${Constants.PAYU_FOREGROUND_SERVICE_STARTED_EXCEPTION}_${e.message}"
            )
            Log.e("OtpAssistFragment", "Error starting foreground service", e)
        }
    }
    
    private fun startNewForegroundService(ctx: android.content.Context, serviceIntent: Intent) {
        try {
            // Android 14+ requires FOREGROUND_SERVICE permission
            if (Build.VERSION.SDK_INT >= 34) {
                val hasPermission =
                    ContextCompat.checkSelfPermission(
                        ctx,
                        android.Manifest.permission.FOREGROUND_SERVICE
                    ) == PackageManager.PERMISSION_GRANTED

                if (!hasPermission) {
                    CheckSecureTxnStatusApiManager.callApi()
                    return
                }
            }

            // Start foreground service
            viewModel?.addAnalytics(
                Constants.OTP_ASSIST_EVENT,
                Constants.PAYU_FOREGROUND_SERVICE_STARTED
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(serviceIntent)
            }
        } catch (e: Exception) {
            viewModel?.addAnalytics(
                Constants.OTP_ASSIST_EVENT,
                "${Constants.PAYU_FOREGROUND_SERVICE_STARTED_EXCEPTION}_${e.message}"
            )
            Log.e("OtpAssistFragment", "Error starting new foreground service", e)
        }
    }
    
    private fun isForegroundServiceRunning(context: android.content.Context): Boolean {
        val activityManager = context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as? ActivityManager
        if (activityManager != null) {
            val runningServices = activityManager.getRunningServices(Integer.MAX_VALUE)
            for (service in runningServices) {
                if (CheckTxnStatusForegroundService::class.java.name == service.service.className) {
                    return true
                }
            }
        }
        return false
    }
    private fun stopForegroundService() {
        val context = context ?: activity
        if (context != null) {
            viewModel?.addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.PAYU_FOREGROUND_SERVICE_STOPED)
            try {
                val serviceIntent = Intent(context, CheckTxnStatusForegroundService::class.java).apply {
                    action = CheckTxnStatusForegroundService.ACTION_STOP_SERVICE
                }
                context.stopService(serviceIntent)
            } catch (e: Exception) {
                viewModel?.addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.PAYU_FOREGROUND_SERVICE_STOPED_EXCEPTION+"_${e.message}")
                Log.e("OtpAssistFragment", "Error stopping foreground service: ${e.message}")
            }
        }
    }

    private fun createPayUProgressDialog() {
        payUProgressDialog = context?.let { PayUProgressDialog(it, null) }
    }

    private fun createAlertDialog() {
        val alertDialogBuilder: AlertDialog.Builder? = AlertDialog.Builder(requireActivity())
            .setMessage(if (isPPSDKLESSTXN) Constants.PP_SDK_LESS_ALERT_DIALOG_STRING else Constants.ALERT_DIALOG_STRING)
            ?.setCancelable(false)
            ?.setPositiveButton(if (isPPSDKLESSTXN) Constants.PAYU_OK else Constants.CANCEL) { dialog, id ->
                if(CheckSecureTxnStatusApiManager.timer != null) {
                    CheckSecureTxnStatusApiManager.timer?.cancel()
                    CheckSecureTxnStatusApiManager.timer = null
                }
                payUProgressDialogHide()
                viewModel?.hideAlertDialog()
                viewModel?.cancelTransactionPayTxn()

            }
        cctAlertDialog = alertDialogBuilder?.create()
    }


    private fun postUrlWebView(url: String) {

        if (otpAssistWebView != null) {
            otpAssistWebView?.visibility = View.VISIBLE
//            otpAssistWebView?.loadUrl("https://w3schools.com")
            otpAssistWebView?.postUrl(url, postDataForIssuer?.toByteArray()!!)
        }
    }

    private fun postDataToWebView(acsTemplate: String) {

        if (otpAssistWebView != null) {
            otpAssistWebView?.visibility = View.VISIBLE
            otpAssistWebView?.loadData(acsTemplate, "text/html; charset=utf-8", "UTF-8")
//            otpAssistWebView?.loadUrl("https://w3schools.com")
        }
    }

    internal fun fragmentCloseCustomTab(response: String) {
        try {
            activity?.let{
                val intent = Intent(it, it::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.putExtra(Constants.RESPONSE,response)
                activity?.startActivity(intent)
            }
        } catch(e: Exception){
            Log.v("PAYU", "closeCustomTab :" + e.message.toString())
        }
    }

//    private fun makeActivityOpaqueFor3ds() {
//        window.setLayout(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
//        setTheme(R.style.PayU_Otp_Assist_Opaque_Screen)
//
//    }


    override fun onBackButtonClicked() {
        if (isWebFlow)
            confirmationDialog()
        else {
            UiUtils.hideKeyboard(requireActivity())
            PayUOtpAssistDialogFragment.viewModel?.onCloseBottomSheet()
        }
    }


    private fun confirmationDialog() {
        val onClickListener: DialogInterface.OnClickListener =
            DialogInterface.OnClickListener { dialogInterface, i ->
                if (i == -1) {
                    viewModel?.cancelTransactionPayTxn()
                } else if (i == -2) {
                    dialogInterface?.dismiss()

                }
            }
        val builder = UiUtils.getAlertDialog(
            requireActivity(),
            onClickListener,
            getString(R.string.payu_yes),
            getString(R.string.payu_no),
            null,
            getString(R.string.payu_do_you_really_want_to_cancel_the_payment)
        )

        alertDialog = builder?.create()
        alertDialog?.show()


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        for (fragment in requireActivity().supportFragmentManager.fragments) {
            if (null != fragment && fragment is PayUOtpAssistDialogFragment) {
                if (requestCode == Constants.PAYMENT_REQUEST_CODE) {
                    isPPSDKLESSTXN = true
                    if (resultCode == RESULT_CANCELED) {
                        viewModel?.showAlertDialog()
                    } else {
                        viewModel?.verifyPayment()
                    }
                } else fragment.onActivityResult(requestCode, resultCode, data)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        for (fragment in requireActivity().supportFragmentManager.fragments) {
            if (null != fragment && fragment is PayUOtpAssistDialogFragment) {
                fragment.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }

    }

    override fun onResume() {
        super.onResume()
        // Stop foreground service when fragment resumes (e.g., user returns from Chrome Custom Tab)

        //close button clicked
        if (viewModel?.getCurrentState() == 6 || viewModel?.getCurrentState() == 2) {
            stopForegroundService()
            val isErrorCallbackNeeded = (CheckSecureTxnStatusApiManager.timer!= null)
            if(CheckSecureTxnStatusApiManager.timer != null) {
                CheckSecureTxnStatusApiManager.timer?.cancel()
                CheckSecureTxnStatusApiManager.timer = null
            }
            viewModel?.addAnalytics(Constants.USER_INTERACTION, Constants.CLOSE_BUTTON_CLICKED)
            viewModel?.cancelTransactionPayTxn(isErrorCallbackNeeded)
        } else if (viewModel?.getIsOpenInChrome() == true) {
            viewModel?.addAnalytics(Constants.USER_INTERACTION, Constants.USER_RETURNED_FROM_SDK)
            viewModel?.closeTabSession()
            viewModel?.hideAlertDialog()
            payUProgressDialogShow()
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        // Stop foreground service when fragment view is destroyed
        stopForegroundService()
    }

    fun showAlertDialog() {
        val alertDialog = getAlertDialog()
        if(alertDialog != null && !alertDialog.isShowing) {
            alertDialog.show()
            alertDialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.RED)
        }
    }

    fun hideAlertDialog() {
        val alertDialog = getAlertDialog()
        if(alertDialog != null && alertDialog.isShowing) {
            alertDialog.hide()
        }
    }

    fun getAlertDialog(): AlertDialog?{
        if(cctAlertDialog == null)
            createAlertDialog()
        return cctAlertDialog
    }

    fun payUProgressDialogShow() {
        val payUProgressDialog = getPayUProgressDialog()
        if(payUProgressDialog != null && !payUProgressDialog.isShowing) {
            payUProgressDialog.show()
        }
    }

    fun payUProgressDialogHide() {
        val payUProgressDialog = getPayUProgressDialog()
        if(payUProgressDialog != null && payUProgressDialog.isShowing) {
            payUProgressDialog.hide()
        }
    }

    fun getPayUProgressDialog(): PayUProgressDialog?{
        if(payUProgressDialog == null)
            createPayUProgressDialog()
        return payUProgressDialog
    }
}