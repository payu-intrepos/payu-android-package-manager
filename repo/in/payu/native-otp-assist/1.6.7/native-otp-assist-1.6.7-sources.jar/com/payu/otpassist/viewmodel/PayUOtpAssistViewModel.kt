package com.payu.otpassist.viewmodel

import android.Manifest
import android.animation.TimeAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.text.TextUtils
import android.util.Log
import android.webkit.URLUtil
import androidx.browser.customtabs.CustomTabsCallback
import androidx.browser.customtabs.CustomTabsClient
import androidx.browser.customtabs.CustomTabsServiceConnection
import androidx.browser.customtabs.CustomTabsSession
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.payu.otpassist.OtpAssistFragment
import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.R
import com.payu.otpassist.apis.CheckSecureTxnStatusApiManager
import com.payu.otpassist.models.PayUAcsRequest
import com.payu.otpassist.models.PayUInitiatePaymentResponse
import com.payu.otpassist.models.SdkLessResponse
import com.payu.otpassist.network.PayUAsyncTaskResponse
import com.payu.otpassist.network.PayUNetworkData
import com.payu.otpassist.network.PayUNetworkHandler
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.utils.Utils
import com.payu.payuanalytics.analytics.model.PayUAnalytics
import okhttp3.Headers
import org.json.JSONException
import java.util.*


class PayUOtpAssistViewModel(
    application: Application, private var payUAnalytics: PayUAnalytics
) : AndroidViewModel(application), PayUAsyncTaskResponse, TimeAnimator.TimeListener {
    var errorResponse: MutableLiveData<String> = MutableLiveData()
    var issuerUrlLoad: MutableLiveData<String> = MutableLiveData()
    var postDataForIssuerUrl: MutableLiveData<String> = MutableLiveData()
    var showLoadingProgressBarMessage: MutableLiveData<String> = MutableLiveData()
    var showNativeFlow: MutableLiveData<String> = MutableLiveData()
    var shouldFinishActivity: MutableLiveData<Boolean> = MutableLiveData()
    var errorMessage: MutableLiveData<String> = MutableLiveData()
    var shouldOpenCancelDialog: MutableLiveData<Boolean> = MutableLiveData()
    var shouldOpenConfirmationDialog: MutableLiveData<Boolean> = MutableLiveData()
    var enableResendOtp: MutableLiveData<Boolean> = MutableLiveData()
    var toastMessage: MutableLiveData<String> = MutableLiveData()
    var titleText: MutableLiveData<String> = MutableLiveData()
    var acsTemplateToLoad: MutableLiveData<String> = MutableLiveData()
    var merchantIcon: MutableLiveData<Drawable> = MutableLiveData()
    var shouldCloseBottomSheet: MutableLiveData<Boolean> = MutableLiveData()
    var fetchedOtp: MutableLiveData<String> = MutableLiveData()
    var amountLiveData: MutableLiveData<String> = MutableLiveData()
    var cardNumberLiveData: MutableLiveData<String> = MutableLiveData()
    var bankIssuerLiveData: MutableLiveData<String> = MutableLiveData()
    var waitingOtpTextLiveData: MutableLiveData<String> = MutableLiveData()
    var mCurrentLevelLiveData: MutableLiveData<Int> = MutableLiveData()
    var cancelAnimatorLiveData: MutableLiveData<Boolean> = MutableLiveData()
    var timerStopLiveData: MutableLiveData<Boolean> = MutableLiveData()
    var resendOtpText: MutableLiveData<String> = MutableLiveData()
    var animatorListnerLiveData: MutableLiveData<TimeAnimator.TimeListener> = MutableLiveData()
    var enableOtpSubmitButton: MutableLiveData<Boolean> = MutableLiveData()
    var enableTabToPause: MutableLiveData<Boolean> = MutableLiveData()
    var visibleManualOtpUI: MutableLiveData<Boolean> = MutableLiveData()
    var isSubmitOtpApiInProgressLiveData: MutableLiveData<Boolean> = MutableLiveData()
    var isIntiatingPaymentInProgressLiveData: MutableLiveData<Boolean> = MutableLiveData()
    var startChromeCustomTab: MutableLiveData<Boolean> = MutableLiveData()
    var closeChromeCustomTab: MutableLiveData<Boolean> = MutableLiveData()
    var showAlertDialog: MutableLiveData<Boolean> = MutableLiveData()
    var showProgressDialog: MutableLiveData<Boolean> = MutableLiveData()
    var showSDkLessIntent: MutableLiveData<SdkLessResponse> = MutableLiveData()
    val applicationContext = application
    internal var referenceId: String? = null
    var otpUrl: String? = null
    private var merchantKey: String? = null
    private var transactionId: String? = null
    private var attemptLeft: Int = 1
    private var countDownTimer: CountDownTimer? = null
    private var countDownTimerForMessageChange: CountDownTimer? = null
    private var countDownTimerForTransactionvalidity: CountDownTimer? = null
    private var diableTimerForResendOtpCountDownTimer: CountDownTimer? = null
    private var mCurrentLevel = 0
    private val levelIncrement = 25
    private val maxLevel = 10000
    private val transactionTimeOut = 180000
    private var isIntiatingPaymentInProgress = false
    private var isSubmitOtpApiInProgress = false
    private var postData = ""
    private var retryCountInitiatePayment = 0
    private var payUInitiatePaymentResponse: PayUInitiatePaymentResponse? = null
    private val mPayUNetWorkHandler = PayUNetworkHandler()
    private var isOtpSubmittedManually = true
    private var transactionFlow = ""
    internal var cctUrl = ""
    internal var responseString = ""

    internal var mClient: CustomTabsClient? = null
    internal var mSession: CustomTabsSession? = null
    internal var currentState = -1
    internal var isOpenInChrome = false
    internal val CHROME_PACKAGE_NAME = "com.android.chrome"
    internal var mActivity: Activity? = null

    fun startPayment(postData: String) {
        if (UiUtils.isInternetAvailable(applicationContext) && PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl != null) {
            isIntiatingPaymentInProgress = true
            this.postData = postData
            deviceAnalytics(postData)
            var pd =
                postData + Constants.AMPERSAND + Constants.TXN_S2S_FLOW + Constants.EQUALS + Constants.FOUR
            if (PayUOtpAssistCurrentState.payUOtpAssistConfig?.shouldShowSecureWebView == true) {
                transactionFlow = Constants.SECURE_WEB_VIEW_FLOW
                pd += Constants.AMPERSAND + Constants.ADDITIONAL_PARAM + Constants.EQUALS + Constants.SEAMLESS_SDK_ZERO
            }
            showLoadingProgressBarMessage.value =
                applicationContext.getString(R.string.payu_processing_your_payment)
            val payUNetworkData = PayUNetworkData()
            payUNetworkData.request = Utils.getAnalyticsAddedPostData(pd)
            payUNetworkData.type = Constants.INITATE_PAYMENT_RESPONSE
            payUNetworkData.url =
                PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl.toString()
            logKibanaApiInfo(
                payUNetworkData.url,
                payUNetworkData.request,
                payUNetworkData.requestType
            )
            mPayUNetWorkHandler.executeApi(payUNetworkData, this)
            CheckSecureTxnStatusApiManager.payUOtpAssistViewModel = this
        } else {
            onError(
                Constants.NO_INTERNET_ERROR_CODE,
                Constants.NO_INTERNET_ERROR,
                Constants.START_PAYMENT
            )
        }
    }

    private fun deviceAnalytics(postData: String) {
        val hashMapPostData = Utils.getDataFromPostData(
            postData
        )
        if (hashMapPostData.containsKey(Constants.KEY) && hashMapPostData.containsKey(Constants.TXNID)) {
            merchantKey = hashMapPostData[Constants.KEY].toString()
            transactionId = hashMapPostData[Constants.TXNID].toString()
            UiUtils.deviceAnalytics(
                hashMapPostData[Constants.KEY].toString(),
                applicationContext,
                hashMapPostData[Constants.TXNID].toString()
            )
        }
    }

    fun finish() {
        dismissTimers()
        shouldFinishActivity.value = true
        mPayUNetWorkHandler.cancel()
        cleanUp()
    }

    private fun cleanUp() {
        PayUOtpAssistCurrentState.payUOtpAssistCallback = null
        PayUOtpAssistCurrentState.payUOtpAssistConfig = null
    }

    fun fetchMerchantDetailsToShow() {
        PayUOtpAssistCurrentState.payUOtpAssistConfig?.merchantLogo?.let {
            merchantIcon.value = it
        }

    }

    fun setFetchedOtp(otp: String) {
        fetchedOtp.value = otp
    }

    fun submitOtp(otp: String, isSubmittingManually: Boolean = true) {
        isOtpSubmittedManually = isSubmittingManually
        if (UiUtils.isInternetAvailable(applicationContext)) {
            if (!otpUrl.isNullOrEmpty()) {
                isSubmitOtpApiInProgress = true
                timerForWaitingTimerMessageChange()
                showLoadingProgressBarMessage.value =
                    applicationContext.getString(R.string.payu_confirming_your_payment)
                val pd = "referenceId=$referenceId&otp=$otp"
                val payUNetworkData = PayUNetworkData()
                payUNetworkData.request = pd
                payUNetworkData.url = otpUrl!!
                payUNetworkData.type = Constants.SUBMIT_OTP
                logKibanaApiInfo(
                    payUNetworkData.url,
                    payUNetworkData.request,
                    payUNetworkData.requestType
                )
                mPayUNetWorkHandler.executeApi(payUNetworkData, this)
            }
        } else {
            toastMessage.value = applicationContext.getString(R.string.payu_otp_no_network)

        }
    }

    fun resendOtp() {
        if (UiUtils.isInternetAvailable(applicationContext)) {
            enableResendOtp.value = false
            resendOtpText.value = applicationContext.getString(R.string.payu_otp_otp_resent)
            countDownTimer?.cancel()
            addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.RESEND_OTP_CLICKED)
            showWaitOtpTimer()
            val mPayUNetWorkHandler = PayUNetworkHandler()
            val pd = "referenceId=$referenceId&resendOtp=1"
            val payUNetworkData = PayUNetworkData()
            payUNetworkData.request = pd
            payUNetworkData.url = otpUrl!!
            payUNetworkData.type = Constants.RESEND_OTP
            logKibanaApiInfo(
                payUNetworkData.url,
                payUNetworkData.request,
                payUNetworkData.requestType
            )
            mPayUNetWorkHandler.executeApi(payUNetworkData, this)
        } else {
            toastMessage.value = applicationContext.getString(R.string.payu_otp_no_network)
        }
    }

    fun fetchInitialValues() {
        fetchAmount()
        fetchCreditCardNumber()
        resendOtpText.value = applicationContext.getString(R.string.payu_otp_resend_otp)
    }

    private fun fetchAmount() {
        if (!PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData.isNullOrEmpty()) {
            amountLiveData.value =
                applicationContext.getString(R.string.payu_rupay_currency) + Utils.getDataFromPostData(
                    PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData
                )[Constants.AMOUNT]!!
        }
    }

    private fun fetchCreditCardNumber() {
        if (!PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData.isNullOrEmpty()) {
            val hashMapPostData = Utils.getDataFromPostData(
                PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData
            )
            cardNumberLiveData.value = fetCcNumToShow(hashMapPostData)

        }
    }

    fun fetCcNumToShow(hashMapPostData: HashMap<String?, String?>?): String {
        if (hashMapPostData?.containsKey(Constants.CCNUM) == true) {
            hashMapPostData[Constants.CCNUM]?.let {
                if (it.length >= 4
                ) {
                    return "****" + it.takeLast(4)
                }
            }

        }
        return "****"
    }

    override fun onPayUAsyncTaskResponse(
        requestType: String,
        response: String,
        headers: Headers?,
        responseCode: Int
    ) {
        logKibanaApiResponseInfo(response)
        when (requestType) {
            Constants.INITATE_PAYMENT_RESPONSE -> {
                isIntiatingPaymentInProgress = false
                checkInitiateResponse(response, responseCode)
            }

            Constants.SUBMIT_OTP -> {
                checkSubmitOtpResponse(response, responseCode)
                isSubmitOtpApiInProgress = false
                dismissTimerMessageChange()
            }

            Constants.RESEND_OTP -> {
                addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.OTP_RESEND)
                handleResendOtpResponse(response)
            }
        }
    }

    private fun checkSubmitOtpResponse(response: String, responseCode: Int) {
        isSubmitOtpApiInProgress = false
        if (responseCode == Constants.NETWORK_TIMEOUT) {
            onError(
                Constants.NETWORK_TIMEOUT_ERROR_CODE,
                Constants.NETWORK_TIMEOUT_ERROR_MESSAGE,
                Constants.CHECK_SUBMIT_OTP_RESPONSE
            )
            finish()
        } else if (Utils.isBackendError(response)) {
            onError(
                Constants.GATEWAY_TIMEOUT_ERROR_CODE,
                Constants.GATEWAY_TIMEOUT_ERROR_MESSAGE,
                Constants.CHECK_SUBMIT_OTP_RESPONSE
            )
            finish()

        } else
            try {
                if (isOtpSubmittedManually)
                    addAnalytics(
                        Constants.OTP_ASSIST_EVENT,
                        Constants.OTP_SUBMIT_MANUALLY
                    )
                else
                    addAnalytics(
                        Constants.OTP_ASSIST_EVENT,
                        Constants.OTP_SUBMIT_AUTO
                    )

                handleSubmitOtpResponse(response)

            } catch (e: JSONException) {
                onError(
                    Constants.SOMETHING_WENT_WRONG_ERROR_CODE,
                    Constants.SOMETHING_WENT_WRONG_ERROR,
                    Constants.CHECK_SUBMIT_OTP_RESPONSE
                )
            }

    }

    private fun checkInitiateResponse(response: String, responseCode: Int) {
        if (responseCode == Constants.NETWORK_TIMEOUT) {
            onError(
                Constants.NETWORK_TIMEOUT_ERROR_CODE,
                Constants.NETWORK_TIMEOUT_ERROR_MESSAGE,
                Constants.CHECK_INITIATE_RESPONSE
            )
            finish()
        } else if (Utils.isBackendError(response)) {
            if (retryCountInitiatePayment == 0) {
                retryCountInitiatePayment++
                if (postData.isNotEmpty())
                    startPayment(postData)
            } else {
                onError(
                    Constants.GATEWAY_TIMEOUT_ERROR_CODE,
                    Constants.GATEWAY_TIMEOUT_ERROR_MESSAGE,
                    Constants.CHECK_INITIATE_RESPONSE
                )
                finish()
            }
        } else
            handleInitiatePaymentResponse(response)

    }

    fun onError(errorCode: String?, errorMessage: String?, api: String?) {
        addAnalytics(Constants.OTP_ASSIST_EVENT, value = "$errorCode|$api")
        PayUOtpAssistCurrentState.payUOtpAssistCallback?.onError(errorCode, errorMessage)
    }

    fun addAnalytics(key: String, value: String) {
        var eventValue = value
        if (!TextUtils.isEmpty(transactionFlow))
            eventValue = value + "_" + transactionFlow

        payUAnalytics.log(
            UiUtils.getLogMessage(
                applicationContext,
                key,
                eventValue,
                merchantKey,
                transactionId
            )!!
        )
    }

    fun handleResendOtpResponse(response: String) {
        try {
            val resendOtpResponse = Utils.getResendOtpResponse(response)
            if (resendOtpResponse.metaData?.resendOtp != null && null != resendOtpResponse.metaData.resendOtp?.attemptsLeft
            ) {
                attemptLeft = resendOtpResponse.metaData.resendOtp?.attemptsLeft!!
                enableResendOtp.value = false
                if (attemptLeft >= 0) {
                    showWaitOtpTimerForResendOtp()
                    toastMessage.value = "Otp sent successfully!"
                }
            }
        } catch (e: JSONException) {
            onError(
                Constants.SOMETHING_WENT_WRONG_ERROR_CODE,
                Constants.SOMETHING_WENT_WRONG_ERROR,
                Constants.HANDLE_RESEND_OTP_RESPONSE
            )
        }
    }

    fun handleSubmitOtpResponse(response: String) {
        try {
            val submitOtpResponse = Utils.getSubmitOtpResponse(response)
            if (null != submitOtpResponse.metaData?.submitOtp && !submitOtpResponse.metaData.submitOtp?.status.isNullOrEmpty()) {
                val submitOtp = submitOtpResponse.metaData.submitOtp
                run {
                    if (submitOtp?.status?.lowercase(Locale.ROOT) == Constants.FAILED) {
                        disableSubmittingTabToPause()
                        visibleManualOtpUI()
                        disableManualOtpSubmitButton()
                        titleTextChange(applicationContext.getString(R.string.payu_submit_otp))
                        if (null != submitOtp.attemptsLeft && submitOtp.attemptsLeft!! > 0) {

                            if (!submitOtpResponse.metaData.message.isNullOrEmpty()) {
                                errorMessage.value = submitOtpResponse.metaData.message
                            }
                        } else {
                            addAnalytics(
                                Constants.TRNX_STATUS,
                                Constants.FAILURE
                            )
                            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentFailure(
                                null,
                                response
                            )
                            finish()
                        }
                    } else if (submitOtp?.status == Constants.SUCCESS
                    ) {
                        addAnalytics(
                            Constants.TRNX_STATUS,
                            Constants.SUCCESS
                        )

                        PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentSuccess(
                            null,
                            response
                        )
                        vibrationAfterSuccess()
                        finish()
                    }
                }
            }

        } catch (e: JSONException) {
            onError(
                Constants.SOMETHING_WENT_WRONG_ERROR_CODE,
                Constants.SOMETHING_WENT_WRONG_ERROR,
                Constants.HANDLE_SUBMIT_OTP_RESPONSE
            )
        }
    }

    private fun disableSubmittingTabToPause() {
        enableTabToPause.value = false
    }

    private fun visibleManualOtpUI() {
        visibleManualOtpUI.value = true
    }

    @SuppressLint("MissingPermission")
    private fun vibrationAfterSuccess() {
        val shouldVibrateAfterPaymentSuccess =
            PayUOtpAssistCurrentState?.payUOtpAssistConfig?.shouldVibrateAfterPaymentSuccess
        if (shouldVibrateAfterPaymentSuccess == true) {
            if (UiUtils.isPermissionAvailable(applicationContext, Manifest.permission.VIBRATE)) {
                val v = applicationContext.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator?
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(
                        VibrationEffect.createOneShot(
                            500,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
                } else {
                    //deprecated in API 26
                    v?.vibrate(500)
                }
            }
        }
    }

    internal fun launchChromeCustomTab(payUInitiatePaymentResponse: PayUInitiatePaymentResponse?) {
        shouldCloseBottomSheet.value = true
        cctUrl =
            Utils.extractUrlFromAcsTemplate(payUInitiatePaymentResponse?.result?.acsTemplate ?: "")
        if (URLUtil.isValidUrl(cctUrl)) {
            CheckSecureTxnStatusApiManager.callHashGenerationFunction()
            startChromeCustomTab.value = true
        } else {
            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onError(
                Constants.INVALID_URL_ERROR_CODE.toString(),
                Constants.INVALID_URL_ERROR_MESSAGE
            )
        }
    }

    fun closeTabSession() {
        mClient = null
        mSession = null
    }

    private val mConnection: CustomTabsServiceConnection = object : CustomTabsServiceConnection() {
        override fun onCustomTabsServiceConnected(
            name: ComponentName,
            client: CustomTabsClient
        ) {
            mClient = client

            // Warm up the browser process
            mClient?.warmup(0 /* placeholder for future use */)
            // Create a new browser session
            mSession = mClient?.newSession(object : CustomTabsCallback() {
                override fun onNavigationEvent(navigationEvent: Int, extras: Bundle?) {
                    currentState = navigationEvent
                }

                override fun extraCallback(callbackName: String, args: Bundle?) {
                    super.extraCallback(callbackName, args)

                    if (callbackName == Constants.OPEN_IN_BROWSER) {
                        isOpenInChrome = true
                    }
                }
            })
            // Pre-render pages the user is likely to visit
            // you can do this any time while the service is connected
            mSession?.mayLaunchUrl(Uri.parse(cctUrl), null, null)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            mClient = null
            mSession = null
        }
    }

    internal fun bindCustomTabService(context: Context) {
        // Check for an existing connection
        if (mClient != null) {
            // Do nothing if there is an existing service connection
            return
        }

        // Get the default browser package name, this will be null if
        // the default browser does not provide a CustomTabsService
        val packageName = CustomTabsClient.getPackageName(context, listOf(CHROME_PACKAGE_NAME))
            ?: return  // Do nothing as service connection is not supported
        CustomTabsClient.bindCustomTabsService(
            context,
            CHROME_PACKAGE_NAME,
            mConnection
        )
    }

    internal fun setActivity(activity: Activity?) {
        mActivity = activity
    }

    internal fun closeCustomTab(response: String) {
        Handler((Looper.getMainLooper())).post {
            responseString = response
            mActivity?.let {
                val intent = Intent(it, it::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                intent.putExtra(Constants.RESPONSE, response)
                mActivity?.startActivity(intent)
            }
        }
    }

    fun handleInitiatePaymentResponse(response: String) {
        try {
            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentInitiate(response)
            payUInitiatePaymentResponse = Utils.getInitiatePaymentModel(response)
            if (PayUOtpAssistCurrentState.payUOtpAssistConfig?.isSdkLessFlow == true && !payUInitiatePaymentResponse?.sdkLessResponse?.redirectUrl.isNullOrEmpty() && payUInitiatePaymentResponse?.sdkLessResponse?.redirectUrl != "null") {
                CheckSecureTxnStatusApiManager.callHashGenerationFunction()
                showSDkLessIntent.value = payUInitiatePaymentResponse?.sdkLessResponse
            }
            else if(PayUOtpAssistCurrentState.payUOtpAssistConfig?.shouldShowSecureWebView == true){
                launchChromeCustomTab(payUInitiatePaymentResponse)
                referenceId = payUInitiatePaymentResponse?.metaData?.referenceId
            } else if (null != payUInitiatePaymentResponse?.metaData && null != payUInitiatePaymentResponse?.binData) {
                if (payUInitiatePaymentResponse?.metaData?.unmappedStatus.equals("success", true)) {
                    PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentSuccess(
                        null,
                        response
                    )
                    vibrationAfterSuccess()
                    finish()
                } else {
                    when (payUInitiatePaymentResponse?.metaData?.txnStatus) {
                        Constants.ENROLLED, Constants.PENDING -> {
                            if (null != payUInitiatePaymentResponse?.binData?.issuingBank && null != payUInitiatePaymentResponse?.binData?.category) {
                                bankIssuerLiveData.value =
                                    payUInitiatePaymentResponse?.binData?.issuingBank + " " + payUInitiatePaymentResponse?.binData?.category
                            }
                            if (payUInitiatePaymentResponse?.binData?.pureS2SSupported!!
                                || !payUInitiatePaymentResponse?.result?.otpPostUrl.isNullOrEmpty()
                            ) {
                                //Webflow Testing
                                /*        val issuerUrlData = "MD="+payUInitiatePaymentResponse.result?.postToBank?.MD+"&"+"PaReq="+payUInitiatePaymentResponse.result?.postToBank?.PaReq+"&"+"TermUrl="+payUInitiatePaymentResponse.result?.postToBank?.TermUrl
                                        val payUAcsRequest =PayUAcsRequest()
                                        payUAcsRequest.issuerUrl = payUInitiatePaymentResponse.result?.issuerUrl
                                        payUAcsRequest.issuerPostData = issuerUrlData
                                        val shouldHandleFallback =PayUOtpAssistCurrentState.payUOtpAssistCallback?.shouldHandleFallback(payUAcsRequest)
                                        addAnalytics(Constants.OTP_ASSIST_SHOULD_HANDLE_FALLBACK,shouldHandleFallback.toString())

                                        if (true==PayUOtpAssistCurrentState.payUOtpAssistCallback?.shouldHandleFallback(payUAcsRequest)) {

                                            if (!payUInitiatePaymentResponse.metaData?.referenceId.isNullOrEmpty())
                                                referenceId =
                                                    payUInitiatePaymentResponse.metaData?.referenceId

                                            shouldCloseBottomSheet.value = true
                                            Log.v("okhttp",
                                                "IssuerUrl Postdata =============>>>>>>>>>> $issuerUrlData"
                                            )
                                            postDataForIssuerUrl.value = issuerUrlData

                                            issuerUrlLoad.value =
                                                payUInitiatePaymentResponse.result?.issuerUrl
        //
                                        }
                                        else{
                                            finish()
                                        }*/
                                transactionFlow = Constants.NATIVE_FLOW
                                addAnalytics(
                                    Constants.OTP_ASSIST_EVENT,
                                    Constants.PAYMENT_OPTION + "_" + Constants.NATIVE_FLOW
                                )
                                showNativeFlow.value = response
                                showWaitOtpTimerForResendOtp()
                                titleTextChange(applicationContext.getString(R.string.payu_auto_reading_otp))
                                //OTP on the fly supported
                                otpUrl = payUInitiatePaymentResponse?.result?.otpPostUrl
                                referenceId =
                                    payUInitiatePaymentResponse?.metaData?.referenceId
                                showWaitOtpTimerTransactionValidity()

                            } else {
                                navigateToBankPageView()
                            }
                        }

                        else -> {

                            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentFailure(
                                null,
                                response
                            )
                            finish()
                        }
                    }
                }
            } else {
                errorResponse.value = Constants.UN_EXPECTED_RESPONSE_ERROR_MESSAGE
                finish()
            }

        } catch (e: JSONException) {
            errorResponse.value = Constants.UN_EXPECTED_RESPONSE_ERROR_MESSAGE
            finish()
        }

    }

    fun titleTextChange(text: String) {
        titleText.value = text
    }

    fun onCloseBottomSheet() {
        shouldOpenCancelDialog.value = true
    }

    fun onClickLinkToBankPage() {
        shouldOpenConfirmationDialog.value = true
    }

    override fun onTimeUpdate(p0: TimeAnimator?, p1: Long, p2: Long) {
        mCurrentLevelLiveData.value = mCurrentLevel
        if (mCurrentLevel >= maxLevel) {
            cancelAnimatorLiveData.value = true
        } else {
            mCurrentLevel = maxLevel.coerceAtMost(mCurrentLevel + levelIncrement)
        }
    }

    fun initAnimationListener() {
        animatorListnerLiveData.value = this
    }

    fun consentDenial() {
        countDownTimer?.onFinish()
    }

    fun checkIsLoadingInProgress() {
        if (showSDkLessIntent.value == null) {
            isIntiatingPaymentInProgressLiveData.value = isIntiatingPaymentInProgress
            isSubmitOtpApiInProgressLiveData.value = isSubmitOtpApiInProgress
        } else {
            showLoadingProgressBarMessage.value =
                applicationContext.getString(R.string.payu_confirming_your_payment)
        }
    }

    fun showWaitOtpTimer() {
        if (null != PayUOtpAssistCurrentState.payUOtpAssistConfig?.waitingTime) {
            countDownTimer = object :
                CountDownTimer(PayUOtpAssistCurrentState.payUOtpAssistConfig?.waitingTime!!, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    waitingOtpTextLiveData.value = applicationContext.getString(
                        R.string.payu_tap_to_enter_otp,
                        millisUntilFinished / 1000
                    )
                }

                override fun onFinish() {
                    timerStopLiveData.value = true
                    titleTextChange(applicationContext.getString(R.string.payu_submit_otp))

                }
            }.start()
        }
    }

    private fun dismissTimers() {
        countDownTimerForTransactionvalidity?.cancel()
        countDownTimer?.cancel()
        diableTimerForResendOtpCountDownTimer?.cancel()
        countDownTimerForMessageChange?.cancel()
        countDownTimer = null
        countDownTimerForTransactionvalidity = null
        diableTimerForResendOtpCountDownTimer = null
        countDownTimerForMessageChange = null
    }

    private fun showWaitOtpTimerTransactionValidity() {
        countDownTimerForTransactionvalidity = object :
            CountDownTimer(transactionTimeOut.toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {

            }

            override fun onFinish() {
//               toastMessage.value= "Transaction Time out"
                if (!isSubmitOtpApiInProgress) {

                    cancelTransaction()
                    onError(
                        Constants.BANK_PAGE_TIME_OUT_ERROR_CODE,
                        Constants.BANK_PAGE_TIME_OUT_ERROR_MESSAGE,
                        Constants.SHOW_WAIT_OTP_TIMER_TRANSACTION_VALIDITY
                    )
                    finish()
                }
            }
        }.start()
    }

    private fun dismissTimerMessageChange() {
        countDownTimerForMessageChange?.cancel()
    }

    private fun timerForWaitingTimerMessageChange() {
        countDownTimerForMessageChange = object :
            CountDownTimer(10000, 1000) {
            override fun onTick(millisUntilFinished: Long) {

            }

            override fun onFinish() {
                if (isSubmitOtpApiInProgress)
                    showLoadingProgressBarMessage.value =
                        applicationContext.getString(R.string.payu_confirming_your_payment_with_delay)
            }
        }.start()
    }

    fun enableManualOtpSubmitButton() {
        enableOtpSubmitButton.value = true
    }

    fun disableManualOtpSubmitButton() {
        enableOtpSubmitButton.value = false
    }

    fun showWaitOtpTimerForResendOtp() {
        enableResendOtp.value = false
        diableTimerForResendOtpCountDownTimer = object :
            CountDownTimer(15000, 1000) {
            override fun onTick(millisUntilFinished: Long) {

            }

            override fun onFinish() {
                Log.v("okhttp", "Enable it")
                if (attemptLeft > 0) {
                    enableResendOtp.value = true
                }
                resendOtpText.value = applicationContext.getString(R.string.payu_otp_resend_otp)
            }
        }.start()
    }

    fun userCancelTransaction() {
        if (UiUtils.isInternetAvailable(applicationContext)) {
            if (null != otpUrl && null != referenceId) {
                val mPayUNetWorkHandler = PayUNetworkHandler()
                val payUNetworkData = PayUNetworkData()
                payUNetworkData.request =
                    "referenceId=$referenceId&${Constants.CANCEL_TRANSACTION}=1"
                payUNetworkData.url = otpUrl!!
                payUNetworkData.type = Constants.USER_CANCEL_TRANSACTION
                logKibanaApiInfo(
                    payUNetworkData.url,
                    payUNetworkData.request,
                    payUNetworkData.requestType
                )
                mPayUNetWorkHandler.executeApi(payUNetworkData, this)
            }
            onError(
                Constants.CANCEL_TRANSACTION_ERROR_CODE,
                Constants.CANCEL_TRANSACTION_ERROR_MESSAGE,
                Constants.USER_CANCEL_TRANSACTION
            )
            finish()

        } else {
            finish()
            onError(
                Constants.NO_INTERNET_ERROR_CODE,
                Constants.NO_INTERNET_ERROR,
                Constants.USER_CANCEL_TRANSACTION
            )

        }
    }

    fun cancelTransaction() {
        if (UiUtils.isInternetAvailable(applicationContext)) {

            if (null != referenceId && PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl != null) {
                val mPayUNetWorkHandler = PayUNetworkHandler()
                val payUNetworkData = PayUNetworkData()
//                payUNetworkData.request =
//                    "referenceId=$referenceId&${Constants.CANCEL_TRANSACTION}=1"
//                https://secure.payu.in/payuAuth?enableRetry=1&mihpayid={mihpayid}&status={status}
                payUNetworkData.url =
                    PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl + "payuAuth?enableRetry=1&mihpayid=$referenceId&status=6"
                payUNetworkData.type = Constants.CANCEL_TRANSACTION
                logKibanaApiInfo(
                    payUNetworkData.url,
                    payUNetworkData.request,
                    payUNetworkData.requestType
                )
                mPayUNetWorkHandler.executeApi(payUNetworkData, this)
            }

        } else {
            finish()
            onError(
                Constants.NO_INTERNET_ERROR_CODE,
                Constants.NO_INTERNET_ERROR,
                Constants.CANCEL_TRANSACTION
            )
        }
    }

    fun cancelTransactionPayTxn(isErrorCallbackNeeded: Boolean = true) {
        if (UiUtils.isInternetAvailable(applicationContext)) {
            if (!referenceId.isNullOrEmpty() && PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl != null) {
                val mPayUNetWorkHandler = PayUNetworkHandler()
                val payUNetworkData = PayUNetworkData()
                payUNetworkData.url =
                    PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl + referenceId + "/" + Constants.PAYU_PAYTXN
                payUNetworkData.type = Constants.PAYU_PAYTXN
                payUNetworkData.cookiesList =
                    UiUtils.getCookieList(
                        applicationContext,
                        PayUOtpAssistCurrentState.payUOtpAssistConfig?.paymentUrl
                    )!!
                logKibanaApiInfo(
                    payUNetworkData.url,
                    payUNetworkData.request,
                    payUNetworkData.requestType
                )
                mPayUNetWorkHandler.executeApi(payUNetworkData, this)
            }
            if (isErrorCallbackNeeded) {
                onError(
                    Constants.CANCEL_TRANSACTION_ERROR_CODE,
                    Constants.CANCEL_TRANSACTION_ERROR_MESSAGE,
                    Constants.CANCEL_TRANSACTION_PAY_TXN
                )
            }
            finish()
        } else {
            onError(
                Constants.NO_INTERNET_ERROR_CODE,
                Constants.NO_INTERNET_ERROR,
                Constants.CANCEL_TRANSACTION_PAY_TXN
            )
            finish()
        }
    }

    fun navigateToBankPageView() {

        if (!payUInitiatePaymentResponse?.result?.issuerUrl.isNullOrEmpty()
        ) {
            shouldCloseBottomSheet.value = true
            val issuerUrlData =
                "MD=" + payUInitiatePaymentResponse?.result?.postToBank?.MD + "&" + "PaReq=" + payUInitiatePaymentResponse?.result?.postToBank?.PaReq + "&" + "TermUrl=" + payUInitiatePaymentResponse?.result?.postToBank?.TermUrl

            transactionFlow = Constants.WEB_FLOW_THROUGH_ISSUER_URL
            addAnalytics(
                Constants.OTP_ASSIST_EVENT,
                Constants.PAYMENT_OPTION + "_" + Constants.WEB_FLOW_THROUGH_ISSUER_URL
            )
            val payUAcsRequest = PayUAcsRequest()
            payUAcsRequest.issuerUrl = payUInitiatePaymentResponse?.result?.issuerUrl
            payUAcsRequest.issuerPostData = issuerUrlData
            val shouldHandleFallback =
                PayUOtpAssistCurrentState.payUOtpAssistCallback?.shouldHandleFallback(payUAcsRequest)
            if (null != shouldHandleFallback) {
                addAnalytics(
                    Constants.OTP_ASSIST_EVENT,
                    Constants.OTP_ASSIST_SHOULD_HANDLE_FALLBACK + "_" + shouldHandleFallback.toString()
                )
                if (true == shouldHandleFallback) {
                    postDataForIssuerUrl.value = issuerUrlData
                    issuerUrlLoad.value =
                        payUInitiatePaymentResponse?.result?.issuerUrl
                    if (!payUInitiatePaymentResponse?.metaData?.referenceId.isNullOrEmpty())
                        referenceId =
                            payUInitiatePaymentResponse?.metaData?.referenceId
                } else {
                    finish()
                }
            } else {
                finish()
            }
        } else if (!payUInitiatePaymentResponse?.result?.acsTemplate.isNullOrEmpty()
        ) {
            transactionFlow = Constants.WEB_FLOW_THROUGH_ACS_TEMPLATE
            addAnalytics(
                Constants.OTP_ASSIST_EVENT,
                Constants.PAYMENT_OPTION + "_" + Constants.WEB_FLOW_THROUGH_ACS_TEMPLATE
            )
            shouldCloseBottomSheet.value = true
            val acsTemplate = UiUtils.getBase64DecodedString(
                payUInitiatePaymentResponse?.result?.acsTemplate
            )
            val payUAcsRequest = PayUAcsRequest()
            payUAcsRequest.acsTemplate = acsTemplate
            payUAcsRequest.issuerPostData = postData
            val shouldHandleFallback =
                PayUOtpAssistCurrentState.payUOtpAssistCallback?.shouldHandleFallback(payUAcsRequest)
            if (null != shouldHandleFallback) {
                addAnalytics(
                    Constants.OTP_ASSIST_EVENT,
                    Constants.OTP_ASSIST_SHOULD_HANDLE_FALLBACK + "_" + shouldHandleFallback.toString()
                )

                if (true == shouldHandleFallback) {

                    acsTemplateToLoad.value =
                        acsTemplate
                    if (!payUInitiatePaymentResponse?.metaData?.referenceId.isNullOrEmpty())
                        referenceId =
                            payUInitiatePaymentResponse?.metaData?.referenceId
                } else {
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    internal fun logKibanaApiInfo(requestUrl: String, requestBody: String, requestMethod: String) {
        addAnalytics(
            Constants.API,
            Constants.REQUEST_URL + requestUrl + Constants.REQUEST_BODY + requestBody + Constants.REQUEST_METHOD + requestMethod
        )
    }

    internal fun logKibanaApiResponseInfo(response: String) {
        addAnalytics(Constants.API, Constants.API_RESPONSE + response)
    }

    fun getCctUrl(): String {
        return cctUrl
    }

    fun getResponseString(): String {
        return responseString
    }

    fun getSession(): CustomTabsSession? {
        return mSession
    }

    fun getCurrentState(): Int {
        return currentState
    }

    fun getIsOpenInChrome(): Boolean {
        return isOpenInChrome
    }

    fun hideProgressDialog() {
        showProgressDialog.value = false
    }

    fun showAlertDialog() {
        showAlertDialog.value = true
    }

    fun hideAlertDialog() {
        showAlertDialog.value = false
    }

    internal fun makePayment(packageName: String, intentUri: String?, fragment: OtpAssistFragment) {
        val intent = Intent()
        intent.setPackage(packageName)
        intent.setAction(Intent.ACTION_VIEW)
        val uri: Uri
        if (null != intentUri && intentUri.length > 0) {
            uri = Uri.parse(intentUri)
            intent.setData(uri)
        }

        if (fragment.requireActivity().packageManager != null && intent.resolveActivity(fragment.requireActivity().packageManager!!) != null) {
            fragment.startActivityForResult(intent, Constants.PAYMENT_REQUEST_CODE)
        }
    }

    internal fun verifyPayment() {
        showLoadingProgressBarMessage.value =
            applicationContext.getString(R.string.payu_confirming_your_payment)
        CheckSecureTxnStatusApiManager.callApi()
    }

}