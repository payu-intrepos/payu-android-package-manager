package com.payu.otpassist

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat.getColor
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.UiUtils
import com.payu.otpassist.utils.Utils
import com.payu.otpassist.viewmodel.PayUOtpAssistViewModel
import com.payu.otpparser.FragCallback
import com.payu.otpparser.OtpCallback
import com.payu.otpparser.OtpParser


class PayUOtpAssistDialogFragment : BottomSheetDialogFragment(), View.OnClickListener, OtpCallback,
    FragCallback {
    private var waitingForOtp: RelativeLayout? = null
    private var rlContent: RelativeLayout? = null
    private var llCloseTransparent: LinearLayout? = null
    private var rlManualOtpSubmit: RelativeLayout? = null
    private var llProgressScreen: LinearLayout? = null
    private var rlCancelLayout: RelativeLayout? = null
    private var rlSubmittingOtpTapToPause: RelativeLayout? = null
    private var tvWaitingForOtp: TextView? = null
    private var rlClose: RelativeLayout? = null
    private var etEnterOtpEditTextSubmitOtp: EditText? = null
    private var resentOtp: TextView? = null
    private var ivMerchantLogo: ImageView? = null
    private var tvErrorMsg: TextView? = null
    private var btnSubmitOtpManual: Button? = null
    private var tvNo: TextView? = null
    private var tvPayUOtpAmount: TextView? = null
    private var tvMaskedCardNumber: TextView? = null
    private var btnYes: Button? = null
    private var btnSubmittingOtpTapToPause: Button? = null
    private var tvTitleText: TextView? = null
    private var tvCardInfo: TextView? = null
    private var layerDrawable: LayerDrawable? = null
    private var mAnimator: TimeAnimator? = null
    private var mClipDrawable: ClipDrawable? = null
    private var otpParser: OtpParser? = null
    private var fetchedOtp: String? = null
    private var isUserPausedSubmitOtp = false
    private var linkToBankPage: TextView? = null
    private var tvDoYouWantToCancel: TextView? = null
    private var tvCancelPaymentTitleText: TextView? = null
    private var linkToBankPageLayout: RelativeLayout? = null
    private var rlmerchanntDetailsLayout: RelativeLayout? = null
    private var alphaColor = ""
    private var tvProgressPleaseWait: TextView? = null

    companion object {
        lateinit var viewModel: PayUOtpAssistViewModel

        fun getPayUOtpAssistViewModel(): PayUOtpAssistViewModel?{
            return if(::viewModel.isInitialized)
                viewModel
            else
                null
        }
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         * @return A new instance of fragment RoundedCornerBottomSheet.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(viewModel: PayUOtpAssistViewModel): PayUOtpAssistDialogFragment {
            this.viewModel = viewModel
            return PayUOtpAssistDialogFragment()
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        otpParser = OtpParser.getInstance(requireActivity())
        otpParser?.setFragCallback(this)
        setStyle(STYLE_NORMAL, R.style.PayU_Otp_CustomBottomSheetDialogTheme)
        viewModel.fetchMerchantDetailsToShow()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        otpParser?.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() {
        super.onResume()
        dialog?.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event?.action == KeyEvent.ACTION_UP) {
                viewModel.onCloseBottomSheet()
            }
            false
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.bottom_sheet_otp_assist, container, false)
        btnSubmittingOtpTapToPause = view?.findViewById(R.id.btnSubmittingOtpTapToPause)
        layerDrawable = btnSubmittingOtpTapToPause?.background as LayerDrawable
        mClipDrawable = layerDrawable?.findDrawableByLayerId(R.id.clip_drawable) as ClipDrawable
        mAnimator = TimeAnimator()
        alphaColor = Utils.addAlpha(
            java.lang.String.format(
                "#%06X",
                0xFFFFFF and getColor(requireContext(), R.color.payu_otp_assist_primary_color)
            ), 0.68
        ).toString()
        val backgroundDrawable = layerDrawable?.getDrawable(0)
        val progressDrawable = layerDrawable?.getDrawable(1)
        backgroundDrawable?.setColorFilter(
            Color.parseColor(alphaColor), PorterDuff.Mode.SRC_IN
        )
        progressDrawable?.setColorFilter(
            getColor(requireContext(), R.color.payu_otp_assist_primary_color),
            PorterDuff.Mode.SRC_IN
        )
        rlClose = view?.findViewById(R.id.rlClose)
        tvWaitingForOtp = view?.findViewById(R.id.tvWaitingForOtp)
        etEnterOtpEditTextSubmitOtp = view?.findViewById(R.id.etEnterOtpEditTextSubmitOtp)
        viewModel.disableManualOtpSubmitButton()
        waitingForOtp = view?.findViewById(R.id.waitingForOtp)
        rlManualOtpSubmit = view?.findViewById(R.id.rlManualOtpSubmit)
        llProgressScreen = view?.findViewById(R.id.llProgressScreen)

        rlContent = view?.findViewById(R.id.rlContent)
        rlCancelLayout = view?.findViewById(R.id.rlCancelLayout)
        llCloseTransparent = view?.findViewById(R.id.llCloseTransparent)
        rlSubmittingOtpTapToPause = view?.findViewById(R.id.rlSubmittingOtpTapToPause)
        btnSubmitOtpManual = view?.findViewById(R.id.btnSubmitOtpManual)
        resentOtp = view?.findViewById(R.id.resentOtp)
        linkToBankPage = view?.findViewById(R.id.linkToBankPage)
        tvErrorMsg = view?.findViewById(R.id.tvErrorMsg)
        tvNo = view?.findViewById(R.id.tvNo)
        tvPayUOtpAmount = view?.findViewById(R.id.tvPayUOtpAmount)
        tvMaskedCardNumber = view?.findViewById(R.id.tvMaskedCardNumber)
        linkToBankPageLayout = view?.findViewById(R.id.linkToBankPageLayout)
        rlmerchanntDetailsLayout = view?.findViewById(R.id.rlmerchanntDetailsLayout)
        tvCancelPaymentTitleText = view?.findViewById(R.id.tvCancelPaymentTitleText)
        tvDoYouWantToCancel = view?.findViewById(R.id.tvDoYouWantToCancel)
        btnYes = view?.findViewById(R.id.btnYes)
        tvTitleText = view?.findViewById(R.id.tvTitleText)
        tvCardInfo = view?.findViewById(R.id.tvCardInfo)
        ivMerchantLogo = view?.findViewById(R.id.ivMerchantLogo)
        tvProgressPleaseWait = view?.findViewById(R.id.tvProgressPleaseWait)
        val payuLoader: AppCompatImageView? = view?.findViewById(R.id.payu_loader)
        payuLoader?.let { UiUtils.applyLoopingAnimatedVectorDrawable(it, activity) }
        tvNo?.setOnClickListener(this)
        btnYes?.setOnClickListener(this)
        llProgressScreen?.setOnClickListener(this)
        btnSubmittingOtpTapToPause?.setOnClickListener(this)
        tvWaitingForOtp?.setOnClickListener(this)
        waitingForOtp?.setOnClickListener(this)
        rlManualOtpSubmit?.setOnClickListener(this)
        rlSubmittingOtpTapToPause?.setOnClickListener(this)
        btnSubmitOtpManual?.setOnClickListener(this)
        rlClose?.setOnClickListener(this)
        resentOtp?.setOnClickListener(this)
        linkToBankPage?.setOnClickListener(this)
        initialState()
        addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.FRAGMENT_INIT)
        UiUtils.hideKeyboardFrom(requireContext(), llCloseTransparent!!)
        addObserver()
        mAnimator?.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                super.onAnimationEnd(animation)
                if (!isUserPausedSubmitOtp) viewModel.submitOtp(fetchedOtp!!, false)
            }
        })
        val textWatcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.length!! in 4..8) viewModel.enableManualOtpSubmitButton()
                else viewModel.disableManualOtpSubmitButton()
            }
        }
        etEnterOtpEditTextSubmitOtp?.addTextChangedListener(textWatcher)

        viewModel.disableManualOtpSubmitButton()

        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        UiUtils.updateLayoutSecurity(
            requireActivity(),
            PayUOtpAssistCurrentState.payUOtpAssistConfig?.isProtectedScreen ?: false
        )
    }

    override fun onDetach() {
        super.onDetach()
        UiUtils.updateLayoutSecurity(requireActivity(), false)
    }

    @SuppressLint("ResourceType")
    private fun addObserver() {
        viewModel.toastMessage.observe(viewLifecycleOwner) {
            showToast(it)
        }
        viewModel.merchantIcon.observe(viewLifecycleOwner) {
            ivMerchantLogo?.setImageDrawable(it)
        }

        viewModel.errorMessage.observe(viewLifecycleOwner) {
            tvErrorMsg?.visibility = View.VISIBLE
            tvErrorMsg?.text = it
            tvErrorMsg?.startAnimation(
                AnimationUtils.loadAnimation(
                    requireContext(), R.anim.payu_error_text_shake
                )
            )
            rlContent?.visibility = View.VISIBLE
            llCloseTransparent?.visibility = View.VISIBLE
            rlCancelLayout?.visibility = View.GONE
            llProgressScreen?.visibility = View.GONE
            addAnalytics(Constants.OTP_ASSIST_EVENT, "Error Message $it")
        }
        viewModel.enableResendOtp.observe(viewLifecycleOwner) {
            resentOtp?.isEnabled = it
            if (!it) {
                resentOtp?.setTextColor(
                    getColor(
                        requireActivity(), R.color.payu_otp_assist_disable_color
                    )
                )
                linkToBankPageLayout?.visibility = View.INVISIBLE
            } else {
                UiUtils.updateTextColor(
                    requireContext(),
                    resentOtp,
                    PayUOtpAssistCurrentState.payUOtpAssistConfig?.primaryColor,
                    R.color.payu_otp_assist_primary_color
                )

                linkToBankPageLayout?.visibility = View.VISIBLE
            }
        }
        viewModel.resendOtpText.observe(viewLifecycleOwner) {
            resentOtp?.text = it
        }
        viewModel.enableOtpSubmitButton.observe(viewLifecycleOwner) {
            btnSubmitOtpManual?.isEnabled = it
            if (!it) {

                btnSubmitOtpManual?.backgroundTintList = ColorStateList.valueOf(
                    getColor(
                        requireActivity(), R.color.payu_otp_assist_disable_color
                    )
                )

            } else {
                UiUtils.updateBackgroundColor(
                    requireContext(),
                    btnSubmitOtpManual,
                    PayUOtpAssistCurrentState.payUOtpAssistConfig?.primaryColor,
                    R.color.payu_otp_assist_primary_color
                )

            }
        }
        viewModel.titleText.observe(viewLifecycleOwner) {
            tvTitleText?.text = it

            if (it == requireActivity().getString(R.string.payu_submitting_otp)) {
                resentOtp?.visibility = View.GONE
            } else resentOtp?.visibility = View.VISIBLE
        }

        viewModel.animatorListnerLiveData.observe(viewLifecycleOwner) {
            mAnimator?.setTimeListener(it)
        }

        viewModel.bankIssuerLiveData.observe(viewLifecycleOwner) {
            tvCardInfo?.text = it
            if (it.contains(Constants.CREDIT_CARD)) {
                tvCardInfo?.text =
                    it.replace(Constants.CREDIT_CARD, getString(R.string.payu_otp_creditcard))
            } else if (it.contains(Constants.DEBIT_CARD)) {
                tvCardInfo?.text =
                    it.replace(Constants.DEBIT_CARD, getString(R.string.payu_otp_debitcard))
            } else tvCardInfo?.text = it

        }

        viewModel.waitingOtpTextLiveData.observe(viewLifecycleOwner) {
            tvWaitingForOtp?.text = it

        }

        viewModel.timerStopLiveData.observe(viewLifecycleOwner) {
            rlSubmittingOtpTapToPause?.visibility = View.GONE
            waitingForOtp?.visibility = View.GONE
            rlManualOtpSubmit?.visibility = View.VISIBLE
            if (etEnterOtpEditTextSubmitOtp?.isShown!!) openKeyBoard()

        }
        viewModel.visibleManualOtpUI.observe(viewLifecycleOwner) {
            if (it) {
                waitingForOtp?.visibility = View.GONE
                rlSubmittingOtpTapToPause?.visibility = View.GONE
                rlCancelLayout?.visibility = View.GONE
                rlManualOtpSubmit?.visibility = View.VISIBLE
            }

        }

        viewModel.mCurrentLevelLiveData.observe(viewLifecycleOwner) {
            mClipDrawable?.level = it
        }

        viewModel.cancelAnimatorLiveData.observe(viewLifecycleOwner) {
            mAnimator?.cancel()
        }


        resentOtp?.isEnabled = true
        viewModel.shouldOpenCancelDialog.observe(viewLifecycleOwner) {
            if (it) {
                rlContent?.visibility = View.GONE
                llCloseTransparent?.visibility = View.GONE
                llProgressScreen?.visibility = View.GONE
                rlCancelLayout?.visibility = View.VISIBLE

                UiUtils.updateBackgroundColor(
                    btnYes, PayUOtpAssistCurrentState.payUOtpAssistConfig?.primaryColor
                )

                tvCancelPaymentTitleText?.setText(R.string.payu_cancel_payment)
                tvDoYouWantToCancel?.setText(R.string.payu_do_you_really_want_to_cancel_the_payment)
                addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.CANCEL_DIALOG_SHOWN)
            }

        }
        viewModel.shouldOpenConfirmationDialog.observe(viewLifecycleOwner) {
            if (it) {
                rlContent?.visibility = View.GONE
                llCloseTransparent?.visibility = View.GONE
                llProgressScreen?.visibility = View.GONE
                rlCancelLayout?.visibility = View.VISIBLE

                UiUtils.updateBackgroundColor(
                    btnYes, PayUOtpAssistCurrentState.payUOtpAssistConfig?.primaryColor
                )

                tvCancelPaymentTitleText?.setText(R.string.payu_confirmation_payment_to_bankPage)
                tvDoYouWantToCancel?.setText(R.string.payu_do_you_proceed_to_bank_page)
                addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.CONFIRMATION_DIALOG_SHOWN)
            }

        }

        viewModel.enableTabToPause.observe(viewLifecycleOwner) {
            if (it) rlSubmittingOtpTapToPause?.visibility = View.VISIBLE
            else rlSubmittingOtpTapToPause?.visibility = View.GONE

        }

        viewModel.fetchedOtp.observe(viewLifecycleOwner) {
            fetchedOtp = it
            rlContent?.visibility = View.VISIBLE
            llCloseTransparent?.visibility = View.VISIBLE
            rlCancelLayout?.visibility = View.GONE
            llProgressScreen?.visibility = View.GONE
            if (waitingForOtp?.visibility == View.VISIBLE) {
                if (!PayUOtpAssistCurrentState.payUOtpAssistConfig?.shouldAllowAutoSubmit!!) {
                    waitingForOtp?.visibility = View.GONE
                    rlManualOtpSubmit?.visibility = View.VISIBLE
                    viewModel.titleTextChange(getString(R.string.payu_submit_otp))
                    etEnterOtpEditTextSubmitOtp?.setText(it)
                    etEnterOtpEditTextSubmitOtp?.clearFocus()
//                    etEnterOtpEditTextSubmitOtp?.requestFocus()
//                    etEnterOtpEditTextSubmitOtp?.placeCursorToEnd()

                    rlSubmittingOtpTapToPause?.visibility = View.GONE
                } else {
                    resentOtp?.visibility = View.GONE
                    waitingForOtp?.visibility = View.GONE
                    rlManualOtpSubmit?.visibility = View.GONE
                    setOtpFetchedTextOnAnimatedBtn()
                    rlSubmittingOtpTapToPause?.visibility = View.VISIBLE
                    viewModel.titleTextChange(getString(R.string.payu_submitting_otp))
                    if (!mAnimator?.isRunning!!) {
                        mAnimator?.start()
                    }

                }
            } else {
                waitingForOtp?.visibility = View.GONE
                rlManualOtpSubmit?.visibility = View.VISIBLE
                etEnterOtpEditTextSubmitOtp?.setText(it)
                etEnterOtpEditTextSubmitOtp?.clearFocus()
                etEnterOtpEditTextSubmitOtp?.requestFocus()
                etEnterOtpEditTextSubmitOtp?.placeCursorToEnd()
                rlSubmittingOtpTapToPause?.visibility = View.GONE
            }


        }

        viewModel.showLoadingProgressBarMessage.observe(viewLifecycleOwner) {
            rlContent?.visibility = View.GONE
            llCloseTransparent?.visibility = View.GONE
            rlCancelLayout?.visibility = View.GONE
            llProgressScreen?.visibility = View.VISIBLE
            tvProgressPleaseWait?.text = it
        }

        viewModel.amountLiveData.observe(viewLifecycleOwner) {
            tvPayUOtpAmount?.text = it
        }

        viewModel.cardNumberLiveData.observe(viewLifecycleOwner) {
            tvMaskedCardNumber?.text = it
        }

        viewModel.isSubmitOtpApiInProgressLiveData.observe(viewLifecycleOwner) {
            if (it || (null != viewModel.isIntiatingPaymentInProgressLiveData.value && viewModel.isIntiatingPaymentInProgressLiveData.value!!)) {
                rlContent?.visibility = View.GONE
                llCloseTransparent?.visibility = View.GONE
                rlCancelLayout?.visibility = View.GONE
                llProgressScreen?.visibility = View.VISIBLE
            } else {
                rlCancelLayout?.visibility = View.GONE
                rlContent?.visibility = View.VISIBLE
                llCloseTransparent?.visibility = View.VISIBLE

            }
        }
        viewModel.isIntiatingPaymentInProgressLiveData.observe(viewLifecycleOwner) {
            if (it || (null != viewModel.isSubmitOtpApiInProgressLiveData.value && viewModel.isSubmitOtpApiInProgressLiveData.value!!)) {
                rlContent?.visibility = View.GONE
                llCloseTransparent?.visibility = View.GONE
                rlCancelLayout?.visibility = View.GONE
                llProgressScreen?.visibility = View.VISIBLE
            } else {
                rlCancelLayout?.visibility = View.GONE
                rlContent?.visibility = View.VISIBLE
                llCloseTransparent?.visibility = View.VISIBLE

            }
        }

        viewModel.showNativeFlow.observe(viewLifecycleOwner) {
            viewModel.showWaitOtpTimer()
            rlContent?.visibility = View.VISIBLE
            rlSubmittingOtpTapToPause?.visibility = View.GONE
            waitingForOtp?.visibility = View.VISIBLE
            rlManualOtpSubmit?.visibility = View.GONE

            llCloseTransparent?.visibility = View.VISIBLE
            rlCancelLayout?.visibility = View.GONE
            llProgressScreen?.visibility = View.GONE
            otpParser?.startListening(
                this, Utils.createBundleForParserAnalytics(
                    Utils.getDataFromPostData(PayUOtpAssistCurrentState.payUOtpAssistConfig?.postData)
                )
            )
        }
    }

    private fun initialState() {
        viewModel.fetchInitialValues()
        viewModel.initAnimationListener()
        rlContent?.visibility = View.GONE
        llCloseTransparent?.visibility = View.GONE
        rlCancelLayout?.visibility = View.GONE
        llProgressScreen?.visibility = View.VISIBLE
        PayUOtpAssistCurrentState.payUOtpAssistConfig?.shouldShowMerchantSummary?.let {
            if (!it) {
                rlmerchanntDetailsLayout?.visibility = View.GONE
            }
        }
    }


    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    private fun openKeyBoard() {
        etEnterOtpEditTextSubmitOtp?.clearFocus()
        etEnterOtpEditTextSubmitOtp?.requestFocus()
//                      etEnterOtpEditTextSubmitOtpubmitOtp?.setText("")
        val imm: InputMethodManager =
            ((requireActivity()).getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        imm.showSoftInput(etEnterOtpEditTextSubmitOtp, InputMethodManager.SHOW_IMPLICIT)
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.tvWaitingForOtp -> {
                viewModel.titleTextChange(getString(R.string.payu_submit_otp))
                waitingForOtp?.visibility = View.GONE
                rlManualOtpSubmit?.visibility = View.VISIBLE
                rlSubmittingOtpTapToPause?.visibility = View.GONE
                etEnterOtpEditTextSubmitOtp?.setText(fetchedOtp)
                etEnterOtpEditTextSubmitOtp?.placeCursorToEnd()
                openKeyBoard()
            }

            R.id.btnSubmittingOtpTapToPause -> {
                isUserPausedSubmitOtp = true
                if (mAnimator?.isRunning!!) {
                    mAnimator?.cancel()

                }
                viewModel.titleTextChange(getString(R.string.payu_submit_otp))
                waitingForOtp?.visibility = View.GONE
                rlManualOtpSubmit?.visibility = View.VISIBLE
                rlSubmittingOtpTapToPause?.visibility = View.GONE
                etEnterOtpEditTextSubmitOtp?.setText(fetchedOtp)
                etEnterOtpEditTextSubmitOtp?.placeCursorToEnd()
            }

            R.id.resentOtp -> {
                otpParser?.startListening(this)
                viewModel.resendOtp()
            }

            R.id.rlClose -> {
                UiUtils.hideKeyboardFrom(requireActivity(), rlClose!!)
                viewModel.onCloseBottomSheet()
            }

            R.id.btnSubmitOtpManual -> {
                if (null != activity && !activity?.isFinishing!! && !activity?.isDestroyed!! && null != etEnterOtpEditTextSubmitOtp) UiUtils.hideKeyboardFrom(
                    requireActivity(),
                    btnSubmitOtpManual!!
                )
                if (etEnterOtpEditTextSubmitOtp?.text?.length!! in 4..8) viewModel.submitOtp(
                    etEnterOtpEditTextSubmitOtp?.text.toString()
                )
            }

            R.id.tvNo -> {

                viewModel.checkIsLoadingInProgress()
                if (true == viewModel.shouldOpenConfirmationDialog.value) {
                    viewModel.shouldOpenConfirmationDialog.value = false
                    viewModel.addAnalytics(
                        Constants.OTP_ASSIST_EVENT, Constants.BANK_REDIRECT_CONFIRM_NO
                    )
                } else {
                    viewModel.addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.CANCEL_CONFIRM_NO)

                }
            }

            R.id.btnYes -> {
                if (viewModel.shouldOpenConfirmationDialog.value == true) {
                    viewModel.navigateToBankPageView()
                    viewModel.addAnalytics(
                        Constants.OTP_ASSIST_EVENT, Constants.BANK_REDIRECT_CONFIRM_YES
                    )
                } else {
                    viewModel.addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.CANCEL_CONFIRM_YES)
                    viewModel.userCancelTransaction()
                    dismiss()
                }
            }

            R.id.linkToBankPage -> {
                viewModel.onClickLinkToBankPage()
            }
        }
    }


    override fun onOtpReceived(otp: String) {
        viewModel.setFetchedOtp(otp)
        addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.OTP_FETCHED)
    }

    override fun onUserDenied() {
        viewModel.consentDenial()

    }

    private fun setOtpFetchedTextOnAnimatedBtn() {
        val str =
            "${getString(R.string.payu_otp)} $fetchedOtp - ${getString(R.string.payu_tap_to_pause)}"
        btnSubmittingOtpTapToPause?.text = str

    }

    private fun EditText.placeCursorToEnd() {
        this.setSelection(this.text.length)
    }

    private fun addAnalytics(key: String, value: String) {
        viewModel.addAnalytics(key, value)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        otpParser?.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    internal fun AppCompatImageView.applyLoopingAnimatedVectorDrawable(@DrawableRes avdResId: Int) {
        val animated = AnimatedVectorDrawableCompat.create(context, avdResId)
        animated?.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                this@applyLoopingAnimatedVectorDrawable.post { animated.start() }
            }
        })
        this.setImageDrawable(animated)
        animated?.start()
    }

    override fun onFragCallback(intent: Intent?, requestCode: Int) {
        startActivityForResult(intent, requestCode)
    }
}
