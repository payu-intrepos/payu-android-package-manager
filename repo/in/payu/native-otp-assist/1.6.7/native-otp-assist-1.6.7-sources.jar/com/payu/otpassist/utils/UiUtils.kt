package com.payu.otpassist.utils

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.CookieSyncManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.payu.otpassist.BuildConfig
import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.R
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUDeviceAnalytics
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.net.URLEncoder
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

object UiUtils {

    const val TAG = "PAYU"
    private const val VERBOSE = Log.VERBOSE
    @Synchronized
    fun longLog(str: String) {
        if (isLogEnabled(VERBOSE)) {
            if (str.length > 4000) {
                Log.v(
                    TAG,
                    str.substring(0, 4000)
                )
                longLog(str.substring(4000))
            } else Log.v(TAG, str)
        }
    }

    private fun isLogEnabled(level: Int): Boolean {
        return Log.isLoggable(TAG, level)
    }

    fun hideKeyboard(activity: Activity) {
        val imm: InputMethodManager =
            activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        var view: View? = activity.currentFocus
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun hideKeyboardFrom(context: Context, view: View) {
        val imm =
            context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun getBase64EncodingString(data: String?): String? {
//        val data: ByteArray = data.getBytes("UTF-8")
        return Base64.encodeToString(data?.toByteArray(), Base64.DEFAULT)
    }

    fun getBase64DecodedString(data: String?): String? {
        return try {
            String(Base64.decode(data, Base64.DEFAULT))
        } catch (e: IllegalArgumentException) {
            null
        }
    }


    /**
     * Return list of cookie of the given domain
     * @param appContext application context
     * @param domainName name of domain
     * @return cookie string
     */
    fun getCookieList(
        appContext: Context?,
        domainName: String?
    ): String? {
        var cookieString = ""
        try {
            val cookieManager =
                CookieManager.getInstance()
            if (Build.VERSION.SDK_INT < 21) {
                CookieSyncManager.createInstance(appContext)
                CookieSyncManager.getInstance().sync()
            }
            val cookies =
                cookieManager.getCookie(domainName) // return string of all cookie for the given domain
            if (cookies != null) {
                val temp = cookies.split(";".toRegex()).toTypedArray()
                for (ar1 in temp) {
                    val cookiesNameValue =
                        ar1.split("=".toRegex()).toTypedArray()
                    cookieString += cookiesNameValue[0] + "=" + cookiesNameValue[1] + ";"
                }
            }
            if (cookieString.isNotEmpty()) {
                cookieString = cookieString.substring(0, cookieString.length - 1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return cookieString
    }

    fun getAlertDialog(
        activity: Activity?,
        onClickDialog: DialogInterface.OnClickListener?,
        positiveText: String?,
        negativeText: String?,
        title: String?,
        message: String?
    ): AlertDialog.Builder? {
        val alertbox =
            AlertDialog.Builder(activity, R.style.PayU_Otp_Acs_Cancel_Dialog)
        if (onClickDialog != null) {
            if (title != null) alertbox.setTitle(title)
            if (message != null) alertbox.setMessage(message)
            if (positiveText != null) alertbox.setPositiveButton(positiveText, onClickDialog)
            if (negativeText != null) alertbox.setNegativeButton(negativeText, onClickDialog)
        }
        return alertbox
    }

    fun getAppIcon(context: Context): Drawable {
        val applicationInfo: ApplicationInfo =
            context.packageManager.getApplicationInfo(
                context.packageName,
                PackageManager.GET_META_DATA
            )
        val res: Resources = context.packageManager.getResourcesForApplication(applicationInfo)
        return res.getDrawableForDensity(
            applicationInfo.icon,
            DisplayMetrics.DENSITY_XXXHIGH,
            null
        )!!
    }

    /**
     * Logging device analytics events.
     *
     * @param sdkMerchantKey, merchant key
     * @param context       activity instance
     * @param txnId  Merchant Transaction Id
     */
    fun deviceAnalytics(
        sdkMerchantKey: String?,
        context: Context?,
        txnId: String?
    ) {
        val activity =
            WeakReference(context)
        if (null != context
        ) {
            val deviceDetails = JSONObject()
            val payuDeviceAnalytics: PayUDeviceAnalytics
            try {
                deviceDetails.put(Constants.TXNID, txnId)
                deviceDetails.put(Constants.MERCHANT_KEY, sdkMerchantKey)
                deviceDetails.put(
                    Constants.DEVICE_OS_VERSION,
                    Build.VERSION.SDK_INT.toString() + ""
                )

                deviceDetails.put(Constants.DEVICE_MANUFACTURE, Build.MANUFACTURER)
                deviceDetails.put(Constants.DEVICE_MODEL, Build.MODEL)
                deviceDetails.put(Constants.SDK_VERSION_NAME, BuildConfig.VERSION_NAME)
                deviceDetails.put(Constants.PACKAGE_NAME, activity.get()!!.packageName)
                payuDeviceAnalytics =
                    AnalyticsFactory(activity.get()!!.applicationContext).getAnalyticsClass(
                        AnalyticsType.PAYU_DEVICE_ANALYTICS
                    ) as PayUDeviceAnalytics
                payuDeviceAnalytics.log(deviceDetails.toString())
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
    }

    fun getLogMessage(
        context: Context,
        key: String?,
        value: String?,
        sdkMerchantKey: String?,
        trnxID: String?
    ): String? {
        return try {
            val eventAnalytics = JSONObject()
            eventAnalytics.put(Constants.TXNID, trnxID)
            eventAnalytics.put(Constants.MERCHANT_KEY, sdkMerchantKey)
            eventAnalytics.put(Constants.EVENT_KEY, key)
            eventAnalytics.put(Constants.VALUE, URLEncoder.encode(value, "UTF-8"))
            eventAnalytics.put(Constants.PACKAGE_NAME, context.packageName)
            eventAnalytics.put(
                Constants.TIMESTAMP,
                getSystemCurrentTime()
            )

            eventAnalytics.put(
                Constants.VERSION_CODE,
                getVersionCode(context)
            )
            eventAnalytics.toString()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            "{}"
        }
    }


    /**
     * Return system current time of system
     *
     * @return system current time in string
     */
    private fun getSystemCurrentTime(): String? {
        try {
            val currentDate = Date(System.currentTimeMillis())
            val df: DateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            return df.format(currentDate)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
        return ""
    }

    fun getVersionCode(context: Context): String? {
        try {
            val pInfo =
                context.packageManager.getPackageInfo(context.packageName, 0)
            return pInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return ""
    }

    fun isInternetAvailable(context: Context): Boolean {
        var result = false

        if (context == null)
            return result

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            result = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_WIFI -> true
                        ConnectivityManager.TYPE_MOBILE -> true
                        ConnectivityManager.TYPE_ETHERNET -> true
                        else -> false
                    }

                }
            }
        }

        return result
    }

    fun isPermissionAvailable(context: Context, permission: String?): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            permission!!
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun updateBackgroundColor(view: View?, color: Int?) {
        if (color != null && view != null && view.background != null) {
            view?.backgroundTintList =
                ColorStateList.valueOf(color)
        }
    }

    fun updateProgressbarColor(view: ProgressBar?, color: Int?) {
        if (color != null && view != null) {
            view?.indeterminateTintList =
                ColorStateList.valueOf(PayUOtpAssistCurrentState.payUOtpAssistConfig?.primaryColor!!)
        }
    }

    fun updateTextColor(context: Context, view: TextView?, color: Int?, defaultColor: Int) {
        if (color != null)
            view?.setTextColor(color)
        else
            view?.setTextColor(ContextCompat.getColor(context, defaultColor))
    }

    fun updateBackgroundColor(context: Context, view: View?, color: Int?, defaultColor: Int) {
        if (color != null && view != null && view.background != null) {
            view?.backgroundTintList =
                ColorStateList.valueOf(color)
        } else view?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(context, defaultColor))
    }

    fun applyLoopingAnimatedVectorDrawable(ivProgress: AppCompatImageView, context: Context? ) {
        val animated = context?.let { AnimatedVectorDrawableCompat.create(it, R.drawable.payu_loader) }
        ivProgress.setImageDrawable(animated)
        if (animated != null) {
            animated.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
                override fun onAnimationEnd(drawable: Drawable) {
                    animated.start()
                }
            })
            animated.start()
        }
    }

    internal fun updateLayoutSecurity(activity: Activity, isSecure: Boolean) {
        if (isSecure) {
            activity.window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

}