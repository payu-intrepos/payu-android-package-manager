package com.payu.otpassist.apis

import android.os.Handler
import android.os.Looper
import com.payu.otpassist.PayUOtpAssistCurrentState
import com.payu.otpassist.listeners.OnCheckSecureTxnStatusListener
import com.payu.otpassist.listeners.PayUHashGenerationListener
import com.payu.otpassist.models.CheckTxnStatusModel
import com.payu.otpassist.models.HashCommand
import com.payu.otpassist.utils.Constants
import com.payu.otpassist.utils.HashGenerationUtils
import com.payu.otpassist.utils.PostDataGenerationUtils
import com.payu.otpassist.viewmodel.PayUOtpAssistViewModel
import org.json.JSONObject
import java.util.*

object CheckSecureTxnStatusApiManager : OnCheckSecureTxnStatusListener, PayUHashGenerationListener {

    internal var timer: Timer? = Timer()
    internal var payUOtpAssistViewModel: PayUOtpAssistViewModel? = null
    internal var hashCallTimerCount = 0
    internal var apiCallTimerCount = 0
    internal var checkTxnStatusHash: String? = null
    internal var checkTxnStatusKey: String? = null
    internal var checkTxnStatusDate: String? = null
    internal var checkTxnStatusBody: String? = null

    fun callHashGenerationFunction() {
        checkTxnStatusBody = PostDataGenerationUtils.generatePostData(HashCommand.CheckTxnStatusHash.hashName)
        callHashGeneration(checkTxnStatusBody)
    }

    fun callHashGeneration(checkTxnStatusBody: String?) {
        val hashMap = HashGenerationUtils.getHash(checkTxnStatusBody ?: "")

        PayUOtpAssistCurrentState.payUOtpAssistCallback?.generateHash(
            hashMap,
            this@CheckSecureTxnStatusApiManager
        )
    }


    fun callApi() {
        timer = Timer()
        timer?.schedule(
            object : TimerTask() {
                override fun run() {
                    if(apiCallTimerCount != 0 && apiCallTimerCount % Constants.HASH_RETRY_COUNT == 0 && !checkTxnStatusHash.isNullOrEmpty()) {

                        Handler((Looper.getMainLooper())).postDelayed(
                            {
                                hashCallTimerCount = 0
                                checkTxnStatusHash = null
                                callHashGeneration(checkTxnStatusBody)
                            },Constants.NEW_HASH_TIME_INTERVAL)

                    }

                    apiCallTimerCount++
                    if (apiCallTimerCount > Constants.API_CALL_TIMOUT_COUNT) {
                        onError(Constants.API_CALL_TIMEOUT_ERROR_CODE, Constants.API_CALL_TIMEOUT_ERROR_MESSAGE)
                    } else if (!checkTxnStatusHash.isNullOrEmpty()) {
                        CheckSecureTxnStatusApi.callAPI(
                            checkTxnStatusHash!!,
                            this@CheckSecureTxnStatusApiManager
                        )
                    } else if (hashCallTimerCount < Constants.HASH_TIMOUT_COUNT) {
                        hashCallTimerCount++
                    } else {
                        onError(
                            Constants.INVALID_HASH_ERROR_CODE,
                            Constants.INVALID_HASH_ERROR_MESSAGE
                        )
                    }
                }
            },
            Constants.CHECK_STATUS_TIME_INTERVAL, Constants.CHECK_STATUS_TIME_INTERVAL // 10 seconds
        ) // 1000 Millisecond  = 1 second

    }

    override fun onSuccess(checkTxnStatusModel: CheckTxnStatusModel) {
        if (checkTxnStatusModel.status == 0) {
            if(timer != null) {
                timer?.cancel()
                timer = null
                PayUOtpAssistCurrentState.payUOtpAssistCallback?.onError(
                    checkTxnStatusModel.status.toString(),
                    checkTxnStatusModel.msg
                )
            }
        } else {
            checkTxnStatusModel.result?.let {
                val resultJson = JSONObject(it)
                payUOtpAssistViewModel?.hideProgressDialog()
                when (resultJson.getString(Constants.STATUS)) {
                    Constants.PENDING -> {
                        if(payUOtpAssistViewModel?.getIsOpenInChrome() == true) {
                            payUOtpAssistViewModel?.showAlertDialog()
                        }
                    }
                    Constants.SUCCESS -> {
                        payUOtpAssistViewModel?.closeCustomTab(checkTxnStatusModel.result ?: "")
                        if(timer != null) {
                            timer?.cancel()
                            timer = null
                            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentSuccess(
                                checkTxnStatusModel.result,
                                checkTxnStatusModel.result
                            )
                        }
                    }
                    else -> {
                        payUOtpAssistViewModel?.closeCustomTab(checkTxnStatusModel.result ?: "")
                        if(timer != null) {
                            timer?.cancel()
                            timer = null
                            PayUOtpAssistCurrentState.payUOtpAssistCallback?.onPaymentFailure(
                                checkTxnStatusModel.result,
                                checkTxnStatusModel.result
                            )
                        }
                    }
                }

            }
        }
    }

    override fun onError(errorCode: Int, errorMessage: String) {
        payUOtpAssistViewModel?.closeCustomTab("")
        if(timer != null) {
            timer?.cancel()
            timer = null
            Handler((Looper.getMainLooper())).post {
                    PayUOtpAssistCurrentState.payUOtpAssistCallback?.onError(
                        errorCode.toString(),
                        errorMessage
                    )
                }
        }
        payUOtpAssistViewModel?.addAnalytics(Constants.OTP_ASSIST_EVENT, Constants.ERROR)
    }

    override fun onHashGenerated(map: HashMap<String, String?>) {
        val hash = map[HashCommand.CheckTxnStatusHash.hashName]
        if (hash.isNullOrEmpty()) {
            onError(Constants.INVALID_HASH_ERROR_CODE, Constants.INVALID_HASH_ERROR_MESSAGE)
        } else {
            checkTxnStatusHash = hash
        }
    }
}