package com.payu.otpassist.widgets

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import com.payu.otpassist.R
import com.payu.otpassist.utils.UiUtils
import java.util.*

class PayUProgressDialog(context: Context, view: View?) :
    Dialog(context, R.style.Theme_AppCompat_Light_NoActionBar) {
    var ivProgress: AppCompatImageView? = null
    private var tvMessage: TextView? = null
    private val mActivity: Activity?
    private var layout: View? = null

    /**
     * Displaying Payuloader.
     *
     * @param context base activity context
     * @param view    Custom Progress Dialog Layout if any
     */
    init {
        mActivity = context as Activity?
        val mInflater = LayoutInflater.from(context)
        if (null != view) {
            layout = view
            if (view.parent != null) {
                val parent = view.parent as ViewGroup
                parent.removeView(view)
            }
            layout?.let{
                setContentView(it)
            }
        } else {
            //Default PayU progress Dialog
            layout = mInflater.inflate(R.layout.payu_prog_dialog_otpassist, null, false)
            layout?.let{ it1 ->
                setContentView(it1)
                tvMessage = it1.findViewById<View>(R.id.tvMessage) as? TextView
                ivProgress = it1.findViewById<View>(R.id.upi_payu_loader) as? AppCompatImageView
                ivProgress?.let {
                        UiUtils.applyLoopingAnimatedVectorDrawable(it, mActivity)
                }
            }
        }
        setCancelable(true)
        setCanceledOnTouchOutside(false)
    }
}