package com.payu.otpassist.models

class BinData {
    var pureS2SSupported = false
    var issuingBank: String? = ""
    var category: String? = ""
    var cardType: String? = ""
    var isDomestic: Boolean? = false
}
