package com.payu.otpassist.models

data class SubmitOtpResponse(
    val metaData: MetaData1?
)

data class MetaData1(
    var message: String? = "",
    var referenceId: String? = "",
    var statusCode: String? = "",
    var submitOtp: SubmitOtp?,
    var txnId: String? = "",
    var unmappedStatus: String? = ""
)


data class SubmitOtp(
    var status: String? = "",
    var attemptsLeft: Int?
)