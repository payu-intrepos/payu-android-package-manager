package com.payu.otpassist.models

class ErrorResponse {
    var errorCode: Int? = null
    var errorMessage: String? = null
}