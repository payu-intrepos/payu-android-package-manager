package com.payu.otpassist.models
/*
 redirectType and redirectUrl two params , redirectType is not getting used now but may be in future implementations
* */

data class SdkLessResponse(var redirectUrl: String?, var redirectType: String?)
