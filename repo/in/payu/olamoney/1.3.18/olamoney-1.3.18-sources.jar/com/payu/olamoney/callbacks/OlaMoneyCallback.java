package com.payu.olamoney.callbacks;

public interface OlaMoneyCallback {

    void onPaymentInitialisationSuccess();

   void onPaymentInitialisationFailure(int errorCode, String description);


}
