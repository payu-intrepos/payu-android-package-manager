package com.payu.olamoney;

import android.app.Activity;
import android.os.AsyncTask;
import android.text.TextUtils;

import com.payu.olamoney.callbacks.OlaMoneyCallback;
import com.payu.olamoney.utils.L;
import com.payu.olamoney.utils.OlaMoneyConstants;
import com.payu.olamoney.utils.OlaMoneyUtil;
import com.payu.olamoney.utils.PayUOlaMoneyParams;
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

public class OlaMoneyHandler implements PayuNetworkAsyncTaskInterface {

    private WeakReference<Activity> reference;
    private JSONObject responseJson;
    private PayUAnalytics payUAnalytics;
    private PayUOlaMoneyParams olaMoneyParams;

    private OlaMoneyCallback callback;

    /**
     * @param activity
     * @param callback
     * @param olaMoneyParams
     */
    void checkForPaymentAvailability(Activity activity, OlaMoneyCallback callback, PayUOlaMoneyParams olaMoneyParams) {
        this.callback = callback;
        L.v("Ola checkForPaymentAvailability");
        if (null == callback) {
            throw new IllegalStateException(OlaMoneyConstants.PAYU_OLA_MONEY_CALLBACK_CANNOT_BE_NULL);
        }

        this.reference = new WeakReference<>(activity);
          this.payUAnalytics = (PayUAnalytics) new AnalyticsFactory(activity.getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
        if (isMandatoryParamAvailable(olaMoneyParams)) {
            String webServiceUrl = OlaMoneyUtil.getWebServiceUrl(reference.get());
            if (!TextUtils.isEmpty(webServiceUrl)) {
                this.olaMoneyParams = olaMoneyParams;
                logAnalytics(olaMoneyParams);
                PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
                browserAsyncTaskData.setHttpMethod(OlaMoneyConstants.POST);
                browserAsyncTaskData.setUrl(webServiceUrl);
                browserAsyncTaskData.setPostData(getPaymentAvailabilityPostData(olaMoneyParams.getMerchantKey(), olaMoneyParams).trim());
                L.v("PostData OlaMoney eligibility " + browserAsyncTaskData.getPostData());
                new PayUNetworkAsyncTask(this, OlaMoneyConstants.CHECK_ELIGIBILITY).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);

            } else {
                L.v(OlaMoneyConstants.EMPTY_WEB_SERVICE_URL);
            }
        } else {
            callback.onPaymentInitialisationFailure(OlaMoneyConstants.OLA_MONEY_ERROR_CODE_MANDATORY_PARAMS_MISSING, OlaMoneyConstants.OLA_MONEY_ERROR_CODE_MANDATORY_PARAMS_MISSING_MESSAGE);
        }
    }

    private void logAnalytics(PayUOlaMoneyParams olaMoneyParams) {
        OlaMoneyUtil.deviceAnalytics(olaMoneyParams.getMerchantKey(), reference, olaMoneyParams.getTxnId());
        payUAnalytics.log(OlaMoneyUtil.getLogMessage(reference.get(), OlaMoneyConstants.PAYMENT_OPTION, OlaMoneyConstants.OLA_MONEY, olaMoneyParams.getMerchantKey(), olaMoneyParams.getTxnId()));

    }

    private Boolean isMandatoryParamAvailable(PayUOlaMoneyParams olaMoneyParams) {

        if (null != olaMoneyParams && !TextUtils.isEmpty(olaMoneyParams.getAmount()) && !TextUtils.isEmpty(olaMoneyParams.getFirstName())
                && !TextUtils.isEmpty(olaMoneyParams.getTxnId()) && !TextUtils.isEmpty(olaMoneyParams.getMobile()) && !TextUtils.isEmpty(olaMoneyParams.getHash())
                && !TextUtils.isEmpty(olaMoneyParams.getMerchantKey())) {
            return true;
        }
        return false;
    }


    private void onApiReponse(String response) {

        if (isValidJson(response)) {
           if (null != payUAnalytics && null != reference && !reference.get().isFinishing()  && !reference.get().isDestroyed() &&  null != olaMoneyParams.getMerchantKey() && null != olaMoneyParams.getTxnId()) {
               payUAnalytics.log(OlaMoneyUtil.getLogMessage(reference.get(), OlaMoneyConstants.ELIGIBILITY_STATUS, response, olaMoneyParams.getMerchantKey(), olaMoneyParams.getTxnId()));
           }
            if (responseJson.optInt(OlaMoneyConstants.STATUS) == 1) {

                this.callback.onPaymentInitialisationSuccess();
            } else {

                this.callback.onPaymentInitialisationFailure(OlaMoneyConstants.OLA_MONEY_ERROR_CODE_MANDATORY_PARAMS_MISSING, responseJson.optString(OlaMoneyConstants.MSG));
            }
        } else {
            this.callback.onPaymentInitialisationFailure(OlaMoneyConstants.OLA_MONEY_ERROR_CODE_SOMETHING_WENT_WRONG, OlaMoneyConstants.OLA_MONEY_ERROR_MESSAGE_SOMETHING_WENT_WRONG);
        }

    }

    /**
     *
     */
    private boolean isValidJson(String response) {

        if (null != response) {
            try {
                responseJson = new JSONObject(response);
                if (responseJson.has(OlaMoneyConstants.STATUS) && responseJson.has(OlaMoneyConstants.MSG)) {

                    return true;
                }
            } catch (JSONException ignored) {

            }

        }
        return false;
    }

    /**
     * @param merchantKey
     * @param payUOlaMoneyParams
     * @return
     */
    private String getPaymentAvailabilityPostData(String merchantKey, PayUOlaMoneyParams payUOlaMoneyParams) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("amount", payUOlaMoneyParams.getAmount());

            jsonObject.put("txnid", payUOlaMoneyParams.getTxnId());
            jsonObject.put("mobile_number", payUOlaMoneyParams.getMobile());
            jsonObject.put("first_name", payUOlaMoneyParams.getFirstName());
            jsonObject.put("bankCode", OlaMoneyConstants.OLA_MONEY_BANK_CODE);
            jsonObject.put("email", payUOlaMoneyParams.getEmail());
//        if(payUOlaMoneyParams.lastName?.length>0)
            jsonObject.put("last_name", payUOlaMoneyParams.getLastName());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return OlaMoneyConstants.COMMAND + OlaMoneyConstants.GET_ELIGIBLE_PAYMENT_OPTIONS +
                OlaMoneyConstants.KEY + merchantKey + OlaMoneyConstants.HASH + payUOlaMoneyParams.getHash() + OlaMoneyConstants.VAR1 + jsonObject.toString();
    }

    @Override
    public void onPayuNetworkAsyncTaskResponse(String payUAsyncTaskResponse, String webServiceType) {
        if (webServiceType.equals(OlaMoneyConstants.CHECK_ELIGIBILITY)) {
            onApiReponse(payUAsyncTaskResponse);
        }
    }
}
