package com.payu.olamoney.utils;

import com.payu.paymentparamhelper.PaymentParams;
import com.payu.paymentparamhelper.PaymentPostParams;
import com.payu.paymentparamhelper.PayuConstants;
import com.payu.paymentparamhelper.PostData;


public class PayUOlaMoneyPaymentParams {

    public PostData getPaymentPostData(PaymentParams paymentParams) throws Exception {
        paymentParams.setSdkPlatformData(OlaMoneyUtil.getAnalyticsString(paymentParams.getSdkPlatformData()));
        return new PaymentPostParams(paymentParams, PayuConstants.OLA_MONEY).getPaymentPostParams();

    }
}
