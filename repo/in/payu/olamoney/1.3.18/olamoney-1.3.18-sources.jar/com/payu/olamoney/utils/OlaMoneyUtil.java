package com.payu.olamoney.utils;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.payu.olamoney.BuildConfig;
import com.payu.paymentparamhelper.PayuConstants;
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUDeviceAnalytics;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OlaMoneyUtil {

    /**
     * Provide JSONObject for analytics
     *
     * @param context        application context
     * @param key            analytics event ket
     * @param value          event value
     * @param sdkMerchantKey merchant key
     * @param trnxID         transaction  ID
     * @return
     */
    public static String getLogMessage(Context context, String key, String value, String sdkMerchantKey, String trnxID) {
        try {
            JSONObject eventAnalytics = new JSONObject();
            eventAnalytics.put(OlaMoneyConstants.TXNID, trnxID);
            eventAnalytics.put(OlaMoneyConstants.MERCHANT_KEY, sdkMerchantKey);
            eventAnalytics.put(OlaMoneyConstants.EVENT_KEY, key);
            eventAnalytics.put(OlaMoneyConstants.VALUE, URLEncoder.encode(value, "UTF-8"));
            eventAnalytics.put(OlaMoneyConstants.PACKAGE_NAME, context.getPackageName());
            eventAnalytics.put(OlaMoneyConstants.SDK_VERSION_NAME, BuildConfig.VERSION_NAME);
            eventAnalytics.put(OlaMoneyConstants.TIMESTAMP, getSystemCurrentTime());
            eventAnalytics.put(OlaMoneyConstants.VERSION_CODE, getVersionCode(context));
            return eventAnalytics.toString();
        } catch ( Exception e) {
            e.printStackTrace();
            return "{}";
        }

    }

    /**
     * Return system current time of system
     *
     * @return system current time in string
     */
    private static String getSystemCurrentTime() {
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return df.format(currentDate);
        } catch ( Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    private static String getVersionCode(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionName;
        } catch ( PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return "";
    }

    public static String getWebServiceUrl( Activity activity) {

        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = activity.getPackageManager().getApplicationInfo(activity.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = applicationInfo.metaData;
            String webServiceUrl = bundle.getString(OlaMoneyConstants.PAYU_WEB_SERVICE_URL, OlaMoneyConstants.PRODUCTION_BASE_URL);
            webServiceUrl = webServiceUrl + OlaMoneyConstants.MERCHANT_POST_SERVICE_FORM;
            return webServiceUrl;
        } catch (PackageManager.NameNotFoundException e) {
            L.v("Exception metadata " + e.getMessage());
            e.printStackTrace();
        }
        return "";

    }


    /**
     * Logging device analytics events.
     *
     * @param sdkMerchantKey, merchant key
     * @param activity       activity instance
     * @param txnId  Merchant Transaction Id
     */
    public static void deviceAnalytics(String sdkMerchantKey, WeakReference<Activity> activity, String txnId) {
        if (null != activity.get() && !activity.get().isDestroyed() && !activity.get().isFinishing()) {
            JSONObject deviceDetails = new  JSONObject();
            PayUDeviceAnalytics payuDeviceAnalytics;
            try {
                deviceDetails.put(OlaMoneyConstants.TXNID, txnId);
                deviceDetails.put(OlaMoneyConstants.MERCHANT_KEY, sdkMerchantKey);
                deviceDetails.put(OlaMoneyConstants.DEVICE_OS_VERSION, Build.VERSION.SDK_INT + "");
                deviceDetails.put(OlaMoneyConstants.DEVICE_RESOLUTION, getDeviceDensity(activity.get()));
                deviceDetails.put(OlaMoneyConstants.DEVICE_MANUFACTURE, Build.MANUFACTURER);
                deviceDetails.put(OlaMoneyConstants.DEVICE_MODEL, Build.MODEL);

                deviceDetails.put(OlaMoneyConstants.PACKAGE_NAME, activity.get().getPackageName());
                payuDeviceAnalytics = (PayUDeviceAnalytics) new AnalyticsFactory(activity.get().getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_DEVICE_ANALYTICS);
                payuDeviceAnalytics.log(deviceDetails.toString());
            } catch ( Exception e) {
                e.printStackTrace();
            }

        }
    }
    private static String getDeviceDensity( Activity activity) {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.densityDpi + "";
    }

    static String getAnalyticsString(String sdkPlatformData){
        JSONArray jsonArray = new JSONArray();
        JSONObject object = new JSONObject();
        try {
            if(null == sdkPlatformData){
                jsonArray = new JSONArray();
            }else {
                jsonArray = new JSONArray(sdkPlatformData);
            }
            object.put(PayuConstants.PLATFORM_KEY, OlaMoneyConstants.PLATFORM_VALUE);
            object.put(PayuConstants.NAME_KEY, OlaMoneyConstants.NAME_VALUE);
            object.put(PayuConstants.VERSION_KEY, BuildConfig.VERSION_NAME);
            jsonArray.put(object);
        }catch (JSONException e){
            e.printStackTrace();
        }
        return jsonArray.toString();
    }
}
