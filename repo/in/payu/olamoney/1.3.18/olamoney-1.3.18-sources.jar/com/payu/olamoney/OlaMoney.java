package com.payu.olamoney;

import android.app.Activity;

import com.payu.olamoney.callbacks.OlaMoneyCallback;
import com.payu.olamoney.utils.PayUOlaMoneyParams;

public class OlaMoney {
    public void checkForPaymentAvailability(Activity activity, OlaMoneyCallback callback, PayUOlaMoneyParams olaMoneyParams) {

        OlaMoneyHandler olaMoneyHandler =new  OlaMoneyHandler();
        olaMoneyHandler.checkForPaymentAvailability(activity, callback, olaMoneyParams);

    }


}
