package com.payu.olamoney.utils;

public interface OlaMoneyConstants {
    String PRODUCTION_BASE_URL = "https://info.payu.in";
    String GET_ELIGIBLE_PAYMENT_OPTIONS = "get_eligible_payment_options";
    int OLA_MONEY_ERROR_CODE_MANDATORY_PARAMS_MISSING = 100;
    int OLA_MONEY_ERROR_CODE_SOMETHING_WENT_WRONG = 101;
    String OLA_MONEY_ERROR_CODE_MANDATORY_PARAMS_MISSING_MESSAGE = "Mandatory params are missing. Please check again!";
    String OLA_MONEY_ERROR_MESSAGE_SOMETHING_WENT_WRONG = "Something Went Wrong!";
    String PAYU_OLA_MONEY_CALLBACK_CANNOT_BE_NULL = "PayUOlaMoneyCallback cannot be null";
    //Error Values
    String TXNID = "txnid";
    String POST = "POST";
    String COMMAND = "command=";
    String HASH = "&hash=";
    String KEY = "&key=";
    String VAR1 = "&var1=";
    String STATUS = "status";
    String MSG = "msg";
    String OLA_MONEY_BANK_CODE = "OLAM";
    String DEFAULT = "default";

    String PACKAGE_NAME = "package_name";
    String EVENT_KEY = "event_key";
    String VALUE = "event_value";
    String TIMESTAMP = "ts";
    String VERSION_CODE = "application_version";
    String MERCHANT_KEY = "merchant_key";
    String SDK_VERSION_NAME = "ola_money_sdk_version";
    /*Device Analytics*/
    String DEVICE_OS_VERSION = "os_version";
    String DEVICE_RESOLUTION = "resolution";
    String DEVICE_MANUFACTURE = "device_manufacturer";
    String DEVICE_MODEL = "device_model";


    /*URLs*/
    String MERCHANT_POST_SERVICE_FORM = "/merchant/postservice.php?form=2";


    //Manifest Constants
    String PAYU_WEB_SERVICE_URL = "payu_web_service_url";
    String DEFAULT_VALUE = "default";
    String PAYMENT_OPTION = "payment_option";
    String ELIGIBILITY_STATUS = "eligibility_status";
    String OLA_MONEY = "ola_money";
    //Analytics
    String PLATFORM_KEY = "platform";
    String PLATFORM_VALUE = "android";
    String NAME_KEY = "name";
    String NAME_VALUE = "olamoney";
    String VERSION_KEY = "version";
    String CHECK_ELIGIBILITY = "CHECK_ELIGIBILITY";
    String EMPTY_WEB_SERVICE_URL = "Empty Web Service URL";


}
