package com.payu.threeDS2.utils

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.lang.ref.WeakReference

internal class ActivityResumeWaiter(
    private val timeoutMs: Long = 5_000L
) {
    private val handler = Handler(Looper.getMainLooper())
    private var timeoutRunnable: Runnable? = null
    private var observedActivity: WeakReference<AppCompatActivity>? = null
    private var lifecycleObserver: LifecycleEventObserver? = null
    private var appCallbacks: Application.ActivityLifecycleCallbacks? = null
    private var app: Application? = null

    fun waitForResume(
        activity: Activity,
        onResumed: (AppCompatActivity) -> Unit,
        onGiveUp: () -> Unit
    ) {
        cancel()
        if (activity.isFinishing) {
            onGiveUp()
            return
        }
        val host = activity as? AppCompatActivity
        if (host != null && isResumed(host)) {
            onResumed(host)
            return
        }
        val timeout = Runnable {
            Log.w(TAG, "Host did not resume within ${timeoutMs}ms")
            cancel()
            onGiveUp()
        }
        timeoutRunnable = timeout
        handler.postDelayed(timeout, timeoutMs)
        if (host != null && !host.isDestroyed) {
            observeSame(host, onResumed, onGiveUp)
        } else {
            val application = activity.applicationContext as? Application
            if (application == null) {
                finishWithGiveUp(onGiveUp)
            } else {
                observeNew(activity.javaClass.name, application, onResumed)
            }
        }
    }

    fun cancel() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
        removeLifecycleObserver()
        unregisterAppCallbacks()
    }

    private fun isResumed(activity: AppCompatActivity): Boolean {
        if (activity.isFinishing || activity.isDestroyed) return false
        return activity.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
    }

    private fun observeSame(
        activity: AppCompatActivity,
        onResumed: (AppCompatActivity) -> Unit,
        onGiveUp: () -> Unit
    ) {
        observedActivity = WeakReference(activity)
        val observer = LifecycleEventObserver { source, event ->
            val current = source as? AppCompatActivity ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_RESUME -> completeWithHost(current, onResumed)
                Lifecycle.Event.ON_DESTROY -> onHostDestroyed(current, onResumed, onGiveUp)
                else -> Unit
            }
        }
        lifecycleObserver = observer
        activity.lifecycle.addObserver(observer)
    }

    private fun onHostDestroyed(
        current: AppCompatActivity,
        onResumed: (AppCompatActivity) -> Unit,
        onGiveUp: () -> Unit
    ) {
        removeLifecycleObserver()
        if (current.isFinishing) {
            finishWithGiveUp(onGiveUp)
            return
        }
        val application = current.applicationContext as? Application
        if (application == null) {
            finishWithGiveUp(onGiveUp)
        } else {
            observeNew(current.javaClass.name, application, onResumed)
        }
    }

    private fun observeNew(
        targetClassName: String,
        application: Application,
        onResumed: (AppCompatActivity) -> Unit
    ) {
        val callbacks = object : EmptyActivityCallbacks() {
            override fun onActivityResumed(activity: Activity) {
                if (activity is AppCompatActivity && activity.javaClass.name == targetClassName) {
                    completeWithHost(activity, onResumed)
                }
            }
        }
        appCallbacks = callbacks
        app = application
        application.registerActivityLifecycleCallbacks(callbacks)
    }

    private fun completeWithHost(
        activity: AppCompatActivity,
        onResumed: (AppCompatActivity) -> Unit
    ) {
        cancel()
        onResumed(activity)
    }

    private fun finishWithGiveUp(onGiveUp: () -> Unit) {
        cancel()
        onGiveUp()
    }

    private fun removeLifecycleObserver() {
        lifecycleObserver?.let { observer ->
            observedActivity?.get()?.takeUnless { it.isDestroyed }?.lifecycle?.removeObserver(observer)
        }
        lifecycleObserver = null
        observedActivity = null
    }

    private fun unregisterAppCallbacks() {
        appCallbacks?.let { app?.unregisterActivityLifecycleCallbacks(it) }
        appCallbacks = null
        app = null
    }

    private abstract class EmptyActivityCallbacks : Application.ActivityLifecycleCallbacks {
        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
        override fun onActivityStarted(activity: Activity) {}
        override fun onActivityResumed(activity: Activity) {}
        override fun onActivityPaused(activity: Activity) {}
        override fun onActivityStopped(activity: Activity) {}
        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
        override fun onActivityDestroyed(activity: Activity) {}
    }

    private companion object {
        const val TAG = "ActivityResumeWaiter"
    }
}
