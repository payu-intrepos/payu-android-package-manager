package com.payu.threeDS2.constants

import androidx.annotation.Keep

@Keep
class PayU3DS2Constants {
    @Keep
    companion object {
        const val KEY = "key"
        const val HASH = "hash"
        const val VAR1 = "var1"
        const val VAR2 = "var2"
        const val VAR5 = "var5"
        const val VAR7 = "var7"

        const val AMOUNT = "amount"
        const val TXN_ID = "txnid"
        const val ERROR = "ERROR"

        const val EMPTY_STRING = ""
        const val COMMAND = "command"
        const val SDK_CHALLENGE_TIMEOUT = 5

        const val THREEDS_MERCHANT_KEY = "merchant_key"
        const val THREEDS_EVENT_KEY = "event_key"
        const val THREEDS_EVENT_VALUE = "event_value"
        const val THREEDS_TIMESTAMP = "ts"
        const val THREEDS_SDK_VERSION = "sdk_version"
        const val THREEDS_LOGGING_SDK = "logging_sdk"
        const val THREEDS_LOGGING_SDK_VERSION = "logging_sdk_version"

        const val THREEDS_TXN_ID = "txn_id" //Getting From Payment Param/ Config
        const val MERCHANT_REQUEST_TXN_ID = "request_id" //Getting From ARes
        const val THREEDS_DEVICE_DETAILS = "device_details"
        const val THREEDS_APPLICATION_VERSION = "application_version"
        const val APPLICATION_PACKAGE = "application_package"
        const val BANK_ID = "bank_id"
        const val CLIENT_ID = "client_id"
        const val TIME_TAKEN_MS = "time_taken_ms"
        const val TDY_CARD_ID = "tdy_card_id"
        const val TEMP_CARD_ID = "temp_card_id"
        const val STATUS = "status"
        const val BINDING_TYPE = "binding_type"
        const val OS_VERSION = "os_version"
        const val ACS_TXN_ID = "acs_txn_id"
        const val IS_RECURRING_TRANSACTION = "is_recurring_transaction"
        const val CUSTOMER_ID = "customer_id"
        const val MERCHANT_NAME = "merchant_name"
        const val MERCHANT_ID = "merchant_id"
        const val API_PATH = "api_path"
        const val MESSAGE_TYPE = "message_type"
        const val CARD_TYPE = "card_type"
        const val MERCHANT_MOBILE_NO = "merchant_mobile_no"
        const val TXN_AMOUNT = "txn_amount"
        const val DATA = "data"
        const val HTTP_CODE = "http_code"
        const val ERROR_CODE = "error_code"
        const val DATE = "Date"
        const val REFERENCE_ID = "referenceId"
        const val DD_MM_YY_HH_MM_SS_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        const val OTP_SENT_DEFAULT_MESSAGE = "Successfully sent OTP to your registered mobile number"
        const val EVENT_SEVERITY = "event_severity"
        const val EVENT_TYPE = "event_type"
        const val PLATFORM = "platform"
        const val SDK_NAME = "sdk_name"
        const val SDK_NAME_VALUE = "ThreeDS SDK"
        const val OOB_ELIGIBLE = "OOB_ELIGIBLE"
        const val OTP_RESENT_SUCCESSFULLY = "Resend OTP successful"
        const val DEREGISTER_MESSAGE = "Biometric authentication disabled by user.Please re-register to continue payments without OTP"

        val CLIENT_IDENTIFIER: ByteArray = intArrayOf(
            225, 168, 117, 11, 239, 250, 149, 133,
            29, 181, 184, 130, 121, 109, 100, 158,
            255, 1, 249, 123, 210, 61, 68, 8,
            77, 164, 141, 151, 113, 182, 168,
        ).map { it.toByte() }.toByteArray()
        internal const val ENV_SIGNATURE =
            "4aca36d11d2ef032bb6813d6b8c7122fb79cb4c700b062cf6665706ee8cc3b"
        internal const val CONFIG_VERSION = "xhdyrtOyJdTS7dkUtN4egibpbN+S+Qf3RfKTmvJJ6g=="
        internal const val MIN_TOKEN_LENGTH = 7
        const val AUTH_DERIVE = "AES/"
        const val PAYU_FP_VALUE = "GCM/"
        const val PAYU_FP_MSG = "NoPadding"
        internal const val FRAME_SUFFIX_BITS = 128
        internal const val MATERIAL_BYTE_LENGTH = 32
    }
}