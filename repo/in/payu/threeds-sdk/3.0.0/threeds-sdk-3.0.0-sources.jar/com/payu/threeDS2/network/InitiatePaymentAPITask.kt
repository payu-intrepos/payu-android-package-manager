package com.payu.threeDS2.network

import android.net.Uri
import android.util.Log
import com.payu.paymentparamhelper.HashCommand
import com.payu.paymentparamhelper.PaymentParams
import com.payu.paymentparamhelper.PaymentPostParams
import com.payu.paymentparamhelper.PayuConstants
import com.payu.paymentparamhelper.PostData
import com.payu.threeDS2.config.InternalConfig
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.LoggingConstants.Companion.LOGGING_ERROR_KEY
import com.payu.threeDS2.constants.PayU3DS2Constants
import com.payu.threeDS2.enums.EventSeverity
import com.payu.threeDS2.enums.EventStatus
import com.payu.threeDS2.enums.EventType
import com.payu.threeDS2.interfaces.listeners.PayU3DS2APIService
import com.payu.threeDS2.interfaces.listeners.PayUAsyncTaskResponse
import com.payu.threeDS2.utils.HashGenerationUtils
import com.payu.threeDS2.utils.LoggingUtils
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_BIN_DATA
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_CARD_BIN
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_CRITICALITY_INDICATOR
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_ISSUER_IMAGE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MESSAGE_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MFA_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MFA_NAME
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MFA_PARAMS
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MFA_STATUS
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_PS_IMAGE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MFA_DATA
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TDY_CARD_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TDY_CLIENT_ID
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.HASH_NULL_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.HASH_NULL_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.threedsbase.data.ErrorResponse
import com.payu.threedsbase.data.apiResponse.PayU3DS2MFAParam
import com.payu.threedsbase.data.apiResponse.PArsResponse
import com.payu.threedsbase.interfaces.listeners.PayU3DS2Callback
import com.payu.threedsbase.interfaces.listeners.PayUHashGeneratedListener
import org.json.JSONObject


class InitiatePaymentAPITask(private val apiLayer: PayU3DSAPILayer) : PayU3DS2APIService {
    private var authOnlyValue = APIConstants.AUTH_WITH_PAYU
    override fun callAPI(request: Any, callback: PayU3DS2Callback) {
        val paymentParam = request as PaymentParams
        val hasName = getHashName(paymentParam)
        val startTime = System.currentTimeMillis()
        loggingMsg(
            LoggingConstants.EVENT_VALUE_INIT_PARAMS,
            ""
        )
        loggingMsg(
            LoggingConstants.LEGACY_HASH_REQUESTED,
            "",
            timeTakenMs = System.currentTimeMillis() - startTime
        )
        generateHash(paymentParam, callback, object : PayUHashGeneratedListener {
            override fun onHashGenerated(map: HashMap<String, String>) {
                val hash = map[hasName.hashName]
                if (hash.isNullOrEmpty()) {
                    loggingMsg(
                        LoggingConstants.FAILED,
                        LOGGING_ERROR_KEY + HASH_NULL_ERROR_MESSAGE,
                        errorCode = HASH_NULL_ERROR_CODE,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        timeTakenMs = System.currentTimeMillis() - startTime,
                        eventStatus = EventStatus.Failed
                    )
                    callback.onError(HASH_NULL_ERROR_CODE, HASH_NULL_ERROR_MESSAGE)
                } else {
                    val postData = generatePostData(
                        request as PaymentParams,
                        hash
                    )

                    if ((postData as PostData).status.equals(
                            PayU3DS2Constants.ERROR,
                            ignoreCase = true
                        )
                    ) {
                        loggingMsg(
                            LoggingConstants.FAILED,
                            "${LoggingConstants.LEGACY_ON_ERROR} ${postData.code} ${postData.result}",
                            eventSeverity = EventSeverity.High,
                            eventType = EventType.Error,
                            timeTakenMs = System.currentTimeMillis() - startTime,
                            eventStatus = EventStatus.Failed
                        )
                        callback.onError(postData.code, postData.result)
                    } else {
                        val networkData = PayUNetworkData()
                        networkData.url =
                            if (apiLayer.config.isProduction) APIConstants.SECURE_URL else
                                APIConstants.UAT_SECURE_URL

                        if (InternalConfig.authenticateOnly)
                            authOnlyValue = APIConstants.AUTH_OUTSIDE_PAYU

                        networkData.postRequest =
                            "${postData.result}&${APIConstants.TXN_S2S_FLOW}=${APIConstants.TXN_S2S_FLOW_VALUE}&" +
                                    "${APIConstants.AUTH_ONLY}=${authOnlyValue}&" +
                                    "${APIConstants.TERM_URL}=${if (apiLayer.config.isProduction) APIConstants.TERM_URL_VALUE else APIConstants.UAT_TERM_URL_VALUE}"
                        loggingMsg(
                            LoggingConstants.LEGACY_API_PARAMS,
                            removeThreeDS2RequestData(postData.result),
                            apiPath = networkData.url
                        )
                        PayU3DSAPICall().makePostAPICall(
                            APIConstants.HTTP_REQUEST_TYPE_POST,
                            networkData,
                            object : PayUAsyncTaskResponse {
                                override fun onSuccess(response: Any, executionTime: Long, httpCode: Int?) {
                                    val jsonObject =
                                        JSONObject(response.toString()).optJSONObject(APIConstants.PAYMENT_API_RESULT)
                                    val postToBank =
                                        jsonObject?.optJSONObject(APIConstants.PAYMENT_API_POST_TO_BANK)
                                    if (postToBank == null) {
                                        val error =
                                            JSONObject(response.toString()).optString(APIConstants.ERROR)
                                        if (!error.isNullOrEmpty()) {
                                            loggingMsg(
                                                LoggingConstants.LEGACY_API_FAILED,
                                                LOGGING_ERROR_KEY + error,
                                                eventSeverity = EventSeverity.High,
                                                eventType = EventType.Error,
                                                timeTakenMs = executionTime,
                                                eventStatus = EventStatus.Failed,
                                                apiPath = networkData.url,
                                                httpCode = httpCode
                                            )
                                            if (error.equals(APIConstants.HASH_ERROR_CODE))
                                                callback.onError(
                                                    PayU3DS2ErrorConstants.HASH_ISSUE_ERROR_CODE,
                                                    PayU3DS2ErrorConstants.HASH_ISSUE_ERROR_MESSAGE
                                                )
                                            else {
                                                callback.onError(
                                                    SDK_RESPONSE_STATUS_CODE_1,
                                                    JSONObject(response.toString()).optString(
                                                        APIConstants.PAYMENT_API_ERROR_MESSAGE
                                                    )
                                                )
                                            }
                                        } else {
                                            val metaData =
                                                JSONObject(response.toString()).optJSONObject(
                                                    APIConstants.PAYMENT_API_META_DATA
                                                )
                                            if (metaData != null) {
                                                loggingMsg(
                                                    LoggingConstants.LEGACY_API_FAILED,
                                                    LOGGING_ERROR_KEY + metaData,
                                                    eventSeverity = EventSeverity.High,
                                                    eventType = EventType.Error,
                                                    timeTakenMs = executionTime,
                                                    eventStatus = EventStatus.Failed,
                                                    apiPath = networkData.url,
                                                    httpCode = httpCode
                                                )

                                                callback.onError(
                                                    SDK_RESPONSE_STATUS_CODE_1,
                                                    metaData.optString(APIConstants.PAYMENT_API_ERROR_MESSAGE)
                                                )
                                            } else {
                                                loggingMsg(
                                                    LoggingConstants.LEGACY_API_FAILED,
                                                    LOGGING_ERROR_KEY + PayU3DS2ErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE,
                                                    eventSeverity = EventSeverity.High,
                                                    eventType = EventType.Error,
                                                    timeTakenMs = executionTime,
                                                    eventStatus = EventStatus.Failed,
                                                    apiPath = networkData.url,
                                                    httpCode = httpCode
                                                )
                                                callback.onError(
                                                    SDK_RESPONSE_STATUS_CODE_1,
                                                    PayU3DS2ErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE
                                                )
                                            }
                                        }
                                    } else {
                                        InternalConfig.referenceId =
                                            postToBank.optString(APIConstants.REFERENCE_ID)
                                        val binValue =
                                            JSONObject(response.toString()).optJSONObject(
                                                RBA_BIN_DATA
                                            )
                                                ?.optString(RBA_CARD_BIN)
                                        loggingMsg(
                                            LoggingConstants.LEGACY_API_SUCCESS,
                                            "$jsonObject",
                                            timeTakenMs = executionTime,
                                            eventStatus = EventStatus.Success,
                                            httpCode = httpCode,
                                            apiPath = networkData.url,
                                        )
                                        callback.onSuccess(parseData(binValue, postToBank))
                                    }
                                }

                                override fun onFailure(
                                    errorCode: Int,
                                    errorMessage: String,
                                    executionTime: Long,
                                    httpCode: Int?
                                ) {
                                    loggingMsg(
                                        LoggingConstants.LEGACY_API_FAILED,
                                        LOGGING_ERROR_KEY + errorMessage,
                                        errorCode = errorCode,
                                        eventSeverity = EventSeverity.High,
                                        eventType = EventType.Error,
                                        timeTakenMs = executionTime,
                                        eventStatus = EventStatus.Failed,
                                        apiPath = networkData.url
                                    )
                                    callback.onError(errorCode, errorMessage)
                                }
                            }
                        )
                    }
                }
            }
        })

    }

    override fun validate(paymentParams: PaymentParams): ErrorResponse {
        return ErrorResponse()
    }

    override fun generateHash(
        param: Any,
        callback: PayU3DS2Callback,
        payUHashGeneratedListener: PayUHashGeneratedListener
    ) {
        val hashName = getHashName(param as PaymentParams)
        return HashGenerationUtils.getHash(
            hashName,
            param as PaymentParams,
            callback, payUHashGeneratedListener
        )
    }

    private fun getHashName(paymentParams: PaymentParams): HashCommand {
        return if (paymentParams.siParams != null) HashCommand.SIPaymentHash else HashCommand.PaymentHash
    }

    override fun generatePostData(request: PaymentParams, hash: String, isSi: Boolean): Any? {
        request.hash = hash
        return PaymentPostParams(
            request,
            if (request.pg.isNullOrEmpty().not())
                request.pg
            else
                PayuConstants.CC
        ).paymentPostParams
    }

    private fun parseData(binValue: String?, jsonObject: JSONObject): PArsResponse {
        val parsResponse = PArsResponse()
        parsResponse.cavv = jsonObject.optString(APIConstants.CAVV)
        parsResponse.eci = jsonObject.optString(APIConstants.ECI)
        parsResponse.threeDSTransID = jsonObject.optString(APIConstants.THREE_DS_TRANS_ID)
        parsResponse.threeDSTransStatus =
            jsonObject.optString(APIConstants.THREE_DS_TRANS_STATUS)
        parsResponse.threeDSVersion = jsonObject.optString(APIConstants.THREE_DS_VERSION)
        parsResponse.threeDSTransStatusReason =
            jsonObject.optString(APIConstants.THREE_DS_TRANS_STATUS_REASON)
        parsResponse.threeDSServerTransID =
            jsonObject.optString(APIConstants.THREE_DS_SERVER_TRANS_ID)
        parsResponse.acsSignedContent = jsonObject.optString(APIConstants.ACS_SIGNED_CONTENT)
        parsResponse.acsReferenceNumber = jsonObject.optString(APIConstants.ACS_REFERENCE_NUMBER)
        parsResponse.acsTransID = jsonObject.optString(APIConstants.ACS_TRANS_ID)

        /**
         * Parameters if txn can be done via MFA or card is supported for MFA registration
         */
        jsonObject.optJSONObject(RBA_MFA_PARAMS)?.let { mfaParamsObject ->
            parsResponse.payU3DS2MfaParam = PayU3DS2MFAParam().apply {
                messageType = mfaParamsObject.optStringOrNull(RBA_MESSAGE_TYPE)
                name = mfaParamsObject.optStringOrNull(RBA_MFA_NAME)
                id = mfaParamsObject.optStringOrNull(RBA_MFA_ID)
                criticalityIndicator = mfaParamsObject.optBoolean(RBA_CRITICALITY_INDICATOR)
                status = mfaParamsObject.optStringOrNull(RBA_MFA_STATUS)
                issuerImage = mfaParamsObject.optStringOrNull(RBA_ISSUER_IMAGE)
                psImage = mfaParamsObject.optStringOrNull(RBA_PS_IMAGE)
                tdyClientId = mfaParamsObject.optStringOrNull(RBA_TDY_CLIENT_ID)
                tdyCardId = mfaParamsObject.optStringOrNull(RBA_TDY_CARD_ID)
                data = mfaParamsObject.optStringOrNull(RBA_MFA_DATA)
            }
        }

        return parsResponse
    }
    private fun JSONObject.optStringOrNull(key: String): String? {
        val value = optString(key)
        return if (value.isNullOrEmpty() || value == "null") null else value
    }

    private fun loggingMsg(
        eventValue: String,
        data: String,
        errorCode: Int? = null,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        timeTakenMs: Long = 0,
        eventStatus: EventStatus = EventStatus.Initiated,
        httpCode: Int? = null,
        apiPath: String? = null
    ) {
        try {
            apiLayer.activity?.let { activity ->
                LoggingUtils.logMessage(
                    activity,
                    LoggingConstants.PAYU_CARDS_AREQ,
                    eventValue,
                    data,
                    errorCode = errorCode,
                    eventSeverity = eventSeverity,
                    eventType = eventType,
                    timeTakenMs = timeTakenMs,
                    eventStatus = eventStatus,
                    httpCode = httpCode,
                    apiPath = apiPath
                )
            }
        } catch (e: Exception) {
            Log.e(LoggingConstants.PAYU_CARDS_AREQ, "Exception while logging to Analytics ${e.message}")
        }
    }

    fun removeThreeDS2RequestData(postData: String): String {
        return postData
            .split("&")
            .filterNot { it.startsWith("threeDS2RequestData=") }
            .joinToString("&")
    }

}
