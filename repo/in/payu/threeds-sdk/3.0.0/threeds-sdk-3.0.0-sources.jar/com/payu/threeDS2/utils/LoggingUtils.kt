package com.payu.threeDS2.utils

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics
import com.payu.threeDS2.BuildConfig
import com.payu.threeDS2.config.InternalConfig
import com.payu.threeDS2.config.InternalConfig.mfaParams
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.LoggingConstants.Companion.PLATFORM_VALUE
import com.payu.threeDS2.constants.PayU3DS2Constants
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.ACS_TXN_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.APPLICATION_PACKAGE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.BANK_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.BINDING_TYPE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.CARD_TYPE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.CLIENT_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.CUSTOMER_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.DATA
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.ERROR_CODE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.IS_RECURRING_TRANSACTION
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.MERCHANT_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.MERCHANT_MOBILE_NO
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.MERCHANT_NAME
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.MERCHANT_REQUEST_TXN_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.MESSAGE_TYPE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.OS_VERSION
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.PLATFORM
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.SDK_NAME_VALUE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.TDY_CARD_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.TEMP_CARD_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.TXN_AMOUNT
import com.payu.threeDS2.enums.EventSeverity
import com.payu.threeDS2.enums.EventStatus
import com.payu.threeDS2.enums.EventType
import com.payu.threeDS2.utils.Utils.getCurrentDateInDDMMYYHHMMSSFormat
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

object LoggingUtils {
    private var payUAnalytics: PayUAnalytics? = null
    private const val TAG = "LoggingUtils"

    private val logHandlerThread = HandlerThread("PayU-LogThread").also { it.start() }
    private val logHandler = Handler(logHandlerThread.looper)

    fun logMessage(
        activity: Activity,
        eventKey: String,
        eventValue: String,
        data: String? = null,
        errorCode: Int? = null,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        timeTakenMs: Long = 0,
        eventStatus: EventStatus = EventStatus.Initiated,
        httpCode: Int? = null,
        apiPath: String? = null,
        ) {
        logHandler.post {
            if (payUAnalytics == null) {
                payUAnalytics =
                    AnalyticsFactory(activity.applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
            }
            val analyticsJson = getAnalyticsJsonWithBasicProperties(activity)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_KEY, eventKey)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_VALUE, eventValue)
            analyticsJson.put(PayU3DS2Constants.EVENT_SEVERITY,eventSeverity.name)
            analyticsJson.put(PayU3DS2Constants.EVENT_TYPE, eventType.name)
            analyticsJson.put(PayU3DS2Constants.STATUS, eventStatus.name)
            if (timeTakenMs > 0) {
                analyticsJson.put(PayU3DS2Constants.TIME_TAKEN_MS, timeTakenMs)
            }
            data?.let { analyticsJson.put(DATA, it) }
            errorCode?.let { analyticsJson.put(ERROR_CODE, it) }
            httpCode?.let { analyticsJson.put(PayU3DS2Constants.HTTP_CODE, it) }
            apiPath?.let { analyticsJson.put(PayU3DS2Constants.API_PATH, it) }
            payUAnalytics?.log(analyticsJson.toString())
        }
    }

    fun logMessage(
        activity: Activity,
        analyticsJson: String
    ) {
        logHandler.post {
            if (payUAnalytics == null) {
                payUAnalytics =
                    AnalyticsFactory(activity.applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
            }
            try {
                val analyticsJson = appendBasicEventLoggingProperties(JSONObject(analyticsJson))
                payUAnalytics?.log(analyticsJson.toString())
            }catch (e : Exception){
                Log.d(TAG, "logMessage: $e")
            }
        }
    }
    fun logMessageFailure(
        activity: Activity,
        eventKey: String,
        eventValue: String,
        data: String? = null,
        errorCode: Int? = null,
        eventSeverity: EventSeverity = EventSeverity.High,
        eventType: EventType = EventType.Error,
        eventStatus: EventStatus = EventStatus.Failed,
    ) {
        logHandler.post {
            if (payUAnalytics == null) {
                payUAnalytics =
                    AnalyticsFactory(activity.applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
            }
            val analyticsJson = getAnalyticsJsonWithBasicProperties(activity)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_KEY, eventKey)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_VALUE, eventValue)
            analyticsJson.put(PayU3DS2Constants.EVENT_SEVERITY,eventSeverity.name)
            analyticsJson.put(PayU3DS2Constants.EVENT_TYPE, eventType.name)
            analyticsJson.put(PayU3DS2Constants.STATUS, eventStatus.name)
            data?.let { analyticsJson.put(DATA, it) }
            errorCode?.let { analyticsJson.put(ERROR_CODE, it) }
            payUAnalytics?.log(analyticsJson.toString())
        }
    }

    fun logMessageSuccess(
        activity: Activity,
        eventKey: String,
        eventValue: String,
        data: String? = null,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        eventStatus: EventStatus = EventStatus.Success,
    ) {
        logHandler.post {
            if (payUAnalytics == null) {
                payUAnalytics =
                    AnalyticsFactory(activity.applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
            }
            val analyticsJson = getAnalyticsJsonWithBasicProperties(activity)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_KEY, eventKey)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_VALUE, eventValue)
            analyticsJson.put(PayU3DS2Constants.EVENT_SEVERITY,eventSeverity.name)
            analyticsJson.put(PayU3DS2Constants.EVENT_TYPE, eventType.name)
            analyticsJson.put(PayU3DS2Constants.STATUS, eventStatus.name)
            data?.let { analyticsJson.put(DATA, it) }
            payUAnalytics?.log(analyticsJson.toString())
        }
    }

    fun logMessageWithAdditionalKeys(
        activity: Activity,
        eventKey: String,
        eventValue: String,
        additionalKeys: Map<String, Any?>? = null,
        data: String? = null,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        timeTakenMs: Long = 0,
        eventStatus: EventStatus = EventStatus.Initiated,
        ) {
        logHandler.post {
            if (payUAnalytics == null) {
                payUAnalytics =
                    AnalyticsFactory(activity.applicationContext).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
            }
            val analyticsJson = getAnalyticsJsonWithBasicProperties(activity)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_KEY, eventKey)
            analyticsJson.put(PayU3DS2Constants.THREEDS_EVENT_VALUE, eventValue)
            eventSeverity?.let { analyticsJson.put(PayU3DS2Constants.EVENT_SEVERITY, it.name) }
            analyticsJson.put(PayU3DS2Constants.EVENT_TYPE, eventType.name)
            analyticsJson.put(PayU3DS2Constants.STATUS, eventStatus.name)
            if (timeTakenMs > 0) {
                analyticsJson.put(PayU3DS2Constants.TIME_TAKEN_MS, timeTakenMs)
            }
            additionalKeys?.forEach { (additionalKey, value) ->
                value?.let { analyticsJson.put(additionalKey, it) }
            }
            data?.let { analyticsJson.put(DATA, it) }
            payUAnalytics?.log(analyticsJson.toString())
        }
    }

    private fun getAnalyticsJsonWithBasicProperties(context: Context): JSONObject {
        val analyticsJson = JSONObject()
        analyticsJson.put(PayU3DS2Constants.THREEDS_TIMESTAMP, getCurrentDateInDDMMYYHHMMSSFormat())
        analyticsJson.put(PayU3DS2Constants.SDK_NAME, SDK_NAME_VALUE)
        analyticsJson.put(PayU3DS2Constants.THREEDS_SDK_VERSION, BuildConfig.VERSION_NAME)
        analyticsJson.put(PLATFORM, PLATFORM_VALUE)
        analyticsJson.put(APPLICATION_PACKAGE, context.applicationContext.packageName)
        analyticsJson.put(
            PayU3DS2Constants.THREEDS_APPLICATION_VERSION,
            getApplicationVersion(context)
        )
        analyticsJson.put(
            PayU3DS2Constants.THREEDS_LOGGING_SDK,
            BuildConfig.LIBRARY_PACKAGE_NAME
        )
        analyticsJson.put(
            PayU3DS2Constants.THREEDS_LOGGING_SDK_VERSION,
            BuildConfig.VERSION_NAME
        )
        analyticsJson.put(
            PayU3DS2Constants.THREEDS_TXN_ID,
            InternalConfig.requestId
        )

        val deviceName = Build.MANUFACTURER + "_" + Build.MODEL
        val deviceOsVersion = Build.VERSION.SDK_INT
        try {
            val deviceTotalMemory = getTotalMemoryInfo(context)
            val availMemory = getAvailableMemoryInfo(context)
            val memoryInfo = if (deviceTotalMemory > 0) availMemory * 100 / deviceTotalMemory else 0
            analyticsJson.put(
                PayU3DS2Constants.THREEDS_DEVICE_DETAILS,
                deviceName + "_" + deviceOsVersion + "_" + memoryInfo + "%"
            )
        } catch (e: Exception) {
            analyticsJson.put(
                PayU3DS2Constants.THREEDS_DEVICE_DETAILS,
                deviceName + "_" + deviceOsVersion
            )
        }
       appendBasicEventLoggingProperties(analyticsJson)
        return analyticsJson
    }

    private fun appendBasicEventLoggingProperties(analyticsJson : JSONObject) : String{
        InternalConfig.mfaParams?.let { params ->
            params.bankId?.let { analyticsJson.put(BANK_ID, it) }
            params.clientId?.let { analyticsJson.put(CLIENT_ID, it) }
            params.bindingType?.let { analyticsJson.put(BINDING_TYPE, it) }
            params.customerId?.let { analyticsJson.put(CUSTOMER_ID, it) }
            params.merchantId?.let { analyticsJson.put(MERCHANT_ID, it) }
            params.messageType?.let { analyticsJson.put(MESSAGE_TYPE, it) }
            analyticsJson.put(MERCHANT_REQUEST_TXN_ID, InternalConfig.merchantTxnId)
            analyticsJson.put(
                PayU3DS2Constants.THREEDS_MERCHANT_KEY,
                InternalConfig.key
            )
            analyticsJson.put(OS_VERSION, Build.VERSION.RELEASE.orEmpty())

            InternalConfig.txnAmount?.let { analyticsJson.put(TXN_AMOUNT, it) }
            if (params.tempCardId != null ) {
                analyticsJson.put(CARD_TYPE, TEMP_CARD_ID)
            } else {
                analyticsJson.put(CARD_TYPE, TDY_CARD_ID)
            }
            params.merchantMobileNo?.let { analyticsJson.put(MERCHANT_MOBILE_NO, it) }
            if (InternalConfig.mfaParams?.messageType != null) {
                analyticsJson.put(IS_RECURRING_TRANSACTION, isRecurringTransaction())
            }
        }
        resolveTdyCardId()?.let { analyticsJson.put(TDY_CARD_ID, it) }
        InternalConfig.acsTxnId?.let { analyticsJson.put(ACS_TXN_ID, it) }
        InternalConfig.merchantName?.let { analyticsJson.put(MERCHANT_NAME, it) }

        return analyticsJson.toString()
    }


    private fun getApplicationVersion(context: Context): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }

    private fun getTotalMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem / (1024 * 1024)
    }

    private fun getAvailableMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024)
    }

    fun getAnalyticsString(sdkPlatformData: String?): String {
        var jsonArray = JSONArray()
        val jsonObject = JSONObject()
        try {
            jsonArray = if (null == sdkPlatformData) {
                JSONArray()
            } else {
                JSONArray(sdkPlatformData)
            }
            jsonObject.put(LoggingConstants.PLATFORM_KEY, PLATFORM_VALUE)
            jsonObject.put(LoggingConstants.NAME_KEY, LoggingConstants.NAME_VALUE)
            jsonObject.put(LoggingConstants.VERSION_KEY, BuildConfig.VERSION_NAME)
            jsonArray.put(jsonObject)
        } catch (e: JSONException) {
            Log.e(TAG, "Error creating analytics string: ${e.message}", e)
        }
        return jsonArray.toString()
    }


    fun isRecurringTransaction(): Boolean {
        val messageType = mfaParams?.messageType
        return messageType == "00" || messageType == "02"
    }

    fun resolveTdyCardId(): String? {
        mfaParams?.let { params ->
            if (!params.cardId.isNullOrEmpty()) return params.cardId
            if (!params.tempCardId.isNullOrEmpty()) return params.tempCardId
            if (!params.tdyCardId.isNullOrEmpty()) return params.tdyCardId
        }
        return null
    }
}
