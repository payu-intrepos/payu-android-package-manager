package com.payu.threeDS2.utils

import androidx.appcompat.app.AppCompatActivity
import com.payu.threeDS2.BuildConfig
import com.payu.threeDS2.config.InternalConfig
import com.payu.threeDS2.config.PayU3DS2Config
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.CARD_TYPE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.TDY_CARD_ID
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.TEMP_CARD_ID
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.LoggingConstants.Companion.NAME_KEY
import com.payu.threedsbase.constants.LoggingConstants.Companion.NAME_VALUE
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_CONFIGURATION
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_DEREGISTER
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_INTACT_CHECK
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_PROCESS_TRANSACTION
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_REGISTRATION
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_TRANSACTION
import com.payu.threedsbase.constants.LoggingConstants.Companion.PLATFORM_KEY
import com.payu.threedsbase.constants.LoggingConstants.Companion.PLATFORM_VALUE
import com.payu.threedsbase.constants.LoggingConstants.Companion.VERSION_KEY
import com.payu.threeDS2.enums.EventSeverity
import com.payu.threeDS2.enums.EventStatus
import com.payu.threeDS2.enums.EventType
import com.payu.threeDS2.utils.Utils.mapUIThemeTridentity
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_ACS_TXN_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_AUTH_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_AUTH_TYPE_VALUE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_BANK_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_BANK_LOGO
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_BIN_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_CLIENT_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_CUSTOMER_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_ENV
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_ENV_PROD_VALUE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_ENV_UAT_VALUE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_FALLBACK_REGISTRATION_TIMEOUT
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_FALLBACK_TRANSACTION_TIMEOUT
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_HASH_KEY
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_BINDING_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MERCHANT_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MERCHANT_KEY
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MERCHANT_NAME
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MERCHANT_TXN_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MESSAGE_TYPE_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MOBILE_NUMBER
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_NETWORK_LOGO
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_REASON_CODE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_RETRY_COUNT
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_RETRY_COUNT_VALUE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_SDK_PLATFORM
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_SDK_VERSION
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_STATUS
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TDY_API_KEY
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TDY_URL
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_THEME_CONFIG
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TXN_AMOUNT
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TXN_ID
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_UID
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_ALREADY_DEREGISTERED_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CARD_OR_TEMP_CARD_ID_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CHECK_REGISTRATION_FAILED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CLIENT_ID_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CONFIG_FAILED_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CONFIG_FAILED_CODE_DEREG
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CONFIG_FAILED_CODE_REG
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEREGISTRATION_FAILED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_DE_REGISTERED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_DE_REGISTERED_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_MANUAL_DE_REGISTERED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_MISSING_PARAMETERS
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_REGISTRATION_FAILED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_REGISTRATION_FAILED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_TXN_ERROR
import com.payu.threedsbase.data.ChallengeParameter
import com.payu.threedsbase.enums.TridentityFlow
import com.payu.threedsbase.interfaces.listeners.PayU3DS2BaseCallback
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.uiCustomisation.UICustomisation
import com.wibmo.tridentity.sdk.TridentitySDK

import com.wibmo.tridentity_headless.di.ConfigStatusCallback
import com.wibmo.tridentity_headless.di.DeregisterCallBack
import com.wibmo.tridentity_headless.di.RegistrationStatusCallBack
import com.wibmo.tridentity_headless.di.UpdateTransactionCallback
import org.json.JSONObject
import java.lang.ref.WeakReference

internal object TridentityHelper {
    private var appCompatActivity: WeakReference<AppCompatActivity>? = null
    private var clientId: String? = null
    private var tempCardId: String? = null
    private var cardId: String? = null
    private var bankId: String? = null
    private var hashKey: String? = null
    private var callback: PayU3DS2BaseCallback? = null
    private var bankLogo: String? = null
    private var txnId: String? = null
    private var customerId: String? = null


    /**
     * Starts the Tridentity flow based on the provided flow type.
     *
     * This method initializes the necessary parameters and configures the SDK.
     * Depending on the flow type, it either initiates the registration process
     * or checks the registration status.
     *
     * @param appCompatActivity The current activity.
     * @param bin The BIN (Bank Identification Number) of the card.
     * @param clientId The client ID.
     * @param tempCardId The temporary card ID.
     * @param cardId The card ID.
     * @param flowType The type of Tridentity flow (registration or transaction).
     * @param callback The callback to handle success and error responses.
     */
    fun startTridentityFlow(
        appCompatActivity: AppCompatActivity,
        isProduction: Boolean,
        challengeParameter: ChallengeParameter,
        flowType: TridentityFlow,
        threedsUiCustomization: PayU3DS2Config?,
        callback: PayU3DS2BaseCallback
    ) {
        val clientId: String? = InternalConfig.mfaParams?.tdyClientId
        val bankLogo: String? = InternalConfig.mfaParams?.bankLogo
        val acsTransactionID: String? = challengeParameter.acsTransactionID
        val cardId: String? =  InternalConfig.mfaParams?.cardId
        val tempCardId: String? =  InternalConfig.mfaParams?.tempCardId
        val bin: String? =  InternalConfig.mfaParams?.cardBin
        val bankId: String? =  InternalConfig.mfaParams?.bankId
        val hashKey: String? =  InternalConfig.mfaParams?.hashKey
        val tdyUrl: String? =  InternalConfig.mfaParams?.tdyUrl
        val registrationTimeout: Int =  InternalConfig.mfaParams?.registrationTimeout ?: 0
        val transactionTimeout: Int =  InternalConfig.mfaParams?.transactionTimeout ?: 0
        val customerId: String? =  InternalConfig.mfaParams?.customerId
        val bindingType: String? =  InternalConfig.mfaParams?.bindingType

        if (clientId.isNullOrEmpty()) {
            LoggingUtils.logMessage(
                appCompatActivity,
                PAYU_CARDS_CONFIGURATION,
                LoggingConstants.FAILED,
                RBA_CLIENT_ID_NULL,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                eventStatus = EventStatus.Failed
            )
            callback.onError(RBA_MISSING_PARAMETERS, RBA_CLIENT_ID_NULL)
            return
        }

        if (tempCardId.isNullOrEmpty() && cardId.isNullOrEmpty()) {
            LoggingUtils.logMessage(
                appCompatActivity,
                PAYU_CARDS_CONFIGURATION,
                LoggingConstants.FAILED,
                RBA_CARD_OR_TEMP_CARD_ID_NULL,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                eventStatus = EventStatus.Failed
            )
            callback.onError(RBA_MISSING_PARAMETERS, RBA_CARD_OR_TEMP_CARD_ID_NULL)
            return
        }

        this.appCompatActivity = WeakReference(appCompatActivity)
        this.clientId = clientId
        this.tempCardId = tempCardId
        this.cardId = cardId
        this.bankLogo = bankLogo
        this.callback = callback
        this.txnId = txnId
        this.customerId = customerId
        this.bankId = bankId
        this.hashKey = hashKey

        val configObject = JSONObject().apply {
            put(RBA_ENV, if (isProduction) RBA_ENV_PROD_VALUE.uppercase() else RBA_ENV_UAT_VALUE.uppercase()) // optional
            put(RBA_CLIENT_ID, clientId)
            put(RBA_TDY_URL, tdyUrl)
            put(RBA_AUTH_TYPE, RBA_AUTH_TYPE_VALUE)
            put(RBA_RETRY_COUNT, RBA_RETRY_COUNT_VALUE)
            put(RBA_BIN_ID, bin)
            put(RBA_BANK_LOGO, bankLogo)
            put(RBA_FALLBACK_REGISTRATION_TIMEOUT, registrationTimeout)
            put(RBA_FALLBACK_TRANSACTION_TIMEOUT, transactionTimeout)
            put(RBA_BANK_ID, bankId)
            put(RBA_CUSTOMER_ID, customerId)
            put(RBA_UID, if (!TridentityHelper.tempCardId.isNullOrEmpty()) TridentityHelper.tempCardId else cardId)
            put(RBA_TXN_ID, InternalConfig.requestId)
            put(RBA_ACS_TXN_ID, acsTransactionID)
            put(RBA_MERCHANT_NAME, InternalConfig.merchantName)
            put(RBA_MOBILE_NUMBER, InternalConfig.mfaParams?.merchantMobileNo)
            put(RBA_TDY_API_KEY, InternalConfig.mfaParams?.tdyApiKey)
            put(RBA_NETWORK_LOGO, InternalConfig.mfaParams?.cardNetworkLogo)
            put(RBA_MERCHANT_ID, InternalConfig.mfaParams?.merchantId)
            put(RBA_TXN_AMOUNT, InternalConfig.txnAmount)
            put(RBA_MERCHANT_TXN_ID, InternalConfig.merchantTxnId)
            put(RBA_MERCHANT_KEY, InternalConfig.key)
            put(RBA_SDK_PLATFORM, getSDKPlateFormData())
            put(RBA_SDK_VERSION, BuildConfig.VERSION_NAME)
            if (tempCardId != null ) {
                put(CARD_TYPE, TEMP_CARD_ID)
            } else {
                put(CARD_TYPE, TDY_CARD_ID)
            }
            put(RBA_MESSAGE_TYPE_TYPE, InternalConfig.mfaParams?.messageType)

            if (!bindingType.isNullOrEmpty())
                put(RBA_BINDING_TYPE, bindingType)

        }

        var themeConfig = com.wibmo.tridentity.sdk.theme.ThemeConfig()
        if (threedsUiCustomization?.uiCustomisation != null) {
            val mapUIThemeTridentity = mapUIThemeTridentity(threedsUiCustomization)
            mapUIThemeTridentity?.let { themeConfig = it }
        }

        configObject.put(RBA_THEME_CONFIG, themeConfig)

        LoggingUtils.logMessage(
            appCompatActivity,
            PAYU_CARDS_CONFIGURATION,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            configObject.toString(),
            eventType = EventType.Info
        )

        TridentitySDK.getInstance()
            .configSdk(appCompatActivity, configObject, object : ConfigStatusCallback {
                override fun onSuccess(event: JSONObject) {
                    LoggingUtils.logMessage(
                        appCompatActivity,
                        PAYU_CARDS_CONFIGURATION,
                        LoggingConstants.SUCCESS,
                        event.toString(),
                        eventType = EventType.Info,
                        eventStatus = EventStatus.Success
                    )
                    when (flowType) {
                        TridentityFlow.REGISTRATION -> {
                            startRegistration()
                        }

                        TridentityFlow.TRANSACTION -> {
                            checkRegistrationStatus(
                                threedsUiCustomization?.uiCustomisation
                            )
                        }

                        TridentityFlow.OOB_INITIATED -> {
                            InternalConfig.isOOBInitiatedCREQ = true
                            startTransaction()
                        }

                        TridentityFlow.DEREGISTRATION -> {
                            startDeRegistration()
                        }
                    }
                }

                override fun onError(code: Int, error: String) {
                    LoggingUtils.logMessage(
                        appCompatActivity,
                        PAYU_CARDS_CONFIGURATION,
                        LoggingConstants.FAILED,
                        "$code $error",
                        errorCode = code,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        eventStatus = EventStatus.Failed
                    )
                    InternalConfig.deviceDeregistered = true

                    when (flowType) {
                        TridentityFlow.REGISTRATION -> {
                            callback.onError(RBA_CONFIG_FAILED_CODE_REG,  error)
                        }

                        TridentityFlow.DEREGISTRATION -> {
                            callback.onError(RBA_CONFIG_FAILED_CODE_DEREG,  error)
                        }

                        else -> {
                            if (RBA_ALREADY_DEREGISTERED_CODE.contains(code)) {
                                SdkUiInitializer.showDeRegisterScreen(
                                    appCompatActivity,
                                    threedsUiCustomization?.uiCustomisation,
                                    TridentityHelper.bankLogo,
                                    code,
                                    error
                                ) {
                                    TridentityHelper.callback?.onError(
                                        RBA_DEVICE_DE_REGISTERED_ERROR_CODE,
                                        RBA_DEVICE_DE_REGISTERED_ERROR_MESSAGE
                                    )
                                }
                            } else {
                                callback.onError(RBA_CONFIG_FAILED_CODE, error)

                            }
                        }
                    }
                }
            })
    }


    fun startDeRegistration() {
        val activity = appCompatActivity?.get() ?: return
        val regObject = JSONObject().apply {
            put(RBA_UID, if (!tempCardId.isNullOrEmpty()) tempCardId else cardId)
        }
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_DEREGISTER,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            regObject.toString(),
            eventType = EventType.Info
        )
        TridentitySDK.getInstance().deRegistration(
            activity,
            object : DeregisterCallBack {
                override fun onSuccess(event: JSONObject) {
                    val registrationStatus = event.optString(APIConstants.CODE)
                    if (registrationStatus.equals("200", ignoreCase = true)) {
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_DEREGISTER,
                                LoggingConstants.SUCCESS,
                                event.toString(),
                                eventType = EventType.Info,
                                eventStatus = EventStatus.Success
                            )

                        callback?.onSuccess(registrationStatus)
                    } else {
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_DEREGISTER,
                                LoggingConstants.FAILED,
                                event.toString(),
                                eventSeverity = EventSeverity.High,
                                eventType = EventType.Error,
                                eventStatus = EventStatus.Failed
                            )
                        callback?.onError(
                            RBA_DEVICE_MANUAL_DE_REGISTERED_ERROR_CODE,
                            RBA_DEREGISTRATION_FAILED
                        )
                    }
                }

                override fun onError(code: Int, error: String) {
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_DEREGISTER,
                            LoggingConstants.FAILED,
                            "$code $error",
                            errorCode = code,
                            eventSeverity = EventSeverity.High,
                            eventType = EventType.Error,
                            eventStatus = EventStatus.Failed
                        )
                    callback?.onError(RBA_DEVICE_MANUAL_DE_REGISTERED_ERROR_CODE, error)
                }
            })
    }


    /**
     * Initiates the registration process using the Tridentity SDK.
     *
     * This method creates a JSON object with the temporary card ID and calls the
     * `initiateRegistration` method of the Tridentity SDK. It handles the success
     * and error responses through the `RegistrationStatusCallBack`. Depending on the
     * registration status, it either calls the success callback or logs an error message.
     */
    private fun startRegistration() {
        val activity = appCompatActivity?.get()?.takeIf { !it.isFinishing && !it.isDestroyed } ?: return
        
        val regObject = JSONObject().apply {
            put(RBA_UID, if (!tempCardId.isNullOrEmpty()) tempCardId else cardId)
        }
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_REGISTRATION,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            regObject.toString(),
            eventType = EventType.Info
        )
        TridentitySDK.getInstance().initiateRegistration(
            activity, regObject,
            object : RegistrationStatusCallBack {
                override fun onSuccess(event: JSONObject) {
                    val registrationStatus = getRegistrationStatusFromResponse(event)
                    
                    if (registrationStatus.equals(APIConstants.REG_SUCCESS_STATUS, ignoreCase = true)) {
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_REGISTRATION,
                            LoggingConstants.SUCCESS,
                            event.toString(),
                            eventType = EventType.Info,
                            eventStatus = EventStatus.Success
                        )
                        callback?.onSuccess(registrationStatus ?: "")
                    } else {
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_REGISTRATION,
                            LoggingConstants.FAILED,
                            event.toString(),
                            eventSeverity = EventSeverity.High,
                            eventType = EventType.Error,
                            eventStatus = EventStatus.Failed
                        )
                        callback?.onError(
                            RBA_REGISTRATION_FAILED_ERROR_CODE,
                            RBA_REGISTRATION_FAILED
                        )
                    }
                }

                override fun onError(code: Int, error: String) {
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_REGISTRATION,
                        LoggingConstants.FAILED,
                        "$code $error",
                        errorCode = code,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        eventStatus = EventStatus.Failed
                    )
                    callback?.onError(RBA_REGISTRATION_FAILED_ERROR_CODE, error)
                }

                override fun onRegistrationProgress(progressJson: String) {
                    try {
                        val registrationJson = JSONObject(progressJson)
                        val message = registrationJson.optString("message")
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_REGISTRATION,
                            message,
                            progressJson,
                        )
                        callback?.onStatusUpdate(registrationJson)
                    } catch (e: Exception) {
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_REGISTRATION,
                            e.message ?: "",
                            progressJson,
                        )
                    }
                }

            })
    }

    /**
     * Checks the registration status of the user and proceeds accordingly.
     *
     * This method creates a JSON object with the temporary card ID and calls the
     * `checkRegistrationStatus` method of the Tridentity SDK. It handles the success
     * and error responses through the `RegistrationStatusCallBack`. Depending on the
     * registration status, it either shows the authentication mode selection screen
     * or the de-registration screen.
     */
    private fun checkRegistrationStatus(themeConfig: UICustomisation?) {
        val activity = appCompatActivity?.get()?.takeIf { !it.isFinishing && !it.isDestroyed } ?: return
        
        val regStatusObject = JSONObject().apply {
            put(RBA_UID, cardId)
            put(RBA_CLIENT_ID, clientId)
            put(RBA_BANK_ID, bankId)
        }
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_INTACT_CHECK,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            regStatusObject.toString(),
            eventType = EventType.Info
        )

        TridentitySDK.getInstance()
            .checkRegistrationStatus(
                activity,
                regStatusObject,
                object : RegistrationStatusCallBack {
                    override fun onSuccess(event: JSONObject) {

                        InternalConfig.deviceDeregistered = false
                        val registrationStatus = getRegistrationStatusFromResponse(event)
                        
                        if (registrationStatus.equals(APIConstants.REG_SUCCESS_STATUS, ignoreCase = true)) {
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_INTACT_CHECK,
                                LoggingConstants.SUCCESS,
                                event.toString(),
                                eventType = EventType.Info,
                                eventStatus = EventStatus.Success
                            )
                            callback?.onSuccess(registrationStatus ?: "")
                        } else {
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_INTACT_CHECK,
                                LoggingConstants.FAILED,
                                "$RBA_DEVICE_DE_REGISTERED_ERROR_CODE $RBA_DEVICE_DE_REGISTERED_ERROR_MESSAGE",
                                errorCode = RBA_DEVICE_DE_REGISTERED_ERROR_CODE,
                                eventSeverity = EventSeverity.High,
                                eventType = EventType.Info,
                                eventStatus = EventStatus.Failed
                            )
                            callback?.onError(
                                RBA_DEVICE_DE_REGISTERED_ERROR_CODE,
                                RBA_DEVICE_DE_REGISTERED_ERROR_MESSAGE
                            )
                        }
                    }

                    override fun onError(code: Int, error: String) {
                        InternalConfig.deviceDeregistered = true
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_INTACT_CHECK,
                            LoggingConstants.FAILED,
                            "$code $error",
                            errorCode = code,
                            eventSeverity = EventSeverity.High,
                            eventType = EventType.Error,
                            eventStatus = EventStatus.Failed
                        )

                        if (RBA_ALREADY_DEREGISTERED_CODE.contains(code)) {
                            SdkUiInitializer.showDeRegisterScreen(
                                activity,
                                themeConfig,
                                bankLogo,
                                code,
                                error
                            ) {
                                callback?.onError(
                                    RBA_DEVICE_DE_REGISTERED_ERROR_CODE,
                                    RBA_DEVICE_DE_REGISTERED_ERROR_MESSAGE
                                )
                            }
                        } else {
                            callback?.onError(RBA_CHECK_REGISTRATION_FAILED, error)
                        }
                    }
                })
    }

    private fun getRegistrationStatusFromResponse(json: JSONObject): String? {
        val subParam = json.optJSONObject(APIConstants.SUB_PARAM)
        return subParam?.optString(APIConstants.CUSTOMER_STATUS)
    }

    /**
     * Initiates a transaction process using the Tridentity SDK.
     *
     * This method creates a JSON object with transaction details and
     * calls the `processTransaction` method of the Tridentity SDK.
     * It handles the success and error responses through the `UpdateTransactionCallback`.
     */
    private fun startTransaction() {
        val activity = appCompatActivity?.get() ?: return
        
        val transactionObject = JSONObject().apply {
            put(RBA_UID, cardId)
            put(RBA_CLIENT_ID, clientId)
            put(RBA_HASH_KEY, hashKey)
        }
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_TRANSACTION,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            "transactionObject :- ${transactionObject.toString()}",
            eventType = EventType.Info
        )

        TridentitySDK.getInstance()
            .processTransaction(
                activity,
                transactionObject,
                false,
                object : UpdateTransactionCallback {

                override fun onSuccess(event: JSONObject) {
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_TRANSACTION,
                        LoggingConstants.SUCCESS,
                        event.toString(),
                        eventType = EventType.Info,
                        eventStatus = EventStatus.Success
                    )
                    callback?.onSuccess(event.optString(APIConstants.STATUS))
                }

                override fun onError(code: Int, error: String) {
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_TRANSACTION,
                        LoggingConstants.FAILED,
                        "$code $error",
                        errorCode = code,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        eventStatus = EventStatus.Failed
                    )
                    callback?.onError(RBA_TXN_ERROR, error)
                }

                    override fun onTransactionProgress(progressJson: String) {
                        try {
                            val txnJson = JSONObject(progressJson)
                            val message = txnJson.optString("message")
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_TRANSACTION,
                                message,
                                progressJson,
                            )
                            callback?.onStatusUpdate(txnJson)
                        } catch (e: Exception) {
                            LoggingUtils.logMessage(
                                activity,
                                PAYU_CARDS_TRANSACTION,
                                e.message ?: "",
                                progressJson,
                            )
                        }
                    }
                })

    }


    fun processAndUpdate(
        status: String,
        reasonCode: String? = null,
        onComplete: () -> Unit = {}
    ) {
        val activity = appCompatActivity?.get() ?: return
        val params = JSONObject().apply {
            put(RBA_UID, cardId)
            put(RBA_CLIENT_ID, clientId)
            put(RBA_HASH_KEY, hashKey)
            put(RBA_REASON_CODE, reasonCode)
            put(RBA_STATUS, status)
        }

        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_PROCESS_TRANSACTION,
            LoggingConstants.EVENT_VALUE_FORWARDED_TO_TRIDENTITY,
            params.toString(),
            eventType = EventType.Info
        )

        TridentitySDK.getInstance().processTransaction(
            activity,
            params,
            true,
            callback = object : UpdateTransactionCallback {
                override fun onSuccess(event: JSONObject) {
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_PROCESS_TRANSACTION,
                        LoggingConstants.SUCCESS,
                        event.toString(),
                        eventType = EventType.Info,
                        eventStatus = EventStatus.Fallback,
                    )
                    onComplete()
                }

                override fun onError(code: Int, error: String) {
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_PROCESS_TRANSACTION,
                        error,
                        "$code $error",
                        errorCode = code,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        eventStatus = EventStatus.Fallback
                    )
                    onComplete()
                }
            })
    }

    private fun getSDKPlateFormData(): String {
        val platformJson = JSONObject()
        platformJson.put(PLATFORM_KEY, PLATFORM_VALUE)
        platformJson.put(NAME_KEY, NAME_VALUE)
        platformJson.put(VERSION_KEY, BuildConfig.VERSION_NAME)
        return platformJson.toString()
    }
}
