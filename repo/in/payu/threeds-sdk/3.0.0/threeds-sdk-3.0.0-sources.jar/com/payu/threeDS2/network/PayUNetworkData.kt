package com.payu.threeDS2.network

import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.enums.APICommand

class PayUNetworkData {
    var url: String? = null
    var postRequest: String? = null
    var contentType: String = APIConstants.APPLICATION_FORM_URL_ENCODED
    var headerMap: HashMap<String, String>? = null
    var getRequest: HashMap<String, Any>? = null
}