package com.payu.threeDS2.utils


import com.payu.threeDS2.constants.PayU3DS2Constants
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

internal object PayU3DS2ContentCodec {



    private val sharedMaterial: String
        get() = PayU3DS2Handler.deriveValue

    private fun nonceFromToken(token: String): ByteArray {
        require(token.length >= PayU3DS2Constants.MIN_TOKEN_LENGTH) {
            "Token must be at least 7 characters long."
        }
        val head = token.substring(0, 6)
        val tail = token.substring(token.length - 7, token.length - 1)
        val combined = head + tail
        return combined.toByteArray(Charsets.UTF_8)
    }

    private fun normalizeMaterialToFixedWidth(token: String): ByteArray {
        return token.toByteArray(Charsets.UTF_8).copyOf(PayU3DS2Constants.MATERIAL_BYTE_LENGTH)
    }

    fun getDataValueFromMFA(data: String): String {
        require(PayU3DS2Handler.deriveValue.isNotEmpty()) { "MFA configuration material unavailable" }
        val combinedBytes = bytesFromHex(data)
        val materialBytes = normalizeMaterialToFixedWidth(sharedMaterial)
        val nonce = nonceFromToken(sharedMaterial)

        val engine =
            Cipher.getInstance(PayU3DS2Constants.AUTH_DERIVE + PayU3DS2Constants.PAYU_FP_VALUE + PayU3DS2Constants.PAYU_FP_MSG)
        val materialSpec = SecretKeySpec(materialBytes, "AES")
        val frameSpec = GCMParameterSpec(PayU3DS2Constants.FRAME_SUFFIX_BITS, nonce)

        engine.init(Cipher.DECRYPT_MODE, materialSpec, frameSpec)
        val output = engine.doFinal(combinedBytes)

        return String(output, Charsets.UTF_8)
    }

    fun toByteArrayValue(value: String): ByteArray? {
        return bytesFromHex(value)
    }

    internal fun bytesFromHex(string: String): ByteArray? {
        val hex = string.trim()
        if (hex.isEmpty() || hex.length % 2 != 0) return null
        val out = ByteArray(hex.length / 2)
        var i = 0
        while (i < hex.length) {
            val chunk = hex.substring(i, i + 2)
            val value = chunk.toIntOrNull(16) ?: return null
            out[i / 2] = value.toByte()
            i += 2
        }
        return out
    }


}
