package com.payu.threeDS2.network

import android.util.Log
import com.payu.paymentparamhelper.HashCommand
import com.payu.paymentparamhelper.PaymentParams
import com.payu.threeDS2.config.InternalConfig
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threeDS2.enums.EventSeverity
import com.payu.threeDS2.enums.EventStatus
import com.payu.threeDS2.enums.EventType
import com.payu.threeDS2.interfaces.listeners.PayU3DS2APIService
import com.payu.threeDS2.interfaces.listeners.PayUAsyncTaskResponse
import com.payu.threeDS2.utils.HashGenerationUtils
import com.payu.threeDS2.utils.LoggingUtils
import com.payu.threeDS2.utils.PostDataGeneratorUtils
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.BIN_INFO_API_CARD_BIN_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.HASH_NULL_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.HASH_NULL_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.MERCHANT_KEY_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.threedsbase.data.ErrorResponse
import com.payu.threedsbase.data.apiRequest.CardBinInfoRequest
import com.payu.threedsbase.data.apiResponse.BinInfoResponse
import com.payu.threedsbase.interfaces.listeners.PayU3DS2Callback
import com.payu.threedsbase.interfaces.listeners.PayUHashGeneratedListener
import org.json.JSONObject

class GetBinInfoAPITask(private val apiLayer: PayU3DSAPILayer) : PayU3DS2APIService {
    override fun callAPI(request: Any, callback: PayU3DS2Callback) {
        val params = PaymentParams()
        params.cardBin = (request as CardBinInfoRequest).cardDetails
        params.key = InternalConfig.key
        val startTime = System.currentTimeMillis()
        loggingMsg(
            LoggingConstants.EVENT_VALUE_INIT_PARAMS,
            request.toString(),
        )

        val error = validate(params)
        if (error.errorCode != null && error.errorMessage != null) {
            loggingMsg(
                LoggingConstants.PAYU_CARDS_BIN_INFO,
                LoggingConstants.FAILED,
                error.errorCode,
                EventSeverity.High,
                EventType.Error,
                eventStatus = EventStatus.Failed

            )
            callback.onError(error.errorCode!!, error.errorMessage!!)
        } else {
            loggingMsg(
                LoggingConstants.LEGACY_HASH_REQUESTED,
                "",
                timeTakenMs = System.currentTimeMillis() - startTime
            )
            generateHash(params, callback, object : PayUHashGeneratedListener {
                override fun onHashGenerated(map: HashMap<String, String>) {
                    val hash = map[HashCommand.BinInfoHash.hashName]
                    if (hash.isNullOrEmpty()) {
                        loggingMsg(
                            LoggingConstants.FAILED,
                            LoggingConstants.LOGGING_ERROR_KEY + HASH_NULL_ERROR_MESSAGE,
                            errorCode = HASH_NULL_ERROR_CODE,
                            eventSeverity = EventSeverity.High,
                            eventType = EventType.Error,
                            timeTakenMs = System.currentTimeMillis() - startTime,
                            eventStatus = EventStatus.Failed
                        )
                        callback.onError(HASH_NULL_ERROR_CODE, HASH_NULL_ERROR_MESSAGE)
                    } else {
                        val postData = generatePostData(params, hash, (request as CardBinInfoRequest).isSI)

                        val networkData = PayUNetworkData()
                        networkData.url =
                            if (apiLayer.config.isProduction) APIConstants.INFO_URL else
                                APIConstants.UAT_INFO_URL
                        networkData.postRequest = postData.toString()
                        loggingMsg(
                            LoggingConstants.LEGACY_API_PARAMS,
                            postData.toString(),
                            apiPath = networkData.url
                        )

                        PayU3DSAPICall().makePostAPICall(
                            APIConstants.HTTP_REQUEST_TYPE_POST,
                            networkData,
                            object : PayUAsyncTaskResponse {
                                override fun onSuccess(response: Any, executionTime: Long, httpCode: Int?) {
                                    val jsonString = response.toString()
                                    val jsonObject = JSONObject(jsonString)
                                    if (jsonObject.optInt(APIConstants.STATUS, 0) == 1) {
                                        val parsedData = parseData(jsonObject)
                                        if (parsedData != null) {
                                            loggingMsg(
                                                LoggingConstants.LEGACY_API_SUCCESS,
                                                "${LoggingConstants.LEGACY_GET_BIN_INFO_SUCCESS} $jsonString",
                                                timeTakenMs = executionTime,
                                                eventStatus = EventStatus.Success,
                                                httpCode = httpCode,
                                                apiPath = networkData.url
                                            )
                                            callback.onSuccess(parsedData)
                                        } else {
                                            loggingMsg(
                                                LoggingConstants.LEGACY_API_FAILED,
                                                jsonString,
                                                eventSeverity = EventSeverity.High,
                                                eventType = EventType.Error,
                                                timeTakenMs = executionTime,
                                                eventStatus = EventStatus.Failed,
                                                apiPath = networkData.url
                                            )
                                            callback.onError(
                                                SDK_RESPONSE_STATUS_CODE_1,
                                                PayU3DS2ErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE
                                            )
                                        }
                                    } else {
                                        val errorMessage =
                                            if (!jsonObject.optString(APIConstants.BIN_INFO_ERROR_MESSAGE)
                                                    .isNullOrBlank()
                                            ) {
                                                jsonObject.optString(APIConstants.BIN_INFO_ERROR_MESSAGE)
                                            } else {
                                                PayU3DS2ErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE
                                            }
                                        loggingMsg(
                                            LoggingConstants.LEGACY_API_FAILED,
                                            jsonString,
                                            eventSeverity = EventSeverity.High,
                                            eventType = EventType.Error,
                                            timeTakenMs = executionTime,
                                            eventStatus = EventStatus.Failed,
                                            apiPath = networkData.url
                                        )
                                        callback.onError(SDK_RESPONSE_STATUS_CODE_1, errorMessage)
                                    }
                                }

                                override fun onFailure(errorCode: Int, errorMessage: String, executionTime: Long, httpCode: Int?) {
                                    loggingMsg(
                                        LoggingConstants.LEGACY_API_FAILED,
                                        LoggingConstants.LOGGING_ERROR_KEY + errorMessage,
                                        errorCode = errorCode,
                                        eventSeverity = EventSeverity.High,
                                        eventType = EventType.Error,
                                        timeTakenMs = executionTime,
                                        eventStatus = EventStatus.Failed,
                                        httpCode = httpCode,
                                        apiPath = networkData.url
                                    )
                                    callback.onError(errorCode, errorMessage)
                                }
                            }
                        )
                    }
                }
            })
        }
    }

    override fun validate(paymentParams: PaymentParams): ErrorResponse {
        val errorResponse = ErrorResponse()
        if (paymentParams.cardBin.isNullOrEmpty()) {
            loggingMsg(
                LoggingConstants.FAILED,
                LoggingConstants.BIN_INFO_VALIDATION_TAG + PayU3DS2ErrorConstants.CARD_BIN_NULL_ERROR_MESSAGE,
                errorCode = BIN_INFO_API_CARD_BIN_ERROR_CODE,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                eventStatus = EventStatus.Failed
            )
            errorResponse.errorCode = BIN_INFO_API_CARD_BIN_ERROR_CODE
            errorResponse.errorMessage = PayU3DS2ErrorConstants.CARD_BIN_NULL_ERROR_MESSAGE
        } else if (paymentParams.key.isNullOrEmpty()) {
            loggingMsg(
                LoggingConstants.FAILED,
                LoggingConstants.BIN_INFO_VALIDATION_TAG + PayU3DS2ErrorConstants.MERCHANT_KEY_CANNOT_BE_NULL,
                errorCode = MERCHANT_KEY_ERROR_CODE,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                eventStatus = EventStatus.Failed
            )
            errorResponse.errorCode = MERCHANT_KEY_ERROR_CODE
            errorResponse.errorMessage = PayU3DS2ErrorConstants.MERCHANT_KEY_CANNOT_BE_NULL
        }
        return errorResponse
    }

    override fun generateHash(
        param: Any,
        callback: PayU3DS2Callback,
        payUHashGeneratedListener: PayUHashGeneratedListener
    ) {
        HashGenerationUtils.getHash(
            (param as PaymentParams).key,
            HashCommand.BinInfoHash,
            callback, payUHashGeneratedListener
        )
    }

    override fun generatePostData(request: PaymentParams, hash: String, isSi: Boolean): Any? {
        return PostDataGeneratorUtils.generatePostData(
            HashCommand.BinInfoHash.hashName,
            hash,
            request, isSi
        )
    }

    private fun parseData(jsonObject: JSONObject): BinInfoResponse? {
        if (jsonObject.has(APIConstants.BIN_INFO_API_DATA)) {
            val binsData = jsonObject.getJSONObject(APIConstants.BIN_INFO_API_DATA)
                .getJSONObject(APIConstants.BIN_INFO_BINS_DATA)
            val binInfoResponse = BinInfoResponse()
            binInfoResponse.cardType =
                binsData.getString(APIConstants.BIN_INFO_CARD_TYPE)
            binInfoResponse.isDomestic =
                binsData.getString(APIConstants.BIN_INFO_IS_DOMESTIC)
            binInfoResponse.isAtmPinCard =
                binsData.optString(APIConstants.BIN_INFO_IS_ATMPIN_CARD)
            binInfoResponse.issuingBank =
                binsData.getString(APIConstants.BIN_INFO_ISSUING_BANK)
            binInfoResponse.bin = binsData.getString(APIConstants.BIN_INFO_BIN)
            binInfoResponse.category = binsData.getString(APIConstants.BIN_INFO_CATEGORY)
            binInfoResponse.isOtpOnTheFly =
                binsData.optInt(APIConstants.BIN_INFO_IS_OTP_ON_THE_FLY)
            binInfoResponse.isSiSupported =
                binsData.optInt(APIConstants.BIN_INFO_IS_SI_SUPPORTED)
            binInfoResponse.messageVersion =
                binsData.optString(APIConstants.BIN_INFO_MESSAGE_VERSION)
            binInfoResponse.oobEligible = binsData.optInt(APIConstants.RBA_CARD_ELIGIBLE) == 1
            return binInfoResponse
        }
        return null
    }

    private fun loggingMsg(
        eventValue: String,
        data: String,
        errorCode: Int? = null,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        timeTakenMs: Long = 0,
        eventStatus: EventStatus = EventStatus.Initiated,
        httpCode: Int? = null,
        apiPath: String? = null
    ) {
        try {
            apiLayer.activity?.let { activity ->
                LoggingUtils.logMessage(
                    activity,
                    LoggingConstants.PAYU_CARDS_BIN_INFO,
                    eventValue,
                    data,
                    errorCode,
                    eventSeverity,
                    eventType,
                    timeTakenMs,
                    eventStatus,
                    httpCode,
                    apiPath
                )
            }
        } catch (e: Exception) {
            Log.e(LoggingConstants.PAYU_CARDS_BIN_INFO, "Exception while logging to Analytics ${e.message}")
        }
    }
}
