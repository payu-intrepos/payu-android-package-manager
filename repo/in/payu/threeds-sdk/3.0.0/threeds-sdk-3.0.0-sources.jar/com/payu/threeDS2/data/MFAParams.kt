package com.payu.threeDS2.data

data class MFAParams(
    var cardId: String? = null,
    var tempCardId: String? = null,
    var bankLogo: String? = null,
    var cardNetworkLogo: String? = null,
    var clientId: String? = null,
    var transactionTimeout: Int = 0,
    var registrationTimeout: Int = 0,
    var fallbackVisibilityDuration: Int = 0,
    var bankId: String? = null,
    var customerId: String? = null,
    var themeType: String? = null,
    var hashKey: String? = null,
    var bindingType: String? = null,
    var tdyUrl: String? = null,
    var tdyApiKey: String? = null,
    var autoInvokeBiometricTime: Double = 0.0,
    var cardBin: String? = null,
    var status: String? = null,
    var tdyClientId: String? = null,
    var tdyCardId: String? = null,
    var issuerImage: String? = null,
    var psImage: String? = null,
    var messageType: String? = null,
    var merchantId: String? = null,
    var merchantMobileNo: String? = null
)