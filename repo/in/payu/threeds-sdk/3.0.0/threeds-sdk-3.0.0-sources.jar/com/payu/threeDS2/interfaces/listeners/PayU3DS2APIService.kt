package com.payu.threeDS2.interfaces.listeners

import com.payu.paymentparamhelper.PaymentParams
import com.payu.threedsbase.data.ErrorResponse
import com.payu.threedsbase.interfaces.listeners.PayU3DS2Callback
import com.payu.threedsbase.interfaces.listeners.PayUHashGeneratedListener

interface PayU3DS2APIService {
    fun callAPI(request: Any, callback: PayU3DS2Callback)
    fun validate(paymentParams: PaymentParams): ErrorResponse
    fun generateHash(
        param: Any,
        callback: PayU3DS2Callback,
        payUHashGeneratedListener: PayUHashGeneratedListener
    )

    fun generatePostData(request: PaymentParams, hash: String, isSi: Boolean = false): Any?
}