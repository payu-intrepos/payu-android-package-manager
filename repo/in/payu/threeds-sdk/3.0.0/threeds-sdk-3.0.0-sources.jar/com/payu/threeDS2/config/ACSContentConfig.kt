package com.payu.threeDS2.config

class ACSContentConfig {

    var submitButtonTitle: String? = null
    var resendButtonTitle: String? = null
    var otpContent: String? = null
    var resendInfoContent: String? = null
    var maxResendInfoContent: String? = null
}