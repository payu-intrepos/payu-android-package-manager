package com.payu.threeDS2.utils

import android.app.Activity
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.payu.threeDS2.BuildConfig
import com.payu.threeDS2.config.InternalConfig
import com.payu.threeDS2.config.PayU3DS2Config
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_CARDS_CREQ
import com.payu.threedsbase.constants.LoggingConstants.Companion.THREE_DS_MFA_CHECK_STARTED
import com.payu.threeDS2.constants.PayU3DS2Constants
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.OOB_ELIGIBLE
import com.payu.threeDS2.constants.PayU3DS2Constants.Companion.OTP_RESENT_SUCCESSFULLY
import com.payu.threeDS2.data.MFAParams
import com.payu.threeDS2.enums.EventSeverity
import com.payu.threeDS2.enums.EventStatus
import com.payu.threeDS2.enums.EventType
import com.payu.threeDS2.utils.TridentityHelper.processAndUpdate
import com.payu.threeDS2.utils.Utils.mapPayUActionTypeToWibmoActionType
import com.payu.threeDS2.utils.Utils.mapUICustomisationToWibmo
import com.payu.threedsbase.config.PayU3DS2MFAResponse
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.LoggingConstants.Companion.PAYU_WIMBO_3DS_CREQ_ACTION
import com.payu.threedsbase.constants.LoggingConstants.Companion.THREE_DS_NO_MFA_PARAMS
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_ACTION_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_ACTION_PARAMS_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_ACTION_PARAMS_NULL_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_INVALID_OTP_SUBMIT
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_OTP_DATA_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_OTP_RESEND_LIMIT_EXCEEDED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_OTP_SUBMISSION_FAILED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_RENDERING_TYPE_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_TXN_CANCELLED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACS_TXN_ID_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACTION_API_TIMEOUT
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACTION_TYPE_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ACTION_TYPE_NULL_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.CARD_SCHEME_OR_THREE_DS_VERSION_NULL
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.CHALLENGE_TIMEDOUT_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.OTP_RESEND_LIMIT_EXCEEDED
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_DE_REGISTERED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_USER_OPTED_FOR_OTP_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_USER_OPTED_FOR_OTP_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_ALREADY_INITIALIZED_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_0
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SOMETHING_WENT_WRONG_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_ACS_ERROR_CODE_001
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_ACS_ERROR_CODE_002
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_ACS_ERROR_CODE_003
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_ACS_ERROR_CODE_004
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_TRANSACTION_NOT_CREATED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.WIBMO_TRANSACTION_NULL
import com.payu.threedsbase.data.ACSActionParams
import com.payu.threedsbase.data.CardData
import com.payu.threedsbase.data.ChallengeParameter
import com.payu.threedsbase.data.HeadlessData
import com.payu.threedsbase.data.ImageDetails
import com.payu.threedsbase.data.PArqResponse
import com.payu.threedsbase.data.PayU3DS2ACSResponse
import com.payu.threedsbase.data.PayU3DS2Response
import com.payu.threedsbase.data.apiResponse.PayU3DS2MFAParam
import com.payu.threedsbase.enums.ACSActionType
import com.payu.threedsbase.enums.AuthType
import com.payu.threedsbase.enums.CardScheme
import com.payu.threedsbase.enums.PayU3DS2MFARequestType
import com.payu.threedsbase.enums.PayU3DS2MFAStatus
import com.payu.threedsbase.enums.PayU3DSDeregisterType
import com.payu.threedsbase.enums.TridentityFlow
import com.payu.threedsbase.interfaces.listeners.PayU3DS2BaseCallback
import com.payu.threedsbase.interfaces.listeners.PayU3DS2MFACallback
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.SdkUiInitializer.showAuthNModeSelectionScreen
import com.wibmo.threeds2.sdk.ChallengeUIStatusReceiver
import com.wibmo.threeds2.sdk.StatusCallBack
import com.wibmo.threeds2.sdk.ThreeDS2RequestorHelper
import com.wibmo.threeds2.sdk.ThreeDS2Service
import com.wibmo.threeds2.sdk.Transaction
import com.wibmo.threeds2.sdk.cfg.ChallengeParameters
import com.wibmo.threeds2.sdk.cfg.ConfigParameters
import com.wibmo.threeds2.sdk.error.InvalidInputException
import com.wibmo.threeds2.sdk.error.SDKAlreadyInitializedException
import com.wibmo.threeds2.sdk.error.SDKRuntimeException
import com.wibmo.threeds2.sdk.event.ACSPageEvents
import com.wibmo.threeds2.sdk.event.ActionType
import com.wibmo.threeds2.sdk.event.CompletionEvent
import com.wibmo.threeds2.sdk.event.ProtocolErrorEvent
import com.wibmo.threeds2.sdk.event.RuntimeErrorEvent
import com.wibmo.threeds2.sdk.event.UIData
import com.wibmo.threeds2.sdk.impl.WibmoThreeDS2ServiceImpl
import java.lang.ref.WeakReference
import java.util.Date
import org.json.JSONObject


object ThreeDSHelper {
    private var threeDS2Service: ThreeDS2Service? = null
    private var transaction: Transaction? = null
    private var activity: WeakReference<Activity>? = null
    private var isSeamless: Boolean? = null
    private var acsTransactionId: String? = null
    private var resendCount: Int = 0
    private var isProduction = true
    private var payU3DS2Config: PayU3DS2Config? = null
    private var wibmoConfigParameters: ConfigParameters? = null

    private val activityResumeWaiter = ActivityResumeWaiter()

    internal fun clean() {
        activityResumeWaiter.cancel()
        threeDS2Service = null
        transaction = null
        wibmoConfigParameters = null
        InternalConfig.mfaParams = null
        InternalConfig.merchantTxnId = null
        InternalConfig.deviceDeregistered = false
        InternalConfig.otpSubmitAttemptNumber = 0
        InternalConfig.acsTxnId = null
    }

    internal fun isInitialized(): Boolean {
        return threeDS2Service != null
    }

    private fun startTridentityWhenResumed(
        activity: Activity,
        challengeParameter: ChallengeParameter,
        flow: TridentityFlow,
        listener: PayU3DS2BaseCallback
    ) {
        activityResumeWaiter.waitForResume(
            activity,
            onResumed = { host ->
                initiateTridentitySDK(host, challengeParameter, flow, listener)
            },
            onGiveUp = { reportMfaSkipped(flow, listener) }
        )
    }

    private fun reportMfaSkipped(flow: TridentityFlow, listener: PayU3DS2BaseCallback) {
        val requestType = when (flow) {
            TridentityFlow.REGISTRATION -> PayU3DS2MFARequestType.REGISTRATION
            TridentityFlow.DEREGISTRATION -> PayU3DS2MFARequestType.DEREGISTRATION
            else -> return
        }
        val message = "Activity not available for MFA ${requestType.name.lowercase()}"
        Log.w("ThreeDSHelper", "MFA ${requestType.name} skipped - activity not ready")
        activity?.get()?.takeUnless { it.isDestroyed || it.isFinishing }?.let { host ->
            LoggingUtils.logMessage(
                host,
                LoggingConstants.PAYU_CARDS_REGISTRATION,
                LoggingConstants.FAILED,
                message,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                eventStatus = EventStatus.Failed
            )
        }
        if (listener is PayU3DS2MFACallback) {
            listener.mfaRegistrationStatus(
                PayU3DS2MFAResponse(requestType, PayU3DS2MFAStatus.FAILED, message = message)
            )
        }
    }

    /**
     * Method to initialise Wibmo SDK if success will return warnings else will
     * return error
     */
    internal fun initialize(
        activity: Activity,
        config: PayU3DS2Config?
    ): PayU3DS2Response {
        clean()
        resendCount = 0
        this.activity = WeakReference(activity)
        this.isSeamless = !config?.supportedUIMode.isNullOrEmpty()
        this.isProduction = config?.isProduction ?: true

        threeDS2Service = WibmoThreeDS2ServiceImpl()
        val wibmoUICustomisation = mapUICustomisationToWibmo(config!!.uiCustomisation)
        payU3DS2Config = config
        val wibmoInitStartTime = System.currentTimeMillis()
        try {
            val configParam = generateConfigParam(config)
            wibmoConfigParameters = configParam
            LoggingUtils.logMessage(
                activity,
                LoggingConstants.PAYU_CARDS_WIBMO_INIT,
                LoggingConstants.EVENT_VALUE_INIT_PARAMS,
                "txnID=${configParam.txnID} autoRead=${configParam.isAutoReadEnabled} " +
                        "autoSubmit=${configParam.isAutoSubmitEnable} " +
                        "supportedUIMode=${config.supportedUIMode?.joinToString()} " +
                        "isProduction=$isProduction"
            )

            threeDS2Service?.initialize(
                activity, configParam, APIConstants.LOCALE, wibmoUICustomisation
            )

            LoggingUtils.logMessage(
                activity,
                LoggingConstants.PAYU_CARDS_WIBMO_INIT,
                LoggingConstants.SUCCESS,
                LoggingConstants.THREE_DS_INITIALIZATION_SUCCESS,
                timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(wibmoInitStartTime),
                eventStatus = EventStatus.Success
            )

            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_0,
                null,
                Utils.mapWibmoWarningsToDeviceWarning(threeDS2Service!!.warnings)
            )


        } catch (e: InvalidInputException) {
            LoggingUtils.logMessage(
                activity,
                LoggingConstants.PAYU_CARDS_WIBMO_INIT,
                LoggingConstants.FAILED,
                e.message,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(wibmoInitStartTime),
                eventStatus = EventStatus.Failed
            )
            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                e.message!!,
                null
            )
        } catch (e: SDKAlreadyInitializedException) {
            LoggingUtils.logMessage(
                activity,
                LoggingConstants.PAYU_CARDS_WIBMO_INIT,
                LoggingConstants.FAILED,
                e.message,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(wibmoInitStartTime),
                eventStatus = EventStatus.Failed
            )
            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                SDK_ALREADY_INITIALIZED_ERROR_MESSAGE,
                null
            )
        } catch (e: SDKRuntimeException) {
            LoggingUtils.logMessage(
                activity,
                LoggingConstants.PAYU_CARDS_WIBMO_INIT,
                LoggingConstants.FAILED,
                e.message,
                eventSeverity = EventSeverity.High,
                eventType = EventType.Error,
                timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(wibmoInitStartTime),
                eventStatus = EventStatus.Failed
            )
            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                e.message!!,
                null
            )
        }
    }

    /**
     * Method to create transaction at wibmo end using SDK
     */
    private fun envCredential(testValue: String, prodValue: String): String =
        if (isProduction) prodValue else testValue

    private fun createTransaction(cardScheme: CardScheme, threeDSVersion: String): Transaction? {
        if (cardScheme == CardScheme.MASTERCARD) {
            return threeDS2Service!!.createTransaction(
                envCredential(BuildConfig.testMastercardDSServerId, BuildConfig.prodMastercardDSServerId),
                threeDSVersion
            )
        } else if (cardScheme == CardScheme.VISA) {
            return threeDS2Service!!.createTransaction(
                envCredential(BuildConfig.testVisaDSServerId, BuildConfig.prodVisaDSServerId),
                threeDSVersion
            )
        }
        return null
    }

    /**
     * Method to extract device details(pArs), it will return device details if success else
     * respective error
     */
    internal fun extractDeviceDetails(cardData: CardData): PayU3DS2Response {
        val startTime = System.currentTimeMillis()
        activity?.get()?.let {
            LoggingUtils.logMessage(
                it,
                LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                LoggingConstants.EVENT_VALUE_INIT_PARAMS,
                "${LoggingConstants.THREE_DS_DEVICE_DETAILS}, ${LoggingConstants.LEGACY_CARD_SCHEME}=${cardData.cardScheme?.name} threeDSVersion=${cardData.threeDSVersion}",
                timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
            )
        }
        if (cardData.cardScheme != null && cardData.threeDSVersion != null)
            transaction = createTransaction(cardData.cardScheme!!, cardData.threeDSVersion!!)
        else {
            activity?.get()?.let {
                LoggingUtils.logMessage(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.FAILED,
                    CARD_SCHEME_OR_THREE_DS_VERSION_NULL,
                    SDK_RESPONSE_STATUS_CODE_1,
                    eventSeverity = EventSeverity.High,
                    eventType = EventType.Error,
                    eventStatus = EventStatus.Failed
                )
            }

            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                CARD_SCHEME_OR_THREE_DS_VERSION_NULL,
                null
            )
        }
        if (transaction == null) {
            activity?.get()?.let {
                LoggingUtils.logMessage(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.FAILED,
                    WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE,
                    SDK_RESPONSE_STATUS_CODE_1,
                    eventSeverity = EventSeverity.High,
                    eventType = EventType.Error,
                    timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime),
                    eventStatus = EventStatus.Failed
                )
            }

            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                PayU3DS2ErrorConstants.SCHEME_NOT_RECOGNISED_ERROR_MESSAGE,
                null
            )
        }
        try {
            activity?.get()?.let {
                LoggingUtils.logMessage(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS_MAKE_PRAQ,
                    LoggingConstants.EVENT_VALUE_INIT_PARAMS,
                    LoggingConstants.LEGACY_MAKE_PARQ,
                    timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                )
            }

            val pArq = ThreeDS2RequestorHelper.makePArq(
                transaction!!.authenticationRequestParameters, Date()
            )
            val payuPArq = PArqResponse(
                pArq.sdkAppID,
                pArq.sdkEncData,
                pArq.sdkEphemPubKey.crv,
                pArq.sdkEphemPubKey.kty,
                pArq.sdkEphemPubKey.x,
                pArq.sdkEphemPubKey.y,
                pArq.sdkTransID,
                pArq.sdkReferenceNumber,
                "2.0.0"
            )

            activity?.get()?.let {
                LoggingUtils.logMessage(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.SUCCESS,
                    payuPArq.toString(),
                    timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime),
                    eventStatus = EventStatus.Success
                )
                CleverTapLoggingUtils.logAnalytics(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.SUCCESS,
                    isSeamless
                )
            }
            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_0,
                null,
                payuPArq
            )
        } catch (e: SDKRuntimeException) {
            activity?.get()?.let {
                LoggingUtils.logMessage(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.FAILED,
                    LoggingConstants.PARQ_EXCEPTION + e.message!!,
                    eventSeverity = EventSeverity.High,
                    eventType = EventType.Error,
                    timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime),
                    eventStatus = EventStatus.Failed
                )
                CleverTapLoggingUtils.logAnalytics(
                    it,
                    LoggingConstants.PAYU_CARDS_DEVICE_DETAILS,
                    LoggingConstants.FAILURE,
                    isSeamless
                )
            }

            return PayU3DS2Response(
                SDK_RESPONSE_STATUS_CODE_1,
                e.message!!,
                null
            )
        }
    }

    private fun buildMFAParamsInternal(
        payU3DS2MfaParam: PayU3DS2MFAParam?
    ): MFAParams? {
        payU3DS2MfaParam ?: return null

        val decryptedJson: JSONObject? = payU3DS2MfaParam.data?.takeIf { it.isNotEmpty() }?.let {
            try {
                JSONObject(PayU3DS2ContentCodec.getDataValueFromMFA(it))
            } catch (e: Exception) {
                Log.e("ThreeDSHelper", "MFA data decryption failed: ${e.message}")
                activity?.get()?.let { activity ->
                    LoggingUtils.logMessage(
                        activity,
                        PAYU_CARDS_CREQ,
                        LoggingConstants.FAILED,
                        LoggingConstants.THREE_DS_MFA_DATA_DECRYPTION_FAILED,
                        eventSeverity = EventSeverity.High,
                        eventType = EventType.Error,
                        eventStatus = EventStatus.Failed
                    )
                }
                null
            }
        }

        val mfaParams = MFAParams(
            cardId = decryptedJson?.optStringOrNull(APIConstants.RBA_CARD_ID),
            tempCardId = decryptedJson?.optStringOrNull(APIConstants.RBA_TEMP_CARD_ID),
            bankLogo = decryptedJson?.optStringOrNull(APIConstants.RBA_BANK_LOGO_URL),
            cardNetworkLogo = decryptedJson?.optStringOrNull(APIConstants.RBA_NETWORK_LOGO),
            cardBin = decryptedJson?.optStringOrNull(APIConstants.RBA_CARD_BIN),
            merchantId = decryptedJson?.optStringOrNull(APIConstants.RBA_MERCHANT_ID),
            merchantMobileNo = decryptedJson?.optStringOrNull(APIConstants.RBA_MERCHANT_MOBILE_NO),
            clientId = decryptedJson?.optStringOrNull(APIConstants.RBA_CLIENT_ID),
            transactionTimeout = decryptedJson?.optInt(
                APIConstants.RBA_FALLBACK_TRANSACTION_TIMEOUT,
                0
            ) ?: 0,
            registrationTimeout = decryptedJson?.optInt(
                APIConstants.RBA_FALLBACK_REGISTRATION_TIMEOUT,
                0
            ) ?: 0,
            fallbackVisibilityDuration = decryptedJson?.optInt(
                APIConstants.RBA_FALLBACK_VISIBILITY_TIMEOUT,
                0
            ) ?: 0,
            bankId = decryptedJson?.optStringOrNull(APIConstants.RBA_BANK_ID),
            customerId = decryptedJson?.optStringOrNull(APIConstants.RBA_CUSTOMER_ID),
            themeType = decryptedJson?.optStringOrNull(APIConstants.RBA_THEME_TYPE),
            hashKey = decryptedJson?.optStringOrNull(APIConstants.RBA_HASH_KEY),
            bindingType = decryptedJson?.optStringOrNull(APIConstants.RBA_BINDING_TYPE),
            tdyUrl = decryptedJson?.optStringOrNull(APIConstants.RBA_TDY_URL),
            tdyApiKey = decryptedJson?.optStringOrNull(APIConstants.RBA_TDY_API_KEY),
            autoInvokeBiometricTime = decryptedJson?.optDouble(
                APIConstants.RBA_AUTO_INVOKE_BIOMETRIC_TIME,
                0.0
            ) ?: 0.0,
            status = decryptedJson?.optStringOrNull(APIConstants.STATUS) ?: payU3DS2MfaParam.status,
            messageType = decryptedJson?.optStringOrNull(APIConstants.RBA_MESSAGE_TYPE)
                ?: payU3DS2MfaParam.messageType,
            tdyClientId = decryptedJson?.optStringOrNull(APIConstants.RBA_TDY_CLIENT_ID)
                ?: decryptedJson?.optStringOrNull(APIConstants.RBA_CLIENT_ID)
                ?: payU3DS2MfaParam.tdyClientId,
            tdyCardId = decryptedJson?.optStringOrNull(APIConstants.RBA_TDY_CARD_ID)
                ?: decryptedJson?.optStringOrNull(APIConstants.RBA_CARD_ID)
                ?: payU3DS2MfaParam.tdyCardId,
            issuerImage = decryptedJson?.optStringOrNull(APIConstants.RBA_ISSUER_IMAGE)
                ?: decryptedJson?.optStringOrNull(APIConstants.RBA_BANK_LOGO_URL)
                ?: payU3DS2MfaParam.issuerImage,
            psImage = decryptedJson?.optStringOrNull(APIConstants.RBA_PS_IMAGE)
                ?: decryptedJson?.optStringOrNull(APIConstants.RBA_NETWORK_LOGO)
                ?: payU3DS2MfaParam.psImage,
        )
        val merchantKey = decryptedJson?.optStringOrNull(APIConstants.RBA_MERCHANT_KEY)
        val txnAmount = decryptedJson?.optStringOrNull(APIConstants.RBA_TXN_AMOUNT)
        merchantKey?.let { InternalConfig.key = it }
        applyUpdatedTxnAmount(txnAmount)

        val merchantTxnId = decryptedJson?.optStringOrNull(APIConstants.RBA_MERCHANT_TXN_ID)
        merchantTxnId?.let { InternalConfig.merchantTxnId = it }
        return mfaParams
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        val value = optString(key)
        return if (value.isNullOrEmpty() || value == "null") null else value
    }

    /**
     * Method to invoke challenge i.e.; to open screen where user will enter OTP to validate
     * transaction. It will return below values it success else error code and message.
     *  String sdkTransactionID;
     *  String transactionStatus;
     *  String data;
     *  String threeDSServerTransID;
     *  String acsTransID;
     *  String dsTransID;
     */
    internal fun initiateChallenge(
        activity: Activity,
        challengeParameter: ChallengeParameter,
        listener: PayU3DS2BaseCallback
    ) {
        if (InternalConfig.isDecoupledFlow) {
            SdkUiInitializer.useHalfScreenProgressLoader = true
            (activity as? AppCompatActivity)?.let { appCompatActivity ->
                appCompatActivity.runOnUiThread {
                    SdkUiInitializer.showProgressLoader(appCompatActivity)
                }
            }

        }
        InternalConfig.acsTxnId = challengeParameter.acsTransactionID
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_CREQ,
            LoggingConstants.EVENT_VALUE_INIT_PARAMS,
            challengeParameter.toString(),
        )
        if (transaction == null) {
            ThreeDSHelper.activity?.get()?.let {
                logCReqFailed(it, WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE)
            }
            listener.onError(
                WIBMO_TRANSACTION_NOT_CREATED_ERROR_CODE,
                WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE
            )
            return
        }
        val mfaParams = buildMFAParamsInternal(challengeParameter.payU3DS2MfaParam)
        InternalConfig.mfaParams = mfaParams
        if (mfaParams == null) {
            LoggingUtils.logMessage(
                activity,
                PAYU_CARDS_CREQ,
                THREE_DS_NO_MFA_PARAMS,
            )
        }
        /***
         * if cardId or cardBin or clientId is null that mean this txn cannot go via MFA
         */
        LoggingUtils.logMessage(
            activity,
            PAYU_CARDS_CREQ,
            THREE_DS_MFA_CHECK_STARTED,
        )
        if (InternalConfig.mfaParams == null || InternalConfig.mfaParams?.cardId.isNullOrEmpty()
            || InternalConfig.mfaParams?.cardBin.isNullOrEmpty() || InternalConfig.mfaParams?.clientId.isNullOrEmpty()
            || InternalConfig.mfaParams?.messageType == "00"
        ) {
            doChallenge(activity, challengeParameter, listener)
            return
        }

        CleverTapLoggingUtils.logAnalytics(
            activity, OOB_ELIGIBLE,
            isSeamless = isSeamless
        )

        /**
         * Initialise tridentity SDK and if init is success check registration status else move to OTP flow
         */
        initiateTridentitySDK(activity, challengeParameter, TridentityFlow.TRANSACTION, listener)
    }


    private fun initiateTridentitySDK(
        activity: Activity,
        challengeParameter: ChallengeParameter,
        tridentityFlow: TridentityFlow,
        listener: PayU3DS2BaseCallback
    ) {

        TridentityHelper.startTridentityFlow(
            activity as AppCompatActivity,
            isProduction,
            challengeParameter,
            tridentityFlow,
            payU3DS2Config,
            object : PayU3DS2BaseCallback {
                override fun onSuccess(response: Any) {
                    if (tridentityFlow == TridentityFlow.DEREGISTRATION) {
                        val payU3DS22MFAResponse = PayU3DS2MFAResponse(
                            PayU3DS2MFARequestType.DEREGISTRATION,
                            PayU3DS2MFAStatus.SUCCESS
                        )
                        if (listener is PayU3DS2MFACallback) {
                            listener.mfaRegistrationStatus(payU3DS22MFAResponse)
                        } else {
                            listener.onSuccess(payU3DS22MFAResponse)
                        }
                        clean()
                    } else if (tridentityFlow != TridentityFlow.REGISTRATION) {
                        doChallenge(activity, challengeParameter, listener)
                    } else {
                        val payU3DS22MFAResponse = PayU3DS2MFAResponse(
                            PayU3DS2MFARequestType.REGISTRATION,
                            PayU3DS2MFAStatus.SUCCESS
                        )
                        if (listener is PayU3DS2MFACallback) {
                            listener.mfaRegistrationStatus(payU3DS22MFAResponse)
                        } else {
                            listener.onSuccess(payU3DS22MFAResponse)
                        }
                        clean()
                    }

                }

                override fun onError(errorCode: Int, errorMessage: String) {
                    Log.d(
                        "StartTridentity_onError",
                        "MA response: tridentityFlow" + errorCode + " " + errorMessage
                    )
                    /**
                     * error code check added to see if error was because of device binding failed
                     * or bcz of authN using MFA failed.
                     * If device binding failed then we have to start doChallenge else error callback
                     * has be be returned
                     * if txn failed don't go to otp flow else start OTP flow if TridentityFlow = Transaction
                     */
                    if (tridentityFlow != TridentityFlow.REGISTRATION && tridentityFlow != TridentityFlow.DEREGISTRATION) {
                        LoggingUtils.logMessageWithAdditionalKeys(
                            activity,
                            PAYU_CARDS_CREQ,
                            LoggingConstants.OOB_OTP_TRANSACTION,
                            mapOf(
                                LoggingConstants.KEY_TRIGGER to LoggingConstants.NUDGE_TRIGGER_RETRY_EXHAUSTED
                            ),
                            eventSeverity = EventSeverity.Low,
                            eventType = EventType.Info
                        )
                        doChallenge(activity, challengeParameter, listener)
                    } else {
                        if (listener is PayU3DS2MFACallback) {
                            when (tridentityFlow) {
                                TridentityFlow.REGISTRATION -> listener.mfaRegistrationStatus(
                                    PayU3DS2MFAResponse(
                                        PayU3DS2MFARequestType.REGISTRATION,
                                        PayU3DS2MFAStatus.FAILED,
                                        message = errorMessage
                                    )
                                )

                                TridentityFlow.DEREGISTRATION -> listener.mfaRegistrationStatus(
                                    PayU3DS2MFAResponse(
                                        PayU3DS2MFARequestType.DEREGISTRATION,
                                        PayU3DS2MFAStatus.FAILED,
                                        message = errorMessage,
                                        deregistrationType = if (errorCode == RBA_DEVICE_DE_REGISTERED_ERROR_CODE)
                                            PayU3DSDeregisterType.AUTO else PayU3DSDeregisterType.MANUAL
                                    )
                                )

                                else -> listener.onError(errorCode, errorMessage)
                            }
                        } else {
                            listener.onError(errorCode, errorMessage)
                        }
                    }
                }
            })
    }


    fun doChallenge(
        activity: Activity,
        challengeParameter: ChallengeParameter,
        listener: PayU3DS2BaseCallback
    ) {

        LoggingUtils.logMessage(
            activity,
            if (InternalConfig.isOOBInitiatedCREQ) LoggingConstants.PAYU_CARDS_CREQ_2 else LoggingConstants.PAYU_CARDS_CREQ,
            LoggingConstants.EVENT_VALUE_DO_CHALLENGE_INIT_PARAMS,
            challengeParameter.toString()
        )

        if (transaction == null) {
            ThreeDSHelper.activity?.get()?.let {
                logCReqFailed(it, WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE)
            }
            listener.onError(
                WIBMO_TRANSACTION_NOT_CREATED_ERROR_CODE,
                WIBMO_TRANSACTION_NOT_CREATED_ERROR_MESSAGE
            )
            return
        }

        val challengeParameters = ChallengeParameters()
        challengeParameters.acsRefNumber = challengeParameter.acsRefNumber
        challengeParameters.acsSignedContent = challengeParameter.acsSignedContent
        challengeParameters.acsTransactionID = challengeParameter.acsTransactionID
        challengeParameters.name = challengeParameter.payU3DS2MfaParam?.name
        challengeParameters.id = challengeParameter.payU3DS2MfaParam?.id
        InternalConfig.acsTxnId = challengeParameter.acsTransactionID
        if (!InternalConfig.mfaParams?.cardId.isNullOrEmpty() && InternalConfig.deviceDeregistered == false) {
            challengeParameters.tdyCardId = InternalConfig.mfaParams?.cardId
        } else {
            SdkUiInitializer.useHalfScreenProgressLoader = false
        }
        challengeParameters.set3DSServerTransactionID(challengeParameter.threeDSServerTransactionID)

        CleverTapLoggingUtils.logAnalytics(
            activity, LoggingConstants.THREE_DS_ACS_INITIATED, isSeamless = isSeamless
        )
        var startTime = System.currentTimeMillis()
        transaction?.doChallenge(
            activity, challengeParameters, object : ChallengeUIStatusReceiver {
                override fun completed(completionEvent: CompletionEvent) {
                    if (InternalConfig.isDecoupledFlow ){
                        SdkUiInitializer.hideProgressLoader()
                    }
                    val elapsedMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                    if (!activity.isDestroyed && !activity.isFinishing) {
                        LoggingUtils.logMessage(
                            activity,
                            if (InternalConfig.isOOBInitiatedCREQ) LoggingConstants.PAYU_CARDS_CREQ_2 else LoggingConstants.PAYU_CARDS_CREQ,
                            LoggingConstants.LEGACY_API_SUCCESS,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + completionEvent.transactionStatus,
                            timeTakenMs = elapsedMs,
                            eventStatus = EventStatus.Success
                        )
                        if (InternalConfig.isOOBInitiatedCREQ)
                            InternalConfig.isOOBInitiatedCREQ = false
                    }

                    val mfaConsentGiven = completionEvent.isConsentGiven
                    val map = HashMap<String, Any>()
                    map.put(APIConstants.TRANSACTION_STATUS, completionEvent.transactionStatus)

                    if (mfaConsentGiven && completionEvent.transactionStatus.equals("Y") && !completionEvent.isMFARegistered) {
                        // Registration flow
                        SdkUiInitializer.useHalfScreenProgressLoader = false
                        val customerId = completionEvent.customerId
                        val bindingType = completionEvent.bindingType
                        val payU3DS22MFAResponse = PayU3DS2MFAResponse(
                            PayU3DS2MFARequestType.REGISTRATION, PayU3DS2MFAStatus.INITIATED,
                            timeout = InternalConfig.mfaParams?.registrationTimeout
                        )

                        if (InternalConfig.isDecoupledFlow && listener is PayU3DS2MFACallback) {
                            listener.mfaRegistrationStatus(payU3DS22MFAResponse)
                            listener.onSuccess(map)
                        } else {
                            map.put(APIConstants.MFA_REGISTRATION_STATUS, payU3DS22MFAResponse)
                            listener.onSuccess(map)
                        }

                        if (!bindingType.isNullOrBlank()) {
                            InternalConfig.mfaParams?.bindingType = bindingType
                        }
                        if (!customerId.isNullOrBlank()) {
                            InternalConfig.mfaParams?.customerId = customerId
                        }

                        // NEW: Wait for activity resume before calling Tridentity
                        startTridentityWhenResumed(
                            activity,
                            challengeParameter,
                            TridentityFlow.REGISTRATION,
                            listener
                        )

                    } else if (mfaConsentGiven && completionEvent.transactionStatus.equals("Y") && completionEvent.isMFARegistered) {
                        // Deregistration flow
                        val payU3DS22MFAResponse = PayU3DS2MFAResponse(
                            PayU3DS2MFARequestType.DEREGISTRATION,
                            PayU3DS2MFAStatus.INITIATED,
                            message = PayU3DS2Constants.DEREGISTER_MESSAGE,
                            timeout = InternalConfig.mfaParams?.transactionTimeout,
                            PayU3DSDeregisterType.MANUAL
                        )

                        if (InternalConfig.isDecoupledFlow && listener is PayU3DS2MFACallback) {
                            listener.mfaRegistrationStatus(payU3DS22MFAResponse)
                            listener.onSuccess(map)
                        } else {
                            map.put(APIConstants.MFA_REGISTRATION_STATUS, payU3DS22MFAResponse)
                            listener.onSuccess(map)
                        }

                        // NEW: Wait for activity resume
                        startTridentityWhenResumed(
                            activity,
                            challengeParameter,
                            TridentityFlow.DEREGISTRATION,
                            listener
                        )
                    } else {
                        Log.d(
                            "Check3DS onSuccess",
                            "MA response: MFA_REGISTRATION_STATUS3"
                        )
                        listener.onSuccess(map)
                    }
                }

                override fun cancelled(completionEvent: CompletionEvent) {
                    SdkUiInitializer.hideProgressLoader()
                    val elapsedMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                    if (!activity.isDestroyed && !activity.isFinishing) {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + completionEvent.error,
                            elapsedMs
                        )
                        LoggingUtils.logMessageWithAdditionalKeys(activity, LoggingConstants.PAYU_CARDS_CREQ,
                            LoggingConstants.EVENT_VALUE_BACK_BUTTON_PRESSED, mapOf(
                                LoggingConstants.SCREEN_NAME to LoggingConstants.OTP_SCREEN
                            ))
                        if (InternalConfig.isOOBInitiatedCREQ)
                            InternalConfig.isOOBInitiatedCREQ = false
                    }
                    listener.onError(
                        PayU3DS2ErrorConstants.CHALLENGE_CANCEL_ERROR_CODE,
                        completionEvent.error
                    )
                }


                override fun timedout() {
                    SdkUiInitializer.hideProgressLoader()
                    val elapsedMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                    if (!activity.isDestroyed && !activity.isFinishing) {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + PayU3DS2ErrorConstants.CHALLENGE_TIMEDOUT_ERROR_MESSAGE,
                            elapsedMs
                        )
                        if (InternalConfig.isOOBInitiatedCREQ)
                            InternalConfig.isOOBInitiatedCREQ = false
                    }
                    listener.onError(
                        CHALLENGE_TIMEDOUT_ERROR_CODE,
                        PayU3DS2ErrorConstants.CHALLENGE_TIMEDOUT_ERROR_MESSAGE
                    )
                }

                override fun protocolError(protocolErrorEvent: ProtocolErrorEvent) {
                    SdkUiInitializer.hideProgressLoader()
                    transaction?.close()
                    val elapsedMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                    if (protocolErrorEvent.errorMessage != null && !protocolErrorEvent.errorMessage.errorDescription.isNullOrEmpty()) {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + protocolErrorEvent.errorMessage.errorDescription,
                            elapsedMs
                        )
                        listener.onError(
                            PayU3DS2ErrorConstants.CHALLENGE_PROTOCOL_ERROR_CODE,
                            protocolErrorEvent.errorMessage.errorDescription
                        )
                    } else {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE_PROTOCOL_ERROR,
                            elapsedMs
                        )
                        listener.onError(
                            PayU3DS2ErrorConstants.CHALLENGE_PROTOCOL_ERROR_CODE,
                            SOMETHING_WENT_WRONG_ERROR_MESSAGE
                        )
                    }
                    if (InternalConfig.isOOBInitiatedCREQ)
                        InternalConfig.isOOBInitiatedCREQ = false
                }

                override fun runtimeError(runtimeErrorEvent: RuntimeErrorEvent) {
                    SdkUiInitializer.hideProgressLoader()
                    val elapsedMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                    if (!runtimeErrorEvent.errorMessage.isNullOrEmpty()) {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + runtimeErrorEvent.errorMessage,
                            elapsedMs
                        )
                        listener.onError(
                            PayU3DS2ErrorConstants.CHALLENGE_RUNTIME_ERROR_CODE,
                            runtimeErrorEvent.errorMessage
                        )
                    } else {
                        logCReqFailed(
                            activity,
                            LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE + LoggingConstants.THREE_DS_SDK_CHALLENGE_RESPONSE_RUNTIME_ERROR,
                            elapsedMs
                        )

                        listener.onError(
                            PayU3DS2ErrorConstants.CHALLENGE_RUNTIME_ERROR_CODE,
                            SOMETHING_WENT_WRONG_ERROR_MESSAGE
                        )
                    }
                    if (InternalConfig.isOOBInitiatedCREQ)
                        InternalConfig.isOOBInitiatedCREQ = false
                }

                override fun acsPageActionTaken(acsPageEvents: ACSPageEvents) {
                    if (acsPageEvents == ACSPageEvents.THREEDS_ACS_LOADED && !activity.isDestroyed && !activity.isFinishing) {
                        SdkUiInitializer.hideProgressLoader()  // add this line
                        val acsLoadMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                        Log.d(
                            "PAYU_TIMING",
                            "[T5] THREEDS_ACS_LOADED | doChallenge→ACS loaded: ${acsLoadMs}ms"
                        )
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_WIMBO_3DS_CREQ_ACTION,
                            acsPageEvents.name,
                            null,
                            null,
                            EventSeverity.Low,
                            EventType.Info,
                            acsLoadMs
                        )
                    } else {
                        startTime =
                            System.currentTimeMillis()
                        CleverTapLoggingUtils.logAnalytics(
                            activity,
                            acsPageEvents.name,
                            isSeamless = isSeamless
                        )
                        val acsLoadMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_WIMBO_3DS_CREQ_ACTION,
                            acsPageEvents.name,
                            null,
                            null,
                            EventSeverity.Low,
                            EventType.Info,
                            acsLoadMs
                        )
                    }
                }

                override fun acsPageLogging(jsonString: String?) {
                    jsonString?.let { LoggingUtils.logMessage(activity, it) }
                }

                override fun oobInitiated() {
                    if (!activity.isDestroyed && !activity.isFinishing) {
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_CARDS_CREQ,
                            LoggingConstants.ACS_OOB_CONTINUE,
                            LoggingConstants.OOB_INITIATED_CALLBACK_3DS,
                            eventSeverity = EventSeverity.Low,
                            timeTakenMs = Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    }

                    CleverTapLoggingUtils.logAnalytics(
                        activity,
                        ACSPageEvents.OOB_CONTINUE.name,
                        isSeamless = isSeamless
                    )

                    handleRbaSelectionScreen(activity, challengeParameter, listener)
                }

                override fun uiResponseData(uiData: UIData) {
                    if (!activity.isDestroyed && !activity.isFinishing)
                        LoggingUtils.logMessage(
                            activity,
                            PAYU_WIMBO_3DS_CREQ_ACTION,
                            ACSPageEvents.THREEDS_ACS_LOADED.name,
                            "uiResponseData",
                            null,
                            EventSeverity.Low,
                            EventType.Info,
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    CleverTapLoggingUtils.logAnalytics(
                        activity, ACSPageEvents.THREEDS_ACS_LOADED.name, isSeamless = isSeamless
                    )
                    listener.onSuccess(
                        HeadlessData(
                            uiData.acsTransactionID,
                            uiData.acsRenderingType,
                            ImageDetails(
                                uiData.issuerImage.medium,
                                uiData.issuerImage.high,
                                uiData.issuerImage.extraHigh
                            ),
                            ImageDetails(
                                uiData.issuerImage.medium,
                                uiData.issuerImage.high,
                                uiData.issuerImage.extraHigh
                            )
                        )
                    )
                }
            }, PayU3DS2Constants.SDK_CHALLENGE_TIMEOUT
        )
    }

    private fun handleRbaSelectionScreen(
        activity: Activity,
        challengeParameter: ChallengeParameter,
        listener: PayU3DS2BaseCallback,
    ) {
        SdkUiInitializer.useHalfScreenProgressLoader = true
        val appCompatActivity = activity as? AppCompatActivity
        appCompatActivity?.let {
            showAuthNModeSelectionScreen(
                it, InternalConfig.mfaParams?.bankLogo, InternalConfig.mfaParams?.cardNetworkLogo,
                InternalConfig.merchantName,
                InternalConfig.txnAmount,
                InternalConfig.mfaParams?.transactionTimeout,
                InternalConfig.mfaParams?.fallbackVisibilityDuration,
                InternalConfig.mfaParams?.autoInvokeBiometricTime,
                payU3DS2Config?.uiCustomisation,
                false,
            ) { authType, status, reasonCode ->
                when (authType) {
                    AuthType.BIOMETRIC -> initiateTridentitySDK(
                        activity,
                        challengeParameter,
                        TridentityFlow.OOB_INITIATED,
                        listener
                    )

                    AuthType.OTP -> {
                        val proceedToOtpChallenge = {
                            doChallenge(
                                activity,
                                challengeParameter,
                                listener
                            )
                        }
                        if (!status.isNullOrEmpty()) {
                            processAndUpdate(status, reasonCode, proceedToOtpChallenge)
                        } else {
                            proceedToOtpChallenge()
                        }
                    }

                    AuthType.USER_CANCELLED -> {
                        listener.onError(
                            PayU3DS2ErrorConstants.CHALLENGE_CANCEL_ERROR_CODE,
                            PayU3DS2ErrorConstants.USER_CANCELLED_ERROR_MESSAGE
                        )
                    }

                    else -> {
                        listener.onError(
                            RBA_USER_OPTED_FOR_OTP_ERROR_CODE,
                            RBA_USER_OPTED_FOR_OTP_ERROR_MESSAGE
                        )
                    }
                }
            }
        }
    }


    /**
     * Method to generate config parameters required for initialisation of Wibmo SDK
     */
    private fun generateConfigParam(config: PayU3DS2Config): ConfigParameters {
        val configParameters = ConfigParameters()
        configParameters.licenseKey = envCredential(
            BuildConfig.testLicenseKey, BuildConfig.prodLicenseKey
        )
        configParameters.addParam(
            envCredential(BuildConfig.testVisaPublicKey, BuildConfig.prodVisaPublicKey),
            envCredential(BuildConfig.testVisaDSServerId, BuildConfig.prodVisaDSServerId)
        )
        configParameters.addParam(
            envCredential(BuildConfig.testMastercardPublicKey, BuildConfig.prodMastercardPublicKey),
            envCredential(BuildConfig.testMastercardDSServerId, BuildConfig.prodMastercardDSServerId)
        )
        configParameters.txnID = InternalConfig.requestId
        configParameters.isAutoReadEnabled = config.autoRead
        configParameters.isAutoSubmitEnable = config.autoSubmit
        configParameters.setCustomDialogLoader(
            config.showDefaultLoader, config.defaultProgressLoaderColor
        )
        if (!config.supportedUIMode.isNullOrEmpty()) configParameters.supportedUiMode =
            config.supportedUIMode?.toTypedArray()

        if (config.enableCustomizedOtpUIFlow) {

            Utils.validateCustomACSContent(config.amount, config.merchantName)
            configParameters.isEnableNoDetailUI = config.enableCustomizedOtpUIFlow
            configParameters.isShowTxnTimer = config.enableTxnTimeoutTimer
            configParameters.merchantName = config.merchantName
            val formattedAmount = formatTxnAmount(config.amount ?: "")
            configParameters.txnAmount = "${config.currency.value}${formattedAmount}"
            configParameters.otpContent =
                if (config.acsContentConfig?.otpContent?.trim()
                        .isNullOrEmpty()
                ) PayU3DS2Constants.OTP_SENT_DEFAULT_MESSAGE else config.acsContentConfig?.otpContent
            if (!config.acsContentConfig?.submitButtonTitle?.trim().isNullOrEmpty())
                configParameters.submitButtonTitle = config.acsContentConfig?.submitButtonTitle
            if (!config.acsContentConfig?.resendButtonTitle?.trim().isNullOrEmpty())
                configParameters.resendButtonTitle = config.acsContentConfig?.resendButtonTitle

            if (!config.acsContentConfig?.resendInfoContent?.trim().isNullOrEmpty())
                configParameters.resendInfoString = config.acsContentConfig?.resendInfoContent
            if (!config.acsContentConfig?.maxResendInfoContent?.trim().isNullOrEmpty())
                configParameters.maxResendInfoString = config.acsContentConfig?.maxResendInfoContent
            InternalConfig.merchantName = config.merchantName
            InternalConfig.txnAmount = formattedAmount
        }
        configParameters.isEnableMFAViaBiometric = config.enableMFAViaBiometric
        return configParameters
    }

    private fun formatTxnAmount(amount: String): String {
        val formattedSplitAmount = amount.split(".")
        var formattedAmount = formattedSplitAmount[0]
        if (formattedSplitAmount.size > 1 && formattedSplitAmount[1] != "")
            formattedAmount = String.format("%.2f", amount.toDouble())
        return formattedAmount
    }

    private fun applyUpdatedTxnAmount(amount: String?) {
        amount?.let {
            if (!amount.isBlank()){
                val formatted = formatTxnAmount(amount)
                payU3DS2Config?.amount = amount
                InternalConfig.txnAmount = formatted
                wibmoConfigParameters?.txnAmount = "${payU3DS2Config?.currency?.value}${formatted}"
            }
        }
    }

    fun acsAction(
        acsActionType: ACSActionType?,
        acsActionParams: ACSActionParams?,
        callback: PayU3DS2BaseCallback
    ) {
        if (acsActionType == null) return callback.onError(
            ACTION_TYPE_NULL_ERROR_CODE, ACTION_TYPE_NULL
        )
        if (acsActionParams == null) return callback.onError(
            ACS_ACTION_PARAMS_NULL_ERROR_CODE, ACS_ACTION_PARAMS_NULL
        )
        if (acsActionParams.acsTransactionID.isNullOrEmpty()) return callback.onError(
            ACS_ACTION_PARAMS_NULL_ERROR_CODE, ACS_TXN_ID_NULL
        )
        if (acsActionParams.acsRenderingType.isNullOrEmpty()) return callback.onError(
            ACS_ACTION_PARAMS_NULL_ERROR_CODE, ACS_RENDERING_TYPE_NULL
        )
        if (acsActionType == ACSActionType.SUBMIT && acsActionParams.challengeData.isNullOrEmpty()) return callback.onError(
            ACS_ACTION_PARAMS_NULL_ERROR_CODE, ACS_OTP_DATA_NULL
        )
        if (transaction == null) return callback.onError(
            WIBMO_TRANSACTION_NOT_CREATED_ERROR_CODE, WIBMO_TRANSACTION_NULL
        )

        activity?.get()?.let {
            LoggingUtils.logMessage(
                it,
                PAYU_CARDS_CREQ,
                LoggingConstants.EVENT_VALUE_INIT_PARAMS,
                LoggingConstants.THREE_DS_HEADLESS_ACTION
            )
        }

        if (resendCount == 3 && acsTransactionId.equals(acsActionParams.acsTransactionID) &&
            acsActionType == ACSActionType.RESEND
        ) {
            return callback.onError(
                ACS_OTP_RESEND_LIMIT_EXCEEDED,
                OTP_RESEND_LIMIT_EXCEEDED
            )
        }

        if (acsActionType == ACSActionType.RESEND)
            resendCount++

        activity?.get()?.let {
            CleverTapLoggingUtils.logAnalytics(
                it,
                if (acsActionType == ACSActionType.SUBMIT) ACSPageEvents.SUBMIT_OTP.name else ACSPageEvents.RESEND_OTP.name,
                isSeamless = isSeamless
            )
        }

        val request = HashMap<String, Any>()
        request[APIConstants.ACS_TXN_ID] = acsActionParams.acsTransactionID.toString()
        request[APIConstants.ACS_RENDERING_TYPE] = acsActionParams.acsRenderingType.toString()

        if (!acsActionParams.challengeData.isNullOrEmpty()) request[APIConstants.OTP_CHALLENGE_DATA] =
            acsActionParams.challengeData.toString()
        transaction?.submitAction(
            mapPayUActionTypeToWibmoActionType(acsActionType),
            request,
            object : StatusCallBack {
                override fun onSuccess(
                    message: String?,
                    actionType: ActionType,
                    uiData: UIData?
                ) {
                    activity?.get()?.let {
                        LoggingUtils.logMessage(
                            it,
                            PAYU_CARDS_CREQ,
                            LoggingConstants.SUCCESS,
                            "${LoggingConstants.THREE_DS_ACS_ACTION_SUCCESS} actionType: ${actionType.name}",
                            eventStatus = EventStatus.Success
                        )
                    }
                    val payU3DS2ACSResponse = PayU3DS2ACSResponse(
                        if (actionType == ActionType.RESEND) OTP_RESENT_SUCCESSFULLY else message,
                        Utils.mapWibmoActionTypeToPayUActionType(actionType),
                        HeadlessData(
                            uiData?.acsTransactionID,
                            uiData?.acsRenderingType,

                            ImageDetails(
                                uiData?.issuerImage?.medium,
                                uiData?.issuerImage?.high,
                                uiData?.issuerImage?.extraHigh
                            ),
                            ImageDetails(
                                uiData?.issuerImage?.medium,
                                uiData?.issuerImage?.high,
                                uiData?.issuerImage?.extraHigh
                            )
                        )
                    )

                    callback.onSuccess(
                        payU3DS2ACSResponse
                    )

                }

                override fun onError(errorCode: String?, errorMessage: String?, p2: UIData?) {
                    val errorCodeInt = when (errorCode) {
                        WIBMO_ACS_ERROR_CODE_001 -> ACS_INVALID_OTP_SUBMIT
                        WIBMO_ACS_ERROR_CODE_002 -> ACS_TXN_CANCELLED
                        WIBMO_ACS_ERROR_CODE_003 -> ACTION_API_TIMEOUT
                        WIBMO_ACS_ERROR_CODE_004 -> ACS_OTP_SUBMISSION_FAILED
                        else -> {
                            ACS_ACTION_ERROR_CODE
                        }

                    }
                    activity?.get()?.let {
                        logCReqFailed(
                            it,
                            "${LoggingConstants.THREE_DS_ACTION_ERROR}  ${acsActionType.name} $errorCode $errorMessage"
                        )
                    }
                    callback.onError(
                        errorCodeInt, if (!errorMessage.isNullOrEmpty()) errorMessage
                        else SOMETHING_WENT_WRONG_ERROR_MESSAGE
                    )
                }
            })
    }

    private fun logCReqFailed(
        activity: Activity,
        data: String,
        timeTakenMs: Long = 0
    ) {
        LoggingUtils.logMessage(
            activity,
            if (InternalConfig.isOOBInitiatedCREQ) LoggingConstants.PAYU_CARDS_CREQ_2 else LoggingConstants.PAYU_CARDS_CREQ,
            LoggingConstants.FAILED,
            data,
            eventSeverity = EventSeverity.High,
            eventType = EventType.Error,
            timeTakenMs = timeTakenMs,
            eventStatus = EventStatus.Failed
        )
    }
}