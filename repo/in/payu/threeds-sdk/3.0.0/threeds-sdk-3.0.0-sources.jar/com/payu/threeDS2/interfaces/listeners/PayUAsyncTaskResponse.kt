package com.payu.threeDS2.interfaces.listeners

interface PayUAsyncTaskResponse {
    fun onSuccess(response: Any, executionTime: Long, httpCode: Int? = null)
    fun onFailure(errorCode: Int, errorMessage: String, executionTime: Long, httpCode: Int? = null)
}
