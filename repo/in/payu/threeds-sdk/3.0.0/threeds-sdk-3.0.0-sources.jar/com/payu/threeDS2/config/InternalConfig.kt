package com.payu.threeDS2.config

import com.payu.threeDS2.data.MFAParams

internal object InternalConfig {
    var key: String? = null
    var requestId: String? = null
    var authenticateOnly: Boolean = false
    var referenceId: String? = null
    var merchantName: String? = null
    var txnAmount: String? = null
    var deviceDeregistered: Boolean? = false
    var acsTxnId: String? = null
    var otpSubmitAttemptNumber: Int = 0
    var mfaParams: MFAParams? = null
    var merchantTxnId: String? = null

    var isOOBInitiatedCREQ: Boolean = false
    var isDecoupledFlow: Boolean = false


}
