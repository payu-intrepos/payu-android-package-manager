package com.payu.gpay.utils;

import android.view.View;

import com.payu.gpay.GpayPaymentType;
import com.payu.gpay.callbacks.PayUGPayCallback;

public enum GPayData {
    SINGLETON;
    private View payUCustomDialogView;
    private PayUGPayCallback payUGPayCallback;
    private String webServiceUrl = "";
    private String postUrl;
    private GpayPaymentType currentPaymentType;
    private PaymentTypeForMerchant paymentTypeForMerchant;

    public PaymentTypeForMerchant getPaymentTypeForMerchant() {
        return paymentTypeForMerchant;
    }

    public void setPaymentTypeForMerchant(PaymentTypeForMerchant paymentTypeForMerchant) {
        this.paymentTypeForMerchant = paymentTypeForMerchant;
    }


    public GpayPaymentType getCurrentPaymentType() {
        return this.currentPaymentType;
    }

    public void setCurrentPaymentType(GpayPaymentType currentPaymentType) {
        this.currentPaymentType = currentPaymentType;
    }

    public String getWebServiceUrl() {
        return webServiceUrl;
    }

    public void setWebServiceUrl(String webServiceUrl) {
        this.webServiceUrl = webServiceUrl;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

     public PayUGPayCallback getPayUGPayCallback() {
        return payUGPayCallback;
    }

    public void setPayUGPayCallback(PayUGPayCallback payUGPayCallback) {
        this.payUGPayCallback = payUGPayCallback;
    }

    public View getPayUCustomDialogView() {
        return payUCustomDialogView;
    }

    public void setPayUCustomDialogView(View payUCustomDialogView) {
        this.payUCustomDialogView = payUCustomDialogView;
    }

}