package com.payu.gpay.utils;

public interface GPayConstants {
    String PRODUCTION_BASE_URL = "https://info.payu.in";
    String PRODUCTION_PAYMENT_BASE_URL = "https://secure.payu.in";
    String PAYMENT_RELATED_DETAILS_FOR_MOBILE_SDK = "payment_related_details_for_mobile_sdk";
    String MAKE_PAYMENT = "make_payment";
    String GPAY_MAKE_PAYMENT_STARTED = "gpay_make_payment_started";
    String IBIBO_CODES = "ibiboCodes";
    String UPI_ = "upi";
    String TEZAPP = "TEZ";
    String GPAY_PACKAGE_NAME = "com.google.android.apps.nbu.paisa.user";
    String PAYU_PAYTXN = "paytxn";
    //Error Codes
    String GPAY_PAYMENT_NOT_ENABLED = "GPay payment not enabled on this merchant key";
    String PAYU_GPAY_CALLBACK_CANNOT_BE_NULL = "PayUGPayCallback cannot be null";
    String PAYU_GPAY_URL_CANNOT_BE_NULL = "PayU URL cannot be null";
    String CHECK_PAYMENT_OPTION = "check_payment_option";
    int MERCHANT_KEY_NOT_REGISTER_FOR_TEZ_CODE = 1;
    int LOAD_TEZ_PAYMENT_DATA_REQUEST_CODE = 2;
    int PAYMENT_API_ERROR_CODE = 3;
    String GPAY_INPUT_DATA_MISSING = "Please check input data.";
    String MERCHANT_INFO_NOT_PRESENT = "Merchant Info Not present.";
    String PAYMENT_RESPONSE_IS_NULL = "Payment Response is null.";
    int SOCKET_NOT_CONNECTED = 1003;
    //Error Values
    String STATUS = "Status";
    String SUCCESS = "success";
    String FAILURE = "failure";
    String SUBMITTED = "SUBMITTED";
    String GET_RESPONSE_FROM_PSP = "response_from_psp";
    String CANCEL = "cancel";
    String ERROR = "error";
    String MESSAGE = "message";
    String CANCEL_BACK_BUTTON = "cancel_back_button";
    String FAIL = "fail";
    String RESULT = "result";
    String KEY_ = "key";

    String MERCHANT_NAME = "merchantName";
    String INTENT_URI_DATA = "intentURIData";
    String MERCHANT_VPA = "merchantVpa";
    String RETURN_URL = "returnUrl";
    String REFERENCE_ID = "referenceId";
    String AMOUNT = "amount";
    String TRANSACTION_ID = "transactionId";
    String FAILURE_REASON = "failureReason";
    String GPAY_PAYMENT_TYPE = "gpay_paymentType";
    String TXNID = "txnid";
    String TOKEN = "token";
    String MCC = "mcc";
    String CARD_SUPPORTED = "cardSupported";
    String ALLOWED_CARD_NETWORKS = "allowedCardNetworks";
    String PAYMENT_GATEWAY = "PAYMENT_GATEWAY";
    String VPA_REGEX = "vpaRegex";

    String UPI_PUSH_DISABLED = "upiPushDisabled";
    String PUSH_SERVICE_URL = "pushServiceUrl";
    String UPI_SERVICE_POLL_INTERVAL = "upiServicePollInterval";
    String SDK_UPI_PUSH_EXPIRY = "sdkUpiPushExpiry";
    String SDK_UPI_VERIFICATION_INTERVAL = "sdkUpiVerificationInterval";

    String ACTION = "action";
    String INTENT = "INTENT";
    String INAPP = "INAPP";
    String GPAYCARDS = "GPAYCARDS";
    String TYPE = "type";
    String PAYEE_VPA = "payeeVpa";
    String PAYEE_NAME = "payeeName";
    String REFERENCE_URL = "referenceUrl";
    String TRANSACTION_REFERENCE_ID = "transactionReferenceId";
    String PARAMETERS = "parameters";
    String TOKENIZATION_SPECIFICATION = "tokenizationSpecification";
    String TOTAL_PRICE_STATUS = "totalPriceStatus";
    String TOTAL_PRICE = "totalPrice";
    String CURRENT_CODE = "currencyCode";
    String TRANSACTION_NOTE = "transactionNote";
    String ALLOWED_PAYMENT_METHODS = "allowedPaymentMethods";
    String TRANSACTION_INFO = "transactionInfo";
    String API_VERSION = "apiVersion";
    int API_VERSION_VALUE = 2;
    String API_VERSION_MINOR = "apiVersionMinor";
    int API_VERSION_MINOR_VALUE = 0;
    String UPI = "UPI";
    String CARD = "CARD";
    String DIRECT = "DIRECT";
    String FINAL = "FINAL";
    String INR = "INR";
    String NOTE = "Note";
    String POST = "POST";
    String GPAY_PACKAGE = "com.google.android.apps.nbu.paisa.user";
    String COMMAND = "command=";
    String HASH = "&hash=";
    String KEY = "&key=";
    String VAR1 = "&var1=";
    String TXN_S2S_FLOW = "&txn_s2s_flow=";
    String SDK_FLOW_TYPE = "&sdk_flow_type=";
    String TXN_STATUS = "txnStatus";
    String UPDATE_GPAY_STATUS = "updateGpayStatus";
    String GPAY_MESSAGE = "GPayMessage";

    String EVENT_INFO = "info";
    String EVENT_ERROR = "error";


    String PACKAGE_NAME = "package_name";
    String EVENT_KEY = "event_key";
    String VALUE = "event_value";
    String TIMESTAMP = "ts";
    String VERSION_CODE = "application_version";
    String MERCHANT_KEY = "merchant_key";
    String SDK_VERSION_NAME = "gpay_sdk_version";
    String CB_VERSION_NAME = "cb_version_name";
    String EVENT_SEVERITY = "event_severity";
    String EVENT_TYPE = "event_type";
    String SDK_NAME = "sdk_name";
    String PLATFORM = "platform";

    /*Device Analytics*/
    String DEVICE_OS_VERSION = "os_version";
    String NETWORK_INFO = "network_info";
    String NETWORK_STRENGTH = "network_strength";
    String DEVICE_RESOLUTION = "resolution";
    String DEVICE_MANUFACTURE = "device_manufacturer";
    String DEVICE_MODEL = "device_model";
    String UPI_SDK_VERSION_NAME = "upi_sdk_version";
    String GPAY_SDK_VERSION = "gpay_sdk_version";
    String GPAY = "Gpay";
    String GPAY_INAPP = "gpay_inapp";
    String GPAY_INTENT = "gpay_intent";
    String GPAY_COLLECT = "gpay_collect";
    String UPI_SOCKET = "upi_socket";
    String PUSH_ENABLED = "push_enabled";
    String SDK_INTEGRATION = "sdkIntegration";
    String ORIGIN_SDK = "originSDK";
    String DEVICE_DETAILS = "device_details";
    String  IS_TEZ_INSTALLED = "isTezAppInstalled";



    /*URLs*/
    String MERCHANT_POST_SERVICE_FORM = "/merchant/postservice.php?form=2";

    String _PAYMENT = "/_payment";


    /*Analytics*/
    String PAYMENT_OPTION = "gpay_payment_option";
    String UPI_INAPP_SUPPORTED = "upi_inapp_supported";
    String CARD_INAPP_SUPPORTED = "card_inapp_supported";
    String PAYMENT_APP_RESPONSE = "_payment_app_response";
    String TEZ = "tez";
    String NOT_TEZ = "_not_tez";

    String EMBED_FAIL_INTENT_FALLBACK = "embed_fail_intent_fallback";
    String INTENT_FAIL_COLLECT_FALLBACK = "intent_fail_collect_fallback";
    String BROWSER_FALLBACK_URL = "browser_fallback_url";
    // Keys set
    String LONG_POLLING_FROM = "long_polling_from";
    String VERIFY_USING_HTTP = "verify_using_http";
    String VERIFY_TYPE = "verify_type";
    String SOCKET = "socket";
    String TRXN_STATUS = "trxn_status_gpay_sdk";
    String FAILURE_TRANSACTION = "failure_transaction";
    String SUCCESS_TRANSACTION = "success_transaction";

    String GPAY_HANDLER_MAKE_PAYMENT = "gpay_handler_make_payment";
    String GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE = "gpay_handler_onPayuNetworkAsyncTaskResponse";
    String MAKE_PAYMENT_SDK_FLOW_TYPE = "make_payment_sdk_flow_type";
    String GPAY_COLLECT_FALLBACK = "Gpay_collect_fallback";


    int PAYMENT_REQUEST_CODE = 103;

    //GPay Bundle Key
    String CANCELLED = "cancelled";
    String GPAY_EMBEDDED = "embedded";
    String GPAY_INTENT_ = "intent";
    String GPAY_COLLECT_ = "collect";
    String GPAY_CARDS = "gpay_cards";
    String PAYMENT_WAY = "paymentway";
    String POST_DATA = "postdata";
    String _PAYMENT_RESPONSE = "_payment_response";
    String MERCHANT_KEY_ = "merchantKey";
    String IS_CARD_INAPP_FLOW = "isCardInAppFlow";
    String IS_UPI_INAPP_FLOW = "isUpiInAppFlow";
    String UPI_INTENT_DATA = "upi://pay?pa=";
    String UPI_INTENT_PREFIX = "upi://pay?";
    String INTENT_PAYEE_NAME = "&pn=";
    String INTENT_AMOUNT = "&am=";
    String INTENT_TRANSACTION_ID = "&tr=";
    String INTENT_TRANSACTION_NOTE = "&tn=";
    String INTENT_TRANSACTION = "&tid=";
    //Manifest Constants
    String PAYU_WEB_SERVICE_URL="payu_web_service_url";
    String PAYU_POST_URL="payu_post_url";
    String ORDER_ID = " Order Id ";

    /*Cards*/
   String VISA = "VISA";
   String MAST = "MAST";
   String MASTERCARD = "MASTERCARD";
   String CC = "CC";
   String GATEWAY = "gateway";
   String GATEWAY_MERCHANT_ID = "gatewayMerchantId";
   String GATEWAY_TRANSACTION_ID = "gatewayTransactionId";
   String PAYUINDIA = "payuindia";
   String STATUS_ = "status";
   String MSG = "msg";
   String PAYMENT_METHOD_DATA = "paymentMethodData";
   String TOKENIZATION_DATA = "tokenizationData";
   String SIGNED_MESSAGE = "signedMessage";
   String PAYMENT_METHOD_DETAILS = "paymentMethodDetails";
   String GETTING_INCORRECT_RESPONSE_FROM_GOOGLE = "Getting incorrect response from Google.";
   String SOMETHING_WENT_WRONG_WHILE_FETCHING_DATA_FROM_PAYU = "Something went wrong while fetching merchant data from PayU.";



    int SUPPORTED = 1;
    int UNSUPPORTED = 0;
    int NOT_CALLED = -1;
    //Analytics
    String PLATFORM_KEY = "platform";
    String PLATFORM_VALUE = "android";
    String SDK_PLATFORM_KEY ="sdk_platform";
    String NAME_KEY ="name";
    String NAME_VALUE ="gpay";
    String VERSION_KEY ="version";


}
