package com.payu.gpay.callbacks;

import android.app.AlertDialog;

/**
 * Created by minie.sahni on 2/15/18.
 */

public interface PayUGPayCallbackInterface {
    void onPaymentSuccess(String payuResponse, String merchantResponse);

    void onPaymentFailure(String payuResponse, String merchantResponse);

    void onPaymentInitialisationSuccess();

    void onPaymentInitialisationFailure(int errorCode, String description);

    void onGpayErrorReceived(int errorCode, String description);

    void onBackApprove();

    void onBackDismiss();

    void onPaymentTerminate();

    void onBackButton(AlertDialog.Builder alertDialogBuilder);
}
