package com.payu.gpay;

import static com.payu.gpay.utils.GPayConstants.EVENT_ERROR;
import static com.payu.gpay.utils.GPayConstants.EVENT_INFO;
import static com.payu.gpay.utils.GPayConstants.GPAY_HANDLER_MAKE_PAYMENT;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import androidx.annotation.NonNull;
import android.view.View;

import com.google.android.apps.nbu.paisa.inapp.client.api.PaymentsClient;
import com.google.android.apps.nbu.paisa.inapp.client.api.Wallet;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.payu.gpay.callbacks.PayUGPayCallback;
import com.payu.gpay.utils.GPayConstants;
import com.payu.gpay.utils.GPayData;
import com.payu.gpay.utils.GPayUtil;
import com.payu.gpay.utils.L;
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.NoSuchAlgorithmException;

/**
 * Processing input getting from the merchant and decision making to find the payment method.
 *
 */
public class GPayHandler implements PayuNetworkAsyncTaskInterface {
    private Activity reference;
    private String merchantKey;
    private PaymentsClient paymentsClient;
    private boolean isEmbedded;
    private String postData;
    private PayUAnalytics payUAnalytics;
    private int isCardSupportedInAppFlow = GPayConstants.NOT_CALLED, isUpiSupportedInAppFlow = GPayConstants.NOT_CALLED;

    /**
     * @param activity
     * @param callback
     * @param paymentOptionHash
     * @param merchantKey
     * @param user_credentials
     */
    void checkForPaymentAvailability(Activity activity, PayUGPayCallback callback, String paymentOptionHash, String merchantKey, String user_credentials) {
        L.v("GPay checkForPaymentAvailability");
        if (callback == null)
            throw new IllegalStateException(GPayConstants.PAYU_GPAY_CALLBACK_CANNOT_BE_NULL);
        this.reference =activity;
        this.merchantKey = merchantKey;
        if (null != reference && !reference.isDestroyed() && !reference.isDestroyed())
        GPayUtil.setMetaData(reference);

        GPayData.SINGLETON.setPayUGPayCallback(callback);
        PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
        browserAsyncTaskData.setHttpMethod(GPayConstants.POST);

        browserAsyncTaskData.setUrl(GPayData.SINGLETON.getWebServiceUrl());
        browserAsyncTaskData.setPostData(getPaymentAvailabilityPostData(merchantKey, paymentOptionHash, user_credentials));
        new PayUNetworkAsyncTask(this, GPayConstants.CHECK_PAYMENT_OPTION).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);

    }

    /**
     *
     * @param merchantKey
     * @param paymentOptionHash
     * @param user_credentials
     * @return
     */
    private String getPaymentAvailabilityPostData(String merchantKey, String paymentOptionHash, String user_credentials) {
        String postData = GPayConstants.COMMAND + GPayConstants.PAYMENT_RELATED_DETAILS_FOR_MOBILE_SDK +
                GPayConstants.KEY + merchantKey + GPayConstants.HASH + paymentOptionHash + GPayConstants.VAR1 + user_credentials;
        return postData;
    }


    /**
     * Creating payment.
     * Using from {@link GPayWrapper while making payment from Upi SDK or CB / Merchant application while making payment from
     * Standalone Gpay SDK.}
     *
     * @param activity
     * @param postData
     * @param payUGPayCallback
     */
    void makePayment(Activity activity,String postData, final PayUGPayCallback payUGPayCallback, String merchantKey, View loadingDialogView) {
        if (activity != null) {
            this.payUAnalytics = (PayUAnalytics) new AnalyticsFactory(activity.getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
            payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.MAKE_PAYMENT, GPayConstants.GPAY_MAKE_PAYMENT_STARTED, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
        }
        if (payUGPayCallback == null)
            throw new IllegalStateException(GPayConstants.PAYU_GPAY_CALLBACK_CANNOT_BE_NULL);
        this.postData = new GPayUtil().getAnalyticsAddedPostData(postData);
        this.merchantKey = merchantKey;
        GPayData.SINGLETON.setPayUGPayCallback(payUGPayCallback);
        GPayData.SINGLETON.setPayUCustomDialogView(loadingDialogView);
        reference = activity;
        if (null!= reference && !reference.isFinishing())
        GPayUtil.setMetaData(reference);
        /**
         * If tez app is installed, we go with the Intent flow else collect flow.
         * If installed -> Call isReadyToPay method of Gpay SDK to find out the intent flow -> {Pure intent or In-App}
         */
        if (null != reference && !reference.isFinishing() && !reference.isDestroyed()) {

            if (payUAnalytics != null)
                payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.IS_TEZ_INSTALLED, "" + GPayUtil.isTezAppInstalled(reference), merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
            if (GPayUtil.isTezAppInstalled(reference)) {
                try {
                    paymentsClient = Wallet.getPaymentsClient();
                    L.v("Request JSON:Card  " + getPaymentRequestObject(GPayConstants.CARD));
                    L.v("Request JSON:UPI  " + getPaymentRequestObject(GPayConstants.UPI));
                    L.v("reference Object:  " + reference);
                    L.v("Merchant Key:::::: :  " + merchantKey);
                    switch (GPayData.SINGLETON.getPaymentTypeForMerchant()) {
                        case UPI_ONLY:
                            isReadyToPay(GPayConstants.UPI);
                            break;

                        case CARDS_ONLY:
                            isReadyToPay(GPayConstants.CARD);
                            break;

                        case CARDS_UPI_BOTH:
                            isReadyToPay(GPayConstants.UPI);
                            isReadyToPay(GPayConstants.CARD);
                            break;
                    }
                } catch (NoClassDefFoundError e) {
                    runFallback();
                }

            } else {
                if (payUAnalytics != null)
                    payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.IS_TEZ_INSTALLED, "Not installed: initiateCollectGpay" , merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
                // Initiate Collect flow.
                initiateCollectGpay(this.postData);
            }
        }
    }

    /**
     * @param type
     */
    private void isReadyToPay(final String type) {
        try {
            if (null != reference && !reference.isDestroyed() && !reference.isFinishing()) {
                Task<Boolean> result = paymentsClient.isReadyToPay(reference, getPaymentRequestObject(type));
                result.addOnCompleteListener(new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        isEmbedded = task.getResult();
                        //isEmbedded = false;
                        L.v("Is Ready:::> type " + type + "  >> " + isEmbedded);


                        if (type.equals(GPayConstants.UPI)) {
                            if (isEmbedded) {
                                isUpiSupportedInAppFlow = GPayConstants.SUPPORTED;
                            } else {
                                isUpiSupportedInAppFlow = GPayConstants.UNSUPPORTED;
                            }
                            if (payUAnalytics != null)
                                payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.UPI_INAPP_SUPPORTED, "" + isEmbedded , merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
                        } else {
                            if (isEmbedded) {
                                isCardSupportedInAppFlow = GPayConstants.SUPPORTED;

                            } else {
                                isCardSupportedInAppFlow = GPayConstants.UNSUPPORTED;
                            }
                            if (payUAnalytics != null)
                                payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.CARD_INAPP_SUPPORTED, "" + isEmbedded, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
                        }
                        doPaymentServerCall();

                    }
                });
            }
        } catch (NoSuchAlgorithmException e) {
            //Going for Intent as GPay is installed and embed is failed
            runFallback();
         }
    }

    /**
     * First check the onboarding of Gpay Application.
     * if true then payment through Intent Upi
     * else collect flow.
     */
    private void runFallback(){
        if (isUserOnBoardedOnGpayForUpi()) {
            if (null != reference && !reference.isFinishing() && !reference.isDestroyed() && (payUAnalytics != null)) {
                payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.PAYMENT_OPTION, "isUserOnBoardedOnGpayForUpi", merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
            }
            if (null != GPayData.SINGLETON.getPayUGPayCallback()) {
                if (null != reference && !reference.isFinishing() && !reference.isDestroyed() && payUAnalytics != null)
                    payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.MAKE_PAYMENT, GPayConstants.EMBED_FAIL_INTENT_FALLBACK, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
                makePayment(postData, GpayPaymentType.INTENT, GPayData.SINGLETON.getPayUGPayCallback());
            }
        } else {
            if (null != reference && !reference.isFinishing() && !reference.isDestroyed()) {
                if (payUAnalytics != null)
                    payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.PAYMENT_OPTION, GPayConstants.INTENT_FAIL_COLLECT_FALLBACK, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
                initiateCollectGpay(postData);
            }
        }
    }


    /**
     * Make Payment Call while checking Payment Type -> Cards, Upi or both
     */
    private void doPaymentServerCall(){
        switch (GPayData.SINGLETON.getPaymentTypeForMerchant()){
            case CARDS_UPI_BOTH:
                if (isUpiSupportedInAppFlow != GPayConstants.NOT_CALLED && isCardSupportedInAppFlow != GPayConstants.NOT_CALLED) {

                if (isCardSupportedInAppFlow == GPayConstants.SUPPORTED) {
                    if(null!= GPayData.SINGLETON.getPayUGPayCallback()&& null!=postData)
                        makePayment(postData, GpayPaymentType.CARD, GPayData.SINGLETON.getPayUGPayCallback());

                } else if (isUpiSupportedInAppFlow == GPayConstants.SUPPORTED) {
                    if(null!= GPayData.SINGLETON.getPayUGPayCallback()&& null!=postData)
                        makePayment(postData, GpayPaymentType.IN_APP, GPayData.SINGLETON.getPayUGPayCallback());

                } else {
                    runFallback();
                }
            }

                break;

            case CARDS_ONLY:
                if (isCardSupportedInAppFlow != GPayConstants.NOT_CALLED) {

                    if (isCardSupportedInAppFlow == GPayConstants.SUPPORTED) {

                        if (null != GPayData.SINGLETON.getPayUGPayCallback() && null != postData)
                            makePayment(postData, GpayPaymentType.CARD, GPayData.SINGLETON.getPayUGPayCallback());

                    } else {
                        if (null != GPayData.SINGLETON.getPayUGPayCallback()){
                            GPayData.SINGLETON.getPayUGPayCallback().onGpayErrorReceived(GPayConstants.PAYMENT_API_ERROR_CODE,"Gpay can't initiate card payments. Please check cards on Gpay cards.");
                        }
                    }
                }
                break;

            case UPI_ONLY:
                if (isUpiSupportedInAppFlow != GPayConstants.NOT_CALLED) {
                    if (isUpiSupportedInAppFlow == GPayConstants.SUPPORTED) {
                        if (null != GPayData.SINGLETON.getPayUGPayCallback() && null != postData)
                            makePayment(postData, GpayPaymentType.IN_APP, GPayData.SINGLETON.getPayUGPayCallback());

                    } else {
                        runFallback();
                    }
                    break;
                }
        }


}
    /**
     *  Utility method to check if User has on-boarded on GPay app via Activity Resolution for UPI Intent
     * @return
     */
    private boolean isUserOnBoardedOnGpayForUpi(){
        if (null!=reference  && !reference.isFinishing() && !reference.isDestroyed()) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setPackage(GPayConstants.GPAY_PACKAGE_NAME);
                intent.setData(Uri.parse(GPayConstants.UPI_INTENT_DATA));
                return reference.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null;

            }
            return false;
        }


    /**
     * Utility function to make GPay payment
     *
     * @param postData
     * @param gpayPaymentType
     * @param payUGPayCallback
     */
    private void makePayment(String postData, GpayPaymentType gpayPaymentType, PayUGPayCallback payUGPayCallback) {
        L.v("Version Cb " + GPay.cb_version_name);
        L.v("Version UPI Sdk " + GPay.upi_sdk_version);
        GPayData.SINGLETON.setPayUGPayCallback(payUGPayCallback);
        if (GPayData.SINGLETON.getPayUGPayCallback() == null) {
            throw new IllegalStateException(GPayConstants.PAYU_GPAY_CALLBACK_CANNOT_BE_NULL);
        }
        if (GPayData.SINGLETON.getPostUrl() == null) {
            throw new IllegalStateException(GPayConstants.PAYU_GPAY_URL_CANNOT_BE_NULL);
        }
        this.postData = postData;
        postData = postData.concat(GPayConstants.TXN_S2S_FLOW + 2).concat(GPayConstants.SDK_FLOW_TYPE + gpayPaymentType.getPaymentType());
        this.merchantKey = GPayUtil.getDataFromPostData(postData).get(GPayConstants.KEY_);
        if (null != reference) {
            this.payUAnalytics = (PayUAnalytics) new AnalyticsFactory(reference.getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
            String makePaymentType = GPayUtil.getLogMessage(reference, GPayConstants.MAKE_PAYMENT_SDK_FLOW_TYPE, gpayPaymentType.getPaymentType(), merchantKey,  GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO);
            payUAnalytics.log(makePaymentType);
            String message = GPayUtil.getLogMessage(reference, GPAY_HANDLER_MAKE_PAYMENT, postData, merchantKey,  GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO);
            payUAnalytics.log(message);
        }
        PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
        browserAsyncTaskData.setUrl(GPayData.SINGLETON.getPostUrl());
        browserAsyncTaskData.setPostData(postData);
        L.v("URL make payment " + GPayData.SINGLETON.getPostUrl());
        L.v("Request make payment " + postData);
        browserAsyncTaskData.setHttpMethod(GPayConstants.POST);
        if (null!=reference && !reference.isFinishing() && !reference.isDestroyed())
            GPayUtil.showProgressDialog(reference, GPayData.SINGLETON.getPayUCustomDialogView());
        new PayUNetworkAsyncTask(this, GPayConstants.MAKE_PAYMENT).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);
    }


    /**
     * Initializing Collect flow
     *
     * @param postData as received from Merchant
     */
    private void initiateCollectGpay(String postData) {
        if (null!=reference && !reference.isFinishing() && !reference.isDestroyed()) {
            if (payUAnalytics != null)
                payUAnalytics.log(GPayUtil.getLogMessage(reference, GPayConstants.PAYMENT_OPTION, GPayConstants.GPAY_COLLECT_FALLBACK + "_PostData_Is_null_" + (postData != null), merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO));
            Intent intent = new Intent(reference, GPayResponseActivity.class);
            if (postData != null) {
                intent.putExtra(GPayConstants.POST_DATA, postData);
                intent.putExtra(GPayConstants.MERCHANT_KEY_, merchantKey);
                intent.putExtra(GPayConstants.PAYMENT_WAY, GPayConstants.GPAY_COLLECT_);
            }

                reference.startActivity(intent);
        }
    }

    /**
     * Creating request to send Gpay API to check isReadyToPay.
     *
     * @return JSON Encoded PaymentRequest as needed by GPay SDK
     */
    public String getPaymentRequestObject(String paymentType) {
        try {
            if (paymentType != null && (paymentType.equals(GPayConstants.UPI) || paymentType.equals(GPayConstants.CARD))) {
                JSONObject requestObject = new JSONObject();
                requestObject.put(GPayConstants.API_VERSION, GPayConstants.API_VERSION_VALUE);
                requestObject.put(GPayConstants.API_VERSION_MINOR, GPayConstants.API_VERSION_MINOR_VALUE);
                JSONObject upiObject = new JSONObject();
                upiObject.put(GPayConstants.TYPE, paymentType);
                if (paymentType.equals(GPayConstants.CARD)) {
                    JSONObject parameters = new JSONObject();
                    JSONArray cardsArray = new JSONArray();
                    cardsArray.put(GPayConstants.VISA);
                    cardsArray.put(GPayConstants.MASTERCARD);
                    parameters.put(GPayConstants.ALLOWED_CARD_NETWORKS, cardsArray);
                    upiObject.put("parameters", parameters);
                }
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(upiObject);
                requestObject.put(GPayConstants.ALLOWED_PAYMENT_METHODS, jsonArray);
                return requestObject.toString();
            } else {
                L.v("Payment type is not defined...");
            }
        } catch (JSONException e) {

        }
        return null;
    }

    @Override
    public void onPayuNetworkAsyncTaskResponse(String payUAsyncTaskResponse, String webServiceType) {
        switch (webServiceType) {
            case GPayConstants.CHECK_PAYMENT_OPTION:
                boolean result = GPayUtil.isGpayEnabledForMerchant(payUAsyncTaskResponse);
                L.v("Is Result " + result);
                if (result) {
                    if (null!=GPayData.SINGLETON.getPayUGPayCallback())
                    GPayData.SINGLETON.getPayUGPayCallback().onPaymentInitialisationSuccess();
                } else {
                    if (null!=GPayData.SINGLETON.getPayUGPayCallback())
                    GPayData.SINGLETON.getPayUGPayCallback().onPaymentInitialisationFailure(GPayConstants.MERCHANT_KEY_NOT_REGISTER_FOR_TEZ_CODE, GPayConstants.GPAY_PAYMENT_NOT_ENABLED);
                }
                break;

            case GPayConstants.MAKE_PAYMENT:

                if (null != reference  && !reference.isFinishing() && !reference.isDestroyed()) {
                    GPayUtil.hideProgressDialog(reference);
                    this.payUAnalytics = (PayUAnalytics) new AnalyticsFactory(reference.getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
                    try {
                        L.v("Response gpay makepayment " + payUAsyncTaskResponse);
                        JSONObject jsonObject = new JSONObject(payUAsyncTaskResponse);
                        L.v("Post Data: " + postData);

                        Intent intent = new Intent(reference, GPayResponseActivity.class);
                        if (intent != null && jsonObject != null && postData != null) {
                            intent.putExtra(GPayConstants._PAYMENT_RESPONSE, payUAsyncTaskResponse);
                            intent.putExtra(GPayConstants.POST_DATA, postData);
                            intent.putExtra(GPayConstants.MERCHANT_KEY_, merchantKey);
                            intent.putExtra(GPayConstants.IS_CARD_INAPP_FLOW, isCardSupportedInAppFlow);
                            intent.putExtra(GPayConstants.IS_UPI_INAPP_FLOW, isUpiSupportedInAppFlow);
                            if (isCardSupportedInAppFlow == GPayConstants.SUPPORTED || isUpiSupportedInAppFlow == GPayConstants.SUPPORTED) {
                                String message = GPayUtil.getLogMessage(reference, GPayConstants.GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE, GPayConstants.GPAY_EMBEDDED, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO);
                                payUAnalytics.log(message);
                                intent.putExtra(GPayConstants.PAYMENT_WAY, GPayConstants.GPAY_EMBEDDED);

                            } else {
                                String message = GPayUtil.getLogMessage(reference, GPayConstants.GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE, GPayConstants.GPAY_INTENT_, merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_INFO);
                                payUAnalytics.log(message);
                                intent.putExtra(GPayConstants.PAYMENT_WAY, GPayConstants.GPAY_INTENT_);
                            }

                            if (null != reference && !reference.isDestroyed() && !reference.isDestroyed()) {
                                String error = getErrorMessage(payUAsyncTaskResponse);
                                if (null == error) {
                                    L.v("Error >>>>> null. ");
                                    reference.startActivityForResult(intent, 101);
                                } else {
                                    L.v("Error >>>>>  " + error);
                                    String message = GPayUtil.getLogMessage(reference, GPayConstants.GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE, "ErrorMsg_" + getErrorMessage(payUAsyncTaskResponse), merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_ERROR);
                                    payUAnalytics.log(message);
                                    if (GPayData.SINGLETON.getPayUGPayCallback() != null) {
                                        GPayData.SINGLETON.getPayUGPayCallback().onGpayErrorReceived(GPayConstants.PAYMENT_API_ERROR_CODE, error);
                                    }
                                }
                            }
                        } else {

                            String message = GPayUtil.getLogMessage(reference, GPayConstants.GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE, "ErrorMsg_" + getErrorMessage(payUAsyncTaskResponse), merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_ERROR);
                            payUAnalytics.log(message);
                            if (GPayData.SINGLETON.getPayUGPayCallback() != null)
                                GPayData.SINGLETON.getPayUGPayCallback().onGpayErrorReceived(GPayConstants.PAYMENT_API_ERROR_CODE, jsonObject.optString(GPayConstants.MESSAGE));

                        }


                    } catch (JSONException | NullPointerException e) {
                        L.v("Exception " + e.getMessage());
                        String message = GPayUtil.getLogMessage(reference, GPayConstants.GPAY_HANDLER_ON_PAYU_NETWORK_ASYNCTASK_RESPONSE, "JSONException" , merchantKey, GPayUtil.getDataFromPostData(postData).get(GPayConstants.TXNID), EVENT_ERROR);
                        payUAnalytics.log(message);

                        if (null != GPayData.SINGLETON.getPayUGPayCallback())
                            GPayData.SINGLETON.getPayUGPayCallback().onGpayErrorReceived(GPayConstants.LOAD_TEZ_PAYMENT_DATA_REQUEST_CODE, "Please check input data.");

                    }
                }

                break;
        }
    }

    /**
     * Checking whether Error occured or not.
     * @param payUAsyncTaskResponse String response of _payment.
     * @return boolean.
     */
    public String getErrorMessage(String payUAsyncTaskResponse) {
        try {
            JSONObject payuResponseJson=null;
            if (null != payUAsyncTaskResponse) {
                 payuResponseJson = new JSONObject(payUAsyncTaskResponse);
                if ((payuResponseJson.optString(GPayConstants.RESULT).equalsIgnoreCase("") || payuResponseJson.optString(GPayConstants.RESULT).equalsIgnoreCase("null")) && payuResponseJson.has(GPayConstants.ERROR) && payuResponseJson.has(GPayConstants.MESSAGE)) {

                    return payuResponseJson.getString(GPayConstants.MESSAGE);
                }
                else {
                    if (payuResponseJson.getInt(GPayConstants.STATUS_)!=1){
                        return payuResponseJson.getString(GPayConstants.MSG);
                    }

                }
            } else {
                return GPayConstants.PAYMENT_RESPONSE_IS_NULL;

            }
        } catch (JSONException e) {
            return GPayConstants.SOMETHING_WENT_WRONG_WHILE_FETCHING_DATA_FROM_PAYU;
        }
        return null;
    }
}
