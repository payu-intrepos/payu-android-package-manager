package com.payu.gpay.utils;

public enum PaymentTypeForMerchant {

    CARDS_UPI_BOTH,
    UPI_ONLY,
    CARDS_ONLY
}
