package com.payu.gpay.utils;

import static com.payu.gpay.utils.GPayConstants.NAME_VALUE;
import static com.payu.gpay.utils.GPayConstants.PLATFORM_VALUE;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;

import com.payu.gpay.BuildConfig;
import com.payu.gpay.GPay;
import com.payu.gpay.PaymentResponse;
import com.payu.gpay.R;
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUDeviceAnalytics;
import com.payu.socketverification.widgets.PayUProgressDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.net.ssl.HttpsURLConnection;

public class GPayUtil {

    public static PayUProgressDialog progressDialog;

    /**
     * Using Hash map to get all the post data key and value.
     * Later we can use this methods to parase non payu's post data.
     *
     * @param postData Merchant Transction PostData
     * @return
     */

    public static HashMap<String, String> getDataFromPostData(String postData) {
        HashMap<String, String> postParamsMap = new HashMap<>();
        if (null != postData) {
            StringTokenizer tokens = new StringTokenizer(postData, "&");
            L.v("Tokens count "+tokens.countTokens());
            while (tokens.hasMoreTokens()) {
                String[] keyValue = tokens.nextToken().split("=");
                if (null != keyValue && keyValue.length > 0 && null != keyValue[0]) {
                    postParamsMap.put(keyValue[0], keyValue.length > 1 ? keyValue[1] : "");
                }
            }
        }
        return postParamsMap;
    }

    /**
     * Method to get the Base64 Decoded String value
     *
     * @param data - Base64 encoded String
     * @return Base64 decoded String/null in case of Invalid Base64
     */
    public static String getBase64DecodedString(String data)  {
        try {
            return new String(Base64.decode(data, Base64.DEFAULT));
        }catch (IllegalArgumentException e){
            return null;
        }
    }


    /**
     * Return status from Success/Failure based on Api response
     * @param response as received from Api
     * @return Failure{@link com.payu.gpay.utils.GPayConstants#FAILURE}/Success {@link com.payu.gpay.utils.GPayConstants#SUCCESS}
     */
    public static String getTransactionStatus(String response){
        if(response!=null&& !response.isEmpty()) {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.has(GPayConstants.RESULT)) {
                    JSONObject resultObject = jsonObject.getJSONObject(GPayConstants.RESULT);
                    if (resultObject.has(GPayConstants.STATUS.toLowerCase()))
                        return resultObject.getString(GPayConstants.STATUS.toLowerCase());
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return GPayConstants.FAILURE;
            }
        }
        return GPayConstants.FAILURE;
    }

    /**
     *
     * @param activity
     * @param onClickDialog
     * @param positiveText
     * @param negativeText
     * @param title
     * @param message
     * @return {@link AlertDialog.Builder which is used for onBackButton Call of interface }{@link com.payu.gpay.callbacks.PayUGPayCallback}
     */
    public static AlertDialog.Builder getAlertDialog(Activity activity, DialogInterface.OnClickListener onClickDialog, String positiveText, String negativeText, String title, String message) {
        AlertDialog.Builder alertbox = new AlertDialog.Builder(activity, R.style.payu_network_dialog);
        if (onClickDialog != null){
            if (title != null)
                alertbox.setTitle(title);
            if (message != null)
                alertbox.setMessage(message);
            if (positiveText != null)
                alertbox.setPositiveButton(positiveText, onClickDialog);
            if (negativeText != null)
                alertbox.setNegativeButton(negativeText, onClickDialog);
        }
        return alertbox;

    }

    /**
     * Provide JSONObject for analytics
     *
     * @param context        application context
     * @param key            analytics event ket
     * @param value          event value
     * @param sdkMerchantKey merchant key
     * @param trnxID         transaction  ID
     * @return
     */
    public static String getLogMessage(Context context, String key, String value, String sdkMerchantKey, String trnxID, String errorType) {
        try {
            JSONObject eventAnalytics = new JSONObject();
            eventAnalytics.put(GPayConstants.TXNID, trnxID);
            eventAnalytics.put(GPayConstants.MERCHANT_KEY, sdkMerchantKey);
            eventAnalytics.put(GPayConstants.EVENT_KEY, key);
            eventAnalytics.put(GPayConstants.VALUE, URLEncoder.encode(value, "UTF-8"));
            eventAnalytics.put(GPayConstants.PACKAGE_NAME, context.getPackageName());
            eventAnalytics.put(GPayConstants.TIMESTAMP, getSystemCurrentTime());
            eventAnalytics.put(GPayConstants.GPAY_SDK_VERSION, BuildConfig.VERSION_NAME);
            eventAnalytics.put(GPayConstants.VERSION_CODE, getVersionCode(context));
            eventAnalytics.put(GPayConstants.EVENT_SEVERITY,"low");
            eventAnalytics.put(GPayConstants.SDK_NAME,NAME_VALUE);
            eventAnalytics.put(GPayConstants.PLATFORM, PLATFORM_VALUE);

            eventAnalytics.put(GPayConstants.EVENT_TYPE, errorType);
            if(!TextUtils.isEmpty(GPay.cb_version_name))
                eventAnalytics.put(GPayConstants.CB_VERSION_NAME, GPay.cb_version_name);

            if (!TextUtils.isEmpty(GPay.upi_sdk_version))
            eventAnalytics.put(GPayConstants.UPI_SDK_VERSION_NAME, GPay.upi_sdk_version + "");
            eventAnalytics.put(GPayConstants.VERSION_CODE, getVersionCode(context));
            eventAnalytics.put(GPayConstants.SDK_INTEGRATION, getIntegratedSdkPackageName());
            eventAnalytics.put(GPayConstants.ORIGIN_SDK, getOriginSdkPackageName());
            String deviceName = Build.MANUFACTURER.toUpperCase() + "(" + Build.MODEL+")";
            int deviceOsVersion = Build.VERSION.SDK_INT;
            Long deviceTotalMemory = getTotalMemoryInfo(context);
            Long availMemory = getAvailableMemoryInfo(context);
            Long memoryInfo = availMemory * 100 / deviceTotalMemory;

            eventAnalytics.put(GPayConstants.DEVICE_DETAILS, deviceName+"_Android("+deviceOsVersion+")_Memory("+memoryInfo+"% Free)");
            L.v(eventAnalytics.toString());

            return eventAnalytics.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "{}";
        }
    }

    private static Long getTotalMemoryInfo(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return memoryInfo.totalMem / (1024 * 1024);
    }

    private static Long getAvailableMemoryInfo(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return memoryInfo.availMem / (1024 * 1024);
    }

    private static String getOriginSdkPackageName() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        StackTraceElement previousStack = null;
        for (int i = 0; i < stackTraceElements.length; i++) {
            StackTraceElement element = stackTraceElements[i];
            if (element.getClassName().startsWith("com.payu")) {
                previousStack = element;
                break;
            }
        }
        return previousStack != null ? previousStack.getClassName() : null;
    }

    private static String getIntegratedSdkPackageName() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        StackTraceElement previousStack = null;
        for (int i = 0; i < stackTraceElements.length; i++) {
            StackTraceElement element = stackTraceElements[i];
            if (element.getClassName().startsWith("com.payu")) {
                previousStack = element;
            }
        }
        return previousStack != null ? previousStack.getClassName() : null;
    }




    /**
     * Return system current time of system
     *
     * @return system current time in string
     */
    public static String getSystemCurrentTime() {
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String date = df.format(currentDate);
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private static String getVersionCode(Context context)
    {
        try {
            PackageInfo pInfo =context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "";
    }


    private static String getDeviceDensity(Activity activity) {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.densityDpi + "";
    }



    /**
     * Checking whether GPay enabled or not.
     *
     * @param jsonResponse
     * @return
     */
    public static boolean isGpayEnabledForMerchant(String jsonResponse) {
        try {
            L.v("Json response " + jsonResponse);
            JSONObject response = new JSONObject(jsonResponse);
            if (response.has(GPayConstants.IBIBO_CODES)) {
                JSONObject ibiboCodes = response.getJSONObject(GPayConstants.IBIBO_CODES);
                if (ibiboCodes.has(GPayConstants.UPI_)) {
                    JSONObject tezObject = ibiboCodes.getJSONObject(GPayConstants.UPI_);
                    if (tezObject.has(GPayConstants.TEZAPP.toUpperCase())) {
                        return true;
                    }
                }
            }
        } catch (JSONException e) {
            return false;
        }
        return false;
    }
    /**
     * Check whether the customer has Gpay/GPay app installed or not
     *
     * @param context
     * @return
     */
    public static  boolean isTezAppInstalled(Context context) {

        try {
            context.getPackageManager().getPackageInfo(GPayConstants.GPAY_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /**
     * Showing Dialog
     */
    public static void showProgressDialog(Activity activity, View dialogView) {
WeakReference<Activity> activityWeakReference = new WeakReference<>(activity);
       if (null!=activityWeakReference && null!= activityWeakReference.get()&&!activityWeakReference.get().isFinishing() && !activityWeakReference.get().isDestroyed()) {
           if (null == progressDialog)
               progressDialog = new com.payu.socketverification.widgets.PayUProgressDialog(activityWeakReference.get(), dialogView);
           if (null == dialogView)
               progressDialog.setPayUDialogSettings(activityWeakReference.get());
           progressDialog.setCancelable(false);
           try {
               progressDialog.show();
           } catch (IllegalStateException | WindowManager.BadTokenException bte) {
               if (null != bte.getMessage())
                   L.v("Catched Exception " + bte.getMessage());
           }
       }
    }


    /**
     * Hiding the PayU progress dialog
     */
    public static void hideProgressDialog(Activity activity) {
        WeakReference<Activity> weakReference = new WeakReference<>(activity);
        if (null != weakReference && null != weakReference.get() && !weakReference.get().isFinishing() && !weakReference.get().isDestroyed() && null != progressDialog && progressDialog.isShowing())
        try {
            progressDialog.dismiss();
            progressDialog = null;
        } catch (IllegalArgumentException | WindowManager.BadTokenException bte) {
            if (null != bte.getMessage())
                L.v("Catched Exception " + bte.getMessage());
        }
    }


    /**
     * Logging device analytics events.
     *
     * @param sdkMerchantKey, merchant key
     * @param context       activity instance
     * @param txnId  Merchant Transaction Id
     */
//    public static void deviceAnalytics(String sdkMerchantKey, Activity context, String txnId) {
//
//       WeakReference<Activity> activity = new WeakReference<>(context);
//        if(null!=activity.get() && !activity.get().isDestroyed() && !activity.get().isFinishing()) {
//            JSONObject deviceDetails = new JSONObject();
////            PayUDeviceAnalytics payuDeviceAnalytics;
//            try {
//                deviceDetails.put(GPayConstants.TXNID, txnId);
//                deviceDetails.put(GPayConstants.MERCHANT_KEY, sdkMerchantKey);
//                deviceDetails.put(GPayConstants.DEVICE_OS_VERSION, Build.VERSION.SDK_INT + "");
//                deviceDetails.put(GPayConstants.DEVICE_RESOLUTION, GPayUtil.getDeviceDensity(activity.get()));
//                deviceDetails.put(GPayConstants.DEVICE_MANUFACTURE, Build.MANUFACTURER);
//                deviceDetails.put(GPayConstants.DEVICE_MODEL, Build.MODEL);
//                if (!TextUtils.isEmpty(GPay.upi_sdk_version))
//                    deviceDetails.put(GPayConstants.UPI_SDK_VERSION_NAME, GPay.upi_sdk_version);
//                deviceDetails.put(GPayConstants.SDK_VERSION_NAME, BuildConfig.VERSION_NAME);
//                if (!TextUtils.isEmpty(GPay.cb_version_name))
//                    deviceDetails.put(GPayConstants.CB_VERSION_NAME, GPay.cb_version_name);
//                deviceDetails.put(GPayConstants.PACKAGE_NAME, activity.get().getPackageName());
//                payuDeviceAnalytics = (PayUDeviceAnalytics) new AnalyticsFactory(activity.get().getApplicationContext()).getAnalyticsClass(AnalyticsType.PAYU_DEVICE_ANALYTICS);
//                payuDeviceAnalytics.log(deviceDetails.toString());
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }

    /**
     * Setting of data from manifest file.
     *
     * @param activity Activity
     */
    public static void setMetaData(Activity activity) {
        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = activity.getPackageManager().getApplicationInfo(activity.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = applicationInfo.metaData;
            String webServiceUrl = bundle.getString(GPayConstants.PAYU_WEB_SERVICE_URL, GPayConstants.PRODUCTION_BASE_URL);
            webServiceUrl = webServiceUrl + GPayConstants.MERCHANT_POST_SERVICE_FORM;

            String postUrl = bundle.getString(GPayConstants.PAYU_POST_URL, GPayConstants.PRODUCTION_PAYMENT_BASE_URL);
            postUrl = postUrl + GPayConstants._PAYMENT;

            GPayData.SINGLETON.setWebServiceUrl(webServiceUrl);
            GPayData.SINGLETON.setPostUrl(postUrl);
        } catch (PackageManager.NameNotFoundException e) {
            L.v("Exception metadata " + e.getMessage());
            e.printStackTrace();
        }

    }

    public static ArrayList convertCommaSeparatedStringToArrayList(String data) {
        if (data != null && data.length()>0) {
            String[] allowedCardsArr = data.split(",");
            ArrayList list = new ArrayList(Arrays.asList(allowedCardsArr));
            for (int i = 0; i < list.size(); i++) {
                L.v("Value " + list.get(i));
            }
            return list;
        }
        return null;
    }

    /**
     * Checks if Card is supported or not.
     * @param paymentResponse
     * @return true if supported else false
     */
    public static boolean isCardSupported(PaymentResponse paymentResponse) {
        if (paymentResponse!=null) {
            return paymentResponse.getCardSupported();
        }
        return false;
    }

    /**
     * Add/Update sdk_platform data with current sdk version
     * @param postData Merchant's PostData
     * @return Postdata with analytics data updated string
     */
    public String getAnalyticsAddedPostData(String postData){
        JSONArray jsonArray = null;
        String jsonArrayValue="";
        HashMap<String,String> hashMap = getDataFromPostData(postData);
        if(hashMap.containsKey(GPayConstants.SDK_PLATFORM_KEY)) {
            jsonArrayValue = hashMap.get(GPayConstants.SDK_PLATFORM_KEY);
        }
        try {
            if(!TextUtils.isEmpty(jsonArrayValue)){
                jsonArray = new JSONArray(jsonArrayValue);
            }else {
                jsonArray = new JSONArray();
            }
            JSONObject object = new JSONObject();
            object.put(GPayConstants.PLATFORM_KEY, PLATFORM_VALUE);
            object.put(GPayConstants.NAME_KEY, NAME_VALUE);
            object.put(GPayConstants.VERSION_KEY,BuildConfig.VERSION_NAME);
            jsonArray.put(object);
        }catch (JSONException e){
            return convertHashMapToPostData(hashMap);
        }
        hashMap.put(GPayConstants.SDK_PLATFORM_KEY,jsonArray.toString());
        return convertHashMapToPostData(hashMap);
    }

    /**
     * Convert HashMap to url-encoded post-data
     * @param hashMap HashMap of PostData
     * @return Url-Encoded post-data string
     */
    private String convertHashMapToPostData(HashMap<String,String> hashMap){
        StringBuilder stringBuilder = new StringBuilder();
        for (String key:hashMap.keySet()) {
            stringBuilder.append(key);
            stringBuilder.append("=");
            stringBuilder.append(hashMap.get(key));
            stringBuilder.append("&");
        }
        return stringBuilder.toString().substring(0,stringBuilder.lastIndexOf("&"));
    }
    /***
     * Return HttpsURLConnection object
     *
     * @param strURL   postURL
     * @param postData data to be posted
     * @param timeout timeout
     * @param cookiesList list of cookie
     * @return connection object
     */
    public HttpsURLConnection getHttpsConn(String strURL, String postData, int timeout, String cookiesList) {
        try {
            URL url = new URL(strURL);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            if(timeout!=-1) {
                conn.setConnectTimeout(timeout);
            }
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            if(postData!=null) {
                conn.setRequestProperty("Content-Length", String.valueOf(postData.length()));
            }
            if(cookiesList!=null){
                conn.setRequestProperty("Cookie",cookiesList);
            }
            conn.setDoOutput(true);
            if(postData!=null) {
                byte[] postParamsByte = postData.getBytes();
                conn.getOutputStream().write(postParamsByte);
            }
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    /**
     * Return list of cookie of the given domain
     * @param appContext application context
     * @param domainName name of domain
     * @return cookie string
     */
    public String getCookieList(Context appContext,String domainName){
        StringBuilder cookieString = new StringBuilder();

        try {
            CookieManager cookieManager = CookieManager.getInstance();
            String cookies = cookieManager.getCookie(domainName); // return string of all cookie for the given domain
            if (cookies != null) {
                String[] temp = cookies.split(";");
                for (String ar1 : temp) {
                    String[] cookiesNameValue = ar1.split("=");
                    cookieString.append(cookiesNameValue[0]).append("=").append(cookiesNameValue[1]).append(";");
                }
            }
            if(cookieString.length()>0)
                cookieString = new StringBuilder(cookieString.substring(0, cookieString.length() - 1));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cookieString.toString();
    }
}
