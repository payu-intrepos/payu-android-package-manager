package com.payu.gpay.callbacks;

import android.app.AlertDialog;

/**
 * Created by himanshu.gupta on 30/10/17.
 */

public class PayUGPayCallback implements PayUGPayCallbackInterface {

    @Override
    public void onPaymentSuccess(String payuResponse, String merchantResponse) {

    }

    @Override
    public void onPaymentFailure(String payuResponse, String merchantResponse) {

    }

    public void onPaymentInitialisationSuccess() {

    }

    public void onPaymentInitialisationFailure(int errorCode, String description) {

    }

    @Override
    public void onGpayErrorReceived(int errorCode, String description) {

    }

    @Override
    public void onBackApprove() {

    }

    @Override
    public void onBackDismiss() {

    }

    @Override
    public void onPaymentTerminate() {

    }

    @Override
    public void onBackButton(AlertDialog.Builder alertDialogBuilder) {

    }
}
