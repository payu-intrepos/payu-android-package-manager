package com.payu.gpay;

import com.payu.gpay.utils.GPayConstants;

public enum GpayPaymentType {

    IN_APP(GPayConstants.INAPP),
    INTENT(GPayConstants.INTENT),
    CARD(GPayConstants.GPAYCARDS);

    private String paymentType;
    GpayPaymentType(String paymentType){
        this.paymentType = paymentType;
    }

    public String getPaymentType() {
        return paymentType;
    }


}
