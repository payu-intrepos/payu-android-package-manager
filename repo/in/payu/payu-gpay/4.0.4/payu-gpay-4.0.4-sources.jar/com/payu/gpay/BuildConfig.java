/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.gpay;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.gpay";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "4.0.4";
}
