package com.payu.ui.model.models

enum class ListOrder {
    Summary,
    TPVAccounts,
    Offer,
    LoginSection,
    OTMMessage,
    AddMoreSection,
    TopBanks,
    Search,
    ListErrorSection,
    BankListItems,
    OfferListItems,
    SKUOfferListItems,
    UPICollectView
}