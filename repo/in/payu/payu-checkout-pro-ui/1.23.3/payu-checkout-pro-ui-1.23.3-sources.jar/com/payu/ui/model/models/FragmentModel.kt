package com.payu.ui.model.models

import androidx.fragment.app.Fragment
import com.payu.ui.model.listeners.HandleBackPress

class FragmentModel {
    var fragment: Fragment? = null
    var addToBackStack = true
    var tag: String? = null
    var handleBackPress: HandleBackPress? = null
}