package com.payu.ui.model.listeners

import com.payu.base.models.PaymentOption

interface BottomSheetValidateApiListener {
    fun validate(paymentOption: PaymentOption?, bsResultListener: BottomSheetValidateResultListener)
}