package com.payu.ui.model.listeners

import android.view.View

interface BottomSheetVerificationListener {
    fun onClick(v: View?, verificationResultListener: VerificationResultListener)

}