package com.payu.ui.model.listeners

interface ValidateOfferResultListener {
    fun onValidateOfferResponse(isOfferValid: Boolean)
}