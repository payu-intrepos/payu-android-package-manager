package com.payu.ui.model.listeners

import android.webkit.WebView
import com.payu.base.models.ErrorResponse

interface PayUCheckoutProListener {

    fun onPaymentSuccess(response: Any)
    fun onPaymentFailure(response: Any)
    fun onPaymentCancel(isTxnInitiated: Boolean)
    fun onError(errorResponse: ErrorResponse)
    fun generateHash(
        map: HashMap<String, String?>,
        hashGenerationListener: PayUHashGenerationListener
    )

    fun setWebViewProperties(webView: WebView?, bank: Any?)
}