package com.payu.ui.model.utils

import com.payu.base.models.ErrorResponse

object ErrorConstants {
    val TIMEOUT = ErrorResponse("Timeout",5408)

    // olw error constant
    val CP_INVALID_MPIN_LENTH_CODE = "1077"
    val CP_INVALID_MPIN_LENTH_MESSAGE = "Enter correct mpin"
    val CP_DEVICE_VERIFICATION_FAILED_CODE = "5020"
    val CP_MPIN_EXPIRED_CODE = "15022"
    val CP_INVALID_TOKEN = "15025"
    val CP_MPIN_LIMIT_REACHED_CODE = "15027"
    val CP_MPIN_LIMIT_REACHED_MESSAGE= "You have reached maximum number of retries please retry after 30 minute(s)"
    val CP_USER_BLOCKED_CODE = "15028"
    val CP_USER_BLOCKED_MESSAGE = "User has been blocked, please retry after 28 minute(s)"
    val CP_TOKEN_EXPIRED_CODE = "15031"

    val CP_OTP_EXPIRED_CODE= "1018"
    val CP_OTP_EXPIRED_MESSAGE = "OTP is expired please resend OTP"
    val CP_OTP_INVALID_CODE= "1030"
    val CP_OTP_INVALID_MESSAGE = "You have entered the wrong otp, Please enter a valid otp"
    val CP_OTP_LIMIT_REACHED_CODE = "15033"
    val CP_MPIN_OR_OTP_DID_NOT_MATCH = "15023"
    val CP_INVALID_OTP = "15040"
    val CP_INVALID_OTP_LENGTH= "15041"
}