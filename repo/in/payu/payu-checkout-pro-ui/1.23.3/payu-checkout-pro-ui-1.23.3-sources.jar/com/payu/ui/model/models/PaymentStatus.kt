package com.payu.ui.model.models

enum class PaymentStatus {
    SUCCESS,
    FAILED,
    CANCELLED
}