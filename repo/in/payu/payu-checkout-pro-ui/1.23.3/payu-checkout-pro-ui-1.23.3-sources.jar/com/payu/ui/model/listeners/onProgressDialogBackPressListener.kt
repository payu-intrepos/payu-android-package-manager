package com.payu.ui.model.listeners

interface onProgressDialogBackPressListener {
    fun onBackPressListener()
}