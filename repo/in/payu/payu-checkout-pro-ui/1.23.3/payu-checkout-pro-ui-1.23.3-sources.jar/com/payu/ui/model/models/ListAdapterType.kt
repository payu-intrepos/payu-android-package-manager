package com.payu.ui.model.models

enum class ListAdapterType {
    Offer,
    SkuOffer,
    Bank
}