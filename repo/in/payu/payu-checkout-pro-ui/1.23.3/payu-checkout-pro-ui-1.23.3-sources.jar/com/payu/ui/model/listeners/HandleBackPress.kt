package com.payu.ui.model.listeners

interface HandleBackPress {
    fun onBackPressed()

}