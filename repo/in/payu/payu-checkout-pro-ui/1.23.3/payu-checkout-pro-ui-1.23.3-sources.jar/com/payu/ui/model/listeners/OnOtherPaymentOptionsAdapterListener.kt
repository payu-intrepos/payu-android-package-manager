package com.payu.ui.model.listeners

import com.payu.base.models.PaymentMode
import com.payu.base.models.PaymentOption

interface OnOtherPaymentOptionsAdapterListener {
    fun setSelectedPaymentMode(paymentMode: PaymentMode)
    fun otherOptionSelected(paymentMode: PaymentMode)
    fun updateSelectedPaymentOption(paymentOption: PaymentOption)
    fun validateOffer()
    fun showOfferNotAvailableSnackBar()
    fun updateHeaderAmount(paymentOption: PaymentOption, resetAmount: Boolean = false)
}