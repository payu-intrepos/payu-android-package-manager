package com.payu.ui.model.utils

object AnalyticsConstant {

    const val GLOBAL_VAULT = "GlobalVault"
    const val CP_NULL = "null"
    const val CP_ORDER_NO = "Order No"
    const val CP_GV_PROCEED_TO_PAY_CLICKED = "Global Vault Proceed clicked"
    const val CP_GV_CREDENTIAL_EXCEPTION = "Global Vault Credentials Read & Write Exception"
    const val CP_GV_OTP_AUTH_INITIATED = "OTP authentication Initiated"
    const val CP_OTP_SUBMISSION_STATUS = "OTP Authentication Final Status"
    const val CP_GV_STATUS = "Status"
    const val CP_COMPLETED = "Completed"
    const val CP_FAILED = "Failed"
    const val CP_OTP_RESEND = "OTP authentication Resend Clicked"
    const val CP_SKIP_CLICKED = "OTP authentication Skip"
    const val CP_TILES_SHOWN_COUNT = "Tiles Shown Count"
    const val CP_LOGGED_IN = "Logged In"
    const val CP_UNLOCKED_OPTION_SHOWN = "Unlock Saved Option Shown"
    const val CP_SAVED_OPTION_COUNT = "Saved Option Count"
    const val CP_TILES_VIEW_CLICKED = "Tiles View Clicked"
    const val CP_UNLOCK_SAVED_OPTION = "Unlock Saved Options"
    const val CP_TILES_PROCEED_CLICKED = "Tiles Proceed Clicked"
    const val CP_LOGOUT_CLICKED = "GV Logout Clicked"
    const val CP_GV_DATA_SHOWN = "GV Data Shown"
    const val CP_EVENTS_INDEX = "event_Index"
    const val CP_DEVICE_DETAILS = "device_details"
    const val CP_LOGGING_SDK = "logging_sdk"
    const val CP_YES = "Yes"
    const val CP_NO = "No"

    const val EVENT_VALUE = "event_value"
    const val EVENT_TYPE = "event_type"
    const val EVENT_TIME = "event_time"
    const val EVENT_SEVERITY = "event_severity"
    const val CP_APPLICATION_PACKAGE = "application_package"
    const val CP_APPLICATION_VERSION = "application_version"
    const val EVENT_STATUS = "status"
    const val EVENT_CP_HASH = "CP_HASH"
    const val EVENT_CP_HASH_GENERATED = "CP_HASH_GENERATED"
    const val EVENT_CP_INITIALISED = "CheckoutPro_Initialised"
    const val EVENT_CP_CONFIG = "payUCheckoutProConfig"
    const val EVENT_PAYMENT_PARAM = "payUPaymentParams"
    const val KEY_HASH_STRING = "hashString"
    const val KEY_GENERATED_HASH = "generatedHash"
    const val CP_API = "CP_API:"
    const val API_RESPONSE_CODE = "code"
    const val API_REQUEST = "request"
}

enum class EventType{
    Info,
    Error
}

enum class EventStatus {
    Success,
    Failure
}

enum class EventSeverity {
    High,
    Low
}