package com.payu.ui.model.utils

object GlobalVaultResponseCodes {

    // send otp/ resend otp is success
    const val GV_SEND_OTP_SUCCESS = 10

    // OTP verification is success
    const val GV_VERIFY_OTP_SUCCESS = 11

    // incorrect OTP
    const val GV_VERIFY_OTP_INCORRECT = 106

    //Verfiy OTP Attempts Exhausted
    const val GV_VERIFY_OTP_ATTEMPT_EXCEED = 107

    //Resend Count exceeded
    const val GV_RESEND_OTP_ATTEMPT_EXCEED = 103

    //UUID is expired. Verify cannot be performed
    const val GV_UUID_EXPIRED_VERIFICATION = 112

    //UUID is expired. Resend cannot be performed
    const val GV_UUID_EXPIRED_RESEND = 108
}