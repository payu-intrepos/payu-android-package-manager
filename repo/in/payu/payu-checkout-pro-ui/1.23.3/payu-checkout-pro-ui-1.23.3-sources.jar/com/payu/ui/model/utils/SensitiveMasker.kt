package com.payu.ui.model.utils

object SensitiveMasker {

    // ----------- Key Groups -----------

    private val MASKED_KEYS = setOf(
        "cardnumber", "card_number", "cardno", "card_no",
        "ccnum", "ccnumber", "cc_number", "cc_num",
        "ccexpyr", "cc_expyr", "cc_exp_yr", "expyr", "exp_yr",
        "expiry_year", "expiryear", "expiryyear", "expiryyr",
        "exp_year", "expyear", "cardexpyr", "card_expyr",
        "ccexpmon", "cc_expmon", "cc_exp_mon", "expmon", "exp_mon",
        "expiry_month", "expirymonth", "expmonth",
        "exp_month", "cardexpmon", "card_expmon",
        "ccvv", "cardcvv", "card_cvv",
        "ccname",
        "phoneno", "phone", "mobile", "mobileno",
        "email"
    )

    private val GENERIC_REGEX =
        Regex("\"([^\"]+)\"\\s*:\\s*\"([^\"]*)\"", RegexOption.IGNORE_CASE)

    fun maskSensitiveData(input: String): String {
        return GENERIC_REGEX.replace(input) { match ->

            val originalKey = match.groupValues.getOrNull(1) ?: return@replace match.value
            val value = match.groupValues.getOrNull(2) ?: return@replace match.value

            val normalizedKey = originalKey.lowercase()

            val maskedValue =
                if (normalizedKey in MASKED_KEYS && value.isNotEmpty()) {
                    maskValue(value)
                } else {
                    value
                }

            "\"$originalKey\":\"$maskedValue\""
        }
    }

    private fun maskValue(value: String): String {

        if (value.length < 5) {
            // Fully mask if less than 5
            return "*".repeat(value.length)
        }

        // Mask 90% for length >= 5
        val maskLength = (value.length * 0.9).toInt()
        val visibleLength = value.length - maskLength

        val maskedPart = "*".repeat(maskLength)
        val visiblePart = value.takeLast(visibleLength)

        return maskedPart + visiblePart
    }
}