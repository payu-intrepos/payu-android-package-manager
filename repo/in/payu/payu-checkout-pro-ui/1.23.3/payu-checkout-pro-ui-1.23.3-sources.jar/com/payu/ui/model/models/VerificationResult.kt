package com.payu.ui.model.models

data class VerificationResult(
    var status: Boolean,
    var errorMessage: String,
    var result: String
)
