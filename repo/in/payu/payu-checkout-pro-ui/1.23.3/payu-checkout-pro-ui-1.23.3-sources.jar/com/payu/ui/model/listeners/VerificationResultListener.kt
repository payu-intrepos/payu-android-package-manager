package com.payu.ui.model.listeners

import com.payu.ui.model.models.VerificationResult

interface VerificationResultListener {
    fun onResult(result: VerificationResult)
}