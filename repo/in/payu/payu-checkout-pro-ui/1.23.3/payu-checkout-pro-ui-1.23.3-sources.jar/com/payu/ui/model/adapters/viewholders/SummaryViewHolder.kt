package com.payu.ui.model.adapters.viewholders

import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.payu.ui.R
import com.payu.ui.model.models.AdapterViewSections

class SummaryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private var tvSISummary: TextView? = view.findViewById(R.id.tv_si_summary_title)
        private var tv_si_summary_title_layout: ConstraintLayout? =
            view.findViewById(R.id.tv_si_summary_title_layout)

        fun bind(item: AdapterViewSections.Summary) {
            tv_si_summary_title_layout?.visibility = View.VISIBLE
            tvSISummary?.text = item.title
        }
    }