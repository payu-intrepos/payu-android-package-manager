package com.payu.ui.model.listeners

interface OnNetBankingAdapterListener {

    fun showSkuBottomSheet(show: Boolean)

    fun removeOffers()

    fun addNewCard()

    fun showLoginSettings()

}