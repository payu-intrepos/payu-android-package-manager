package com.payu.ui.model.models

data class ToolTipModel(var title: String, var description: String, var imageId: Int?)