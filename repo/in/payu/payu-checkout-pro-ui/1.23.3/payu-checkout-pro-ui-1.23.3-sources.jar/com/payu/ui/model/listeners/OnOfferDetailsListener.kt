package com.payu.ui.model.listeners

interface OnOfferDetailsListener {
    fun updateSelectedOfferForUserSelected()
    fun showChangeOfferView(
        shouldShowChangeOffer: Boolean, isAutoApply: Boolean
    )
    fun updateOffer()
    fun hideBottomSheet()
}