package com.payu.ui.model.listeners

interface EnachCallback {
    fun onCompleted()
}