package com.payu.ui.model.models

data class TilesData(val title: String?, val subText: String?, val imageUrl: String?)
