package com.payu.ui.model.listeners

interface PayUHashGenerationListener {
    fun onHashGenerated(map: HashMap<String, String?>)
}