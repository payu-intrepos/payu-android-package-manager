package com.payu.ui.model.listeners

interface OfferApplyListener {
    fun removeOffer(isAutoApply: Boolean)
}