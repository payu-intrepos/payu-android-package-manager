package com.payu.ui.model.listeners

interface BottomSheetValidateResultListener {
    fun onValidateResultListener(isOfferValid: Boolean)
}