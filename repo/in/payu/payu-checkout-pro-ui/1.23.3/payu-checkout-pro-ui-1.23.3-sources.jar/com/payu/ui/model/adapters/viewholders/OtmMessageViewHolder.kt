package com.payu.ui.model.adapters.viewholders

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.payu.ui.R
import com.payu.ui.model.models.AdapterViewSections

class OtmMessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    private var tvOtmTitle: TextView? = view.findViewById(R.id.tv_otm_title)
    private var tvOtmSubtitle: TextView? = view.findViewById(R.id.tv_otm_subtitle)

    fun bind(item: AdapterViewSections.OTMMessageView) {
        tvOtmTitle?.text = item.title
        tvOtmSubtitle?.text = item.subTitle
    }
}