package com.payu.ui.model.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.payu.ui.R
import com.payu.ui.model.adapters.viewholders.TpvAccountInfoViewHolder
import com.payu.ui.model.models.TilesData

class HorizontalTilesAdapter(private val tilesDataList: ArrayList<TilesData>): RecyclerView.Adapter<TpvAccountInfoViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TpvAccountInfoViewHolder {
        val inflater = LayoutInflater.from(parent.context)
         val view = inflater.inflate(R.layout.payu_tpv_account_info, parent, false)
        return TpvAccountInfoViewHolder(view)
    }

    override fun getItemCount(): Int {
        return tilesDataList.size
    }

    override fun onBindViewHolder(holder: TpvAccountInfoViewHolder, position: Int) {
       holder.bind(tilesDataList[position])
    }

}