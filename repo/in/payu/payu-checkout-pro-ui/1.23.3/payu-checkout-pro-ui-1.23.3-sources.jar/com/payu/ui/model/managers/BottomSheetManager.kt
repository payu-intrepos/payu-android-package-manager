package com.payu.ui.model.managers

import android.view.View
import com.payu.ui.model.widgets.RoundedCornerBottomSheet

abstract class BottomSheetManager: RoundedCornerBottomSheet.OnBottomSheetListener {
    lateinit var view: View
    lateinit var roundedCornerBottomSheet: RoundedCornerBottomSheet
    override fun getInflatedView(view: View, roundedCornerBottomSheet: RoundedCornerBottomSheet) {
        this.view = view
        this.roundedCornerBottomSheet = roundedCornerBottomSheet
        init()
    }
    abstract fun init()

    abstract override fun handleBottomSheetClose()
}