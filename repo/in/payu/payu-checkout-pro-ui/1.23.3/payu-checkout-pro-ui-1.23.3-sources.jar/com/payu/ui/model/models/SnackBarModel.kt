package com.payu.ui.model.models

class SnackBarModel(var message: String? = "", var icon: Int? = null)