package com.payu.ui.model.utils

object AnalyticsConstant {

    const val GLOBAL_VAULT = "GlobalVault"
    const val CP_NULL = "null"
    const val CP_ORDER_NO = "Order No"
    const val CP_GV_PROCEED_TO_PAY_CLICKED = "Global Vault Proceed clicked"
    const val CP_GV_CREDENTIAL_EXCEPTION = "Global Vault Credentials Read & Write Exception"
    const val CP_GV_OTP_AUTH_INITIATED = "OTP authentication Initiated"
    const val CP_OTP_SUBMISSION_STATUS = "OTP Authentication Final Status"
    const val CP_GV_STATUS = "Status"
    const val CP_COMPLETED = "Completed"
    const val CP_FAILED = "Failed"
    const val CP_OTP_RESEND = "OTP authentication Resend Clicked"
    const val CP_SKIP_CLICKED = "OTP authentication Skip"
    const val CP_TILES_SHOWN_COUNT = "Tiles Shown Count"
    const val CP_LOGGED_IN = "Logged In"
    const val CP_UNLOCKED_OPTION_SHOWN = "Unlock Saved Option Shown"
    const val CP_SAVED_OPTION_COUNT = "Saved Option Count"
    const val CP_TILES_VIEW_CLICKED = "Tiles View Clicked"
    const val CP_UNLOCK_SAVED_OPTION = "Unlock Saved Options"
    const val CP_TILES_PROCEED_CLICKED = "Tiles Proceed Clicked"
    const val CP_LOGOUT_CLICKED = "GV Logout Clicked"
    const val CP_GV_DATA_SHOWN = "GV Data Shown"
    const val CP_EVENTS_INDEX = "event_Index"
    const val CP_DEVICE_DETAILS = "device_details"
    const val CP_LOGGING_SDK = "logging_sdk"
    const val CP_YES = "Yes"
    const val CP_NO = "No"

    const val EVENT_VALUE = "event_value"
    const val EVENT_TYPE = "event_type"
    const val EVENT_TIME = "event_time"
    const val EVENT_SEVERITY = "event_severity"
    const val CP_APPLICATION_PACKAGE = "application_package"
    const val CP_APPLICATION_VERSION = "application_version"
    const val EVENT_STATUS = "status"
    const val EVENT_CP_HASH = "CP_HASH"
    const val EVENT_CP_HASH_GENERATED = "CP_HASH_GENERATED"
    const val EVENT_CP_INITIALISED = "CheckoutPro_Initialised"
    const val EVENT_CP_CONFIG = "payUCheckoutProConfig"
    const val EVENT_PAYMENT_PARAM = "payUPaymentParams"
    const val KEY_HASH_STRING = "hashString"
    const val KEY_GENERATED_HASH = "generatedHash"
    const val CP_API = "CP_API:"
    const val API_RESPONSE_CODE = "code"
    const val API_REQUEST = "request"

    const val CP_UPI_APPS_FETCH_INITIATED = "UPI Apps Fetch Initiated"
    const val CP_UPI_APPS_FETCHED = "UPI Apps Fetched"
    const val CP_UPI_APPS_LIST = "UPI Apps Available"
    const val CP_UPI_APP_LOAD_FAILED = "UPI App Load Failed"

    const val CP_UPI_MODE_ENTRY = "UPI Mode Entry"
    const val CP_UPI_SI_AMOUNT_TOO_LOW = "UPI SI Amount Below Minimum"
    const val CP_UPI_COLLECT_ADDED = "UPI Collect Option Added"
    const val CP_UPI_TEZOMNI_ADDED = "UPI TezOmni Option Added"
    const val CP_UPI_SI_INTENT_APPS_FILTERED = "UPI SI Intent Apps Filtered"
    const val CP_UPI_INTENT_APPS_FINAL = "UPI Intent Apps Final List"
    const val CP_UPI_MERCHANT_APP_ENRICHED = "UPI Merchant App Name Enriched"
    const val CP_UPI_MODE_DOWN = "UPI Mode Marked Down"

    const val CP_ADAPTER_ITEM_SELECTED = "itemSelected"
    const val CP_ADAPTER_ITEM_UNSELECTED = "itemUnSelected"
    const val CP_ADAPTER_EMI_SELECTED = "emiSelected"
    const val CP_ADAPTER_ADD_NEW_CARD = "addNewCard"
    const val CP_ADAPTER_VALIDATE_OFFER = "validateOffer"
    const val CP_ADAPTER_REMOVE_OFFER = "removeOffer"
    const val CP_ADAPTER_REMOVE_OFFERS = "removeOffers"
    const val CP_ADAPTER_SKU_BOTTOM_SHEET = "showSkuBottomSheet"
    const val CP_ADAPTER_SHOW_LOGIN = "showLoginSettings"

    const val CP_LIFECYCLE_ON_ATTACH = "onAttach"
    const val CP_LIFECYCLE_ON_CREATE = "onCreate"
    const val CP_LIFECYCLE_ON_CREATE_VIEW = "onCreateView"
    const val CP_LIFECYCLE_ON_VIEW_CREATED = "onViewCreated"
    const val CP_LIFECYCLE_ON_START = "onStart"
    const val CP_LIFECYCLE_ON_RESTART = "onRestart"
    const val CP_LIFECYCLE_ON_RESUME = "onResume"
    const val CP_LIFECYCLE_ON_PAUSE = "onPause"
    const val CP_LIFECYCLE_ON_STOP = "onStop"
    const val CP_LIFECYCLE_ON_DESTROY_VIEW = "onDestroyView"
    const val CP_LIFECYCLE_ON_DESTROY = "onDestroy"
    const val CP_LIFECYCLE_ON_DETACH = "onDetach"
    const val CP_LIFECYCLE_ON_SAVE_INSTANCE = "onSaveInstanceState"
    const val CP_LIFECYCLE_ON_RESTORE_INSTANCE = "onRestoreInstanceState"
    const val CP_LIFECYCLE_ON_NEW_INTENT = "onNewIntent"
    const val CP_LIFECYCLE_ON_ACTIVITY_RESULT = "onActivityResult"
    const val CP_LIFECYCLE_ON_PERMISSIONS_RESULT = "onRequestPermissionsResult"
    const val CP_LIFECYCLE_ON_WINDOW_FOCUS = "onWindowFocusChanged"
}

enum class EventType{
    Info,
    Error
}

enum class EventStatus {
    Success,
    Failure
}

enum class EventSeverity {
    High,
    Low
}