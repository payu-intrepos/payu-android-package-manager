package com.payu.base.listeners

interface OnFetchGaidListener {
    fun onFetchGaidResponse(gaid: String)
}