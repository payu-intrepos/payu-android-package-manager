package com.payu.base.models;

public enum EmiType {
    CC,
    DC,
    CARD_LESS
}
