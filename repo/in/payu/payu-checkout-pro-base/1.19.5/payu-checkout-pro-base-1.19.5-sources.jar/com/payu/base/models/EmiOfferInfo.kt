package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.ArrayList

@Parcelize
data class EmiOfferInfo(
    val emiCCOfferList: ArrayList<PaymentOptionOfferinfo>?,
    val emiDCOfferList: ArrayList<PaymentOptionOfferinfo>?,
    val emiCardLessOfferList: ArrayList<PaymentOptionOfferinfo>?
) : Parcelable
