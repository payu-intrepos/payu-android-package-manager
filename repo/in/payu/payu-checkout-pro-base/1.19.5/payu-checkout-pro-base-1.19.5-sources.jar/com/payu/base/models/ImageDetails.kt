package com.payu.base.models

data class ImageDetails(val type: DrawableType, val image: Any)
