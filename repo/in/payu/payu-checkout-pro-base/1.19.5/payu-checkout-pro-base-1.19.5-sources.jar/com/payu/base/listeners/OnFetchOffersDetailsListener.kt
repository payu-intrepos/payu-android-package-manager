package com.payu.base.listeners

import com.payu.base.models.FetchOfferDetails

interface OnFetchOffersDetailsListener {
    fun onFetchOffersDetailsResponse(fetchOfferDetails: FetchOfferDetails?)
}