package com.payu.base.models

enum class CardType {
    CC {
        override fun getTypeName(): String = "Credit Card"
    },
    DC {
        override fun getTypeName(): String = "Debit Card"
    };

    abstract fun getTypeName(): String
}