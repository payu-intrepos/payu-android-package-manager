package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ConvenienceFeeCharges(
    val chargeUuid: String,
    val chargeName: String,
    val baseFee: Double,
    val taxAmount: Double,
    val ruleId: String
) : Parcelable
