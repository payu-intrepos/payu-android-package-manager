package com.payu.base.models

enum class PaymentType {
    CARD,
    NB,
    UPI,
    UPI_INTENT,
    WALLET,
    EMI,
    NEFTRTGS,
    L1_OPTION,
    SODEXO,
    BNPL,
    CLOSED_LOOP_WALLET,
    OPEN_LOOP_WALLET
}