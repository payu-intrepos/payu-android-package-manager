package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SKU(
    val quantity: Int,
    val skuAmount: String,
    val skuId: String,
    val skuName: String,
    var offerKeys: ArrayList<String>? = null,
    var autoApplyOffer: Boolean = true
) : Parcelable