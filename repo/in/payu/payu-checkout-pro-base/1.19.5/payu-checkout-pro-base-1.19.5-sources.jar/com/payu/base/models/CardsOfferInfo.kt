package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class CardsOfferInfo(val bankOfferInfoCards: BankOfferInfoCards?, val networkOfferInfoCards: NetworkOfferInfoCards?) :
    Parcelable
