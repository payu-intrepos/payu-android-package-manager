package com.payu.base.listeners

import com.payu.base.models.ErrorResponse
import com.payu.base.models.GlobalVaultAPIsCommand

/**
 * Listener to Return the Result from PayU SDK to CheckoutPro-UI.
 */
interface OnGVQuickPayListener {
    fun onSuccess(responseMap: Any)
    fun onError(errorResponse: ErrorResponse)
}