package com.payu.base.models

import java.util.ArrayList

data class L1PaymentModes(
    val quickOptionsList: ArrayList<PaymentMode>?,
    val moreOptionsList: ArrayList<PaymentMode>?
)
