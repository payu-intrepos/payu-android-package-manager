package com.payu.base.listeners

interface OnConfigFetchedListener : BaseApiListener {
    fun onConfigReceived()
}