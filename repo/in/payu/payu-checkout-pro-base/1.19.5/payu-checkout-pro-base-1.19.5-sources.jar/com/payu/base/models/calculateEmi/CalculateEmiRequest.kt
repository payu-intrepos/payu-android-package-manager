package com.payu.base.models.calculateEmi

data class CalculateEmiRequest(
    var additionalCharges: Int? = 0,
    var autoApplyOffer: Boolean = true,
    var bankCodes: List<String?>? = null,
    var emiCodes: List<String>,
    var offerKeys: List<String?>? = null,
    var isSkuOffer: Boolean = false,
    var txnAmount: Double,
    var cardBin: String? = null,
    var includeOfferRequest: Boolean = true,
    var isPricingEnabled: Boolean = false,
)