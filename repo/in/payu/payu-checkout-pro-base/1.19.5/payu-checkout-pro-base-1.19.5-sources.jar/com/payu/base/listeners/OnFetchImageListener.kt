package com.payu.base.listeners

import com.payu.base.models.ImageDetails

interface OnFetchImageListener {
    fun onImageGenerated(result: ImageDetails)
}