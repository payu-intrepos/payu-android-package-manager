package com.payu.base.models

data class SendOtpResponse(val bankId: Long, val olwAPIResponse: OlwAPIResponse)
