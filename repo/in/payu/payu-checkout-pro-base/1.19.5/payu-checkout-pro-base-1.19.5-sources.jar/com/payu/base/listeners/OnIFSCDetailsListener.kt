package com.payu.base.listeners

import com.payu.base.models.IFSCDetails

interface OnIFSCDetailsListener : BaseApiListener {
    fun onIFSCDetailsReceived(ifscDetails: IFSCDetails)
}