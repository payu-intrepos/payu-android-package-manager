package com.payu.base.models

data class VariableDynamics(val combinationKey: String, val ibiboCode: String)
