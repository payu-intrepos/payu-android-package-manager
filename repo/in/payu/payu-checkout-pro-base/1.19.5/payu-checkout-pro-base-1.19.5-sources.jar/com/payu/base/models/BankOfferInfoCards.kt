package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.ArrayList

@Parcelize
data class BankOfferInfoCards( val banksListForCCCards: ArrayList<PaymentOptionOfferinfo>?, val banksListForDCCards: ArrayList<PaymentOptionOfferinfo>?) :
    Parcelable