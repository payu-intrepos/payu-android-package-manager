package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class FeeCombinations(
    val combinationUUID: String,
    val requestUuid: String,
    val convenienceFeeCharges: ArrayList<ConvenienceFeeCharges>
) : Parcelable