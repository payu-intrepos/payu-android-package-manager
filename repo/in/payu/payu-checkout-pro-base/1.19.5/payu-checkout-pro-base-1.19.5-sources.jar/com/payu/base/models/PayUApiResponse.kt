package com.payu.base.models

data class  PayUApiResponse<O>(val listener:(O?) -> Unit?, var inProgress: Boolean, var response: O? )
