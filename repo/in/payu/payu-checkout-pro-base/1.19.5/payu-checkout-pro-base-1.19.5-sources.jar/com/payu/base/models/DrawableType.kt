package com.payu.base.models

enum class DrawableType {
    Bitmap,
    PictureDrawable
}