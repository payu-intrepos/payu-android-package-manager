package com.payu.base.models

object BaseApiLayerConstants {
    const val SDK_TAG = "UiSdk"
}