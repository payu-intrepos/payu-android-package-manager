package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.ArrayList

@Parcelize
data class EMiOptionInOffers(
    val bankCode: String,
    val emiType: String,
    val paymentOptionOfferinfoArrayList: ArrayList<PaymentOptionOfferinfo>
) : Parcelable