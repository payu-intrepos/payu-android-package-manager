package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.ArrayList

@Parcelize
data class NetworkOfferInfoCards(
    val networkListForCCCards: ArrayList<PaymentOptionOfferinfo>?,
    val networkListForDCCards: ArrayList<PaymentOptionOfferinfo>?
) : Parcelable
