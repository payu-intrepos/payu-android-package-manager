package com.payu.base.models

open class SavedCardOption : CardOption() {
    var cardToken: String = ""
    var networkToken: String = ""

    // below params used for global vault saved card
    var userCredential: String = ""
    var isTokenTxn: Boolean = false
}