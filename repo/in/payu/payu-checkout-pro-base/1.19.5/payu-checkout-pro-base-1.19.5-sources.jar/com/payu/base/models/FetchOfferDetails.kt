package com.payu.base.models

data class FetchOfferDetails(
    val payuOfferArrayList: ArrayList<OfferInfo>,
    val payuSkuOfferList: ArrayList<OfferInfo>,
    val payuRewardOfferArrayList: ArrayList<OfferInfo>
)
