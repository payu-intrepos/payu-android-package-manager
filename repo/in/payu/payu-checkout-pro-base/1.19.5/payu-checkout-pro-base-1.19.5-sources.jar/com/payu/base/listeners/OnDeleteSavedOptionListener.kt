package com.payu.base.listeners

interface OnDeleteSavedOptionListener : BaseApiListener {
    fun onDeletedSuccessfully()
}