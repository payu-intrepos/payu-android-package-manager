// YApi QuickType插件生成，具体参考文档:https://plugins.jetbrains.com/plugin/18847-yapi-quicktype/documentation

package com.payu.base.models

data class OlwErrorResponse (
    val errorType: String,
    val errorMessage: String,
    val issueCode: String
)
