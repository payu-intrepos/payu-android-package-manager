package com.payu.base.models

class ErrorResponse() {
    var errorMessage: String? = null
    var errorCode: Int? = null
    constructor(errorMessage: String,errorCode:Int):this(){
        this.errorMessage =errorMessage
        this.errorCode = errorCode
    }
}