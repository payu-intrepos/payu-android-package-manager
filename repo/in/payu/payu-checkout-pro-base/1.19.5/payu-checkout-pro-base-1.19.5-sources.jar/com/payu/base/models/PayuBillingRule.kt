package com.payu.base.models

enum class PayuBillingRule {
    MAX,
    EXACT
}