package com.payu.base.listeners

import com.payu.base.models.PaymentMode

interface OnCheckOfferDetailsListener : BaseApiListener {
    fun onOfferDetailsReceived(paymentMode: PaymentMode)
}