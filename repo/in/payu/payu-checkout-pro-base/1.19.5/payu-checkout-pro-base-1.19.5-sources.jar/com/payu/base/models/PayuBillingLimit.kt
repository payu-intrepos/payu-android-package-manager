package com.payu.base.models

enum class PayuBillingLimit {
    ON,
    BEFORE,
    AFTER
}