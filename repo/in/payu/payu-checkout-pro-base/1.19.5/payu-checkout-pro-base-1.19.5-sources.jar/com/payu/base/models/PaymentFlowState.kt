package com.payu.base.models

import android.os.Parcel
import android.os.Parcelable

class PaymentFlowState() : Parcelable {
    var paymentState: PaymentState? = null

    constructor(parcel: Parcel) : this() {
        paymentState = parcel.readSerializable() as PaymentState?
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeSerializable(paymentState)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<PaymentFlowState> {
        override fun createFromParcel(parcel: Parcel): PaymentFlowState {
            return PaymentFlowState(parcel)
        }

        override fun newArray(size: Int): Array<PaymentFlowState?> {
            return arrayOfNulls(size)
        }
    }
}