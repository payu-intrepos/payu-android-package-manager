package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PaymentOptionOfferinfo(
    val emiBankCode: String? = null,
    val title: String,
    val paymentCode: String,
    val paymentOptionName: String?
) : Parcelable