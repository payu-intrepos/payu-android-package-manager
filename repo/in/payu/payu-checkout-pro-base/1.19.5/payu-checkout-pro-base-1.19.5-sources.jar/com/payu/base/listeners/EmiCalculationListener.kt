package com.payu.base.listeners

import com.payu.base.listeners.BaseApiListener
import com.payu.base.models.ErrorResponse
import com.payu.base.models.calculateEmi.EmiDetails
import org.json.JSONObject

interface EmiCalculationListener:BaseApiListener {
    fun onEmiCalculated(list : ArrayList<EmiDetails>?)
}
