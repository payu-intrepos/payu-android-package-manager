package com.payu.base.models

import kotlinx.parcelize.Parcelize

@Parcelize
class UPIOption : PaymentOption() {
    var vpa: String = ""
    var packageName: String = ""
    var upiHandles: ArrayList<String> = ArrayList()
    var appName: String = ""
}