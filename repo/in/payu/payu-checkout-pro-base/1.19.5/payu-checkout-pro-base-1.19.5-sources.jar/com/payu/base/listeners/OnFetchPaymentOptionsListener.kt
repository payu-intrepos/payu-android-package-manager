package com.payu.base.listeners

import com.payu.base.models.PaymentMode

interface OnFetchPaymentOptionsListener : BaseApiListener {
    fun onMoreOptionsFetched(list: ArrayList<PaymentMode>?)
    fun onQuickOptionsFetched(list: ArrayList<PaymentMode>?, shouldAuthenticate: Boolean)
}