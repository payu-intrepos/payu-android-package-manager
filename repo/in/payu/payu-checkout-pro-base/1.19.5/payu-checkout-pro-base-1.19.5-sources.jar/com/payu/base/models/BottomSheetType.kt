package com.payu.base.models

enum class BottomSheetType {

    L1_BOTTOM_SHEET,
    L2_TOP_BANKS,
    OTHERS

}