package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PayUUserDetail(
    val firstName: String? = null,
    val phoneNo: String? = null,
    val email: String? = null,
) : Parcelable


