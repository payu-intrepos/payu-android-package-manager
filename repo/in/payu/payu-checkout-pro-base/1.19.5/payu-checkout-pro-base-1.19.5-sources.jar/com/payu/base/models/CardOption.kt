package com.payu.base.models

import kotlinx.parcelize.Parcelize

@Parcelize
open class CardOption : PaymentOption() {
    var nameOnCard: String = ""
    var cardAlias: String = ""
    var cardNumber: String = ""
    var cvv: String = ""
    var expiryMonth: String = ""
    var expiryYear: String = ""
    override var additionalCharge: Double? = cardBinInfo?.additionalCharge
    override var gstPercentageValue: Double? = cardBinInfo?.gstPercentageValue
    //Below params are used for Multi Currency Payments
    var lookupId: String = ""
    var convertedAmount: String = ""
    var convertedCurrency: String = ""
}