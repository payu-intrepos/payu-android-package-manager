package com.payu.base.models

class PayuToolbar {
    var title: String = ""
    var textColor: Int = -1
    var bgColor: Int = -1
}