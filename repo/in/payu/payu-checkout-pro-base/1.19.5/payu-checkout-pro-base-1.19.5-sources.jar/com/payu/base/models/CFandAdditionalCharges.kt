package com.payu.base.models

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.parcelize.Parcelize

@Keep
@Parcelize
data class CFandAdditionalCharges(
    var feeCombinations: HashMap<String, FeeCombinations>? = null,
    var feeCombinationsSi: HashMap<String, FeeCombinations>? = null,
    var additionalCharge: AdditionalCharge? = null
) : Parcelable

@Keep
@Parcelize
data class AdditionalCharge(
    var convenienceFee: String? = null,
    var gst: String? = null
) : Parcelable