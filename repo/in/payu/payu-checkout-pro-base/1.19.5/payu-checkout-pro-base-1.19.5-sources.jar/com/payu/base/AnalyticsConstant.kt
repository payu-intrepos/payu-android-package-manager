package com.payu.base

import org.json.JSONObject

object AnalyticsConstant {

    const val PAYU_IS_FREE_TRIAL = "isFreeTrial"
    const val PAYU_BILLING_CYCLE = "billingCycle"
    const val PAYU_BILLING_INTERVAL = "billingInterval"
    const val PAYU_BILLING_AMOUNT = "billingAmount"
    const val PAYU_BILLING_CURRENCY = "billingCurrency"
    const val PAYU_PAYMENT_START_DATE = "paymentStartDate"
    const val PAYU_PAYMENT_END_DATE = "paymentEndDate"
    const val PAYU_REMARKS = "remarks"
    const val PAYU_BILLING_LIMIT = "billingLimit"
    const val PAYU_BILLING_RULE = "billingRule"
    const val PAYU_BILLING_DATE = "billingDate"
    const val PAYU_ENACH_FEEDBACK_HANDLER_MESSAGE = "enachFeedbackHandlerMessage"
    const val PAYU_ENACH_FEEDBACK_HANDLER_TITLE = "enachFeedbackHandlerTitle"
    const val PAYU_ENACH_ENABLE_FEEDBACK = "enachEnableFeedback"
    const val PAYU_ENACH_ENABLE_FEEDBACK_HANDLER = "enachEnableFeedbackHandler"
    const val PAYU_CC_CARD_TYPE = "ccCardType"
    const val PAYU_CC_CATEGORY = "ccCategory"
    const val PAYU_BENEFICIARY_DETAILS = "beneficiaryDetail"

    const val PAYU_AMOUNT = "amount"
    const val PAYU_IS_PRODUCTION = "isProduction"
    const val PAYU_KEY = "key"
    const val PAYU_TRANSACTION_ID = "transactionId"
    const val PAYU_PRODUCT_INFO = "productInfo"
    const val PAYU_FIRST_NAME = "firstName"
    const val PAYU_EMAIL = "email"
    const val PAYU_PHONE = "phone"
    const val PAYU_SURL = "surl"
    const val PAYU_FURL = "furl"
    const val PAYU_USER_CREDENTIALS = "userCredential"
    const val PAYU_PAYU_SI_PARAMS = "payUSIParams"
    const val PAYU_ADDITIONAL_PARAMS = "additionalParams"
    const val PAYU_SPLIT_PAYMENT_DETAILS = "splitPaymentDetails"
    const val PAYU_CATEGORY = "category"
    const val PAYU_USER_TOKEN = "userToken"
    const val PAYU_SKU_DETAILS = "skuDetails"
    const val PAYU_ENABLE_NATIVE_OTP = "enableNativeOTP"
    const val PAYU_ADDITIONAL_CHARGES= "additionalCharges"
    const val PAYU_PERCENTAGE_ADDITIONAL_CHARGES = "percentageAdditionalCharges"

    const val PAYU_BENEFICIARY_NAME = "beneficiaryName"
    const val PAYU_BENEFICIARY_ACCOUNT_NUMBER = "beneficiaryAccountNumber"
    const val PAYU_BENEFICIARY_IFSC = "beneficiaryIfsc"
    const val PAYU_VERIFICATION_MODE = "verificationMode"
    const val PAYU_BENEFICIARY_ACCOUNT_TYPE = "beneficiaryAccountType"

    const val PAYU_VALUE = "value"

    const val PAYU_OFFER_KEYS = "offerKeys"
}