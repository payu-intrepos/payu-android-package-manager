package com.payu.base.models

import com.payu.base.models.calculateEmi.EmiOfferInfo

object InternalConfig {
    var selectedOfferInfo: SelectedOfferInfo? = null
    var isAdsEnabled: Boolean = false
    var oneClickPayBankCodes: List<String>? = null
    var isQuickPayEnabled: Boolean = false
    var walletIdentifier: String? = null
    var logo: String? = null
    var enableInternal3DSS: Boolean = false
    var internationalOn3DSS: Boolean = false
    var enable3dsSDK: Boolean = false
    var threeDSSupportedBankList: List<String>? = null
    var isDeviceIdApiEnabled: Boolean = false
    var emiOfferInfo: EmiOfferInfo? = null
    var interestCharged: Double? = null
    var noCostEmi: ArrayList<String>? = null
    var offerBankListEmi: ArrayList<String>? = null
    var userSelectedOfferInfo: OfferInfo? = null
    var isPaymentOptionSelected: Boolean = false
    var outletId: Int? = null
    var isOfferEnabled: Boolean = false
    var removeOfferIfNeeded: Boolean = true
    var isEnforced: Boolean = false
    var isRetryTxn = false
    var isQuickPayBottomSheetEnabled = false
    var userAccountInfoList: List<UserAccountInfo>? = null
    var isNfcEnabled = false
    var isUserConsentAvailableForPersonalisedOffers: Boolean? = null
    var isUserPersonalizedOffersAvailable = false
    var isPricingCFCall: Boolean? = null
    var supportedUpiSiIntentAppList: ArrayList<String>? = null
    var appliedCouponOfferKey: String? = null
    var couponsAvailable = false
    var deviceId: String? = null
    var isInsuranceMerchant: Boolean? = null
    var merchantDisplayName: String? = null
    var pricingEnabledModes: List<String>? = null
    var disableConvFeeCompounding: Boolean ? = null
    var compoundingPercentage: String? = null
    var isTimerEnabled: Boolean? = null
    var timerTime: Int? = null

    var freeTrialAmounts: HashMap<String, String>? = null
    var siBufferAmount: Double? = null

    var paymentInProgress = false;

}