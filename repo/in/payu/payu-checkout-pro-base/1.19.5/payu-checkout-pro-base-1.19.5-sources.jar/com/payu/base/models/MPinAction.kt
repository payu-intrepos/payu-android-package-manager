package com.payu.base.models

enum class MPinAction {
    SETMPIN,
    FORGOTMPIN,
    TOKENEXPIRED
}