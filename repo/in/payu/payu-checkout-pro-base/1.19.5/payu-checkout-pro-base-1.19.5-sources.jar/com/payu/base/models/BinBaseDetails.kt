package com.payu.base.models

data class BinBaseDetails(
    var cardBinInfo: CardBinInfo? = null,
    var selectedOfferInfo: SelectedOfferInfo? = null,
    var feeCombinations: FeeCombinations? = null,
    var feeCombinationsSi: FeeCombinations? = null
)
