package com.payu.base.models

class NBOptions: PaymentOption(), Cloneable {

    var beneficiaryDetails: PayUBeneficiaryDetail? = null

    public override fun clone(): Any {
        return super.clone() as NBOptions
    }
}