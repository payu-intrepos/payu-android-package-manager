package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DiscountDetailsofOffers(
    val discountPercentage: String?,
    val maxDiscount: Double?,
    val discountType: String?,
    val discount: Double?,
    val discountedAmount: Double?
) : Parcelable