package com.payu.base.models

enum class PaymentState {
    MobileEligibility,
    MCP,
    RETRY,
    CardTenureEligibility,
    CardMobileTenureEligibility,
    CardnumMobileTenureEligibility,
    CardnumTenureEligibility,
    FullCard,
    BankDetails,
    VPAEligibility,
    INTENT,
    Mobile,
    Default,
    MobilePanTenureEligibility,
    ClosedLoopWalletLoadAndPay,
    VpaAndMobileEligibility,
    OLW
}
