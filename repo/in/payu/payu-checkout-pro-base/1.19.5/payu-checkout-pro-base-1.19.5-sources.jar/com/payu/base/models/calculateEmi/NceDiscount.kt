package com.payu.base.models.calculateEmi

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
open class NceDiscount(
    var total: Double = 0.0,
    var instant: Double? = 0.0,
    var cashback: Double? = 0.0
) : Parcelable