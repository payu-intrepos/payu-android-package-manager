package com.payu.base.models

data class DeviceIdRequestModel(var payUID: String, var gaID: String)