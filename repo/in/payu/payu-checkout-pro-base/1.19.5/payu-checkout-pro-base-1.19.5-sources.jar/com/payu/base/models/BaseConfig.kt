package com.payu.base.models

import android.content.Context

open class BaseConfig() {
    var paymentModesOrder: ArrayList<PaymentMode>? = null
    var cartDetails: ArrayList<OrderDetails>? = null
    var customNoteDetails: ArrayList<CustomNote>? = null
    var showExitConfirmationOnCheckoutScreen: Boolean = true
    var merchantName: String = ""
    var merchantLogo: Int? = null
    var enforcePaymentList: ArrayList<HashMap<String, String>>? = null
    var merchantLogoUrl: String? = null
    var primaryColor: String? = null
    var primaryColorDark: String? = null
    var primaryColorAccent: String? = null
    var baseTextColor: String? = null
    var showMerchantLogo: Boolean = false
    var enableSavedCard: Boolean = true
    var isQrScan: Boolean = false
    var enableREOptions: Boolean = true
    var upiAppsOrder: String? = null

    var isProtectedScreen: Boolean = true

    fun isProtectedScreen (context: Context): Boolean {
        if(isReleaseBuild(context))
            return true
        return isProtectedScreen
    }

    fun isReleaseBuild(context: Context): Boolean {
        return try {
            val clazz = Class.forName("${context.packageName}.BuildConfig")
            val buildType = clazz.getField("BUILD_TYPE").get(null) as String
            buildType == "release"
        } catch (e: Exception) {
            true // safe default — treat unknown as release
        }
    }
}
