package com.payu.base.listeners

interface HashGenerationListener {
    fun onHashGenerated(map: HashMap<String, String?>)
}