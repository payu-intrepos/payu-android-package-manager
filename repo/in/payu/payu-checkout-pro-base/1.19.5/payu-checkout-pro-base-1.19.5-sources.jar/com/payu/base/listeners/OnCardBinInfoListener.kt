package com.payu.base.listeners

import com.payu.base.models.CardBinInfo

interface OnCardBinInfoListener : BaseApiListener {
    fun onCardBinInfo(cardBinInfo: CardBinInfo?)
}