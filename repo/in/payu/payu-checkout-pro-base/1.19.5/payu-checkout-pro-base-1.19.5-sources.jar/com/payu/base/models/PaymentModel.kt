package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PaymentModel(
    var paymentOption: PaymentOption? = null,
    var paymentOptionList: ArrayList<PaymentOption>? = null,
    var paymentFlowState: PaymentFlowState? = null
) : Parcelable