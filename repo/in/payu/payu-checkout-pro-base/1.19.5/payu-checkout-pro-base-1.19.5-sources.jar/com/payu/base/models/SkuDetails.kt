package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SkuDetails(val skus: List<SKU>) : Parcelable
