package com.payu.base.models

class WalletOption : PaymentOption() {
}