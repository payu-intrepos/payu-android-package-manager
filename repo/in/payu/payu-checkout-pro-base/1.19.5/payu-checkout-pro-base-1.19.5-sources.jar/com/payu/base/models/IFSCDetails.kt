package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class IFSCDetails(
    val bank: String,
    val city: String,
    val ifsc: String,
    val micr: String,
    val state: String,
    val branch: String,
    val office: String,
    val address: String,
    val contact: String,
    val district: String
) : Parcelable