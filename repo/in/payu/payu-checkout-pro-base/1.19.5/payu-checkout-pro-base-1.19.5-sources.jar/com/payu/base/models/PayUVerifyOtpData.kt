package com.payu.base.models

data class PayUVerifyOtpData(
    val mobileNumber: String? = null,
    val maskedMobileNumber: String? = null,
    val verifyOtpDesc: String? = null,
    val postVerifyAction: (() -> Unit)? = null
)
