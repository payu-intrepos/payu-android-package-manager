package com.payu.base.models

data class OlwPaymentOption(
    var isMPinSet: Boolean = false,
    var customerRegistered: Boolean = true,
    var topUpAmount: Double? = null,
    var mPin: String? = null,
    var token: String? = null,
    var otp: String? = null,
    var errorMessage: String? = null
) : SodexoCardOption()