package com.payu.base.listeners

import com.payu.base.models.ErrorResponse

interface PaymentVerificationListener : BaseApiListener {
    fun onPaymentVerificationFailed(response: Any?)
    fun onPaymentVerificationSuccess(response: Any?)
    fun onPaymentVerificationPending(errorResponse: ErrorResponse)
}