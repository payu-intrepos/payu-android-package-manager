package com.payu.base.models

 class QuickOptionsModel {

    var quickOptionsList: ArrayList<PaymentMode>? = null
    var recommendedOptionsList: ArrayList<PaymentMode>? = null
    var errorResponse: ErrorResponse? = null
}