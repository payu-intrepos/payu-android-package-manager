package com.payu.base.listeners

interface OnLookupApiListener : BaseApiListener {
    fun onLookupApiCalled()
}