package com.payu.base.models

class CardBinInfo(
    var cardScheme: CardScheme? = null,
    var cardType: CardType? = null,
    var isDomestic: Boolean = true,
    var issuingBank: String? = null,
    var isBankDown: Boolean = false,
    open var additionalCharge: Double? = null,
    open var gstPercentageValue: Double? = null,
    var gstFlatValue: Double? = null,
    var bankCode: String? = null,
    var isSiSupported: Boolean = false,
    var cardCategory: String? = null,
    var binNumber: String? = null,
    var message: String? = null,
    var emiOption: EMIOption? = null
)