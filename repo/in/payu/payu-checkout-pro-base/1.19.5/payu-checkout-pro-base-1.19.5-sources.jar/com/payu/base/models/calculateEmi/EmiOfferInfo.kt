package com.payu.base.models.calculateEmi

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class EmiOfferInfo(
    var nceDiscount: NceDiscount? = null,
    var offerDiscount: NceDiscount? = null,
    var totalPayableAmount: Double = 0.0,
    var revisedPrincipalAmount: Double = 0.0
) : Parcelable