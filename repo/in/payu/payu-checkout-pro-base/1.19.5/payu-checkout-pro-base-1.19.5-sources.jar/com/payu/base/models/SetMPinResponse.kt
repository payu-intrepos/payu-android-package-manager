// YApi QuickType插件生成，具体参考文档:https://plugins.jetbrains.com/plugin/18847-yapi-quicktype/documentation

package com.payu.base.models

data class SetMPinResponse(
    val olwAPIResponse: OlwAPIResponse?,
    val deviceId: String?,
    val token: String?,
    val tokenExpiryTime: String?,
    val mpinExpiryTime: String?
)
