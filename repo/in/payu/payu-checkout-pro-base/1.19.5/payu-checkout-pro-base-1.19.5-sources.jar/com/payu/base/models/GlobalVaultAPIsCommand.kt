package com.payu.base.models

/**
 * Enums to distinguish the category of the Global Vault results
 */
enum class GlobalVaultAPIsCommand {
    SEND_OTP,
    RESEND_OTP,
    VERIFY_OTP,
    GLOBAL_VAULT_LIST
}