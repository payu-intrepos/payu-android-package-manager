package com.payu.base.listeners

import com.payu.base.models.ErrorResponse

interface BaseApiListener {
    fun onError(errorResponse: ErrorResponse)
    fun showProgressDialog(showDialog: Boolean)
}
