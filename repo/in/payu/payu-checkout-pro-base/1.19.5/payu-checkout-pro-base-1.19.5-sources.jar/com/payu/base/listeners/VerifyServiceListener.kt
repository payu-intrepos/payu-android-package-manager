package com.payu.base.listeners

import com.payu.base.models.ApiResponse

interface VerifyServiceListener {
    fun eligibilityDetails(apiResponse: ApiResponse)
}