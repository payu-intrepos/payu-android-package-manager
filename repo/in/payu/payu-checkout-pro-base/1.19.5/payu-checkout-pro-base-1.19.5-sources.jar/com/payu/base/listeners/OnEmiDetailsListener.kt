package com.payu.base.listeners

import com.payu.base.models.PaymentOption

interface OnEmiDetailsListener : BaseApiListener {
    fun emiDetailsReceived(emiList: ArrayList<PaymentOption>)
}