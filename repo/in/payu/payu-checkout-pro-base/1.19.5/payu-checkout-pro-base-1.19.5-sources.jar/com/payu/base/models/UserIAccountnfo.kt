package com.payu.base.models

data class UserAccountInfo(
    val bankName: String,
    val imageUrl: String?,
    val accountDetails: PayUBeneficiaryDetail?
)
