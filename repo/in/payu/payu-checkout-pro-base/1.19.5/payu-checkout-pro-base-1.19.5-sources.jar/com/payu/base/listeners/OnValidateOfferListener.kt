package com.payu.base.listeners

import com.payu.base.models.SelectedOfferInfo

interface OnValidateOfferListener {
    fun onValidateOfferResponse(selectedOfferInfo: SelectedOfferInfo?)
}