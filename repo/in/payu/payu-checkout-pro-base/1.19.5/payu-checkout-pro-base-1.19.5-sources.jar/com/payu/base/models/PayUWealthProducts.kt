// YApi QuickType插件生成，具体参考文档:https://plugins.jetbrains.com/plugin/18847-yapi-quicktype/documentation

package com.payu.base.models

class PayUWealthProducts(builder: Builder) {

    var mfInvestmentType: String = ""
        private set

    var mfAmcCode: String = ""
        private set

    var amount: String = ""
        private set

    var scheme: String = ""
        private set

    var mfPartner: String = ""
        private set

    var folio: String = ""
        private set

    var receipt: String = ""
        private set

    var mfUserID: String = ""
        private set

    var type: String = ""
        private set

    var plan: String = ""
        private set

    var mfMemberID: String = ""
        private set

    var option: String = ""
        private set


    init {
        this.mfInvestmentType = builder.mfInvestmentType
        this.mfAmcCode = builder.mfAmcCode
        this.amount = builder.amount
        this.scheme = builder.scheme
        this.mfPartner = builder.mfPartner
        this.folio = builder.folio
        this.receipt = builder.receipt
        this.mfUserID = builder.mfUserID
        this.type = builder.type
        this.plan = builder.plan
        this.mfMemberID = builder.mfMemberID
        this.option = builder.option
    }

    class Builder(
        var type: String,
        var amount: String,
        var receipt: String,
        var mfMemberID: String,
        var mfUserID: String,
        var mfPartner: String,
        var mfInvestmentType: String
    ) {
        var mfAmcCode: String = ""
        var scheme: String = ""
        var folio: String = ""
        var plan: String = ""
        var option: String = ""

        fun setMfAmcCode(value: String) = apply { this.mfAmcCode = value }
        fun setScheme(value: String) = apply { this.scheme = value }
        fun setFolio(value: String) = apply { this.folio = value }
        fun setPlan(value: String) = apply { this.plan = value }
        fun setOption(value: String) = apply { this.option = value }

        fun build() = PayUWealthProducts(this)
    }
}
