package com.payu.base.listeners

interface V2BaseTransactionListener {
    fun generateV2Hash(
        map: HashMap<String, String?>,
        hashGenerationListener: HashGenerationListener
    )
}