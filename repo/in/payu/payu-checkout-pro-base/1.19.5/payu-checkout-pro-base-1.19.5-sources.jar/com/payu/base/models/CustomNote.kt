package com.payu.base.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class CustomNote(var custom_note: String, var custom_note_category: ArrayList<PaymentType>?) :
    Parcelable