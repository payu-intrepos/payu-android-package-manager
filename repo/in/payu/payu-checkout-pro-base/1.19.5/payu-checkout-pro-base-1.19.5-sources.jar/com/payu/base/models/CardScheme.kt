package com.payu.base.models

enum class CardScheme {
    VISA,
    MAST,
    AMEX,
    MAES,
    SMAE,
    RUPAY,
    RUPAYCC,
    JCB,
    DINR,
    DISCOVER,
    SODEXO,
    UNKNOWN
}