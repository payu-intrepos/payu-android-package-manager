package com.payu.base.models

enum class LoadMoney {
    PAY200,
    PAY500,
    PAY1000
}