package com.payu.base.models

import androidx.annotation.DrawableRes

class ImageParam(
    var paymentOption: PaymentOption,
    var isCardScheme: Boolean,
    @DrawableRes var defaultDrawable: Int,
    var imageKey: String? = null
)
