package com.payu.base.models

data class GoogleAdIdInfo(val adId: String?, val status: Boolean, val errorMessage: String?)
