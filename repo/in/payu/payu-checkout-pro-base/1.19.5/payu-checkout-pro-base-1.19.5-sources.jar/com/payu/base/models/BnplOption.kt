package com.payu.base.models

class BnplOption : PaymentOption(), Cloneable {
    var isEligible: Boolean? = null
    public override fun clone(): Any {
        val user = super.clone() as BnplOption
        return user
    }
}