package com.payu.base.models

class ApiResponse {
    var status: Boolean? = false
    var errorMessage: String = ""
    var successMessage: String = ""
    var paymentOptionList: ArrayList<PaymentOption>? = null
}