
package com.payu.base.models

data class OlwAPIResponse(
    val responseMessage: String?,
    val responseCode: String?,
    val messageCode: Long?,
    val responseDateTime: String?,
    val clientTxnID: String?,
    val token: String?
)
