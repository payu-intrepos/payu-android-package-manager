package com.payu.base.models

open class SodexoCardOption : CardOption() {
    var balance: String = "-1"
    var fetchedStatus: Int = -1
    var isNewCard = false
    var walletUrn: String? = null
    var loadAmount: String? = null
}