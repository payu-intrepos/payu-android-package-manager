package com.payu.base.models

enum class PayUBillingCycle {
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY,
    ONCE,
    ADHOC;
}