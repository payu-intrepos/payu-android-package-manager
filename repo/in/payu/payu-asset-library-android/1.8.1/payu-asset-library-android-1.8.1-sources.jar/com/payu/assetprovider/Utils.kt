package com.payu.assetprovider

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.graphics.drawable.toBitmap
import com.payu.assetprovider.PaymentTypes.*
import com.payu.assetprovider.completionmanager.CompletionManager
import com.payu.assetprovider.enums.DrawableType
import com.payu.assetprovider.imagecache.ImageMemoryCache
import com.payu.assetprovider.model.ImageDetails
import com.payu.assetprovider.task.FetchImageFromURLTask
import java.util.*
import java.util.concurrent.Executors


object Utils {

    private val bitmapLoadExecutor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun getBitmapFromDrawable(context: Context, drawableId: Int): Bitmap? {
        return AppCompatResources.getDrawable(context, drawableId)?.toBitmap()
//        return BitmapFactory.decodeResource(context.applicationContext.resources, drawableId);
    }

    private fun PaymentTypes.nameLowerCase(): String = this.name.lowercase(Locale.getDefault())

    private fun getResourceForTypes(types: String, defaultDrawableId: Int): Int {
        return when (types) {
            ALLB.nameLowerCase() -> R.drawable.payu_allahabadbank
            ADBB.nameLowerCase(), ANDBENCC.nameLowerCase(), ABNBTPV.nameLowerCase() -> R.drawable.payu_andhrabank
            ABIRLA.nameLowerCase() -> R.drawable.payu_aditya_birla_payments
            AXISCNB.nameLowerCase(), AXIS.nameLowerCase(), AXIB.nameLowerCase(), UTIBENCC.nameLowerCase(), AXNBTPV.nameLowerCase(), AXISD.nameLowerCase() -> R.drawable.payu_axisbank
            AIRNB.nameLowerCase(), AMON.nameLowerCase() -> R.drawable.payu_airtel
            BBRB.nameLowerCase(), BOB.nameLowerCase(), BBCB.nameLowerCase(), BARBENCC.nameLowerCase(), BOBD.nameLowerCase() -> R.drawable.payu_bank_of_baroda
            BBKB.nameLowerCase() -> R.drawable.payu_bankofbahrainkuwait
            BHNB.nameLowerCase() -> R.drawable.payu_the_bharat_co_op_bank_ltd
            BMNN.nameLowerCase() -> R.drawable.payu_payzapp
            BOIB.nameLowerCase(), BKIDENCC.nameLowerCase() -> R.drawable.payu_bank_of_india
            BOMB.nameLowerCase(), MAHBENCC.nameLowerCase() -> R.drawable.payu_bank_of_maharastra
            CABB.nameLowerCase(), CNRBENCC.nameLowerCase(), CBNBTPV.nameLowerCase() -> R.drawable.payu_canara_bank
            CBIB.nameLowerCase(), CBINENCC.nameLowerCase() -> R.drawable.payu_central_bank_of_india
            CITNB.nameLowerCase(), CITIRDR.nameLowerCase(), CITI.nameLowerCase() -> R.drawable.payu_citi
            CORP.nameLowerCase(), CRPB.nameLowerCase(), CRBP.nameLowerCase() -> R.drawable.payu_corporation_bank
            CSBN.nameLowerCase(), CSBNBTPV.nameLowerCase() -> R.drawable.payu_catholic_syrianbank
            CSMSNB.nameLowerCase(), COSBENCC.nameLowerCase() -> R.drawable.payu_cosmos_bank
            CUBB.nameLowerCase(), CIUBENCC.nameLowerCase() -> R.drawable.payu_city_union_bank
            DBSB.nameLowerCase(), DBSSENCC.nameLowerCase() -> R.drawable.payu_dbs_bank
            DCBB.nameLowerCase(), DCBLENCC.nameLowerCase(), DCBCORP.nameLowerCase() -> R.drawable.payu_dcb
            DENN.nameLowerCase() -> R.drawable.payu_dena_bank
            DLSB.nameLowerCase(), DLXBENCC.nameLowerCase(), DLSBCORP.nameLowerCase(), DLSNBTPV.nameLowerCase() -> R.drawable.payu_dhanlaxmi_bank
            DSHB.nameLowerCase(), DEUTENCC.nameLowerCase() -> R.drawable.payu_deutsche_bank
            FEDB.nameLowerCase(), FDRLENCC.nameLowerCase(), FEDERAL.nameLowerCase(), FEDED.nameLowerCase() -> R.drawable.payu_federal_bank
            HDFB.nameLowerCase(), HDFCENCC.nameLowerCase(), HDFCCONB.nameLowerCase(), HDFC.nameLowerCase(), HDFCD.nameLowerCase(), HDFNBTPV.nameLowerCase() -> R.drawable.payu_hdfc_bank
            ICIB.nameLowerCase(), ICICB.nameLowerCase(), ICICENCC.nameLowerCase(), ICICICNB.nameLowerCase(), ICICI.nameLowerCase(), ICICID.nameLowerCase(), ICINBTPV.nameLowerCase() -> R.drawable.payu_icici_bank
            IDBB.nameLowerCase(), IBKLENCC.nameLowerCase(), IDBC.nameLowerCase() -> R.drawable.payu_idbi
            IDFCNB.nameLowerCase(), IDFBENCC.nameLowerCase(), IDFNBTPV.nameLowerCase() -> R.drawable.payu_idfc_bank
            INDB.nameLowerCase() -> R.drawable.payu_indian_bank
            INGB.nameLowerCase() -> R.drawable.payu_ing_vysya_bank
            INIB.nameLowerCase(), INDUS.nameLowerCase(),
            INDBENCC.nameLowerCase() -> R.drawable.payu_indus_ind_bank
            INOB.nameLowerCase(), IOBAENCC.nameLowerCase(), IOB.nameLowerCase(), IOBNBTPV.nameLowerCase() -> R.drawable.payu_indian_overseas_bank
            JAKB.nameLowerCase() -> R.drawable.payu_j_k_bank
            JSBNB.nameLowerCase() -> R.drawable.payu_janata_sahakari_bank_pune
            KRKB.nameLowerCase(), KARBENCC.nameLowerCase() -> R.drawable.payu_karnataka_bank
            KRVB.nameLowerCase(), KVBLENCC.nameLowerCase(), KRVBC.nameLowerCase(), KVBNBTPV.nameLowerCase() -> R.drawable.payu_karur_vysya_bank
            LAZYPAY.nameLowerCase() -> R.drawable.payu_emi_lazy_pay
            LVBD.nameLowerCase(), LVRB.nameLowerCase(), LVBNBTPV.nameLowerCase(), LVCB.nameLowerCase() -> R.drawable.payu_laxmi_vilas_bank
            OBCB.nameLowerCase(), ORBCENCC.nameLowerCase(), OBCNBTPV.nameLowerCase() -> R.drawable.payu_oriental_bank_of_commerce
            PMNB.nameLowerCase() -> R.drawable.payu_punjab_maharashtra_co_operative_bank_limited
            PNBB.nameLowerCase(), PUNBENCC.nameLowerCase(), PNBNBTPV.nameLowerCase(), CPNB.nameLowerCase() -> R.drawable.payu_punjab_national_bank
            PSBNB.nameLowerCase(), PSIBENCC.nameLowerCase() -> R.drawable.payu_punjab_sind_bank
            RBL.nameLowerCase(), RATNENCC.nameLowerCase(), RTN.nameLowerCase() -> R.drawable.payu_rbl
            RYBS.nameLowerCase() -> R.drawable.payu_royal_bank_of_scotland
            SBBJB.nameLowerCase(), SBNCORP.nameLowerCase(), SBTB.nameLowerCase(), SBI.nameLowerCase(), SBPB.nameLowerCase(), SBINBTPV.nameLowerCase(), SBMB.nameLowerCase(), SBIB.nameLowerCase(), SBINENCC.nameLowerCase(), SBHB.nameLowerCase() -> R.drawable.payu_state_bank_of_india_corporate
            SCBNB.nameLowerCase(), SDCB.nameLowerCase(), SCB.nameLowerCase(), SCBLENCC.nameLowerCase(), SCBNBTPV.nameLowerCase() -> R.drawable.payu_standard_chartered_bank
            SOIB.nameLowerCase(), SIBLENCC.nameLowerCase() -> R.drawable.payu_south_india_bank
            SRSWT.nameLowerCase() -> R.drawable.payu_saraswat_bank
            SVCB.nameLowerCase(), SVCNB.nameLowerCase() -> R.drawable.payu_shamrao_vithal
            SYDB.nameLowerCase(), SYNBENCC.nameLowerCase(), SYNDB.nameLowerCase() -> R.drawable.payu_syndicate_bank
            TBON.nameLowerCase() -> R.drawable.payu_the_nainital_bank
            TMBB.nameLowerCase(), TMBLENCC.nameLowerCase() -> R.drawable.payu_tamilnad_mercantile_bank
            UBIB.nameLowerCase(), UBINENCC.nameLowerCase(), UBIBC.nameLowerCase() -> R.drawable.payu_union_bankof_india
            UCOB.nameLowerCase(), UCBAENCC.nameLowerCase() -> R.drawable.payu_uco_bank
            UNIB.nameLowerCase(), UTBIENCC.nameLowerCase() -> R.drawable.payu_united_bank_of_india
            VJYB.nameLowerCase() -> R.drawable.payu_vijaya_bank
            YESB.nameLowerCase(), YES.nameLowerCase(), YESBENCC.nameLowerCase(), YESNBTPV.nameLowerCase() -> R.drawable.payu_yes_bank
            HSBC.nameLowerCase() -> R.drawable.payu_hsbc
            ONEC.nameLowerCase() -> R.drawable.payu_one_card
            AUSF.nameLowerCase() -> R.drawable.payu_au_bank
            AMZPAY.nameLowerCase() -> R.drawable.payu_amazon
            BKASH.nameLowerCase() -> R.drawable.payu_bkash
            CPMC.nameLowerCase(), CITIENCC.nameLowerCase() -> R.drawable.payu_citi
            DONE.nameLowerCase() -> R.drawable.payu_done_card
            FREC.nameLowerCase() -> R.drawable.payu_freecharge
            ICASH.nameLowerCase(), IDM.nameLowerCase() -> R.drawable.payu_icash
            ITZC.nameLowerCase() -> R.drawable.payu_itzcash
            JIOM.nameLowerCase() -> R.drawable.payu_jio_money
            OLAM.nameLowerCase() -> R.drawable.payu_ola_money
            OXICASH.nameLowerCase() -> R.drawable.payu_oxigen
            PAYCASH.nameLowerCase() -> R.drawable.payu_paycash
            PAYTM.nameLowerCase(), PYTMENCC.nameLowerCase() -> R.drawable.payu_paytm
            PAYZ.nameLowerCase(), ZIPCASH.nameLowerCase() -> R.drawable.payu_payzapp
            PHONEPE.nameLowerCase(), PPINAPP.nameLowerCase(), PPINTENT.nameLowerCase(), PPSDKLES.nameLowerCase() -> R.drawable.payu_phonepe
            TEZ.nameLowerCase(), "google_pay" -> R.drawable.payu_google_pay
            YESW.nameLowerCase() -> R.drawable.payu_yespay
            "162b", KOTAK.nameLowerCase(), KKBKENCC.nameLowerCase(), KOTAKD.nameLowerCase() -> R.drawable.payu_kotak
            VISA.nameLowerCase() -> R.drawable.payu_visa
            DISCOVER.nameLowerCase() -> R.drawable.payu_discover
            MAST.nameLowerCase() -> R.drawable.payu_master_card
            MAES.nameLowerCase(), SMAE.nameLowerCase() -> R.drawable.payu_maestro
            JCB.nameLowerCase() -> R.drawable.payu_jcb
            RUPAY.nameLowerCase(), RUPAYCC.nameLowerCase() -> R.drawable.payu_rupay
            AMEX.nameLowerCase() -> R.drawable.payu_amex
            DINR.nameLowerCase() -> R.drawable.payu_dinersclub
            USFBENCC.nameLowerCase() -> R.drawable.payu_ujjivan_bank
            AUBLENCC.nameLowerCase() -> R.drawable.payu_au_bank
            ESFBENCC.nameLowerCase() -> R.drawable.payu_equitas_bank
            JSFBENCC.nameLowerCase(), JANANB.nameLowerCase() -> R.drawable.payu_jana_bank
            USD.nameLowerCase() -> R.drawable.payu_usd
            EUR.nameLowerCase() -> R.drawable.payu_eur
            JPY.nameLowerCase() -> R.drawable.payu_jpy
            GBP.nameLowerCase() -> R.drawable.payu_gbp
            CHF.nameLowerCase() -> R.drawable.payu_chf
            SEK.nameLowerCase() -> R.drawable.payu_sek
            DKK.nameLowerCase() -> R.drawable.payu_dkk
            NOK.nameLowerCase() -> R.drawable.payu_nok
            SGD.nameLowerCase() -> R.drawable.payu_sgd
            AUD.nameLowerCase() -> R.drawable.payu_aud
            CAD.nameLowerCase() -> R.drawable.payu_cad
            AED.nameLowerCase() -> R.drawable.payu_aed
            HKD.nameLowerCase() -> R.drawable.payu_hkd
            QAR.nameLowerCase() -> R.drawable.payu_qar
            SAR.nameLowerCase() -> R.drawable.payu_sar
            OMR.nameLowerCase() -> R.drawable.payu_omr
            ZAR.nameLowerCase() -> R.drawable.payu_zar
            MYR.nameLowerCase() -> R.drawable.payu_myr
            KWD.nameLowerCase() -> R.drawable.payu_kwd
            MUR.nameLowerCase() -> R.drawable.payu_mur
            LKR.nameLowerCase() -> R.drawable.payu_lkr
            KES.nameLowerCase() -> R.drawable.payu_kes
            NZD.nameLowerCase() -> R.drawable.payu_nzd
            THB.nameLowerCase() -> R.drawable.payu_thb
            BDT.nameLowerCase() -> R.drawable.payu_bdt
            CNY.nameLowerCase() -> R.drawable.payu_cny
            NPR.nameLowerCase() -> R.drawable.payu_npr
            BHD.nameLowerCase() -> R.drawable.payu_bhd
            INR.nameLowerCase() -> R.drawable.payu_inr
            BAJFIN.nameLowerCase() -> R.drawable.payu_emi_bajaj_finserv
            TWID.nameLowerCase() -> R.drawable.payu_rewards_twid
            BDBLENCC.nameLowerCase() -> R.drawable.payu_bandhan_bank
            SODEXO.nameLowerCase() -> R.drawable.payu_sodexo
            PLUXEE.nameLowerCase() -> R.drawable.payu_pluxee
            ZESTMONEY.nameLowerCase() -> R.drawable.payu_emi_zest_money
            SIMPL.nameLowerCase() -> R.drawable.payu_simpl
            else -> defaultDrawableId
        }
    }

    fun getDrawablesForTypes(context: Context, types: String, defaultDrawableId: Int): Bitmap? {
        return getBitmapFromDrawable(context, getResourceForTypes(types, defaultDrawableId))
    }

    /** check image details from cache, save and  return bitmap image (never blocks the main thread) */
    fun getBitmapFromURL(
        context: Context,
        imageURL: String?,
        updatedOn: Long,
        defaultDrawableId: Int,
        callback: BitmapCallback
    ) {
        if (!imageURL.isNullOrEmpty()) {
            val imageDetails =
                ImageDetails(
                    updatedOn = updatedOn,
                    imageUrl = imageURL,
                    defaultDrawableId = defaultDrawableId
                )
            if (CompletionManager.checkExistingRequestSaveIfNeeded(imageDetails, callback)) {
                bitmapLoadExecutor.execute {
                    val result = loadImageFromCacheOrServer(imageDetails, context, callback)
                    mainHandler.post {
                        CompletionManager.executeAllSaveCallback(result)
                    }
                }
            }
        } else {
            callback.onBitmapReceived("", ImageDetails())
        }
    }

    /** compare the date and return */
    private fun compareDates(currentTime: Long, cachedTime: Long): Boolean {
        return currentTime <= cachedTime
    }

    /** load the bitmap image from server end (never blocks the main thread) */
    fun getBitmapFromURL(imageUrl: String, callback: BitmapCallback) {
        bitmapLoadExecutor.execute {
            val result = try {
                FetchImageFromURLTask().execute(imageUrl).get() ?: ImageDetails()
            } catch (e: Exception) {
                ImageDetails()
            }
            mainHandler.post {
                callback.onBitmapReceived(imageUrl, result)
            }
        }
    }

    /** load the bitmap image from cache or server end */
    private fun loadImageFromCacheOrServer(
        imageDetails: ImageDetails,
        context: Context,
        callback: BitmapCallback
    ): ImageDetails {
        val imageURL = imageDetails.imageUrl
        val data = ImageMemoryCache.get(imageURL)
        return if (data != null && compareDates(imageDetails.updatedOn!!, data.updatedOn!!)) {
            imageDetails.drawableType = data.drawableType
            imageDetails.image = data.image
            imageDetails
        } else {
            val result = FetchImageFromURLTask().execute(imageURL).get()
            var bitmap = result?.image
            if (bitmap == null && imageDetails.defaultDrawableId != null) {
                bitmap = getBitmapFromDrawable(context, imageDetails.defaultDrawableId)
                imageDetails.image = bitmap
                imageDetails.drawableType = DrawableType.Bitmap
            } else {
                imageDetails.image = bitmap
                imageDetails.drawableType = result?.drawableType
                ImageMemoryCache.set(imageURL, imageDetails)
            }
            imageDetails
        }


    }
}