package com.payu.assetprovider.task

import android.graphics.BitmapFactory
import android.graphics.drawable.PictureDrawable
import android.os.AsyncTask
import android.util.Log
import android.webkit.URLUtil
import com.payu.assetprovider.BitmapCallback
import com.payu.assetprovider.enums.DrawableType
import com.payu.assetprovider.enums.ImageType
import com.payu.assetprovider.model.ImageDetails
import com.payu.assetprovider.svgHandler.SVG
import com.payu.assetprovider.task.base.PayUAsyncTask
import java.net.HttpURLConnection
import java.net.URL


class FetchImageFromURLTask :
    PayUAsyncTask<String?, Void?, ImageDetails?>() {

    override fun doInBackground(vararg url: String?): ImageDetails {

        val validUrl = url.isNotEmpty()  && URLUtil.isValidUrl(url[0].toString());

        if (validUrl) {
            val stringUrl = URL(url[0])
            var connection: HttpURLConnection? = null
            return try {
                connection = stringUrl.openConnection() as HttpURLConnection
                connection.connect()
                if (stringUrl.path.endsWith(ImageType.SVG.name.lowercase())) {
                    val pictureDrawable = PictureDrawable(
                        SVG.getFromInputStream(connection.inputStream).renderToPicture()
                    )
                    ImageDetails(
                        drawableType = DrawableType.PictureDrawable,
                        image = pictureDrawable
                    )
                } else
                    ImageDetails(
                        drawableType = DrawableType.Bitmap,
                        image = BitmapFactory.decodeStream(connection.inputStream)
                    )
            } catch (e: Exception) {
                Log.d(
                    FetchImageFromURLTask::class.simpleName,
                    "Exception while Fetching Image : " + e.message
                )
                return ImageDetails(drawableType = null, image = null)
            } finally {
                connection?.disconnect()
            }
        } else {
            Log.d(FetchImageFromURLTask::class.simpleName, "Exception invalid url  ")
            return ImageDetails(drawableType = null, image = null)
        }
    }
}
