package com.payu.assetprovider.imagecache

import android.util.LruCache
import com.payu.assetprovider.model.ImageDetails

/**
 *
 * ImageMemoryCache
 * Store the image Data in cache cache memory using LRU.
 */
object ImageMemoryCache {
    private val maxMemory = Runtime.getRuntime().maxMemory().toInt()
    private val cacheSize = maxMemory / 8

    private val cache = object : LruCache<String, ImageDetails>(cacheSize) {
    }

    /** get the image details using image url */
    fun get(key: String?): ImageDetails? {
        return cache.get(key)
    }

    /** set the image details*/
    fun set(key: String?, value: ImageDetails?) {
        cache.put(key, value)
    }

}
