package com.payu.assetprovider.svgHandler;

/*
 * Thrown by the CSS parser if a problem is found while parsing a CSS file.
 */

class CSSParseException extends Exception
{
   CSSParseException(String msg)
   {
      super(msg);
   }
}
