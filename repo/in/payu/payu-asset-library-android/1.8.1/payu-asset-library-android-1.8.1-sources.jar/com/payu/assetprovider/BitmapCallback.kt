package com.payu.assetprovider

import com.payu.assetprovider.model.ImageDetails

interface BitmapCallback {
    fun onBitmapReceived(types: String, data: ImageDetails)
}