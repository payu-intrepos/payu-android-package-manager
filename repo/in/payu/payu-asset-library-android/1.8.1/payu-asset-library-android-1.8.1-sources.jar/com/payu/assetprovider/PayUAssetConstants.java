package com.payu.assetprovider;

public interface PayUAssetConstants {

    String ASYNC_TASK_ILLEGAL_STATE_EXCEPTION_MESSAGE_1 = "Cannot execute task:"
            + " the task is already running.";

    String ASYNC_TASK_ILLEGAL_STATE_EXCEPTION_MESSAGE_2 = "Cannot execute task:"
            + " the task has already been executed "
            + "(a task can be executed only once)";
}
