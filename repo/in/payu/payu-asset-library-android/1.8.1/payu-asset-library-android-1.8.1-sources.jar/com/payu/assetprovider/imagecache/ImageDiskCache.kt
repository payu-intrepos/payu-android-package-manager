//package com.payu.assetprovider.imagecache
//
//import android.content.Context
//import android.os.Environment
//import android.os.Environment.isExternalStorageRemovable
//import androidx.annotation.Keep
//import com.payu.assetprovider.Utils
//import com.payu.assetprovider.model.ImageDetails
//import java.io.File
//import java.io.ObjectOutputStream
//import java.security.MessageDigest
//
///**
// *
// * ImageDiskCache
// * Store the image Data in disk memory like image url, timestamp.
// */
//class ImageDiskCache private constructor(var context: Context) {
//
//    private val DISK_CACHE_SIZE: Long = 10 * 1024 * 1024
//    private val DISK_CACHE_SUBDIR = "bankImages"
//    private var cache: DiskLruCache? = null
//    private var diskCacheDir: File? = null
//
//    init {
//        if (cache == null) {
//            diskCacheDir = getDiskCacheDir(context, DISK_CACHE_SUBDIR)
//            cache = DiskLruCache.open(
//                diskCacheDir!!,
//                1,
//                1,
//                DISK_CACHE_SIZE
//            )
//        }
//    }
//
//
//    /** return the filename, created using image url */
//    private fun filenameForKey(key: String): String {
//        return MessageDigest
//            .getInstance("SHA-1")
//            .digest(key.toByteArray())
//            .joinToString(separator = "", transform = { Integer.toHexString(0xFF and it.toInt()) })
//    }
//
//
//    /** get the image from disk memory by image url */
//    fun get(key: String): String? {
//        val filename = filenameForKey(key)
//        var snapshot: DiskLruCache.Snapshot? = null
//        try {
//            snapshot = cache?.get(filename)
//            if (snapshot == null) {
//                return null
//            }
//            return snapshot.getString(0)
//        } finally {
//            snapshot?.close()
//        }
//    }
//
//    /** save the image details into disk memory */
//    fun set(key: String?, value: ImageDetails) {
//        var objectOutputStream: ObjectOutputStream? = null
//        try {
//            val filename = filenameForKey(key!!)
//            val snapshot = cache?.get(filename)
//            if (snapshot == null) {
//                val editor = cache?.edit(filename)
//                value.bitmapString = Utils.encodeBitmapToBase64(value.image!!)
//                objectOutputStream = ObjectOutputStream(editor?.newOutputStream(0))
//                objectOutputStream.writeObject(value)
//                editor?.commit()
//            } else {
//                snapshot.getInputStream(0).close()
//            }
//        } catch (e: Exception) {
//
//        } finally {
//            objectOutputStream?.close()
//        }
//    }
//
//
//    /** return the disk memory cache path */
//    private fun getDiskCacheDir(context: Context, uniqueName: String): File {
//        val cachePath =
//            if (Environment.MEDIA_MOUNTED == Environment.getExternalStorageState()
//                || !isExternalStorageRemovable()
//            ) {
//                context.externalCacheDir?.path
//            } else {
//                context.cacheDir.path
//            }
//
//        return File(cachePath + File.separator + uniqueName)
//    }
//
//
//    /** refresh cache memory
//     * store the image data from disk memory into cache memory
//     * */
//    fun refreshCacheMemory() {
////        try {
////            val imagesList = diskCacheDir!!.listFiles()
////            for (element in imagesList) {
////                var fileInputStream: FileInputStream? = null
////                var objectInputStream: ObjectInputStream? = null
////
////                try {
////                    fileInputStream = FileInputStream(element.path)
////                    objectInputStream = ObjectInputStream(fileInputStream)
////                    val imageDataObj = objectInputStream.readObject() as ImageDataInfo
////                    ImageMemoryCache.set(
////                        imageDataObj.imageUrl, ImageDataInfo(
////                            Utils.decodeBase64(imageDataObj.bitmapString),
////                            imageDataObj.updatedOn,
////                            imageDataObj.bitmapString,
////                            imageDataObj.imageUrl
////                        )
////                    )
////                } catch (e: Exception) {
////                    e.message
////                } finally {
////                    fileInputStream?.close()
////                    objectInputStream?.close()
////                }
////            }
////        } catch (e: IOException) {
////        }
//    }
//
//    @Keep
//    companion object {
//        private var INSTANCE: ImageDiskCache? = null
//
//        @Synchronized
//        fun getInstance(context: Context): ImageDiskCache {
//            return INSTANCE ?: ImageDiskCache(context).also { INSTANCE = it }
//
//        }
//    }
//
//}
