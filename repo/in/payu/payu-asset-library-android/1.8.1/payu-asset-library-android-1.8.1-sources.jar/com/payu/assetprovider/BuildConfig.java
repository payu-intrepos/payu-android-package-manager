/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.assetprovider;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.assetprovider";
  public static final String BUILD_TYPE = "release";
}
