package com.payu.assetprovider.model

import com.payu.assetprovider.enums.DrawableType

data class ImageDetails(
    val imageUrl: String? = null,
    val defaultDrawableId: Int? = null,
    val updatedOn: Long? = null,
    var drawableType: DrawableType? = null,
    var image: Any? = null
)
