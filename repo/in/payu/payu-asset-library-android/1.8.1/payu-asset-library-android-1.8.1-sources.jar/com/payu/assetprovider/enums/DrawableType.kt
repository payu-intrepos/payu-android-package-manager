package com.payu.assetprovider.enums

enum class DrawableType {
    Bitmap,
    PictureDrawable
}