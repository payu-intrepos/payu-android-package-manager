package com.payu.assetprovider.completionmanager

import com.payu.assetprovider.BitmapCallback
import com.payu.assetprovider.model.ImageDetails
object CompletionManager {
    private var savedCallbackInfoMap: HashMap<String, ArrayList<BitmapCallback>?> = HashMap()
    fun checkExistingRequestSaveIfNeeded(
        imageDataInfo: ImageDetails,
        bitmapCallback: BitmapCallback?
    ): Boolean {

        var isNewRequest = false
        var list = savedCallbackInfoMap[imageDataInfo.imageUrl!!]

        if (list == null) {
            list = ArrayList()
            isNewRequest = true
        }
        list.add(bitmapCallback!!)

        savedCallbackInfoMap[imageDataInfo.imageUrl] = list
        return isNewRequest
    }

    fun executeAllSaveCallback(
        imageDetails: ImageDetails,
    ) {
        val savedImageDataMap = savedCallbackInfoMap[imageDetails.imageUrl]
        if (savedImageDataMap != null) {
            for (item in savedImageDataMap) {
                item.onBitmapReceived(imageDetails.imageUrl!!, ImageDetails(drawableType = imageDetails.drawableType, image = imageDetails.image))
            }
        }

        //remove all the data for key
        savedCallbackInfoMap.remove(imageDetails.imageUrl)
    }
}