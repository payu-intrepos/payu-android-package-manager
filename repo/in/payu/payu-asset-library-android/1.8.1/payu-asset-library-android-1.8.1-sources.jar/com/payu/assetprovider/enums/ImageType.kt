package com.payu.assetprovider.enums

enum class ImageType {
    SVG,
    JPEG,
    PNG
}