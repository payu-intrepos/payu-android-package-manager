package com.payu.assetprovider

import android.content.Context
import androidx.annotation.Keep
import com.payu.assetprovider.enums.DrawableType
import com.payu.assetprovider.model.ImageDetails

class AssetManager private constructor(var _context: Context) {


    fun get(key: String, callback: BitmapCallback) {
        get(key, R.drawable.payu_placeholder, callback)
    }

    fun get(key: String, defaultDrawableId: Int, callback: BitmapCallback) {
        val bitmap = Utils.getDrawablesForTypes(_context, key, defaultDrawableId)
        callback.onBitmapReceived(key, ImageDetails(drawableType = DrawableType.Bitmap, image =  bitmap))
    }

    fun getBitmapFromURL(
        imageUrl: String?,
        updatedOn: Long,
        defaultDrawableId: Int,
        callback: BitmapCallback
    ) {
        Utils.getBitmapFromURL(
            _context,
            imageUrl,
            updatedOn,
            defaultDrawableId,
            callback
        )
    }

    fun getBitmapFromURL(imageUrl: String, callback: BitmapCallback) {
        Utils.getBitmapFromURL(imageUrl, callback)
    }

    @Keep
    companion object {
        private val INSTANCE: AssetManager? = null

        @Synchronized
        fun getInstance(context: Context): AssetManager {
            return INSTANCE?.let { return INSTANCE }
                ?: run {
                    return AssetManager(context)
                }
        }
    }

}