package com.payu.threedsui

import android.app.Activity
import android.content.Intent
import android.util.Log
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.data.BaseApiLayer
import com.payu.threedsbase.enums.AuthType
import com.payu.threedsui.interfaces.listeners.PayU3DS2PaymentCallback
import com.payu.threedsui.view.activities.AuthSelectionBottomSheet
import com.payu.threedsui.view.activities.AuthSelectionFullScreenDialog
import com.payu.threedsui.view.activities.bottomsheets.DeRegistrationBottomSheet
import com.payu.threedsui.uiCustomisation.UICustomisation
import com.payu.threedsui.interfaces.listeners.PayU3DS2PaymentBaseCallback
import com.payu.threedsui.utils.PayUDialog
import com.payu.threedsui.view.activities.FallbackActivity
import androidx.fragment.app.DialogFragment
import java.lang.ref.WeakReference

object SdkUiInitializer {

    private const val TAG = "SdkUiInitializer"

    private const val AUTH_SELECTION_BOTTOM_SHEET_TAG = "AuthSelectionBottomSheet"
    private const val AUTH_SELECTION_INIT_LOADER_TAG = "${AUTH_SELECTION_BOTTOM_SHEET_TAG}_InitLoader"
    private const val AUTH_SELECTION_FULL_SCREEN_TAG = "AuthSelectionFullScreenDialog"

    var apiLayer: BaseApiLayer? = null

    var paymentCallback: PayU3DS2PaymentBaseCallback? = null

    /** Default false → full-screen loader; set true only where half-screen loader is needed. */
    var useHalfScreenProgressLoader: Boolean = true

    private var payuDialog: PayUDialog? = null
    private var authSelectionInitLoader: AuthSelectionBottomSheet? = null
    /** Tracks auth-selection bottom sheet after init-loader transition or direct show. */
    private var activeAuthSelectionBottomSheet: AuthSelectionBottomSheet? = null
    private var activeAuthSelectionDialog: AuthSelectionFullScreenDialog? = null
    private var hostActivityRef: WeakReference<AppCompatActivity>? = null

    fun startPayment(
        activity: AppCompatActivity,
        apiLayer: BaseApiLayer,
        callback: PayU3DS2PaymentCallback
    ) {
        this.apiLayer = apiLayer
        this.paymentCallback = callback
        PayU3DSUI(activity)
    }

    fun showProgressLoader(
        activity: AppCompatActivity,
        onBackPressed: (() -> Unit)? = null
    ) {
        if (useHalfScreenProgressLoader) {
            showAuthSelectionInitLoader(activity)
        } else {
            dismissAuthSelectionInitLoader()
            showFullScreenProgress(activity, onBackPressed)
        }
    }

    fun hideProgressLoader() {
        val activity = hostActivityRef?.get()
        if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
            activity.runOnUiThread {
                dismissFullScreenProgress()
                dismissAuthSelectionUi()
            }
        } else {
            dismissFullScreenProgress()
            dismissAuthSelectionUi()
        }
    }

    fun updateProgressText(showText: Boolean) {
        if (payuDialog?.isShowing == true) {
            payuDialog?.initializePayment(showText)
        }
    }

    private fun showAuthSelectionInitLoader(activity: AppCompatActivity) {
        if (authSelectionInitLoader != null) return
        hostActivityRef = WeakReference(activity)

        val uiCustomisation = apiLayer?.getUICustomisation() as? UICustomisation
        authSelectionInitLoader = AuthSelectionBottomSheet(
            context = activity,
            logoUrl = null,
            networkUrl = null,
            merchantName = null,
            txnAmount = null,
            fallbackTimeout = null,
            fallbackVisibilityDuration = null,
            autoInvokeBiometricTime = null,
            uICustomisation = uiCustomisation,
            loaderOnlyMode = true,
            onAuthTypeSelected = { _, _, _ -> }
        ).also { sheet ->
            activeAuthSelectionBottomSheet = sheet
            sheet.show(activity.supportFragmentManager, "${sheet.tagName}_InitLoader")
        }
    }

    fun dismissAuthSelectionInitLoader() {
        dismissAuthSelectionUi()
    }

    fun dismissAuthSelectionUi() {
        dismissAuthSelectionFragment(authSelectionInitLoader)
        dismissAuthSelectionFragment(activeAuthSelectionBottomSheet)
        dismissAuthSelectionFragment(activeAuthSelectionDialog)
        dismissAuthSelectionFragmentsByTag()
        authSelectionInitLoader = null
        activeAuthSelectionBottomSheet = null
        activeAuthSelectionDialog = null
    }

    private fun dismissAuthSelectionFragment(fragment: DialogFragment?) {
        if (fragment == null) return
        try {
            if (fragment.isAdded) {
                fragment.dismissAllowingStateLoss()
            }
        } catch (e: Exception) {
            Log.e(TAG, "dismissAuthSelectionFragment error: ${e.message}", e)
        }
    }

    private fun dismissAuthSelectionFragmentsByTag() {
        val activity = hostActivityRef?.get() ?: return
        if (activity.isFinishing || activity.isDestroyed) return
        val fragmentManager = activity.supportFragmentManager
        listOf(
            AUTH_SELECTION_BOTTOM_SHEET_TAG,
            AUTH_SELECTION_INIT_LOADER_TAG,
            AUTH_SELECTION_FULL_SCREEN_TAG
        ).forEach { tag ->
            (fragmentManager.findFragmentByTag(tag) as? DialogFragment)?.let { fragment ->
                try {
                    if (fragment.isAdded) {
                        fragment.dismissAllowingStateLoss()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "dismissAuthSelectionFragmentsByTag error: ${e.message}", e)
                }
            }
        }
    }

    internal fun clearActiveAuthSelectionBottomSheet(sheet: AuthSelectionBottomSheet) {
        if (activeAuthSelectionBottomSheet === sheet) {
            activeAuthSelectionBottomSheet = null
        }
        if (authSelectionInitLoader === sheet) {
            authSelectionInitLoader = null
        }
    }

    internal fun clearActiveAuthSelectionDialog(dialog: AuthSelectionFullScreenDialog) {
        if (activeAuthSelectionDialog === dialog) {
            activeAuthSelectionDialog = null
        }
    }

    fun showOtpFallbackProgress(activity: AppCompatActivity) {
        activity.runOnUiThread {
            useHalfScreenProgressLoader = false
            showProgressLoader(activity)
        }
    }

    fun showAuthNModeSelectionScreen(
        activity: AppCompatActivity,
        logoUrl: String?, networkUrl: String?,
        merchantName: String?,
        txnAmount: String?,
        fallbackTimeout : Int? ,
        fallbackVisibilityDuration : Int?,
        autoInvokeBiometricTime: Double? = null,
        uICustomisation: UICustomisation?,
        enableFullScreen: Boolean = false,
        onAuthTypeSelected: (AuthType, String?, String?) -> Unit
    ) {
        dismissFullScreenProgress()
        apiLayer?.setContext(activity)

        val existingInitLoader = authSelectionInitLoader
        if (existingInitLoader?.dialog?.isShowing == true &&
            existingInitLoader.transitionToAuthSelection(
                logoUrl = logoUrl,
                networkUrl = networkUrl,
                merchantName = merchantName,
                txnAmount = txnAmount,
                fallbackTimeout = fallbackTimeout,
                fallbackVisibilityDuration = fallbackVisibilityDuration,
                autoInvokeBiometricTime = autoInvokeBiometricTime,
                uICustomisation = uICustomisation,
                onAuthTypeSelected = onAuthTypeSelected
            )
        ) {
//            useHalfScreenProgressLoader = true
            activeAuthSelectionBottomSheet = existingInitLoader
            authSelectionInitLoader = null
            return
        }

        dismissAuthSelectionUi()
        if (enableFullScreen) {
            val dialog = AuthSelectionFullScreenDialog(
                activity,
                logoUrl,
                networkUrl,
                merchantName,
                txnAmount,
                fallbackTimeout,
                fallbackVisibilityDuration,
                autoInvokeBiometricTime,
                uICustomisation,
                onAuthTypeSelected
            )
            activeAuthSelectionDialog = dialog
            dialog.show(activity.supportFragmentManager, dialog.tagName)
        } else {
            val bottomSheet = AuthSelectionBottomSheet(
                activity,
                logoUrl,
                networkUrl,
                merchantName,
                txnAmount,
                fallbackTimeout,
                fallbackVisibilityDuration,
                autoInvokeBiometricTime,
                uICustomisation,
                skipInitialLoader = true,
                onAuthTypeSelected = onAuthTypeSelected
            )
            activeAuthSelectionBottomSheet = bottomSheet
            bottomSheet.show(activity.supportFragmentManager, bottomSheet.tagName)
        }
    }

    fun showDeRegisterScreen(
        activity: AppCompatActivity,
        themeConfig: UICustomisation?,
        bankLogo: String?,
        errorCode: Int?,
        errorMsg: String?,
        onProceedAction: () -> Unit
    ) {
        activity.runOnUiThread {
            apiLayer?.setContext(activity)
            // Dismiss transaction-init loader before showing de-register bottom sheet.
            hideProgressLoader()
            SdkUiInitializer.apiLayer?.logDataWithAdditionalKeys(
                LoggingConstants.PAYU_CARDS_DEREGISTER,
                LoggingConstants.BIOMETRIC_AUTO_DEREGISTER_TRIGGERED,
                additionalKeys = mapOf(
                    LoggingConstants.KEY_BIOMETRIC_TYPE to LoggingConstants.BIOMETRIC_TYPE_FINGERPRINT,
                    LoggingConstants.KEY_DISABLE_REASON to errorMsg.orEmpty(),
                    LoggingConstants.ERROR_CODE to errorCode.toString()
                )
            )
            val bottomSheet = DeRegistrationBottomSheet(
                activity,
                themeConfig,
                bankLogo,
                errorCode,
                errorMsg
            ) {
                showOtpFallbackProgress(activity)
                onProceedAction()
            }
            bottomSheet.show(activity.supportFragmentManager, bottomSheet.tagName)
        }
    }

    fun openWebFlow(
        activity: Activity,
        params: Map<String, Any?>,
        apiLayer: BaseApiLayer,
        callback: PayU3DS2PaymentBaseCallback
    ) {
        this.apiLayer = apiLayer
        this.paymentCallback = callback
        val intent = Intent(activity, FallbackActivity::class.java)
        if (params[APIConstants.POST_DATA] != null)
            intent.putExtra(APIConstants.POST_DATA, params[APIConstants.POST_DATA] as String)
        else if (params[APIConstants.ACS_TEMPLATE] != null)
            intent.putExtra(APIConstants.ACS_TEMPLATE, params[APIConstants.ACS_TEMPLATE] as String)
        if (params.containsKey(APIConstants.AUTO_SUBMIT) && params[APIConstants.AUTO_SUBMIT] is Boolean)
            intent.putExtra(APIConstants.AUTO_SUBMIT, params[APIConstants.AUTO_SUBMIT] as Boolean)
        if (params.containsKey(APIConstants.AUTO_READ) && params[APIConstants.AUTO_READ] is Boolean)
            intent.putExtra(APIConstants.AUTO_READ, params[APIConstants.AUTO_READ] as Boolean)
        if (params.containsKey(APIConstants.SURL) && params[APIConstants.SURL] is String)
            intent.putExtra(APIConstants.SURL, params[APIConstants.SURL] as String)
        if (params.containsKey(APIConstants.FURL) && params[APIConstants.FURL] is String)
            intent.putExtra(APIConstants.FURL, params[APIConstants.FURL] as String)
        if (params.containsKey(APIConstants.MERCHANT_RESPONSE_TIMEOUT) && params[APIConstants.MERCHANT_RESPONSE_TIMEOUT] is Int)
            intent.putExtra(APIConstants.MERCHANT_RESPONSE_TIMEOUT, params[APIConstants.MERCHANT_RESPONSE_TIMEOUT] as Int)
        activity.startActivity(intent)
    }

    private fun showFullScreenProgress(
        activity: AppCompatActivity,
        onBackPressed: (() -> Unit)? = null
    ) {
        try {
            if (activity.isFinishing || activity.isDestroyed) return
            hostActivityRef = WeakReference(activity)

            if (payuDialog == null) {
                payuDialog = PayUDialog(activity)
            }
            if (payuDialog?.isShowing != true) {
                payuDialog?.show()
            }
            if (onBackPressed != null) {
                payuDialog?.setOnKeyListener { _, keyCode, event ->
                    if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                        onBackPressed()
                    }
                    true
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "showFullScreenProgress error: ${e.message}")
        }
    }

    private fun dismissFullScreenProgress() {
        try {
            if (payuDialog?.isShowing == true) {
                payuDialog?.dismiss()
            }
        } catch (e: Exception) {
            Log.e(TAG, "dismissFullScreenProgress error: ${e.message}", e)
        } finally {
            payuDialog = null
        }
    }
}
