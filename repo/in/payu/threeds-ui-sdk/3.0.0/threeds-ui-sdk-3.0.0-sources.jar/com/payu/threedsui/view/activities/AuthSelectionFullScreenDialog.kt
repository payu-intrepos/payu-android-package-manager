package com.payu.threedsui.view.activities

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.DialogFragment
import com.payu.threedsbase.enums.AuthType
import com.payu.threedsui.R
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.uiCustomisation.UICustomisation
import com.payu.threedsui.view.activities.authselection.AuthSelectionController

class AuthSelectionFullScreenDialog(
    private val context: Context,
    private val logoUrl: String?,
    private val networkUrl: String?,
    private val merchantName: String?,
    private val txnAmount: String?,
    private val fallbackTimeout: Int?,
    private val fallbackVisibilityDuration: Int?,
    private val autoInvokeBiometricTime: Double?,
    private val uICustomisation: UICustomisation?,
    private val onAuthTypeSelected: (AuthType, String?, String?) -> Unit
) : DialogFragment() {

    val tagName: String = this::class.java.simpleName

    private var controller: AuthSelectionController? = null

    override fun getTheme(): Int = R.style.PayU_Opaque_Screen

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        Dialog(requireContext(), theme).apply {
            setCanceledOnTouchOutside(false)
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(
        R.layout.authentication_or_biometric_selection_default_layout,
        container,
        false
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        isCancelable = false
        applyFullScreenHeader(view)
        controller = createController().also {
            it.bind(view)
            it.attachBackPressHandler(dialog)
        }
    }

    private fun applyFullScreenHeader(view: View) {
        val root = view.findViewById<LinearLayout>(R.id.auth_selection_root)
        root.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            width = ViewGroup.LayoutParams.MATCH_PARENT
            height = ViewGroup.LayoutParams.MATCH_PARENT
        }
        root.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.payu_color_ffffff))

        val headerContainer = view.findViewById<FrameLayout>(R.id.auth_selection_header_container)
        headerContainer.setPadding(0, 0, 0, 0)
        headerContainer.removeAllViews()
        LayoutInflater.from(context).inflate(
            R.layout.auth_selection_header_full_screen,
            headerContainer,
            true
        )

        view.findViewById<View>(R.id.rl_header)?.let { header ->
            header.setBackgroundResource(R.drawable.payu_auth_merchant_strip_full_width_bg)
            val extraPadding = resources.getDimensionPixelSize(R.dimen.payu_dimen_12dp)
            header.setPaddingRelative(
                header.paddingStart + extraPadding,
                header.paddingTop,
                header.paddingEnd + extraPadding,
                header.paddingBottom
            )
        }

        view.findViewById<View>(R.id.auth_selection_middle_container)
            ?.updateLayoutParams<LinearLayout.LayoutParams> {
                height = 0
                weight = 1f
            }

        view.findViewById<View>(R.id.flexible_footer_spacer)
            ?.updateLayoutParams<LinearLayout.LayoutParams> {
                weight = 1f
            }

        view.findViewById<View>(R.id.fp_icon_container)
            ?.updateLayoutParams<LinearLayout.LayoutParams> {
                topMargin += resources.getDimensionPixelSize(R.dimen.payu_dimen_20dp)
            }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    override fun dismiss() {
        controller?.cleanup()
        controller = null
        SdkUiInitializer.clearActiveAuthSelectionDialog(this)
        try {
            super.dismiss()
        } catch (e: Exception) {
            Log.e(TAG, "Error dismissing full screen dialog: ${e.message}", e)
        }
    }

    private fun createController() = AuthSelectionController(
        context = context,
        logoUrl = logoUrl,
        networkUrl = networkUrl,
        merchantName = merchantName,
        txnAmount = txnAmount,
        fallbackTimeout = fallbackTimeout,
        fallbackVisibilityDuration = fallbackVisibilityDuration,
        autoInvokeBiometricTime = autoInvokeBiometricTime,
        uiCustomisation = uICustomisation,
        isBottomSheet = false,
        onAuthTypeSelected = onAuthTypeSelected,
        dismissScreen = { dismiss() },
        isHostShowing = { dialog?.isShowing == true }
    )

    companion object {
        private const val TAG = "AuthSelectionFullScreenDialog"
    }
}
