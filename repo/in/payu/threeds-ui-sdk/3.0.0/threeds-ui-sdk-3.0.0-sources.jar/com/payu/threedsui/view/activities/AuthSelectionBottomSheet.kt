package com.payu.threedsui.view.activities

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.View
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.payu.threedsbase.enums.AuthType
import com.payu.threedsui.R
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.uiCustomisation.UICustomisation
import com.payu.threedsui.view.activities.authselection.AuthSelectionController
import com.payu.threedsui.view.activities.bottomsheets.FixedRoundedCornerBottomSheet

class AuthSelectionBottomSheet(
    private val context: Context,
    private val logoUrl: String?,
    private val networkUrl: String?,
    private val merchantName: String?,
    private val txnAmount: String?,
    private val fallbackTimeout: Int?,
    private val fallbackVisibilityDuration: Int?,
    private val autoInvokeBiometricTime: Double?,
    private val uICustomisation: UICustomisation?,
    private val loaderOnlyMode: Boolean = false,
    private val skipInitialLoader: Boolean = false,
    private val onAuthTypeSelected: (AuthType, String?, String?) -> Unit
) : FixedRoundedCornerBottomSheet() {

    val tagName: String = this::class.java.simpleName

    private var controller: AuthSelectionController? = null
    private var rootView: View? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rootView = view
        (dialog as? BottomSheetDialog)?.behavior?.apply {
            skipCollapsed = true
            setFitToContents(true)
            state = BottomSheetBehavior.STATE_EXPANDED
        }
        controller = createController().also {
            it.bind(view)
            it.attachBackPressHandler(dialog)
        }
    }

    override fun getTheme(): Int = R.style.PayU_AuthSelectionBottomSheetDialog

    override fun getLayoutId(): Int = R.layout.authentication_or_biometric_selection_default_layout

    override fun dismiss() {
        controller?.cleanup()
        controller = null
        rootView = null
        SdkUiInitializer.clearActiveAuthSelectionBottomSheet(this)
        try {
            super.dismissAllowingStateLoss()
        } catch (e: Exception) {
            Log.e(TAG, "Error dismissing bottom sheet: ${e.message}", e)
        }
    }

    fun transitionToAuthSelection(
        logoUrl: String?,
        networkUrl: String?,
        merchantName: String?,
        txnAmount: String?,
        fallbackTimeout: Int?,
        fallbackVisibilityDuration: Int?,
        autoInvokeBiometricTime: Double?,
        uICustomisation: UICustomisation?,
        onAuthTypeSelected: (AuthType, String?, String?) -> Unit
    ): Boolean {
        val view = rootView ?: return false
        val activeController = controller ?: return false
        activeController.transitionFromLoaderToAuth(
            view = view,
            logoUrl = logoUrl,
            networkUrl = networkUrl,
            merchantName = merchantName,
            txnAmount = txnAmount,
            fallbackTimeout = fallbackTimeout,
            fallbackVisibilityDuration = fallbackVisibilityDuration,
            autoInvokeBiometricTime = autoInvokeBiometricTime,
            uiCustomisation = uICustomisation,
            onAuthTypeSelected = onAuthTypeSelected
        )
        return true
    }

    private fun createController() = AuthSelectionController(
        context = context,
        logoUrl = logoUrl,
        networkUrl = networkUrl,
        merchantName = merchantName,
        txnAmount = txnAmount,
        fallbackTimeout = fallbackTimeout,
        fallbackVisibilityDuration = fallbackVisibilityDuration,
        autoInvokeBiometricTime = autoInvokeBiometricTime,
        uiCustomisation = uICustomisation,
        isBottomSheet = true,
        loaderOnlyMode = loaderOnlyMode,
        skipInitialLoader = skipInitialLoader,
        onAuthTypeSelected = onAuthTypeSelected,
        dismissScreen = { dismiss() },
        isHostShowing = { dialog?.isShowing == true }
    )

    companion object {
        private const val TAG = "AuthSelectionBottomSheet"
    }
}
