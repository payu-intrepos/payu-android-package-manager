package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.tridentity.TextCustomization

class UICustomisation(builder: Builder) {
    var buttonCustomisation: ButtonCustomisation? = null
        private set
    var labelCustomisation: LabelCustomisation? = null
        private set
    var textBoxCustomisation: TextBoxCustomisation? = null
        private set
    var toolbarCustomisation: ToolbarCustomisation? = null
        private set
    var bottomSheetCustomisation: BottomSheetCustomisation? = null
        private set
    var fontFamilyCustomisation: FontFamilyCustomisation? = null
        private set
    var textCustomization: TextCustomization? = null
        private set

    init {
        this.buttonCustomisation = builder.buttonCustomisation
        this.labelCustomisation = builder.labelCustomisation
        this.textBoxCustomisation = builder.textBoxCustomisation
        this.toolbarCustomisation = builder.toolbarCustomisation
        this.bottomSheetCustomisation = builder.bottomSheetCustomisation
        this.fontFamilyCustomisation = builder.fontFamilyCustomisation
        this.textCustomization = builder.textCustomization
    }

    class Builder {
        internal var buttonCustomisation: ButtonCustomisation? = null
        internal var labelCustomisation: LabelCustomisation? = null
        internal var textBoxCustomisation: TextBoxCustomisation? = null
        internal var toolbarCustomisation: ToolbarCustomisation? = null
        internal var bottomSheetCustomisation: BottomSheetCustomisation? = null
        internal var fontFamilyCustomisation: FontFamilyCustomisation? = null
        internal var textCustomization: TextCustomization? = null

        fun setButtonCustomisation(buttonCustomisation: ButtonCustomisation?): Builder {
            this.buttonCustomisation = buttonCustomisation
            return this
        }

        fun setLabelCustomisation(labelCustomisation: LabelCustomisation?): Builder {
            this.labelCustomisation = labelCustomisation
            return this
        }

        fun setTextBoxCustomisation(textBoxCustomisation: TextBoxCustomisation?): Builder {
            this.textBoxCustomisation = textBoxCustomisation
            return this
        }

        fun setToolbarCustomisation(toolbarCustomisation: ToolbarCustomisation?): Builder {
            this.toolbarCustomisation = toolbarCustomisation
            return this
        }

        fun setBottomSheetCustomisation(bottomSheetCustomisation: BottomSheetCustomisation?): Builder {
            this.bottomSheetCustomisation = bottomSheetCustomisation
            return this
        }

        fun setFontFamilyCustomisation(fontFamilyCustomisation: FontFamilyCustomisation?): Builder {
            this.fontFamilyCustomisation = fontFamilyCustomisation
            return this
        }

        fun setTextCustomization(textCustomization: TextCustomization?): Builder {
            this.textCustomization = textCustomization
            return this
        }

        fun build(): UICustomisation {
            return UICustomisation(this)
        }
    }
}