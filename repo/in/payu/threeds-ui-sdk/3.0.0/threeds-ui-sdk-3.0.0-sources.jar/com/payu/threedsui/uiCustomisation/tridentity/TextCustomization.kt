package com.payu.threedsui.uiCustomisation.tridentity

class TextCustomization private constructor(builder: Builder) {

    val bottomSheetAuthenticationPopupConfiguration: BottomSheetAuthenticationPopupConfiguration? =
        builder.bottomSheetAuthenticationPopupConfiguration
    val bottomSheetFailureScreenConfiguration: BottomSheetFailureScreenConfiguration? =
        builder.bottomSheetFailureScreenConfiguration
    val bottomSheetPermissionPopupConfiguration: BottomSheetPermissionPopupConfiguration? =
        builder.bottomSheetPermissionPopupConfiguration
    val bottomSheetRegistrationSuccessfulPopupConfiguration: BottomSheetRegistrationSuccessfulPopupConfiguration? =
        builder.bottomSheetRegistrationSuccessfulPopupConfiguration
    val bottomSheetSimBindingProcessingPopupConfiguration: BottomSheetSimBindingProcessingPopupConfiguration? =
        builder.bottomSheetSimBindingProcessingPopupConfiguration

    class Builder {
        internal var bottomSheetAuthenticationPopupConfiguration: BottomSheetAuthenticationPopupConfiguration? = null
        internal var bottomSheetFailureScreenConfiguration: BottomSheetFailureScreenConfiguration? = null
        internal var bottomSheetPermissionPopupConfiguration: BottomSheetPermissionPopupConfiguration? = null
        internal var bottomSheetRegistrationSuccessfulPopupConfiguration: BottomSheetRegistrationSuccessfulPopupConfiguration? = null
        internal var bottomSheetSimBindingProcessingPopupConfiguration: BottomSheetSimBindingProcessingPopupConfiguration? = null

        fun setBottomSheetAuthenticationPopupConfiguration(
            config: BottomSheetAuthenticationPopupConfiguration?
        ) = apply { bottomSheetAuthenticationPopupConfiguration = config }

        fun setBottomSheetFailureScreenConfiguration(
            config: BottomSheetFailureScreenConfiguration?
        ) = apply { bottomSheetFailureScreenConfiguration = config }

        fun setBottomSheetPermissionPopupConfiguration(
            config: BottomSheetPermissionPopupConfiguration?
        ) = apply { bottomSheetPermissionPopupConfiguration = config }

        fun setBottomSheetRegistrationSuccessfulPopupConfiguration(
            config: BottomSheetRegistrationSuccessfulPopupConfiguration?
        ) = apply { bottomSheetRegistrationSuccessfulPopupConfiguration = config }

        fun setBottomSheetSimBindingProcessingPopupConfiguration(
            config: BottomSheetSimBindingProcessingPopupConfiguration?
        ) = apply { bottomSheetSimBindingProcessingPopupConfiguration = config }

        fun build(): TextCustomization {
            return TextCustomization(this)
        }
    }
}