package com.payu.threedsui

import android.app.Application
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModelProvider
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.data.CardData
import com.payu.threedsbase.enums.APICommand
import com.payu.threedsbase.enums.CardScheme
import com.payu.threedsui.constants.UIConstant
import com.payu.threedsui.constants.UIConstant.Companion.DOUBLE_CLICK_TIME_INTERVAL
import com.payu.threedsui.constants.UIConstant.Companion.DOUBLE_CLICK_TO_EXIT
import com.payu.threedsui.view.activities.FallbackActivity
import com.payu.threedsui.viewmodel.PayU3DS2ViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import com.payu.threedsbase.constants.LoggingConstants


//TODO : This logic has to re-analyzed
class SingleVMOwner : ViewModelStoreOwner {
    private val store = ViewModelStore()
    override fun getViewModelStore(): ViewModelStore = store

    fun clear() {
        store.clear() // clears only this store’s ViewModels
    }
}


class PayU3DS2VMFactory(
    private val application: Application,
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PayU3DS2ViewModel::class.java)) {
            return PayU3DS2ViewModel(application = application) as T
        }
        throw IllegalArgumentException("Unknown VM: ${modelClass.name}")
    }
}

class PayU3DSUI(activity: AppCompatActivity) {
    private var payU3DS2ViewModel: PayU3DS2ViewModel? = null
    private var activity: AppCompatActivity? = null
    private var doubleBackPressToExitPressedOnce = false

    private val TAG = "PayU3DSUI"

    init {
        this.activity = activity
        activity.lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                owner.lifecycle.removeObserver(this)
                // Avoid WindowLeaked: progress may still be showing if destroy beats hideProgressDialog.
                try {
                    SdkUiInitializer.hideProgressLoader()
                } catch (e: Exception) {
                    Log.d(TAG, "onDestroy dismiss progress: ${e.message}")
                }
                this@PayU3DSUI.activity = null
            }
        })
        initViewModel()
        activity.runOnUiThread {
            SdkUiInitializer.showProgressLoader(activity)
        }

        activity.runOnUiThread {
            registerObserver()
        }
    }

    private fun initViewModel() {
        activity?.application?.let {
            SdkUiInitializer.apiLayer?.setContext(activity!!)
            val vmOwner = SingleVMOwner()
            val factory = PayU3DS2VMFactory(it)
            payU3DS2ViewModel = ViewModelProvider(vmOwner, factory)[PayU3DS2ViewModel::class.java]
            payU3DS2ViewModel?.getBinInfoData(APICommand.BinInfo)
        }
    }

    private fun registerObserver() {
        payU3DS2ViewModel?.binInfoResponse?.observe(activity as LifecycleOwner) {
            if (it != null)
                when (it.cardType) {
                    UIConstant.MASTERCARD -> {
                        payU3DS2ViewModel?.getDeviceDetails(
                            activity!!,
                            CardData(CardScheme.MASTERCARD, it.messageVersion)
                        )
                    }

                    UIConstant.VISA -> {
                        payU3DS2ViewModel?.getDeviceDetails(
                            activity!!,
                            CardData(CardScheme.VISA, it.messageVersion)
                        )
                    }

                    else -> payU3DS2ViewModel?.schemeNotSupportedError()
                }
        }

        payU3DS2ViewModel?.deviceDetails?.observe(activity as LifecycleOwner) {
            if (it != null) {
                payU3DS2ViewModel?.updatePaymentParamWithPArqAndSDKData(it)
            }
        }

        payU3DS2ViewModel?.paymentParamUpdated?.observe(activity as LifecycleOwner) {
            if (it != null) {
                payU3DS2ViewModel?.initiatePayment(APICommand.InitiatePayment)
            }
        }

        payU3DS2ViewModel?.fallbackFlow?.observe(activity as LifecycleOwner) {
            if (it != null) payU3DS2ViewModel?.generateFallbackData()
        }

        payU3DS2ViewModel?.showProgressDialog?.observe(activity as LifecycleOwner) {
            Log.d("PayU3DSUI", "onSuccess showProgressDialog " + it)
            if (it != null)
                if (it)
                    showProgressDialog()
                else
                    hideProgressDialog()
        }

        payU3DS2ViewModel?.showProgressDialogInfoText?.observe(activity as LifecycleOwner) {
            Log.d("PayU3DSUI", "onSuccess showProgressDialogInfoText " + it)
            if (it == true) {
                SdkUiInitializer.updateProgressText(false)
            }
        }

        payU3DS2ViewModel?.showChallenge?.observe(activity as LifecycleOwner) { response ->
            if (response != null) {
                payU3DS2ViewModel?.initiateChallenge()
            }
        }

        payU3DS2ViewModel?.postData?.observe(activity as LifecycleOwner) {
            if (it != null) {
                SdkUiInitializer.apiLayer?.logData(
                    LoggingConstants.PAYU_CARDS_WEB_FALLBACK,
                    LoggingConstants.EVENT_VALUE_INIT_PARAMS
                )
                val intent = Intent(activity, FallbackActivity::class.java)
                intent.putExtra(APIConstants.POST_DATA, it)
                activity!!.startActivity(intent)
            }
        }

        payU3DS2ViewModel?.initiateAuthentication?.observe(activity as LifecycleOwner) {
            if (it != null) payU3DS2ViewModel?.authenticatePayment(APICommand.AuthenticatePayment)
        }

        payU3DS2ViewModel?.initiateAuthorization?.observe(activity as LifecycleOwner) {
            if (it != null) payU3DS2ViewModel?.authorizePayment(APICommand.AuthorizePayment)
        }
    }

    private fun showProgressDialog() {
        try {
            val currentActivity = activity ?: return
            if (currentActivity.isFinishing || currentActivity.isDestroyed) {
                return
            }

            SdkUiInitializer.showProgressLoader(currentActivity) {
                if (doubleBackPressToExitPressedOnce) {
                    payU3DS2ViewModel = null
                    SdkUiInitializer.hideProgressLoader()
                } else {
                    doubleBackPressToExitPressedOnce = true
                    Toast.makeText(activity, DOUBLE_CLICK_TO_EXIT, Toast.LENGTH_SHORT).show()
                    Handler(Looper.getMainLooper()).postDelayed({
                        doubleBackPressToExitPressedOnce = false
                    }, DOUBLE_CLICK_TIME_INTERVAL)
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "showProgressDialog error: ${e.message}")
        }
    }

    private fun hideProgressDialog() {
        try {
            SdkUiInitializer.hideProgressLoader()
        } catch (e: Exception) {
            Log.e(TAG, "Error dismissing progress dialog: ${e.message}", e)
        }
    }


}
