package com.payu.threedsui.utils

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.inputmethod.InputMethodManager
import android.graphics.drawable.Drawable
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.appcompat.widget.AppCompatImageView
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.updateLayoutParams
import com.payu.threedsui.R
import com.payu.threedsui.uiCustomisation.ButtonCustomisation
import com.payu.threedsui.uiCustomisation.LabelCustomisation
import com.payu.threedsui.uiCustomisation.enums.ButtonTextCaseType
import kotlin.math.roundToInt


object UIUtils {
    // Compile pattern once for reuse
    private val COLOR_PATTERN = Regex("#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})")
    
    // Default stroke width in pixels
    private const val DEFAULT_STROKE_WIDTH = 3
    private const val MAX_ALPHA = 255
    private var elapsedLastClickTime: Long = 0

    internal fun getAlertDialog(
        activity: Context?,
        onClickDialog: DialogInterface.OnClickListener?,
        positiveText: String?,
        negativeText: String?,
        title: String?,
        message: String?,
        neutralText: String? = null
        ): AlertDialog.Builder {
        val alertBox =
            AlertDialog.Builder(activity, R.style.PayU_3DS1_Cancel_Dialog)
        if (onClickDialog != null) {
            if (title != null) alertBox.setTitle(title)
            if (message != null) alertBox.setMessage(message)
            if (positiveText != null) alertBox.setPositiveButton(positiveText, onClickDialog)
            if (negativeText != null) alertBox.setNegativeButton(negativeText, onClickDialog)
            if (neutralText != null) alertBox.setNeutralButton(neutralText, onClickDialog)
        }
        return alertBox
    }

    internal fun hideKeyboard(activity: Activity) {
        val imm: InputMethodManager =
            activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        // Find the currently focused view, or create a new one to grab a window token from it
        val view: View = activity.currentFocus ?: View(activity)
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    internal fun isInternetAvailable(context: Context): Boolean {
        var result = false

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            result = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_WIFI -> true
                        ConnectivityManager.TYPE_MOBILE -> true
                        ConnectivityManager.TYPE_ETHERNET -> true
                        else -> false
                    }

                }
            }
        }

        return result
    }

    internal fun updateStrokeColor(context: Context, view: View, colorRes: Int) {
        applyStrokeToBackground(view, ContextCompat.getColor(context, colorRes))
    }

    internal fun updateStrokeColor(view: View, color: String) {
        applyStrokeToBackground(view, Color.parseColor(color), getAlphaTxtColor(color))
    }

    private fun applyStrokeToBackground(view: View, strokeColor: Int, fillColor: Int? = null, strokeWidth: Int = DEFAULT_STROKE_WIDTH
    ) {
        (view.background as? GradientDrawable)?.apply {
            mutate()
            setStroke(strokeWidth, strokeColor)
            fillColor?.let { setColor(it) }
        }
    }

    internal fun generateTransparentColor(context: Context, colorRes: Int, alpha: Double?): Int {
        return applyAlphaToColor(ContextCompat.getColor(context, colorRes), alpha)
    }

    internal fun generateTransparentColor(color: String, alpha: Double?): Int {
        return applyAlphaToColor(Color.parseColor(color), alpha)
    }

    private fun applyAlphaToColor(color: Int, alpha: Double?): Int {
        val colorAlpha = alpha?.times(MAX_ALPHA)?.roundToInt() ?: MAX_ALPHA
        return ColorUtils.setAlphaComponent(color, colorAlpha)
    }

    internal fun updateTextColor(view: TextView, color: String) {
        if (!view.text.isNullOrEmpty()) {
            view.setTextColor( Color.parseColor(color))
        }
    }

    fun updateBackgroundColor(view: View, color: String) {
        view.background?.let { drawable ->
            DrawableCompat.wrap(drawable).apply {
                mutate()
                DrawableCompat.setTint(this, Color.parseColor(color))
            }
        }
    }

    internal fun dpToPx(context: Context, dp: Int): Float =
        dp * context.resources.displayMetrics.density

    /**
     * Light tinted merchant strip — matches OTP challenge screen (#1A + button bg color).
     */
    internal fun applyMerchantStripStyle(
        merchantStrip: View,
        buttonBackgroundColor: String,
        showBorder: Boolean = true,
        cornerRadiusDp: Int = 8
    ) {
        if (!isValidColorCode(buttonBackgroundColor)) return
        val colorHex = buttonBackgroundColor.removePrefix("#")
        val context = merchantStrip.context
        val cornerRadiusPx = dpToPx(context, cornerRadiusDp)
        val strokeWidthPx = dpToPx(context, 1).roundToInt().coerceAtLeast(1)

        merchantStrip.background = GradientDrawable().apply {
            setColor(Color.parseColor("#1A$colorHex"))
            cornerRadius = if (showBorder) cornerRadiusPx else 0f
            if (showBorder) {
                setStroke(
                    strokeWidthPx,
                    ContextCompat.getColor(context, R.color.payu_color_E0E1E2)
                )
            }
        }
    }

    internal fun applyProgressButtonStyle(
        container: View,
        fillView: View?,
        buttonConfig: ButtonCustomisation
    ) {
        val bgColor = buttonConfig.backgroundColor?.takeIf { isValidColorCode(it) } ?: return
        val parsedColor = Color.parseColor(bgColor)
        val cornerRadiusPx = buttonConfig.cornerRadius?.let { dpToPx(container.context, it) }
            ?: dpToPx(container.context, 8)

        container.background = GradientDrawable().apply {
            setColor(ColorUtils.setAlphaComponent(parsedColor, 128))
            cornerRadius = cornerRadiusPx
        }
        fillView?.background = GradientDrawable().apply {
            setColor(parsedColor)
            cornerRadius = cornerRadiusPx
        }
    }

    internal fun applyButtonTextStyle(
        buttonText: TextView,
        buttonConfig: ButtonCustomisation
    ) {
        buttonConfig.textFontColor?.takeIf { isValidColorCode(it) }?.let { color ->
            buttonText.setTextColor(Color.parseColor(color))
        }
        buttonConfig.textFontSize?.let { buttonText.textSize = it.toFloat() }
        buttonConfig.textCaseType?.let { setTextTransform(buttonText, it) }
    }

    internal fun applyLabelHeadingStyle(vararg textViews: TextView, labelConfig: LabelCustomisation) {
        labelConfig.headingTextColor?.takeIf { isValidColorCode(it) }?.let { color ->
            val parsedColor = Color.parseColor(color)
            textViews.forEach { it.setTextColor(parsedColor) }
        }
        labelConfig.headingTextFontSize?.let { size ->
            textViews.forEach { it.textSize = size.toFloat() }
        }
    }

    internal fun applyLabelTextStyle(vararg textViews: TextView, labelConfig: LabelCustomisation) {
        labelConfig.textColor?.takeIf { isValidColorCode(it) }?.let { color ->
            val parsedColor = Color.parseColor(color)
            textViews.forEach { it.setTextColor(parsedColor) }
        }
        labelConfig.textFontSize?.let { size ->
            textViews.forEach { it.textSize = size.toFloat() }
        }
    }

    internal fun applyImageTint(imageView: ImageView, color: String) {
        if (!isValidColorCode(color)) return
        imageView.imageTintList = ColorStateList.valueOf(Color.parseColor(color))
    }

    fun animateFillWidth(
        fillView: View,
        durationMs: Long,
        fromWidth: Int = 0
    ): ValueAnimator? {
        val parentWidth = (fillView.parent as? View)?.width ?: return null
        if (parentWidth <= 0) return null

        val startWidth = fromWidth.coerceIn(0, parentWidth)
        fillView.updateLayoutParams<ViewGroup.LayoutParams> { width = startWidth }

        return ValueAnimator.ofInt(startWidth, parentWidth).apply {
            duration = durationMs
            interpolator = LinearInterpolator()
            addUpdateListener { animator ->
                fillView.updateLayoutParams<ViewGroup.LayoutParams> { width = animator.animatedValue as Int }
            }
            start()
        }
    }

    fun getCountDownTimer(
        timeout: Long,
        interval: Long? = null,
        onFinish: () -> Unit,
        onInterval: ((millisUntilFinished: Long) -> Unit)? = null
    ): CountDownTimer {
        return object : CountDownTimer(timeout, interval ?: timeout) {
            override fun onTick(millisUntilFinished: Long) {
                onInterval?.invoke(millisUntilFinished)
            }

            override fun onFinish() {
                onFinish.invoke()
            }
        }
    }

    /**
     * Loads an image from URL asynchronously without blocking the main thread.
     * Uses coroutines instead of deprecated AsyncTask.
     */
    fun ImageView.loadImageUrl(url: String?, @DrawableRes placeholder: Int? = null) {
        placeholder?.let { setImageResource(placeholder) }
        if(url.isNullOrEmpty().not()) {
            val result = FetchImageFromURLTask().execute(url).get()
            result?.let {
                setImageBitmap(it)
            }
        }
    }

    private fun getAlphaTxtColor(color: String): Int {
        return ColorUtils.setAlphaComponent(Color.parseColor(color), 50)
    }

    fun isValidColorCode(colorCode: String?): Boolean {
        return colorCode?.let { COLOR_PATTERN.matches(it) } ?: false
    }
    fun typeface(context: Context, fontPath: String?): Typeface? {
        if (fontPath.isNullOrEmpty()) return null
        return try {
            Typeface.createFromAsset(
                context.assets,
                fontPath.replace("assets/", "")
            )
        } catch (e: Exception) {
            null
        }
    }
    
    fun isDarkColor(color: Int): Boolean {
        return ColorUtils.calculateLuminance(color) < 0.5
    }

    fun setTextTransform(button: Button, buttonTextCaseType: ButtonTextCaseType) {
        button.text = applyTextTransform(button.text?.toString(), buttonTextCaseType)
    }

    fun setTextTransform(textView: TextView, buttonTextCaseType: ButtonTextCaseType) {
        textView.text = applyTextTransform(textView.text?.toString(), buttonTextCaseType)
    }

    private fun applyTextTransform(text: String?, transformType: ButtonTextCaseType): String {
        if (text.isNullOrEmpty()) return text.orEmpty()

        return when (transformType) {
            ButtonTextCaseType.UPPER_CASE -> text.uppercase()
            // Note: LOWER_CASE applies Title Case (first letter uppercase, rest lowercase)
            ButtonTextCaseType.LOWER_CASE -> text.lowercase().replaceFirstChar { it.uppercaseChar() }
        }
    }


    fun isSafeOnClickListener(timeToCompare: Long = 1000): Boolean {
        if ((System.currentTimeMillis() - elapsedLastClickTime) < timeToCompare) {
            return false
        }
        elapsedLastClickTime = System.currentTimeMillis()
        return true
    }

    internal fun startProcessingDotsAnimation(
        handler: Handler,
        textView: TextView,
        baseText: String,
        intervalMs: Long = 500L
    ): Runnable {
        val runnable = object : Runnable {
            private var dotCount = 0

            override fun run() {
                dotCount = (dotCount + 1) % 4
                val fullText = "$baseText..."
                val spannable = SpannableString(fullText)
                spannable.setSpan(
                    ForegroundColorSpan(Color.TRANSPARENT),
                    baseText.length + dotCount,
                    fullText.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                textView.text = spannable
                handler.postDelayed(this, intervalMs)
            }
        }
        handler.post(runnable)
        return runnable
    }

    internal fun AppCompatImageView.applyLoopingAnimatedVectorDrawable(@DrawableRes avdResId: Int) {
        val animated = AnimatedVectorDrawableCompat.create(context, avdResId)
        animated?.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                post { animated.start() }
            }
        })
        setImageDrawable(animated)
        animated?.start()
    }
}