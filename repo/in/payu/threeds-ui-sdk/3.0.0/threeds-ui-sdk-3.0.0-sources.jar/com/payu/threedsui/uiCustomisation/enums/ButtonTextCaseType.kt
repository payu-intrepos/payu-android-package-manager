package com.payu.threedsui.uiCustomisation.enums

enum class ButtonTextCaseType {
    LOWER_CASE,
    UPPER_CASE
}