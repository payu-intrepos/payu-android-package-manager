package com.payu.threedsui.constants

import androidx.annotation.Keep

@Keep
class UIConstant {
    @Keep
    companion object {
        const val MASTERCARD = "MAST"
        const val VISA = "VISA"
        const val JAVASCRIPT = "javascript"
        const val DOUBLE_CLICK_TO_EXIT = "Please click BACK again to exit"
        const val DOUBLE_CLICK_TIME_INTERVAL = 2000L
        const val AUTH_SELECTION_TIMEOUT = 30 * 1000L
        const val AUTH_SELECTION_LOADER_DURATION_MS = 2000L
        const val DE_REGISTERED_CONFIRMATION_TIMEOUT = 5 * 1000L
    }
}