package com.payu.threedsui.uiCustomisation.tridentity

class BottomSheetAuthenticationPopupConfiguration private constructor(builder: Builder) {

    val declineButtonText: String? = builder.declineButtonText
    val headerTextForContents: String? = builder.headerTextForContents
    val subTextForContents: String? = builder.subTextForContents
    val swipeToPayButtonText: String? = builder.swipeToPayButtonText
    val topHeaderText: String? = builder.topHeaderText
    val topSubHeaderText: String? = builder.topSubHeaderText

    class Builder {
        internal var declineButtonText: String? = null
        internal var headerTextForContents: String? = null
        internal var subTextForContents: String? = null
        internal var swipeToPayButtonText: String? = null
        internal var topHeaderText: String? = null
        internal var topSubHeaderText: String? = null

        fun setDeclineButtonText(declineButtonText: String?) = apply { this.declineButtonText = declineButtonText }
        fun setHeaderTextForContents(headerTextForContents: String?) = apply { this.headerTextForContents = headerTextForContents }
        fun setSubTextForContents(subTextForContents: String?) = apply { this.subTextForContents = subTextForContents }
        fun setSwipeToPayButtonText(swipeToPayButtonText: String?) = apply { this.swipeToPayButtonText = swipeToPayButtonText }
        fun setTopHeaderText(topHeaderText: String?) = apply { this.topHeaderText = topHeaderText }
        fun setTopSubHeaderText(topSubHeaderText: String?) = apply { this.topSubHeaderText = topSubHeaderText }

        fun build(): BottomSheetAuthenticationPopupConfiguration {
            return BottomSheetAuthenticationPopupConfiguration(this)
        }
    }
}