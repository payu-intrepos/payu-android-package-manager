package com.payu.threedsui.view.activities.authselection

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageView
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_AUTH_REASON
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_AUTH_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_MERCHANT_NAME
import com.payu.threedsbase.constants.APIConstants.Companion.RBA_TXN_AMOUNT
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.enums.AuthType
import com.payu.threedsbase.enums.PayUCurrency
import com.payu.threedsui.R
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.constants.UIConstant.Companion.AUTH_SELECTION_LOADER_DURATION_MS
import com.payu.threedsui.constants.UIConstant.Companion.AUTH_SELECTION_TIMEOUT
import com.payu.threedsui.uiCustomisation.UICustomisation
import androidx.appcompat.app.AppCompatActivity
import com.payu.threedsui.utils.UIUtils
import com.payu.threedsui.utils.UIUtils.applyLoopingAnimatedVectorDrawable
import com.payu.threedsui.utils.UIUtils.loadImageUrl
import org.json.JSONObject
import androidx.core.graphics.toColorInt

class AuthSelectionController(
    private val context: Context,
    logoUrl: String?,
    networkUrl: String?,
    merchantName: String?,
    txnAmount: String?,
    fallbackTimeout: Int?,
    fallbackVisibilityDuration: Int?,
    autoInvokeBiometricTime: Double?,
    uiCustomisation: UICustomisation?,
    private val isBottomSheet: Boolean = true,
    private val loaderOnlyMode: Boolean = false,
    private val skipInitialLoader: Boolean = false,
    onAuthTypeSelected: (AuthType, String?, String?) -> Unit,
    private val dismissScreen: () -> Unit,
    private val isHostShowing: () -> Boolean,
) {

    private var logoUrl: String? = logoUrl
    private var networkUrl: String? = networkUrl
    private var merchantName: String? = merchantName
    private var txnAmount: String? = txnAmount
    private var fallbackTimeout: Int? = fallbackTimeout
    private var fallbackVisibilityDuration: Int? = fallbackVisibilityDuration
    private var autoInvokeBiometricTime: Double? = autoInvokeBiometricTime
    private var uiCustomisation: UICustomisation? = uiCustomisation
    private var authTypeSelectedListener: (AuthType, String?, String?) -> Unit = onAuthTypeSelected

    private var tvAutoRedirect: TextView? = null
    private var redirectTimer: CountDownTimer? = null
    private var fallbackOTPUIViewTimer: CountDownTimer? = null
    private var autoInvokeBiometricTimer: CountDownTimer? = null
    private var fillAnimator: ValueAnimator? = null
    private var btnFillView: View? = null
    private var alertDialog: AlertDialog? = null
    private var transactionTimeoutEndTimeMs: Long = 0L
    private var showTransactionTimeoutUi: Boolean = false
    private var hasTransactionTimeoutExpired: Boolean = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var loaderRevealRunnable: Runnable? = null
    private var loaderTextAnimationRunnable: Runnable? = null
    private var canShowExitConfirmation = false
    private var pauseAutoInvokeAction: (() -> Unit)? = null

    fun bind(view: View) {
        createExitConfirmationDialog()
        setupBackButton(view)

        if (!isBottomSheet) {
            view.findViewById<View>(R.id.auth_selection_loader_container)?.visibility = View.GONE
            view.findViewById<View>(R.id.auth_selection_header_container)?.visibility = View.VISIBLE
            view.findViewById<View>(R.id.auth_selection_content_container)?.visibility = View.VISIBLE
            bindAuthSelectionContent(view, startTimers = true)
            canShowExitConfirmation = true
            return
        }

        if (loaderOnlyMode) {
            setupLoader(view)
            return
        }

        bindAuthSelectionContent(view, startTimers = false)
        if (skipInitialLoader) {
            revealAuthSelectionContent(view)
        } else {
            setupLoader(view)
            loaderRevealRunnable = Runnable { revealAuthSelectionContent(view) }
            mainHandler.postDelayed(loaderRevealRunnable!!, AUTH_SELECTION_LOADER_DURATION_MS)
        }
    }

    private fun setupLoader(view: View) {
        applyLoaderGradientBackground(view)
        view.findViewById<View>(R.id.auth_selection_header_container)?.visibility = View.INVISIBLE
        view.findViewById<View>(R.id.auth_selection_loader_container)?.visibility = View.VISIBLE
        view.findViewById<View>(R.id.auth_selection_content_container)?.visibility = View.GONE
        view.findViewById<View>(R.id.lbl_use_otp_layout)?.visibility = View.INVISIBLE

        view.findViewById<AppCompatImageView>(R.id.payu_progress_loader)
            ?.applyLoopingAnimatedVectorDrawable(R.drawable.payu_threeds_payu_logo)

        val loaderTitle = view.findViewById<TextView>(R.id.dialog_title_txt) ?: return
        val baseText = context.getString(R.string.threeds_payu_processing).trimEnd('.')
        loaderTextAnimationRunnable = UIUtils.startProcessingDotsAnimation(
            mainHandler,
            loaderTitle,
            baseText
        )
    }

    private fun revealAuthSelectionContent(view: View) {
        stopLoaderAnimation()
        clearLoaderGradientBackground(view)
        view.findViewById<View>(R.id.auth_selection_header_container)?.visibility = View.VISIBLE
        view.findViewById<View>(R.id.auth_selection_loader_container)?.visibility = View.GONE
        view.findViewById<View>(R.id.auth_selection_content_container)?.visibility = View.VISIBLE
        canShowExitConfirmation = true
        startAuthSelectionTimers(view)
    }

    fun transitionFromLoaderToAuth(
        view: View,
        logoUrl: String?,
        networkUrl: String?,
        merchantName: String?,
        txnAmount: String?,
        fallbackTimeout: Int?,
        fallbackVisibilityDuration: Int?,
        autoInvokeBiometricTime: Double?,
        uiCustomisation: UICustomisation?,
        onAuthTypeSelected: (AuthType, String?, String?) -> Unit
    ) {
        this.logoUrl = logoUrl
        this.networkUrl = networkUrl
        this.merchantName = merchantName
        this.txnAmount = txnAmount
        this.fallbackTimeout = fallbackTimeout
        this.fallbackVisibilityDuration = fallbackVisibilityDuration
        this.autoInvokeBiometricTime = autoInvokeBiometricTime
        this.uiCustomisation = uiCustomisation
        this.authTypeSelectedListener = onAuthTypeSelected
        bindAuthSelectionContent(view, startTimers = false)
        revealAuthSelectionContent(view)
    }

    private fun bindAuthSelectionContent(view: View, startTimers: Boolean) {
        val ivBankLogo: ImageView = view.findViewById(R.id.ivBankIcon)
        val ivNetworkLogo: ImageView = view.findViewById(R.id.ivNetworkIcon)
        val tvMerchantName: TextView = view.findViewById(R.id.tv_merchant_name)
        val tvTxnAmount: TextView = view.findViewById(R.id.tv_amount)
        val tvPayingTo: TextView = view.findViewById(R.id.lbl_paying_to)
        val btnContainer: View = view.findViewById(R.id.btn_fingerprint_container)
        val btnUseFingerprint: TextView = view.findViewById(R.id.btn_use_fingerprint)
        val lblUseOtpLayout: LinearLayout = view.findViewById(R.id.lbl_use_otp_layout)
        val lblUseOtpDesc: TextView = view.findViewById(R.id.lbl_use_otp_desc)
        val lblUseOtp: TextView = view.findViewById(R.id.lbl_use_otp)
        val tapToPause: TextView = view.findViewById(R.id.lbl_tap_to_pause)
        val btnFingerprintIcon: ImageView = view.findViewById(R.id.iv_btn_fingerprint_icon)
        val merchantStrip: View = view.findViewById(R.id.rl_header)

        btnFillView = view.findViewById(R.id.btn_fingerprint_fill)
        tvAutoRedirect = view.findViewById(R.id.lbl_auto_redirecting)

        tvMerchantName.text = merchantName.orEmpty()
        tvTxnAmount.text = "${PayUCurrency.INR.value}${txnAmount.orEmpty()}"
        ivBankLogo.loadImageUrl(logoUrl)
        ivNetworkLogo.loadImageUrl(networkUrl)

        applyCustomisations(
            btnContainer,
            btnUseFingerprint,
            lblUseOtp,
            tvPayingTo,
            tvTxnAmount,
            btnFingerprintIcon,
            tvMerchantName,
            tapToPause,
            merchantStrip,
            lblUseOtpDesc
        )
        applySemiBold(btnUseFingerprint)

        if ((autoInvokeBiometricTime ?: 0.0) <= 0.0) {
            tapToPause.visibility = View.GONE
            btnFingerprintIcon.visibility = View.VISIBLE
            animateButtonFill(STATIC_BUTTON_FILL_DURATION_MS)  // 1ms = instant
            // No auto-invoke phase: show transaction timeout countdown from dialog start.
            showTransactionTimeoutUi = true
        }

        pauseAutoInvokeAction = pauseAutoInvoke@{
            if (autoInvokeBiometricTimer == null) return@pauseAutoInvoke
            logNudgeScreenOutcome(LoggingConstants.OUTCOME_TAP_TO_PAUSE, "null")
            autoInvokeBiometricTimer?.cancel()
            autoInvokeBiometricTimer = null
            tapToPause.visibility = View.GONE
            btnFingerprintIcon.visibility = View.VISIBLE
            animateButtonFill(FAST_FILL_AFTER_PAUSE_DURATION_MS, fromCurrentWidth = true)
            fallbackOTPUIViewTimer?.cancel()
            lblUseOtpLayout.visibility = View.VISIBLE
            revealTransactionTimeoutCountdown()
        }

        tapToPause.setOnClickListener { pauseAutoInvokeAction?.invoke() }

        lblUseOtp.setOnClickListener {
            selectAuthAction(
                LoggingConstants.AUTH_TYPE_OTP_SELECTED,
                buildAuthTypeData(
                    LoggingConstants.AUTH_TYPE_OTP,
                    LoggingConstants.AUTH_SELECTION_REASON_OTP_SELECTED
                ),
                AuthType.OTP,
                LoggingConstants.OUTCOME_GET_OTP_TAPPED,
                skipDebounce = true,
                fpStatus = APIConstants.RBA_STATUS_CANCELLED,
                reasonCode = APIConstants.RBA_REASON_CODE_C01,
                useFullScreenLoader = true
            )
        }

        val onFingerprintButtonClick = {
            if (tapToPause.visibility == View.VISIBLE) {
                pauseAutoInvokeAction?.invoke()
            } else {
                selectAuthAction(
                    LoggingConstants.AUTH_TYPE_BIOMETRIC_SELECTED_MANUAL,
                    buildAuthTypeData(
                        LoggingConstants.AUTH_TYPE_BIOMETRIC,
                        LoggingConstants.AUTH_SELECTION_REASON_BIOMETRIC_MANUAL
                    ),
                    AuthType.BIOMETRIC,
                    LoggingConstants.OUTCOME_PAY_TAPPED
                )
            }
        }
        btnUseFingerprint.setOnClickListener { onFingerprintButtonClick() }
        btnContainer.setOnClickListener { onFingerprintButtonClick() }

        if (startTimers) {
            startAuthSelectionTimers(view)
        }
    }

    private fun startAuthSelectionTimers(view: View) {
        val lblUseOtpLayout: LinearLayout = view.findViewById(R.id.lbl_use_otp_layout)

        startAutoInvokeBiometricTimer()
        startOTPRedirectTimer()
        startTimerToShowOTPOption(lblUseOtpLayout)
        SdkUiInitializer.apiLayer?.logDataWithAdditionalKeys(
            LoggingConstants.PAYU_CARDS_TRANSACTION,
            LoggingConstants.EVENT_BIOMETRIC_NUDGE_SCREEN_INITIATED,
            mapOf(LoggingConstants.KEY_VIEWED to LoggingConstants.VIEWED_YES),
            buildOpenScreenData()
        )
    }

    fun attachBackPressHandler(hostDialog: Dialog?) {
        hostDialog?.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                showExitConfirmation()
                return@setOnKeyListener true
            }
            false
        }
    }

    fun cleanup() {
        stopLoaderAnimation()
        cancelAllTimers()
        try {
            alertDialog?.dismiss()
            alertDialog = null
        } catch (e: Exception) {
            Log.e(TAG, "Error dismissing alert dialog: ${e.message}", e)
        }
    }

    private fun setupBackButton(view: View) {
        view.findViewById<ImageView>(R.id.ivBack)?.setOnClickListener {
            showExitConfirmation()
        }
    }

    private fun applyCustomisations(
        btnContainer: View,
        btnUseFingerprint: TextView,
        lblUseOtp: TextView,
        tvPayingTo: TextView,
        tvTxnAmount: TextView,
        ivFingerPrintBtn: ImageView?,
        tvMerchantName: TextView,
        tapToPause: TextView,
        merchantStrip: View,
        lblUseOtpDesc: TextView
    ) {
        uiCustomisation?.fontFamilyCustomisation?.let { fontConfig ->
            fontConfig.subTextFontFamily?.takeIf { it.isNotBlank() }?.let { fontPath ->
                val typeface = UIUtils.typeface(context, fontPath)
                tvPayingTo.typeface = typeface
                lblUseOtp.typeface = typeface
                lblUseOtpDesc.typeface = typeface
                tvAutoRedirect?.typeface = typeface
            }
            fontConfig.headerFontFamily?.takeIf { it.isNotBlank() }?.let { fontPath ->
                val typeface = UIUtils.typeface(context, fontPath)
                btnUseFingerprint.typeface = typeface
                tvTxnAmount.typeface = typeface
                tvMerchantName.typeface = typeface
                tapToPause.typeface = typeface
            }
        }

        uiCustomisation?.labelCustomisation?.let { labelConfig ->
            UIUtils.applyLabelHeadingStyle(tvMerchantName, labelConfig = labelConfig)
            UIUtils.applyLabelTextStyle(
                tvPayingTo,
                tvTxnAmount,
                lblUseOtpDesc,
                labelConfig = labelConfig
            )
        }

        uiCustomisation?.buttonCustomisation?.let { buttonConfig ->
            buttonConfig.backgroundColor
                ?.takeIf { UIUtils.isValidColorCode(it) }
                ?.let { color ->
                    UIUtils.applyMerchantStripStyle(
                        merchantStrip,
                        color,
                        showBorder = isBottomSheet
                    )
                }
            buttonConfig.textFontColor?.takeIf { UIUtils.isValidColorCode(it) }
                ?.let { color ->
                    runCatching {
                        btnUseFingerprint.setTextColor(color.toColorInt())
                        ivFingerPrintBtn?.imageTintList = ColorStateList.valueOf(color.toColorInt())
                    }
                }

            UIUtils.applyProgressButtonStyle(btnContainer, btnFillView, buttonConfig)
            UIUtils.applyButtonTextStyle(btnUseFingerprint, buttonConfig)

            val otpLinkColor = buttonConfig.backgroundColor?.takeIf { UIUtils.isValidColorCode(it) }
            otpLinkColor?.let { UIUtils.updateTextColor(lblUseOtp, it) }
        }
    }

    private fun applySemiBold(textView: TextView) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            textView.typeface = Typeface.create(textView.typeface, BUTTON_TEXT_WEIGHT, false)
        } else {
            textView.setTypeface(textView.typeface, Typeface.BOLD)
        }
    }

    private fun selectAuthAction(
        eventValue: String,
        data: String?,
        authType: AuthType,
        nudgeOutcome: String,
        skipDebounce: Boolean = false,
        fpStatus: String? = null,
        reasonCode: String? = null,
        useFullScreenLoader: Boolean = false
    ) {
        if (!skipDebounce && !UIUtils.isSafeOnClickListener(2000)) return
        if (!UIUtils.isInternetAvailable(context)) {
            logNudgeScreenOutcome(LoggingConstants.OUTCOME_NETWORK_FALLBACK, authTypeValue(authType))
            Toast.makeText(context, R.string.threeds_payu_no_internet_connection, Toast.LENGTH_SHORT).show()
            return
        }
        logNudgeScreenOutcome(nudgeOutcome, authTypeValue(authType))
        logTransactionEvent(eventValue, data)
        if (authType == AuthType.OTP) {
            SdkUiInitializer.useHalfScreenProgressLoader = false
            (context as? AppCompatActivity)?.let { SdkUiInitializer.showProgressLoader(it) }
        }else if (authType == AuthType.BIOMETRIC){
            SdkUiInitializer.useHalfScreenProgressLoader = true
            (context as? AppCompatActivity)?.let { SdkUiInitializer.showProgressLoader(it) }
        }
        authTypeSelectedListener(authType, fpStatus, reasonCode)
        dismissScreen()
    }

    private fun logNudgeScreenOutcome(
        outcome: String,
        authType: String = LoggingConstants.AUTH_TYPE_BIOMETRIC.lowercase()
    ) {
        val additionalKeys = mutableMapOf<String, Any?>(
            LoggingConstants.KEY_OUTCOME to outcome,
            LoggingConstants.KEY_AUTH_TYPE to authType
        )
        SdkUiInitializer.apiLayer?.logDataWithAdditionalKeys(
            LoggingConstants.PAYU_CARDS_TRANSACTION,
            LoggingConstants.EVENT_BIOMETRIC_NUDGE_SCREEN_OUTCOME,
            additionalKeys
        )
    }

    private fun logNudgeInterceptionOutcome(
        outcome: String,
        authType: String = LoggingConstants.AUTH_TYPE_BIOMETRIC.lowercase()
    ) {
        val additionalKeys = mutableMapOf<String, Any?>(
            LoggingConstants.KEY_OUTCOME to outcome,
            LoggingConstants.KEY_AUTH_TYPE to authType,
            LoggingConstants.KEY_BIOMETRIC_TYPE to LoggingConstants.BIOMETRIC_TYPE_FINGERPRINT
        )
        SdkUiInitializer.apiLayer?.logDataWithAdditionalKeys(
            LoggingConstants.PAYU_CARDS_TRANSACTION,
            LoggingConstants.EVENT_BIOMETRIC_NUDGE_INTERCEPTION_OUTCOME,
            additionalKeys
        )
    }

    private fun authTypeValue(authType: AuthType): String = when (authType) {
        AuthType.BIOMETRIC -> LoggingConstants.AUTH_TYPE_BIOMETRIC.lowercase()
        AuthType.OTP -> LoggingConstants.AUTH_TYPE_OTP.lowercase()
        else -> "null"
    }

    private fun logTransactionEvent(eventValue: String, data: String? = null) {
        SdkUiInitializer.apiLayer?.logData(
            LoggingConstants.PAYU_CARDS_TRANSACTION,
            eventValue,
            data
        )
    }

    private fun buildOpenScreenData(): String {
        return JSONObject().apply {
            merchantName?.takeIf { it.isNotBlank() }?.let { put(RBA_MERCHANT_NAME, it) }
            txnAmount?.takeIf { it.isNotBlank() }?.let { put(RBA_TXN_AMOUNT, it) }
        }.toString()
    }

    private fun buildAuthTypeData(authType: String, reason: String): String {
        return JSONObject().apply {
            put(RBA_AUTH_TYPE, authType)
            put(RBA_AUTH_REASON, reason)
        }.toString()
    }


    private fun startTimerToShowOTPOption(lblUseOtpLayout: LinearLayout) {
        val fallbackTimeoutValue = fallbackVisibilityDuration?.takeIf { it > 0 }?.let { it * 1000L } ?: 0L

        fallbackOTPUIViewTimer = UIUtils.getCountDownTimer(
            timeout = fallbackTimeoutValue,
            interval = 1000L,
            onFinish = { lblUseOtpLayout.visibility = View.VISIBLE }
        )
        fallbackOTPUIViewTimer?.start()
    }

    private fun startOTPRedirectTimer() {
        // Only one transactionTimeout per dialog lifecycle — never restart after start.
        if (redirectTimer != null || transactionTimeoutEndTimeMs > 0L) return

        val fallbackTimeoutValue = fallbackTimeout?.takeIf { it > 0 }?.let { it * 1000L } ?: AUTH_SELECTION_TIMEOUT
        transactionTimeoutEndTimeMs = SystemClock.elapsedRealtime() + fallbackTimeoutValue

        redirectTimer = UIUtils.getCountDownTimer(
            timeout = fallbackTimeoutValue,
            interval = 1000L,
            onFinish = { onTransactionTimeoutExpired() },
            onInterval = { millisUntilFinished ->
                if (showTransactionTimeoutUi) {
                    updateTransactionTimeoutUi(millisUntilFinished)
                }
            }
        )
        redirectTimer?.start()
    }


    private fun revealTransactionTimeoutCountdown() {
        showTransactionTimeoutUi = true
        val remainingMs = transactionTimeoutEndTimeMs - SystemClock.elapsedRealtime()
        if (remainingMs <= 0L) {
            redirectTimer?.cancel()
            redirectTimer = null
            onTransactionTimeoutExpired()
        } else {
            updateTransactionTimeoutUi(remainingMs)
        }
    }

    private fun updateTransactionTimeoutUi(millisUntilFinished: Long) {
        val seconds = (millisUntilFinished / 1000).coerceAtLeast(0).toString()
        tvAutoRedirect?.text = context.getString(R.string.threeds_payu_auto_redirecting, seconds)
        tvAutoRedirect?.visibility = View.VISIBLE
    }

    private fun onTransactionTimeoutExpired() {
        if (hasTransactionTimeoutExpired) return
        hasTransactionTimeoutExpired = true
        selectAuthAction(
            LoggingConstants.OTP_FALLBACK_MANUAL,
            buildAuthTypeData(
                LoggingConstants.AUTH_TYPE_OTP,
                LoggingConstants.AUTH_SELECTION_REASON_OTP_TIMER_EXPIRED
            ),
            AuthType.OTP,
            LoggingConstants.OUTCOME_INACTIVITY_TIMEOUT,
            skipDebounce = true,
            fpStatus = APIConstants.RBA_STATUS_EXPIRED,
            reasonCode = APIConstants.RBA_REASON_CODE_E01
        )
    }

    private fun startAutoInvokeBiometricTimer() {
        val autoInvokeTime = autoInvokeBiometricTime?.takeIf { it > 0.0 } ?: return
        if (autoInvokeTime < 1.0) {
            selectAuthAction(
                LoggingConstants.AUTH_TYPE_BIOMETRIC_SELECTED_AUTO,
                buildAuthTypeData(
                    LoggingConstants.AUTH_TYPE_BIOMETRIC,
                    LoggingConstants.AUTH_SELECTION_REASON_BIOMETRIC_AUTO
                ),
                AuthType.BIOMETRIC,
                LoggingConstants.OUTCOME_LOADER_COMPLETED,
                skipDebounce = true
            )
            return
        }
        val autoInvokeTimeout = (autoInvokeTime * 1000).toLong()

        autoInvokeBiometricTimer = UIUtils.getCountDownTimer(
            timeout = autoInvokeTimeout,
            interval = autoInvokeTimeout,
            onFinish = {
                selectAuthAction(
                    LoggingConstants.AUTH_TYPE_BIOMETRIC_SELECTED_AUTO,
                    buildAuthTypeData(
                        LoggingConstants.AUTH_TYPE_BIOMETRIC,
                        LoggingConstants.AUTH_SELECTION_REASON_BIOMETRIC_AUTO
                    ),
                    AuthType.BIOMETRIC,
                    LoggingConstants.OUTCOME_LOADER_COMPLETED,
                    skipDebounce = true
                )
            }
        )
        autoInvokeBiometricTimer?.start()
        animateButtonFill(autoInvokeTimeout)
    }

    private fun animateButtonFill(durationMs: Long, fromCurrentWidth: Boolean = false) {
        val fillView = btnFillView ?: return
        fillView.post {
            fillAnimator?.cancel()
            val fromWidth = if (fromCurrentWidth) fillView.width else 0
            fillAnimator = UIUtils.animateFillWidth(fillView, durationMs, fromWidth = fromWidth)
        }
    }

    private fun createExitConfirmationDialog() {
        alertDialog = UIUtils.getAlertDialog(
            activity = context,
            onClickDialog = { dialog, which ->
                when (which) {
                    DialogInterface.BUTTON_POSITIVE -> {
                        logNudgeInterceptionOutcome(LoggingConstants.INTERCEPTION_OUTCOME_YES, "null")
                        authTypeSelectedListener(AuthType.USER_CANCELLED, null, null)
                        dismissScreen()
                    }
                    DialogInterface.BUTTON_NEGATIVE -> {
                        logNudgeInterceptionOutcome(LoggingConstants.INTERCEPTION_OUTCOME_NO)
                        dialog.dismiss()
                    }
                    DialogInterface.BUTTON_NEUTRAL -> {
                        logNudgeInterceptionOutcome(LoggingConstants.INTERCEPTION_OUTCOME_OTP,
                            LoggingConstants.AUTH_TYPE_OTP.lowercase())
                        selectAuthAction(
                            LoggingConstants.OTP_FALLBACK_BACKPRESS,
                            buildAuthTypeData(
                                LoggingConstants.AUTH_TYPE_OTP,
                                LoggingConstants.AUTH_SELECTION_REASON_OTP_USER_CANCELLED
                            ),
                            AuthType.OTP,
                            LoggingConstants.OUTCOME_BIOMETRIC_TO_OTP,
                            skipDebounce = true,
                            fpStatus = APIConstants.RBA_STATUS_CANCELLED,
                            reasonCode = APIConstants.RBA_REASON_CODE_C04,
                            useFullScreenLoader = true
                        )
                    }
                }
            },
            positiveText = context.getString(R.string.threeds_payu_yes),
            negativeText = context.getString(R.string.threeds_payu_no),
            neutralText = context.getString(R.string.threeds_payu_use_otp),
            title = null,
            message = context.getString(R.string.threeds_payu_do_you_really_want_to_cancel_the_payment)
        ).create()
    }

    private fun showExitConfirmation() {
        if (!canShowExitConfirmation) return
        pauseAutoInvokeAction?.invoke()
        logNudgeScreenOutcome(LoggingConstants.OUTCOME_BACK_PRESSED, "null")
        try {
            if (alertDialog?.isShowing != true) {
                alertDialog?.show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing exit confirmation dialog: ${e.message}", e)
        }
    }

    private fun stopLoaderAnimation() {
        loaderRevealRunnable?.let { mainHandler.removeCallbacks(it) }
        loaderRevealRunnable = null
        loaderTextAnimationRunnable?.let { mainHandler.removeCallbacks(it) }
        loaderTextAnimationRunnable = null
    }

    private fun applyLoaderGradientBackground(view: View) {
        view.findViewById<View>(R.id.auth_selection_root)
            ?.setBackgroundResource(R.drawable.payu_half_progress_bottom_sheet_bg)
    }

    private fun clearLoaderGradientBackground(view: View) {
        view.findViewById<View>(R.id.auth_selection_root)
            ?.setBackgroundResource(R.drawable.payu_auth_bottom_sheet_bg)
    }

    private fun cancelAllTimers() {
        redirectTimer?.cancel()
        redirectTimer = null
        fallbackOTPUIViewTimer?.cancel()
        fallbackOTPUIViewTimer = null
        autoInvokeBiometricTimer?.cancel()
        autoInvokeBiometricTimer = null
        fillAnimator?.cancel()
        fillAnimator = null
        transactionTimeoutEndTimeMs = 0L
        showTransactionTimeoutUi = false
        hasTransactionTimeoutExpired = false
        pauseAutoInvokeAction = null
    }

    companion object {
        private const val TAG = "AuthSelectionController"
        private const val BUTTON_TEXT_WEIGHT = 600
        private const val FAST_FILL_AFTER_PAUSE_DURATION_MS = 300L
        private const val STATIC_BUTTON_FILL_DURATION_MS = 1L
    }
}
