package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.enums.FontName

class LabelCustomisation(builder: Builder) {
    var headingTextColor: String? = null
        private set
    var headingTextFontName: FontName? = null
        private set
    var headingTextFontSize: Int? = null
        private set
    var textColor: String? = null
        private set
    var textFontName: FontName? = null
        private set
    var textFontSize: Int? = null
        private set

    init {
        this.headingTextColor = builder.headingTextColor
        this.headingTextFontName = builder.headingTextFontName
        this.headingTextFontSize = builder.headingTextFontSize
        this.textColor = builder.textColor
        this.textFontName = builder.textFontName
        this.textFontSize = builder.textFontSize
    }

    class Builder {
        internal var headingTextColor: String? = null
        internal var headingTextFontName: FontName? = null
        internal var headingTextFontSize: Int? = null
        internal var textColor: String? = null
        internal var textFontName: FontName? = null
        internal var textFontSize: Int? = null

        fun setHeadingTextColor(headingTextColor: String?): Builder {
            this.headingTextColor = headingTextColor
            return this
        }

        fun setHeadingTextFontName(headingTextFontName: FontName?): Builder {
            this.headingTextFontName = headingTextFontName
            return this
        }

        fun setHeadingTextFontSize(headingTextFontSize: Int?): Builder {
            this.headingTextFontSize = headingTextFontSize
            return this
        }

        fun setTextColor(textColor: String?): Builder {
            this.textColor = textColor
            return this
        }

        fun setTextFontName(textFontName: FontName?): Builder {
            this.textFontName = textFontName
            return this
        }

        fun setTextFontSize(textFontSize: Int?): Builder {
            this.textFontSize = textFontSize
            return this
        }


        fun build(): LabelCustomisation {
            return LabelCustomisation(this)
        }
    }

}