package com.payu.threedsui.interfaces.listeners

import com.payu.threedsbase.config.PayU3DS2MFAResponse


interface PayU3DS2PaymentBaseCallback {
    fun onPaymentSuccess(successResponse: Any)
    fun onPaymentFailure(failureResponse: Any)
    fun onError(errorCode: Int, errorMessage: String)
    fun mfaRegistrationStatus(status: Any?)
}