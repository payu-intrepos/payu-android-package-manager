package com.payu.threedsui.uiCustomisation.tridentity

class BottomSheetSimBindingProcessingPopupConfiguration private constructor(builder: Builder) {

    val biometricSetupText: String? = builder.biometricSetupText
    val biometricVerifiedText: String? = builder.biometricVerifiedText
    val headerTextForContents: String? = builder.headerTextForContents
    val numberVerificationProcessingText: String? = builder.numberVerificationProcessingText
    val numberVerifiedText: String? = builder.numberVerifiedText
    val simSelectionHeaderText: String? = builder.simSelectionHeaderText
    val subTextForContents: String? = builder.subTextForContents
    val topHeaderText: String? = builder.topHeaderText
    val topSubHeaderText: String? = builder.topSubHeaderText

    class Builder {
        internal var biometricSetupText: String? = null
        internal var biometricVerifiedText: String? = null
        internal var headerTextForContents: String? = null
        internal var numberVerificationProcessingText: String? = null
        internal var numberVerifiedText: String? = null
        internal var simSelectionHeaderText: String? = null
        internal var subTextForContents: String? = null
        internal var topHeaderText: String? = null
        internal var topSubHeaderText: String? = null

        fun setBiometricSetupText(biometricSetupText: String?) = apply { this.biometricSetupText = biometricSetupText }
        fun setBiometricVerifiedText(biometricVerifiedText: String?) = apply { this.biometricVerifiedText = biometricVerifiedText }
        fun setHeaderTextForContents(headerTextForContents: String?) = apply { this.headerTextForContents = headerTextForContents }
        fun setNumberVerificationProcessingText(numberVerificationProcessingText: String?) = apply { this.numberVerificationProcessingText = numberVerificationProcessingText }
        fun setNumberVerifiedText(numberVerifiedText: String?) = apply { this.numberVerifiedText = numberVerifiedText }
        fun setSimSelectionHeaderText(simSelectionHeaderText: String?) = apply { this.simSelectionHeaderText = simSelectionHeaderText }
        fun setSubTextForContents(subTextForContents: String?) = apply { this.subTextForContents = subTextForContents }
        fun setTopHeaderText(topHeaderText: String?) = apply { this.topHeaderText = topHeaderText }
        fun setTopSubHeaderText(topSubHeaderText: String?) = apply { this.topSubHeaderText = topSubHeaderText }

        fun build(): BottomSheetSimBindingProcessingPopupConfiguration {
            return BottomSheetSimBindingProcessingPopupConfiguration(this)
        }
    }
}