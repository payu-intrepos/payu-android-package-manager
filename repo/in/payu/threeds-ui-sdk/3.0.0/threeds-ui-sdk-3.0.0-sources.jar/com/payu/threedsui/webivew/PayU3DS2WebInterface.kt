package com.payu.threedsui.webivew

import android.app.Activity
import android.content.Intent
import android.os.CountDownTimer
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.view.activities.PayUJSCallback
import org.json.JSONObject

class PayU3DS2WebInterface(private val activity: Activity, private val jsCallback: PayUJSCallback) {
    private var countDownTimer: CountDownTimer? = null
    private var payuResponse: String? = null
    private var isSuccessTransaction = false
    private var merchantResponse: String? = null

    /**
     * @param result json data of post param.
     * call back function from furl - failure transaction.
     * keep the value in [.merchantResponse]
     * set result ok, and send the received data.
     * @param result json string
     */
    @JavascriptInterface
    fun onFailure(result: String?) {
        merchantResponse = result
        callTimer()
    }

    /**
     * call back function from surl - success transaction.
     * keep the data in [.merchantResponse]
     * set result ok, and send the received data.
     *
     * @param result success result received from surl
     */
    @JavascriptInterface
    fun onSuccess(result: String) {
        merchantResponse = result
        isSuccessTransaction = true
        callTimer()
    }

    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    fun onCancel() {
        onCancel("")
    }


    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    fun onCancel(result: String) {
        if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
            activity?.runOnUiThread {
                SdkUiInitializer.apiLayer!!.dismissBottomSheet()
                if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                    val intent = Intent()
                    Toast.makeText(
                        activity,
                        PayU3DS2ErrorConstants.CANCEL_TRANSACTION_ERROR_MESSAGE,
                        Toast.LENGTH_SHORT
                    ).show()
                    activity?.setResult(Activity.RESULT_CANCELED, intent)
                    activity?.finish()
                }
            }
        }
    }


    /**
     * Attempt to deprecate furl.
     * Javascript call from payu server.
     * Lets keep the data in local variable and pass it to calling activity.
     *
     * @param result json string result of failure transaction
     */
    @JavascriptInterface
    fun onPayuFailure(result: String) {
        if (activity != null) {
            isSuccessTransaction = false
            payuResponse = result
            callTimer()
        }
    }

    /**
     * Fun to start times for merchant timeout value
     */
    private fun callTimer() {
        activity?.runOnUiThread {
            SdkUiInitializer.apiLayer!!.dismissBottomSheet()
        }
        countDownTimer = object : CountDownTimer(
            SdkUiInitializer.apiLayer!!.config.merchantResponseTimeout,
            APIConstants.MERCHANT_RESPONSE_TIMEOUT_INTERVAL
        ) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                    activity?.runOnUiThread {
                        if (activity != null && !activity?.isFinishing!! && !activity?.isDestroyed!!) {
                            onMerchantUrlFinished()
                        }
                    }
                }
            }
        }.start()
    }

    /**
     * This function takes care of sending the data back to calling activity with the status,
     * merchantResponse, payuresponse.
     */
    private fun onMerchantUrlFinished() {
        if (null != countDownTimer) countDownTimer!!.cancel()
        if (activity != null && activity?.isFinishing == false && activity?.isDestroyed == false) {
            activity?.runOnUiThread {
                if (activity != null && activity?.isFinishing == false && activity?.isDestroyed == false) {
                    if (isSuccessTransaction) {
                        if (SdkUiInitializer.paymentCallback != null) {
                            val response = HashMap<String, String?>()
                            response[APIConstants.MERCHANT_RESPONSE] = merchantResponse
                            response[APIConstants.PAYU_RESPONSE] = payuResponse
                            SdkUiInitializer.paymentCallback!!.onPaymentSuccess(
                                response
                            )
                        }
                    } else {
                        if (SdkUiInitializer.paymentCallback!! != null) {
                            val response = HashMap<String, String?>()
                            response[APIConstants.MERCHANT_RESPONSE] = merchantResponse
                            response[APIConstants.PAYU_RESPONSE] = payuResponse
                            SdkUiInitializer.paymentCallback!!.onPaymentFailure(
                                response
                            )
                        }
                    }
                    activity?.finish()
                }
            }
        }
    }

    @JavascriptInterface
    fun convertToNative(fields: String, params: String) {
        val jsonObject = JSONObject(params)
        jsCallback.hasSubmitButton(jsonObject.getBoolean(APIConstants.HAS_SUBMIT_BUTTON))
    }
}