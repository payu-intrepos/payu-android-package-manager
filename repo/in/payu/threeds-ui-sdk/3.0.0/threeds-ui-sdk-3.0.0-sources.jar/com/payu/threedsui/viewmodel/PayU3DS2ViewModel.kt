package com.payu.threedsui.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.payu.paymentparamhelper.HashCommand
import com.payu.threedsbase.config.PayU3DS2MFAResponse
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.APIConstants.Companion.CHALLENGE_SUCCESS_VALUE
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.CARD_SCHEME_NOT_SUPPORTED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.CHALLENGE_CANCEL_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CONFIG_FAILED_CODE_DEREG
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_CONFIG_FAILED_CODE_REG
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_DE_REGISTERED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_DEVICE_MANUAL_DE_REGISTERED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.RBA_REGISTRATION_FAILED_ERROR_CODE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SOMETHING_WENT_WRONG_ERROR_MESSAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.TRANSACTION_FAILED
import com.payu.threedsbase.data.CardData
import com.payu.threedsbase.data.ChallengeParameter
import com.payu.threedsbase.data.PArqResponse
import com.payu.threedsbase.data.apiRequest.CardBinInfoRequest
import com.payu.threedsbase.data.apiResponse.BinInfoResponse
import com.payu.threedsbase.data.apiResponse.PArsResponse
import com.payu.threedsbase.enums.APICommand
import com.payu.threedsbase.enums.PayU3DS2MFAStatus
import com.payu.threedsbase.enums.PayU3DS2MFARequestType
import com.payu.threedsbase.enums.TransactionFlowType
import com.payu.threedsbase.interfaces.listeners.FallbackPostDataListener
import com.payu.threedsbase.interfaces.listeners.PayU3DS2Callback
import com.payu.threedsbase.interfaces.listeners.PayU3DS2MFACallback
import com.payu.threedsbase.interfaces.listeners.PayUHashGeneratedListener
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.interfaces.listeners.PayU3DS2PaymentCallback
import org.json.JSONObject
import kotlin.collections.HashMap

class PayU3DS2ViewModel(application: Application) : AndroidViewModel(application),
    PayU3DS2Callback, PayU3DS2MFACallback {

    private val TAG = this.javaClass.simpleName
    var deviceDetails: MutableLiveData<PArqResponse?> = MutableLiveData()
    var binInfoResponse: MutableLiveData<BinInfoResponse?> = MutableLiveData()
    var showProgressDialog: MutableLiveData<Boolean?> = MutableLiveData()
    var showProgressDialogInfoText: MutableLiveData<Boolean?> = MutableLiveData()

    var paymentParamUpdated: MutableLiveData<Boolean?> = MutableLiveData()
    private var apiCommand: APICommand? = null
    var fallbackFlow: MutableLiveData<Boolean?> = MutableLiveData()
    var showChallenge: MutableLiveData<PArsResponse?> = MutableLiveData()
    var initiateAuthentication: MutableLiveData<Boolean?> = MutableLiveData()
    var postData: MutableLiveData<String?> = MutableLiveData()
    var initiateAuthorization: MutableLiveData<Boolean?> = MutableLiveData()

    private var mfaRegistrationStatus : PayU3DS2MFAResponse? = null
    private var initPaymentResponse: PArsResponse? = null
    private var biometricConsentGiven = false

    private var errorCode: Int? = null
    private var errorMessage: String? = null

    /**
     * Fetch bin info data
     */
    internal fun getBinInfoData(apiCommand: APICommand) {
        this.apiCommand = apiCommand
        showProgressDialog.postValue(true)

        SdkUiInitializer.apiLayer?.run {
            val cardBinInfoRequest = CardBinInfoRequest(
                if (!paymentParams.cardNumber.isNullOrEmpty())
                    paymentParams.cardNumber
                else if (!paymentParams.networkToken.isNullOrEmpty())
                    paymentParams.networkToken
                else if (!paymentParams.cardToken.isNullOrEmpty())
                    paymentParams.cardToken
                else "",
                paymentParams.siParams != null
            )
            fetchBinInfo(cardBinInfoRequest, this@PayU3DS2ViewModel)
        }
    }


    /**
     * Extract device details using wibmo SDK or redirect to fallback flow or return error
     */
    internal fun getDeviceDetails(context: Context, cardData: CardData) {
        val sdkInitialisationResponse =
            SdkUiInitializer.apiLayer?.initialise3DSService(context as Activity)
        if (sdkInitialisationResponse?.status == 0) {
            val deviceDetail = SdkUiInitializer.apiLayer?.extractDeviceDetails(cardData)
            if (deviceDetail?.status == 0) {
                deviceDetails.value = deviceDetail.result as PArqResponse
            } else if (SdkUiInitializer.apiLayer?.isFallbackAllowed() == true) {
                fallbackFlow.value = true
            } else {
                showProgressDialog.value = false
                SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_DEVICE_DETAILS, LoggingConstants.FAILED, deviceDetail?.errorMessage, SDK_RESPONSE_STATUS_CODE_1)
                SdkUiInitializer.paymentCallback?.onError(
                    deviceDetail?.status ?: SDK_RESPONSE_STATUS_CODE_1,
                    deviceDetail?.errorMessage ?: ""
                )
                SdkUiInitializer.apiLayer?.clean()
            }
        } else if (SdkUiInitializer.apiLayer?.isFallbackAllowed() == true) {
            fallbackFlow.value = true
        } else {
            showProgressDialog.value = false
            SdkUiInitializer.apiLayer?.logDataFailure(
                LoggingConstants.PAYU_CARDS_INIT,
                LoggingConstants.FAILED,
                sdkInitialisationResponse?.errorMessage,
                SDK_RESPONSE_STATUS_CODE_1
            )
            SdkUiInitializer.paymentCallback?.onError(
                sdkInitialisationResponse?.status ?: SDK_RESPONSE_STATUS_CODE_1,
                sdkInitialisationResponse?.errorMessage ?: ""

            )
            SdkUiInitializer.apiLayer?.clean()
        }
    }

    /**
     * API fun to start payment
     */
    internal fun initiatePayment(apiCommand: APICommand) {
        this.apiCommand = apiCommand
        showProgressDialog.value = true
        SdkUiInitializer.apiLayer?.initiatePayment(this)
    }

    /**
     * Fun to update payment parameters with pArq or device details and SDK platform data
     */
    internal fun updatePaymentParamWithPArqAndSDKData(pArqResponse: PArqResponse) {
        SdkUiInitializer.apiLayer?.updatePaymentParamsWithSDKInfo(pArqResponse)
        paymentParamUpdated.value = true
    }

    override fun generateHash(
        map: HashMap<String, String>,
        hashGenerationListener: PayUHashGeneratedListener
    ) {
        var callback = SdkUiInitializer.paymentCallback

        if (callback != null && callback is PayU3DS2PaymentCallback) {
            callback!!.generateHash(map, hashGenerationListener)
        }
    }


    override fun onSuccess(response: Any) {
        Log.d(TAG,"apiCommand" + apiCommand.toString())
        when (apiCommand) {
            APICommand.BinInfo -> {
                response as BinInfoResponse
                if (!response.messageVersion.isNullOrEmpty() && response.messageVersion!!.startsWith(
                        APIConstants.THREE_DS_VERSION_VALUE
                    )
                ) {
                    /**
                     * paymentParams?.threeDSVersion will pass to _payment call from binInfo response
                     */
                    SdkUiInitializer.apiLayer?.paymentParams?.threeDSVersion =
                        response.messageVersion
                    SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_BIN_INFO,
                        LoggingConstants.SUCCESS,response.toString())
                    binInfoResponse.value = response
                } else if (SdkUiInitializer.apiLayer!!.isFallbackAllowed()) {
                    showProgressDialog.postValue(false)
                    SdkUiInitializer.apiLayer?.logDataFailure(
                        LoggingConstants.PAYU_CARDS_BIN_INFO,
                        LoggingConstants.FAILED,
                        LoggingConstants.FLOW_COMPLETED_FALLBACK,
                        PayU3DS2ErrorConstants.BIN_INFO_API_CARD_NOT_SUPPORTED_ERROR_CODE
                    )
                    fallbackFlow.postValue(true)
                } else {
                    showProgressDialog.postValue(false)
                    SdkUiInitializer.apiLayer?.logDataFailure(
                        LoggingConstants.PAYU_CARDS_BIN_INFO,
                        LoggingConstants.FAILED,
                        "${PayU3DS2ErrorConstants.BIN_INFO_API_CARD_NOT_SUPPORTED_ERROR_CODE} ${PayU3DS2ErrorConstants.CARD_NOT_SUPPORTED_ON_3DS2}",
                        PayU3DS2ErrorConstants.BIN_INFO_API_CARD_NOT_SUPPORTED_ERROR_CODE
                    )
                    SdkUiInitializer.paymentCallback!!.onError(
                        PayU3DS2ErrorConstants.BIN_INFO_API_CARD_NOT_SUPPORTED_ERROR_CODE,
                        PayU3DS2ErrorConstants.CARD_NOT_SUPPORTED_ON_3DS2
                    )
                    SdkUiInitializer.apiLayer!!.clean()
                }
            }

                APICommand.InitiatePayment -> {
                    response as PArsResponse
                    when (response.threeDSTransStatus) {
                        TransactionFlowType.Frictionless.value -> authorizePayment(APICommand.AuthorizePayment)
                        TransactionFlowType.Challenge.value -> {
                            initPaymentResponse = response
                            showChallenge.value = response
                        }

                        else -> sendFailureCallback()
                    }
                }

                /**
                 * To solve, if in reg process we are sending a callback and command will remain authN or authZ and will return again a callback
                 */
                APICommand.AuthorizePayment -> {
                    if(response is PayU3DS2MFAResponse){
                        mfaRegistrationStatus = response
                        SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                            LoggingConstants.SUCCESS,response.toString())
                        SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(mfaRegistrationStatus?.toJSONString())
                        Log.d(TAG,"onSuccess AuthorizePayment MFAResponse" + mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialog.postValue(mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialogInfoText.postValue(true)
                    } else {
                        Log.d(TAG,"onSuccess AuthorizePayment " + mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))

                        showProgressDialog.postValue(false)
//                        showProgressDialogInfoText.postValue(true)
                        val metaData =
                            JSONObject(response.toString()).getJSONObject(APIConstants.PAYMENT_API_META_DATA)
                        val statusCode = metaData.getString(APIConstants.STATUS_CODE)
                        if (statusCode.equals(APIConstants.PAYMENT_SUCCESS_CODE)) {
                            SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                                LoggingConstants.SUCCESS,response.toString())
                            SdkUiInitializer.paymentCallback?.onPaymentSuccess(response)
                        } else {
                            SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                                LoggingConstants.FAILED,response.toString())
                            SdkUiInitializer.paymentCallback?.onPaymentFailure(response)
                        }

                        apiCommand = null
                        if (!biometricConsentGiven)
                            SdkUiInitializer.apiLayer?.clean()
                    }



                }

                APICommand.AuthenticatePayment -> {

                    if(response is PayU3DS2MFAResponse){
                        mfaRegistrationStatus = response
                        SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                            LoggingConstants.SUCCESS,response.toString())
                        SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(mfaRegistrationStatus?.toJSONString())
                        Log.d(TAG,"onSuccess AuthenticatePayment MFAResponse" + mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialog.postValue(mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialogInfoText.postValue(true)

                    } else {
                        Log.d(TAG,"onSuccess AuthenticatePayment " + mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialog.postValue(mfaRegistrationStatus?.status?.name.equals(PayU3DS2MFAStatus.INITIATED.name))
                        showProgressDialogInfoText.postValue(true)


                        val resp = JSONObject(response.toString())
                        if (resp.getString(APIConstants.STATUS) == APIConstants.FAILURE) {
                            SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                                LoggingConstants.FAILED,response.toString())
                            SdkUiInitializer.paymentCallback?.onPaymentFailure(
                                resp.getString(APIConstants.ERROR_MESSAGE)
                            )
                        } else {
                            SdkUiInitializer.apiLayer?.logMessageSuccess(LoggingConstants.PAYU_CARDS_CREQ,
                                LoggingConstants.SUCCESS, response.toString())
                            SdkUiInitializer.paymentCallback?.onPaymentSuccess(response)
                        }

                        apiCommand = null
                        if (!biometricConsentGiven)
                            SdkUiInitializer.apiLayer?.clean()
                    }
                }


                APICommand.ChallengeFlow -> {
                    Log.d(TAG,"onSuccess ChallengeFlow" )
                    if (response is HashMap<*, *>) {
                        val transactionStatus = response[APIConstants.TRANSACTION_STATUS] as String
                        if (transactionStatus == CHALLENGE_SUCCESS_VALUE) {
                            val payU3DS22MFAResponse = response[APIConstants.MFA_REGISTRATION_STATUS] as? PayU3DS2MFAResponse
                            if (payU3DS22MFAResponse?.status == PayU3DS2MFAStatus.INITIATED) {
                                mfaRegistrationStatus = payU3DS22MFAResponse
                                biometricConsentGiven = true
                                // Send JSON string instead of object
                                SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_CREQ,
                                    LoggingConstants.SUCCESS,response.toString())
                                SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(mfaRegistrationStatus?.toJSONString())
                            }
                            startAuthZOrAuthNOnlyFlow()
                        } else {
                            showProgressDialog.postValue(false)
                            SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_CREQ,
                                LoggingConstants.FAILED)
                            SdkUiInitializer.paymentCallback?.onError(
                                SDK_RESPONSE_STATUS_CODE_1,
                                TRANSACTION_FAILED
                            )
                            SdkUiInitializer.apiLayer?.clean()
                        }
                    } else {
                        showProgressDialog.postValue(false)
                        SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_CREQ,
                            LoggingConstants.FAILED, SOMETHING_WENT_WRONG_ERROR_MESSAGE, SDK_RESPONSE_STATUS_CODE_1)
                        SdkUiInitializer.paymentCallback?.onError(
                            SDK_RESPONSE_STATUS_CODE_1,
                            SOMETHING_WENT_WRONG_ERROR_MESSAGE
                        )
                        SdkUiInitializer.apiLayer?.clean()
                    }
                }

                else -> {
                    biometricConsentGiven = false
                    if (errorCode != null && errorMessage.isNullOrEmpty().not()) {
                        showProgressDialog.postValue(false)
                        SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_CREQ,
                            LoggingConstants.FAILED,errorMessage, errorCode)
                        SdkUiInitializer.paymentCallback?.onError(
                            errorCode!!,
                            errorMessage!!
                        )
                    } else {
                        val mfaRegistrationStatus = response as? PayU3DS2MFAResponse
                        Log.d(TAG,"onSuccess else mfaRegistrationStatus" + mfaRegistrationStatus?.status?.name)

                        showProgressDialog.postValue(false)
                        SdkUiInitializer.apiLayer?.logMessageSuccess("mfaRegistrationStatus",
                            LoggingConstants.SUCCESS,mfaRegistrationStatus?.toJSONString())
                        // Send JSON string instead of object
                        SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(mfaRegistrationStatus?.toJSONString())

                    }

                }
            }
        }

    private fun startAuthZOrAuthNOnlyFlow() {
        val isAuthOnly = SdkUiInitializer.apiLayer?.isAuthenticationOnly() == true
     //   if (isAuthOnly) initiateAuthentication.value = true else initiateAuthorization.value = true

      //NOTE: did this change to support "Dont keep activity" setting via developer options
      if (isAuthOnly) authenticatePayment(APICommand.AuthenticatePayment) else authorizePayment(APICommand.AuthorizePayment)
    }



    override fun onError(
        errorCode: Int,
        errorMessage: String
    ) {

        Handler(Looper.getMainLooper()).post {
            if (SdkUiInitializer.apiLayer?.isFallbackAllowed() == true && apiCommand == APICommand.BinInfo) {
                fallbackFlow.value = true
            } else {
                SdkUiInitializer.hideProgressLoader()
                showProgressDialog.value = false

                if (errorCode == CHALLENGE_CANCEL_ERROR_CODE){
                    SdkUiInitializer.apiLayer?.logData(LoggingConstants.PAYU_CARDS_CREQ,
                        LoggingConstants.FAILED, "onPaymentCancel")
                    val callback = SdkUiInitializer.paymentCallback
                    if (callback != null && callback is PayU3DS2PaymentCallback) {
                        callback.onPaymentCancel(true)
                    }
                } else if (errorCode == RBA_REGISTRATION_FAILED_ERROR_CODE || errorCode ==  RBA_CONFIG_FAILED_CODE_REG) {
                    biometricConsentGiven = false
                    val payU3DS22MFAResponse = PayU3DS2MFAResponse(PayU3DS2MFARequestType.REGISTRATION,PayU3DS2MFAStatus.FAILED, errorMessage)
                    mfaRegistrationStatus = payU3DS22MFAResponse
                    SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_AUTHORIZE_PAYMENT,
                        LoggingConstants.FAILED, payU3DS22MFAResponse.toJSONString(), errorCode)
                    // Send JSON string instead of object
                    SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(payU3DS22MFAResponse.toJSONString())
                } else if (errorCode == RBA_DEVICE_MANUAL_DE_REGISTERED_ERROR_CODE || errorCode ==  RBA_CONFIG_FAILED_CODE_DEREG) {
                    biometricConsentGiven = false
                    val payU3DS22MFAResponse = PayU3DS2MFAResponse(PayU3DS2MFARequestType.DEREGISTRATION,PayU3DS2MFAStatus.FAILED, errorMessage)
                    mfaRegistrationStatus = payU3DS22MFAResponse
                    SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_DEREGISTER,
                        LoggingConstants.FAILED, payU3DS22MFAResponse.toJSONString(), errorCode)
                    // Send JSON string instead of object
                    SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(payU3DS22MFAResponse.toJSONString())
                }  else if (errorCode == RBA_DEVICE_DE_REGISTERED_ERROR_CODE ) {
                    this.errorCode = errorCode
                    this.errorMessage = errorMessage
                    biometricConsentGiven = false
                    SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_DEREGISTER,
                        LoggingConstants.FAILED,errorMessage, errorCode)
                    SdkUiInitializer.paymentCallback?.onError(
                        errorCode,
                        errorMessage
                    )
                }else if (biometricConsentGiven && apiCommand != null) {
                    this.errorCode = errorCode
                    this.errorMessage = errorMessage
                    biometricConsentGiven = false
                    SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_DEREGISTER,
                        LoggingConstants.FAILED,errorMessage, errorCode)
                    SdkUiInitializer.paymentCallback?.onError(
                        errorCode,
                        errorMessage
                    )
                } else {
                    SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_AREQ,
                        LoggingConstants.FAILED,errorMessage, errorCode)
                    SdkUiInitializer.paymentCallback?.onError(
                        errorCode,
                        errorMessage
                    )
                }
                if (!biometricConsentGiven)
                    SdkUiInitializer.apiLayer?.clean()
            }
        }
    }

    /**
     * API method to authorize payment
     */
    fun authorizePayment(apiCommand: APICommand) {
        this.apiCommand = apiCommand
        // Preserve whatever loader mode the flow set earlier (half-screen for
        // decoupled/MFA-biometric). Forcing false here caused a full-screen
        // loader to appear post-biometric in the recurring/decoupled path.
        showProgressDialog.value = true
        SdkUiInitializer.apiLayer?.authorizePayment(this)
    }

    /**
     * API method to authorize payment
     */
    fun authenticatePayment(apiCommand: APICommand) {
        this.apiCommand = apiCommand
        showProgressDialog.value = true
        SdkUiInitializer.apiLayer?.authenticatePayment(this)
    }

    /**
     * Method to initiate challenge for 3DS2 flow
     */
    fun initiateChallenge() {
        initPaymentResponse?.let {
            val challengeParameter = ChallengeParameter(
                it.acsSignedContent ?: "",
                it.acsReferenceNumber ?: "",
                it.acsTransID ?: "",
                it.threeDSServerTransID ?: "",
                it.payU3DS2MfaParam
            )
            apiCommand = APICommand.ChallengeFlow
            SdkUiInitializer.apiLayer?.initiateChallenge(
                challengeParameter,
                this
            )
        }
    }

    /**
     * Method to generate post data required for fallback flow
     */
    fun generateFallbackData() {
        SdkUiInitializer.apiLayer?.generateFallbackPostData(
            HashCommand.PaymentHash,
            this,
            object : FallbackPostDataListener {
                override fun onFallbackPostDataGenerated(fallbackPostData: String?) {
                    showProgressDialog.postValue(false)
                    postData.postValue(fallbackPostData)
                }
            })
    }

    private fun sendFailureCallback() {
        showProgressDialog.postValue(false)
        SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_AREQ,
            LoggingConstants.FAILED,TRANSACTION_FAILED, SDK_RESPONSE_STATUS_CODE_1)
        SdkUiInitializer.paymentCallback!!.onError(
            SDK_RESPONSE_STATUS_CODE_1,
            TRANSACTION_FAILED
        )
        SdkUiInitializer.apiLayer?.clean()
    }

    fun schemeNotSupportedError() {
        SdkUiInitializer.apiLayer?.logDataFailure(LoggingConstants.PAYU_CARDS_BIN_INFO,
            LoggingConstants.FAILED,PayU3DS2ErrorConstants.SCHEME_NOT_RECOGNISED_ERROR_MESSAGE, CARD_SCHEME_NOT_SUPPORTED_ERROR_CODE)
        SdkUiInitializer.paymentCallback!!.onError(
            CARD_SCHEME_NOT_SUPPORTED_ERROR_CODE,
            PayU3DS2ErrorConstants.SCHEME_NOT_RECOGNISED_ERROR_MESSAGE,
        )
        SdkUiInitializer.apiLayer?.clean()
        showProgressDialog.value = false
    }

    override fun mfaRegistrationStatus(response: Any?) {
        val mfaRegistrationStatus = response as? PayU3DS2MFAResponse
        showProgressDialog.postValue(false)
        SdkUiInitializer.apiLayer?.logMessageSuccess("mfaRegistrationStatus",
            LoggingConstants.SUCCESS,mfaRegistrationStatus?.toJSONString())
        SdkUiInitializer.paymentCallback?.mfaRegistrationStatus(mfaRegistrationStatus?.toJSONString())
    }

}