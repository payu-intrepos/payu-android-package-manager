package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.enums.FontName

class TextBoxCustomisation(builder: Builder) {
    var textColor: String? = null
        private set
    var textFontName: FontName? = null
        private set
    var borderColor: String? = null
        private set
    var borderWidth: Int? = null
        private set
    var cornerRadius: Int? = null
        private set
    var textFontSize: Int? = null
        private set

    init {
        this.textColor = builder.textColor
        this.textFontName = builder.textFontName
        this.borderColor = builder.borderColor
        this.borderWidth = builder.borderWidth
        this.cornerRadius = builder.cornerRadius
        this.textFontSize = builder.textFontSize
    }

    class Builder {
        internal var textColor: String? = null
        internal var textFontName: FontName? = null
        internal var borderColor: String? = null
        internal var borderWidth: Int? = null
        internal var cornerRadius: Int? = null
        internal var textFontSize: Int? = null

        fun setTextColor(textColor: String?): Builder {
            this.textColor = textColor
            return this
        }

        fun setTextFontName(textFontName: FontName?): Builder {
            this.textFontName = textFontName
            return this
        }

        fun setBorderColor(borderColor: String?): Builder {
            this.borderColor = borderColor
            return this
        }

        fun setBorderWidth(borderWidth: Int?): Builder {
            this.borderWidth = borderWidth
            return this
        }

        fun setCornerRadius(cornerRadius: Int?): Builder {
            this.cornerRadius = cornerRadius
            return this
        }

        fun setTextFontSize(textFontSize: Int?): Builder {
            this.textFontSize = textFontSize
            return this
        }

        fun build(): TextBoxCustomisation {
            return TextBoxCustomisation(this)
        }
    }
}