package com.payu.threedsui.utils

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.appcompat.widget.AppCompatImageView
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.payu.threedsui.R


class PayUDialog(context: Context) : Dialog(
    context,
    androidx.appcompat.R.style.Theme_AppCompat_Light_NoActionBar
) {

    init {
        val mInflater = LayoutInflater.from(context)
        val layout = mInflater.inflate(R.layout.threeds_payu_custom_progress_dialog, null, false)
        setContentView(layout)
        val ivProgress = layout.findViewById(R.id.payu_progress_loader) as AppCompatImageView
        ivProgress.applyLoopingAnimatedVectorDrawable(R.drawable.payu_threeds_payu_logo)
        setCancelable(true)
        setCanceledOnTouchOutside(false)
        initializePayment(true)
    }

    fun initializePayment(showText : Boolean) {

        val textView = findViewById<TextView>(R.id.dialog_title_txt)
        if(!showText){
            textView.visibility = View.INVISIBLE
        }
        val handler = Handler(Looper.getMainLooper())
        var count = 0

        val runnable = object : Runnable {
            override fun run() {
                count = (count + 1) % 4

                // Use a Spannable to make trailing dots transparent
                val base = "Initiating Payment"
                val fullText = "$base..."
                val spannable = SpannableString(fullText)

                // Set transparency for dots that shouldn't be "visible" yet
                // Start index is base length + current count
                spannable.setSpan(
                    ForegroundColorSpan(Color.TRANSPARENT),
                    base.length + count,
                    fullText.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                textView.text = spannable
                handler.postDelayed(this, 500)
            }
        }
        handler.post(runnable)
    }

    private fun AppCompatImageView.applyLoopingAnimatedVectorDrawable(@DrawableRes avdResId: Int) {
        val animated = AnimatedVectorDrawableCompat.create(
            context,
            avdResId
        )
        animated?.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                this@applyLoopingAnimatedVectorDrawable.post { animated.start() }
            }
        })
        this.setImageDrawable(animated)
        animated?.start()
    }


}