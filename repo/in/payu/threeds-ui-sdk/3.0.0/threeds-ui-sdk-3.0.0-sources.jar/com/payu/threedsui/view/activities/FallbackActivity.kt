package com.payu.threedsui.view.activities

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.payu.otpparser.OtpCallback
import com.payu.otpparser.OtpParser
import com.payu.threedsbase.constants.APIConstants
import com.payu.threedsbase.constants.APIConstants.Companion.CB_URL
import com.payu.threedsbase.constants.APIConstants.Companion.TEXT_HTML
import com.payu.threedsbase.constants.APIConstants.Companion.UTF_8
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.ERROR_WHILE_LOADING_PAGE
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.threedsbase.constants.PayU3DS2ErrorConstants.Companion.USER_CANCELLED_ERROR_MESSAGE
import com.payu.threedsui.R
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.constants.UIConstant.Companion.JAVASCRIPT
import com.payu.threedsui.utils.UIUtils
import com.payu.threedsui.utils.Utils
import com.payu.threedsui.webivew.PayU3DS2WebInterface
import com.payu.threedsui.webivew.PayUWebChromeClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import androidx.core.net.toUri

class FallbackActivity : AppCompatActivity(), OtpCallback, PayUJSCallback, (String?) -> Unit {
    private var webView: WebView? = null
    private var alertDialog: AlertDialog? = null
    private var mBankJS: JSONObject? = null
    private var otpParser: OtpParser? = null
    private var postDataForIssuer: String? = null
    private var isAutoRead = false
    private var isAutoFill = false
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO)

    private var surl: Uri? = null
    private var furl: Uri?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTheme()
        setContentView(R.layout.activity_fallback)

        val toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        toolbar.title = resources.getString(R.string.threeds_secure_checkout)
        toolbar.setNavigationOnClickListener {
            confirmationDialog()
        }
        webView = findViewById(R.id.wv_webView)
        webView?.let {
            it.settings.javaScriptEnabled = true

            val payUOtpAssistWebInterface = PayU3DS2WebInterface(this, this)
            webView?.addJavascriptInterface(
                payUOtpAssistWebInterface, APIConstants.WEBVIEW_INTERFACE
            )
            it.webChromeClient = PayUWebChromeClient()
        }
        setCollectWebViewSettings()
        getInitializeJS()
        intent?.extras?.getBoolean(APIConstants.AUTO_READ)?.let {
            isAutoRead = it
        }
        UIUtils.hideKeyboard(this)
        validateParams()

        if (postDataForIssuer.isNullOrEmpty().not())
            startPayment(postDataForIssuer)
        else if (!intent?.extras?.getString(APIConstants.ACS_TEMPLATE)
                .isNullOrEmpty()
        ) {
            navigateToBankPageView(true)
        }

    }

    private fun validateParams() {
        postDataForIssuer = intent?.extras?.getString(APIConstants.POST_DATA)
        val acsTemplate = intent?.extras?.getString(APIConstants.ACS_TEMPLATE)
        getParamsFromIntent(
            if (postDataForIssuer.isNullOrEmpty().not()) {
                postDataForIssuer
            } else null
        )
        if (postDataForIssuer.isNullOrEmpty() &&
            acsTemplate
                .isNullOrEmpty()
        ) {
            SdkUiInitializer.paymentCallback?.onError(
                SDK_RESPONSE_STATUS_CODE_1, PayU3DS2ErrorConstants.ACS_DATA_MISSING
            )
            finish()
        }
        if (surl == null) {
            SdkUiInitializer.paymentCallback?.onError(
                SDK_RESPONSE_STATUS_CODE_1, PayU3DS2ErrorConstants.SURL_MISSING
            )
            finish()
        }
        if (furl == null) {
            SdkUiInitializer.paymentCallback?.onError(
                SDK_RESPONSE_STATUS_CODE_1, PayU3DS2ErrorConstants.FURL_MISSING
            )
            finish()
        }
    }

    private fun initTheme() {
        setTheme(R.style.AppTheme_NoActionBar)
    }

    private fun startPayment(postData: String?) {
        if (UIUtils.isInternetAvailable(applicationContext)) {
            postDataForIssuer = postData
            navigateToBankPageView(false)
        } else {
            SdkUiInitializer.paymentCallback?.onError(
                SDK_RESPONSE_STATUS_CODE_1, PayU3DS2ErrorConstants.NO_INTERNET_ERROR
            )
        }
    }

    private fun navigateToBankPageView(isAcsTemplate: Boolean) {
        webView?.visibility = View.VISIBLE
        window.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        setTheme(R.style.PayU_Opaque_Screen)
        if (isAcsTemplate) {
            val acsTemplate = Utils.getBase64DecodedString(
                intent.extras?.getString(APIConstants.ACS_TEMPLATE)
            )
            acsTemplate?.let { webView?.loadData(acsTemplate, TEXT_HTML, UTF_8) }
        } else {
            postDataForIssuer?.toByteArray()?.let {
                if (SdkUiInitializer.apiLayer?.config?.isProduction == true)
                    webView?.postUrl(APIConstants.SECURE_URL, it)
                else
                    webView?.postUrl(APIConstants.UAT_SECURE_URL, it)
            }
        }
    }

    private fun getInitializeJS() {
        if (UIUtils.isInternetAvailable(applicationContext)) {
            Thread {
                val fileName = APIConstants.INITIALIZE
                val strURL: String =
                    CB_URL + fileName + APIConstants.JS_EXTENSION
                SdkUiInitializer.apiLayer?.getBankJS(strURL)
                try {
                    mBankJS = JSONObject(Utils.decodeContents(openFileInput(fileName)))
                } catch (e: Exception) {
                    SdkUiInitializer.apiLayer?.logData(
                        LoggingConstants.THREEDS_WEBVIEW,
                        e.message.toString()
                    )
                    Log.d("Exception", "" + e.message)
                }
            }.start()

        }
    }

    @SuppressLint("JavascriptInterface", "SetJavaScriptEnabled")
    private fun setCollectWebViewSettings() {
        webView?.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                if (surl?.compareTo(request?.url) == 0
                    || furl?.compareTo(request?.url) == 0) {
                    val delay = intent?.extras?.getInt(APIConstants.MERCHANT_RESPONSE_TIMEOUT) ?: 0
                    if (delay > 0) {
                        return super.shouldOverrideUrlLoading(view, request)
                    } else {
                        sendCallbackOnPageFinish(request?.url)
                        return true
                    }
                } else {
                    return super.shouldOverrideUrlLoading(view, request)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                callJSMethod(APIConstants.CHECK_SUBMIT_BUTTON_AVAILABILITY, null)
                UIUtils.hideKeyboard(this@FallbackActivity)
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
            }

            override fun onReceivedSslError(
                view: WebView?, handler: SslErrorHandler?, error: SslError?
            ) {
                handler?.cancel()
                SdkUiInitializer.paymentCallback?.onError(
                    SDK_RESPONSE_STATUS_CODE_1, ERROR_WHILE_LOADING_PAGE
                )
                finish()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                UIUtils.hideKeyboard(this@FallbackActivity)
                sendCallbackOnPageFinish(Uri.parse(url))
            }
        }
    }


    private fun autoReadOTP(otp: String?) {
        otp?.let {
            val obj = JSONObject()
            obj.put(APIConstants.OTP, otp)
            callJSMethod(APIConstants.FILL_OTP, obj)
            isAutoFill = true

            Handler(Looper.getMainLooper()).post {
                SdkUiInitializer.apiLayer?.setOTP(otp)
            }
        }
    }


    override fun onBackPressed() {
        SdkUiInitializer.apiLayer?.logData(
            LoggingConstants.THREEDS_WEBVIEW,
            LoggingConstants.USER_PRESSED_BACK
        )
        confirmationDialog()
    }

    private fun confirmationDialog() {
        val onClickListener: DialogInterface.OnClickListener =
            DialogInterface.OnClickListener { dialogInterface, i ->
                if (i == -1) {
                    SdkUiInitializer.paymentCallback?.onError(
                        SDK_RESPONSE_STATUS_CODE_1, USER_CANCELLED_ERROR_MESSAGE
                    )
                    otpParser?.lifeCycleOnDestroy()
                    otpParser = null
                    finish()
                } else if (i == -2) {
                    dialogInterface.dismiss()

                }
            }
        if (!isFinishing && !isDestroyed) {
            val builder = UIUtils.getAlertDialog(
                this,
                onClickListener,
                getString(R.string.threeds_payu_yes),
                getString(R.string.threeds_payu_no),
                getString(R.string.threeds_payu_do_you_really_want_to_cancel_the_payment),
                null
            )

            alertDialog = builder.create()
            alertDialog?.show()

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        otpParser?.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        otpParser?.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults[0] == -1)
            SdkUiInitializer.apiLayer?.dismissBottomSheet()

    }

    override fun onUserDenied() {
        SdkUiInitializer.apiLayer?.dismissBottomSheet()
        SdkUiInitializer.apiLayer?.logData(
            LoggingConstants.THREEDS_WEBVIEW,
            LoggingConstants.WEBVIEW_USER_PERMISSION_DENIED
        )
    }

    override fun onOtpReceived(otp: String) {
        if (!otp.trim().isNullOrEmpty()) {
            SdkUiInitializer.apiLayer?.logData(
                LoggingConstants.THREEDS_WEBVIEW,
                LoggingConstants.WEBVIEW_AUTO_READ_OTP
            )
            autoReadOTP(otp)
        }
    }

    override fun hasSubmitButton(hasSubmitButton: Boolean) {
        if (hasSubmitButton) {
            SdkUiInitializer.apiLayer?.logData(
                LoggingConstants.THREEDS_WEBVIEW,
                LoggingConstants.WEBVIEW_SUBMIT_BUTTON_FOUND
            )
            Handler(Looper.getMainLooper()).post {
                if (isAutoRead) {
                    otpParser = OtpParser.getInstance(this)
                    otpParser?.startListening(this)
                    var autoSubmit = false
                    intent?.extras?.getBoolean(APIConstants.AUTO_SUBMIT)?.let {
                        autoSubmit = it
                    }
                    SdkUiInitializer.apiLayer?.showAutoReadBottomSheet(
                        this, true, autoSubmit, this
                    )
                }
            }
        }
    }

    override fun invoke(otp: String?) {
        if (!otp?.trim().isNullOrEmpty()) {
            SdkUiInitializer.apiLayer?.logData(
                LoggingConstants.THREEDS_WEBVIEW,
                "true"
            )
            if (!isAutoFill) {
                val obj = JSONObject()
                obj.put(APIConstants.OTP, otp)
                callJSMethod(APIConstants.FILL_OTP, obj)
            }

            callJSMethod(APIConstants.SUBMIT_OTP, null)
        }
    }

    private fun callJSMethod(methodName: String, data: JSONObject?) {
        SdkUiInitializer.apiLayer?.logData(
            LoggingConstants.THREEDS_WEBVIEW,
            LoggingConstants.JS_CALLED_WITH + " " + methodName
        )
        try {
            if (data == null)
                webView?.post {
                    webView?.loadUrl(
                        "$JAVASCRIPT:" + mBankJS?.optString(methodName)
                            .toString() + "(" + "" + ")"
                    )
                }
            else webView?.post {
                webView?.loadUrl(
                    "$JAVASCRIPT:" + mBankJS?.optString(methodName)
                        .toString() + "(" + data.toString() + ")"
                )
            }
        } catch (e: Exception) {
        }

    }

    private fun getParamsFromIntent(queryString: String?) {
        try {
            val intentSURL = intent?.extras?.getString(APIConstants.SURL)
            val intentFURL = intent?.extras?.getString(APIConstants.FURL)

            if (intentSURL.isNullOrEmpty().not()) {
                surl = intentSURL?.toUri()
            }
            if (intentFURL.isNullOrEmpty().not()) {
                furl = intentFURL?.toUri()
            }
            queryString?.let {
                if (surl == null && furl == null) {
                    val decodedQuery = it.replace("&amp;", "&")
                    val params = decodedQuery.split("&").associate {
                        val (key, value) = it.split("=", limit = 2)
                        key to java.net.URLDecoder.decode(value, "UTF-8")
                    }

                    val tempSurl = params[APIConstants.SURL]
                    if(tempSurl.isNullOrEmpty().not())
                        surl = tempSurl?.toUri()

                    val tempFurl = params[APIConstants.FURL]
                    if(tempFurl.isNullOrEmpty().not())
                        furl = tempFurl?.toUri()
                }
            }
        } catch (e: Exception) {
            SdkUiInitializer.apiLayer?.logData(
                LoggingConstants.SDK_INITIALISATION,
                e.message.toString()
            )
            Log.d("Exception", "" + e.message)
        }
    }

    private fun sendCallbackOnPageFinish(url: Uri?) {
        val isSurl = surl?.compareTo(url) == 0
        val isFurl = furl?.compareTo(url) == 0
        if (isSurl || isFurl) {
            coroutineScope.launch {
                val delay = (intent?.extras?.getInt(APIConstants.MERCHANT_RESPONSE_TIMEOUT) ?: 0).toLong()
                if (delay > 0) { delay(delay) }
                withContext(Dispatchers.Main.immediate) {
                    val status = if (isSurl)
                        APIConstants.SUCCESS
                    else
                        APIConstants.FAILURE
                    if (isSurl) {
                        SdkUiInitializer.paymentCallback?.onPaymentSuccess(
                            JSONObject().put(APIConstants.STATUS, status)
                        )
                    } else {
                        SdkUiInitializer.paymentCallback?.onPaymentFailure(
                            JSONObject().put(APIConstants.STATUS, status)
                        )
                    }
                    finish()
                }
            }
        }
    }
}

interface PayUJSCallback {
    fun hasSubmitButton(hasSubmitButton: Boolean)
}