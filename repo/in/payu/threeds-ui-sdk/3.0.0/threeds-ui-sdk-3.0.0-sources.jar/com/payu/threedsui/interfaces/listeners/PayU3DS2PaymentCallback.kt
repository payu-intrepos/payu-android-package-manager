package com.payu.threedsui.interfaces.listeners

import com.payu.threedsbase.interfaces.listeners.PayUHashGeneratedListener

interface PayU3DS2PaymentCallback : PayU3DS2PaymentBaseCallback {

    fun onPaymentCancel(isTxnInitiated: Boolean)
    fun generateHash(
        map: HashMap<String, String>,
        hashGenerationListener: PayUHashGeneratedListener
    )
}