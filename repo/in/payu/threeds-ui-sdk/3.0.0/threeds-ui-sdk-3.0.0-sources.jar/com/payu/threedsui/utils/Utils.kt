package com.payu.threedsui.utils

import android.util.Base64
import java.io.FileInputStream
import java.io.IOException

object Utils {

    /**
     * should be used to decode initialize.js and bank specific js.
     *
     * @param fileInputStream reference of file input stream
     * @return decoded string.
     */
    fun decodeContents(fileInputStream: FileInputStream): String {
        val decoded = java.lang.StringBuilder()
        try {
            var c: Int
            var i = 0
            while (fileInputStream.read().also { c = it } != -1) {
                if (i % 2 == 0) {
                    decoded.append((c - (i % 5 + 1)).toChar())
                } else {
                    decoded.append((c + (i % 5 + 1)).toChar())
                }
                i++
            }
            fileInputStream.close()
        } catch (e: IOException) {
        }
        return decoded.toString()
    }

    fun getBase64DecodedString(data: String?): String? {
        return try {
            String(Base64.decode(data, Base64.DEFAULT))
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}