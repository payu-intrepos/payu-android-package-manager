package com.payu.threedsui.uiCustomisation.tridentity

class BottomSheetPermissionPopupConfiguration private constructor(builder: Builder) {

    val buttonTextForAllowPermissions: String? = builder.buttonTextForAllowPermissions
    val buttonTextForSkipPermissions: String? = builder.buttonTextForSkipPermissions
    val headerTextForContents: String? = builder.headerTextForContents
    val subTextForContents: String? = builder.subTextForContents
    val topHeaderText: String? = builder.topHeaderText
    val topSubHeaderText: String? = builder.topSubHeaderText

    class Builder {
        internal var buttonTextForAllowPermissions: String? = null
        internal var buttonTextForSkipPermissions: String? = null
        internal var headerTextForContents: String? = null
        internal var subTextForContents: String? = null
        internal var topHeaderText: String? = null
        internal var topSubHeaderText: String? = null

        fun setButtonTextForAllowPermissions(buttonTextForAllowPermissions: String?) = apply { this.buttonTextForAllowPermissions = buttonTextForAllowPermissions }
        fun setButtonTextForSkipPermissions(buttonTextForSkipPermissions: String?) = apply { this.buttonTextForSkipPermissions = buttonTextForSkipPermissions }
        fun setHeaderTextForContents(headerTextForContents: String?) = apply { this.headerTextForContents = headerTextForContents }
        fun setSubTextForContents(subTextForContents: String?) = apply { this.subTextForContents = subTextForContents }
        fun setTopHeaderText(topHeaderText: String?) = apply { this.topHeaderText = topHeaderText }
        fun setTopSubHeaderText(topSubHeaderText: String?) = apply { this.topSubHeaderText = topSubHeaderText }

        fun build(): BottomSheetPermissionPopupConfiguration {
            return BottomSheetPermissionPopupConfiguration(this)
        }
    }
}