package com.payu.threedsui.uiCustomisation

class FontFamilyCustomisation(builder: Builder) {
    var headerFontFamily: String? = null
        private set
    var subTextFontFamily: String? = null
        private set

    init {
        this.headerFontFamily = builder.headerFontFamily
        this.subTextFontFamily = builder.subTextFontFamily
    }

    class Builder {
        internal var headerFontFamily: String? = null
        internal var subTextFontFamily: String? = null

        fun setHeaderFontFamily(headerFontFamily: String?): Builder {
            this.headerFontFamily = headerFontFamily
            return this
        }

        fun setSubTextFontFamily(subTextFontFamily: String?): Builder {
            this.subTextFontFamily = subTextFontFamily
            return this
        }

        fun build(): FontFamilyCustomisation {
            return FontFamilyCustomisation(this)
        }
    }

}