package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.enums.ButtonTextCaseType

class BottomSheetCustomisation(builder: Builder) {
    var buttonBackgroundColor: String? = null
        private set
    var textFontColor: String? = null
        private set
    var cornerRadius: Int? = null
        private set
    var textFontSize: Int? = null
        private set
    var labelTextFontSize: Int? = null
        private set
    var headingTextFontSize: Int? = null
        private set
    var textCaseType: ButtonTextCaseType? = null
        private set
    var resendTextFontColor: String? = null
        private set

    init {
        this.buttonBackgroundColor = builder.buttonBackgroundColor
        this.cornerRadius = builder.cornerRadius
        this.textCaseType = builder.textCaseType
        this.textFontSize = builder.textFontSize
        this.textFontColor = builder.textFontColor
        this.labelTextFontSize = builder.labelTextFontSize
        this.headingTextFontSize = builder.headingTextFontSize
        this.resendTextFontColor = builder.resendTextFontColor
    }

    class Builder {
        internal var buttonBackgroundColor: String? = null
        internal var cornerRadius: Int? = null
        internal var textCaseType: ButtonTextCaseType? = null
        internal var textFontSize: Int? = null
        internal var textFontColor: String? = null
        internal var labelTextFontSize: Int? = null
        internal var headingTextFontSize: Int? = null
        internal var resendTextFontColor: String? = null

        fun setButtonBackgroundColor(buttonBackgroundColor: String?): Builder {
            this.buttonBackgroundColor = buttonBackgroundColor
            return this
        }

        fun setCornerRadius(cornerRadius: Int?): Builder {
            this.cornerRadius = cornerRadius
            return this
        }

        fun setTextCaseType(textCaseType: ButtonTextCaseType?): Builder {
            this.textCaseType = textCaseType
            return this
        }

        fun setTextFontSize(textFontSize: Int?): Builder {
            this.textFontSize = textFontSize
            return this
        }

        fun setTextFontColor(textFontColor: String?): Builder {
            this.textFontColor = textFontColor
            return this
        }

        fun setLabelTextFontSize(labelTextFontSize: Int?): Builder {
            this.labelTextFontSize = labelTextFontSize
            return this
        }

        fun setHeadingTextFontSize(headingTextFontSize: Int?): Builder {
            this.headingTextFontSize = headingTextFontSize
            return this
        }

        fun setResendTextFontColor(resendTextFontColor: String?): Builder {
            this.resendTextFontColor = resendTextFontColor
            return this
        }

        fun build(): BottomSheetCustomisation {
            return BottomSheetCustomisation(this)
        }
    }
}