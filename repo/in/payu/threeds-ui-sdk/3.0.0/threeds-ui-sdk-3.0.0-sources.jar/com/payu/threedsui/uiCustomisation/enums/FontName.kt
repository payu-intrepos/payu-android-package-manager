package com.payu.threedsui.uiCustomisation.enums

enum class FontName {
    ROBOTO_REGULAR,
    ROBOTO_MEDIUM
}