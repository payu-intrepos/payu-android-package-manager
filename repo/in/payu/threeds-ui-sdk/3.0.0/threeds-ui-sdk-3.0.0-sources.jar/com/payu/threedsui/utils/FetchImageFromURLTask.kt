package com.payu.threedsui.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL


class FetchImageFromURLTask: AsyncTask<String?, Void?, Bitmap?>() {

    override fun doInBackground(vararg url: String?): Bitmap? {
        val stringUrl = URL(url[0])
        var connection: HttpURLConnection? = null
        return try {
            connection = stringUrl.openConnection() as HttpURLConnection
            connection.connect()
            BitmapFactory.decodeStream(connection.inputStream)
        } catch (e: Exception) {
            Log.d(FetchImageFromURLTask::class.simpleName,"Exception while Fetching Image : " + e.message)
            return null
        } finally {
            connection?.disconnect()
        }
    }
}
