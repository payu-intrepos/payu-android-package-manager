package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.enums.ButtonTextCaseType

class ButtonCustomisation(builder: Builder) {
    var backgroundColor: String? = null
        private set
    var cornerRadius: Int? = null
        private set
    var textCaseType: ButtonTextCaseType? = null
        private set
    var textFontColor: String? = null
        private set
    var textFontSize: Int? = null
        private set
    var resendTextFontColor: String? = null
        private set

    init {
        this.backgroundColor = builder.backgroundColor
        this.cornerRadius = builder.cornerRadius
        this.textCaseType = builder.textCaseType
        this.textFontColor = builder.textFontColor
        this.textFontSize = builder.textFontSize
        this.resendTextFontColor = builder.resendTextFontColor
    }

    class Builder {
        internal var backgroundColor: String? = null
        internal var cornerRadius: Int? = null
        internal var textCaseType: ButtonTextCaseType? = null
        internal var textFontColor: String? = null
        internal var textFontSize: Int? = null
        internal var resendTextFontColor: String? = null

        fun setBackgroundColor(backgroundColor: String?): Builder {
            this.backgroundColor = backgroundColor
            return this
        }

        fun setCornerRadius(cornerRadius: Int?): Builder {
            this.cornerRadius = cornerRadius
            return this
        }

        fun setTextCaseType(textCaseType: ButtonTextCaseType?): Builder {
            this.textCaseType = textCaseType
            return this
        }

        fun setTextFontColor(textFontColor: String?): Builder {
            this.textFontColor = textFontColor
            return this
        }

        fun setTextFontSize(textFontSize: Int?): Builder {
            this.textFontSize = textFontSize
            return this
        }

        fun setResendTextFontColor(resendTextFontColor: String?): Builder {
            this.resendTextFontColor = resendTextFontColor
            return this
        }

        fun build(): ButtonCustomisation {
            return ButtonCustomisation(this)
        }
    }
}

