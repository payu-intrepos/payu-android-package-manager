package com.payu.threedsui.view.activities.bottomsheets

import android.animation.ValueAnimator
import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.payu.threedsbase.constants.LoggingConstants
import com.payu.threedsui.R
import com.payu.threedsui.SdkUiInitializer
import com.payu.threedsui.constants.UIConstant
import com.payu.threedsui.uiCustomisation.UICustomisation
import com.payu.threedsui.utils.UIUtils

class DeRegistrationBottomSheet(
    private val context: Context,
    private val themeConfig: UICustomisation?,
    private val bankLogo: String?,
    private val errorCode: Int?,
    private val errorMsg: String?,
    private val onProceedAction: () -> Unit
) : FixedRoundedCornerBottomSheet() {

    val tagName: String = this::class.java.simpleName

    private var tvAutoRedirect: TextView? = null
    private var redirectTimer: CountDownTimer? = null
    private var fillAnimator: ValueAnimator? = null
    private var btnFillView: View? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI(view)
    }

    override fun getTheme(): Int = R.style.PayU_AuthSelectionBottomSheetDialog

    private fun initUI(view: View) {
        val btnGotIt: View = view.findViewById(R.id.btn_got_it)
        val btnGotItText: TextView = view.findViewById(R.id.btn_got_it_text)
        val tvMsg: TextView = view.findViewById(R.id.lbl_msg)
        val tvUseFingerprintMsg: TextView = view.findViewById(R.id.lbl_use_fingerprint)
        val ivFingerprint: ImageView = view.findViewById(R.id.ivFingerprint)
        btnFillView = view.findViewById(R.id.btn_redirect_fill)
        tvAutoRedirect = view.findViewById(R.id.tv_auto_redirecting)
        handleBackPress()
        if (!errorMsg.isNullOrBlank()) {
            tvMsg.text = errorMsg
        }

        // Apply button customizations
        themeConfig?.buttonCustomisation?.let { buttonConfig ->
            UIUtils.applyProgressButtonStyle(btnGotIt, btnFillView, buttonConfig)
            UIUtils.applyButtonTextStyle(btnGotItText, buttonConfig)
        }
        // Apply font customizations
        themeConfig?.fontFamilyCustomisation?.let { fontConfig ->
            fontConfig.headerFontFamily?.takeIf { it.isNotEmpty() }?.let { fontPath ->
                val typeface = UIUtils.typeface(context, fontPath)
                btnGotItText.typeface = typeface
                tvUseFingerprintMsg.typeface = typeface
            }
            fontConfig.subTextFontFamily?.takeIf { it.isNotEmpty() }?.let { fontPath ->
                val typeface = UIUtils.typeface(context, fontPath)
                tvAutoRedirect?.typeface = typeface
                tvMsg.typeface = typeface
            }
        }

        themeConfig?.labelCustomisation?.let { labelConfig ->
            UIUtils.applyLabelHeadingStyle(tvUseFingerprintMsg, labelConfig = labelConfig)
            UIUtils.applyLabelTextStyle(tvMsg, labelConfig = labelConfig)
            tvAutoRedirect?.let { UIUtils.applyLabelTextStyle(it, labelConfig = labelConfig) }
        }



        startRedirectTimer()

        btnGotIt.setOnClickListener {
            logDeregisterEvent(
                LoggingConstants.AUTO_DEREGISTRATION_UI_CONFIRM_TAPPED,
                LoggingConstants.AUTO_DEREGISTRATION_UI_CONFIRM_TAPPED_MESSAGE
            )
            onProceedAction()
            dismissScreen()
        }

        logBiometricAutoDisabledScreenViewed()
    }

    private fun startRedirectTimer() {
        redirectTimer = UIUtils.getCountDownTimer(
            timeout = UIConstant.DE_REGISTERED_CONFIRMATION_TIMEOUT,
            interval = 1000L,
            onFinish = {
                logDeregisterEvent(
                    LoggingConstants.AUTO_DEREGISTRATION_UI_TIMER_EXPIRED,
                    LoggingConstants.AUTO_DEREGISTRATION_UI_TIMER_EXPIRED_MESSAGE
                )
                onProceedAction()
                dismissScreen()
            },
            onInterval = { millisUntilFinished ->
                val seconds = (millisUntilFinished / 1000).toString()
                tvAutoRedirect?.text = context.getString(R.string.threeds_payu_auto_redirecting, seconds)
            }
        )
        redirectTimer?.start()
        startFillAnimation(UIConstant.DE_REGISTERED_CONFIRMATION_TIMEOUT)
    }

    private fun startFillAnimation(durationMs: Long) {
        val fillView = btnFillView ?: return
        fillView.post {
            fillAnimator?.cancel()
            fillAnimator = UIUtils.animateFillWidth(fillView, durationMs)
        }
    }

    private fun handleBackPress() {
        dialog?.setOnKeyListener { _, keyCode, _ ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                logDeregisterEvent(
                    LoggingConstants.AUTO_DEREGISTRATION_UI_BACK_PRESSED,
                    LoggingConstants.AUTO_DEREGISTRATION_UI_BACK_PRESSED_MESSAGE
                )
                return@setOnKeyListener true
            }
            false
        }
    }

    private fun logDeregisterEvent(eventValue: String, message: String? = null) {
        SdkUiInitializer.apiLayer?.logDataFailure(
            LoggingConstants.PAYU_CARDS_DEREGISTER,
            eventValue,
            "$errorCode $errorMsg",
            errorCode
        )
    }

    private fun logBiometricAutoDisabledScreenViewed() {

        SdkUiInitializer.apiLayer?.logDataWithAdditionalKeys(
            LoggingConstants.PAYU_CARDS_DEREGISTER,
            LoggingConstants.BIOMETRIC_AUTO_DISABLED_SCREEN_VIEWED,
            additionalKeys = mapOf(
                LoggingConstants.KEY_BIOMETRIC_TYPE to LoggingConstants.BIOMETRIC_TYPE_FINGERPRINT,
                LoggingConstants.KEY_DISABLE_REASON to errorMsg.orEmpty(),
                LoggingConstants.ERROR_CODE to errorCode.toString()
            )
        )
    }

    private fun dismissScreen() {
        redirectTimer?.cancel()
        fillAnimator?.cancel()
        dismiss()
    }

    override fun dismiss() {
        redirectTimer?.cancel()
        fillAnimator?.cancel()
        super.dismiss()
    }

    override fun getLayoutId() = R.layout.de_registration_layout
}
