package com.payu.threedsui.uiCustomisation

import com.payu.threedsui.uiCustomisation.enums.FontName

class ToolbarCustomisation(builder: Builder) {
    var backgroundColor: String? = null
        private set
    var textColor: String? = null
        private set
    var buttonText: String? = null
        private set
    var textFontName: FontName? = null
        private set
    var headerText: String? = null
        private set
    var textFontSize: Int? = null
        private set

    init {
        this.backgroundColor = builder.backgroundColor
        this.textColor = builder.textColor
        this.buttonText = builder.buttonText
        this.textFontName = builder.textFontName
        this.headerText = builder.headerText
        this.textFontSize = builder.textFontSize
    }

    class Builder {
        internal var backgroundColor: String? = null
        internal var textColor: String? = null
        internal var buttonText: String? = null
        internal var textFontName: FontName? = null
        internal var headerText: String? = null
        internal var textFontSize: Int? = null

        fun setBackgroundColor(backgroundColor: String?): Builder {
            this.backgroundColor = backgroundColor
            return this
        }

        fun setTextColor(textColor: String?): Builder {
            this.textColor = textColor
            return this
        }

        fun setButtonText(buttonText: String?): Builder {
            this.buttonText = buttonText
            return this
        }

        fun setTextFontName(textFontName: FontName?): Builder {
            this.textFontName = textFontName
            return this
        }

        fun setHeaderText(headerText: String?): Builder {
            this.headerText = headerText
            return this
        }

        fun setTextFontSize(textFontSize: Int?): Builder {
            this.textFontSize = textFontSize
            return this
        }

        fun build(): ToolbarCustomisation {
            return ToolbarCustomisation(this)
        }
    }

}