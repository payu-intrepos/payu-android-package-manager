package com.payu.threedsui.uiCustomisation.tridentity

class BottomSheetFailureScreenConfiguration private constructor(builder: Builder) {

      val buttonText: String? = builder.buttonText
      val headerTextForContents: String? = builder.headerTextForContents
      val subTextForContents: String? = builder.subTextForContents

    class Builder {
        internal var buttonText: String? = null
        internal var headerTextForContents: String? = null
        internal var subTextForContents: String? = null

        fun setButtonText(buttonText: String?) = apply { this.buttonText = buttonText }
        fun setHeaderTextForContents(headerTextForContents: String?) = apply { this.headerTextForContents = headerTextForContents }
        fun setSubTextForContents(subTextForContents: String?) = apply { this.subTextForContents = subTextForContents }

        fun build(): BottomSheetFailureScreenConfiguration {
            return BottomSheetFailureScreenConfiguration(this)
        }
    }
}