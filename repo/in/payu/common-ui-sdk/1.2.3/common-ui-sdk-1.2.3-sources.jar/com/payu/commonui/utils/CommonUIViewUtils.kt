package com.payu.commonui.utils

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat

object CommonUIViewUtils {
    fun updateTextColor(context: Context, view: TextView?, color: String?, defaultColor: Int) {
        if (!color.isNullOrEmpty() && HexColorValidator.validate(color))
            view?.setTextColor(Color.parseColor(color))
        else
            view?.setTextColor(ContextCompat.getColor(context, defaultColor))
    }

    fun updateBackgroundColor(context: Context, view: View?, color: String?, defaultColor: Int) {
        if (!color.isNullOrEmpty() && HexColorValidator.validate(color)
            && view != null && view.background != null
        ) {
            val unwrappedDrawable: Drawable? =
                view.background
            val wrappedDrawable: Drawable = DrawableCompat.wrap(unwrappedDrawable!!)
            wrappedDrawable.mutate()
            DrawableCompat.setTint(wrappedDrawable, Color.parseColor(color))
        } else {
            val unwrappedDrawable: Drawable? =
                view?.background
            unwrappedDrawable?.let {
                val wrappedDrawable: Drawable = DrawableCompat.wrap(unwrappedDrawable)
                wrappedDrawable.mutate()
                DrawableCompat.setTint(wrappedDrawable, context.resources.getColor(defaultColor))
            }
        }
    }

    fun enableView(view: View?) {
        view?.alpha = 1f
        view?.isEnabled = true
    }

    fun disableView(view: View?) {
        view?.alpha = 0.5f
        view?.isEnabled = false
    }

    @JvmStatic
    fun updateLayoutSecurity(activity: Activity, isSecure: Boolean) {
        if (isSecure) {
            activity.window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}