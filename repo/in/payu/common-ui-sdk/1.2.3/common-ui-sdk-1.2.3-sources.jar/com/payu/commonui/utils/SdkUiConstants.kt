package com.payu.commonui.utils

object SdkUiConstants {

    const val LAYOUT_ID = "layoutId"
    const val OTHER = "Other"
    const val SKIP = "PayU - Skipped"
}