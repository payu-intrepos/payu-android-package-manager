package com.payu.commonui.view.customViews

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentManager
import com.payu.commonui.R
import com.payu.commonui.model.listeners.OnUserCancellationFeedbackListener
import com.payu.commonui.model.widgets.RoundedCornerBottomSheet
import com.payu.commonui.utils.SdkUiConstants
import com.payu.commonui.utils.CommonUIViewUtils

class UserCancellationFeedbackBottomSheet(
    private val fragmentManager: FragmentManager, val tag: String,
    private val roundedCornerBottomSheet: RoundedCornerBottomSheet
) {

    fun show() {
        roundedCornerBottomSheet.show(fragmentManager, tag)
    }

    class Builder(
        private val context: Context,
        private val fragmentManager: FragmentManager,
        val className: String
    ) :
        RoundedCornerBottomSheet.OnBottomSheetListener {

        private lateinit var btnSubmit: Button
        private lateinit var tvSkip: TextView
        private lateinit var roundedCornerBottomSheet: RoundedCornerBottomSheet
        private lateinit var radioGroup: RadioGroup
        private lateinit var etCancellationDetails: EditText
        private var reasonsList: ArrayList<String>? = ArrayList()
        private var selectedReason: String? = null
        private var feedbackListener: OnUserCancellationFeedbackListener? = null
        private var feebackListSize: Int = -1
        private var isOtherSelected: Boolean = false
        private var primaryColor: String? = null
        private var baseTextColor: String? = null

        fun setDefaultFeedbacksList(
            userCancellationReasonsList: ArrayList<String>? = null,
            isDefaultList: Boolean = false
        ): Builder {
            if (isDefaultList) {
                val deafultList = context.resources.getStringArray(R.array.userCancellationFeedback)
                reasonsList?.addAll(deafultList)
                feebackListSize = reasonsList?.size ?: 0
            } else {
                reasonsList = userCancellationReasonsList
                feebackListSize = userCancellationReasonsList?.size ?: -1
            }
            return this
        }

        fun setFeedbackListener(listener: OnUserCancellationFeedbackListener): Builder {
            this.feedbackListener = listener
            return this
        }

        fun setPrimaryColor(color: String?): Builder {
            this.primaryColor = color
            return this
        }

        fun setBaseTextColor(color: String?): Builder {
            this.baseTextColor = color
            return this
        }

        fun build(): UserCancellationFeedbackBottomSheet {

            roundedCornerBottomSheet = RoundedCornerBottomSheet.newInstance(
                R.layout.user_cancellation_feedback_bottomsheet
            )
            roundedCornerBottomSheet.setListener(this)
            return UserCancellationFeedbackBottomSheet(
                fragmentManager,
                className,
                roundedCornerBottomSheet
            )

        }

        override fun getInflatedView(
            view: View,
            roundedCornerBottomSheet: RoundedCornerBottomSheet
        ) {
            btnSubmit = view.findViewById(R.id.btnSubmit)
            tvSkip = view.findViewById(R.id.tvSkip)
            radioGroup = view.findViewById(R.id.rgUserCancelReasons)
            etCancellationDetails = view.findViewById(R.id.etCancellationDetails)
            populateUserCancellationAdapter()
            addListeners()

            CommonUIViewUtils.disableView(btnSubmit)

            context?.let {
                CommonUIViewUtils.updateBackgroundColor(
                    it,
                    btnSubmit,
                    primaryColor,
                    R.color.one_payu_colorPrimary
                )
            }

            context?.let {
                CommonUIViewUtils.updateTextColor(
                    it,
                    btnSubmit,
                    baseTextColor,
                    R.color.one_payu_baseTextColor
                )
            }

        }

        private fun addListeners() {

            btnSubmit.setOnClickListener {
                roundedCornerBottomSheet?.dismissAllowingStateLoss()
                if (isOtherSelected) {
                    selectedReason = etCancellationDetails.text.toString()
                }
                feedbackListener?.onUserCancellationFeedbackReceived(selectedReason ?: "")
                radioGroup.removeAllViews()
            }

            tvSkip.setOnClickListener {
                roundedCornerBottomSheet?.dismissAllowingStateLoss()
                feedbackListener?.onUserCancellationFeedbackReceived(SdkUiConstants.SKIP)
                radioGroup.removeAllViews()
            }

            etCancellationDetails.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }

                override fun afterTextChanged(s: Editable?) {
                    val updatedString = s.toString().replace(" ","").replace("\n","")
                    if (s.isNullOrEmpty() || updatedString.isEmpty()) {
                        CommonUIViewUtils.disableView(btnSubmit)
                    } else {
                        CommonUIViewUtils.enableView(btnSubmit)
                    }
                }

            })
        }

        /**
         * This function is called after bottomsheet is closed.
         * No action is required when it closes, so it is empty in this case.
         */
        override fun handleBottomSheetClose() {
            feedbackListener?.onUserCancellationFeedbackReceived()
        }

        private fun populateUserCancellationAdapter() {
            if (reasonsList.isNullOrEmpty()) return

            reasonsList!!.forEachIndexed { index, item ->
                val radioButton = RadioButton(context)

                // Set the custom drawable as the button background
                val customDrawable =
                    ContextCompat.getDrawable(context, R.drawable.custom_radio_button)
                radioButton.buttonDrawable = customDrawable

                val checkedColor = if(primaryColor.isNullOrEmpty()) R.color.one_payu_colorPrimary else Color.parseColor(primaryColor)
                val defaultColor =
                    ContextCompat.getColorStateList(context, R.color.payu_color_7B7B7B)
                val checkedColorStateList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    defaultColor?.defaultColor?.let { intArrayOf(checkedColor, it) }
                )

                radioButton.setButtonTintList(checkedColorStateList)

                radioButton.text = item
                radioButton.setTextColor(
                    ContextCompat.getColorStateList(
                        context,
                        R.color.payu_color_7B7B7B
                    )
                )
                // Set layout parameters if needed
                val layoutParams = RadioGroup.LayoutParams(
                    RadioGroup.LayoutParams.WRAP_CONTENT,
                    RadioGroup.LayoutParams.WRAP_CONTENT
                )

                val leftMargin = 0
                val topMargin = 28
                val rightMargin = 0
                val bottomMargin = 28
                layoutParams.setMargins(leftMargin, topMargin, rightMargin, bottomMargin)

                radioButton.setPadding(15,0,0,0)
                radioButton.id = index + 1
                radioButton.layoutParams = layoutParams
                radioButton.isSingleLine = false
                radioGroup.addView(radioButton)
            }

            radioGroup.setOnCheckedChangeListener { group, position ->
                if (position == feebackListSize) {
                    CommonUIViewUtils.disableView(btnSubmit)
                    isOtherSelected = true
                    etCancellationDetails.visibility = View.VISIBLE
                } else {
                    CommonUIViewUtils.enableView(btnSubmit)
                    etCancellationDetails.visibility = View.GONE
                }

                selectedReason = reasonsList!![position - 1]

            }

        }

    }

}