package com.payu.commonui.model.listeners

interface OnUserCancellationFeedbackListener {
    fun onUserCancellationFeedbackReceived(reason: String = "")
}