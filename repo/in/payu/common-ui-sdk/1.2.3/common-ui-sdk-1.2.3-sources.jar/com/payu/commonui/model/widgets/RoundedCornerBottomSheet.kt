package com.payu.commonui.model.widgets

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.payu.commonui.R
import com.payu.commonui.utils.SdkUiConstants

class RoundedCornerBottomSheet :
    BottomSheetDialogFragment() {

    var bottomSheetListener: OnBottomSheetListener? = null
    var layoutId: Int? = null

    override fun getTheme(): Int = R.style.PayU_BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.setCanceledOnTouchOutside(false)
        dialog.behavior.apply {
            isHideable = false
        }
        return dialog
    }
    
    fun setListener(bottomSheetListener: OnBottomSheetListener) {
        this.bottomSheetListener = bottomSheetListener
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (bottomSheetListener == null && context is OnBottomSheetListener) {
            this.bottomSheetListener = context
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            layoutId = it.getInt(SdkUiConstants.LAYOUT_ID)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(layoutId!!, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         * @return A new instance of fragment RoundedCornerBottomSheet.
         */
        @JvmStatic
        fun newInstance(layoutId: Int) =
            RoundedCornerBottomSheet().apply {
                arguments = Bundle().apply {
                    putInt(SdkUiConstants.LAYOUT_ID, layoutId)
                }
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bottomSheetListener?.getInflatedView(view, this)
    }

    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
        bottomSheetListener?.handleBottomSheetClose()
    }

    interface OnBottomSheetListener {
        fun getInflatedView(view: View, roundedCornerBottomSheet: RoundedCornerBottomSheet)
        fun handleBottomSheetClose()
    }
}