/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.custombrowser;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.custombrowser";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "7.161.12-alpha";
}
