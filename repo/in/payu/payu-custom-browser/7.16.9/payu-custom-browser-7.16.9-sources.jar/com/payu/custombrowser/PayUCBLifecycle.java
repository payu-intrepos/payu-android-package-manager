package com.payu.custombrowser;


import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.payu.custombrowser.AnalyticsHandler.AnalyticsConstant;
import com.payu.custombrowser.bean.CustomBrowserConfig;
import com.payu.custombrowser.bean.CustomBrowserData;
import com.payu.custombrowser.cbinterface.CbBottomSheetEventListener;
import com.payu.custombrowser.util.CBAnalyticsConstant;
import com.payu.custombrowser.util.CBConstant;
import com.payu.custombrowser.util.CBUtil;
import com.payu.custombrowser.util.L;
import com.payu.custombrowser.util.SharedPreferenceUtil;
import com.payu.custombrowser.util.SnoozeConfigMap;
import com.payu.custombrowser.widgets.PayUProgressDialog;
import com.payu.custombrowser.widgets.SnoozeLoaderView;
import com.payu.custombrowser.widgets.SurePayCancelAsyncTaskHelper;
import com.payu.otpparser.Constants;
import com.payu.otpparser.OtpCallback;
import com.payu.otpparser.OtpParser;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;


public abstract class PayUCBLifecycle extends CustomBrowserMain implements CbBottomSheetEventListener, View.OnClickListener {

    public static int snoozeImageDownloadTimeout;
    //    protected static List<String> whiteListedUrls = new ArrayList<>();
    // Flag to check whether the txn is from normal flow or snooze flow
    private static boolean isFromSnoozeService;
    // Intent action for determining WEBVIEW status
    protected String SNOOZE_GET_WEBVIEW_STATUS_INTENT_ACTION = "webview_status_action";
    // Broadcast receiver for WEBVIEW status updates
    protected BroadcastReceiver snoozeBroadCastReceiver;
    // Bind service for snooze notifications
//    protected SnoozeService snoozeService;
    // snooze broadcast receiver registered
    protected boolean isSnoozeBroadCastReceiverRegistered = false;
    // snooze service bounded
    protected boolean isSnoozeServiceBounded = false;
    // NO. of times snooze will appear during a txn for forward journey
    protected int snoozeCount = 0;
    // NO. of times snooze will appear during a txn for backward journey
    protected int snoozeCountBackwardJourney = 0;
    // Flag for snooze feature
    protected boolean isSnoozeEnabled = true;
    // Slow user warning waitingOTPTimer
    protected CountDownTimer slowUserCountDownTimer;
    // Slow user warning dialog
    protected AlertDialog slowUserWarningDialog;

    protected int snoozeVisibleCountFwdJourney;
    protected int snoozeVisibleCountBackwdJourney;

//    protected CustomBrowserAsyncTask customBrowserAsyncTask;

    // cb blank overlay should appear on click of snooze try later
    View cbBlankOverlay;

    // Flag to keep the snoozeNotificationLaunch status.
    // used in on Resume.
    boolean isSnoozeNotificationLaunched;

    Intent snoozeNotificationIntent;
    public static boolean hasToStart = false;
    protected boolean isRetryNowPressed = false;
    protected boolean isListenerAttached = false;
    //    protected ServiceConnection snoozeServiceConnection = new ServiceConnection() {
//        @Override
//        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
//            SnoozeService.SnoozeBinder snoozeBinder = (SnoozeService.SnoozeBinder) iBinder;
//            snoozeService = snoozeBinder.getSnoozeService();
//        }
//
//        @Override
//        public void onServiceDisconnected(ComponentName componentName) {
//            snoozeService = null;
//        }
//    };
    // snoozeUrlLoadingPercentage
    protected int snoozeUrlLoadingPercentage;//20;
    // percentage of page should load with in snoozeUrlLoadingTimeout
    protected int snoozeUrlLoadingTimeout;//5000;
    //Check instance

    // true - when password is selected from CB. Default value is - false
    boolean pin_selected_flag;
    // choose view hieght
    int chooseActionHeight;
    // check for CB visibility for dynamic CB
    boolean showCB = true;
    // OTP received from message
    String mPassword;
    // waitingOTPTimer for OTP wait
    Timer waitingOTPTimer;
    // Approve OTP click
    Boolean approve_flag = false;
    // Loading is visible on screen
    boolean checkLoading;
    // JsonObject string received by javascript
    String enterOtpParams;
    // sms receiving permission granted
    boolean permissionGranted = true;
    // check for sms receiving permission
    boolean checkedPermission = false;
    // check for permission dialog visiblility
    boolean checkPermissionVisibility;
    // page load complete
    boolean mPageReady = false;
    // OTP button clicked
    boolean SMSOTPClicked = false;
    // dot progress dialog utility
    int[] snoozeLoadPercentageAndTimeOut;

    SnoozeConfigMap snoozeConfigMap;
    private String SNOOZE_BROAD_CAST_MESSAGE = "snooze_broad_cast_message";

    // This variable hold's Living time of Internet Restored window, from JS.
    int mInternetRestoredWindowTTL = 0;

    // By default snooze is enabled
    int surePayDisableStatus = CBConstant.ENABLE_WARN_AND_FAIL_MODE;

    // Analytics coming from js, might logged more than one time,
    // inorder to avoid this multiple logging of same event, using this map.
    protected HashMap<String, String> mAnalyticsMap;
    // To check if rendered data is of S2S Html
    public boolean isS2SHtmlSupport = false;
    //  private Config config;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        activity = getActivity();

        //Default values of CB config
        //auto approve false
        // auto select false
        // store one click none
        // merchant sms permission false
        // magic retry true
        // back button true
        // view port default false

        // reset payuId when transaction is initiated to avoid old payuID
        // cbUtil.resetPayuID(customBrowserConfig);
        surePayS2SPayUId = null;

        isSnoozeEnabled = cbUtil.getBooleanSharedPreferenceDefaultTrue(SNOOZE_ENABLED, activity.getApplicationContext());
        isFromSnoozeService = false;

        snoozeConfigMap = cbUtil.convertToSnoozeConfigMap(SharedPreferenceUtil.getSharedPrefMap(activity, CBConstant.SNOOZE_SHARED_PREF));

        // Setting default snooze config values.
        snoozeLoadPercentageAndTimeOut = snoozeConfigMap.getPercentageAndTimeout(CBConstant.DEFAULT_PAYMENT_URLS);
        snoozeUrlLoadingPercentage = snoozeLoadPercentageAndTimeOut[0];
        snoozeUrlLoadingTimeout = snoozeLoadPercentageAndTimeOut[1];
//        surePayDisableStatus = snoozeLoadPercentageAndTimeOut[2];
        surePayDisableStatus = cbUtil.getSurePayDisableStatus(snoozeConfigMap, CBConstant.DEFAULT_PAYMENT_URLS);

        // Setting up magic retry white listed urls.
//        whiteListedUrls = CBUtil.processAndAddWhiteListedUrls(SharedPreferenceUtil.getStringFromSharedPreference(activity, CBConstant.SP_RETRY_FILE_NAME, CBConstant.SP_RETRY_WHITELISTED_URLS, ""));

        // setup the snoozeImageDownloadTimeout from shared pref. (this value will be used till we get initialize.js)
        snoozeImageDownloadTimeout = SharedPreferenceUtil.getIntFromSharedPreference(activity.getApplicationContext(), CBUtil.CB_PREFERENCE, CBConstant.SNOOZE_IMAGE_DOWNLOAD_TIME_OUT, 0);

        /**
         * Coming from snooze service - lets notify snooze service to kill itself.
         */
//        if (null != snoozeService) {
//            snoozeService.killSnoozeService();
//        }

        // setting the snooze cout.
//        if (null != activity.getIntent().getStringExtra(SENDER) && activity.getIntent().getStringExtra(SENDER).contentEquals(SNOOZE_SERVICE)) {
//            isFromSnoozeService = true;
//        }

        /**
         * Registering snooze broad cast receiver
         */
//        snoozeBroadCastReceiver = new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                if (context != null && activity != null && !activity.isFinishing()) {
//                    // Acknowledge the same message to service
//                    if (intent.hasExtra("broadcaststatus")) {
//                        Intent cbIntent = new Intent(context.getApplicationContext(), CBActivity.class);
//                        cbIntent.putExtra(CBConstant.CB_CONFIG, customBrowserConfig);
//                        //  cbIntent.putExtra(POST_DATA, intent.getExtras().getString(POST_DATA));
//                        cbIntent.putExtra(CBConstant.SENDER, CBConstant.SNOOZE_SERVICE);
//                        //cbIntent.putExtra(POST_URL, intent.getExtras().getString(POST_URL));
//                        cbIntent.putExtra(CBConstant.VERIFICATION_MSG_RECEIVED, true);
//                        cbIntent.putExtra(CBConstant.PAYU_RESPONSE, intent.getExtras().getString(CBConstant.PAYU_RESPONSE));
//                        cbIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                        addEventAnalytics("startActivity", CBAnalyticsConstant.CB_ACTIVITY);
//                        context.startActivity(cbIntent);
//
//                    }
//                    if (intent.hasExtra(SNOOZE_BROAD_CAST_MESSAGE)) {
//                        if (snoozeService != null)
//                            snoozeService.updateWebviewStatus(intent.getStringExtra(SNOOZE_BROAD_CAST_MESSAGE));
//                    }
//
//                    //Analytics events.
//                    if (intent.getBooleanExtra(CBAnalyticsConstant.BROAD_CAST_FROM_SNOOZE_SERVICE, false)) {
//                        addEventAnalytics(intent.getStringExtra(CBAnalyticsConstant.KEY), intent.getStringExtra(CBAnalyticsConstant.VALUE));
//                    }
//
////                    if (intent.hasExtra(CBConstant.SNOOZE_SERVICE_STATUS)) { // Snooze service expired! we need to update snooze dialog with new message!
////                        isSnoozeNotificationLaunched = true;
////                        if (CBActivity.STATE == STATE_PAUSED) {
////                            // Activity is on background, Since service have not identified good internet, we can kill the activity.
////                            // TODO: If we finish the activity, and user click recent app, it will land them on MainActivity.
////                            // activity.finish();
////                        } else if (CBActivity.STATE == STATE_RESUMED) {
////                            // updateSnoozeDialogWithSnoozeServiceStatus();
////                        }
////
////                        updateSnoozeDialogWithSnoozeServiceStatus();
////                    }
//
//                    if (intent.getBooleanExtra(CBConstant.BROADCAST_FROM_SERVICE_UPDATE_UI, false) && intent.hasExtra(CBConstant.IS_FORWARD_JOURNEY)) {
//
//                        if (intent.getStringExtra(CBConstant.KEY).contentEquals(CBConstant.GOOD_NETWORK_NOTIFICATION_LAUNCHED)) {
//                            // wait till activity get resumed, then update the snooze dialog. - continue at the onResume();
//                            isSnoozeNotificationLaunched = true;
//                            snoozeNotificationIntent = intent;
//                        } else {
//                            isSnoozeNotificationLaunched = false;
//                            // kill the window in 5 seconds and start the payment.
//                            killSnoozeWindowAndContinuePayment(intent);
//                        }
//                    }
//                }
//            }
//        };


        cbOnCreate();
        cbUtil.clearCookie(customBrowserConfig);
        initAnalytics(Bank.keyAnalytics);
        pin_selected_flag = false;
        if (activity != null) {
            cbUtil.clearCookie(customBrowserConfig);
            surePayS2SPayUId = null;
            surePayS2Surl = null;
        }
        if (customBrowserConfig != null) {
            addEventAnalytics(CBAnalyticsConstant.SNOOZE_ENABLE_COUNT, "" + customBrowserConfig.getEnableSurePay());
            addEventAnalytics(CBAnalyticsConstant.SNOOZE_MODE_SET_MERCHANT, customBrowserConfig.getSurePayMode() == CustomBrowserConfig.WARN_MODE ? "WARN" : "FAIL");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.activity = (Activity) context;
        if (OtpParser.getInstance(getActivity()) != null) {
            OtpParser.getInstance(getActivity()).lifeCycleOnDestroy();
        }
        otpParser = OtpParser.getInstance(getActivity());
        otpParser.setFragCallback((intent, requestCode) -> startActivityForResult(intent, requestCode));
    }

//    private void updateSnoozeDialogWithSnoozeServiceStatus() {
//        if (null != snoozeDialog && snoozeDialog.isShowing()) { // This case we update the ui.
//            snoozeDialog.cancel();
//            snoozeDialog.dismiss();
//        }
//        if (null != activity && !activity.isFinishing()) {
//            LayoutInflater layoutInflater = activity.getLayoutInflater();
//            View snoozeLayout = layoutInflater.inflate(R.layout.cb_layout_snooze, null);
//
//            ((TextView) snoozeLayout.findViewById(R.id.snooze_header_txt)).setText(getString(R.string.cb_snooze_network_error));
//            // Top right cancel (x) is not required here.
//            snoozeLayout.findViewById(R.id.text_view_cancel_snooze_window).setVisibility(View.GONE);
//            ((TextView) snoozeLayout.findViewById(R.id.text_view_snooze_message)).setText(getString(R.string.cb_snooze_network_down_message));
//            snoozeLayout.findViewById(R.id.snooze_loader_view).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.text_view_retry_message_detail).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.button_retry_transaction).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.button_cancel_transaction).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.t_confirm).setVisibility(View.GONE);
//            snoozeLayout.findViewById(R.id.t_nconfirm).setVisibility(View.GONE);
//            Button goBackButton = (Button) snoozeLayout.findViewById(R.id.button_go_back_snooze);
//            goBackButton.setVisibility(View.VISIBLE);
//            goBackButton.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    activity.finish();
//                }
//            });
//
//            snoozeDialog = new androidx.appcompat.app.AlertDialog.Builder(activity, R.style.cb_snooze_dialog).create();
//            snoozeDialog.setView(snoozeLayout);
////        snoozeDialog.setCancelable(false);
//            snoozeDialog.setCanceledOnTouchOutside(false);
//            snoozeDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface dialogInterface) {
//                    // Here we launch Do you want cancel dialog.
//                    activity.finish();
//                }
//            });
//            snoozeDialog.show();
//        }
//    }

    /**
     * For Backward compability with old CB flow
     */
    public void cbOldOnCreate() {
        bundle = getArguments();
        autoApprove = bundle.getBoolean(AUTO_APPROVE, false);
        autoSelectOtp = bundle.getBoolean(AUTO_SELECT_OTP, false);
        merchantSMSPermission = bundle.getBoolean(MERCHANT_SMS_PERMISSION, false);

        if (Bank.sdkVersion == null || Bank.sdkVersion.equalsIgnoreCase(""))
            Bank.sdkVersion = (getArguments().getString(Bank.SDK_DETAILS));

        if (Bank.transactionID == null || Bank.transactionID.equalsIgnoreCase(""))
            Bank.transactionID = (getArguments().getString(Bank.TXN_ID));

        if (Bank.keyAnalytics == null || Bank.keyAnalytics.equalsIgnoreCase(""))
            Bank.keyAnalytics = (getArguments().getString(Bank.MERCHANT_KEY));


    }

    public void cbOnCreate() {
        if (getArguments() != null && getArguments().containsKey(CB_CONFIG)) {
            customBrowserConfig = CBUtil.getCustomBrowserConfig(getArguments());
            merchantSMSPermission = (customBrowserConfig != null) && customBrowserConfig.getMerchantSMSPermission() == CB_ENABLE_OPTION;
            autoApprove = (customBrowserConfig != null) && customBrowserConfig.getAutoApprove() == CB_ENABLE_OPTION;
            autoSelectOtp = (customBrowserConfig != null) && customBrowserConfig.getAutoSelectOTP() == CB_ENABLE_OPTION;

            if (customBrowserConfig != null) {
                if (Bank.keyAnalytics == null || Bank.keyAnalytics.trim().equals("")) {
                    if (customBrowserConfig.getMerchantKey() != null)
                        Bank.keyAnalytics = customBrowserConfig.getMerchantKey().trim();
                    else
                        Bank.keyAnalytics = "";
                }

                if (Bank.transactionID == null || Bank.transactionID.trim().equals("")) {
                    if (customBrowserConfig.getTransactionID() != null && !customBrowserConfig.getTransactionID().trim().equals(""))
                        Bank.transactionID = customBrowserConfig.getTransactionID();
                    else
                        Bank.transactionID = "123";
                }

                if (Bank.sdkVersion == null || Bank.sdkVersion.trim().equals("")) {
                    if (customBrowserConfig.getSdkVersionName() != null)
                        Bank.sdkVersion = customBrowserConfig.getSdkVersionName().trim();
                    else
                        Bank.sdkVersion = "";
                }
                if (!TextUtils.isEmpty(customBrowserConfig.getSurepayS2Surl()) || !TextUtils.isEmpty(customBrowserConfig.getHtmlData()))
                    isS2SHtmlSupport = true;

            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        // postDataToSurl();
        // view which is inflated
        // For old flow it is cbSlideBarView + cbBaseView
        // for new flow it is cbWebView + cbSlideBarView + cbBaseView
        View cbInflatedView;
        // Custom Browser cbMainView which has the cbSlideBarView and the cbBaseView
        View cbMainView;

//         WebView.setWebContentsDebuggingEnabled(true);

        // condition to handle old integration for CB
        if (cbOldFlow) {
            cbInflatedView = inflater.inflate(R.layout.bankold, container, false);
            cbMainView = cbInflatedView;
            cbInflatedView.bringToFront();
            cbOldFlowOnCreateView();
        } else {
            cbInflatedView = inflater.inflate(R.layout.bank, container, false);
            cbTransparentView = cbInflatedView.findViewById(R.id.trans_overlay);
            cbWebView = (WebView) cbInflatedView.findViewById(R.id.webview);
            cbBlankOverlay = cbInflatedView.findViewById(R.id.cb_blank_overlay);
            cbMainView = cbInflatedView.findViewById(R.id.parent);
            // common review order bar
            cbOnCreateView();
        }
        // reviewOrderLayout = cbInflatedView.findViewById(R.id.payu_review_order);

//        CBUtil.setVariableReflection(CBConstant.MAGIC_RETRY_PAKAGE, BuildConfig.VERSION_NAME, CBConstant.CB_VERSION);


        // cbBaseView - FrameLayout, different cbInflatedView are added to this framelayout, event depend on js.
        cbBaseView = (FrameLayout) cbInflatedView.findViewById(R.id.help_view);
        payuBottomSheetCollapsed = (FrameLayout) cbInflatedView.findViewById(R.id.payuBottomSheetCollapsed);
        flFullScreenLoader = (FrameLayout) cbInflatedView.findViewById(R.id.flFullScreenLoader);

        View loaderView = activity.getLayoutInflater().inflate(R.layout.cb_full_screen_loader, null);
        if (customBrowserConfig != null) {
            if (customBrowserConfig.getProgressDialogCustomView() != null) {
                loaderView = customBrowserConfig.getProgressDialogCustomView();
                ImageView ivProgress = (ImageView) loaderView.findViewById(R.id.payu_progress_loader);
                CBUtil.applyLoopingAnimatedVectorDrawable(ivProgress, this.activity);
            }
        }

        flFullScreenLoader.addView(loaderView);
        cbSlideBarView = cbInflatedView.findViewById(R.id.view);
        cbWebPageProgressBar = PayUProgressDialog.getInstance(activity, null);
        initCBSettings();

        // download initialize.js file
        getInitializeJS();
        // initialize or clear analytics map
        // for every txn we are logging
        mAnalyticsMap = new HashMap<>();

        // touch listener to handle minimise and maximise of the CustomBrowser
        cbMainView.setOnTouchListener(new PayUCBLifeCycleTouchListener());
        return cbInflatedView;
    }


    private void initCBSettings() {
        cbWebView.getSettings().setJavaScriptEnabled(true);
        cbWebView.addJavascriptInterface(this, "PayU");
        cbWebView.getSettings().setSupportMultipleWindows(true);
        cbWebView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                /**
                 * This check is added to detect user's interaction on web page to show Internet not
                 * available message to save their time, to given better UX
                 */
                if (!CBUtil.isNetworkAvailable(activity)) {
                    internetErrorHandler(0, MSG_NO_INTERNET);
                } else {
                    // User is interacting, dismiss slow user warning waitingOTPTimer
                    dismissSlowUserWarningTimerOnTouch();
                    if (cbTransparentView != null)
                        cbTransparentView.setVisibility(View.GONE);
                    if (frameState == MAXIMISED) {
                        minimizeWebviewHeight();
                    }
                }
                return false;
            }
        });

        // improve webView performance
        cbWebView.getSettings().setDomStorageEnabled(true);
        cbWebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        cbWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
//        cbWebView.getSettings().setAppCacheEnabled(false);
        // cbWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        // improve webView performance ends
    }

    public void cbOldFlowOnCreateView() {
        cbWebView = (WebView) activity.findViewById(getArguments().getInt(Bank.WEBVIEW));

        if (Bank.paymentMode != null && Bank.paymentMode.equalsIgnoreCase(NB)) {
            cbWebView.getSettings().setUseWideViewPort(true);
        } else if (customBrowserConfig != null && customBrowserConfig.getViewPortWideEnable() == CB_ENABLE_OPTION) {
            // CustomBrowserData.SINGLETON.getPayuCustomBrowserConfig().getViewPortWideEnable() is 1 when during integration it is set to true
            cbWebView.getSettings().setUseWideViewPort(true);
        }
        cbWebView.setFocusable(true);
        cbWebView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    if (getArguments().getBoolean(BACK_BUTTON, true)) {
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity, R.style.cb_dialog);
                        alertDialog.setCancelable(false);
                        alertDialog.setMessage("Do you really want to cancel the transaction ?");
                        alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                postToPaytxn();
                                addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.BACK_BUTTON_OK_CLICK + "_Ok");
                                dialog.dismiss();
                                onBackApproved();
                                HashMap<String, String> postParams = new CBUtil().getDataFromPostData(customBrowserConfig.getPayuPostData());
                                Bank.amount = postParams.get(CBConstant.AMOUNT);
                                Bank.transactionID = postParams.get(CBConstant.TXN_ID);
                                CBUtil.logBackButton(getContext(), AnalyticsConstant.CB_BACK_BUTTON_CTA, customBrowserConfig.getPaymentType(), true, Bank.amount);
                                // CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onBackApprove();
                                if (customBrowserConfig.isActionBarPresent())activity.finish();
                            }
                        });
                        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.BACK_BUTTON_CANCEL_CLICK + "_Cancel");
                                onBackCancelled();
                                dialog.dismiss();
                                HashMap<String, String> postParams = new CBUtil().getDataFromPostData(customBrowserConfig.getPayuPostData());
                                CBUtil.logBackButton(getContext(), AnalyticsConstant.CB_BACK_BUTTON_CTA, customBrowserConfig.getPaymentType(), false, Bank.amount);
                                //  CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onBackDismiss();
                            }
                        });
                        // CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onBackButton(alertDialog);
                        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.PAYU_BACK_BUTTON_CLICK);
                        onBackPressed(alertDialog);
                        alertDialog.show();

                        return true;
                    } else {
                        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.MERCHANT_BACK_BUTTON_CLICK);
                        onBackPressed(null);
                        activity.onBackPressed();
                    }
                }

                return false;
            }
        });

        if ((Bank.paymentMode != null && Bank.paymentMode.equalsIgnoreCase(NB))
                || (bundle.getBoolean(VIEWPORTWIDE, false))) {
            cbWebView.getSettings().setUseWideViewPort(true);
        }
    }

    public void cbOnCreateView() {

        if (Bank.paymentMode != null && Bank.paymentMode.equalsIgnoreCase(NB)) {
            cbWebView.getSettings().setUseWideViewPort(true);
            cbWebView.getSettings().setLoadWithOverviewMode(true);
        } else if (customBrowserConfig != null && customBrowserConfig.getViewPortWideEnable() == CB_ENABLE_OPTION) {
            cbWebView.getSettings().setUseWideViewPort(true);
            cbWebView.getSettings().setLoadWithOverviewMode(true);
        }

        cbWebView.setWebChromeClient(new PayUWebChromeClient((Bank) this));
        final int enableSurePay = (customBrowserConfig != null) ? customBrowserConfig.getEnableSurePay() : 0;
        if (enableSurePay > 0) {
            // Snooze is enabled use SnoozeWebViewClient
            cbWebView.setWebViewClient(new PayUSurePayWebViewClient((Bank) this, Bank.keyAnalytics));
        } else {
            cbWebView.setWebViewClient(new PayUWebViewClient((Bank) this, Bank.keyAnalytics));
        }
        //If html is set by merchant load html in Webview
        if (customBrowserConfig != null && !TextUtils.isEmpty(customBrowserConfig.getHtmlData())) {
            addEventAnalytics(CBAnalyticsConstant.CB_STATUS, CBAnalyticsConstant.CB_LOAD_HTML);
            cbWebView.loadDataWithBaseURL(CBConstant.PAYMENT_URL, customBrowserConfig.getHtmlData(), "text/html", "UTF-8", null);
        } else if (customBrowserConfig != null && !TextUtils.isEmpty(customBrowserConfig.getSurepayS2Surl())) {
            cbWebView.loadUrl(customBrowserConfig.getSurepayS2Surl());
        } else if (customBrowserConfig != null && customBrowserConfig.getPostURL() != null && customBrowserConfig.getPayuPostData() != null) {
            cbWebView.postUrl(customBrowserConfig.getPostURL(), customBrowserConfig.getPayuPostData().getBytes());
        } else if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null) {
            CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback()
                    .onCBErrorReceived(CBConstant.errorCodes.MISSING_PARAMETER_EXCEPTION,
                            getString(R.string.custombrowserconfig_is_null));
        }

        if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null) {
            CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().setCBProperties(cbWebView, (Bank) this);
        }


//        if (customBrowserConfig != null && customBrowserConfig.getMagicretry() == CB_ENABLE_OPTION) {
//            if (customBrowserConfig.getEnableSurePay() == 0) {
//                initMagicRetry();
//            }
//            if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null) {
//                // TODO Do we need this callback??
//                CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().initializeMagicRetry((Bank) this, cbWebView, magicRetryFragment);
//            }
//        }

        // initialize or clear analytics map
        // for every txn we are logging
        mAnalyticsMap = new HashMap<>();

        // Check if the old webview version is same as the current one.
        String existingWebViewVersion = CBUtil.getWebViewVersionFromSP(getContext());
        if (existingWebViewVersion.length() > 0) { // we already have some webview version,
            if (!existingWebViewVersion.contentEquals(CBUtil.getWebViewVersion(new WebView(getContext())))) {
                addEventAnalytics("web_view_updated_successfully", CBUtil.getWebViewVersion(new WebView(getContext())));
                // clearing webview version.
                CBUtil.setWebViewVersionInSP(getContext(), "");
            }
        }
    }

    // log the event for destroy of fragment
    // events - custom browser / non custom browser, last url , terminate
    public void logOnTerminate() {
        try {

            addEventAnalytics(CBAnalyticsConstant.LAST_URL, CBUtil.updateLastUrl(cbUtil.getStringSharedPreference(activity.getApplicationContext(), CBAnalyticsConstant.LAST_URL)));
        } catch (Exception e) {

        } finally {
            cbUtil.deleteSharedPrefKey(activity.getApplicationContext(), CBAnalyticsConstant.LAST_URL);
        }

        if (null != eventArray && !eventArray.contains(CBAnalyticsConstant.CUSTOM_BROWSER)) {
            if (eventArray.contains(CBAnalyticsConstant.VAL_RO_CUSTOM_BROWSER)) {
                eventRecorded = CBAnalyticsConstant.VAL_RO_CUSTOM_BROWSER;
            } else {
                eventRecorded = CBAnalyticsConstant.NON_CUSTOM_BROWSER;
            }
            addEventAnalytics(CBAnalyticsConstant.CB_STATUS, eventRecorded);
        }

        eventRecorded = CBAnalyticsConstant.TERMINATE_TRANSACTION;
        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);

        if (progressDialog != null && !progressDialog.isShowing())
            progressDialog.dismiss();

//        if (isAdded() &&null!=flFullScreenLoader)
//            flFullScreenLoader.setVisibility(View.GONE);

//        if (mBroadcastReceiver != null) {
//
//            unregisterBroadcast(mBroadcastReceiver);
//            mBroadcastReceiver = null;
//        }

        if (listOfTxtFld != null && listOfTxtFld.length() > 1 && !isOTPFilled) {
            addEventAnalytics(CBAnalyticsConstant.KEY_BANK_PAGE_OTP_FIELDS, listOfTxtFld);
            addEventAnalytics(CBAnalyticsConstant.KEY_BANK_PAGE_HOST_NAME, hostName);
        }
        //Clear CB JS preference
        cbUtil.clearJSStringSharedPreference(activity);

    }

    @Override
    public void onDestroyView() {
        CBUtil.stopLoopingAnimatedVectorDrawable();
        cbUtil.cancelTimer(timerProgress);
        if (snoozeDialog != null && snoozeDialog.isShowing()) {
            snoozeDialog.dismiss();
        }
        if (progressDialog != null) {
            progressDialog.dismiss();
            // checkForInput = 1;
        }
        super.onDestroyView();
//        if (isAdded() &&null!=flFullScreenLoader)
//            flFullScreenLoader.setVisibility(View.GONE);
    }

    public void onDestroy() {
        super.onDestroy();
        cbUtil.cancelTimer(timerProgress);
        cbUtil.cancelTimer(waitingOTPTimer);
        stopListening();
        //        if(customBrowserAsyncTask!=null){
//            customBrowserAsyncTask.cancel(false);
//        }
        // Destroy slowUserCountDownTimer
        if (slowUserCountDownTimer != null) {
            slowUserCountDownTimer.cancel();
        }


        // Snooze Event Analytics
        //  addEventAnalytics(CBAnalyticsConstant.SNOOZE_WINDOW_STATUS,snoozeCount>0?CBAnalyticsConstant.SNOOZE_VISIBLE:CBAnalyticsConstant.SNOOZE_NOT_VISIBLE);

        addEventAnalytics(CBAnalyticsConstant.SNOOZE_COUNT, "" + (snoozeVisibleCountBackwdJourney + snoozeVisibleCountFwdJourney));

        /**
         * If snooze window available then we might need to send the post data to snooze service.
         * Otherwise we dont need config data, because snooze service already has it.
         * CBActivity's onNewIntent will have the post data and current loading url .
         */

        CustomBrowserData.SINGLETON.setPayuCustomBrowserCallback(null);
//        CustomBrowserData.SINGLETON.setPaymentOptionWrapper(null);

        if (snoozeDialog != null && snoozeDialog.isShowing()) {
            snoozeDialog.dismiss();
        }


        if (null != snoozeBroadCastReceiver && isSnoozeBroadCastReceiverRegistered && !isFromSnoozeService) {
            LocalBroadcastManager.getInstance(activity.getApplicationContext()).unregisterReceiver(snoozeBroadCastReceiver);
        }

//        if (null != snoozeServiceConnection && isSnoozeServiceBounded) {
//            activity.unbindService(snoozeServiceConnection);
//        }
//
//        if (null != snoozeService && isFromSnoozeService) {
//            snoozeService.killSnoozeService();
//        }

        if (payuDeviceAnalytics != null) {
            payuDeviceAnalytics.cancelTimer();
        }

        AnalyticsCBInit.getInstance(activity.getApplicationContext()).cancelTimer();

        cbUtil.cancelTimer(waitingOTPTimer);

        if (countDownTimer != null)
            countDownTimer.cancel();

        //testing remove
        logOnTerminate();
        Bank.sdkVersion = null;
        Bank.keyAnalytics = null;
        Bank.transactionID = null;
        Bank.paymentMode = null;
        if (cbWebView != null)
            cbWebView.destroy();
        // reset payuid cookie
        cbUtil.resetPayuID(customBrowserConfig);
        surePayS2SPayUId = null;
    }

    @Override
    public void onResume() {
        super.onResume();

        // If There is snooze notification, kill it and continue payment.
        if (isSnoozeNotificationLaunched) {
            isSnoozeNotificationLaunched = false;
            cancelTransactionNotification();
            if (null != snoozeNotificationIntent) { // we have the intent.
                if (backwardJourneyStarted) {
                    // based on the txn status we need to update the message.
                    String apiResponse = snoozeNotificationIntent.getStringExtra(CBConstant.VALUE);
                    try {
                        int verifyApiStatus;
                        JSONObject jsonObject = new JSONObject(apiResponse);
                        verifyApiStatus = Integer.parseInt(jsonObject.optString(getString(R.string.cb_snooze_verify_api_status)));
                        if (verifyApiStatus == 1) { // success
                            addEventAnalytics(CBAnalyticsConstant.TRANSACTION_VERIFIED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
                        } else { // txn status unknown
                            addEventAnalytics(CBAnalyticsConstant.TRANSACTION_NOT_VERIFIED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
                        }
                    } catch (Exception e) { // Txn status unknown
                        // Removing e.printStackTrace(); as per the security review.
                        addEventAnalytics(CBAnalyticsConstant.TRANSACTION_NOT_VERIFIED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
                    }

                } else { // Forward journey, just one status.
                    // kill the window in 5 seconds and start the payment.
                    addEventAnalytics(CBAnalyticsConstant.INTERNET_RESTORED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
                }
                // For backward journey and forward journey both we use the same method
                killSnoozeWindowAndContinuePayment(snoozeNotificationIntent);
            } else { // Notification intent is null. - sure pay expired and app is in background
                addEventAnalytics(CBAnalyticsConstant.INTERNET_NOT_RESTORED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
            }
        }

    }

    void stopListening() {
        if (isListenerAttached) {
            otpParser.stopListening();
            isListenerAttached = false;
        }
    }

    /**
     * Preparing sms listener.
     * Reads the sms and checks whether its a otp message.
     */
    void prepareSmsListener() {
        if (!isListenerAttached) {
            isListenerAttached = true;
            Bundle bundle = new Bundle();
            bundle.putString(CBAnalyticsConstant.MERCHANT_KEY, customBrowserConfig.getMerchantKey());
            bundle.putString(CBAnalyticsConstant.TRANSACTION_ID, customBrowserConfig.getTransactionID());
            otpParser.startListening(new OtpCallback() {
                @Override
                public void onOtpReceived(@NotNull String otp) {
                    if (!otp.isEmpty()) {
                        mPassword = otp;
                        L.v("onOtpReceived " + mPassword);
                        fillOTPOnBankPage();
                        otp = mPassword;
                        backupOfOTP = otp;
                        otpTriggered = true;
                        otpFetched = otp;
                        try {
                            isOTPFilled = false;
                            if (null != cbBottomSheet && cbBottomSheet.isAdded() && isCbBottomSheetExpanded) {
                                cbBottomSheet.otpFetched(otp);
                            } else {
                                BOTTOM_SHEET_STATUS = CBConstant.MANUAL_OTP;
                                openCollapsedUI();
                            }
                            if (catchAllJSEnabled && !TextUtils.isEmpty(otp)) {
                                JSONObject obj = new JSONObject();
                                obj.put("otp", otp);
                                obj.put("isAutoFillOTP", true);
                                cbWebView.loadUrl("javascript:" + mBankJS.getString(getString(R.string.cb_fill_otp)) + "(" + obj + ")");
                            }
                        } catch (JSONException e) {
                            L.e(e.getMessage());
                        }
                        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBConstant.CB_OTP_RECEIVED);

//                    fillOTP();
                    }
                }

                @Override
                public void onUserDenied() {
                    L.v("onUserDenied permissionGranted " + permissionGranted);
                    addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBConstant.CB_OTP_USERDENIED);
                    permissionGranted = false;
//                    if(SMSOTPClicked)
//                        enter_otp(enterOtpParams);
                    if (null != cbBottomSheet && cbBottomSheet.isAdded() && isCbBottomSheetExpanded)
                        cbBottomSheet.enterManually("");
                    else {
                        otpFetched = "";
                        BOTTOM_SHEET_STATUS = CBConstant.MANUAL_OTP;
                        openCollapsedUI();
                    }


                }
            }, bundle);
        }
//        if (mBroadcastReceiver == null && permissionGranted) {
//            mBroadcastReceiver = new BroadcastReceiver() {
//                @Override
//                public void onReceive(Context context, Intent intent) {
//                    try {
//                        if (mBankJS == null) {
//                            return;
//                        }
//                        Bundle myBundle = intent.getExtras();
//                        if (getActivity() != null && !getActivity().isFinishing()) {
//                            Bundle extras = intent.getExtras();
//                            if (extras != null) {
//                                //Initialise with empty string to avoid concatenation of null
//                                String msgBody = "";
//                                String msgAddress = null;
//                                if(SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())){
//                                    Status status = (Status) extras.get(SmsRetriever.EXTRA_STATUS);
//                                    switch(status.getStatusCode()) {
//                                        case CommonStatusCodes.SUCCESS:
//                                            // Get SMS message contents
//                                            msgBody = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);
//                                            addEventAnalytics(CBAnalyticsConstant.OTP_RECIEVED, CBAnalyticsConstant.SMS_RETRIEVER);
//                                            break;
//                                        case CommonStatusCodes.TIMEOUT:
//                                            // Waiting for SMS timed out (5 minutes)
//                                            // Handle the error ...
//                                            break;
//                                    }
//                                } else {
//                                    // Get received SMS array
//                                    SmsMessage[] msgs;
//                                    Object[] pdus = (Object[]) extras.get("pdus");
//                                    if (pdus != null) {
//                                        msgs = new SmsMessage[pdus.length];
//                                        for (int i = 0; i < msgs.length; i++) {
//                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                                                String format = myBundle.getString("format");
//                                                msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
//                                            } else {
//                                                msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
//                                            }
//                                            //  msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
//                                            msgBody += msgs[i].getMessageBody();
//                                            msgAddress = msgs[i].getDisplayOriginatingAddress();
//                                        }
//                                    }
//                                }
//                                // We have the message!
//                                //filter sms
//                                if(!TextUtils.isEmpty(msgBody)) {
//                                    mPassword = CBUtil.filterSMS(mBankJS, msgBody, activity.getApplicationContext());
//
//                                    // fill otp
//                                    if (mPassword != null && (mPassword.length() >= 6 && mPassword.length() <= 8)) {
////                                    fillOTP(this);
//                                        fillOTPOnBankPage();
//                                        otp = mPassword;
//                                        backupOfOTP = otp;
//                                        otpTriggered = true;
//                                        try {
//                                            isOTPFilled = false;
//                                            if (catchAllJSEnabled && !TextUtils.isEmpty(otp)) {
//                                                JSONObject obj = new JSONObject();
//                                                obj.put("otp", otp);
//                                                obj.put("isAutoFillOTP", true);
//                                                cbWebView.loadUrl("javascript:" + mBankJS.getString(getString(R.string.cb_fill_otp)) + "(" + obj + ")");
//                                            }
//                                        } catch (JSONException e) {
//                                            e.printStackTrace();
//                                        }
//                                        fillOTP();
//                                    } else {
//                                        if (payuPG && !TextUtils.isEmpty(msgAddress))
//                                            verificationMsgReceived = checkConfirmMessage(msgAddress, msgBody);
//                                        if (verificationMsgReceived) {
//                                            addEventAnalytics(CBAnalyticsConstant.SNOOZE_BACKWARD_WINDOW_SMS_RECEIVED, CBAnalyticsConstant.RECEIVED);
//                                        }
//                                    }
//                                }
//                            }
//
//                        }
//                    } catch (Exception e) {
//                    }
//                }
//            };
//            // Register the broadcast receiver
//        }
//        registerBroadcast(mBroadcastReceiver, createFilter());
    }

    public void fillOTPOnBankPage() {
        try {
            if (mJS != null && !TextUtils.isEmpty(mPassword) && mJS.has(getString(R.string.cb_fill_otp))) {
                cbWebView.loadUrl("javascript:" + mJS.getString(getString(R.string.cb_fill_otp)) + "(\"" + mPassword + "\"" + ",\"url\"" + ")");
                mPassword = null;
            }

        } catch (JSONException e) {
            L.e(e.getMessage());
        }
    }


    //    public void registerSMSBroadcast() {
//        // Register the broadcast receiver
////        if (mBroadcastReceiver == null) {
//            prepareSmsListener();
////        } else {
////            registerBroadcast(mBroadcastReceiver, createFilter());
////        }
//    }
//    IntentFilter createFilter(){
//        IntentFilter filter = new IntentFilter();
//        filter.setPriority(9999999);
//        // this condition checks if the user has given us the permission to read sms
//        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
//            filter.addAction("android.provider.Telephony.SMS_RECEIVED");
//        }else {
//            filter.addAction(SmsRetriever.SMS_RETRIEVED_ACTION);
//        }
//        return filter;
//    }
    String getValueFromPostData(String key) {
        String[] list = customBrowserConfig.getPayuPostData().split("&");

        for (String item : list) {
            String[] items = item.split("=");
            if (items.length >= 2) {
                String id = items[0];
                if (id.equalsIgnoreCase(key)) {
                    return items[1];
                }
            }
        }
        return null;
    }


    private boolean checkConfirmMessage(String msgAddress, String msgBody) {
        int count = 0;
        if(msgBody != null)
            msgBody = msgBody.toLowerCase();
        boolean returnValue = false;

        if (null != bankName && msgAddress != null && msgAddress.contains(bankName)) {
            count++;
        }
        if (msgBody != null && msgBody.toLowerCase().contains(getValueFromPostData("amount").replace(",", ""))) {
            count++;
        }

        if (count == 2) {
            returnValue = true;
        }

        /* 1. Verify the bank name from which SMS was received.
                                2. Verify the amount of transaction.
                                3. Look for the following set of keywords:
                                made+purchase
                                account+debited
                                ac+debited
                                a/c+debited
                                tranx+made
                                transaction+made
                                spent
                                Thank+you+using+card+for
                                Spent
                                charge+initiated*/
        if(count > 0 && msgBody != null && !msgBody.isEmpty()) {
            if (msgBody.contains("made") && msgBody.contains("purchase")) {
                returnValue = true;
            } else if (msgBody.contains("account") && msgBody.contains("debited")) {
                returnValue = true;
            } else if (msgBody.contains("ac") && msgBody.contains("debited")) {
                returnValue = true;
            } else if (msgBody.contains("tranx") && msgBody.contains("made")) {
                returnValue = true;
            } else if (msgBody.contains("transaction") && msgBody.contains("made")) {
                returnValue = true;
            } else if (msgBody.contains("spent")) {
                returnValue = true;
            } else if (msgBody.contains("Thank you using card for")) {
                returnValue = true;
            } else if (msgBody.contains("charge") && msgBody.contains("initiated")) {
                returnValue = msgBody.contains("charge") && msgBody.contains("initiated");
            }
        }
        return returnValue;
    }


    /*  public void fillOTP() {
          if (getActivity().findViewById(R.id.otp_sms) != null) {
              final TextView otpSMS = (TextView) getActivity().findViewById(R.id.otp_sms);
              if (showCB && mPassword != null *//*&& otpSMS.getVisibility() != View.VISIBLE*//*) {
                cbUtil.cancelTimer(waitingOTPTimer);
                switch (eventRecorded) {
                    case CBAnalyticsConstant.PAYMENT_INITIATED:
                        eventRecorded = CBAnalyticsConstant.RECEIVED_OTP_DIRECT;

                        break;
                    case CBAnalyticsConstant.OTP:
                        eventRecorded = CBAnalyticsConstant.RECEIVED_OTP_SELECTED;

                        break;
                    case CBAnalyticsConstant.REGENERATE:
                        eventRecorded = CBAnalyticsConstant.RECEIVED_OTP_REGENERATE;

                        break;
                    default:
                        eventRecorded = CBAnalyticsConstant.OTP_WEB;
                        break;
                }
                addEventAnalytics(CBAnalyticsConstant.OTP_RECIEVED, eventRecorded);

                otpSMS.setText(mPassword);
                mPassword = null;
                customProgressBar.removeDialog(getActivity().findViewById(R.id.progress));

                Button approveButton = (Button) getActivity().findViewById(R.id.approve);
                approveButton.setClickable(true);
                CBUtil.setAlpha(1, approveButton);
                approveButton.setVisibility(View.VISIBLE);

                activity.findViewById(R.id.timer).setVisibility(View.GONE);
                activity.findViewById(R.id.retry_text).setVisibility(View.GONE);
                activity.findViewById(R.id.regenerate_layout).setVisibility(View.GONE);
                activity.findViewById(R.id.waiting).setVisibility(View.GONE);
                activity.findViewById(R.id.otp_recieved).setVisibility(View.VISIBLE);
                otpSMS.setVisibility(View.VISIBLE);
                if (autoApprove) {
                    approveButton.performClick();
                    eventRecorded = CBAnalyticsConstant.CB_AUTO_APPROVE;
                    addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);
                }
                approveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            mPassword = null;
                            eventRecorded = CBAnalyticsConstant.APPROVED_OTP;
                            addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);
                            addEventAnalytics(CBAnalyticsConstant.APPROVE_BTN_CLICK_TIME,CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);

                            prepareSmsListener();
                            checkLoading = false;
                            approve_flag = true;
                            onHelpUnavailable();
                            maximiseWebviewHeight();
                            frameState = MINIMISED;
                            if (null!=  otpSMS.getText())
                            cbWebView.loadUrl("javascript:" + mJS.optString(getString(R.string.cb_process_otp)) + "(\"" + otpSMS.getText().toString() + "\")");
                            otpSMS.setText("");
                            hideSoftKeyboard();

                        } catch (Exception e) {
                        }
                    }
                });

                // unregister the broadcast receiver.
                // Commented this as CatchAllJS needs SMS receiver to be active at all time
//                if (mBroadcastReceiver != null) {
//                    mReceiver.abortBroadcast();
//                    unregisterBroadcast(mBroadcastReceiver);
//                    mBroadcastReceiver = null;
//                }
            }
        }
    }*/
    public void approveOtp(String otp) {
        mPassword = null;
        eventRecorded = CBAnalyticsConstant.APPROVED_OTP;
        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);
        addEventAnalytics(CBAnalyticsConstant.APPROVE_BTN_CLICK_TIME, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);

        prepareSmsListener();
        checkLoading = false;
        approve_flag = true;
        onHelpUnavailable();
        maximiseWebviewHeight();
        frameState = MINIMISED;
        if (null != otp && !otp.isEmpty())
            cbWebView.loadUrl("javascript:" + mJS.optString(getString(R.string.cb_process_otp)) + "(\"" + otp + "\")");
        hideSoftKeyboard();
    }

    /**
     * Download initialize.js form payu server.
     */
    private void getInitializeJS() {
        // listen for OTP
//        prepareSmsListener();
        eventRecorded = CBAnalyticsConstant.PAYMENT_INITIATED;

        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);
        if (customBrowserConfig.getPayuPostData() != null) {
            HashMap<String, String> postParams = new CBUtil().getDataFromPostData(customBrowserConfig.getPayuPostData());
            Bank.amount = postParams.get(CBConstant.AMOUNT);
            Bank.transactionID = postParams.get(CBConstant.TXN_ID);
            Bank.paymentType = CBUtil.getPaymenttype(postParams);
            Bank.bankcode = CBUtil.getBankCodeFromPostData(postParams);
            if (Bank.paymentType != null && Bank.paymentType.equalsIgnoreCase(CBConstant.NETBANKING))
                Bank.screenType = "L2";
            else Bank.screenType = "";
            Bank.time = System.currentTimeMillis();

            CBUtil.logData(getActivity().getApplicationContext(), AnalyticsConstant.UI_CUSTOME_BROWSER_INITIATED, CBUtil.getPaymenttype(postParams), AnalyticsConstant.UI_CB_INITIATED, Bank.amount, Bank.bankcode, Bank.paymentType, "", String.valueOf(0));
        }
        Runnable initilializeRunnable = new Runnable() {
            @Override
            public void run() {
                String fileName = "initialize";
                String strURL = CB_URL + fileName + ".js";
                HttpsURLConnection conn = CBUtil.getHttpsConn(strURL);
                try {
                    if (conn != null && conn.getResponseCode() == HttpsURLConnection.HTTP_OK) {
                        cbUtil.writeFileOutputStream(conn.getInputStream(), activity, fileName, Context.MODE_PRIVATE);

                    }
                } catch (Exception e) {

                } finally {
                    try {
                        if (activity != null && !activity.isFinishing()) {
                            mBankJS = new JSONObject(CBUtil.decodeContents(activity.openFileInput(fileName)));
                            setUrlString();
                            if (!cbOldFlow) {
                                checkStatusFromJS("", CBConstant.CHECK_SURE_PAY_ENABLE_JS_STATUS);
                                checkStatusFromJS("", CBConstant.CHECK_REVIEW_ORDER_ENABLE_JS_STATUS);
                            }
                            //snoozeImageDownloadTimeout = Integer.parseInt(mBankJS.getString("snooze_image_download_time"));

                            final String snoozeConfig = mBankJS.has("snooze_config") ? mBankJS.get("snooze_config") + "('" + Bank.keyAnalytics + "')" : "";
                            snoozeImageDownloadTimeout = Integer.parseInt(mBankJS.has("snooze_image_download_time") ? mBankJS.get("snooze_image_download_time").toString() : "0");
                            // Store snoozeImageTimeOut in sharedPref.
                            // Storing it in CBUtil.CB_PREFERENCE because CB_CONSTANTS.SNOOZE_SHARED_PREF will be cleared and filled with new set of config on every initialize.js download.
                            SharedPreferenceUtil.addIntToSharedPreference(activity.getApplicationContext(), CBUtil.CB_PREFERENCE, CBConstant.SNOOZE_IMAGE_DOWNLOAD_TIME_OUT, snoozeImageDownloadTimeout);

                            final String spInternetRestoredTTL = mBankJS.has(getString(R.string.sp_internet_restored_ttl)) ? mBankJS.get(getString(R.string.sp_internet_restored_ttl)) + "('" + Bank.keyAnalytics + "')" : "";

                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    cbWebView.loadUrl("javascript:" + snoozeConfig);
                                }
                            });

                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    cbWebView.loadUrl("javascript:" + spInternetRestoredTTL);
                                }
                            });
                            //Store the value of S2S js in shared preference
                            if (mBankJS.has(CBConstant.SUREPAY_S2S)) {
                                cbUtil.setStringSharedPreference(activity, CBConstant.SUREPAY_S2S, mBankJS.getString(CBConstant.SUREPAY_S2S));
                            }

                            if (mPageReady) {
                                if (activity != null) {
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            onPageStarted();
                                        }
                                    });
                                }
                            }
                        }
                    } catch (FileNotFoundException | JSONException e) {
                        Log.d("Bank", "communicationError onReceivedErrorWebClient " + e.getMessage());
                        communicationError();
                    } catch (Exception e) {
                        Log.d("Bank", "communicationError onReceivedErrorWebClient " + e.getMessage());
                        communicationError();

                    }
                }

            }
        };
        serialExecutor.execute(initilializeRunnable);
    }


    /**
     * Adjust cbWebView size
     *
     * @param view instance of view of which hieght has to be updated
     */
    public void updateHeight(View view) {

        if (maxWebview == 0) {
            calculateMaximumWebViewHeight();
            maximiseWebviewHeight();
        }
        calculateCBHeight(view);
    }

    /**
     * Calculate and update loader height.
     */
    public void updateLoaderHeight() {
        if (chooseActionHeight == 0) {
            cbWebView.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            int maxWebview = cbWebView.getMeasuredHeight();
            chooseActionHeight = (int) (maxWebview * (0.35));
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == Constants.NATIVE_SMS_READER_PERMISSION_ID && resultCode == Activity.RESULT_CANCELED) {
            if (cbBottomSheet.isVisible())
                cbBottomSheet.makeManualOtpVisible();
        } else {
            otpParser.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {// here we get the respose of the above request for receiving sms
        checkPermissionVisibility = false;
        if (SMSOTPClicked) {
            try {
                cbWebView.loadUrl("javascript:" + mJS.getString(getString(R.string.cb_otp)));
            } catch (JSONException e) {
                L.e(e.getMessage());
            }
        }
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {// this condition checks if the user has given us the permission to read sms
            permissionGranted = true;
            mPassword = null;
        }
        otpParser.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (SMSOTPClicked) {
//                enter_otp(enterOtpParams);
            prepareSmsListener();
            if (null != cbBottomSheet) {
                if (!cbBottomSheet.isAdded()) {
                    Bank.time = System.currentTimeMillis();
                    CBUtil.logData(getActivity().getApplicationContext(), AnalyticsConstant.UI_CUSTOME_BROWSER_LOADED, Bank.paymentType, AnalyticsConstant.UI_CB_LOADED, Bank.amount, Bank.bankcode, Bank.paymentType, Bank.screenType, String.valueOf((TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()))));
                    cbBottomSheet.showNow(getActivity().getSupportFragmentManager(), "CbBottomSheet");
                }
                cbBottomSheet.enterOtp(enterOtpParams);

            }
        }

    }

    /**
     * Display slow user warning dialog
     */
//    protected void showSlowUserWarning() {
//
//        if (activity != null && !activity.isFinishing() && !isSnoozeWindowVisible) {
//
//            // ############################################################################################## //
//            // TODO ADD SOME Event analytics HERE
//            // addEventAnalytics(CBAnalyticsConstant.SNOOZE_WINDOW_STATUS, CBAnalyticsConstant.SNOOZE_VISIBLE);
//            // ############################################################################################## //
//
//            LayoutInflater layoutInflater = activity.getLayoutInflater();
//            // Inflating the Slow User Warning UI
//            View slowUserWarningLayout = layoutInflater.inflate(R.layout.cb_layout_snooze_slow_user, null);
//            // Find header text
//            TextView slowUserWarningDialogHeaderText = (TextView) slowUserWarningLayout.findViewById(R.id.snooze_header_txt);
//            // Set header text
//            slowUserWarningDialogHeaderText.setText(R.string.cb_snooze_slow_user_warning_header);
//            // Find close button
//            TextView slowUserWarningDialogCloseBtn = (TextView) slowUserWarningLayout.findViewById(R.id.text_view_cancel_snooze_window);
//            // Set Visual Graphics
//            ImageView slowUserWarningDialogGraphics = (ImageView) slowUserWarningLayout.findViewById(R.id.snooze_status_icon);
//            slowUserWarningDialogGraphics.setVisibility(View.VISIBLE);
//            slowUserWarningDialogGraphics.setImageDrawable(getCbDrawable(activity.getApplicationContext(), R.drawable.hourglass));
//
//            // AlertDialog slowUserWarningDialog = null;
//            if (null == slowUserWarningDialog) {
//                slowUserWarningDialog = new AlertDialog.Builder(activity).create();
//                slowUserWarningDialog.setView(slowUserWarningLayout);
//                slowUserWarningDialog.setCanceledOnTouchOutside(true);
//                slowUserWarningDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//                    @Override
//                    public void onDismiss(DialogInterface dialogInterface) {
//                        // TODO Future scope - if something needs to be done on dismiss
//                    }
//                });
//                slowUserWarningDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
//                    @Override
//                    public boolean onKey(DialogInterface arg0, int keyCode, KeyEvent event) {
//
//                        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
//                            // NOTE: Doing nothing in case of back button press as of now.
//                            // This dialog can be closed only by touching outside OR
//                            // cancel button press OR back press
//                            slowUserWarningDialog.dismiss();
//
//                            // Toast.makeText(activity.getApplicationContext(), "Back button pressed: IGNORED", Toast.LENGTH_SHORT).show();
//                            // showBackButtonDialog();
//
//                        }
//                        return true;
//                    }
//                });
//                slowUserWarningDialogCloseBtn.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        // Dismiss warning dialog when close button is clicked
//                        slowUserWarningDialog.dismiss();
//                    }
//                });
//            }
//            slowUserWarningDialog.show();
//
//            if (((CBActivity) activity).STATE == CBConstant.STATE_RESUMED) {
//                // User is in background Show Notification to user as well
//                showSlowUserWarningNotification();
//            }
//        }
//    }

    /**
     * Dismiss slow user warning dialog
     */
    protected void dismissSlowUserWarning() {
        if (slowUserWarningDialog != null)
            slowUserWarningDialog.dismiss();
    }

    /**
     * Dismiss slow user warning waitingOTPTimer on touch event fire
     */
    private void dismissSlowUserWarningTimerOnTouch() {
        // Marking first CB interaction after forwardjourney
        // is marked completed
        if (forwardJourneyForChromeLoaderIsComplete) {
            firstTouch = true;
            dismissSlowUserWarningTimer();
        }
    }

    protected void showSlowUserWarningNotification() {
        if (activity != null && !activity.isFinishing()) {
            Intent i = new Intent();
            // TODO After discussion with PM
            // cbUtil.showNotification(activity.getApplicationContext(), i, "title", "txt", R.drawable.snooze11, 63);
        }
    }

    abstract void onPageStarted();

    abstract void enter_otp(String params);

    /**
     * Dismiss slow user warning waitingOTPTimer
     * <p/>
     * WARNING: Don't override this method and let bank.java handle it
     */
    abstract void dismissSlowUserWarningTimer();

    /**
     * Start slow user warning waitingOTPTimer
     * <p/>
     * WARNING: Don't override this method and let bank.java handle it
     */

    abstract void startSlowUserWarningTimer();

    /**
     * Having touch listener
     */
    public class PayUCBLifeCycleTouchListener extends CBMainViewOnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            L.v("Class Name: " + getClass().getCanonicalName() + "onTouch of PayUCBLifeCycleCalled");

            // User is interacting, dismiss slow user warning waitingOTPTimer
            dismissSlowUserWarningTimerOnTouch();

            return super.onTouch(v, event);
        }
    }


    /**
     * Method to display and hide cb blank overlay.
     * should be visible once the user clicked the trylater of snooze
     * should be gone once the snoozewindo disappear.
     *
     * @param visibility
     */
    protected void showCbBlankOverlay(int visibility) {
        if (null != cbBlankOverlay) cbBlankOverlay.setVisibility(visibility);
    }

    /**
     * Method to create a dialog with given title and message
     * Should be used with Sure pay
     * There are no Button visible, not even cancel button.
     *
     * @param header  Dialog title
     * @param message Dialog message
     */
    protected void updateSnoozeDialogWithMessage(String header, String message) {
        if (null != snoozeDialog && snoozeDialog.isShowing()) {
            snoozeDialog.cancel();
            snoozeDialog.dismiss();
        }
//        if (snoozeService != null)
//            snoozeService.killSnoozeService();
        hideBackButtonDialog();
        if (null != activity && !activity.isFinishing()) {
            LayoutInflater layoutInflater = activity.getLayoutInflater();
            View snoozeLayout = layoutInflater.inflate(R.layout.cb_layout_snooze, null);

            ((TextView) snoozeLayout.findViewById(R.id.snooze_header_txt)).setText(header);
            // Top right cancel (x) is not required here.
            snoozeLayout.findViewById(R.id.text_view_cancel_snooze_window).setVisibility(View.GONE);
            ((TextView) snoozeLayout.findViewById(R.id.text_view_snooze_message)).setText(message);
            SnoozeLoaderView snoozeLoaderView = (SnoozeLoaderView) snoozeLayout.findViewById(R.id.snooze_loader_view);
            snoozeLoaderView.setVisibility(View.VISIBLE);
            snoozeLoaderView.startAnimation();
            snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.text_view_retry_message_detail).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.button_retry_transaction).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.button_cancel_transaction).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.t_confirm).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.t_nconfirm).setVisibility(View.GONE);
            snoozeLayout.findViewById(R.id.button_go_back_snooze).setVisibility(View.GONE);

            snoozeDialog = new androidx.appcompat.app.AlertDialog.Builder(activity).create();
            snoozeDialog.setView(snoozeLayout);
            snoozeDialog.setCancelable(false);
            snoozeDialog.setCanceledOnTouchOutside(false);
            snoozeDialog.show();
        }
    }

    /**
     * Method to continue payment after a interval
     * Interval is based on the following priority
     * 1. default value: CBConstant.INTERNET_RESTORED_WINDOW_TTL
     * 2. merchant's value: customBrowserConfig.getInternetRestoredWindowTTL()
     * 3. JS overridden value: mInternetRestoredWindowTTL
     *
     * @param intent intent with required details to continue the payment.
     */
    private void killSnoozeWindowAndContinuePayment(final Intent intent) {

        // Use default value. 5sec - 5000ms.
        int internetRestoredWindowTTL = CBConstant.INTERNET_RESTORED_WINDOW_TTL;

        // if merchant has set some value use the merchant's value.
        if (null != customBrowserConfig) {
            internetRestoredWindowTTL = customBrowserConfig.getInternetRestoredWindowTTL();
        }

        // if payu's js gives different value - use payu's value.
        internetRestoredWindowTTL = mInternetRestoredWindowTTL == 0 ? internetRestoredWindowTTL : mInternetRestoredWindowTTL;


        // update snooze dialog and show internet restored message.
        // Backward journey has two different status.
        // 1. txn status unknown.
        // 2. txn status verified.
        if (backwardJourneyStarted) {
            // based on the txn status we need to update the message.
            try {
                String verifyApiStatus = cbUtil.getValueOfJSONKey(intent.getStringExtra(CBConstant.VALUE), getString(R.string.cb_snooze_verify_api_status));
                if (verifyApiStatus.contentEquals(CBConstant.TRANSACTION_STATUS_SUCCESS)) { // success
                    if (activity != null && !activity.isFinishing())
                        updateSnoozeDialogWithMessage(activity.getResources().getString(R.string.cb_transaction_verified), activity.getResources().getString(R.string.redirect_back_to_merchant));
                } else { // txn status unknown
                    if (activity != null && !activity.isFinishing())
                        updateSnoozeDialogWithMessage(activity.getResources().getString(R.string.cb_transaction_state_unknown), activity.getResources().getString(R.string.status_unknown_redirect_to_merchant));
                }
            } catch (Exception e) { // Txn status unknown

                if (activity != null && !activity.isFinishing())
                    updateSnoozeDialogWithMessage(activity.getResources().getString(R.string.cb_transaction_state_unknown), activity.getResources().getString(R.string.status_unknown_redirect_to_merchant));
            }

        } else { // Forward journey, just one status.
            // addEventAnalytics(CBAnalyticsConstant.INTERNET_RESTORED_DIALOG_RECENT_APP, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
            if (activity != null && !activity.isFinishing())
                updateSnoozeDialogWithMessage(activity.getResources().getString(R.string.internet_restored), activity.getResources().getString(R.string.resuming_your_transaction));
        }

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                // Remove if any existing dialog available.
                if (null != snoozeDialog) {
                    snoozeDialog.dismiss();
                }

                // 5 secs over lets finish the surepay widow.
                if (backwardJourneyStarted) { // backward Journey
//                    if (null != snoozeService) {
//                        snoozeService.killSnoozeService(); // kill snooze service before - transaction status dialog
//                    }
                    showTransactionStatusDialog(intent.getStringExtra(CBConstant.VALUE), false);
                } else { // Forward Journey.
                    //Set variable to false in case surepay is by retry now pressed.
                    if (isRetryNowPressed) {
                        isRetryNowPressed = false;
                    } else {
                        //Increment snoozecount for Surepay auto resume scenario
                        snoozeCount++;
                    }
                    resumeTransaction(intent);
                }

            }
        }, internetRestoredWindowTTL);
    }


    /**
     * launch the dialog which shows transaction status
     *
     * @param payuResponse      response from verify API
     * @param showDialogMessage true if dialog with transaction status is needed else false
     */
    public void showTransactionStatusDialog(final String payuResponse, boolean showDialogMessage) {
        try {
            setTransactionStatusReceived(true);

            String verifyApiStatus = cbUtil.getValueOfJSONKey(payuResponse, getString(R.string.cb_snooze_verify_api_status));

            LayoutInflater layoutInflater = activity.getLayoutInflater();
            View snoozeLayout = layoutInflater.inflate(R.layout.cb_layout_snooze, null);
            final androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(activity);
            builder.setView(snoozeLayout);
            snoozeDialog = builder.create();

            // success transaction api status 1 and failure api status 0
            if (verifyApiStatus.contentEquals(CBConstant.TRANSACTION_STATUS_SUCCESS)) {
                // Logging notification action for bank confirmed screen.

                // replace with new event
                // addEventAnalytics(CBAnalyticsConstant.SNOOZE_NOTIFICATION_ACTION, CBAnalyticsConstant.SUCCESS_SCREEN);
                // addEventAnalytics(CBAnalyticsConstant.TRANSACTION_VERIFIED_NOTIFICATION_CLICK, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);

                // reload data if url is whitelisted URL or kitkat. In case of kitkat we dont reload. rather we post the data to
                if (Bank.isUrlWhiteListed(cbWebView.getUrl() != null ? cbWebView.getUrl() : "") && 19 != Build.VERSION.SDK_INT) { // Check for whitelisted URL
                    addEventAnalytics(CBAnalyticsConstant.SNOOZE_TRANSACTION_STATUS_UPDATE, CBAnalyticsConstant.SNOOZE_RELOAD);
//                        dismissSnoozeWindow();
                    progressBarVisibilityPayuChrome(View.GONE, "");
                    reloadWebView();
                } else { // Make API call to post data if it is not whitelisted URL

                    addEventAnalytics(CBAnalyticsConstant.SNOOZE_TRANSACTION_STATUS_UPDATE, CBAnalyticsConstant.SNOOZE_POST_SURL);

                    // Keeping it in a try catch, if exception comes, let other code run atleast.
                    String response = "";
                    try {
                        response = cbUtil.getValueOfJSONKey(payuResponse, CBConstant.RESPONSE);
                        postDataToSurl(response, new CBUtil().getDataFromPostData(customBrowserConfig.getPayuPostData(), "surl"));
                    } catch (JSONException e) {
                        L.e(e.getMessage());
                    }
                    final String finalResponse = response;
                    // show transaction status dialog if notification is click else finish activity
                    if (showDialogMessage) {
                        snoozeLayout.findViewById(R.id.snooze_status_icon).setVisibility(View.VISIBLE);
                        // snoozeLayout.findViewById(R.id.snooze_status_icon).setVisibility(View.GONE);
                        ((TextView) snoozeLayout.findViewById(R.id.snooze_header_txt)).setText(R.string.cb_transaction_sucess);
                        snoozeLayout.findViewById(R.id.text_view_cancel_snooze_window).setVisibility(View.GONE);
                        ((TextView) snoozeLayout.findViewById(R.id.text_view_snooze_message)).setText(getString(R.string.cb_transaction_success_msg));
                        snoozeLayout.findViewById(R.id.snooze_loader_view).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.text_view_retry_message_detail).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.button_retry_transaction).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.button_cancel_transaction).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.t_confirm).setVisibility(View.GONE);
                        snoozeLayout.findViewById(R.id.t_nconfirm).setVisibility(View.GONE);

                        snoozeDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {
                                try {
                                    if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null) {
                                        if (null != cbBottomSheet && cbBottomSheet.isAdded()) {
                                            cbBottomSheet.finish();
                                        }
                                        CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onPaymentSuccess(finalResponse, "");
                                    }
                                } catch (Exception e) {

                                }
                                snoozeDialog.dismiss();
                                snoozeDialog.cancel();
                                activity.finish();

                            }
                        });
                        snoozeDialog.setCanceledOnTouchOutside(false);
                        snoozeDialog.show();


                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (snoozeDialog != null && snoozeDialog.isShowing()) {
                                    snoozeDialog.cancel();
                                    snoozeDialog.dismiss();
                                    activity.finish();
                                }
                            }
                        }, 5000);
                    } else {
                        if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null) {
                            if (null != cbBottomSheet && cbBottomSheet.isAdded()) {
                                cbBottomSheet.finish();
                            }
                            CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onPaymentSuccess(finalResponse, "");
                        }
                        activity.finish();
                    }
                }
            } else {
                // show transaction status dialog if notification is click else finish activity
                if (showDialogMessage) {
                    // Logging notification action for bank not confirmed screen

                    // replaced with new event
                    // addEventAnalytics(CBAnalyticsConstant.SNOOZE_NOTIFICATION_ACTION, CBAnalyticsConstant.TXN_NOT_CONFIRMED);
                    // addEventAnalytics(CBAnalyticsConstant.TRANSACTION_NOT_VERIFIED_NOTIFICATION_CLICK, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);
                    snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.VISIBLE);
                    snoozeLayout.findViewById(R.id.snooze_status_icon).setVisibility(View.VISIBLE);
                    snoozeLayout.findViewById(R.id.text_view_cancel_snooze_window).setVisibility(View.GONE);
                    snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.GONE);

                    ((TextView) snoozeLayout.findViewById(R.id.snooze_header_txt)).setText(R.string.cb_transaction_failed_title);
                    ((TextView) snoozeLayout.findViewById(R.id.text_view_snooze_message)).setText(R.string.cb_transaction_failed);
                    //  ((TextView) snoozeLayout.findViewById(R.id.text_view_transaction_snoozed_message1)).setText(R.string.cb_transaction_failed_retry);
                    // ((TextView) snoozeLayout.findViewById(R.id.text_view_retry_message_detail)).setText(R.string.cb_transaction_failed_debited);

                    // if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() == null) {
                    snoozeLayout.findViewById(R.id.button_retry_transaction).setVisibility(View.GONE);
                    snoozeLayout.findViewById(R.id.button_cancel_transaction).setVisibility(View.VISIBLE);
                    snoozeLayout.findViewById(R.id.button_snooze_transaction).setVisibility(View.GONE);
                    snoozeLayout.findViewById(R.id.text_view_retry_message_detail).setVisibility(View.GONE);
                    snoozeLayout.findViewById(R.id.text_view_transaction_snoozed_message1).setVisibility(View.GONE);
                    snoozeLayout.findViewById(R.id.text_view_ac_debited_twice).setVisibility(View.GONE);

                    //  }
             /*   snoozeLayout.findViewById(R.id.button_retry_transaction).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        snoozeDialog.dismiss();
                        snoozeDialog.cancel();
                        Long interationTime=(System.currentTimeMillis() - snoozeWindowAppearTime) / 1000;
                        payUCustomBrowser.addEventAnalytics(CBAnalyticsConstant.SNOOZE_INTERACTION_TIME,  interationTime+"");
                        payUCustomBrowser.addEventAnalytics(CBAnalyticsConstant.SNOOZE_WINDOW_ACTION, CBAnalyticsConstant.SNOOZE_RETRY_CLICK);
                        payUCustomBrowser.addEventAnalytics(CBAnalyticsConstant.SNOOZE_RETRY_NOW_URL, customBrowserConfig.getPostURL());

                        if (payUCustomBrowser == null) {
                            setContentView(com.payu.custombrowser.R.layout.cb_payments);
                            payUCustomBrowser = new Bank();
                            getSupportFragmentManager().beginTransaction().add(com.payu.custombrowser.R.id.main_frame, payUCustomBrowser).commit();
                        } else {
                            payUCustomBrowser.reloadWebView(customBrowserConfig.getPostURL(), customBrowserConfig.getPayuPostData());
                        }

                        // getSupportFragmentManager().beginTransaction().replace(com.payu.custombrowser.R.id.main_frame, payUCustomBrowser).commit();
                    }
                });
*/
                    snoozeLayout.findViewById(R.id.button_cancel_transaction).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            addEventAnalytics(CBAnalyticsConstant.SNOOZE_INTERACTION_TIME, CBAnalyticsConstant.DEFAULT_ANALYTICS_EVENT_VALUE);

                            // finish Activity
                            addEventAnalytics(CBAnalyticsConstant.SNOOZE_WINDOW_ACTION, CBAnalyticsConstant.SNOOZE_CANCEL_TRANSACTION_CLICK);
                            //showBackButtonDialog();
                            snoozeDialog.dismiss();
                            snoozeDialog.cancel();
                            activity.finish();
                        }
                    });
                    snoozeDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {
                            snoozeDialog.dismiss();
                            snoozeDialog.cancel();

                        }
                    });

                    snoozeDialog.setCanceledOnTouchOutside(false);
                    snoozeDialog.show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (snoozeDialog != null && snoozeDialog.isShowing()) {
                                snoozeDialog.cancel();
                                snoozeDialog.dismiss();
                                activity.finish();
                            }
                        }
                    }, 5000);
                } else {
                    activity.finish();
                }
            }
        } catch (Exception e) {

        }
    }

    /**
     * Post data to surl(success URL)
     *
     * @param postData data to be poted on success url
     * @param surl     success url
     */
    public void postDataToSurl(final String postData, final String surl) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                String responseStringBuffer = "";
                try {
                    java.net.URL url = new URL(URLDecoder.decode(surl, "UTF-8"));
                    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    conn.setRequestProperty("Content-Length", String.valueOf(postData.length()));
                    conn.setDoOutput(true);
                    byte[] postParamsByte = postData.getBytes();
                    conn.getOutputStream().write(postParamsByte);
                    //   if (conn.getResponseCode() != 200) {
                    //    postDataToSurl(postData, surl);
                    // }
                } catch (Exception e) {
                }

            }
        }).start();

    }


    /**
     * Declaring reloadWebView as abstract to communicate with bank's reload webview.
     * Since we dont have any bank object and bank inherits PayUCBLifeCycle using abstract
     *
     * @param url        url to be loaded
     * @param postParams post params to be posted to the url.
     */
    abstract void reloadWebView(String url, String postParams);

    /**
     * Declaring reloadWebView as abstract to communicate with bank's reload webview.
     * Since we dont have any bank object and bank inherits PayUCBLifeCycle using abstract
     */
    abstract void reloadWebView();

    abstract void internetErrorHandler(int errorCode, String errorDesc);

    abstract void reloadWebViewUrl();

    abstract boolean retryCancellationHandler();

    /**
     * Declaring showBackButtonDialog as abstract to communicate with bank's showBackButtonDialog.
     * Since we dont have any bank object and bank inherits PayUCBLifeCycle using abstract
     */
    abstract void showBackButtonDialog();

    /**
     * Declaring hideBackButtonDialog as abstract to communicate with bank's hideBackButtonDialog.
     * Since we dont have any bank object and bank inherits PayUCBLifeCycle using abstract
     */
    abstract void hideBackButtonDialog();

    /**
     * Declaring reloadWebView as abstract to communicate with bank's reload webview.
     * Since we dont have any bank object and bank inherits PayUCBLifeCycle using abstract
     *
     * @param resumeUrl, url used in analytics.
     */
    abstract void reloadWebView(String resumeUrl);


    /**
     * Method to resume the transaction, based on the MR checks.
     *
     * @param intent
     */
    public void resumeTransaction(Intent intent) {
        customBrowserConfig = intent.getExtras().getParcelable("cb_config");
        // replace with new event
        // addEventAnalytics(CBAnalyticsConstant.SNOOZE_NOTIFICATION_ACTION, CBAnalyticsConstant.SNOOZE_TRANSACTION_RESUMED);
        //Check if S2S retry url is not present and current url is present in intent
        if (intent.getStringExtra(CBConstant.CURRENT_URL) != null && intent.getStringExtra(CBConstant.S2S_RETRY_URL) == null) {
            if (intent.getStringExtra(CBConstant.CURRENT_URL).equalsIgnoreCase(customBrowserConfig.getPostURL())) {
                if (customBrowserConfig.getPostURL().contentEquals(CBConstant.PAYMENT_URL) || customBrowserConfig.getPostURL().contentEquals(CBConstant.TEST_PAYMENT_URL)) {
                    // mark the previous txn as sure_pay canceled.
                    markPreviousTxnAsUserCanceled(cbUtil.getLogMessage(activity.getApplicationContext(), CBAnalyticsConstant.SURE_PAY_CANCELLED, customBrowserConfig.getTransactionID(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID(), ""));
                }
                reloadWebView(customBrowserConfig.getPostURL(), customBrowserConfig.getPayuPostData());
            } else {
                if (Bank.isUrlWhiteListed(intent.getStringExtra(CBConstant.CURRENT_URL))) {
                    reloadWebView(intent.getStringExtra(CBConstant.CURRENT_URL));
                } else {
                    if (customBrowserConfig.getPostURL().contentEquals(CBConstant.PAYMENT_URL) || customBrowserConfig.getPostURL().contentEquals(CBConstant.TEST_PAYMENT_URL)) {
                        // mark the previous txn as sure_pay canceled.
                        markPreviousTxnAsUserCanceled(cbUtil.getLogMessage(activity.getApplicationContext(), CBAnalyticsConstant.SURE_PAY_CANCELLED, customBrowserConfig.getTransactionID(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID(), ""));
                    }
                    reloadWebView(customBrowserConfig.getPostURL(), customBrowserConfig.getPayuPostData());
                }
            }
        }//Check if S2S retry url is present and load it in webview
        else if (intent.getStringExtra(CBConstant.S2S_RETRY_URL) != null) {
            reloadWebView(intent.getStringExtra(CBConstant.S2S_RETRY_URL), null);
        } else {
            reloadWebView(customBrowserConfig.getPostURL(), customBrowserConfig.getPayuPostData());
        }
    }

    /**
     * Method to mark the previous txn as user canceled.
     * Should be called on every reposting at _payment url.
     * currently we call this on the following places.
     * 1. on Click of notification
     * 2. Retry on snooze window.
     * 3. Retry anyway on Snooze txn paused window.
     *
     * @param logMessage should be the log message in json format.
     *                   example: {"payu_id":"","txnid":"1467622816434","merchant_key":"0MQaQP","page_type":"","event_key":"sure_pay_cancelled","event_value":"1467622816434","bank":"","package_name":"com.payu.testapp"}
     */

    public void markPreviousTxnAsUserCanceled(String logMessage) {
        new SurePayCancelAsyncTaskHelper(logMessage, AnalyticsCBInit.getInstance(activity.getApplicationContext()).getUrl()).execute();
    }

    @Override
    public void onCbBottomSheetCancel() {
        if (null != cbBaseView) {
            cbBaseView.removeAllViews();
            cbBaseView.setVisibility(View.GONE);
        }
        openCollapsedUI();
    }

    private RelativeLayout rlWaitingForOtpCollapsed;
    private RelativeLayout rlManualOtpCollapsed;
    private TextView tvCollapsedOtp;
    private TextView tvWaitingForOtp;
    private TextView resentOtp;
    private LinearLayout llOtpFetched;

    void dismissCollapsedUI() {
        cancelCountDownTimer();
        if (null != payuBottomSheetCollapsed)
            payuBottomSheetCollapsed.removeAllViews();
    }

    void openCollapsedUI() {
        cancelCountDownTimer();
        if (null != payuBottomSheetCollapsed) {
            payuBottomSheetCollapsed.removeAllViews();
        }
        final View view = activity.getLayoutInflater().inflate(R.layout.cb_bottom_sheet_collapsed, null);
        rlWaitingForOtpCollapsed = view.findViewById(R.id.rlWaitingForOtpCollapsed);
        rlManualOtpCollapsed = view.findViewById(R.id.rlManualOtpCollapsed);
        View viewOpenBottomSheet = view.findViewById(R.id.viewOpenBottomSheet);
        tvCollapsedOtp = view.findViewById(R.id.tvCollapsedOtp);
        tvWaitingForOtp = view.findViewById(R.id.tvWaitingForOtp);
        resentOtp = view.findViewById(R.id.resentOtp);
        TextView btnSubmitOtpCollapsed = view.findViewById(R.id.btnSubmitOtpCollapsed);
        llOtpFetched = view.findViewById(R.id.llOtpFetched);


        if (BOTTOM_SHEET_STATUS == CBConstant.MANUAL_OTP || BOTTOM_SHEET_STATUS == CBConstant.WAITING_OTP || BOTTOM_SHEET_STATUS == CBConstant.AUTO_SUBMIT) {
            payuBottomSheetCollapsed.setVisibility(View.VISIBLE);
            payuBottomSheetCollapsed.addView(view);
            btnSubmitOtpCollapsed.setOnClickListener(this);
            resentOtp.setOnClickListener(this);
            viewOpenBottomSheet.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (null != cbBottomSheet) {
                        if (!cbBottomSheet.isAdded())
                            cbBottomSheet.showNow(getActivity().getSupportFragmentManager(), "CbBottomSheet");
                        cbBottomSheet.enterManually(otpFetched);
                    }
                    cancelCountDownTimer();
                    return false;
                }
            });
            if (BOTTOM_SHEET_STATUS == CBConstant.MANUAL_OTP || BOTTOM_SHEET_STATUS == CBConstant.AUTO_SUBMIT) {

                if (!otpFetched.isEmpty() && otpFetched.length() >= 6 && otpFetched.length() <= 8) {
                    addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.READY_TO_SUBMIT_OTP_COLLPASED);
                    tvCollapsedOtp.setText(otpFetched);
                    llOtpFetched.setVisibility(View.VISIBLE);
                    rlManualOtpCollapsed.setVisibility(View.GONE);
                    rlWaitingForOtpCollapsed.setVisibility(View.GONE);
                } else {
                    handleResendOtpVisibility();
                    manualOtpVisible();
                }

            } else if (BOTTOM_SHEET_STATUS == CBConstant.WAITING_OTP) {
                addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.WAITING_OTP_COLLPASED);
                rlWaitingForOtpCollapsed.setVisibility(View.VISIBLE);
                llOtpFetched.setVisibility(View.GONE);
                rlManualOtpCollapsed.setVisibility(View.GONE);
                cancelCountDownTimer();
                showWaitOtpTimer();
            }

        }

    }

    private void handleResendOtpVisibility() {
        if (null != params && !params.isEmpty()) {
            final boolean regenerate = CBUtil.hasKeyValue(params, getString(R.string.cb_regenerate));
            if (getActivity() != null) {
                if (regenerate) {
                    resentOtp.setVisibility(View.VISIBLE);
                } else {
                    resentOtp.setVisibility(View.GONE);
                }
            }
        }
    }

    private CountDownTimer countDownTimerForOtp;

    private void manualOtpVisible() {
        addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.MANUAL_OTP_COLLPASED);
        rlManualOtpCollapsed.setVisibility(View.VISIBLE);
        rlWaitingForOtpCollapsed.setVisibility(View.GONE);
        llOtpFetched.setVisibility(View.GONE);

    }

    private void showWaitOtpTimer() {

        countDownTimerForOtp = new CountDownTimer(timerValueRemaining, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (isAdded()) {
                    tvWaitingForOtp.setText(getString(R.string.cb_payu_waiting_for_otp) + " " +
                            millisUntilFinished / 1000 + " SEC");
                }
            }

            @Override
            public void onFinish() {
                manualOtpVisible();
                if (isAdded()) {
                    JSONObject p;
                    try {
                        p = new JSONObject(params);
                        final boolean regenerate = p.has(getString(R.string.cb_regenerate)) && p.getBoolean(getString(R.string.cb_regenerate));
                        final boolean pin = p.has(getString(R.string.cb_pin)) && p.getBoolean(getString(R.string.cb_pin));
                        if (regenerate) {
                            resentOtp.setVisibility(View.VISIBLE);
                        }
                    } catch (JSONException e) {
                        L.e(e.getMessage());
                    }
                }
            }
        };
        countDownTimerForOtp.start();

    }


    void cancelCountDownTimer() {
        if (null != countDownTimerForOtp) {
            countDownTimerForOtp.cancel();
            countDownTimerForOtp = null;
        }

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.resentOtp) {
            try {
                eventRecorded = CBAnalyticsConstant.REGENERATE_COLLAPSED;
                addEventAnalytics(CBAnalyticsConstant.USER_INPUT, eventRecorded);
                mPassword = null;
                cbWebView.loadUrl("javascript:" + mJS.getString(getString(R.string.cb_regen_otp)));
                isListenerAttached = false;//Reattach listener to again ask for permission
                permissionGranted = true;//Reset so that user knows that consent is working
                prepareSmsListener();
                otpFetched = "";
            } catch (JSONException e) {
                L.e(e.getMessage());
            }
        } else if (v.getId() == R.id.btnSubmitOtpCollapsed) {
            try {
                hideKeyboardForcefully();
                mPassword = null;
                checkLoading = false;
                approve_flag = true;
//                onHelpUnavailable();
//                maximiseWebviewHeight();
//                frameState = MINIMISED;
                prepareSmsListener();

                if (tvCollapsedOtp.getText().toString().length() > 5) {
                    if (null != cbBottomSheet) {
                        if (!cbBottomSheet.isAdded())
                            cbBottomSheet.showNow(getActivity().getSupportFragmentManager(), "CbBottomSheet");
                        cbBottomSheet.loading(getString(R.string.cb_confirming_your_payment));
                    }
                    addEventAnalytics(CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.SUBMIT_OTP_COLLPASED);
                    cbWebView.loadUrl("javascript:" + mJS.getString(getString(R.string.cb_process_otp)) + "(\"" + tvCollapsedOtp.getText().toString() + "\")");
                }
            } catch (JSONException e) {
                L.e(e.getMessage());
            }
        }

    }
}

