package com.payu.custombrowser.bean;

import com.payu.custombrowser.util.PaymentOption;

/**
 * Created by himanshu.gupta on 07/03/18.
 */

public class CustomBrowserResultData {
    String vpa;
    String jsonResult;
    boolean paymentOptionAvailable;
    PaymentOption paymentOption;
    String errorMessage;

    public boolean isPaymentOptionAvailable() {
        return paymentOptionAvailable;
    }

    public void setPaymentOptionAvailable(boolean paymentOptionAvailable) {
        this.paymentOptionAvailable = paymentOptionAvailable;
    }

    public String getSamsungPayVpa() {
        return vpa;
    }

    public void setSamsungPayVpa(String vpa) {
        this.vpa = vpa;
    }

    public String getJsonResult() {
        return jsonResult;
    }

    public void setJsonResult(String jsonResult) {
        this.jsonResult = jsonResult;
    }

    public PaymentOption getPaymentOption() {
        return paymentOption;
    }

    public void setPaymentOption(PaymentOption paymentOption) {
        this.paymentOption = paymentOption;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
