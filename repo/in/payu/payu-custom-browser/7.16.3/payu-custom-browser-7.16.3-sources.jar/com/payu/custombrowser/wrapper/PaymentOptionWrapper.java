package com.payu.custombrowser.wrapper;

import android.app.Activity;
import android.content.Context;

import androidx.fragment.app.Fragment;

import com.payu.custombrowser.PayUCustomBrowserCallback;
import com.payu.custombrowser.bean.CustomBrowserConfig;

public abstract class PaymentOptionWrapper {

    protected PayUCustomBrowserCallback cbListener;

    public abstract void checkForPaymentOptionAvailability(Context context, String paymentOptionHash, String merchantKey, String user_credentials, String paymentType);

    public abstract void makePayment(Activity activity, CustomBrowserConfig customBrowserConfig);

    public abstract Fragment makeSeamlessPayment(CustomBrowserConfig customBrowserConfig, Context context);

}
