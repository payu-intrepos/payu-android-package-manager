package com.payu.custombrowser.cbinterface;

/**
 * Created by franklin.michael on 23/06/16.
 */

public interface CustomBrowserAsyncTaskInterface {
    public void onCustomBrowserAsyncTaskResponse(String cbAsynTaskResponse, String webServiceType);
}
