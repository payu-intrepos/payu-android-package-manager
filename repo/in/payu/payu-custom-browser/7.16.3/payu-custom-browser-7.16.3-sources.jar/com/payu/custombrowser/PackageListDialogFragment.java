package com.payu.custombrowser;

import com.payu.custombrowser.wrapper.UpiWrapper;

public class PackageListDialogFragment {
    public void verifyVpa(String hash) {
        UpiWrapper upiWrapper = new UpiWrapper();
        upiWrapper.verifyVpa(hash);
    }
}
