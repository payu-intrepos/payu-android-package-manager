package com.payu.custombrowser.cbinterface;

public interface OnBackButtonListener {
    public void onBackButtonClicked();
}
