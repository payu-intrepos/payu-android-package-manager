package com.payu.custombrowser.util;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.KeyPairGeneratorSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import com.payu.payuanalytics.analytics.utils.EncryptionUtils;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;

/**
 * Created by shoaib on 10/13/15.
 */
public class SharedPreferenceUtil {

    public static SharedPreferences getSharedPref(
            Context context,
            String fileName) {
        EncryptionUtils.getKeys(context);
        return context.getSharedPreferences(fileName, MODE_PRIVATE);
    }


    public static void addStringToSharedPreference(Context context, String spFileName, String spKey, String spValue) {
        SharedPreferences sharedPref = getSharedPref(context, spFileName);
        SharedPreferences.Editor editor = sharedPref.edit();
        if (spValue != null) {
            editor.putString(spKey, EncryptionUtils.encrypt(
                    context,
                    spValue
            ));
            editor.apply();
        }
    }

    public static void addIntToSharedPreference(Context context, String spFileName, String spKey, int spValue) {
        try {
            SharedPreferences sharedPref = getSharedPref(context, spFileName);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(spKey, EncryptionUtils.encrypt(
                    context,
                    String.valueOf(spValue)
            ));
            editor.apply();
        } catch (Exception e) {

        }
    }

    public static void addBooleanToSharedPreference(Context context, String spFileName, String spKey, boolean spValue) {
        SharedPreferences sharedPref = getSharedPref(context, spFileName);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(spKey, EncryptionUtils.encrypt(
                context,
                String.valueOf(spValue)
        ));
        editor.apply();
    }

    public static String getStringFromSharedPreference(Context context, String spFileName, String spKey, String defaultValue) {
        try {
            SharedPreferences sharedPref = getSharedPref(context, spFileName);
            String encryptedString = sharedPref.getString(spKey, defaultValue);
            String decodedString = EncryptionUtils.decrypt(
                    context,
                    encryptedString
            );
            if (decodedString == null) return defaultValue;
            return decodedString;
        } catch (Exception e) {
            removeAllFromSharedPref(context, spFileName);
            return defaultValue;
        }
    }

    public static int getIntFromSharedPreference(Context context, String spFileName, String spKey, int defaultValue) {
        try {
            SharedPreferences sharedPref = getSharedPref(context, spFileName);
            String encryptedData = sharedPref.getString(spKey, String.valueOf(defaultValue));
            String decodedString = EncryptionUtils.decrypt(
                    context,
                    encryptedData
            );
            if (decodedString == null) return defaultValue;
            return Integer.parseInt(decodedString);
        } catch (Exception e) {
            removeAllFromSharedPref(context, spFileName);
            return defaultValue;
        }
    }

    public static boolean getBooleanFromSharedPreference(Context context, String spFileName, String spKey, boolean defaultValue) {
        try {
            SharedPreferences sharedPref = getSharedPref(context, spFileName);
            String encryptedData = sharedPref.getString(spKey, String.valueOf(defaultValue));
            String decodedString = EncryptionUtils.decrypt(
                    context,
                    encryptedData
            );
            if (decodedString == null) return defaultValue;
            return Boolean.getBoolean(decodedString);
        } catch (Exception e) {
            removeAllFromSharedPref(context, spFileName);
            return defaultValue;
        }
    }

    /**
     * Simple helper method read a preference and return all the values as hashmap<String, Object> format.
     *
     * @param context  context
     * @param prefName name of the perference file.
     * @return hashmap.
     */
    public static Map<String, ?> getSharedPrefMap(Context context, String prefName) {
        try {
            HashMap<String, Object> sharedPrefHashMap = new HashMap<>();
            SharedPreferences snoozeSharedPref = getSharedPref(context, prefName);
            Map<String, ?> allEntries = snoozeSharedPref.getAll();

            return allEntries;
        } catch (Exception e) {
            Map<String, ?> allEntries = new HashMap<>();
            removeAllFromSharedPref(context, prefName);
            return allEntries;
        }
    }

    /**
     * Simple helper method to remove all the keys from given shared pref file.
     *
     * @param context
     * @param prefName
     */
    public static void removeAllFromSharedPref(Context context, String prefName) {
        try {
            SharedPreferences settings = getSharedPref(context, prefName);
            settings.edit().clear().apply();
        } catch (Exception e) {

        }
    }

}
