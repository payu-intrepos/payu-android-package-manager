package com.payu.custombrowser.AnalyticsHandler;

public interface AnalyticsConstant {
    String UI_CTA_NAME = "cta_name";
    String UI_CTA_PAGE = "CTA page";
    String UI_CTA_TYPE = "CTA type";
    String UI_EVENT_NAME = "evtName";
    String UI_EVENT_DATA = "evtData";

    String UI_IDENTITY = "identity";
    String UI_TIME = "Time";
    String UI_MERCHANT_IDENTIFIER = "Merchant Identifier";
    String UI_MERCHANT_NAME = "Merchant Name";
    String UI_DEVICE = "Device";
    String UI_DEVICE_ID = "Device id";
    String UI_AMOUNT = "Amount";
    String UI_TXNID = "Transaction identifier";
    String UI_ENFORCED = "Enforced";
    String UI_TYPE = "type";
    String UI_FLOW_TYPE = "Flow Type";
    String UI_BANKCODE = "Bank Code";
    String UI_BANKANME = "Bank Name";
    String UI_SCREEN_TYPE = "Screen Type";
    String UI_CB_INITIATED = "CB Initiated";
    String UI_CUSTOME_BROWSER_INITIATED = "Custom browser Initiated";
    String UI_CB_LOADED = "CB Loaded";
    String UI_CUSTOME_BROWSER_LOADED = "Custom Browser Loaded";
    String UI_CB_SUBMIT = "CB Submit";
    String UI_CUSTOME_BROWSER_SUBMIT = "Custom Browser Submit";
    String UI_CB_RESEND = "CB Resend";
    String UI_CUSTOME_BROWSER_RESEND = "Custom Browser Resend";

    String CARDS = "Cards";
    String NB = "Netbanking";

    String CB_PACKAGE_NAME = "com.payu.custombrowser";
    String CB_EVENT = "event";

    String CB_ANDROID = "Android";
    String CB_DEVICE_NAME = "Device name";
    String CB_DEVICE_VERSION = "Device version";
    String CB_SDK_VERSION = "SDK version";
    String CB_SDK_CLOSED = "SDK closed";

    String CB_TIMEIN_MILISECONDS = "Time milliseconds";

    String CB_CTA_TYPE_ACTION = "Action";
    String CB_SECTION_NAME = "section_name";
    String CB_LEFT_SIDEBAR = "Left Sidebar";
    String CB_BACK_BUTTON = "Back button";
    String CB_BACK_BUTTON_CTA = "CB Back Button";
    String PAYU_CB = "PayUCustomBrowser";

    String UI_ERROR = "error";

}
