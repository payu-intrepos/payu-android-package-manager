package com.payu.custombrowser.wrapper;

import static com.payu.custombrowser.util.CBUtil.getAnalyticsConfig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.fragment.app.Fragment;

import com.payu.custombrowser.AnalyticsCBInit;
import com.payu.custombrowser.Bank;
import com.payu.custombrowser.PackageListDialogFragment;
import com.payu.custombrowser.bean.CustomBrowserConfig;
import com.payu.custombrowser.bean.CustomBrowserData;
import com.payu.custombrowser.bean.CustomBrowserResultData;
import com.payu.custombrowser.util.CBAnalyticsConstant;
import com.payu.custombrowser.util.CBConstant;
import com.payu.custombrowser.util.CBUtil;
import com.payu.custombrowser.util.L;
import com.payu.custombrowser.util.PaymentOption;
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.BaseAnalytics;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class UpiWrapper extends PaymentOptionWrapper {

    private Object upiWrapperObject;
    private PayUAnalytics analytics;
    private Activity activity;
    private CustomBrowserConfig customBrowserConfig;
    private CBUtil cbUtil;
    private Method method;
    /**
     * Reflection Callback mapping with PayUCustomBrowserCallback and wrapper callback and SamsungPay Wrapper Callback
     */
    private java.lang.reflect.InvocationHandler cbCallback = new java.lang.reflect.InvocationHandler() {
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (method.getName().equalsIgnoreCase(CBConstant.PAYMENT_OPTION_SUCCESS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "   Success cb UpiWrapper " + args[0]);
                if (customBrowserConfig != null) {
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBAnalyticsConstant.SUCCESS_TRANSACTION, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                }
                if (cbListener != null)
                    cbListener.onPaymentSuccess(args[0] + "", null);
            } else if (method.getName().equalsIgnoreCase(CBConstant.PAYMENT_OPTION_FAILURE)) {
                L.v("Failure cb Upiwrapper " + args[0]);
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBAnalyticsConstant.FAILURE_TRANSACTION + "_" + CBConstant.PAYMENT_OPTION_FAILURE, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "CbListener " + cbListener);
                if (cbListener != null)
                    cbListener.onPaymentFailure(args[0] + "", null);

            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_UPI_ERROR_RECEIVED)) {
                L.v("Failure cb Upiwrapper " + args[0]);
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBAnalyticsConstant.FAILURE_TRANSACTION + "_" + CBConstant.ON_UPI_ERROR_RECEIVED, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "CbListener " + cbListener);
                if (cbListener != null)
                    cbListener.onCBErrorReceived((Integer) args[0], "" + args[1]);

            } else if (method.getName().equalsIgnoreCase(CBConstant.PAYMENT_OPTION_INIT_SUCCESS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Option cbInit Success");
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, "_" + CBConstant.PAYMENT_OPTION_INIT_SUCCESS, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                CustomBrowserResultData resultData = new CustomBrowserResultData();
                resultData.setPaymentOption(PaymentOption.PHONEPE);
                L.v("Class Name: " + getClass().getCanonicalName() + "paymentoptioninitsuccess  type>> " + resultData.getPaymentOption());
                resultData.setPaymentOptionAvailable(true);
                if (cbListener != null)
                    cbListener.isPaymentOptionAvailable(resultData);

            } else if (method.getName().equalsIgnoreCase(CBConstant.IS_PAYMENT_OPTION_AVAILABLE)) {
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBConstant.IS_PAYMENT_OPTION_AVAILABLE, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Option isPaymentOptionAvailable cb");
                CustomBrowserResultData resultData = new CustomBrowserResultData();
                L.v("Class Name: " + getClass().getCanonicalName() + "paymentoption available cb type>> " + args[1] + (Boolean) args[0]);
                if (args[1].toString().equals("PPINTENT")) {
                    resultData.setPaymentOption(PaymentOption.PHONEPE);
                } else if (args[1].toString().equals("SAMPAY")) {
                    resultData.setPaymentOption(PaymentOption.SAMSUNGPAY);
                } else if (args[1].toString().equals("Tez")) {
                    resultData.setPaymentOption(PaymentOption.TEZ);
                }
                resultData.setPaymentOptionAvailable((Boolean) args[0]);
                CustomBrowserData.SINGLETON.setPaymentOption(resultData.getPaymentOption());
                resultData.setErrorMessage(args[1] + "");
                if (cbListener != null)
                    cbListener.isPaymentOptionAvailable(resultData);
            }
            if (method.getName().equalsIgnoreCase(CBConstant.ON_PAYMENT_FAILURE)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "onPayment Failure UpiWrapper Cb " + args[0]);
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBAnalyticsConstant.FAILURE_TRANSACTION + "_" + CBConstant.ON_PAYMENT_FAILURE, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                if (cbListener != null)
                    cbListener.onPaymentFailure(args[0] + "", args[1] + "");
            }
            if (method.getName().equalsIgnoreCase(CBConstant.ON_PAYMENT_SUCCESS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "onPayment Success UpiWrapper Cb " + args[0]);
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBAnalyticsConstant.SUCCESS_TRANSACTION, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                cbListener.onPaymentSuccess(args[0] + "", args[1] + "");
            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_PAYMENT_TERMINATED)) {
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBConstant.ON_PAYMENT_TERMINATED, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "onPaymentTerminate UpiWrapper Cb ");
                cbListener.onPaymentTerminate();
            } else if (method.getName().equalsIgnoreCase(CBConstant.PAYMENT_OPTION_INIT_SUCCESS)) {
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBConstant.PAYMENT_OPTION_INIT_SUCCESS, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "PAYMENT_OPTION_INIT_SUCCESS");
                CustomBrowserResultData resultData = new CustomBrowserResultData();
                resultData.setPaymentOption(PaymentOption.PHONEPE);
                resultData.setPaymentOptionAvailable(true);
                cbListener.isPaymentOptionAvailable(resultData);
                CustomBrowserData.SINGLETON.setPaymentOption(PaymentOption.PHONEPE);
            } else if (method.getName().equalsIgnoreCase(CBConstant.PAYMENT_OPTION_INIT_FAILURE)) {
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.TRNX_STATUS, CBConstant.PAYMENT_OPTION_INIT_FAILURE, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                L.v("Class Name: " + getClass().getCanonicalName() + "PAYMENT_OPTION_INIT_FAILURE type>> " + args[1]);
                CustomBrowserResultData resultData = new CustomBrowserResultData();

                if (args[1] != null) {
                    String description = (String) args[1];
                    L.v("Check description " + description.toLowerCase());
                    String s = description.toLowerCase();
                    if (s.contains("tez")) {
                        resultData.setPaymentOption(PaymentOption.TEZ);

                    } else if (s.contains("ppintent")) {
                        resultData.setPaymentOption(PaymentOption.PHONEPE);

                    } else if (s.contains("sampay")) {
                        resultData.setPaymentOption(PaymentOption.SAMSUNGPAY);

                    }
                }

                CustomBrowserData.SINGLETON.removePaymentOption(resultData.getPaymentOption());
                resultData.setPaymentOptionAvailable(false);
                resultData.setErrorMessage(args[1] + "");
                cbListener.isPaymentOptionAvailable(resultData);
            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_VPA_ENTERED)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Check Validilty upiwrapper cb");
                PackageListDialogFragment packageListDialogFragment = new PackageListDialogFragment();
                cbListener.onVpaEntered(args[0] + "", packageListDialogFragment);
            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_BACK_APPROVE)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "On Back Approve");
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.BACK_BUTTON_OK_CLICK, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                cbListener.onBackApprove();
                // CustomBrowserData.SINGLETON.setiPackageListDialogFragment(iPackageListDialogFragment);
            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_BACK_DISMISS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "On Back Dismiss");
                if (customBrowserConfig != null)
                    analyticsLogging(activity, CBAnalyticsConstant.USER_INPUT, CBAnalyticsConstant.BACK_BUTTON_CANCEL_CLICK, null, cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.KEY), cbUtil.getDataFromPostData(customBrowserConfig.getPayuPostData(), CBConstant.TXNID));
                cbListener.onBackDismiss();
            } else if (method.getName().equalsIgnoreCase(CBConstant.ON_BACK_BUTTON)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "On Back Button");
                cbListener.onBackButton((AlertDialog.Builder) args[0]);
            }
            return null;
        }
    };


    private void initUpi() {
        try {
            ClassLoader upiWrapperClassLoader = UpiWrapper.class.getClassLoader();
            Class upiWrapperClass = upiWrapperClassLoader.loadClass("com.payu.upisdk.UpiWrapper");
            Constructor upiWrapperConstructor = upiWrapperClass.getDeclaredConstructor(java.lang.reflect.InvocationHandler.class);
            upiWrapperConstructor.setAccessible(true);
            upiWrapperObject = upiWrapperConstructor.newInstance(cbCallback);
            L.v("Class Name: " + getClass().getCanonicalName() + "UpiWrapper Initiated");
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Exception " + e.getMessage());
        }
    }

    /**
     * Function to call checkForPaymentAvailability in UPI SDK
     *
     * @param context
     * @param paymentOptionHash
     * @param merchantKey
     * @param user_credentials
     * @param paymentType
     */
    @Override
    public void checkForPaymentOptionAvailability(Context context, String paymentOptionHash, String merchantKey, String user_credentials, String paymentType) {
        L.v("paymentType " + paymentType);
        PayUAnalytics mAnalytics = AnalyticsCBInit.getInstance(context);

        if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null)
            this.cbListener = CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback();
        try {
            initUpi();
            Method method = upiWrapperObject.getClass().getMethod("checkForPaymentAvailability", Context.class, String.class, String.class, String.class, String.class);
            method.invoke(upiWrapperObject, context, paymentOptionHash, user_credentials, paymentType, merchantKey);
            mAnalytics.log(CBUtil.getLogMessage(context, CBAnalyticsConstant.CB_LOADER_TYPE_KEY, getClass().getCanonicalName() + CBAnalyticsConstant.PAYMENT_OPTIONS_AVAILABLITY, "", Bank.keyAnalytics, Bank.transactionID, ""));
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + " Exception catch " + e.getMessage());
            mAnalytics.log(CBUtil.getLogMessage(context, CBAnalyticsConstant.CB_LOADER_TYPE_KEY, getClass().getCanonicalName() + CBAnalyticsConstant.PAYMENT_OPTIONS_AVAILABLITY_FALSE, "", Bank.keyAnalytics, Bank.transactionID, ""));
        }
    }

    @Override
    public Fragment makeSeamlessPayment(CustomBrowserConfig customBrowserConfig, Context context) {
        Log.v("Upiwrapper", "Upiwrapper Postdata1");
        try {
            L.v("Class Name: " + getClass().getCanonicalName() + "Make Payment params " + customBrowserConfig.getPayuPostData() + " - -- -  " + customBrowserConfig.getIsPhonePeUserCacheEnabled() + " - --  " + customBrowserConfig.getPaymentType());
            if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null)
                this.cbListener = CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback();
            if (null == upiWrapperObject)
                initUpi();

            this.cbUtil = new CBUtil();
            this.customBrowserConfig = customBrowserConfig;
            this.analytics = AnalyticsCBInit.getInstance(context);
            Bundle upiConfigDataBundle = new Bundle();
            upiConfigDataBundle.putString("packageNameForSpecificApp", customBrowserConfig.getPackageNameForSpecificApp());
            upiConfigDataBundle.putInt("disableIntentSeamlessFailure", customBrowserConfig.getDisableIntentSeamlessFailure());
            upiConfigDataBundle.putString("postURL", customBrowserConfig.getPostURL());
            upiConfigDataBundle.putInt("gmsProviderUpdatedStatus", customBrowserConfig.getGmsProviderUpdatedStatus());
            upiConfigDataBundle.putString("paymentType", customBrowserConfig.getPaymentType());
            upiConfigDataBundle.putBoolean("isPhonePeUserCacheEnabled", customBrowserConfig.getIsPhonePeUserCacheEnabled() == CustomBrowserConfig.TRUE);
            upiConfigDataBundle.putString("payuPostData", customBrowserConfig.getPayuPostData());
            upiConfigDataBundle.putInt("merchantResponseTimeout", customBrowserConfig.getMerchantResponseTimeout());
            upiConfigDataBundle.putBoolean("isProtectedScreen", customBrowserConfig.isProtectedScreen());
            upiConfigDataBundle.putBoolean("isProduction", customBrowserConfig.isProduction());
            method = upiWrapperObject.getClass().getMethod("makeSeamlessPayment", View.class, Bundle.class,Context.class);
            Object frag = method.invoke(upiWrapperObject, customBrowserConfig.getProgressDialogCustomView(), upiConfigDataBundle, context);
            Log.v("Upiwrapper", "Upiwrapper Postdata");
            analyticsLogging(context, CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_POSTDATA, customBrowserConfig.getPayuPostData(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID());
            analyticsLogging(context, CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_URL, customBrowserConfig.getPostURL(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID());

            return (Fragment) frag;
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Exception make payment " + e.getMessage());
            L.v("Class Name: " + getClass().getCanonicalName() + "Cause make payment " + e.getCause());
            this.analytics = AnalyticsCBInit.getInstance(context);
            analytics.log(CBUtil.getLogMessage(context, CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_FAILED, CBAnalyticsConstant.CB_LOADER_MAKE_PAYMENT_FAILED + "_" + e.getMessage(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID(), ""));
        }
        return null;
    }


    @Override
    public void makePayment(Activity activity, CustomBrowserConfig customBrowserConfig) {
        Log.v("Upiwrapper", "Upiwrapper Postdata1");
        try {
            L.v("Class Name: " + getClass().getCanonicalName() + "Make Payment params " + customBrowserConfig.getPayuPostData() + " - -- -  " + customBrowserConfig.getIsPhonePeUserCacheEnabled() + " - --  " + customBrowserConfig.getPaymentType());
            if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null)
                this.cbListener = CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback();
            if (null == upiWrapperObject)
                initUpi();

            this.activity = activity;
            this.cbUtil = new CBUtil();
            this.customBrowserConfig = customBrowserConfig;
            this.analytics = AnalyticsCBInit.getInstance(activity.getApplicationContext());
            Bundle upiConfigDataBundle = new Bundle();
            upiConfigDataBundle.putString("packageNameForSpecificApp", customBrowserConfig.getPackageNameForSpecificApp());
            upiConfigDataBundle.putInt("disableIntentSeamlessFailure", customBrowserConfig.getDisableIntentSeamlessFailure());
            upiConfigDataBundle.putString("postURL", customBrowserConfig.getPostURL());
            upiConfigDataBundle.putInt("gmsProviderUpdatedStatus", customBrowserConfig.getGmsProviderUpdatedStatus());
            upiConfigDataBundle.putString("paymentType", customBrowserConfig.getPaymentType());
            upiConfigDataBundle.putBoolean("isPhonePeUserCacheEnabled", customBrowserConfig.getIsPhonePeUserCacheEnabled() == CustomBrowserConfig.TRUE);
            upiConfigDataBundle.putString("payuPostData", customBrowserConfig.getPayuPostData());
            upiConfigDataBundle.putInt("merchantResponseTimeout", customBrowserConfig.getMerchantResponseTimeout());
            upiConfigDataBundle.putBoolean("isProtectedScreen", customBrowserConfig.isProtectedScreen());
            upiConfigDataBundle.putBoolean("isProduction", customBrowserConfig.isProduction());
            method = upiWrapperObject.getClass().getMethod("makePayment", Activity.class, View.class, Bundle.class);
            method.invoke(upiWrapperObject, activity, customBrowserConfig.getProgressDialogCustomView(), upiConfigDataBundle);
            Log.v("Upiwrapper", "Upiwrapper Postdata");
            analyticsLogging(activity, CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_POSTDATA, customBrowserConfig.getPayuPostData(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID());
            analyticsLogging(activity, CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_URL, customBrowserConfig.getPostURL(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID());

        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Exception make payment " + e.getMessage());
            L.v("Class Name: " + getClass().getCanonicalName() + "Cause make payment " + e.getCause());
            this.analytics = AnalyticsCBInit.getInstance(activity.getApplicationContext());
            analytics.log(CBUtil.getLogMessage(activity.getApplicationContext(), CBAnalyticsConstant.UPIWRAPPER_MAKEPAYMENT_FAILED, CBAnalyticsConstant.CB_LOADER_MAKE_PAYMENT_FAILED + "_" + e.getMessage(), "", Bank.keyAnalytics, customBrowserConfig.getTransactionID(), ""));
        }
    }

    /**
     * Utility method to call verifyVpa of UPI SDK in case of Generic Intent UPI Collect
     *
     * @param verifyVpaHash
     */
    public void verifyVpa(String verifyVpaHash) {
        try {
            L.v("Class Name: " + getClass().getCanonicalName() + "verifyVpa called with Hash" + verifyVpaHash);
            if (CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback() != null)
                this.cbListener = CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback();
            if (null == upiWrapperObject)
                initUpi();

            method = upiWrapperObject.getClass().getMethod("verifyVpa", String.class);
            method.invoke(upiWrapperObject, verifyVpaHash);

        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Exception make payment " + e.getMessage());
            L.v("Class Name: " + getClass().getCanonicalName() + "Cause make payment " + e.getCause());
        }
    }

    private void analyticsLogging(Context context, String key, String value, String item, String sdkMerchantKey, String trnxID) {
        try {
            analytics.log(CBUtil.getLogMessage(context.getApplicationContext(), key, value, item, sdkMerchantKey, trnxID, item));

        } catch (Exception e) {
            L.v("Class analyticsLogging: key" + key + " value" + value + " " + e.getMessage());
        }

    }
}
