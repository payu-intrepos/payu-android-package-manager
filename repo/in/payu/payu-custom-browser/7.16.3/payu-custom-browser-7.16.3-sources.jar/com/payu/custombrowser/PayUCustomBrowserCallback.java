package com.payu.custombrowser;

import android.app.AlertDialog;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;

import android.webkit.WebView;

import com.payu.custombrowser.bean.CustomBrowserResultData;
//import com.payu.magicretry.MagicRetryFragment;

public class PayUCustomBrowserCallback {
    private String postData;
    private String postURL;


    public void onPaymentFailure(String payuResult, String merchantResponse) {
    }

    public void onPaymentTerminate() {
    }

    public void onPaymentSuccess(String payuResult, String merchantResponse) {
    }

    public void onCBErrorReceived(int code, String errormsg) {
    }

    public void setCBProperties(@NonNull String postURL, @NonNull String postData) {
        setPostData(postData);
        setPostURL(postURL);
    }

    public void setCBProperties(WebView webview, Bank payUCustomBrowser) {
    }

    public void onBackButton(AlertDialog.Builder alertDialogBuilder) {
    }

    public void onBackApprove() {
    }

    public void onBackDismiss() {
    }

//    public void initializeMagicRetry(Bank payUCustomBrowser, WebView webview, MagicRetryFragment magicRetryFragment) {
//    }

    public String getPostData() {
        return postData;
    }

    public void setPostData(String postData) {
        this.postData = postData;
    }

    public String getPostURL() {
        return postURL;
    }

    public void setPostURL(String postURL) {
        this.postURL = postURL;
    }

    public void getNavigationDrawerObject(DrawerLayout drawerLayout) {

    }

    public void isPaymentOptionAvailable(CustomBrowserResultData resultData) {
    }

    public void onVpaEntered(String vpa, PackageListDialogFragment packageListDialogFragment) {
    }
}
