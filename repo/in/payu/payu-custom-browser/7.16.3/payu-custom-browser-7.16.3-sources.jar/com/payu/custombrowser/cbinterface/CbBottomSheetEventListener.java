package com.payu.custombrowser.cbinterface;

public interface CbBottomSheetEventListener {

    void onCbBottomSheetCancel();
}
