package com.payu.custombrowser.upiintent;

/**
 * Created by himanshu.gupta on 18/01/18.
 */
@Deprecated
/*
 * This class is now Deprecated.
 * Use {@link com.payu.custombrowser.util.PaymentOption}
 */
public enum Payment {
    TEZ("Tez", "com.google.android.apps.nbu.paisa.user", true, 19),
    GENERIC_INTENT("INTENT", "", false, 16);

    private String paymentName;
    private String packageName;
    private boolean isWebFlowSupported;
    private int minSdk;

    Payment(String paymentName, String packageName, boolean isWebFlowSupported, int minSdk) {
        this.paymentName = paymentName;
        this.packageName = packageName;
        this.isWebFlowSupported = isWebFlowSupported;
        this.minSdk = minSdk;
    }

    public String getPaymentName() {
        return paymentName;
    }

    public String getPackageName() {
        return packageName;
    }

    public boolean isWebFlowSupported() {
        return isWebFlowSupported;
    }

    public void setWebFlowSupported(boolean webFlowSupported) {
        isWebFlowSupported = webFlowSupported;
    }

    public int getMinSdk() {
        return minSdk;
    }
}
