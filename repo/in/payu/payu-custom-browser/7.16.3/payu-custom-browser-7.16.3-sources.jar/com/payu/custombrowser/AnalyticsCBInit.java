package com.payu.custombrowser;

import static com.payu.custombrowser.util.CBUtil.getAnalyticsConfig;

import android.content.Context;

import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;

public class AnalyticsCBInit {
    private static PayUAnalytics instancePayUAnalytics;

    public static PayUAnalytics getInstance(Context context) {
        if (instancePayUAnalytics == null) {
            instancePayUAnalytics = (PayUAnalytics) new AnalyticsFactory(context, getAnalyticsConfig(AnalyticsType.PAYU_ANALYTICS.name())).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
        }
        return instancePayUAnalytics;
    }
}
