package com.payu.custombrowser.util;

/**
 * Created by Minie on 6/14/16.
 */
public class MissingParamException extends RuntimeException {
    public MissingParamException(String msg) {
        super(msg);
    }
}
