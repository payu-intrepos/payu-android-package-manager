package com.payu.upiboltcore.interfaces

import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.listeners.ApiFailedCallback
import com.payu.upiboltcore.models.AccountInfo

interface TransactionService {

    fun checkVPA(vpa: String, requestType: String, payUUPIProCallBack: PayUUPIBoltCallBack)
    fun getProfile(payUUpiProCallBack: PayUUPIBoltCallBack)
    fun makePayment(
        txnAmount: String, account: AccountInfo, payeeName: String, payeeVpa: String,
        note: String? = null, txnId: String, mcc: String? = null, merchantId: String? = null,
        initMode: String, purpose: String, refUrl: String? = null, payeeAccountNo: String? = null,
        payUUpiProCallBack: PayUUPIBoltCallBack, refreshToken: Boolean? = false,
        tid: String? = null, retryCallback: ApiFailedCallback? = null, apiCount: Int = 0
    )
}