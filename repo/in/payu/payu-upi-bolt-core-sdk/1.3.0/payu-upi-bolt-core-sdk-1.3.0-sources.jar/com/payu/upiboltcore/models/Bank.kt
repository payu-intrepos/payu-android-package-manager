package com.payu.upiboltcore.models

import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.upiboltcore.utils.Utils.titleCase
import org.json.JSONObject
import java.util.Locale

data class Bank(
    val bankCode: String,
    val bankId: String,
    val bankName: String,
    val formatType: String,
    val ifsc: String,
    val iin: String,
    val statusCode: String,
    var isCreditSupported: Boolean = false,
    var isUPICreditLineSupported: Boolean = false
) {
    companion object {
        const val BANK_CODE = "bankCode"
        const val BANK_ID = "bankId"
        const val BANK_NAME = "bankName"
        const val FORMAT_TYPE = "formatType"
        const val IFSC = "ifsc"
        const val IIN = "iin"
        const val STATUS_CODE = "statusCode"
        const val IS_CREDIT_SUPPORTED = "isCreditSupported"
        const val IS_UPI_CREDIT_LINE_SUPPORTED = "isUPICreditLineSupported"

        fun getBankFromJSON(jsonObject: JSONObject): Bank {
            return Bank(
                jsonObject.optString(BANK_CODE), jsonObject.opt(BANK_ID)?.toString() ?: "",
                jsonObject.optString(BANK_NAME), jsonObject.optString(FORMAT_TYPE),
                jsonObject.optString(IFSC), jsonObject.optString(IIN),
                jsonObject.optString(STATUS_CODE),
                jsonObject.optBoolean(IS_CREDIT_SUPPORTED, false),
                jsonObject.optBoolean(IS_UPI_CREDIT_LINE_SUPPORTED, false)
            )
        }
        fun getBankData(bank: Bank): PayUBankData {
            return PayUBankData(
                bank.bankName.titleCase(),
                bank.iin,
                bank.ifsc,
                null,
                bank.bankCode,
                bank.bankId,
                bank.isCreditSupported,
                bank.isUPICreditLineSupported
            )
        }
    }
}