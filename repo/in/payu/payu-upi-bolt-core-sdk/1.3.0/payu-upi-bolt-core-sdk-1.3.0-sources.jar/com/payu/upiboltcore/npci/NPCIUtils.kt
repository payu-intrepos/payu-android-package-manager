package com.payu.upiboltcore.npci

import org.npci.upi.security.services.CLServices

internal object NPCIUtils {

    fun getChallenge(type: String, clServices: CLServices): String {
        val deviceId = DeviceInfoManager.deviceInfo?.deviceId
        return clServices.getChallenge(type, deviceId)
    }


}