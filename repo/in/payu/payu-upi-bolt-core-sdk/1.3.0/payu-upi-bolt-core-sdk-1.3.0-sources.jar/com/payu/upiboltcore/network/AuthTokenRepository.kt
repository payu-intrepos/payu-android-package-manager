package com.payu.upiboltcore.network

internal object AuthTokenRepository {

    var authToken: String? = null
}