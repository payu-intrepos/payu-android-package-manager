package com.payu.upiboltcore.constants

enum class DeviceRegistration {
    NOT_REGISTERED, REGISTERED
}

