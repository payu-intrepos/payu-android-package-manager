package com.payu.upiboltcore.network

import android.os.Handler
import android.os.Looper
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.listeners.ApiBaseCallback
import com.payu.upiboltcore.constants.UPIConstants
import com.payu.upiboltcore.constants.payUErrorCodeMap
import com.payu.upiboltcore.models.BaseResponse
import okhttp3.Response

open class BaseRepository {

    protected fun sendSuccessCallback(callback: ApiBaseCallback, response: Any) {
        val handler = Handler(Looper.getMainLooper())
        val runnable = Runnable {
            callback.onApiSuccess(response)
        }
        handler.post(runnable)
    }

    protected fun sendFailureCallback(callback: ApiBaseCallback, errorCode: Int, errorMessage: String) {
        val handler = Handler(Looper.getMainLooper())
        val runnable = Runnable {
            callback.onApiError(errorCode, errorMessage)
        }
        handler.post(runnable)
    }

    protected fun getResponse(
        response: Any,
        apiCallback: ApiBaseCallback,
        getResponse: (response: String) -> Unit
    ) {
        val responseBody = (response as? Response)
            ?.body
            ?.string()
            ?.takeIf { it.isNotBlank() }
            ?: return sendFailureCallback(
                apiCallback,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                PayUResponseMessages.PAYU_INVALID_RESPONSE_MESSAGE
            )

        try {
            val result = BaseResponse.getBaseResponseFromJSON(responseBody).result

            val isFailure =
                result?.errorCode?.isNotEmpty() == true ||
                        result?.status == UPIConstants.RESPONSE_STATUS_FAILURE

            if (!isFailure) {
                getResponse.invoke(responseBody)
                return
            }

            val errorCode = result?.errorCode
                ?.let { payUErrorCodeMap[it] }
                ?: PayUResponseCodes.PAYU_FAILED_STATUS

            sendFailureCallback(
                apiCallback,
                errorCode,
                result?.statusDesc ?: PayUResponseMessages.RUNTIME_ERROR_MESSAGE
            )

        } catch (e: Exception) {
            sendFailureCallback(
                apiCallback,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                e.message ?: PayUResponseMessages.RUNTIME_ERROR_MESSAGE
            )
        }
    }

}