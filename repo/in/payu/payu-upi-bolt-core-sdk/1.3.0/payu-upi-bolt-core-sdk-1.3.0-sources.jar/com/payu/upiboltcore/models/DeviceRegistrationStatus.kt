package com.payu.upiboltcore.models

import com.payu.upiboltcore.constants.DeviceRegistration

data class DeviceRegistrationStatus(
    val deviceStatus: DeviceRegistration,
    var smsReceiverNumber: String? = null,
    val smsContent: String? = null,
    val smsEncKey: String? = null
)
