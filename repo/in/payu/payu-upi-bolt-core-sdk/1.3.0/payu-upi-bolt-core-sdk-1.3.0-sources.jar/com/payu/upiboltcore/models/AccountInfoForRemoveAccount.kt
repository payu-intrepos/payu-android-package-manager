package com.payu.upiboltcore.models

import org.json.JSONObject

data class AccountInfoForRemoveAccount(
    val accId: String
) {
    companion object {
        const val ACC_ID = "accId"
    }

    fun getJSONObject(): JSONObject {
        return JSONObject().apply {
            put(ACC_ID, accId)
        }
    }
}