package com.payu.upiboltcore.constants

import com.payu.commonmodelssdk.constants.PayUResponseCodes

val payUErrorCodeMap = HashMap<String, Int>().apply {
    put(UPIConstants.MOBILE_MISMATCH_CODE, PayUResponseCodes.PAYU_MOBILE_NUMBER_MISMATCHED)
    put(UPIConstants.DEVICE_FINGERPRINT_MISMATCH_CODE, PayUResponseCodes.PAYU_DEVICE_FINGERPRINT_MISMATCHED)
    put(UPIConstants.DEVICE_REGISTRATION_FAILED, PayUResponseCodes.PAYU_DEVICE_REGISTRATION_FAILED)
}