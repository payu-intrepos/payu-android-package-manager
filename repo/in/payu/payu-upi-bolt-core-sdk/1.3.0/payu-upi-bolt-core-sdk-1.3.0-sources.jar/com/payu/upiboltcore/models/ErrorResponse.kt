package com.payu.upiboltcore.models

import com.payu.commonmodelssdk.constants.PayUResponseMessages
import org.json.JSONObject

data class ErrorResponse(
    val status: String,
    val errorCode: String,
    val guid: String,
    val message: String,
) {

    companion object {

        const val STATUS = "status"
        const val ERROR_CODE = "errorCode"
        const val GUID = "guid"
        const val MESSAGE = "message"

        fun getErrorResponseFromJSON(string: String): ErrorResponse {
            return try {
                // Check if the string is valid JSON (not HTML or other content)
                val trimmedString = string.trim()
                if (trimmedString.startsWith("{") && trimmedString.endsWith("}")) {
                    val json = JSONObject(string)
                    ErrorResponse(
                        json.optString(STATUS),
                        json.optString(ERROR_CODE),
                        json.optString(GUID),
                        json.optString(MESSAGE)
                    )
                } else {
                    // Return default error response for non-JSON content (HTML, etc.)
                    ErrorResponse(
                        PayUResponseMessages.RUNTIME_ERROR_MESSAGE,
                        PayUResponseMessages.RUNTIME_ERROR_MESSAGE,
                        "",
                        "Invalid response format received from server"
                    )
                }
            } catch (e: Exception) {
                // Return default error response if JSON parsing fails
                ErrorResponse(
                    PayUResponseMessages.RUNTIME_ERROR_MESSAGE,
                    PayUResponseMessages.RUNTIME_ERROR_MESSAGE,
                    "",
                    "Failed to parse error response: ${e.message}"
                )
            }
        }
    }
}
