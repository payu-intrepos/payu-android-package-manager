package com.payu.flashpay.config

import com.payu.flashpay.enums.PayUFPCurrency

data class PayUFPConfig(
    val merchantName: String,
    val amount: String,
    val currency: PayUFPCurrency? = PayUFPCurrency.INR,
    val isProduction: Boolean = true,
    val merchantKey: String? = null,
    val txnId: String,
    val acsTxnId: String,
    val bgGradientColor: String = ""
)