package com.payu.flashpay.constants

object PayUFPConstants {

    // Environment
    const val PAYU_FP_ENV_UAT = "uat"
    const val PAYU_FP_ENV_PROD = "prod"

    // Message types from ARes messageExtension
    const val PAYU_FP_MESSAGE_TYPE_REGISTRATION = "00"
    const val PAYU_FP_MESSAGE_TYPE_TRANSACTION = "02"

    internal const val PAYU_FP_KEY_MFA_DATA = "data"
    internal const val PAYU_FP_KEY_MFA_MESSAGE_TYPE = "messageType"
    /** Configure API: root `mfaParams` JSON object (empty object validation). */
    internal const val PAYU_FP_KEY_MFA_PARAMS_ROOT = "mfaParams"
    internal const val PAYU_FP_KEY_MFA_NAME = "name"
    internal const val PAYU_FP_KEY_MFA_ID = "id"
    internal const val PAYU_FP_KEY_MFA_CRITICALITY = "criticalityIndicator"
    internal const val PAYU_FP_KEY_MFA_STATUS = "status"
    internal const val PAYU_FP_KEY_ISSUER_IMAGE = "issuerImage"
    internal const val PAYU_FP_KEY_PS_IMAGE = "psImage"
    internal const val PAYU_FP_KEY_CARD_NETWORK_LOGO = "cardNetworkLogo"
    internal const val PAYU_FP_KEY_OOB_INITIATED = "oobInitiated"
    internal const val PAYU_FP_KEY_CARD_ID = "cardId"
    internal const val PAYU_FP_KEY_TEMP_CARD_ID = "tempCardId"
    internal const val PAYU_FP_KEY_MERCHANT_NAME_FIELD = "merchantName"
    internal const val PAYU_FP_KEY_MERCHANT_KEY_FIELD = "merchantKey"
    internal const val PAYU_FP_KEY_TDY_API_KEY_FIELD = "tdyApiKey"
    internal const val PAYU_FP_KEY_TXN_AMOUNT_FIELD = "txnAmount"
    internal const val PAYU_FP_KEY_MERCHANT_ID_FIELD = "merchantId"
    internal const val PAYU_FP_KEY_AMOUNT_FIELD = "amount"

    // JSON keys used in TridentitySDK config
    internal const val PAYU_FP_KEY_ENV = "env"
    internal const val PAYU_FP_KEY_CLIENT_ID = "clientId"
    internal const val PAYU_FP_KEY_TDY_CLIENT_ID = "tdyClientId"
    internal const val PAYU_FP_KEY_TDY_URL = "tdyUrl"
    internal const val PAYU_FP_KEY_AUTH_TYPE = "authType"
    internal const val PAYU_FP_KEY_AUTH_TYPE_VALUE = "BIOMETRIC"
    internal const val PAYU_FP_KEY_RETRY_COUNT = "biometricRetryCount"
    internal const val PAYU_FP_KEY_RETRY_COUNT_VALUE = 3
    internal const val PAYU_FP_KEY_BIN_ID = "binId"
    internal const val PAYU_FP_KEY_BIN_VALUE = "cardBin"
    internal const val PAYU_FP_KEY_BANK_LOGO = "bankLogo"
    internal const val PAYU_FP_KEY_REGISTRATION_TIMEOUT = "registrationTimeout"
    internal const val PAYU_FP_KEY_TRANSACTION_TIMEOUT = "transactionTimeout"
    internal const val PAYU_FP_KEY_BIOMETRIC_TIMEOUT = "autoInvokeBiometricTime"
    internal const val PAYU_FP_KEY_FALLBACK_VISIBILITY_DURATION = "fallbackVisibilityDuration"
    internal const val PAYU_FP_KEY_BANK_ID = "bankId"
    internal const val PAYU_FP_KEY_CUSTOMER_ID = "customerId"
    internal const val PAYU_FP_KEY_MERCHANT_ID = "merchantId"
    internal const val PAYU_FP_KEY_MERCHANT_MOBILE_NO = "mobileInfoText"
    internal const val PAYU_FP_KEY_UID = "uid"
    internal const val PAYU_FP_KEY_TXN_ID = "txnId"
    internal const val PAYU_FP_KEY_BINDING_TYPE = "bindingType"
    internal const val PAYU_FP_KEY_THEME_CONFIG = "themeConfig"
    internal const val PAYU_FP_KEY_THEME_TYPE = "themeType"
    internal const val PAYU_FP_KEY_HASH_KEY = "hashKey"
    internal const val PAYU_FP_KEY_REASON_CODE = "reasonCode"
    internal const val PAYU_FP_KEY_ACS_TXN_ID = "acsTxnId"
    internal const val PAYU_FP_MERCHANT_TXN_ID = "merchantTxnId"
    internal const val PAYU_FP_MOBILE_NO = "mobileNumber"

    // Shared error / status messages used by the validator, coordinator and response mapper.
    const val PAYU_FP_MSG_MFA_PAYLOAD_RESOLVE_FAILED =
        "MFA parameters could not be read from the response. Please try again."
    const val PAYU_FP_MSG_INVALID_PARAMS =
        "Invalid parameters provided. Please check your input and try again."
    /** Appended to a field/param name for configure validation (e.g. `"amount" + suffix`). */
    const val PAYU_FP_MSG_NULL_OR_EMPTY_SUFFIX = " null or empty"
    const val PAYU_FP_MSG_DATA_PARSE_ERROR = "Unable to parse the mfaParams"
    const val PAYU_FP_MSG_INVALID_HASHKEY = "hashKey is empty"
    const val PAYU_FP_MSG_INVALID_TDY_CARD_UID =
        "tdyCardId/tempCardId (uid) is empty for transaction"
    const val PAYU_FP_MSG_AMOUNT_INVALID=
        "amount is invalid for transaction"
    const val PAYU_FP_MSG_SDK_NOT_CONFIGURED =
        "SDK not configured. Please initialize the SDK with valid configuration parameters before making API calls."
    const val PAYU_FP_MSG_ACTIVITY_NOT_APPCOMPAT = "Activity must be AppCompatActivity"
    const val PAYU_FP_MSG_ACTIVITY_DESTROYED =
        "Cannot present biometric screen, activity is finishing/destroyed"
    const val PAYU_FP_MSG_CANNOT_PRESENT_SCREEN =
        "Cannot present authentication selection screen at this time"
    const val PAYU_FP_MSG_UNHANDLED_ERROR = "Unhandled error from authentication SDK"
    const val PAYU_FP_MSG_TDY_CARD_ID_EMPTY = "tdyCardId is null or empty"
    const val PAYU_FP_MSG_BANK_ID_EMPTY = "bankId is null or empty"
    const val PAYU_FP_MSG_TDY_CLIENT_ID_EMPTY = "tdyClientId is empty"

    // Status / message strings for merchant-facing JSON payloads.
    const val PAYU_FP_MSG_SDK_CONFIGURED_SUCCESS = "SDK configured successfully"
    const val PAYU_FP_MSG_PROCEED_WITH_BIOMETRIC = "Proceed with Biometric"
    const val PAYU_FP_MSG = "NoPadding"
    const val PAYU_FP_MSG_CUSTOMER_STATUS_RETRIEVED = "Customer status retrieved"
    const val PAYU_FP_MSG_TRANSACTION_AUTH_SUCCESS = "Transaction authenticated successfully"
    const val PAYU_FP_MSG_USER_OPTED_FOR_OTP = "User opted for OTP authentication"
    const val PAYU_FP_MSG_TXN_CANCELLED_BY_USER = "Transaction cancelled by user"
    const val PAYU_FP_MSG_BIOMETRIC_TIMEOUT = "Biometric authentication has timed out"
    const val PAYU_FP_MSG_BIOMETRIC_MAX_RETRIES = "Maximum retries reached for biometric"
    const val PAYU_FP_MSG_DEVICE_DEREGISTERED_SUCCESS = "Device deregistered successfully"
    const val PAYU_FP_MSG_OTP_CONFIRMATION_ERROR = "Error showing OTP confirmation dialog"

    // Registration merchant-facing messages
    const val PAYU_FP_MSG_REG_GENERIC_ERROR = "We encountered an error"
    const val PAYU_FP_MSG_REG_CANCELLED_BY_USER = "Registration cancelled by user"

    // IntactCheck merchant-facing messages
    const val PAYU_FP_MSG_BIOMETRIC_CHANGED = "Biometric changed"
    const val PAYU_FP_MSG_CUSTOMER_NOT_REGISTERED = "Customer not registered"

    internal const val PAYU_FP_MSG_SIM_MOVEMENT_DEREGISTERED =
        "SIM movement detected, device deregistered"
    internal const val PAYU_FP_MSG_BIOMETRIC_SETTINGS_CHANGED_DEREGISTERED =
        "Biometric authentication settings changed, device deregistered"
    internal const val PAYU_FP_MSG_ROOTING_DEREGISTERED =
        "Device is jailbroken, device deregistered"
    internal const val ENV_SIGNATURE =  "4aca36d11d2ef032bb6813d6b8c7122fb79cb4c700b062cf6665706ee8cc3b"


    // Response keys
    const val PAYU_FP_KEY_CODE = "code"
    const val PAYU_FP_KEY_STATUS = "status"
    const val PAYU_FP_KEY_MESSAGE = "message"
    const val PAYU_FP_KEY_SUB_PARAM = "subParam"
    const val PAYU_FP_KEY_CUSTOMER_STATUS = "customerStatus"
    const val PAYU_FP_KEY_DATA_KEY = "dataKey"
    const val PAYU_FP_KEY_INTACT = "intact"
    const val PAYU_FP_KEY_TDY_CARD_ID_RESP = "tdyCardId"

    // Data key values for sdkStatusUpdate (must match docs verbatim)
    const val PAYU_FP_DATA_KEY_PAYMENT_STATUS = "paymentStatusData"
    const val PAYU_FP_DATA_KEY_DEREGISTRATION = "deregistrationData"
    const val PAYU_FP_DATA_KEY_PROCEED_WITH_OTP = "proceedWithOTP"

    // status field values
    const val PAYU_FP_STATUS_SUCCESS = "SUCCESS"
    const val PAYU_FP_STATUS_FAILURE = "FAILURE"
    const val PAYU_FP_STATUS_FALLBACK = "FALLBACK"
    internal const val PAYU_FP_STATUS_CANCELLED = "CANCELLED"
    internal const val PAYU_FP_STATUS_EXPIRED = "EXPIRED"
    internal const val MATERIAL_BYTE_LENGTH = 32

    // Registration status values
    const val PAYU_FP_REG_STATUS_SUCCESS = "registration_comm_success"

    const val PAYU_FP_TOKEN_LENGTH_ERROR = "Token must be at least 7 characters long."
    const val PAYU_FP_MFA_CONFIG_ERROR = "MFA configuration material unavailable"
    internal const val FRAME_SUFFIX_BITS = 128

    const val PAYU_FP_CODE_SUCCESS = 200
    const val PAYU_FP_CODE_BIOMETRIC_FAILED_OR_OTP = 51

    const val PAYU_FP_CODE_SDK_NOT_CONFIGURED = 52
    const val PAYU_FP_CODE_INVALID_PARAMS = 53

    const val PAYU_FP_CODE_CUSTOMER_NOT_REGISTERED = 54

    const val PAYU_FP_CODE_TXN_BIOMETRIC_TIMEOUT = 55
    const val PAYU_FP_CODE_TXN_CANCELLED_BY_USER = 56

    const val PAYU_FP_CODE_TRIDENTITY_USER_CANCELLED = 57

    const val PAYU_FP_CODE_CANNOT_PRESENT_SCREEN = 58
    const val PAYU_FP_CODE_REG_CANCELLED_BY_USER = 59
    const val PAYU_FP_CODE_SDK_EXCEPTION = 59

    const val PAYU_FP_CODE_UNHANDLED_ERROR = 60
    const val PAYU_FP_CODE_REG_GENERIC_ERROR = 400
    internal val PAYU_FP_AUTO_DEREGISTER_CODES =
        intArrayOf(10, 11, 12, 392, 300, 303, 305, 4050, 4006)

    internal const val PAYU_FP_DE_REGISTERED_CONFIRMATION_TIMEOUT = 5_000L

    internal const val MIN_TOKEN_LENGTH = 7

    const val SDK_PLATFORM_KEY = "sdk_platform"
    const val SDK_VERSION = "sdk_version"
    const val IS_CO_BRANDED = "isCoBranded"
    const val MERCHANT_LOGO = "merchantLogo"

    const val IS_GRADIENT_REQUIRED = "bgGradientColor"

    const val SHOULD_SHOW_LOADER = "shouldShowLoader"

    const val SHOULD_STEPPER_BE_ON_TOP = "shouldStepperBeOnTop"

    const val PLATFORM_KEY = "platform"
    const val PLATFORM_VALUE = "android"
    const val NAME_KEY = "name"
    const val NAME_VALUE = "payu-flashPay-sdk"
    const val VERSION_KEY = "version"
    const val TDY_CARD_ID = "tdy_card_id"
    const val TEMP_CARD_ID = "temp_card_id"
    const val CARD_TYPE = "card_type"
    const val PAYU_FP_AES = "AES"
}
