package com.payu.flashpay.viewModel

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPUiConstants
import com.payu.flashpay.constants.PayUFPUiConstants.MILLIS_PER_SECOND
import com.payu.flashpay.constants.PayUFPUiConstants.MILLIS_PER_SECOND_DOUBLE
import com.payu.flashpay.coordinator.PayUFPTransactionCoordinator
import com.payu.flashpay.enums.AuthType
import com.payu.flashpay.enums.PayUFPCurrency
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

internal class PayUFPAuthViewModel(private val args: AuthUiArgs) : ViewModel() {

    data class AuthUiArgs(
        val logoUrl: String? = null,
        val networkUrl: String? = null,
        val merchantName: String? = null,
        val txnAmount: String? = null,
        val currency: PayUFPCurrency? = null,
        val fallbackTimeout: Double? = null,
        val biometricTimeout: Double? = null,
        val fallbackVisibilityDuration: Double? = null,
        val themeType: String? = null,
        val merchantLogo: Int? = null
    )

    data class AuthUiData(
        val args: AuthUiArgs,
        val showOtpOption: Boolean = false,
        val autoRedirectSecondsLeft: Double? = null,
        val otpRedirectSecondsLeft: Double? = null,
        val transactionSecondsLeft: Double? = null,
        val autoRedirectProgress: Float = 0f,
        val noInternetMessageVisible: Boolean = false,
        val processing: Boolean = false
    ) {
        val visibleTimer: VisibleTimer
            get() = when {
                (autoRedirectSecondsLeft ?: 0.0) > 0.0 -> VisibleTimer.BIOMETRIC
                (transactionSecondsLeft ?: 0.0) > 0.0 -> VisibleTimer.TRANSACTION
                else -> VisibleTimer.NONE
            }

        val visibleTimerSeconds: Double?
            get() = when (visibleTimer) {
                VisibleTimer.BIOMETRIC -> autoRedirectSecondsLeft
                VisibleTimer.TRANSACTION -> transactionSecondsLeft
                VisibleTimer.NONE -> null
            }

        val confirmButtonProgress: Float
            get() = if (isConfirmButtonAnimationEnabled) autoRedirectProgress else 1f

        // Animation is shown only when biometricTimeout > 0 and the timer is actively running.
        // If autoInvokeBiometricTime is 0 or absent, autoRedirectSecondsLeft stays null and
        // the button must render as a normal (fully-filled) button, not gray.
        val isConfirmButtonAnimationEnabled: Boolean
            get() = autoRedirectSecondsLeft != null && autoRedirectSecondsLeft != 0.0
    }

    enum class VisibleTimer {
        BIOMETRIC,
        TRANSACTION,
        NONE
    }

    private val _uiData = MutableStateFlow(AuthUiData(args))
    val uiData: StateFlow<AuthUiData> = _uiData.asStateFlow()

    private var hostActivity: AppCompatActivity? = null

    private var redirectJob: Job? = null
    private var otpVisibilityJob: Job? = null
    private var fallbackJob: Job? = null
    private var selectionEmitted = false

    fun attachHost(activity: AppCompatActivity) {
        hostActivity = activity
    }

    fun detachHost() {
        hostActivity = null
    }

    init {
        startAutoRedirectTimer()
        startOtpVisibilityTimer()
        startFallbackTimeoutTimer()
    }

    fun onConfirm(reason: String? = null) {
        _uiData.update {
            it.copy(
                autoRedirectProgress = 1f,
                autoRedirectSecondsLeft = null,
                transactionSecondsLeft = null,
                otpRedirectSecondsLeft = null,
                showOtpOption = false,
            )
        }
        emitSelection(
            AuthType.BIOMETRIC,
            biometricEventValue(reason),
            reason,
            null,
        )
    }

    fun onUseOtp(reason: String? = null, reasonCode: String? = null) = emitSelection(
        AuthType.OTP,
        otpFallbackEventValue(reason) ?: PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_OTP_SELECTED,
        reason,
        reasonCode
    )

    fun onCancelTransaction(reason: String? = PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CANCELLED_TXN) =
        emitSelection(
            AuthType.USER_CANCELLED,
            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_CANCELLED_BY_USER,
            reason,
            null
        )

    fun onInternetUnavailable() {
        _uiData.update { it.copy(noInternetMessageVisible = true) }
    }

    fun onInternetMessageShown() {
        _uiData.update { it.copy(noInternetMessageVisible = false) }
    }

    fun stopAutoInvoke() {
        redirectJob?.cancel()
        otpVisibilityJob?.cancel()
        _uiData.update {
            it.copy(
                autoRedirectSecondsLeft = null,
                autoRedirectProgress = 1f,
                showOtpOption = true
            )
        }
    }

    private fun emitSelection(type: AuthType, eventValue: String, reason: String?, reasonCode: String?) {
        if (selectionEmitted) return
        selectionEmitted = true
        cancelTimers()
        if (type == AuthType.BIOMETRIC) {
            _uiData.update {
                it.copy(
                    transactionSecondsLeft = null,
                    otpRedirectSecondsLeft = null,
                    showOtpOption = false,
                    processing = true,
                )
            }
        }
        handleAuthSelection(type, eventValue, reason, reasonCode)
    }
    
    private fun startAutoRedirectTimer() {
        val totalSeconds = args.biometricTimeout?.takeIf { it > 0 } ?: return
        _uiData.update {
            it.copy(
                autoRedirectSecondsLeft = totalSeconds,
                autoRedirectProgress = 0f
            )
        }
    }

    private fun startOtpVisibilityTimer() {
        val totalSeconds = args.fallbackVisibilityDuration?.takeIf { it > 0 } ?: 0.0
        if (totalSeconds <= 0.0) {
            _uiData.update { it.copy(showOtpOption = true) }
            return
        }
        val totalMillis = (totalSeconds * MILLIS_PER_SECOND).toLong()
        _uiData.update { it.copy(otpRedirectSecondsLeft = totalSeconds) }
        otpVisibilityJob = viewModelScope.launch {
            var remainingMillis = totalMillis
            while (remainingMillis > 0) {
                val delayMs = minOf(MILLIS_PER_SECOND, remainingMillis)
                delay(delayMs)
                remainingMillis -= delayMs
                _uiData.update { it.copy(otpRedirectSecondsLeft = remainingMillis / MILLIS_PER_SECOND_DOUBLE) }
            }
            _uiData.update { it.copy(showOtpOption = true, otpRedirectSecondsLeft = null) }
        }
    }

    private fun startFallbackTimeoutTimer() {
        val totalSeconds = args.fallbackTimeout?.takeIf { it > 0 } ?: return
        val totalMillis = (totalSeconds * MILLIS_PER_SECOND).toLong()
        _uiData.update { it.copy(transactionSecondsLeft = totalSeconds) }
        fallbackJob = viewModelScope.launch {
            var remainingMillis = totalMillis
            while (remainingMillis > 0) {
                val delayMs = minOf(MILLIS_PER_SECOND, remainingMillis)
                delay(delayMs)
                remainingMillis -= delayMs
                _uiData.update { it.copy(transactionSecondsLeft = remainingMillis / MILLIS_PER_SECOND_DOUBLE) }
            }
            _uiData.update { it.copy(transactionSecondsLeft = null) }
            emitSelection(
                AuthType.OTP,
                PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK_TIMER_EXPIRED,
                PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED,
                PayUFPUiConstants.REASON_CODE_E01
            )
        }
    }

    fun cancelTimers() {
        redirectJob?.cancel()
        otpVisibilityJob?.cancel()
        fallbackJob?.cancel()
    }

    private fun biometricEventValue(reason: String?): String =
        if (reason == PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED) {
            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_BIOMETRIC_AUTO_SELECTED
        } else {
            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_BIOMETRIC_MANUAL_SELECTED
        }

    private fun otpFallbackEventValue(reason: String?): String? = when (reason) {
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_PRESSED_BACK ->
            PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK_BACKPRESS
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CHOSE_OTP ->
            PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK_MANUAL
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED ->
            PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK_TIMER_EXPIRED
        else -> null
    }

    override fun onCleared() {
        cancelTimers()
        hostActivity = null
        super.onCleared()
    }

    internal class Factory(private val args: AuthUiArgs) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(PayUFPAuthViewModel::class.java)) {
                "Unknown ViewModel class: ${modelClass.name}"
            }
            return PayUFPAuthViewModel(args) as T
        }
    }
    private fun handleAuthSelection(
        type: AuthType,
        eventValue: String,
        reason: String?,
        reasonCode: String?
    ) {
        val activity = hostActivity ?: return
        logAuthSelectionOutcome(activity, type, reason)
        PayUFPTransactionCoordinator.handleAuthSelection(
            appCompatActivity = activity,
            authType = type,
            otpFallbackEventValue = eventValue,
            reason = reason,
            reasonCode = reasonCode,
        )
    }

    private fun logAuthSelectionOutcome(
        activity: AppCompatActivity,
        type: AuthType,
        reason: String?
    ) {
        when (type) {
            AuthType.BIOMETRIC -> {
                if (reason == PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED) {
                    PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                        activity,
                        PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
                        PayUFPLoggingConstants.PAYU_FP_LOADER_COMPLETED,
                        PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_BIOMETRIC
                    )
                }
                PayUFPTransactionUiHelper.logAuthSelectionEvent(
                    activity,
                    PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_FLOW_INITIATED,
                    reason
                )
            }
            AuthType.OTP -> {
                if (reason == PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED) {
                    PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                        activity,
                        PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
                        PayUFPLoggingConstants.PAYU_FP_INACTIVITY_TIMEOUT,
                        PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_OTP
                    )
                }
                logAuthUiDismissed(activity, reason)
            }
            AuthType.USER_CANCELLED -> logAuthUiDismissed(activity, reason)
        }
    }
    
    private fun logAuthUiDismissed(activity: AppCompatActivity, reason: String?) {
        reason ?: return
        PayUFPTransactionUiHelper.logAuthSelectionEvent(
            activity,
            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_UI_DISMISSED,
            reason
        )
    }
}