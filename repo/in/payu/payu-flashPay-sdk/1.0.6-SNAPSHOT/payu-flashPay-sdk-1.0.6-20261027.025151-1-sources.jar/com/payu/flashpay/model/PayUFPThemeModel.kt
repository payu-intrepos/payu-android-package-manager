package com.payu.flashpay.model

data class PayUFPThemeModel(
    val uiCustomization: PayUFPUICustomization? = null
)


data class PayUFPUICustomization(
    val labelCustomization: PayUFPLabelCustomization? = null,
    val buttonCustomization: PayUFPButtonCustomization? = null,
    val toolbarCustomization: PayUFPToolbarCustomization? = null,
    val  logoConfig: PayUFPLogoConfig? = null,
)

data class PayUFPLabelCustomization(
    val headingCustomization: PayUFPHeadingContentCustomization? = null,
    val subHeadingCustomization: PayUFPSubHeadingCustomization? = null,
)

data class PayUFPHeadingContentCustomization(
    val textColor: String? = null,
    val fontSize: Float? = null,
    val fontName: String? = null,
)

data class PayUFPSubHeadingCustomization(
    val textColor: String? = null,
    val fontSize: Float? = null,
    val fontName: String? = null,
)

data class PayUFPButtonCustomization(
    val primaryButtonCustomization: PayUFPPrimaryButtonCustomization? = null,
    val buttonCornerRadius: Int? = null,
    val fontSize: Float? = null,
    val fontName: String? = null,
    val buttonTextTransform: String? = null,
)

data class PayUFPPrimaryButtonCustomization(
    val enabledBackgroundColor: String? = null,
    val enabledTextColor: String? = null
)

data class PayUFPToolbarCustomization(
    val backgroundColor: String? = null,
    val textColor: String? = null,
    val fontSize: Float? = null,
    val fontName: String? = null,
)

data class PayUFPLogoConfig(
    val merchant: Int? = null,
    val mfaBiometric: Int? = null,
    val mfaMessaging: Int? = null,
    val mfaTick: Int? = null,
    val mfaBiometricEnabled: Int? = null,
)
