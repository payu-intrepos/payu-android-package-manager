package com.payu.flashpay.utils

import android.util.Base64
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPUiConstants

internal object PayUFHandler {

    val deriveValue: String by lazy {
        val derive = PayUFPContentCodec.toByteArrayValue(PayUFPConstants.ENV_SIGNATURE) ?: return@lazy ""
        // CONFIG_VERSION is Base64; toByteArrayValue() only parses hex (see bytesFromHex).
        val byteString = runCatching { getUpdatedValue(PayUFPLoggingConstants.CONFIG_VERSION) }
            .getOrNull()
            ?.takeIf { it.isNotEmpty() }
            ?: return@lazy ""
        val bytes = combine(PayUFPUiConstants.CLIENT_IDENTIFIER, derive, byteString)
        if (bytes.isEmpty()) "" else String(bytes, Charsets.UTF_8)
    }

    internal fun combine(a: ByteArray, b: ByteArray, c: ByteArray): ByteArray {
        if (a.isEmpty() || a.size != b.size || b.size != c.size) return byteArrayOf()
        return ByteArray(a.size) { i ->
            (a[i].toInt() and 0xFF xor b[i].toInt() and 0xFF xor c[i].toInt() and 0xFF).toByte()
        }
    }

    private fun getUpdatedValue(input: String): ByteArray {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                java.util.Base64.getDecoder().decode(input)
            } else {
                Base64.decode(input, Base64.DEFAULT)
            }
        } catch (e: RuntimeException) {
            if (isAndroidBase64Unavailable(e)) {
                java.util.Base64.getDecoder().decode(input)
            } else {
                throw e
            }
        }
    }

    private fun isAndroidBase64Unavailable(error: RuntimeException): Boolean {
        val message = error.message ?: return false
        return message == "Stub!" || message.contains("not mocked")
    }
}
