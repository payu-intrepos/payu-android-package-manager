
package com.payu.flashpay.view

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.R
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPUiConstants
import com.payu.flashpay.enums.AuthType
import com.payu.flashpay.enums.PayUFPCurrency
import com.payu.flashpay.enums.EventSeverity
import com.payu.flashpay.enums.EventStatus
import com.payu.flashpay.enums.EventType
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.payu.flashpay.viewModel.PayUFPAuthViewModel
import org.json.JSONObject

internal object PayUFPTransactionUiHelper {

    private var txnProgressDialog: ProgressDialog? = null

    fun isHostDestroyedOrFinishing(host: Context): Boolean {
        val activity = host as? Activity ?: return true
        return PayUFPUIUtils.isActivityDestroyedOrFinishing(activity)
    }

    fun logTransactionAuthUiShown(activity: Activity, authUIShown: String) {
        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(
                    PayUFPLoggingConstants.EVENT_VALUE,
                    PayUFPLoggingConstants.PAYU_FP_BIOMETRIC_NUDGE_UI_SHOWN
                )
                put(PayUFPLoggingConstants.PAYU_FP_VIEWED, authUIShown)
                put(
                    PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                        PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TXN_ID to PayUFPDataManager.payUFPConfig?.txnId,
                        PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MERCHANT_NAME to PayUFPDataManager.payUFPConfig?.merchantName,
                        PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TXN_AMOUNT to PayUFPDataManager.payUFPConfig?.amount
                    )
                )
            }
        )
    }

    fun logAuthSelectionEvent(activity: Activity, eventValue: String, reason: String?) {
        PayUFPLoggingUtils.logMessage(
            activity,
            EventSeverity.Low,
            EventType.Info,
            EventStatus.Initiated,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(PayUFPLoggingConstants.EVENT_VALUE, eventValue)
                reason?.let { put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(PayUFPLoggingConstants.PAYU_FP_DATA_KEY_REASON to it)) }
            }
        )
    }

    fun logBioMetricOutComeEvent(
        activity: Activity,
        eventValue: String?,
        outCome: String?,
        authType: String? = PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_BIOMETRIC
    ) {
        PayUFPLoggingUtils.logMessage(
            activity,
            EventSeverity.Low,
            EventType.Info,
            EventStatus.Initiated,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(
                    PayUFPLoggingConstants.EVENT_VALUE,
                    eventValue
                )
                put(
                    PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE,
                    authType
                )

                outCome?.let {
                    put(
                        PayUFPLoggingConstants.PAYU_FP_OUTCOME,
                        it
                    )
                    put(
                        PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA,
                        PayUFPLoggingUtils.dataJson(PayUFPLoggingConstants.PAYU_FP_OUTCOME to it)
                    )

                }
            }
        )
    }

    fun parseAuthUiArgs(bundle: Bundle?): PayUFPAuthViewModel.AuthUiArgs {
        val args = bundle ?: Bundle.EMPTY
        return PayUFPAuthViewModel.AuthUiArgs(
            logoUrl = args.getString(PayUFPUiConstants.AUTH_ARG_LOGO_URL),
            networkUrl = args.getString(PayUFPUiConstants.AUTH_ARG_NETWORK_URL),
            merchantName = args.getString(PayUFPUiConstants.AUTH_ARG_MERCHANT_NAME),
            txnAmount = args.getString(PayUFPUiConstants.AUTH_ARG_TXN_AMOUNT),
            currency = args.getString(PayUFPUiConstants.AUTH_ARG_CURRENCY)?.let { name ->
                runCatching { PayUFPCurrency.valueOf(name) }.getOrNull()
            },
            fallbackTimeout = args.takeIf { it.containsKey(PayUFPUiConstants.AUTH_ARG_FALLBACK_TIMEOUT) }
                ?.getDouble(PayUFPUiConstants.AUTH_ARG_FALLBACK_TIMEOUT),
            biometricTimeout = args.takeIf { it.containsKey(PayUFPUiConstants.AUTH_ARG_BIOMETRIC_TIMEOUT) }
                ?.getDouble(PayUFPUiConstants.AUTH_ARG_BIOMETRIC_TIMEOUT),
            fallbackVisibilityDuration = args.takeIf {
                it.containsKey(PayUFPUiConstants.AUTH_ARG_FALLBACK_VISIBILITY_DURATION)
            }?.getDouble(PayUFPUiConstants.AUTH_ARG_FALLBACK_VISIBILITY_DURATION),
            themeType = args.getString(PayUFPUiConstants.AUTH_ARG_THEME_TYPE),
            merchantLogo = args.takeIf { it.containsKey(PayUFPUiConstants.AUTH_ARG_MERCHANT_LOGO) }
                ?.getInt(PayUFPUiConstants.AUTH_ARG_MERCHANT_LOGO),
        )
    }

    fun openTransactionAuthSelectionFlow(
        activity: AppCompatActivity,
        onHostInvalid: () -> Unit,
        onAuthTypeSelected: (AuthType, String?, String?, String?) -> Unit,
    ) {
        PayUFPUIUtils.dispatchOnMain(activity) {
            if (isHostDestroyedOrFinishing(activity)) {
                onHostInvalid()
                return@dispatchOnMain
            }
            val biometricTimeout = PayUFPDataManager.mfaParams?.autoInvokeBiometricTime
            if (biometricTimeout != null && biometricTimeout > 0.0 && biometricTimeout < PayUFPUiConstants.BIOMETRIC_DIRECT_INVOKE_THRESHOLD_SECONDS) {
                // Sub-second timeout — skip the auth-selection UI and fire biometric immediately.
                onAuthTypeSelected(
                    AuthType.BIOMETRIC,
                    PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_BIOMETRIC_AUTO_SELECTED,
                    PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED,
                    null
                )
                return@dispatchOnMain
            }
            showAuthSelectionUi(
                activity = activity,
                merchantName = PayUFPDataManager.payUFPConfig?.merchantName,
                txnAmount = PayUFPDataManager.payUFPConfig?.amount,
                currency = PayUFPDataManager.payUFPConfig?.currency,
                logoUrl = PayUFPDataManager.mfaParams?.bankLogo,
                networkUrl = PayUFPDataManager.mfaParams?.cardNetworkLogo,
                fallbackTimeout = PayUFPDataManager.mfaParams?.transactionTimeout?.toDouble(),
                biometricTimeout = biometricTimeout,
                fallbackVisibilityDuration = PayUFPDataManager.mfaParams?.fallbackVisibilityDuration?.toDouble(),
                themeType = PayUFPDataManager.mfaParams?.themeType,
                merchantLogo = PayUFPDataManager.payUFPConfig?.merchantLogo,
            )
        }
    }

    fun dismissAuthSelectionUi(activity: AppCompatActivity) {
        if (isHostDestroyedOrFinishing(activity)) {
            return
        }
        val fragment = activity.supportFragmentManager
            .findFragmentByTag(PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG) as? PayUFPAuthSelectionFragment
        fragment?.dismissAuthUi()
    }

    fun showTransactionProgressLoader(activity: AppCompatActivity) {
        PayUFPUIUtils.dispatchOnMain(activity) {
            if (isHostDestroyedOrFinishing(activity) || txnProgressDialog?.isShowing == true) {
                return@dispatchOnMain
            }
            try {
                txnProgressDialog = ProgressDialog(activity).apply {
                    setMessage(activity.getString(R.string.payu_fp_processing_payment))
                    setCancelable(false)
                    setCanceledOnTouchOutside(false)
                }
                txnProgressDialog?.show()
            } catch (e: Exception) {
                PayUFPUIUtils.logExceptionToAnalytics(
                    activity,
                    PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG,
                    "Failed to show transaction progress loader",
                    e
                )
            }
        }
    }

    fun dismissTransactionProgressLoader() {
        try {
            txnProgressDialog?.dismiss()
        } catch (_: Exception) {
        }
        txnProgressDialog = null
    }

    private fun canPresentDeRegisterBottomSheet(
        isActivityDestroyedOrFinishing: Boolean,
        isFragmentManagerStateSaved: Boolean,
        isDeRegisterSheetAlreadyShowing: Boolean,
    ): Boolean =
        !isActivityDestroyedOrFinishing &&
                !isFragmentManagerStateSaved &&
                !isDeRegisterSheetAlreadyShowing

    fun showAuthSelectionUi(
        activity: AppCompatActivity,
        merchantName: String?,
        txnAmount: String?,
        currency: PayUFPCurrency? = null,
        logoUrl: String? = null,
        networkUrl: String? = null,
        fallbackTimeout: Double? = null,
        biometricTimeout: Double? = null,
        fallbackVisibilityDuration: Double? = null,
        themeType: String? = null,
        merchantLogo: Int? = null,
    ) {
        val fragmentManager = activity.supportFragmentManager
        if (fragmentManager.findFragmentByTag(PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG) != null) {
            // Auth UI is already on screen — block duplicate presentation; no merchant callback.
            return
        }
        val fragment = PayUFPAuthSelectionFragment.newInstance(
            logoUrl = logoUrl,
            networkUrl = networkUrl,
            merchantName = merchantName,
            txnAmount = txnAmount,
            currency = currency,
            fallbackTimeout = fallbackTimeout,
            biometricTimeout = biometricTimeout,
            fallbackVisibilityDuration = fallbackVisibilityDuration,
            themeType = themeType,
            merchantLogo = merchantLogo,
        )
        if (fragmentManager.isStateSaved) {
            PayUFPLoggingUtils.logMessage(
                activity,
                analyticsJson = JSONObject().apply {
                    put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                    put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_TXN_UNEXPECTED_ERROR)
                    put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                        PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MESSAGE to
                                PayUFPLoggingConstants.PAYU_FP_DATA_VALUE_FRAGMENT_ALREADY_SAVED
                    ))
                }
            )
            return
        }
        fragmentManager.beginTransaction()
            .add(android.R.id.content, fragment, PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG)
            .commit()
    }


}
