package com.payu.flashpay.model

import android.content.Context
import android.util.Log
import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.utils.PayUFPContentCodec
import com.payu.flashpay.utils.PayUFPUIUtils.normalizeId
import org.json.JSONObject
import com.payu.flashpay.coordinator.PayUFPConfigureCoordinatorLogging
import com.payu.flashpay.storage.PayUFPDataManager

internal sealed class PayUFPMfaParamsBuildResult {
    internal data class Success(val params: PayUFPMfaParams?) : PayUFPMfaParamsBuildResult()
    internal data class MfaPayloadResolveFailed(val cause: Throwable) : PayUFPMfaParamsBuildResult()
}

internal data class PayUFPMfaParams(
    val messageType: String? = null,
    val name: String? = null,
    val id: String? = null,
    val criticalityIndicator: Boolean = false,
    val status: String? = null,
    val tdyClientId: String? = null,
    val tdyCardId: String? = null,
    val tempCardId: String? = null,
    val bankId: String? = null,
    val customerId: String? = null,
    val binValue: String? = null,
    val bankLogo: String? = null,
    val cardNetworkLogo: String? = null,
    val issuerImage: String? = null,
    val psImage: String? = null,
    val tdyUrl: String? = null,
    val transactionTimeout: Int = 60,
    val registrationTimeout: Int = 32,
    val autoInvokeBiometricTime: Double = 0.0,
    val tdyApiKey: String? = null,
    val fallbackVisibilityDuration: Int = 0,
    val hashKey: String? = null,
    val themeType: String? = null,
    val bindingType: String? = null,
    val oobInitiated: Boolean = false,
    var txnAmount: String? = null,
    val merchantTxnId: String? = null,
    val merchantKey: String? = null,
    val merchantId: String? = null,
    val merchantMobileNo: String? = null,
) {
    internal val uid: String?
        get() = tempCardId.normalizeId() ?: tdyCardId.normalizeId()

    companion object {
        fun buildMfaParams(
            context: Context,
            payUFPConfig: PayUFPConfig,
            mfaParams: JSONObject
        ): PayUFPMfaParamsBuildResult {
            return try {
                val datValue = mfaParams.optString(PayUFPConstants.PAYU_FP_KEY_MFA_DATA)
                val dataJson = getJsonFromMfaData(datValue)
                PayUFPConfigureCoordinatorLogging.logMfaParamsParsed(context)
                PayUFPMfaParamsBuildResult.Success(fromDataObject(mfaParams, dataJson, payUFPConfig))
            } catch (e: Throwable) {
                PayUFPMfaParamsBuildResult.MfaPayloadResolveFailed(e)
            }
        }

        private fun getJsonFromMfaData(
            data: String
        ): JSONObject {
            val jsonText = PayUFPContentCodec.getDataValueFromMFA(data)
            return JSONObject(jsonText)
        }

        private fun fromDataObject(
            mfaParams: JSONObject,
            dataJson: JSONObject,
            payUFPConfig: PayUFPConfig
        ): PayUFPMfaParams = PayUFPMfaParams(
            messageType = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_MFA_MESSAGE_TYPE),
            name = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_MFA_NAME),
            id = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_MFA_ID),
            criticalityIndicator = mfaParams.optBoolean(
                PayUFPConstants.PAYU_FP_KEY_MFA_CRITICALITY,
                false
            ),
            status = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_MFA_STATUS),
            tdyClientId = mfaParams.optString(PayUFPConstants.PAYU_FP_KEY_TDY_CLIENT_ID)
                ?: dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_CLIENT_ID),
            tdyCardId = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_TDY_CARD_ID_RESP)
                ?: mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_CARD_ID),
            issuerImage = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_ISSUER_IMAGE),
            psImage = mfaParams.optNullableString(PayUFPConstants.PAYU_FP_KEY_PS_IMAGE),
            oobInitiated = mfaParams.optBoolean(
                PayUFPConstants.PAYU_FP_KEY_OOB_INITIATED,
                false
            ),
            tempCardId = dataJson.optString(PayUFPConstants.PAYU_FP_KEY_TEMP_CARD_ID),
            bankId = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_BANK_ID),
            customerId = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_CUSTOMER_ID),
            merchantId = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_MERCHANT_ID),
            merchantMobileNo = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_MERCHANT_MOBILE_NO),
            binValue = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_BIN_VALUE),
            bankLogo = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_BANK_LOGO),
            cardNetworkLogo = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_CARD_NETWORK_LOGO),
            tdyUrl = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_TDY_URL),
            transactionTimeout = dataJson.optInt(
                PayUFPConstants.PAYU_FP_KEY_TRANSACTION_TIMEOUT,
                30
            ),
            registrationTimeout = dataJson.optInt(
                PayUFPConstants.PAYU_FP_KEY_REGISTRATION_TIMEOUT,
                0
            ),
            fallbackVisibilityDuration = dataJson.optInt(
                PayUFPConstants.PAYU_FP_KEY_FALLBACK_VISIBILITY_DURATION,
                0
            ),
            autoInvokeBiometricTime = dataJson.optDouble(
                PayUFPConstants.PAYU_FP_KEY_BIOMETRIC_TIMEOUT,
                0.0
            ),
            tdyApiKey = dataJson.optString(PayUFPConstants.PAYU_FP_KEY_TDY_API_KEY_FIELD),
            hashKey = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_HASH_KEY),
            themeType = dataJson.optNullableString(PayUFPConstants.PAYU_FP_KEY_THEME_TYPE),
            merchantKey = dataJson.optString(PayUFPConstants.PAYU_FP_KEY_MERCHANT_KEY_FIELD, null) ?: payUFPConfig.merchantKey,
            merchantTxnId = dataJson.optString(PayUFPConstants.PAYU_FP_MERCHANT_TXN_ID),
            txnAmount = dataJson.optString(PayUFPConstants.PAYU_FP_KEY_TXN_AMOUNT_FIELD, null)
                ?: payUFPConfig.amount,
            bindingType = dataJson.optString(PayUFPConstants.PAYU_FP_KEY_BINDING_TYPE)
        )

        private fun JSONObject.optNullableString(key: String): String? =
            optString(key, "").normalizeId()
    }
}
