package com.payu.flashpay.view

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Property
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.Group
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.payu.flashpay.R
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPUiConstants
import com.payu.flashpay.enums.PayUFPCurrency
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.payu.flashpay.utils.PayUFPUIUtils.loadImageUrl
import com.payu.flashpay.viewModel.PayUFPAuthViewModel
import org.json.JSONObject
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

internal class PayUFPAuthSelectionFragment : Fragment() {

    private val viewModel: PayUFPAuthViewModel by viewModels {
        PayUFPAuthViewModel.Factory(PayUFPTransactionUiHelper.parseAuthUiArgs(arguments))
    }

    private var otpConfirmationDialog: AlertDialog? = null
    private var biometricFlowInProgress = false
    private var processingStateApplied = false
    private var lblUseOtpLayout: View? = null
    private var btnConfirmLayout: FrameLayout? = null
    private var btnConfirmProgressFill: View? = null
    private var ivFingerPrintBtn: ImageView? = null
    private var backPressedCallback: OnBackPressedCallback? = null
    private var pendingProgress: Float? = null
    private var progressAnimator: ObjectAnimator? = null
    private var lastTargetFillWidth: Int = -1
    private var pendingOtpReason: String? = null
    private var tvOTPRedirect: TextView? = null
    private var lblTapToPause: TextView? = null
    private var btnConfirmLabel: TextView? = null
    private var pbProcessing: ProgressBar? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(
        R.layout.payu_fp_authentication_or_biometric_selection_custom_layout,
        container,
        false
    ).apply {
        isClickable = true
        isFocusable = true
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        applySystemBarInsets(view)
        (requireActivity() as? AppCompatActivity)?.let { viewModel.attachHost(it) }
        bindViews(view)
        observeViewModel()
        createConfirmationDialogs()
        handleBackPress()
        view.findViewById<View>(R.id.v_gradient_background)?.background =
            fingerprintResultSuccessScreenBackground()
        activity?.let {
            PayUFPTransactionUiHelper.logTransactionAuthUiShown(
                it,
                PayUFPLoggingConstants.PAYU_FP_YES
            )
        }
    }

    private fun applySystemBarInsets(root: View) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, windowInsets ->
            val types = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            val bars = windowInsets.getInsets(types)
            v.updatePadding(bars.left, bars.top, bars.right, bars.bottom)
            windowInsets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun bindViews(view: View) {
        val context = requireContext()
        lblUseOtpLayout = view.findViewById(R.id.lbl_use_otp_layout)
        val lblUseOtp: TextView = view.findViewById(R.id.lbl_use_otp)
        val lblUseOtpDesc: TextView = view.findViewById(R.id.lbl_use_otp_desc)
        val rlHeader: View = view.findViewById(R.id.rl_header)
        val rlFingerprint: View = view.findViewById(R.id.rl_fingerprint)
        val ivFingerprint: ImageView = view.findViewById(R.id.ivFingerprint)
        ivFingerPrintBtn = view.findViewById(R.id.ivFingerPrintBtn)
        val ivBankLogo: ImageView = view.findViewById(R.id.ivBankIcon)
        val ivNetworkLogo: ImageView = view.findViewById(R.id.ivNetworkIcon)
        val ivMerchantLogo: ImageView = view.findViewById(R.id.iv_merchant_logo)
        val ivBack: ImageView = view.findViewById(R.id.ivBack)
        btnConfirmLayout = view.findViewById(R.id.btn_use_fingerprint)
        btnConfirmProgressFill = view.findViewById(R.id.btn_confirm_progress_fill)
        btnConfirmLabel = view.findViewById(R.id.btn_confirm_label)
        tvOTPRedirect = view.findViewById(R.id.lbl_OTP_redirecting)
        lblTapToPause = view.findViewById(R.id.lbl_tap_to_pause)
        pbProcessing = view.findViewById(R.id.pb_processing)

        val args = viewModel.uiData.value.args
        val merchantName = args.merchantName.orEmpty()
        val hasMerchantLogo = args.merchantLogo != null && args.merchantLogo != 0

        val groupDefault: Group = view.findViewById(R.id.group_header_default)
        val groupWithLogo: Group = view.findViewById(R.id.group_header_with_logo)
        groupDefault.visibility = if (hasMerchantLogo) View.GONE else View.VISIBLE
        groupWithLogo.visibility = if (hasMerchantLogo) View.VISIBLE else View.GONE

        val tvPayingTo: TextView = view.findViewById(
            if (hasMerchantLogo) R.id.lbl_paying_with_logo else R.id.lbl_paying_to
        )
        val tvMerchantName: TextView = view.findViewById(
            if (hasMerchantLogo) R.id.tv_merchant_name_with_logo else R.id.tv_merchant_name
        )
        val tvTxnAmount: TextView = view.findViewById(
            if (hasMerchantLogo) R.id.tv_amount_with_logo else R.id.tv_amount
        )
        tvMerchantName.text = when {
            merchantName.isEmpty() -> ""
            hasMerchantLogo -> "$merchantName:"
            else -> merchantName
        }
        val currencySymbol = args.currency?.value ?: PayUFPCurrency.INR.value
        tvTxnAmount.text = "$currencySymbol${args.txnAmount.orEmpty()}"

        val themeLightColor = PayUFPUIUtils.generateTransparentColor(context, R.color.payu_fp_color_25272C, 0.1)
//        rlHeader.setBackgroundColor(themeLightColor)
        rlFingerprint.backgroundTintList = ColorStateList.valueOf(themeLightColor)
        ivBankLogo.loadImageUrl(args.logoUrl, viewLifecycleOwner.lifecycleScope)
        ivNetworkLogo.loadImageUrl(args.networkUrl, viewLifecycleOwner.lifecycleScope)
        applyMerchantLogo(ivMerchantLogo, args.merchantLogo)
        applyFingerprintRingStroke(ivFingerprint)

        ivBack.setOnClickListener {
            if (biometricFlowInProgress) return@setOnClickListener
            stopConfirmButtonAnimation()
            showOtpConfirmation(PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_PRESSED_BACK)
        }
        lblUseOtp.setOnClickListener {
            if (!PayUFPUIUtils.isSafeOnClickListener(PayUFPUiConstants.AUTH_SAFE_CLICK_INTERVAL_MS)) return@setOnClickListener
            viewModel.onUseOtp(PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CHOSE_OTP,
                PayUFPUiConstants.REASON_CODE_C01)
            PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                requireActivity(),
                PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
                PayUFPLoggingConstants.PAYU_FP_GET_OTP_TAPPED,
                PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_OTP
            )
        }
        val biometricClickListener = View.OnClickListener {
            if (biometricFlowInProgress) {
                return@OnClickListener
            }
            if (!PayUFPUIUtils.isSafeOnClickListener(PayUFPUiConstants.AUTH_SAFE_CLICK_INTERVAL_MS)) return@OnClickListener
            if (ensureInternet()) {
                PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                    requireActivity(),
                    PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
                    PayUFPLoggingConstants.PAYU_FP_PAY_TAPPED,
                    PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_BIOMETRIC
                )
                proceedToTransaction(PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CONFIRMED)
            }
        }
        btnConfirmLayout?.setOnClickListener(biometricClickListener)
            ?: rlFingerprint.setOnClickListener(biometricClickListener)

        // ACTION_DOWN fires before onClick and before any biometricFlowInProgress guard,
        // so we handle animation-running taps here to guarantee they are never dropped.
        btnConfirmLayout?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN && progressAnimator?.isRunning == true) {
                PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                    requireActivity(),
                    PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
                    PayUFPLoggingConstants.PAYU_FP_TAP_TO_PAUSE,
                    PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_NULL
                )
                stopConfirmButtonAnimation()
                true
            } else {
                false
            }
        }

        btnConfirmLayout?.viewTreeObserver?.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    btnConfirmLayout?.viewTreeObserver?.removeOnGlobalLayoutListener(this)
                    pendingProgress?.let { updateConfirmButtonProgress(it) }
                }
            }
        )
        if (!viewModel.uiData.value.isConfirmButtonAnimationEnabled) {
            applyNormalConfirmButton()
        }

        PayUFPUIUtils.applyAuthUiCustomisation(
            context = context,
            uiCustomisation = PayUFPDataManager.themeModel?.uiCustomization,
            rlHeader = rlHeader,
            ivFingerprint = ivFingerprint,
            ivFingerPrintBtn = ivFingerPrintBtn,
            tvMerchantName = tvMerchantName,
            tvTxnAmount = tvTxnAmount,
            tvPayingTo = tvPayingTo,
            lblUseOtp = lblUseOtp,
            lblUseOtpDesc = lblUseOtpDesc,
            tvOTPRedirect = tvOTPRedirect,
            btnConfirmLabel = btnConfirmLabel,
            lblTapToPause = lblTapToPause,
            btnConfirmLayout = btnConfirmLayout,
            btnConfirmProgressFill = btnConfirmProgressFill,
            ivBack = ivBack,
        )
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            launch {
                viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                    observeOtpVisibility()
                }
            }
            launch {
                viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                    observeTimerLabels()
                }
            }
            launch {
                viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                    observeButtonAnimation()
                }
            }
            launch {
                viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                    observeInternetMessage()
                }
            }
            launch {
                viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                    observeProcessingState()
                }
            }
        }
    }

    private suspend fun observeOtpVisibility() {
        viewModel.uiData
            .map { it.showOtpOption }
            .distinctUntilChanged()
            .collect { show ->
                lblUseOtpLayout?.visibility = if (show) View.VISIBLE else View.INVISIBLE
            }
    }

    private suspend fun observeButtonAnimation() {
        viewModel.uiData
            .map { it.confirmButtonProgress to it.isConfirmButtonAnimationEnabled }
            .distinctUntilChanged()
            .collect { (progress, _) ->
                updateConfirmButtonProgress(progress)
            }
    }

    private suspend fun observeTimerLabels() {
        viewModel.uiData
            .map { it.visibleTimer to it.visibleTimerSeconds }
            .distinctUntilChanged()
            .collect { (timer, seconds) ->
                updateRedirectTimerLabels(timer, seconds)
            }
    }

    private suspend fun observeInternetMessage() {
        viewModel.uiData
            .map { it.noInternetMessageVisible }
            .distinctUntilChanged()
            .collect { visible ->
                if (visible) {
                    Toast.makeText(requireContext(), R.string.payu_fp_no_internet_connection, Toast.LENGTH_SHORT).show()
                    viewModel.onInternetMessageShown()
                }
            }
    }

    private fun updateRedirectTimerLabels(
        visibleTimer: PayUFPAuthViewModel.VisibleTimer,
        seconds: Double?
    ) {
        when (visibleTimer) {
            PayUFPAuthViewModel.VisibleTimer.BIOMETRIC -> {
                seconds ?: return
                tvOTPRedirect?.visibility = View.INVISIBLE
                lblUseOtpLayout?.visibility = View.INVISIBLE
            }
            PayUFPAuthViewModel.VisibleTimer.TRANSACTION -> {
                seconds ?: return
                tvOTPRedirect?.visibility = View.VISIBLE
                tvOTPRedirect?.text = getString(R.string.payu_fp_otp_redirecting, seconds.toInt().toString())
                lblUseOtpLayout?.visibility = View.VISIBLE
            }
            PayUFPAuthViewModel.VisibleTimer.NONE -> {
                tvOTPRedirect?.visibility = View.INVISIBLE
                lblUseOtpLayout?.visibility = View.INVISIBLE
            }
        }
    }
    
    private suspend fun observeProcessingState() {
        viewModel.uiData
            .map { it.processing }
            .distinctUntilChanged()
            .collect { processing ->
                if (processing) {
                    beginProcessingState()
                }
            }
    }

    internal fun dismissAuthUi() = dismissSelf(null)

    private fun dismissSelf(dismissReason: String? = null) {
        try {
            viewModel.cancelTimers()
            backPressedCallback?.isEnabled = false
            biometricFlowInProgress = false
            if (isAdded) {
                val fragmentManager = parentFragmentManager
                if (!fragmentManager.isStateSaved &&
                    viewLifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
                ) {
                    dismissReason?.let { logAuthEvent(PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_UI_DISMISSED, it) }
                    fragmentManager.beginTransaction().remove(this).commit()
                } else {
                    activity?.let { host ->
                        PayUFPLoggingUtils.logMessage(
                            host,
                            analyticsJson = JSONObject().apply {
                                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_TXN_UNEXPECTED_ERROR)
                                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MESSAGE to
                                        "Skipped auth UI removal; fragment manager state saved or lifecycle below STARTED",
                                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_REASON to dismissReason,
                                ))
                            }
                        )
                    }
                }
            }
        } catch (e: Exception) {
            context?.let {
                PayUFPUIUtils.logExceptionToAnalytics(
                    it, PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG, "Failed to dismiss PayUAuthFragment", e
                )
            }
        }
    }

    private fun updateConfirmButtonProgress(progress: Float) {
        val container = btnConfirmLayout ?: return
        val fill = btnConfirmProgressFill ?: return
        if (biometricFlowInProgress) return
        if (!viewModel.uiData.value.isConfirmButtonAnimationEnabled) {
            applyNormalConfirmButton()
            return
        }
        ivFingerPrintBtn?.visibility = View.GONE
        if (container.width <= 0) {
            pendingProgress = progress
            return
        }
        pendingProgress = null

        if (progressAnimator?.isRunning == true) return

        val containerWidth = container.width
        val latestProgress = viewModel.uiData.value.autoRedirectProgress.coerceIn(0f, 1f)
        val totalMs = ((viewModel.uiData.value.args.biometricTimeout ?: 0.0) * 1000.0).toLong()
        val remainingMs = (totalMs * (1f - latestProgress)).toLong().coerceAtLeast(0L)
        if (remainingMs <= 0L) {
            setFillWidth(fill, containerWidth)
            lastTargetFillWidth = containerWidth
            return
        }
        val fromWidth = (containerWidth * latestProgress).toInt()
        setFillWidth(fill, fromWidth)
        lastTargetFillWidth = containerWidth
        animateFillWidth(fill, containerWidth, containerWidth, remainingMs, onCompleted = ::onFillReachedFull)
    }

    private fun onFillReachedFull() {
        if (!isAdded) return
        proceedToTransaction(PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED)
    }

    private fun proceedToTransaction(reason: String) {
        beginProcessingState()
        val host = btnConfirmLayout ?: btnConfirmProgressFill
        if (host != null) {
            host.post {
                if (isAdded) viewModel.onConfirm(reason)
            }
        } else {
            viewModel.onConfirm(reason)
        }
    }

    private fun beginProcessingState() {
        if (processingStateApplied) return
        processingStateApplied = true
        biometricFlowInProgress = true
        applyProcessingState()
    }

    private fun applyNormalConfirmButton() {
        val container = btnConfirmLayout ?: return
        val fill = btnConfirmProgressFill ?: return
        progressAnimator?.cancel()
        pendingProgress = null
        lblTapToPause?.visibility = View.GONE
        ivFingerPrintBtn?.visibility = View.VISIBLE
        if (container.width <= 0) {
            pendingProgress = 1f
            return
        }
        setFillWidth(fill, container.width)
        lastTargetFillWidth = container.width
    }

    private fun applyProcessingState() {
        val container = btnConfirmLayout ?: return
        val fill = btnConfirmProgressFill ?: return
        progressAnimator?.cancel()
        pendingProgress = null
        setFillWidth(fill, 0)
        lastTargetFillWidth = 0
        val processingColor = ContextCompat.getColor(requireContext(), R.color.payu_fp_color_E0E1E2)
        (container.background as? GradientDrawable)?.mutate()?.also {
            (it as GradientDrawable).setColor(processingColor)
        } ?: container.setBackgroundResource(R.drawable.payu_fp_processing_btn_bg)
        lblTapToPause?.visibility = View.GONE
        ivFingerPrintBtn?.visibility = View.GONE
        pbProcessing?.visibility = View.VISIBLE
        btnConfirmLabel?.apply {
            text = getString(R.string.payu_fp_processing)
            setTextColor(ContextCompat.getColor(requireContext(), R.color.payu_fp_color_717D7B))
        }
        container.isClickable = false
        container.isEnabled = false
        tvOTPRedirect?.visibility = View.INVISIBLE
        lblUseOtpLayout?.visibility = View.INVISIBLE
    }

    private fun setFillWidth(fill: View, width: Int) {
        (fill.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
            params.width = width
            fill.requestLayout()
        }
    }

    private fun fingerprintResultSuccessScreenBackground(): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                buttonBackgroundColorWithAlpha(0x40),
                buttonBackgroundColorWithAlpha(0x08),
                Color.WHITE
            )
        )

    private fun buttonBackgroundColorWithAlpha(alpha: Int): Int =
        ColorUtils.setAlphaComponent(merchantButtonBaseColor(), alpha)

    private fun merchantButtonBaseColor(): Int {
        val hex = PayUFPDataManager.themeModel
            ?.uiCustomization
            ?.buttonCustomization
            ?.primaryButtonCustomization
            ?.enabledBackgroundColor
        return if (PayUFPUIUtils.isValidColorCode(hex)) Color.parseColor(hex) else DEFAULT_BUTTON_BG
    }

    private fun applyFingerprintRingStroke(target: ImageView) {
        val ring = (target.background as? GradientDrawable)?.mutate() as? GradientDrawable ?: return
        val strokeWidth = resources.getDimensionPixelSize(R.dimen.payu_fp_dimen_2dp)
        ring.setStroke(strokeWidth, merchantButtonBaseColor())
        target.background = ring
    }

    private fun applyMerchantLogo(target: ImageView, @DrawableRes drawableRes: Int?) {
        if (drawableRes == null || drawableRes == 0) {
            target.setImageDrawable(null)
            target.visibility = View.GONE
            return
        }
        try {
            target.setImageResource(drawableRes)
            target.visibility = View.VISIBLE
        } catch (e: Resources.NotFoundException) {
            target.setImageDrawable(null)
            target.visibility = View.GONE
            PayUFPUIUtils.logExceptionToAnalytics(
                target.context,
                PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG,
                "Merchant logo drawable resource not found",
                e,
            )
        }
    }

    private fun animateFillWidth(
        fill: View,
        targetWidth: Int,
        containerWidth: Int,
        durationMs: Long? = null,
        onCompleted: (() -> Unit)? = null,
    ) {
        progressAnimator?.cancel()
        val fromWidth = FILL_WIDTH_PROPERTY.get(fill)
        progressAnimator = ObjectAnimator.ofInt(fill, FILL_WIDTH_PROPERTY, fromWidth, targetWidth).apply {
            duration = durationMs
                ?: if (targetWidth >= containerWidth) FILL_ANIM_FINAL_MS else FILL_ANIM_STEP_MS
            interpolator = FILL_INTERPOLATOR

            if (onCompleted != null) {
                var cancelled = false
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationCancel(animation: Animator) {
                        cancelled = true
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        if (!cancelled) onCompleted.invoke()
                    }
                })
            }
            start()
        }
    }
    
    private fun stopConfirmButtonAnimation() {
        progressAnimator?.cancel()
        progressAnimator = null
        // If the countdown was still active, pause it and expose the Get OTP option immediately.
        if (viewModel.uiData.value.isConfirmButtonAnimationEnabled) {
            viewModel.stopAutoInvoke()
        }
        // Apply the final visual state right away without waiting for the StateFlow emission.
        val container = btnConfirmLayout ?: return
        val fill = btnConfirmProgressFill ?: return
        lblTapToPause?.visibility = View.GONE
        ivFingerPrintBtn?.visibility = View.VISIBLE
        if (container.width > 0) {
            setFillWidth(fill, container.width)
            lastTargetFillWidth = container.width
        }
    }

    private fun ensureInternet(): Boolean {
        val available = PayUFPUIUtils.isInternetAvailable(requireContext())
        if (!available) viewModel.onInternetUnavailable()
        return available
    }

    private fun createConfirmationDialogs() {
        otpConfirmationDialog = PayUFPUIUtils.getAlertDialog(
            activity = context,
            onClickDialog = { dialog, which ->
                when (which) {
                    DialogInterface.BUTTON_POSITIVE -> {
                        if (ensureInternet()) {
                            dialog.dismiss()
                            PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                                requireActivity(),
                                PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_NUDGE_OUTCOME,
                                PayUFPLoggingConstants.PAYU_FP_YES,
                                PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_NULL
                            )
                            viewModel.onCancelTransaction()
                            pendingOtpReason = null
                        }
                    }
                    DialogInterface.BUTTON_NEGATIVE -> {
                        PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                            requireActivity(),
                            PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_NUDGE_OUTCOME,
                            PayUFPLoggingConstants.PAYU_FP_NO,
                            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_NULL
                        )
                        pendingOtpReason = null
                        dialog.dismiss()
                    }
                    DialogInterface.BUTTON_NEUTRAL -> {
                        PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
                            requireActivity(),
                            PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_NUDGE_OUTCOME,
                            PayUFPLoggingConstants.PAYU_FP_OUTCOME_BIOMETRIC_TO_OTP,
                            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_OTP
                        )
                        dialog.dismiss()
                        viewModel.onUseOtp(
                            pendingOtpReason ?: PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CHOSE_OTP, PayUFPUiConstants.REASON_CODE_C04
                        )
                    }
                }
            },
            positiveText = getString(R.string.payu_fp_yes),
            negativeText = getString(R.string.payu_fp_no),
            neutralText = getString(R.string.payu_fp_useOtp),
            title = null,
            message = getString(R.string.payu_fp_do_you_really_want_to_cancel_the_payment)
        ).create()
    }

    private fun handleBackPress() {
        backPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (biometricFlowInProgress) return
                stopConfirmButtonAnimation()
                showOtpConfirmation(PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_PRESSED_BACK)
            }
        }.also { requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, it) }
    }

    private fun showOtpConfirmation(reason: String) {
        pendingOtpReason = reason
        PayUFPTransactionUiHelper.logBioMetricOutComeEvent(
            requireActivity(),
            PayUFPLoggingConstants.PAYU_FP_TXN_BIOMETRIC_SCREEN_OUTCOME,
            PayUFPLoggingConstants.PAYU_FP_BACK_PRESSED,
            PayUFPLoggingConstants.PAYU_FP_TXN_AUTH_TYPE_OTP
        )
        showConfirmationDialog(otpConfirmationDialog, PayUFPConstants.PAYU_FP_MSG_OTP_CONFIRMATION_ERROR)
    }

    private fun showConfirmationDialog(dialog: AlertDialog?, errorMessage: String) {
        try {
            if (isAdded && dialog?.isShowing != true) {
                dialog?.show()
                dialog?.let { applyDialogButtonColor(it) }
            }
        } catch (e: Exception) {
            PayUFPUIUtils.logExceptionToAnalytics(requireContext(), PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG, errorMessage, e)
        }
    }

    private fun applyDialogButtonColor(dialog: AlertDialog) {
        val color = ContextCompat.getColor(requireContext(), R.color.payu_fp_color_25272C)
        listOf(AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL).forEach { which ->
            dialog.getButton(which)?.apply { setTextColor(color); isAllCaps = true; visibility = View.VISIBLE }
        }
    }

    override fun onDestroyView() {
        viewModel.detachHost()
        try { otpConfirmationDialog?.dismiss() } catch (e: Exception) {
            context?.let {
                PayUFPUIUtils.logExceptionToAnalytics(
                    it, PayUFPUiConstants.AUTH_SELECTION_FRAGMENT_TAG, "Failed to dismiss OTP confirmation dialog", e
                )
            }
        }
        otpConfirmationDialog = null
        pendingOtpReason = null
        biometricFlowInProgress = false
        processingStateApplied = false
        tvOTPRedirect = null
        lblUseOtpLayout = null
        lblTapToPause = null
        btnConfirmLabel = null
        btnConfirmLayout = null
        btnConfirmProgressFill = null
        ivFingerPrintBtn = null
        pbProcessing = null
        pendingProgress = null
        progressAnimator?.cancel()
        progressAnimator = null
        lastTargetFillWidth = -1
        backPressedCallback = null
        super.onDestroyView()
    }

    private fun logAuthEvent(eventValue: String, reason: String? = null) {
        activity?.let { PayUFPTransactionUiHelper.logAuthSelectionEvent(it, eventValue, reason) }
    }

    companion object {
        // Uses View.layout() instead of mutating LayoutParams + requestLayout() so that
        // the per-frame width updates do not trigger a full parent layout traversal.
        // requestLayout() is reserved for the final settled width in setFillWidth().
        private val FILL_WIDTH_PROPERTY = object : Property<View, Int>(Int::class.java, "fillWidth") {
            override fun get(view: View): Int = view.width.takeIf { it >= 0 } ?: 0

            override fun set(view: View, value: Int) {
                val safeValue = maxOf(0, value)
                view.layout(view.left, view.top, view.left + safeValue, view.bottom)
            }
        }

        private val FILL_INTERPOLATOR = LinearInterpolator()
        private const val FILL_ANIM_STEP_MS = 1000L
        private const val FILL_ANIM_FINAL_MS = 500L
        private val DEFAULT_BUTTON_BG = Color.parseColor("#FFD814")

        fun newInstance(
            logoUrl: String?, networkUrl: String?, merchantName: String?, txnAmount: String?,
            currency: PayUFPCurrency?, fallbackTimeout: Double?, biometricTimeout: Double?,
            fallbackVisibilityDuration: Double?, themeType: String?, merchantLogo: Int?
        ): PayUFPAuthSelectionFragment = PayUFPAuthSelectionFragment().apply {
            arguments = Bundle().apply {
                putString(PayUFPUiConstants.AUTH_ARG_LOGO_URL, logoUrl)
                putString(PayUFPUiConstants.AUTH_ARG_NETWORK_URL, networkUrl)
                putString(PayUFPUiConstants.AUTH_ARG_MERCHANT_NAME, merchantName)
                putString(PayUFPUiConstants.AUTH_ARG_TXN_AMOUNT, txnAmount)
                currency?.name?.let { putString(PayUFPUiConstants.AUTH_ARG_CURRENCY, it) }
                fallbackTimeout?.let { putDouble(PayUFPUiConstants.AUTH_ARG_FALLBACK_TIMEOUT, it) }
                biometricTimeout?.let { putDouble(PayUFPUiConstants.AUTH_ARG_BIOMETRIC_TIMEOUT, it) }
                fallbackVisibilityDuration?.let { putDouble(PayUFPUiConstants.AUTH_ARG_FALLBACK_VISIBILITY_DURATION, it) }
                putString(PayUFPUiConstants.AUTH_ARG_THEME_TYPE, themeType)
                if (merchantLogo != null) {
                    putInt(PayUFPUiConstants.AUTH_ARG_MERCHANT_LOGO, merchantLogo)
                }
            }
        }
    }
}
