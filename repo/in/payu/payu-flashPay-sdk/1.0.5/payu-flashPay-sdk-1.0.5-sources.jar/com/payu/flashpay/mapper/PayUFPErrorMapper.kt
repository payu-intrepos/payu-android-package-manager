package com.payu.flashpay.mapper

import com.payu.flashpay.constants.PayUFPConstants

internal object PayUFPErrorMapper {

    fun mapIntactCheckError(code: Int, message: String): Pair<Int, String> =
        when (code) {
            PayUFPConstants.PAYU_FP_CODE_CUSTOMER_NOT_REGISTERED ->
                PayUFPConstants.PAYU_FP_CODE_CUSTOMER_NOT_REGISTERED to
                        PayUFPConstants.PAYU_FP_MSG_CUSTOMER_NOT_REGISTERED

            else -> {
                code to message
            }
        }

    fun mapRegistrationError(code: Int, message: String): Pair<Int, String> =
        when (code) {
            PayUFPConstants.PAYU_FP_CODE_TRIDENTITY_USER_CANCELLED ->
                PayUFPConstants.PAYU_FP_CODE_TRIDENTITY_USER_CANCELLED to
                        PayUFPConstants.PAYU_FP_MSG_REG_CANCELLED_BY_USER

            PayUFPConstants.PAYU_FP_CODE_TXN_BIOMETRIC_TIMEOUT ->
                PayUFPConstants.PAYU_FP_CODE_TXN_BIOMETRIC_TIMEOUT to (
                        message.takeIf { it.isNotBlank() }
                            ?: PayUFPConstants.PAYU_FP_MSG_BIOMETRIC_TIMEOUT
                        )

            else -> code to message
        }

    fun mapConfigureError(code: Int, message: String): Pair<Int, String> {
        val trimmedMessage = message.trim()
        return when {
            code == 0 || isUnhandledConfigureException(trimmedMessage) ->
                PayUFPConstants.PAYU_FP_CODE_SDK_EXCEPTION to
                    PayUFPConstants.PAYU_FP_MSG_UNHANDLED_ERROR

            trimmedMessage.isBlank() ->
                code to PayUFPConstants.PAYU_FP_MSG_UNHANDLED_ERROR

            else -> code to message
        }
    }

    private fun isUnhandledConfigureException(message: String): Boolean =
        message.equals("Unhandeled Exception", ignoreCase = true) ||
            message.equals("Unhandled Exception", ignoreCase = true)

}
