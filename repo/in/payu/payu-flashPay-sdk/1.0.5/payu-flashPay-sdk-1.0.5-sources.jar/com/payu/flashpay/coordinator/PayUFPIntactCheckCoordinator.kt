package com.payu.flashpay.coordinator

import android.content.Context
import com.payu.flashpay.callbacks.PayUFPCheckIntactStatusCallback
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.mapper.PayUFPRequestMapper
import com.payu.flashpay.tridentity.PayUFPTridentityWrapper
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.validator.PayUFPInputValidator
import org.json.JSONObject

internal object PayUFPIntactCheckCoordinator {

    fun checkIntactStatus(
        context: Context,
        tdyCardId: String?,
        bankId: String?,
        isLocalCheck: Boolean,
        isDeregisterCall: Boolean = false,
        callback: PayUFPCheckIntactStatusCallback
    ) {
        val startTime = System.currentTimeMillis()
        PayUFPLoggingUtils.logMessage(
            context,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_INTACT_CHECK)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_INIT_PARAMS)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TDY_CARD_ID to tdyCardId,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_IS_LOCAL_CHECK to isLocalCheck,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_BANK_ID to bankId
                ))
            }
        )

        PayUFPInputValidator.validateCheckRegistrationParams(bankId, tdyCardId)?.let { error ->
            val responseFlowContext = PayUFPValidationFailureContext.INTACT_CHECK
            deliverErrorResponse(
                activity = context,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = error.code,
                errorMessage = error.message,
                deliver = callback::onIntactResponse,
            )
            return
        }

        val checkIntactParam = PayUFPRequestMapper.mapToIntactCheckParams(
            uidOverride = tdyCardId,
            bankIdOverride = bankId,
        )
        PayUFPTridentityWrapper.checkRegistrationStatus(
            context = context,
            params = checkIntactParam,
            isLocalCheck = isLocalCheck,
            isDeregisterCall = isDeregisterCall,
            startTime = startTime,
            callback = callback
        )
    }
}
