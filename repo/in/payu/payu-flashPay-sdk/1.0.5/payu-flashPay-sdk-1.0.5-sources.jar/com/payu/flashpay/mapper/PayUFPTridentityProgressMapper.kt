package com.payu.flashpay.mapper

import com.payu.flashpay.constants.PayUFPLoggingConstants
import org.json.JSONObject

/**
 * Maps Tridentity registration / transaction progress payloads to standardized analytics event_value strings.
 */
internal object PayUFPTridentityProgressMapper {

    private val registrationProgressMappings = listOf(
        "parameter_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_PARAMETER_VALIDATION_PASSED,
        "param_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_PARAMETER_VALIDATION_PASSED,
        "sim_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_SIM_VALIDATION_PASSED,
        "security_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_SECURITY_VALIDATION_PASSED,
        "sms_token_fetched" to PayUFPLoggingConstants.PAYU_FP_EVENT_SMS_TOKEN_FETCHED,
        "sms_sent" to PayUFPLoggingConstants.PAYU_FP_EVENT_SMS_SENT_SUCCESS,
        "sim_binding" to PayUFPLoggingConstants.PAYU_FP_EVENT_SIM_BINDING_SUCCESS,
        "biometric_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_BIOMETRIC_VALIDATION_PASSED,
    )

    private val transactionProgressMappings = listOf(
        "parameter_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_PARAMETER_VALIDATION_PASSED,
        "param_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_PARAMETER_VALIDATION_PASSED,
        "biometric_auth" to PayUFPLoggingConstants.PAYU_FP_EVENT_BIOMETRIC_AUTH_SELECTED,
        "security_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_SECURITY_VALIDATION_PASSED,
        "user_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_USER_VALIDATION_PASSED,
        "biometric_validation" to PayUFPLoggingConstants.PAYU_FP_EVENT_BIOMETRIC_VALIDATION_PASSED
    )

    fun mapRegistrationProgress(progressJson: String): String? =
        mapProgress(progressJson, registrationProgressMappings)

    fun mapTransactionProgress(progressJson: String): String? =
        mapProgress(progressJson, transactionProgressMappings)

    private fun mapProgress(
        progressJson: String,
        mappings: List<Pair<String, String>>,
    ): String? {
        val normalized = extractProgressToken(progressJson) ?: return null
        return mappings.firstOrNull { (token, _) ->
            normalized.contains(token, ignoreCase = true)
        }?.second
    }

    private fun extractProgressToken(progressJson: String): String? {
        val trimmed = progressJson.trim()
        if (trimmed.isEmpty()) return null
        return runCatching {
            val json = JSONObject(trimmed)
            sequenceOf("event", "status", "step", "state", "message", "name")
                .mapNotNull { key -> json.optString(key).takeIf { it.isNotBlank() } }
                .firstOrNull()
        }.getOrNull() ?: trimmed
    }
}
