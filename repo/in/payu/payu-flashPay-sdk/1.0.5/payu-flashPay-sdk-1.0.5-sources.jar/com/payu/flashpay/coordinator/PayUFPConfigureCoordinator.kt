package com.payu.flashpay.coordinator

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPConfigSDKCallback
import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.mapper.PayUFPRequestMapper
import com.payu.flashpay.model.PayUFPThemeModel
import com.payu.flashpay.model.PayUFPMfaParams
import com.payu.flashpay.model.PayUFPMfaParamsBuildResult
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.tridentity.PayUFPTridentityWrapper
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.validator.PayUFPInputValidator
import org.json.JSONObject

internal object PayUFPConfigureCoordinator {

    fun configureSDK(
        context: Context,
        payUFPConfig: PayUFPConfig,
        themeModel: PayUFPThemeModel?,
        mfaParams: JSONObject,
        callback: PayUFPConfigSDKCallback,
    ) {
        val startTime = System.currentTimeMillis()
        prepareConfigureSession(context, payUFPConfig, mfaParams)
        PayUFPInputValidator.validateInitSDKParam(payUFPConfig)?.let { error ->
            val responseFlowContext = PayUFPValidationFailureContext.CONFIG
            deliverErrorResponse(
                activity = context as? AppCompatActivity,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = error.code,
                errorMessage = error.message,
                deliver = callback::onConfigureResponse,
            )
        }
        if (!validateConfigureSdkInputs(context, payUFPConfig, mfaParams, callback)) return
        val payUFPMfaParams =
            buildValidatedMfaParamsForConfigure(context, payUFPConfig, mfaParams, callback)
                ?: return

        val configParams = PayUFPRequestMapper.mapToConfigParams(
            payUFPMfaParams, themeModel, payUFPConfig
        )

        PayUFPDataManager.saveData(payUFPConfig, payUFPMfaParams, themeModel)

        PayUFPTridentityWrapper.startTridentityFlow(
            context = context,
            configParams = configParams,
            startTime = startTime,
            callback = callback
        )
    }

    private fun prepareConfigureSession(
        context: Context,
        payUFPConfig: PayUFPConfig,
        mfaParams: JSONObject,
    ) {
        PayUFPDataManager.clearData()
        PayUFPDataManager.setTxnId(payUFPConfig.txnId)
        PayUFPDataManager.setAcsTxnId(payUFPConfig.acsTxnId)
        PayUFPDataManager.setMerchantKey(payUFPConfig.merchantKey)
        PayUFPSdkInitializationCoordinator.initializeSDK(context)
        PayUFPConfigureCoordinatorLogging.initiated(context, payUFPConfig, mfaParams)
    }

    private fun validateConfigureSdkInputs(
        context: Context,
        payUFPConfig: PayUFPConfig,
        mfaParams: JSONObject,
        callback: PayUFPConfigSDKCallback,
    ): Boolean {
        PayUFPInputValidator.validateConfigureSDKParam(payUFPConfig, mfaParams)?.let { error ->
            val responseFlowContext = PayUFPValidationFailureContext.CONFIG
            deliverErrorResponse(
                activity = context as? AppCompatActivity,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = error.code,
                errorMessage = error.message,
                deliver = callback::onConfigureResponse,
            )
            return false
        }
        return true
    }

    private fun buildValidatedMfaParamsForConfigure(
        context: Context,
        payUFPConfig: PayUFPConfig,
        mfaParams: JSONObject,
        callback: PayUFPConfigSDKCallback,
    ): PayUFPMfaParams? {
        return when (val result =
            PayUFPMfaParams.buildMfaParams(context, payUFPConfig, mfaParams)) {
            is PayUFPMfaParamsBuildResult.MfaPayloadResolveFailed -> {
                val responseFlowContext = PayUFPValidationFailureContext.CONFIG
                deliverErrorResponse(
                    activity = context as? AppCompatActivity,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = PayUFPConstants.PAYU_FP_CODE_INVALID_PARAMS,
                    errorMessage = PayUFPConstants.PAYU_FP_MSG_MFA_PAYLOAD_RESOLVE_FAILED,
                    deliver = callback::onConfigureResponse
                )
                null
            }
            is PayUFPMfaParamsBuildResult.Success -> {
                val params = result.params
                val parseError = PayUFPInputValidator.validateMfaParamsParsed(params)
                if (parseError != null) {
                    val responseFlowContext = PayUFPValidationFailureContext.CONFIG
                    deliverErrorResponse(
                        activity = context as? AppCompatActivity,
                        responseFlow = responseFlowContext.responseFlow,
                        logCategory = responseFlowContext.logCategory,
                        errorCode = parseError.code,
                        errorMessage = parseError.message,
                        deliver = callback::onConfigureResponse,
                    )
                    null
                } else {
                    params
                }
            }
        }
    }
}

/**
 * Analytics for the configure-SDK coordinator path only (keeps [PayUFPConfigureCoordinator] focused on flow).
 */
internal object PayUFPConfigureCoordinatorLogging {

    fun initiated(context: Context, payUFPConfig: PayUFPConfig, mfaParams: JSONObject) {
        PayUFPLoggingUtils.logMessage(
            context,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_CONFIG)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_INIT_PARAMS)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MERCHANT_NAME to payUFPConfig.merchantName,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_AMOUNT to payUFPConfig.amount,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TXN_ID to payUFPConfig.txnId,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MFA_PARAMS to mfaParams,
                ))
            }
        )
    }

    fun logMfaParamsParsed(context: Context) {
        PayUFPLoggingUtils.logMessage(
            context,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_CONFIG)
                put(
                    PayUFPLoggingConstants.EVENT_VALUE,
                    PayUFPLoggingConstants.PAYU_FP_CONFIG_MFA_PARSED
                )
            }
        )
    }
}
