package com.payu.flashpay.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

internal object FetchImageFromURLTask {

    private const val TAG = "FetchImageFromURLTask"

    suspend fun fetch(url: String): Bitmap? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply { connect() }
            BitmapFactory.decodeStream(connection.inputStream)
        } catch (e: Exception) {
            Log.e(TAG, "Exception while fetching image: ${e.message}")
            null
        } finally {
            connection?.disconnect()
        }
    }
}
