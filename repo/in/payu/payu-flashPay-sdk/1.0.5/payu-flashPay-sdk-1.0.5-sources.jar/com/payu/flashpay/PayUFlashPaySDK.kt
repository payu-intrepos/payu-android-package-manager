package com.payu.flashpay

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPCheckIntactStatusCallback
import com.payu.flashpay.callbacks.PayUFPConfigSDKCallback
import com.payu.flashpay.callbacks.PayUFPDeregisterCallback
import com.payu.flashpay.callbacks.PayUFPProcessTxnCallback
import com.payu.flashpay.callbacks.PayUFPRegistrationStatusCallback
import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.coordinator.PayUFPConfigureCoordinator
import com.payu.flashpay.coordinator.PayUFPDeRegistrationCoordinator
import com.payu.flashpay.coordinator.PayUFPIntactCheckCoordinator
import com.payu.flashpay.coordinator.PayUFPRegistrationCoordinator
import com.payu.flashpay.coordinator.PayUFPSdkInitializationCoordinator
import com.payu.flashpay.coordinator.PayUFPTransactionCoordinator
import com.payu.flashpay.model.PayUFPThemeModel
import com.payu.flashpay.storage.PayUFPDataManager
import org.json.JSONObject

object PayUFlashPaySDK {

    @JvmStatic
    fun initializeSDK(context: Context) {
        PayUFPSdkInitializationCoordinator.initializeSDK(context)
    }

    @JvmStatic
    fun configureSDK(
        context: Context,
        payUFPConfig: PayUFPConfig,
        themeModel: PayUFPThemeModel? = null,
        mfaParams: JSONObject,
        configSDKCallback: PayUFPConfigSDKCallback
    ) = PayUFPConfigureCoordinator.configureSDK(
        context,
        payUFPConfig,
        themeModel,
        mfaParams,
        configSDKCallback
    )

    @JvmStatic
    fun checkIntactStatus(
        context: Context,
        tdyCardId: String?,
        bankId: String?,
        isLocalCheck: Boolean = true,
        isDeregisterCall: Boolean = false,
        checkIntactStatusCallback: PayUFPCheckIntactStatusCallback
    ) = PayUFPIntactCheckCoordinator.checkIntactStatus(
        context,
        tdyCardId,
        bankId,
        isLocalCheck,
        isDeregisterCall,
        checkIntactStatusCallback
    )

    @JvmStatic
    fun initiateRegistration(
        activity: AppCompatActivity,
        maskedMobileNumber: String?,
        registrationStatusCallBack: PayUFPRegistrationStatusCallback
    ) = PayUFPRegistrationCoordinator.initiateRegistration(activity, maskedMobileNumber, registrationStatusCallBack)

    @JvmStatic
    fun processTransaction(
        context: AppCompatActivity,
        txnCallback: PayUFPProcessTxnCallback
    ) = PayUFPTransactionCoordinator.processTransaction(context, txnCallback)

    @JvmStatic
    fun deRegisterCard(
        activity: AppCompatActivity,
        deregisterCallBack: PayUFPDeregisterCallback
    ) = PayUFPDeRegistrationCoordinator.deRegister(activity, deregisterCallBack)

    @JvmStatic
    fun clearData() = PayUFPDataManager.clearData()

}
