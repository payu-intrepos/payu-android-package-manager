package com.payu.flashpay.constants

internal object PayUFPUiConstants {

    const val AUTH_SELECTION_FRAGMENT_TAG = "PayUAuthFragment"
    const val DEREGISTRATION_BOTTOM_SHEET_TAG = "DeRegistrationBottomSheet"
    const val AUTH_ARG_LOGO_URL = "logoUrl"
    const val AUTH_DERIVE = "AES/"
    const val AUTH_ARG_NETWORK_URL = "networkUrl"
    const val AUTH_ARG_MERCHANT_NAME = "merchantName"
    const val AUTH_ARG_TXN_AMOUNT = "txnAmount"
    const val AUTH_ARG_CURRENCY = "currency"
    const val AUTH_ARG_FALLBACK_TIMEOUT = "fallbackTimeout"
    const val AUTH_ARG_BIOMETRIC_TIMEOUT = "autoInvokeBiometricTime"
    const val AUTH_ARG_FALLBACK_VISIBILITY_DURATION = "fallbackVisibilityDuration"
    const val AUTH_ARG_THEME_TYPE = "themeType"
    const val AUTH_ARG_MERCHANT_LOGO = "merchantLogo"
    const val AUTH_SAFE_CLICK_INTERVAL_MS = 1000L
    const val MILLIS_PER_SECOND = 1000L
    const val MILLIS_PER_SECOND_DOUBLE = 1000.0
    const val BIOMETRIC_DIRECT_INVOKE_THRESHOLD_SECONDS = 1.0
    internal val CLIENT_IDENTIFIER: ByteArray = intArrayOf(
            225, 168, 117, 11, 239, 250, 149, 133,
            29, 181, 184, 130, 121, 109, 100, 158,
            255, 1, 249, 123, 210, 61, 68, 8,
            77, 164, 141, 151, 113, 182, 168,
        ).map { it.toByte() }.toByteArray()
    const val REASON_CODE_E01 = "E01"
    const val REASON_CODE_C01 = "C01"
    const val REASON_CODE_C04 = "C04"
}
