package com.payu.flashpay.mapper

import com.payu.flashpay.BuildConfig
import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.model.PayUFPMfaParams
import com.payu.flashpay.model.PayUFPThemeModel
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPUIUtils.normalizeId
import org.json.JSONObject

internal object PayUFPRequestMapper {

    fun mapToConfigParams(
        mfaParams: PayUFPMfaParams,
        themeModel: PayUFPThemeModel?,
        payUFPConfig: PayUFPConfig,
    ): JSONObject {
        val env = (if (payUFPConfig.isProduction) {
            PayUFPConstants.PAYU_FP_ENV_PROD
        } else {
            PayUFPConstants.PAYU_FP_ENV_UAT
        }).uppercase()

        val configParams = JSONObject().apply {
            put(PayUFPConstants.PAYU_FP_KEY_ENV, env)
            put(PayUFPConstants.PAYU_FP_KEY_CLIENT_ID, mfaParams.tdyClientId)
            put(PayUFPConstants.PAYU_FP_KEY_TDY_URL, mfaParams.tdyUrl)
            put(PayUFPConstants.PAYU_FP_KEY_AUTH_TYPE, PayUFPConstants.PAYU_FP_KEY_AUTH_TYPE_VALUE)
            if (mfaParams.binValue.isNullOrBlank().not())
                put(PayUFPConstants.PAYU_FP_KEY_BIN_ID, mfaParams.binValue)
            put(PayUFPConstants.PAYU_FP_KEY_BANK_LOGO, mfaParams.bankLogo)
            put(PayUFPConstants.PAYU_FP_KEY_REGISTRATION_TIMEOUT, mfaParams.registrationTimeout)
            put(PayUFPConstants.PAYU_FP_KEY_TRANSACTION_TIMEOUT, mfaParams.transactionTimeout)
            put(PayUFPConstants.PAYU_FP_KEY_BANK_ID, mfaParams.bankId)
            put(PayUFPConstants.PAYU_FP_KEY_CUSTOMER_ID, mfaParams.customerId)
            put(PayUFPConstants.PAYU_FP_KEY_UID, mfaParams.uid)
            put(PayUFPConstants.PAYU_FP_KEY_TXN_ID, payUFPConfig.txnId)
            put(PayUFPConstants.PAYU_FP_KEY_ACS_TXN_ID, payUFPConfig.acsTxnId)
            put(PayUFPConstants.PAYU_FP_KEY_TDY_API_KEY_FIELD, mfaParams.tdyApiKey)
            mfaParams.messageType?.takeIf { it.isNotBlank() }?.let {
                put(PayUFPConstants.PAYU_FP_KEY_MFA_MESSAGE_TYPE, it)
            }
            if (!mfaParams.bindingType.isNullOrEmpty()) {
                put(PayUFPConstants.PAYU_FP_KEY_BINDING_TYPE, mfaParams.bindingType)
            }

            put(
                PayUFPConstants.PAYU_FP_KEY_THEME_CONFIG,
                PayUFPThemeMapper.mapToTridentityTheme(themeModel)
            )
            put(PayUFPConstants.PAYU_FP_KEY_MERCHANT_NAME_FIELD, payUFPConfig.merchantName)
            put(PayUFPConstants.PAYU_FP_KEY_TXN_AMOUNT_FIELD, mfaParams.txnAmount)
            put(PayUFPConstants.PAYU_FP_MERCHANT_TXN_ID, mfaParams.merchantTxnId)
            put(PayUFPConstants.PAYU_FP_KEY_MERCHANT_ID_FIELD, mfaParams.merchantId)
            put(
                PayUFPConstants.PAYU_FP_KEY_MERCHANT_KEY_FIELD,
                mfaParams.merchantKey
            )
            put(
                PayUFPConstants.PAYU_FP_KEY_CARD_NETWORK_LOGO,
                mfaParams.cardNetworkLogo
            )
            put(
                PayUFPConstants.PAYU_FP_MOBILE_NO,
                mfaParams.merchantMobileNo
            )
            put(PayUFPConstants.SDK_PLATFORM_KEY, getSDKPlateFormData())
            put(PayUFPConstants.SDK_VERSION, BuildConfig.VERSION_NAME)
            put(PayUFPConstants.IS_CO_BRANDED, false)
            if (payUFPConfig.merchantLogo != null){
                put(PayUFPConstants.MERCHANT_LOGO, payUFPConfig.merchantLogo)
            }
            if (mfaParams.tempCardId != null ) {
                put(PayUFPConstants.CARD_TYPE, PayUFPConstants.TEMP_CARD_ID)
            } else {
                put(PayUFPConstants.CARD_TYPE, PayUFPConstants.TDY_CARD_ID)
            }

        }
        return configParams
    }

    fun mapToIntactCheckParams(
        uidOverride: String? = null,
        bankIdOverride: String? = null,
    ): JSONObject {
        val params = JSONObject().apply {
            val mfaParams = PayUFPDataManager.mfaParams
            val uid = uidOverride.normalizeId() ?: mfaParams?.uid
            val bankId = bankIdOverride.normalizeId() ?: mfaParams?.bankId
            put(PayUFPConstants.PAYU_FP_KEY_UID, uid)
            put(PayUFPConstants.PAYU_FP_KEY_CLIENT_ID, mfaParams?.tdyClientId)
            put(PayUFPConstants.PAYU_FP_KEY_BANK_ID, bankId)
            put(PayUFPConstants.PAYU_FP_KEY_CUSTOMER_ID, mfaParams?.customerId)
        }
        return params
    }


    fun mapToRegistrationParams(): JSONObject {
        val params = JSONObject().apply {
            put(PayUFPConstants.PAYU_FP_KEY_UID, PayUFPDataManager.mfaParams?.uid)
        }
        return params
    }

    fun mapToTransactionParams(): JSONObject {
        val mfa = PayUFPDataManager.mfaParams
        val params = JSONObject().apply {
            put(PayUFPConstants.PAYU_FP_KEY_UID, mfa?.uid)
            put(PayUFPConstants.PAYU_FP_KEY_CLIENT_ID, mfa?.tdyClientId)
            put(PayUFPConstants.PAYU_FP_KEY_HASH_KEY, mfa?.hashKey)
        }
        return params
    }

    fun createProcessAndUpdateStatus(status: String, reasonCode: String?): JSONObject {
        val mfa = PayUFPDataManager.mfaParams
        val params = JSONObject().apply {
            put(PayUFPConstants.PAYU_FP_KEY_UID, mfa?.uid)
            put(PayUFPConstants.PAYU_FP_KEY_CLIENT_ID, mfa?.tdyClientId)
            put(PayUFPConstants.PAYU_FP_KEY_HASH_KEY, mfa?.hashKey)
            put(PayUFPConstants.PAYU_FP_KEY_REASON_CODE, reasonCode)
            put(PayUFPConstants.PAYU_FP_KEY_STATUS, status)
        }
        return params
    }


    private fun getSDKPlateFormData(): String {
        val platformJson = JSONObject()
        platformJson.put(PayUFPConstants.PLATFORM_KEY, PayUFPConstants.PLATFORM_VALUE)
        platformJson.put(PayUFPConstants.NAME_KEY, PayUFPConstants.NAME_VALUE)
        platformJson.put(PayUFPConstants.VERSION_KEY, BuildConfig.VERSION_NAME)
        return platformJson.toString()
    }
}