package com.payu.flashpay.mapper

import com.payu.flashpay.model.*
import com.wibmo.tridentity.sdk.theme.*

internal object PayUFPThemeMapper {

    fun mapToTridentityTheme(model: PayUFPThemeModel?): ThemeConfig {
        if (model == null) return ThemeConfig()
        return ThemeConfig(
            uiCustomization = model.uiCustomization?.toTridentity() ?: UICustomization()
        )
    }

    private fun PayUFPUICustomization.toTridentity(): UICustomization = UICustomization(
        labelCustomization = labelCustomization?.toTridentity() ?: LabelCustomization(),
        buttonCustomization = buttonCustomization?.toTridentity() ?: ButtonCustomization(),
        toolbarCustomization = toolbarCustomization?.toTridentity() ?: ToolbarCustomization(),
    )

    private fun PayUFPLabelCustomization.toTridentity(): LabelCustomization = LabelCustomization(
        headingCustomization = headingCustomization?.toTridentity() ?: HeadingContentCustomization(),
        subHeadingCustomization = subHeadingCustomization?.toTridentity() ?: SubHeadingCustomization(),
    )

    private fun PayUFPHeadingContentCustomization.toTridentity(): HeadingContentCustomization =
        HeadingContentCustomization(
            textColor = textColor,
            fontSize = fontSize,
            fontName = fontName,
        )

    private fun PayUFPSubHeadingCustomization.toTridentity(): SubHeadingCustomization =
        SubHeadingCustomization(
            textColor = textColor,
            fontSize = fontSize,
            fontName = fontName,
        )

    private fun PayUFPButtonCustomization.toTridentity(): ButtonCustomization = ButtonCustomization(
        primaryButtonCustomization = primaryButtonCustomization?.toTridentity()
            ?: PrimaryButtonCustomization(),
        buttonCornerRadius = buttonCornerRadius,
        fontSize = fontSize,
        fontName = fontName,
        buttonTextTransform = buttonTextTransform,
    )

    private fun PayUFPPrimaryButtonCustomization.toTridentity(): PrimaryButtonCustomization =
        PrimaryButtonCustomization(
            enabledBackgroundColor = enabledBackgroundColor,
            enabledTextColor = enabledTextColor
        )

    private fun PayUFPToolbarCustomization.toTridentity(): ToolbarCustomization =
        ToolbarCustomization(
            backgroundColor = backgroundColor,
            textColor = textColor,
            fontSize = fontSize,
            fontName = fontName,
        )
}
