package com.payu.flashpay.coordinator

import android.content.Context
import com.payu.crashlogger.CrashManager
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.utils.PayUFPLoggingUtils

internal object PayUFPSdkInitializationCoordinator {

    private var sdkInitialized: Boolean = false

    fun initializeSDK(context: Context) {
        if (sdkInitialized) return
        CrashManager.init(context)
        sdkInitialized = true
        PayUFPLoggingUtils.logSuccess(
            context,
            PayUFPLoggingConstants.PAYU_FP_INIT,
            PayUFPLoggingConstants.PAYU_FP_INIT_SUCCESS,
        )
    }
}
