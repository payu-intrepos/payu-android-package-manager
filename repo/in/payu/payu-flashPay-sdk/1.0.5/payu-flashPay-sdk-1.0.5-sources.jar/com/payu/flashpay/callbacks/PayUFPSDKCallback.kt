package com.payu.flashpay.callbacks

import org.json.JSONObject

interface PayUFPConfigSDKCallback {
    fun onConfigureResponse(code: Int, response: JSONObject)
}

interface PayUFPDeregisterCallback {
    fun onDeRegisterResponse(code: Int, response: JSONObject)
}

interface PayUFPCheckIntactStatusCallback {
    fun onIntactResponse(code: Int, response: JSONObject)
}

interface PayUFPProcessTxnCallback: PayUFPStatusUpdateCallback {
    fun onProcessTxnResponse(code: Int, data: JSONObject)
}

interface PayUFPRegistrationStatusCallback: PayUFPStatusUpdateCallback {
    fun onRegistrationResponse(code: Int, response: JSONObject)
}

interface PayUFPStatusUpdateCallback {
    fun onStatusUpdate(response: JSONObject) {
    }
}


