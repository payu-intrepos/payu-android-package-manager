package com.payu.flashpay.mapper

import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.storage.PayUFPDataManager
import org.json.JSONObject

internal object PayUFPResponseMapper {

    enum class ResponseFlow {
        CONFIG,
        INTACT_CHECK,
        REGISTRATION,
        TRANSACTION,
        PROCEED_WITH_OTP,
        DEREGISTRATION
    }

    fun parseRegistrationStatus(json: JSONObject): String? =
        json.optJSONObject(PayUFPConstants.PAYU_FP_KEY_SUB_PARAM)
            ?.optString(PayUFPConstants.PAYU_FP_KEY_CUSTOMER_STATUS)
            ?.takeIf { it.isNotBlank() }

    fun parseTransactionSuccessMessage(json: JSONObject): String =
        json.optString(PayUFPConstants.PAYU_FP_KEY_MESSAGE)
            .trim()
            .ifEmpty { PayUFPConstants.PAYU_FP_MSG_TRANSACTION_AUTH_SUCCESS }

    fun parseDeRegisterCode(json: JSONObject): String? =
        json.optString(PayUFPConstants.PAYU_FP_KEY_CODE)
            .takeIf { it.isNotBlank() }

    fun parseDeRegisterSuccessMessage(json: JSONObject): String =
        json.optString(PayUFPConstants.PAYU_FP_KEY_MESSAGE)
            .trim()
            .ifEmpty { PayUFPConstants.PAYU_FP_MSG_DEVICE_DEREGISTERED_SUCCESS }

    fun isRegistrationSuccess(status: String?): Boolean =
        status?.equals(
            PayUFPConstants.PAYU_FP_REG_STATUS_SUCCESS,
            ignoreCase = true
        ) == true

    fun isDeRegisterSuccess(code: String?): Boolean =
        code.equals(
            PayUFPConstants.PAYU_FP_CODE_SUCCESS.toString(),
            ignoreCase = true
        )

    fun mapSuccessResponse(
        flow: ResponseFlow,
        code: Int = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
        message: String,
        payload: Map<String, Any?> = emptyMap()
    ): JSONObject =
        buildResponse(
            flow = flow,
            code = code,
            message = message,
            status = payload[PayUFPConstants.PAYU_FP_KEY_CUSTOMER_STATUS] as? String
                ?: PayUFPConstants.PAYU_FP_STATUS_SUCCESS,
            intact = true
        )

    fun mapErrorResponse(
        flow: ResponseFlow,
        code: Int,
        message: String
    ): JSONObject =
        buildResponse(
            flow = flow,
            code = code,
            message = message,
            status = PayUFPConstants.PAYU_FP_STATUS_FAILURE,
            intact = false
        )

    private fun buildResponse(
        flow: ResponseFlow,
        code: Int,
        message: String,
        status: String,
        intact: Boolean
    ): JSONObject =
        JSONObject().apply {
            put(PayUFPConstants.PAYU_FP_KEY_CODE, code)
            put(PayUFPConstants.PAYU_FP_KEY_MESSAGE, message)
            putIfNotBlank(
                PayUFPConstants.PAYU_FP_KEY_TDY_CARD_ID_RESP,
                PayUFPDataManager.mfaParams?.tdyCardId
                    ?: PayUFPDataManager.mfaParams?.tempCardId
            )

            putIfNotBlank(
                PayUFPConstants.PAYU_FP_KEY_BANK_ID,
                PayUFPDataManager.mfaParams?.bankId
            )

            when (flow) {

                ResponseFlow.CONFIG -> Unit

                ResponseFlow.INTACT_CHECK -> {
                    put(PayUFPConstants.PAYU_FP_KEY_STATUS, status)
                    put(PayUFPConstants.PAYU_FP_KEY_INTACT, intact)
                }

                ResponseFlow.REGISTRATION -> {
                    put(PayUFPConstants.PAYU_FP_KEY_STATUS, status)
                }

                ResponseFlow.TRANSACTION -> {
                    put(
                        PayUFPConstants.PAYU_FP_KEY_DATA_KEY,
                        PayUFPConstants.PAYU_FP_DATA_KEY_PAYMENT_STATUS
                    )
                    put(PayUFPConstants.PAYU_FP_KEY_STATUS, status)
                }

                ResponseFlow.PROCEED_WITH_OTP -> {
                    put(
                        PayUFPConstants.PAYU_FP_KEY_DATA_KEY,
                        PayUFPConstants.PAYU_FP_DATA_KEY_PROCEED_WITH_OTP
                    )
                    put(
                        PayUFPConstants.PAYU_FP_KEY_STATUS,
                        PayUFPConstants.PAYU_FP_STATUS_FALLBACK
                    )
                }

                ResponseFlow.DEREGISTRATION -> {
                    put(
                        PayUFPConstants.PAYU_FP_KEY_DATA_KEY,
                        PayUFPConstants.PAYU_FP_DATA_KEY_DEREGISTRATION
                    )
                    put(PayUFPConstants.PAYU_FP_KEY_STATUS, status)
                }
            }
        }

    private fun JSONObject.putIfNotBlank(
        key: String,
        value: String?
    ) {
        value?.takeIf { it.isNotBlank() }?.let {
            put(key, it)
        }
    }
}
