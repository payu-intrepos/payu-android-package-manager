package com.payu.flashpay.tridentity

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPCheckIntactStatusCallback
import com.payu.flashpay.callbacks.PayUFPConfigSDKCallback
import com.payu.flashpay.callbacks.PayUFPDeregisterCallback
import com.payu.flashpay.callbacks.PayUFPProcessTxnCallback
import com.payu.flashpay.callbacks.PayUFPRegistrationStatusCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPValidationFailureContext
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.wibmo.tridentity.sdk.TridentitySDK
import com.payu.flashpay.mapper.PayUFPRequestMapper
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import com.payu.flashpay.utils.PayUFPUIUtils
import com.wibmo.tridentity_headless.di.UpdateTransactionCallback
import org.json.JSONObject

internal object PayUFPTridentityWrapper {

    private const val TRIDENTITY_LOCAL_INTACT_SUCCESS_MESSAGE = "Local intact success"
//  TODO: do check based on the code
    internal fun isLocalIntactSuccessPayload(json: JSONObject): Boolean =
        json.optString(PayUFPConstants.PAYU_FP_KEY_MESSAGE).trim()
            .equals(TRIDENTITY_LOCAL_INTACT_SUCCESS_MESSAGE, ignoreCase = true)

    /**
     * Transaction configure is headless — pass [Context.getApplicationContext] to Tridentity
     * so [com.wibmo.tridentity.sdk.BaseTridentSDK] does not treat the host as an [android.app.Activity].
     * UI callbacks still use the original [context] (typically the payment Activity).
     */
    private fun resolveConfigSdkContext(context: Context, configParams: JSONObject): Context {
        val isTransactionConfig = configParams.optString(PayUFPConstants.PAYU_FP_KEY_MFA_MESSAGE_TYPE) ==
            PayUFPConstants.PAYU_FP_MESSAGE_TYPE_TRANSACTION
        return if (isTransactionConfig) context.applicationContext else context
    }

    fun startTridentityFlow(
        context: Context,
        configParams: JSONObject,
        startTime: Long,
        callback: PayUFPConfigSDKCallback,
    ) {
        val configSdkContext = resolveConfigSdkContext(context, configParams)
        logForwardedToTridentity(
            context,
            PayUFPLoggingConstants.PAYU_FP_CONFIG,
            configParams.toString(),
        )
        try {
            TridentitySDK.getInstance().configSdk(
                configSdkContext,
                configParams,
                PayUFPConfigTridentityResponses.configSdkCallback(
                    context = context,
                    startTime = startTime,
                    merchantCallback = callback,
                ),
            )
        } catch (t: Throwable) {
            val responseFlowContext = PayUFPValidationFailureContext.CONFIG
            handleThrowable(
                context = context,
                t = t,
                responseFlow = responseFlowContext,
                deliver = callback::onConfigureResponse,
            )
        }
    }

    fun checkRegistrationStatus(
        context: Context,
        params: JSONObject,
        isLocalCheck: Boolean = true,
        isDeregisterCall: Boolean = false,
        startTime: Long,
        callback: PayUFPCheckIntactStatusCallback,
        logCategory: String = PayUFPLoggingConstants.PAYU_FP_INTACT_CHECK,
    ) {
        logForwardedToTridentity(context, logCategory, params.toString())
        try {
            TridentitySDK.getInstance().checkRegistrationStatus(
                context,
                params,
                isLocalCheck,
                true,
                PayUFPIntactTridentityResponses.intactCheckCallback(
                    context = context,
                    coordinatorStartTime = startTime,
                    isDeregisterCall = isDeregisterCall,
                    merchantCallback = callback
                ),
            )
        } catch (t: Throwable) {
            val responseFlowContext = PayUFPValidationFailureContext.INTACT_CHECK
            handleThrowable(
                context = context,
                t = t,
                responseFlow = responseFlowContext,
                deliver = callback::onIntactResponse,
            )
        }
    }

    fun startRegistration(
        activity: AppCompatActivity,
        params: JSONObject,
        maskedMobileNumber: String?, //TODO Used in future development
        startTime: Long,
        callback: PayUFPRegistrationStatusCallback,
    ) {
        logForwardedToTridentity(
            activity,
            PayUFPLoggingConstants.PAYU_FP_REGISTRATION,
            params.toString(),
        )
        try {
            TridentitySDK.getInstance().initiateRegistration(
                activity,
                params,
                PayUFPRegistrationTridentityResponses.registrationCallback(
                    activity = activity,
                    startTime = startTime,
                    merchantCallback = callback,
                ),
            )
        } catch (t: Throwable) {
            val responseFlowContext = PayUFPValidationFailureContext.REGISTRATION
            handleThrowable(
                context = activity,
                t = t,
                responseFlow = responseFlowContext,
                deliver = callback::onRegistrationResponse,
            )
        }
    }

    fun startTransaction(
        activity: AppCompatActivity,
        params: JSONObject,
        startTime: Long,
        callback: PayUFPProcessTxnCallback,
    ) {
        logForwardedToTridentity(
            activity,
            PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
            params.toString(),
        )
        try {
            val checkIntactParam = PayUFPRequestMapper.mapToIntactCheckParams(
            )

            TridentitySDK.getInstance().processTransaction(
                activity,
                params,
                checkIntactParam,
                callback = PayUFPTransactionTridentityResponses.transactionCallback(
                    activity = activity,
                    coordinatorStartTime = startTime,
                    merchantCallback = callback,
                ),
            )
        } catch (t: Throwable) {
            PayUFPTransactionUiHelper.dismissTransactionProgressLoader()
            val responseFlowContext = PayUFPValidationFailureContext.TRANSACTION
            handleThrowable(
                context = activity,
                t = t,
                responseFlow = responseFlowContext,
                deliver = callback::onProcessTxnResponse,
            )
        }
    }

    /**
     * [TridentitySDK.deRegistration] does not accept JSON — the SDK reads persisted state.
     */
    fun startDeRegistration(
        activity: AppCompatActivity,
        startTime: Long,
        callback: PayUFPDeregisterCallback,
    ) {
        logForwardedToTridentity(activity, PayUFPLoggingConstants.PAYU_FP_DEREGISTRATION)
        try {
            TridentitySDK.getInstance().deRegistration(
                activity,
                PayUFPDeRegistrationTridentityResponses.deregistrationCallback(
                    activity = activity,
                    coordinatorStartTime = startTime,
                    merchantCallback = callback,
                ),
            )
        } catch (t: Throwable) {
            val responseFlowContext = PayUFPValidationFailureContext.DEREGISTRATION
            handleThrowable(
                context = activity,
                t = t,
                responseFlow = responseFlowContext,
                deliver = callback::onDeRegisterResponse,
            )
        }
    }

    fun logForwardedToTridentity(
        context: Context,
        logCategory: String,
        data: String? = null,
    ) {
        PayUFPLoggingUtils.logMessage(
            context,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, logCategory)
                put(
                    PayUFPLoggingConstants.EVENT_VALUE,
                    PayUFPLoggingConstants.PAYU_FP_EVENT_FORWARDED_TO_TRIDENTITY
                )
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA,data )
            }
        )
    }

    fun handleThrowable(
        context: Context,
        t: Throwable,
        responseFlow: PayUFPValidationFailureContext,
        deliver: (Int, JSONObject) -> Unit,
    ) {
        PayUFPUIUtils.dispatchOnMain(context) {
            deliverErrorResponse(
                activity = context as? AppCompatActivity,
                responseFlow = responseFlow.responseFlow,
                logCategory = responseFlow.logCategory,
                errorCode = PayUFPConstants.PAYU_FP_CODE_UNHANDLED_ERROR,
                errorMessage = t.message ?: PayUFPConstants.PAYU_FP_MSG_UNHANDLED_ERROR,
                deliver = deliver
            )
        }

    }
    fun callProcessAndUpdate(
        appCompatActivity: AppCompatActivity,
        status: String,
        reasonCode: String?,
        onComplete: () -> Unit = {}
    ) {
        val params = PayUFPRequestMapper.createProcessAndUpdateStatus(status, reasonCode)
        try {
            TridentitySDK.getInstance().processTransaction(
                appCompatActivity,
                params,
                true,
                callback = object : UpdateTransactionCallback {
                    override fun onSuccess(event: JSONObject) {
                        PayUFPUIUtils.dispatchOnMain(appCompatActivity) {
                            onComplete()
                        }
                    }

                    override fun onError(code: Int, error: String) {
                        PayUFPUIUtils.dispatchOnMain(appCompatActivity) {
                            onComplete()
                        }
                    }
                })
        } catch (t: Throwable) {
            PayUFPUIUtils.dispatchOnMain(appCompatActivity) {
                onComplete()
            }
        }
    }
}
