package com.payu.flashpay.coordinator

import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPDeregisterCallback
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.tridentity.PayUFPTridentityWrapper
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.validator.PayUFPInputValidator
import org.json.JSONObject

internal object PayUFPDeRegistrationCoordinator {

    fun deRegister(
        activity: AppCompatActivity,
        callback: PayUFPDeregisterCallback
    ) {
        val startTime = System.currentTimeMillis()
        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_DEREGISTRATION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_INIT_PARAMS)
            }
        )

        PayUFPInputValidator.validateSdkConfigured()?.let { error ->
            val responseFlowContext = PayUFPValidationFailureContext.DEREGISTRATION
            deliverErrorResponse(
                activity = activity,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = error.code,
                errorMessage = error.message,
                deliver = callback::onDeRegisterResponse,
            )
            return
        }

        PayUFPTridentityWrapper.startDeRegistration(
            activity = activity,
            startTime = startTime,
            callback = callback
        )
    }
}
