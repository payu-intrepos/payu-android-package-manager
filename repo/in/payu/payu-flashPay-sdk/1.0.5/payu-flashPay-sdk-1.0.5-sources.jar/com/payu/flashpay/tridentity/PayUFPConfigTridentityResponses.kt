package com.payu.flashpay.tridentity

import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPConfigSDKCallback
import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPValidationFailureContext
import com.payu.flashpay.mapper.PayUFPErrorMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import com.wibmo.tridentity_headless.di.ConfigStatusCallback
import org.json.JSONObject

internal object PayUFPConfigTridentityResponses {
    private val AUTO_DEREG_CONFIG_TAG: String = "configSdkCallback"

    fun configSdkCallback(
        context: Context,
        startTime: Long,
        merchantCallback: PayUFPConfigSDKCallback,
    ): ConfigStatusCallback = object : ConfigStatusCallback {
        override fun onSuccess(event: JSONObject) {
            Log.d("configSdkCallback", "onSuccess: ")
            PayUFPUIUtils.dispatchOnMain(context) {
                val successResponse = PayUFPResponseMapper.mapSuccessResponse(
                    ResponseFlow.CONFIG,
                    code = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                    message = PayUFPConstants.PAYU_FP_MSG_SDK_CONFIGURED_SUCCESS
                )
                PayUFPLoggingUtils.logSuccess(
                    context,
                    PayUFPLoggingConstants.PAYU_FP_CONFIG,
                    PayUFPLoggingConstants.PAYU_FP_EVENT_SUCCESS,
                    PayUFPUIUtils.getTimeDifferenceInMilliSeconds(startTime),
                    data = successResponse.toString(),
                )
                merchantCallback.onConfigureResponse(
                    PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                    successResponse
                )
            }
        }

        override fun onError(code: Int, error: String) {
            PayUFPUIUtils.dispatchOnMain(context) {
                configureSDKCallback(context, code, error, merchantCallback)
            }
        }

        override fun onError(error: String) {
            val errorJsonObject = JSONObject(error)
            val errorCode = errorJsonObject.optString("code")
            val errorMessage = errorJsonObject.optString("message")
            configureSDKCallback(context, errorCode.toInt(), errorMessage, merchantCallback)
        }
    }

    fun configureSDKCallback(
        context: Context,
        code: Int,
        error: String,
        merchantCallback: PayUFPConfigSDKCallback
    ) {
        Log.d("Anand", "configureSDKCallback: $code and $error")
        val activity = context as? AppCompatActivity
//        if (code in PayUFPConstants.PAYU_FP_AUTO_DEREGISTER_CODES && activity != null) {
//            PayUFPTransactionUiHelper.showDeregisterBottomSheet(
//                activity = activity,
//                bankLogo = PayUFPDataManager.mfaParams?.bankLogo,
//                errorMsg = error,
//                errorCode = code,
//            ) {
//                val responseFlowContext = PayUFPValidationFailureContext.CONFIG
//                deliverErrorResponse(
//                    activity = activity,
//                    responseFlow = responseFlowContext.responseFlow,
//                    logCategory = responseFlowContext.logCategory,
//                    errorCode = code,
//                    errorMessage = error,
//                    deliver = merchantCallback::onConfigureResponse
//                )
//            }
//
//        } else {
            val (errorCode, errorMessage) = PayUFPErrorMapper.mapConfigureError(code, error)
            val responseFlowContext = PayUFPValidationFailureContext.CONFIG
            deliverErrorResponse(
                activity = activity,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = errorCode,
                errorMessage = errorMessage,
                deliver = merchantCallback::onConfigureResponse
            )
        //}
    }
}
