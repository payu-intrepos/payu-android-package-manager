package com.payu.flashpay.utils

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.payu.flashpay.BuildConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.enums.EventSeverity
import com.payu.flashpay.enums.EventStatus
import com.payu.flashpay.enums.EventType
import com.payu.flashpay.mapper.PayUFPTridentityProgressMapper
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPUIUtils.normalizeId
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsConfig
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

internal object PayUFPLoggingUtils {

    private const val TAG = "FlashPayLogger"

    @Volatile
    private var payUAnalytics: PayUAnalytics? = null

    private val logHandlerThread = HandlerThread("PayU-FlashPay-LogThread").also { it.start() }
    private val logHandler = Handler(logHandlerThread.looper)


    fun logMessage(
        context: Context,
        eventSeverity: EventSeverity = EventSeverity.Low,
        eventType: EventType = EventType.Info,
        eventStatus: EventStatus = EventStatus.Initiated,
        analyticsJson: JSONObject? = null
    ) {
        logHandler.post {
            val analytics = ensureAnalytics(context) ?: return@post
            val baseJson =
                getAnalyticsJsonWithBasicProperties(context, analyticsJson ?: JSONObject())
            baseJson.put(PayUFPLoggingConstants.EVENT_SEVERITY, eventSeverity.name)
            baseJson.put(PayUFPLoggingConstants.EVENT_TYPE, eventType.name)
            baseJson.put(PayUFPLoggingConstants.EVENT_STATUS, eventStatus.name)
            analytics.log(baseJson.toString())
        }
    }

    fun logSuccess(
        activity: Context,
        key: String,
        msg: String,
        sdkTime: Long = 0L,
        data: String = "",
    ) {
        logMessage(
            activity,
            EventSeverity.Low,
            EventType.Info,
            EventStatus.Success,
            JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, key)
                put(PayUFPLoggingConstants.EVENT_VALUE, msg)
                put(PayUFPLoggingConstants.PAYU_SDK_TIME, sdkTime.toString())
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, data)
            }
        )
    }


    fun logRegistrationProgress(activity: Activity, progressJson: String) {
        val eventValue = PayUFPTridentityProgressMapper.mapRegistrationProgress(progressJson) ?: return
        logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_REGISTRATION)
                put(PayUFPLoggingConstants.EVENT_VALUE, eventValue)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, progressJson)
            }
        )
    }

    fun logTransactionProgress(activity: Activity, progressJson: String) {
        val eventValue = PayUFPTridentityProgressMapper.mapTransactionProgress(progressJson) ?: return
        logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(PayUFPLoggingConstants.EVENT_VALUE, eventValue)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, progressJson)
            }
        )
    }

    fun logError(
        activity: Context,
        key: String,
        msg: String,
        errorCode: Int,
        sdkTime: Long = 0L,
        data: String = "",
    ) {
        logMessage(
            activity,
            EventSeverity.High,
            EventType.Error,
            EventStatus.Failed,
            JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, key)
                put(PayUFPLoggingConstants.EVENT_VALUE, msg)
                put(PayUFPLoggingConstants.PAYU_FP_ERROR_CODE, errorCode)
                put(PayUFPLoggingConstants.PAYU_SDK_TIME, sdkTime.toString())
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, data)
            }
        )
    }

    fun dataJson(vararg pairs: Pair<String, Any?>): String {
        val json = JSONObject()
        for ((key, value) in pairs) {
            if (value == null) continue
            json.put(key, toJsonValue(value))
        }
        return json.toString()
    }

    fun registrationTypeAnalyticsData(): String {
        val mfa = PayUFPDataManager.mfaParams ?: return ""
        val registrationType = registrationTypeEventValue()
        return dataJson(
            PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MESSAGE_TYPE to mfa.messageType,
            PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TEMP_CARD_ID to mfa.tempCardId,
            PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TDY_CARD_ID to mfa.tdyCardId,
            PayUFPLoggingConstants.PAYU_FP_DATA_KEY_REGISTRATION_TYPE to registrationType.takeIf { it.isNotBlank() },
            PayUFPLoggingConstants.PAYU_FP_DATA_KEY_IS_FRESH_REGISTRATION to isFreshRegistration(),
        )
    }

    fun registrationTypeEventValue(): String {
        return if (isFreshRegistration() == true) PayUFPLoggingConstants.PAYU_FP_FRESH_REGISTRATION
        else PayUFPLoggingConstants.PAYU_FP_RE_REGISTRATION
    }

    private fun isFreshRegistration(): Boolean? {
        val mfa = PayUFPDataManager.mfaParams ?: return null
        return mfa.messageType == PayUFPConstants.PAYU_FP_MESSAGE_TYPE_REGISTRATION
    }

    private fun toJsonValue(value: Any): Any {
        return when (value) {
            is Map<*, *> -> {
                val obj = JSONObject()
                for ((k, v) in value) {
                    if (k == null || v == null) continue
                    obj.put(k.toString(), toJsonValue(v))
                }
                obj
            }
            is Iterable<*> -> {
                val arr = JSONArray()
                for (item in value) {
                    if (item == null) continue
                    arr.put(toJsonValue(item))
                }
                arr
            }
            is Array<*> -> {
                val arr = JSONArray()
                for (item in value) {
                    if (item == null) continue
                    arr.put(toJsonValue(item))
                }
                arr
            }
            else -> value
        }
    }

    private fun ensureAnalytics(context: Context): PayUAnalytics? {
        return try {
            val analyticsConfig = AnalyticsConfig()
            analyticsConfig.isDebugEnabled = false
            AnalyticsFactory(context.applicationContext, analyticsConfig).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as? PayUAnalytics
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialise PayUAnalytics: ${e.message}", e)
            null
        }
    }

    private fun getAnalyticsJsonWithBasicProperties(
        context: Context,
        analyticsJson: JSONObject
    ): JSONObject {
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_IS_RECURRING_TXN,
            isFreshRegistration() != true
        )
        analyticsJson.put(PayUFPLoggingConstants.TIMESTAMP, getCurrentTimestamp())
        analyticsJson.put(PayUFPLoggingConstants.SDK_NAME, PayUFPLoggingConstants.SDK_NAME_VALUE)
        analyticsJson.put(PayUFPLoggingConstants.SDK_VERSION, BuildConfig.VERSION_NAME)
        analyticsJson.put(PayUFPLoggingConstants.PLATFORM, PayUFPLoggingConstants.PLATFORM_VALUE)
        analyticsJson.put(PayUFPLoggingConstants.APPLICATION_VERSION, getApplicationVersion(context))
        analyticsJson.put(
            PayUFPLoggingConstants.APPLICATION_PACKAGE,
            context.applicationContext?.packageName
        )
        analyticsJson.put(
            PayUFPLoggingConstants.LOGGING_SDK,
            BuildConfig.LIBRARY_PACKAGE_NAME
        )
        analyticsJson.put(PayUFPLoggingConstants.LOGGING_SDK_VERSION, BuildConfig.VERSION_NAME)
        analyticsJson.put(PayUFPLoggingConstants.TXN_ID, PayUFPDataManager.getTxnId())
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_CLIENT_ID, PayUFPDataManager.mfaParams?.tdyClientId)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_BANK_ID, PayUFPDataManager.mfaParams?.bankId)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_TDY_CARD_ID, PayUFPDataManager.mfaParams?.uid)
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_ACS_TXN_ID,
            PayUFPDataManager.payUFPConfig?.acsTxnId ?: PayUFPDataManager.getAcsTxnId()
        )
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_BINDING_TYPE, PayUFPDataManager.mfaParams?.bindingType)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_CUSTOMER_ID, PayUFPDataManager.mfaParams?.customerId)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_MERCHANT_ID, PayUFPDataManager.mfaParams?.merchantId)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_TYPE, PayUFPDataManager.mfaParams?.messageType)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_MERCHANT_TXN_ID, PayUFPDataManager.mfaParams?.merchantTxnId)
        analyticsJson.put(PayUFPLoggingConstants.PAYU_FP_MERCHANT_MOBILE_NO, PayUFPDataManager.mfaParams?.merchantMobileNo)
        PayUFPDataManager.mfaParams?.let { params ->
            analyticsJson.put(
                PayUFPLoggingConstants.PAYU_FP_CARD_TYPE,
                if (params.tempCardId.normalizeId() != null) {
                    PayUFPLoggingConstants.PAYU_FP_CARD_TYPE_TEMP
                } else {
                    PayUFPLoggingConstants.PAYU_FP_CARD_TYPE_TDY
                }
            )
        }
        analyticsJson.put(
            PayUFPLoggingConstants.MERCHANT_KEY,
            PayUFPDataManager.mfaParams?.merchantKey ?: PayUFPDataManager.payUFPConfig?.merchantKey
        )
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_MERCHANT_NAME,
            PayUFPDataManager.payUFPConfig?.merchantName
        )

        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_TXN_AMOUNT,
            PayUFPDataManager.mfaParams?.txnAmount ?: PayUFPDataManager.payUFPConfig?.amount
        )
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_KEY_MERCHANT_ID_FIELD,
            PayUFPDataManager.mfaParams?.merchantId
        )
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_REQUEST_ID,
            PayUFPDataManager.mfaParams?.merchantTxnId
        )
        analyticsJson.put(
            PayUFPLoggingConstants.PAYU_FP_CUSTOMER_ID,
            PayUFPDataManager.mfaParams?.customerId
        )

        val deviceName = "${Build.MANUFACTURER}_${Build.MODEL}"
        val deviceOsVersion = Build.VERSION.SDK_INT
        analyticsJson.put(
            PayUFPLoggingConstants.DEVICE_OS_VERSION,
            Build.VERSION.RELEASE
        )

        try {
            val deviceTotalMemory = getTotalMemoryInfo(context)
            val availMemory = getAvailableMemoryInfo(context)
            val memoryInfo = if (deviceTotalMemory > 0) availMemory * 100 / deviceTotalMemory else 0
            analyticsJson.put(
                PayUFPLoggingConstants.DEVICE_DETAILS,
                "${deviceName}_${deviceOsVersion}_${memoryInfo}%"
            )
        } catch (e: Exception) {
            analyticsJson.put(
                PayUFPLoggingConstants.DEVICE_DETAILS,
                "${deviceName}_${deviceOsVersion}"
            )
        }
        return analyticsJson
    }

    private fun getCurrentTimestamp(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            DateTimeFormatter.ofPattern(PayUFPLoggingConstants.DATE_FORMAT, Locale.US)
                .format(LocalDateTime.now())
        } else {
            val sdf = SimpleDateFormat(PayUFPLoggingConstants.DATE_FORMAT, Locale.US)
            sdf.format(Date())
        }
    }

    private fun getMemoryInfo(context: Context): ActivityManager.MemoryInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
    }

    private fun getTotalMemoryInfo(context: Context): Long {
        return getMemoryInfo(context).totalMem / (1024 * 1024)
    }

    private fun getAvailableMemoryInfo(context: Context): Long {
        return getMemoryInfo(context).availMem / (1024 * 1024)
    }


    private fun getApplicationVersion(context: Context): String {
        return try {
            val packageInfo: PackageInfo =
                context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName ?: "unknown"
        } catch (e: PackageManager.NameNotFoundException) {
            "unknown"
        }
    }
}
