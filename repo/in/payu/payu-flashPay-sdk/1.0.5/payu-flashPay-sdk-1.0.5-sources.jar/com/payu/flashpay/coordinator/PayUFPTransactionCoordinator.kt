package com.payu.flashpay.coordinator

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPCheckIntactStatusCallback
import com.payu.flashpay.callbacks.PayUFPProcessTxnCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverTransactionOtpFallback
import com.payu.flashpay.enums.AuthType
import com.payu.flashpay.mapper.PayUFPRequestMapper
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.tridentity.PayUFPTridentityWrapper
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.validator.PayUFPInputValidator
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import com.payu.flashpay.view.PayUFPTransactionUiHelper.dismissAuthSelectionUi
import org.json.JSONObject

internal object PayUFPTransactionCoordinator {
    
    private var pendingCallback: PayUFPProcessTxnCallback? = null
    private var transactionStartTime: Long = 0L

    fun processTransaction(
        context: Context,
        callback: PayUFPProcessTxnCallback,
    ) {
        val activity = context as? AppCompatActivity
        if (activity == null) {
            deliverErrorResponse(
                activity = null,
                errorCode = PayUFPConstants.PAYU_FP_CODE_CANNOT_PRESENT_SCREEN,
                errorMessage = PayUFPConstants.PAYU_FP_MSG_ACTIVITY_DESTROYED,
                responseFlow = PayUFPValidationFailureContext.TRANSACTION.responseFlow,
                logCategory = PayUFPValidationFailureContext.TRANSACTION.logCategory,
                deliver = callback::onProcessTxnResponse,
            )
            return
        }
        val startTime = System.currentTimeMillis()
        pendingCallback = callback
        transactionStartTime = startTime
        logProcessTransactionStarted(activity)

        if (!validateTxnSdkAndParams(activity, callback)) {
            return
        }

        openAuthUi(activity, startTime, callback)
    }

    private fun openAuthUi(
        activity: AppCompatActivity,
        startTime: Long,
        callback: PayUFPProcessTxnCallback,
    ) {
        val mfa = PayUFPDataManager.mfaParams
        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_INIT_CHECK_INTACT_PARAMS)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_TDY_CARD_ID to mfa?.tdyCardId,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_IS_LOCAL_CHECK to true,
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_BANK_ID to mfa?.bankId
                ))
            }
        )
        PayUFPIntactCheckCoordinator.checkIntactStatus(
            context = activity,
            tdyCardId = mfa?.tdyCardId,
            bankId = mfa?.bankId,
            isLocalCheck = true,
            isDeregisterCall = true,
            callback = object : PayUFPCheckIntactStatusCallback {
                override fun onIntactResponse(code: Int, response: JSONObject) {
                    val message = response.optString(PayUFPConstants.PAYU_FP_KEY_MESSAGE)
                        .ifBlank { PayUFPConstants.PAYU_FP_MSG_CUSTOMER_NOT_REGISTERED }
                    when (code) {
                        PayUFPConstants.PAYU_FP_CODE_SUCCESS -> {
                            openTransactionAuthSelectionFlow(activity, startTime, callback)
                        }
//                        300, 303 -> {
//                            PayUFPTransactionUiHelper.logTransactionAuthUiShown(
//                                activity,
//                                PayUFPLoggingConstants.PAYU_FP_NO
//                            )
//                            Log.d("Anand", "PayUFPCheckIntactStatusCallback: onSuccess $code and $response")
//                            PayUFPTransactionUiHelper.showDeregisterBottomSheet(
//                                activity = activity,
//                                bankLogo = PayUFPDataManager.mfaParams?.bankLogo,
//                                errorMsg = message,
//                                errorCode = code,
//                            ) {
//                                deliverTransactionOtpFallback(
//                                    activity = activity,
//                                    deliver = callback::onProcessTxnResponse,
//                                    errorCode = code,
//                                    errorMessage = message,
//                                )
//                            }
//                        }
                        else -> {
                            PayUFPTransactionUiHelper.logTransactionAuthUiShown(
                                activity,
                                PayUFPLoggingConstants.PAYU_FP_NO
                            )
                            val responseFlowContext = PayUFPValidationFailureContext.TRANSACTION
                            val message = response.optString(PayUFPConstants.PAYU_FP_KEY_MESSAGE)
                                .ifBlank { PayUFPConstants.PAYU_FP_MSG_CUSTOMER_NOT_REGISTERED }
                            deliverErrorResponse(
                                activity = activity,
                                responseFlow = responseFlowContext.responseFlow,
                                logCategory = responseFlowContext.logCategory,
                                errorCode = code,
                                errorMessage = message,
                                deliver = callback::onProcessTxnResponse
                            )
                        }
                    }
                }
            },
        )
    }

    private fun openTransactionAuthSelectionFlow(
        activity: AppCompatActivity,
        startTime: Long,
        callback: PayUFPProcessTxnCallback,
    ) {
        PayUFPTransactionUiHelper.openTransactionAuthSelectionFlow(
            activity = activity,
            onHostInvalid = {
                val responseFlowContext = PayUFPValidationFailureContext.TRANSACTION
                deliverErrorResponse(
                    activity = activity,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = PayUFPConstants.PAYU_FP_CODE_CANNOT_PRESENT_SCREEN,
                    errorMessage = PayUFPConstants.PAYU_FP_MSG_ACTIVITY_DESTROYED,
                    deliver = callback::onProcessTxnResponse,
                )
            },
            onAuthTypeSelected = { authType, eventValue, reason, reasonCode ->
                handleAuthSelection(
                    appCompatActivity = activity,
                    authType = authType,
                    otpFallbackEventValue = eventValue,
                    reason = reason,
                    reasonCode = reasonCode,
                )
            },
        )
    }

    private fun logProcessTransactionStarted(activity: Activity) {
        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_PROCESSING_STARTED)
            }
        )
    }

    private fun validateTxnSdkAndParams(
        activity: AppCompatActivity,
        callback: PayUFPProcessTxnCallback,
    ): Boolean {
        PayUFPInputValidator.validateProcessTxnParams()?.let { error ->
            if (error.code == PayUFPConstants.PAYU_FP_CODE_INVALID_PARAMS) {
                deliverTransactionOtpFallback(
                    context = activity,
                    deliver = callback::onProcessTxnResponse,
                    errorCode = error.code,
                    errorMessage = error.message,
                )
            } else {
                val responseFlowContext = PayUFPValidationFailureContext.TRANSACTION
                deliverErrorResponse(
                    activity = activity,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = error.code,
                    errorMessage = error.message,
                    deliver = callback::onProcessTxnResponse,
                )
            }
            return false
        }
        return true
    }

    internal fun handleAuthSelection(
        appCompatActivity: AppCompatActivity,
        authType: AuthType,
        otpFallbackEventValue: String?,
        reason: String?,
        reasonCode: String?,
    ) {
        val callback = pendingCallback ?: return
        when (authType) {
            AuthType.BIOMETRIC -> startBiometricTransaction(
                appCompatActivity, transactionStartTime, callback
            )
            AuthType.OTP -> notifyProceedWithOtp(
                appCompatActivity,
                callback,
                otpFallbackEventValue ?: PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK_MANUAL,
                reason,
                reasonCode
            )
            AuthType.USER_CANCELLED -> notifyTransactionCancelledByUser(appCompatActivity, callback)
        }
    }

    private fun startBiometricTransaction(
        appCompatActivity: AppCompatActivity,
        startTime: Long,
        callback: PayUFPProcessTxnCallback,
    ) {
        PayUFPLoggingUtils.logMessage(
            appCompatActivity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_TRANSACTION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_BIOMETRIC_AUTH_SELECTED)
            }
        )
        val params = PayUFPRequestMapper.mapToTransactionParams()
        PayUFPTridentityWrapper.startTransaction(
            activity = appCompatActivity,
            params = params,
            startTime = startTime,
            callback = callback,
        )
    }


    private fun notifyProceedWithOtp(
        activity: AppCompatActivity,
        callback: PayUFPProcessTxnCallback,
        eventValue: String,
        reason: String?,
        reasonCode: String?
    ) {
        val status = statusForOtpFallback(reason)
        dismissAuthSelectionUi(activity)
        val deliverOtpFallback = {
            PayUFPCoordinatorErrorHandler.deliverTransactionOtpFallback(
                activity,
                callback::onProcessTxnResponse,
                errorMessage = reason,
                eventValue = eventValue
            )
        }
        if (status != null) {
            PayUFPTridentityWrapper.callProcessAndUpdate(activity, status, reasonCode, deliverOtpFallback)
        } else {
            deliverOtpFallback()
        }
    }

    private fun statusForOtpFallback(reason: String?): String? = when (reason) {
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_CHOSE_OTP,
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_USER_PRESSED_BACK -> PayUFPConstants.PAYU_FP_STATUS_CANCELLED
        PayUFPLoggingConstants.PAYU_FP_AUTH_REASON_TIMER_EXPIRED -> PayUFPConstants.PAYU_FP_STATUS_EXPIRED
        else -> null
    }

    private fun notifyTransactionCancelledByUser(
        activity: AppCompatActivity,
        callback: PayUFPProcessTxnCallback,
    ) {
        dismissAuthSelectionUi(activity)
        val responseFlowContext = PayUFPValidationFailureContext.TRANSACTION
        deliverErrorResponse(
            activity = activity,
            responseFlow = responseFlowContext.responseFlow,
            logCategory = responseFlowContext.logCategory,
            errorCode = PayUFPConstants.PAYU_FP_CODE_TXN_CANCELLED_BY_USER,
            errorMessage = PayUFPConstants.PAYU_FP_MSG_TXN_CANCELLED_BY_USER,
            deliver = callback::onProcessTxnResponse,
        )
    }
}
