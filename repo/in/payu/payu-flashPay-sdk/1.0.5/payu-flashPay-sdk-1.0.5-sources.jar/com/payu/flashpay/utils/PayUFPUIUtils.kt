package com.payu.flashpay.utils

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.payu.flashpay.R
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.model.PayUFPUICustomization
import com.payu.flashpay.storage.PayUFPDataManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.String
import org.w3c.dom.Text
import kotlin.math.roundToInt


internal object PayUFPUIUtils {
    private const val TAG = "PayUFPUIUtils"

    private const val MAX_ALPHA = 255
    private const val FONT_SIZE_MIN = 11f
    private const val FONT_SIZE_MAX = 19f
    private const val PROGRESS_BUTTON_TRACK_ALPHA = 128
    private const val DEFAULT_BUTTON_CORNER_RADIUS_DP = 8
    private var elapsedLastClickTime: Long = 0


    fun logExceptionToAnalytics(context: Context, tag: String, message: String, error: Throwable) {
        Log.e(tag, "$message: ${error.message}", error)
        try {
            val activity = (context as? Activity) ?: return
            PayUFPLoggingUtils.logError(
                activity,
                PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
                PayUFPLoggingConstants.PAYU_FP_EVENT_FAILED,
                com.payu.flashpay.constants.PayUFPConstants.PAYU_FP_CODE_UNHANDLED_ERROR,
                data = PayUFPLoggingUtils.dataJson(
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MESSAGE to "$message: ${error.javaClass.simpleName} ${error.message.orEmpty()}"
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to forward swallowed exception to analytics: ${e.message}", e)
        }
    }

    internal fun getAlertDialog(
        activity: Context?,
        onClickDialog: DialogInterface.OnClickListener?,
        positiveText: String?,
        negativeText: String?,
        title: String?,
        message: String?,
        neutralText: String? = null
    ): AlertDialog.Builder {
        val alertBox =
            AlertDialog.Builder(activity, R.style.PayU_FP_Cancel_Dialog)
        if (onClickDialog != null) {
            if (title != null) alertBox.setTitle(title)
            if (message != null) alertBox.setMessage(message)
            if (positiveText != null) alertBox.setPositiveButton(positiveText, onClickDialog)
            if (negativeText != null) alertBox.setNegativeButton(negativeText, onClickDialog)
            if (neutralText != null) alertBox.setNeutralButton(neutralText, onClickDialog)
        }
        return alertBox
    }

    internal fun isInternetAvailable(context: Context): Boolean {
        var result = false

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            result = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_WIFI -> true
                        ConnectivityManager.TYPE_MOBILE -> true
                        ConnectivityManager.TYPE_ETHERNET -> true
                        else -> false
                    }

                }
            }
        }

        return result
    }

    internal fun generateTransparentColor(context: Context, colorRes: Int, alpha: Double?): Int {
        return this.applyAlphaToColor(ContextCompat.getColor(context, colorRes), alpha)
    }

    /** Hex-string overload — used when the color comes from a merchant theme config. */
    internal fun generateTransparentColor(hexColor: String, alpha: Double): Int {
        return applyAlphaToColor(Color.parseColor(hexColor), alpha)
    }

    private fun applyAlphaToColor(color: Int, alpha: Double?): Int {
        val colorAlpha = alpha?.times(MAX_ALPHA)?.roundToInt() ?: MAX_ALPHA
        return ColorUtils.setAlphaComponent(color, colorAlpha)
    }

    /**
     * Returns true when [color] is a non-blank string that [Color.parseColor] can successfully
     * parse (e.g. "#25272C", "#FF25272C", "red").  Any invalid or null value returns false.
     */
    internal fun isValidColorCode(color: String?): Boolean {
        if (color.isNullOrBlank()) return false
        return try {
            Color.parseColor(color)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Attempts to load a [Typeface] from the app's assets folder at [fontPath].
     * Returns null (and logs a warning) if the asset does not exist or cannot be decoded.
     */
    internal fun loadTypeface(context: Context, fontPath: String): Typeface? {
        return try {
            Typeface.createFromAsset(
                context.assets,
                fontPath.replace("assets/", "")
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not load typeface from '$fontPath': ${e.message}")
            null
        }
    }

    /**
     * Applies merchant-supplied [PayUFPUICustomization] to auth-selection themed views.
     * Each block is independently guarded so a missing/invalid value never suppresses another.
     */
    internal fun applyAuthUiCustomisation(
        context: Context,
        uiCustomisation: PayUFPUICustomization?,
        rlHeader: View,
        ivFingerprint: ImageView,
        ivFingerPrintBtn: ImageView?,
        tvMerchantName: TextView,
        tvTxnAmount: TextView,
        tvPayingTo: TextView,
        lblUseOtp: TextView,
        lblUseOtpDesc: TextView,
        tvOTPRedirect: TextView?,
        btnConfirmLabel: TextView?,
        lblTapToPause: TextView?,
        btnConfirmLayout: View?,
        btnConfirmProgressFill: View?,
        ivBack: ImageView?,
    ) {
        if (uiCustomisation == null) return

        val labels = uiCustomisation.labelCustomization
        val button = uiCustomisation.buttonCustomization
        val primaryButton = button?.primaryButtonCustomization
        val heading = labels?.headingCustomization
        val subHeading = labels?.subHeadingCustomization

        applyTypeface(context, subHeading?.fontName, lblUseOtpDesc, tvOTPRedirect, tvTxnAmount, tvPayingTo)
        applyTypeface(context, heading?.fontName, tvMerchantName)
        applyTypeface(context, button?.fontName, btnConfirmLabel, lblTapToPause, lblUseOtp)

        parseColor(primaryButton?.enabledTextColor)?.let { color ->
            btnConfirmLabel?.setTextColor(color)
            lblTapToPause?.setTextColor(color)
            ivFingerPrintBtn?.imageTintList = ColorStateList.valueOf(color)
            ivBack?.imageTintList = ColorStateList.valueOf(color)
        }

        parseColor(heading?.textColor)?.let { color ->
            tvMerchantName.setTextColor(color)
        }
        heading?.fontSize?.takeIf { it in FONT_SIZE_MIN..FONT_SIZE_MAX }?.let { size ->
            applyFontSize(size, tvMerchantName, btnConfirmLabel, lblTapToPause)
        }

        parseColor(subHeading?.textColor)?.let { color ->
            lblUseOtpDesc.setTextColor(color)
            tvTxnAmount.setTextColor(color)
            tvPayingTo.setTextColor(color)
        }
        subHeading?.fontSize?.takeIf { it in FONT_SIZE_MIN..FONT_SIZE_MAX }?.let { size ->
            applyFontSize(size, lblUseOtpDesc, tvTxnAmount, tvPayingTo, tvOTPRedirect)
        }

        primaryButton?.enabledBackgroundColor
            ?.takeIf { isValidColorCode(it) }
            ?.let { bgHex ->
                val bgColor = Color.parseColor(bgHex)
                applyProgressButtonStyle(
                    container = btnConfirmLayout,
                    fillView = btnConfirmProgressFill,
                    bgColor = bgHex,
                    cornerRadiusDp = button?.buttonCornerRadius,
                    context = context,
                )
//                lblUseOtp.setTextColor(bgColor)
//                rlHeader.setBackgroundColor(generateTransparentColor(bgHex, 0.1))
            }

        when (button?.buttonTextTransform?.uppercase()) {
            "UPPER_CASE" -> {
                btnConfirmLabel?.isAllCaps = true
                lblTapToPause?.isAllCaps = true
            }
            "LOWER_CASE" -> {
                btnConfirmLabel?.isAllCaps = false
                btnConfirmLabel?.text = btnConfirmLabel?.text?.toString()?.lowercase()
                lblTapToPause?.isAllCaps = false
                lblTapToPause?.text = lblTapToPause?.text?.toString()?.lowercase()
            }
        }
    }


    fun applyDeregisterUICustomisation(
        lblMsg: TextView,
        lblDeregisterMessage: TextView,
        btnDeregisterLabel: TextView?,
        btnDeregContainer: View?,
        btnConfirmProgressFill: View?,
        deregTopSection: View? = null,
    ) {
        val uiCustomisation = PayUFPDataManager.themeModel?.uiCustomization
        val labels = uiCustomisation?.labelCustomization
        val button = uiCustomisation?.buttonCustomization
        val primaryButton = button?.primaryButtonCustomization
        val heading = labels?.headingCustomization
        val subHeading = labels?.subHeadingCustomization
        val context = lblMsg.context
        applyTypeface(context, subHeading?.fontName, lblDeregisterMessage)
        applyTypeface(context, heading?.fontName, lblMsg)
        applyTypeface(context, button?.fontName, btnDeregisterLabel)
        parseColor(primaryButton?.enabledTextColor)?.let { color ->
            btnDeregisterLabel?.setTextColor(color)
        }

        parseColor(heading?.textColor)?.let { color ->
            lblMsg.setTextColor(color)
        }
        heading?.fontSize?.takeIf { it in FONT_SIZE_MIN..FONT_SIZE_MAX }?.let { size ->
            applyFontSize(size,lblMsg)
        }

        parseColor(subHeading?.textColor)?.let { color ->
            lblDeregisterMessage.setTextColor(color)
        }
        subHeading?.fontSize?.takeIf { it in FONT_SIZE_MIN..FONT_SIZE_MAX }?.let { size ->
            applyFontSize(size, lblDeregisterMessage)
        }
        button?.fontSize?.takeIf { it in FONT_SIZE_MIN..FONT_SIZE_MAX }?.let { size ->
            applyFontSize(size, btnDeregisterLabel)
        }

        primaryButton?.enabledBackgroundColor
            ?.takeIf { isValidColorCode(it) }
            ?.let { bgHex ->
                applyProgressButtonStyle(
                    container = btnDeregContainer,
                    fillView = btnConfirmProgressFill,
                    bgColor = bgHex,
                    cornerRadiusDp = button?.buttonCornerRadius,
                    context = context,
                )
//                deregTopSection?.setBackgroundColor(generateTransparentColor(bgHex, 0.1))
            }

        when (button?.buttonTextTransform?.uppercase()) {
            "UPPER_CASE" -> btnDeregisterLabel?.isAllCaps = true
            "LOWER_CASE" -> {
                btnDeregisterLabel?.isAllCaps = false
                btnDeregisterLabel?.text = btnDeregisterLabel?.text?.toString()?.lowercase()
            }
        }

    }

    internal fun applyProgressButtonStyle(
        container: View?,
        fillView: View?,
        bgColor: String,
        cornerRadiusDp: Int?,
        context: Context,
    ) {
        if (!isValidColorCode(bgColor)) return
        val containerView = container ?: return
        val parsedColor = Color.parseColor(bgColor)
        val cornerRadiusPx = dpToPx(context, cornerRadiusDp ?: DEFAULT_BUTTON_CORNER_RADIUS_DP)

        containerView.background = GradientDrawable().apply {
            setColor(ColorUtils.setAlphaComponent(parsedColor, PROGRESS_BUTTON_TRACK_ALPHA))
            cornerRadius = cornerRadiusPx
        }
        fillView?.background = GradientDrawable().apply {
            setColor(parsedColor)
            cornerRadius = cornerRadiusPx
        }
    }

    private fun dpToPx(context: Context, dp: Int): Float =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            context.resources.displayMetrics
        )

    private fun applyTypeface(context: Context, fontPath: String?, vararg views: TextView?) {
        val path = fontPath?.takeIf { it.isNotBlank() } ?: return
        val typeface = loadTypeface(context, path) ?: return
        views.forEach { it?.typeface = typeface }
    }

    private fun applyFontSize(sizeSp: Float, vararg views: TextView?) {
        views.forEach { it?.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp) }
    }

    private fun parseColor(color: String?): Int? =
        color?.takeIf { isValidColorCode(it) }?.let { Color.parseColor(it) }


    fun getCountDownTimer(
        timeout: Long,
        interval: Long? = null,
        onFinish: () -> Unit,
        onInterval: ((millisUntilFinished: Long) -> Unit)? = null
    ): CountDownTimer {
        return object : CountDownTimer(timeout, interval ?: timeout) {
            override fun onTick(millisUntilFinished: Long) {
                onInterval?.invoke(millisUntilFinished)
            }

            override fun onFinish() {
                onFinish.invoke()
            }
        }
    }

    fun ImageView.loadImageUrl(
        url: String?,
        scope: CoroutineScope,
        @DrawableRes placeholder: Int? = null
    ) {
        placeholder?.let { setImageResource(placeholder) }
        if (url.isNullOrEmpty()) return
        val target = this
        scope.launch {
            val bitmap = FetchImageFromURLTask.fetch(url)
            bitmap ?: return@launch
            withContext(Dispatchers.Main) {
                target.setImageBitmap(bitmap)
            }
        }
    }

    fun getTimeDifferenceInMilliSeconds(apiCalledTime: Long): Long {
        return System.currentTimeMillis() - apiCalledTime
    }

    fun String?.normalizeId(): String? =
        this?.takeIf { it.isNotBlank() && !it.equals("null", ignoreCase = true) }
    fun isActivityDestroyedOrFinishing(activity: Activity): Boolean =
        activity.isFinishing || activity.isDestroyed

    fun isSafeOnClickListener(timeToCompare: Long = 1000): Boolean {
        val currentTime = SystemClock.elapsedRealtime()
        if (elapsedLastClickTime > 0 && (currentTime - elapsedLastClickTime) < timeToCompare) {
            return false
        }
        elapsedLastClickTime = currentTime
        return true
    }

    inline fun dispatchOnMain(activity: Activity, crossinline block: () -> Unit) {
        if (isActivityDestroyedOrFinishing(activity)) return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            activity.runOnUiThread {
                block()
            }
        }
    }

    inline fun dispatchOnMain(context: Context, crossinline block: () -> Unit) {
        when (context) {
            is Activity -> dispatchOnMain(context, block)
            else -> {
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    block()
                } else {
                    Handler(Looper.getMainLooper()).post { block() }
                }
            }
        }
    }
}
