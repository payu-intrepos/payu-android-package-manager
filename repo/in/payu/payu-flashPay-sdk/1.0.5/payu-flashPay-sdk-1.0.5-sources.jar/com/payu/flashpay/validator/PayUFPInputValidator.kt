package com.payu.flashpay.validator

import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.model.PayUFPMfaParams
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPUIUtils.normalizeId
import org.json.JSONObject

internal object PayUFPInputValidator {

    data class ValidationError(val code: Int, val message: String)

    fun validateInitSDKParam(payUFPConfig: PayUFPConfig): ValidationError? {
        if (payUFPConfig.txnId.isBlank()) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_TXN_ID))
        }
        if (payUFPConfig.acsTxnId.isBlank()) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_ACS_TXN_ID))
        }
        return null
    }

    fun validateConfigureSDKParam(
        payUFPConfig: PayUFPConfig,
        mfaParams: JSONObject
    ): ValidationError? {
        if (payUFPConfig.merchantName.isBlank()) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_MERCHANT_NAME_FIELD))
        }
        if (mfaParams.length() == 0) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_MFA_PARAMS_ROOT))
        }

        val data = mfaParams.optString(PayUFPConstants.PAYU_FP_KEY_MFA_DATA)
        if (data.isBlank()) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_MFA_DATA))
        }

        val messageType = mfaParams.optString(PayUFPConstants.PAYU_FP_KEY_MFA_MESSAGE_TYPE)
        if (messageType.isBlank()) {
            return invalidParams(fieldNullOrEmpty(PayUFPConstants.PAYU_FP_KEY_MFA_MESSAGE_TYPE))
        }

        return null
    }

    fun validateCheckRegistrationParams(bankId: String?, tdyCardId: String?): ValidationError? {
        val mfa = PayUFPDataManager.mfaParams
        val resolvedBankId = bankId.normalizeId() ?: mfa?.bankId
        if (resolvedBankId.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_BANK_ID_EMPTY)
        }
        val resolvedTdyCardId = tdyCardId.normalizeId() ?: mfa?.tdyCardId
        if (resolvedTdyCardId.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_TDY_CARD_ID_EMPTY)
        }
        return null
    }

    fun validateSdkConfigured(): ValidationError? {
        if (PayUFPDataManager.mfaParams == null || !PayUFPDataManager.isConfigured) {
            return ValidationError(
                PayUFPConstants.PAYU_FP_CODE_SDK_NOT_CONFIGURED,
                PayUFPConstants.PAYU_FP_MSG_SDK_NOT_CONFIGURED
            )
        }
        return null
    }

    fun validateMfaParamsParsed(payUFPMfaParams: PayUFPMfaParams?): ValidationError? {
        if (payUFPMfaParams == null) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_DATA_PARSE_ERROR)
        }
        if (payUFPMfaParams.tdyApiKey.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_KEY_TDY_API_KEY_FIELD)
        }
        return null
    }

    private fun invalidParams(message: String): ValidationError =
        ValidationError(PayUFPConstants.PAYU_FP_CODE_INVALID_PARAMS, message)

    private fun fieldNullOrEmpty(fieldKey: String): String =
        fieldKey + PayUFPConstants.PAYU_FP_MSG_NULL_OR_EMPTY_SUFFIX

    fun validateRegistrationParams(): ValidationError? {
        validateSdkConfigured()?.let { return it }
        if (PayUFPDataManager.mfaParams?.uid.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_TDY_CARD_ID_EMPTY)
        }
        return null
    }

    fun validateProcessTxnParams(): ValidationError? {
        validateSdkConfigured()?.let { return it }

        val mfaParams = PayUFPDataManager.mfaParams
        if (mfaParams?.tdyClientId.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_TDY_CLIENT_ID_EMPTY)
        }
        if (mfaParams?.hashKey.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_INVALID_HASHKEY)
        }
        if (mfaParams?.uid.isNullOrBlank()) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_INVALID_TDY_CARD_UID)
        }
        val payUFPConfig = PayUFPDataManager.payUFPConfig
        val amount = payUFPConfig?.amount?.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            return invalidParams(PayUFPConstants.PAYU_FP_MSG_AMOUNT_INVALID)
        }

        return null
    }
}