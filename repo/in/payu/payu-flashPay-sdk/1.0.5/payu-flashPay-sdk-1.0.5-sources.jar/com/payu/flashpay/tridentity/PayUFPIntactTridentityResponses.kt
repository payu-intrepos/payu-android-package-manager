package com.payu.flashpay.tridentity

import android.content.Context
import com.payu.flashpay.callbacks.PayUFPCheckIntactStatusCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPValidationFailureContext
import com.payu.flashpay.mapper.PayUFPErrorMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.wibmo.tridentity_headless.di.RegistrationStatusCallBack
import org.json.JSONObject

internal object PayUFPIntactTridentityResponses {

    private fun deliverIntactCheckSuccess(
        context: Context,
        coordinatorStartTime: Long,
        merchantCallback: PayUFPCheckIntactStatusCallback,
    ) {
        PayUFPDataManager.setDeviceDeregistered(false)
        val response = PayUFPResponseMapper.mapSuccessResponse(
            ResponseFlow.INTACT_CHECK,
            code = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
            message = PayUFPConstants.PAYU_FP_MSG_PROCEED_WITH_BIOMETRIC
        )
        PayUFPLoggingUtils.logSuccess(
            context,
            PayUFPLoggingConstants.PAYU_FP_INTACT_CHECK,
            PayUFPLoggingConstants.PAYU_FP_EVENT_SUCCESS,
            PayUFPUIUtils.getTimeDifferenceInMilliSeconds(coordinatorStartTime),
            data = response.toString()
        )
        merchantCallback.onIntactResponse(
            PayUFPConstants.PAYU_FP_CODE_SUCCESS,
            response
        )
    }

    fun intactCheckCallback(
        context: Context,
        coordinatorStartTime: Long,
        isDeregisterCall: Boolean,
        merchantCallback: PayUFPCheckIntactStatusCallback,
    ): RegistrationStatusCallBack = object : RegistrationStatusCallBack {

        override fun onSuccess(event: JSONObject) {
            PayUFPUIUtils.dispatchOnMain(context) {
                if (PayUFPTridentityWrapper.isLocalIntactSuccessPayload(event)) {
                    deliverIntactCheckSuccess(context, coordinatorStartTime, merchantCallback)
                    return@dispatchOnMain
                }
                //TODO: it must be check based on code and tridentity must return code
                val status = PayUFPResponseMapper.parseRegistrationStatus(event)
                if (PayUFPResponseMapper.isRegistrationSuccess(status)) {
                    deliverIntactCheckSuccess(context, coordinatorStartTime, merchantCallback)
                } else {
                    val responseFlowContext = PayUFPValidationFailureContext.INTACT_CHECK
                    deliverErrorResponse(
                        activity = context,
                        responseFlow = responseFlowContext.responseFlow,
                        logCategory = responseFlowContext.logCategory,
                        errorCode = PayUFPConstants.PAYU_FP_CODE_CUSTOMER_NOT_REGISTERED,
                        errorMessage = PayUFPConstants.PAYU_FP_MSG_CUSTOMER_NOT_REGISTERED,
                        deliver = merchantCallback::onIntactResponse
                    )
                }
            }
        }

        override fun onError(code: Int, error: String) {
            PayUFPUIUtils.dispatchOnMain(context) {
                val (errorCode, errorMessage) = PayUFPErrorMapper.mapIntactCheckError(
                    code,
                    error
                )
                val responseFlowContext = PayUFPValidationFailureContext.INTACT_CHECK
                deliverErrorResponse(
                    activity = context,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = errorCode,
                    errorMessage = errorMessage,
                    deliver = merchantCallback::onIntactResponse
                )
            }
        }
    }

}
