package com.payu.flashpay.coordinator

import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPRegistrationStatusCallback
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.mapper.PayUFPRequestMapper
import com.payu.flashpay.tridentity.PayUFPTridentityWrapper
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.validator.PayUFPInputValidator
import org.json.JSONObject

internal object PayUFPRegistrationCoordinator {

    fun initiateRegistration(
        activity: AppCompatActivity, maskedMobileNumber: String?, callback: PayUFPRegistrationStatusCallback
    ) {
        val startTime = System.currentTimeMillis()
        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_REGISTRATION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingConstants.PAYU_FP_EVENT_INIT_PARAMS)
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.dataJson(
                    PayUFPLoggingConstants.PAYU_FP_DATA_KEY_MASKED_MOBILE_NUMBER to maskedMobileNumber,
                ))
            }
        )

        PayUFPInputValidator.validateRegistrationParams()?.let { error ->
            val responseFlowContext = PayUFPValidationFailureContext.REGISTRATION
            deliverErrorResponse(
                activity = activity,
                responseFlow = responseFlowContext.responseFlow,
                logCategory = responseFlowContext.logCategory,
                errorCode = error.code,
                errorMessage = error.message,
                deliver = callback::onRegistrationResponse,
            )
            return
        }

        PayUFPLoggingUtils.logMessage(
            activity,
            analyticsJson = JSONObject().apply {
                put(PayUFPLoggingConstants.EVENT_KEY, PayUFPLoggingConstants.PAYU_FP_REGISTRATION)
                put(PayUFPLoggingConstants.EVENT_VALUE, PayUFPLoggingUtils.registrationTypeEventValue())
                put(PayUFPLoggingConstants.PAYU_FP_MESSAGE_DATA, PayUFPLoggingUtils.registrationTypeAnalyticsData())
            }
        )

        val params = PayUFPRequestMapper.mapToRegistrationParams()
        PayUFPTridentityWrapper.startRegistration(
            activity = activity,
            params = params,
            maskedMobileNumber,
            startTime = startTime,
            callback = callback
        )
    }
}
