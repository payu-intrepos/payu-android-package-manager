package com.payu.flashpay.enums

enum class PayUFPCurrency(val value: String) {
    INR("₹");
}