package com.payu.flashpay.storage

import com.payu.flashpay.config.PayUFPConfig
import com.payu.flashpay.model.PayUFPThemeModel
import com.payu.flashpay.model.PayUFPMfaParams

internal object PayUFPDataManager {

    var isConfigured: Boolean = false
        private set

    var deviceDeregistered: Boolean = false
        private set

    var mfaParams: PayUFPMfaParams? = null
        private set

    var themeModel: PayUFPThemeModel? = null
        private set

    var payUFPConfig: PayUFPConfig? = null
        private set

    private var txnId: String? = null

    private var acsTxnId: String? = null
    private var merchantKey: String? = null

    fun getTxnId(): String? = txnId

    fun setTxnId(txnId: String?) {
        this.txnId = txnId?.takeIf { it.isNotBlank() }
    }

    fun getAcsTxnId(): String? = acsTxnId

    fun setAcsTxnId(acsTxnId: String?) {
        this.acsTxnId = acsTxnId?.takeIf { it.isNotBlank() }
    }

    fun getMerchantKey(): String? = merchantKey

    fun setMerchantKey(merchantKey: String?) {
        this.merchantKey = merchantKey?.takeIf { it.isNotBlank() }
    }
    fun saveData(
        payUFPConfig: PayUFPConfig,
        mfaParams: PayUFPMfaParams,
        themeModel: PayUFPThemeModel?
    ) {
        this.payUFPConfig = payUFPConfig
        this.mfaParams = mfaParams
        this.themeModel = themeModel
        txnId = payUFPConfig.txnId
        isConfigured = true
        deviceDeregistered = false
    }

    fun clearData() {
        payUFPConfig = null
        mfaParams = null
        themeModel = null
        isConfigured = false
        deviceDeregistered = false
    }

    fun setDeviceDeregistered(value: Boolean) {
        deviceDeregistered = value
    }
}
