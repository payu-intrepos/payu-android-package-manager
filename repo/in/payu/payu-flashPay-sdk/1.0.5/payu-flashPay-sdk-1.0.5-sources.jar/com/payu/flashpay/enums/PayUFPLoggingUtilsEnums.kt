package com.payu.flashpay.enums

enum class EventSeverity {
    High,
    Low
}

enum class EventType {
    Error,
    Info
}

enum class EventStatus {
    Initiated,
    Success,
    Failed
}
