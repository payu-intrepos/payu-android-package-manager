package com.payu.flashpay.tridentity

import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPProcessTxnCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants.PAYU_FP_EVENT_SUCCESS
import com.payu.flashpay.constants.PayUFPLoggingConstants.PAYU_FP_TRANSACTION
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.notifyProceedWithOtp
import com.payu.flashpay.mapper.PayUFPErrorMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import com.wibmo.tridentity_headless.di.UpdateTransactionCallback
import org.json.JSONObject

internal object PayUFPTransactionTridentityResponses {

    fun transactionCallback(
        activity: AppCompatActivity,
        coordinatorStartTime: Long,
        merchantCallback: PayUFPProcessTxnCallback,
    ): UpdateTransactionCallback = object : UpdateTransactionCallback {
        override fun onSuccess(event: JSONObject) {
            PayUFPUIUtils.dispatchOnMain(activity) {
                PayUFPTransactionUiHelper.dismissTransactionProgressLoader()
                PayUFPTransactionUiHelper.dismissAuthSelectionUi(activity)
                onBiometricTransactionSuccess(
                    activity,
                    merchantCallback,
                    coordinatorStartTime,
                    event
                )
            }
        }

        override fun onError(code: Int, error: String) {
            PayUFPUIUtils.dispatchOnMain(activity) {
                PayUFPTransactionUiHelper.dismissTransactionProgressLoader()
                onBiometricTransactionError(activity, code, error, merchantCallback)
            }
        }

        override fun onTransactionProgress(progressJson: String) {
            try {
                val txnJson = JSONObject(progressJson)
                PayUFPLoggingUtils.logSuccess(
                    activity,
                    PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
                    txnJson.optString("message", ""),
                    PayUFPUIUtils.getTimeDifferenceInMilliSeconds(coordinatorStartTime),
                    data = progressJson,
                )
                merchantCallback.onStatusUpdate(txnJson)
            } catch (e: Exception) {
                PayUFPLoggingUtils.logSuccess(
                    activity,
                    PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
                    e.message ?: "",
                    PayUFPUIUtils.getTimeDifferenceInMilliSeconds(coordinatorStartTime),
                    data = progressJson,
                )
            }
        }
    }


    private fun onBiometricTransactionSuccess(
        activity: AppCompatActivity,
        merchantCallback: PayUFPProcessTxnCallback,
        coordinatorStartTime: Long,
        transactionResponse: JSONObject,
    ) {
        val message = PayUFPResponseMapper.parseTransactionSuccessMessage(transactionResponse)
        val successResponse = PayUFPResponseMapper.mapSuccessResponse(
            ResponseFlow.TRANSACTION,
            code = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
            message = message,
            payload = mapOf(
                PayUFPConstants.PAYU_FP_KEY_TDY_CARD_ID_RESP to PayUFPDataManager.mfaParams?.tdyCardId,
                PayUFPConstants.PAYU_FP_KEY_BANK_ID to PayUFPDataManager.mfaParams?.bankId
            )
        )
        PayUFPLoggingUtils.logSuccess(
            activity = activity,
            PAYU_FP_TRANSACTION,
            PAYU_FP_EVENT_SUCCESS,
            PayUFPUIUtils.getTimeDifferenceInMilliSeconds(coordinatorStartTime),
            data = successResponse.toString(),
        )
        PayUFPDataManager.clearData()
        merchantCallback.onProcessTxnResponse(PayUFPConstants.PAYU_FP_CODE_SUCCESS, successResponse)
    }

    private fun onBiometricTransactionError(
        appCompatActivity: AppCompatActivity,
        code: Int,
        msg: String,
        merchantCallback: PayUFPProcessTxnCallback
    ) {
        Log.d("Anand", "onBiometricTransactionError: $code and $msg")
        when {
            shouldShowDeRegisterUi(code) -> showDeregisterBtSheet(
                appCompatActivity, code, msg, merchantCallback
            )
            else -> {
                notifyProceedWithOtp(
                    appCompatActivity,
                    merchantCallback::onProcessTxnResponse,
                    errorCode = code,
                    msg
                )
            }
        }
    }

    private fun showDeregisterBtSheet(
        appCompatActivity: AppCompatActivity,
        code: Int,
        errorMsg: String,
        merchantCallback: PayUFPProcessTxnCallback,
    ) {
        PayUFPTransactionUiHelper.dismissAuthSelectionUi(appCompatActivity)
        PayUFPDataManager.setDeviceDeregistered(true)
        Log.d("Anand", "showDeregisterBtSheet: $code and $errorMsg")
//        PayUFPTransactionUiHelper.showDeregisterBottomSheet(
//            activity = appCompatActivity,
//            bankLogo = PayUFPDataManager.mfaParams?.bankLogo,
//            errorMsg = errorMsg
//        ) {

            notifyProceedWithOtp(
                appCompatActivity,
                merchantCallback::onProcessTxnResponse,
                errorCode = code,
                errorMsg
            )
       // }
    }

    private fun shouldShowDeRegisterUi(code: Int): Boolean =
        code in PayUFPConstants.PAYU_FP_AUTO_DEREGISTER_CODES

}
