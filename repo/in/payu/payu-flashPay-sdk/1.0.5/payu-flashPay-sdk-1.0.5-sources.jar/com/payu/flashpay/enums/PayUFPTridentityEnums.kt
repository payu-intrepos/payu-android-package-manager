package com.payu.flashpay.enums


enum class AuthType {
    BIOMETRIC,
    OTP,
    USER_CANCELLED
}
