package com.payu.flashpay.view

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.payu.flashpay.R

internal abstract class FixedRoundedCornerBottomSheet : BottomSheetDialogFragment() {

    override fun getTheme(): Int = R.style.PayU_FP_BaseBottomSheetDialog

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme).apply {
            setCanceledOnTouchOutside(false)
            behavior.isHideable = false
        }

    abstract fun getLayoutId(): Int

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(getLayoutId(), container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        isCancelable = false
    }

    override fun onStart() {
        super.onStart()
        applyRoundedCorners()
    }

    /**
     * Sets the rounded-corner background directly on the BottomSheet container view
     * (design_bottom_sheet) and enables clipToOutline so that child views — including
     * their own backgrounds — are clipped to the rounded shape. This overrides any
     * background that BottomSheetBehavior may have applied after inflation.
     */
    private fun applyRoundedCorners() {
        val bottomSheet = (dialog as? BottomSheetDialog)
            ?.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
            ?: return
        bottomSheet.setBackgroundResource(R.drawable.payu_fp_bottom_sheet_rounded_corner)
        bottomSheet.clipToOutline = true
    }
}