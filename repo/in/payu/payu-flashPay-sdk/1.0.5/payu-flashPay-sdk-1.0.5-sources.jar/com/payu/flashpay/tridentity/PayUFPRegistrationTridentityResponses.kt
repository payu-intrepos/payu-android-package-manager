package com.payu.flashpay.tridentity

import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPRegistrationStatusCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPValidationFailureContext
import com.payu.flashpay.mapper.PayUFPErrorMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.wibmo.tridentity_headless.di.RegistrationStatusCallBack
import org.json.JSONObject

internal object PayUFPRegistrationTridentityResponses {

    fun registrationCallback(
        activity: AppCompatActivity,
        startTime: Long,
        merchantCallback: PayUFPRegistrationStatusCallback,
    ): RegistrationStatusCallBack = object : RegistrationStatusCallBack {
        override fun onSuccess(event: JSONObject) {
            PayUFPUIUtils.dispatchOnMain(activity) {
                val status = PayUFPResponseMapper.parseRegistrationStatus(event)
                if (PayUFPResponseMapper.isRegistrationSuccess(status)) {
                    PayUFPDataManager.setDeviceDeregistered(false)
                    val customerStatus = status ?: PayUFPConstants.PAYU_FP_REG_STATUS_SUCCESS
                    val response = PayUFPResponseMapper.mapSuccessResponse(
                        ResponseFlow.REGISTRATION,
                        code = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                        message = PayUFPConstants.PAYU_FP_MSG_CUSTOMER_STATUS_RETRIEVED,
                        payload = mapOf(
                            PayUFPConstants.PAYU_FP_KEY_CUSTOMER_STATUS to customerStatus,
                            PayUFPConstants.PAYU_FP_KEY_TDY_CARD_ID_RESP to PayUFPDataManager.mfaParams?.tdyCardId,
                            PayUFPConstants.PAYU_FP_KEY_BANK_ID to PayUFPDataManager.mfaParams?.bankId
                        )
                    )
                    PayUFPLoggingUtils.logSuccess(
                        activity,
                        PayUFPLoggingConstants.PAYU_FP_REGISTRATION,
                        PayUFPLoggingConstants.PAYU_FP_EVENT_SUCCESS,
                        PayUFPUIUtils.getTimeDifferenceInMilliSeconds(startTime),
                        data = response.toString(),
                    )
                    merchantCallback.onRegistrationResponse(
                        PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                        response
                    )
                    PayUFPDataManager.clearData()
                } else {
                    val responseFlowContext = PayUFPValidationFailureContext.REGISTRATION
                    deliverErrorResponse(
                        activity = activity,
                        responseFlow = responseFlowContext.responseFlow,
                        logCategory = responseFlowContext.logCategory,
                        errorCode = PayUFPConstants.PAYU_FP_CODE_REG_GENERIC_ERROR,
                        errorMessage = PayUFPConstants.PAYU_FP_MSG_REG_GENERIC_ERROR,
                        deliver = merchantCallback::onRegistrationResponse
                    )
                }
            }
        }

        override fun onError(code: Int, error: String) {
            PayUFPUIUtils.dispatchOnMain(activity) {
                val (errorCode, errorMessage) = PayUFPErrorMapper.mapRegistrationError(code, error)
                val responseFlowContext = PayUFPValidationFailureContext.REGISTRATION
                deliverErrorResponse(
                    activity = activity,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = errorCode,
                    errorMessage = errorMessage,
                    deliver = merchantCallback::onRegistrationResponse
                )
            }
        }

        override fun onRegistrationProgress(progressJson: String) {
            try {
                val registrationJson = JSONObject(progressJson)
                PayUFPLoggingUtils.logSuccess(
                    activity,
                    PayUFPLoggingConstants.PAYU_FP_REGISTRATION,
                    registrationJson.optString("message", ""),
                    PayUFPUIUtils.getTimeDifferenceInMilliSeconds(startTime),
                    data = progressJson,
                )
                merchantCallback.onStatusUpdate(registrationJson)
            } catch (e: Exception) {
                PayUFPLoggingUtils.logSuccess(
                    activity,
                    PayUFPLoggingConstants.PAYU_FP_REGISTRATION,
                    e.message ?: "",
                    PayUFPUIUtils.getTimeDifferenceInMilliSeconds(startTime),
                    data = progressJson,
                )
            }
        }
    }

}
