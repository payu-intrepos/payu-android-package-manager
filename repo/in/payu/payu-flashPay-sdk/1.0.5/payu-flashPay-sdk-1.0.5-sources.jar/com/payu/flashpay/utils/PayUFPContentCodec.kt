package com.payu.flashpay.utils

import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.constants.PayUFPUiConstants
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

internal object PayUFPContentCodec {

    private val sharedMaterial: String
        get() = PayUFHandler.deriveValue

    private fun nonceFromToken(token: String): ByteArray {
        require(token.length >= PayUFPConstants.MIN_TOKEN_LENGTH) {
            PayUFPConstants.PAYU_FP_TOKEN_LENGTH_ERROR
        }
        val head = token.substring(0, 6)
        val tail = token.substring(token.length - 7, token.length - 1)
        val combined = head + tail
        return combined.toByteArray(Charsets.UTF_8)
    }

    private fun normalizeMaterialToFixedWidth(token: String): ByteArray {
        return token.toByteArray(Charsets.UTF_8).copyOf(PayUFPConstants.MATERIAL_BYTE_LENGTH)
    }

    fun getDataValueFromMFA(data: String): String {
        require(PayUFHandler.deriveValue.isNotEmpty()) { PayUFPConstants.PAYU_FP_MFA_CONFIG_ERROR }
        val combinedBytes = bytesFromHex(data)
        val materialBytes = normalizeMaterialToFixedWidth(sharedMaterial)
        val nonce = nonceFromToken(sharedMaterial)

        val engine =
            Cipher.getInstance(PayUFPUiConstants.AUTH_DERIVE + PayUFPLoggingConstants.PAYU_FP_VALUE + PayUFPConstants.PAYU_FP_MSG)
        val materialSpec = SecretKeySpec(materialBytes, PayUFPConstants.PAYU_FP_AES)
        val frameSpec = GCMParameterSpec(PayUFPConstants.FRAME_SUFFIX_BITS, nonce)

        engine.init(Cipher.DECRYPT_MODE, materialSpec, frameSpec)
        val output = engine.doFinal(combinedBytes)

        return String(output, Charsets.UTF_8)
    }

    fun toByteArrayValue(value: String): ByteArray? {
        return bytesFromHex(value)
    }

    internal fun bytesFromHex(string: String): ByteArray? {
        val hex = string.trim()
        if (hex.isEmpty() || hex.length % 2 != 0) return null
        val out = ByteArray(hex.length / 2)
        var i = 0
        while (i < hex.length) {
            val chunk = hex.substring(i, i + 2)
            val value = chunk.toIntOrNull(16) ?: return null
            out[i / 2] = value.toByte()
            i += 2
        }
        return out
    }


}
