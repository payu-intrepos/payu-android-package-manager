package com.payu.flashpay.tridentity

import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.callbacks.PayUFPDeregisterCallback
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.coordinator.PayUFPCoordinatorErrorHandler.deliverErrorResponse
import com.payu.flashpay.coordinator.PayUFPValidationFailureContext
import com.payu.flashpay.mapper.PayUFPErrorMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.storage.PayUFPDataManager
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.utils.PayUFPUIUtils
import com.wibmo.tridentity_headless.di.DeregisterCallBack
import org.json.JSONObject

internal object PayUFPDeRegistrationTridentityResponses {

    fun deregistrationCallback(
        activity: AppCompatActivity,
        coordinatorStartTime: Long,
        merchantCallback: PayUFPDeregisterCallback,
    ): DeregisterCallBack = object : DeregisterCallBack {
        override fun onSuccess(event: JSONObject) {
            PayUFPUIUtils.dispatchOnMain(activity) {
                val code = PayUFPResponseMapper.parseDeRegisterCode(event)
                if (PayUFPResponseMapper.isDeRegisterSuccess(code)) {
                    PayUFPDataManager.setDeviceDeregistered(true)
                    val message = PayUFPResponseMapper.parseDeRegisterSuccessMessage(event)
                    val response = PayUFPResponseMapper.mapSuccessResponse(
                        ResponseFlow.DEREGISTRATION,
                        code = PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                        message = message,
                        payload = mapOf(
                            PayUFPConstants.PAYU_FP_KEY_TDY_CARD_ID_RESP to PayUFPDataManager.mfaParams?.tdyCardId,
                            PayUFPConstants.PAYU_FP_KEY_BANK_ID to PayUFPDataManager.mfaParams?.bankId
                        )
                    )
                    PayUFPLoggingUtils.logSuccess(
                        activity,
                        PayUFPLoggingConstants.PAYU_FP_DEREGISTRATION,
                        PayUFPLoggingConstants.PAYU_FP_EVENT_SUCCESS,
                        PayUFPUIUtils.getTimeDifferenceInMilliSeconds(coordinatorStartTime),
                        data = response.toString(),
                    )
                    PayUFPDataManager.clearData()
                    merchantCallback.onDeRegisterResponse(
                        PayUFPConstants.PAYU_FP_CODE_SUCCESS,
                        response
                    )
                } else {
                    val responseFlowContext = PayUFPValidationFailureContext.DEREGISTRATION
                    deliverErrorResponse(
                        activity = activity,
                        responseFlow = responseFlowContext.responseFlow,
                        logCategory = responseFlowContext.logCategory,
                        errorCode = PayUFPConstants.PAYU_FP_CODE_REG_GENERIC_ERROR,
                        errorMessage = PayUFPConstants.PAYU_FP_MSG_REG_GENERIC_ERROR,
                        deliver = merchantCallback::onDeRegisterResponse
                    )
                }
            }
        }

        override fun onError(code: Int, error: String) {
            PayUFPUIUtils.dispatchOnMain(activity) {
//                val (errorCode, errorMessage) = PayUFPErrorMapper.mapDeregistrationError(code, error)
                val responseFlowContext = PayUFPValidationFailureContext.DEREGISTRATION
                deliverErrorResponse(
                    activity = activity,
                    responseFlow = responseFlowContext.responseFlow,
                    logCategory = responseFlowContext.logCategory,
                    errorCode = code,
                    errorMessage = error,
                    deliver = merchantCallback::onDeRegisterResponse
                )
            }
        }
    }
}
