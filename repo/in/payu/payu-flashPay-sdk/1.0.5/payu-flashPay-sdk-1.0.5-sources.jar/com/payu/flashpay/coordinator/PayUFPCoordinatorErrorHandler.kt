package com.payu.flashpay.coordinator

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.payu.flashpay.constants.PayUFPConstants
import com.payu.flashpay.constants.PayUFPLoggingConstants
import com.payu.flashpay.mapper.PayUFPResponseMapper
import com.payu.flashpay.mapper.PayUFPResponseMapper.ResponseFlow
import com.payu.flashpay.utils.PayUFPLoggingUtils
import com.payu.flashpay.view.PayUFPTransactionUiHelper
import org.json.JSONObject


internal enum class PayUFPValidationFailureContext(
    val responseFlow: ResponseFlow,
    val logCategory: String,
) {
    CONFIG(
        ResponseFlow.CONFIG,
        PayUFPLoggingConstants.PAYU_FP_CONFIG,
    ),
    INTACT_CHECK(
        ResponseFlow.INTACT_CHECK,
        PayUFPLoggingConstants.PAYU_FP_INTACT_CHECK,
    ),
    REGISTRATION(
        ResponseFlow.REGISTRATION,
        PayUFPLoggingConstants.PAYU_FP_REGISTRATION,
    ),
    TRANSACTION(
        ResponseFlow.TRANSACTION,
        PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
    ),
    DEREGISTRATION(
        ResponseFlow.DEREGISTRATION,
        PayUFPLoggingConstants.PAYU_FP_DEREGISTRATION,
    ),
}

internal object PayUFPCoordinatorErrorHandler {

    fun deliverErrorResponse(
        activity: Context?,
        responseFlow: ResponseFlow,
        logCategory: String,
        errorCode: Int,
        errorMessage: String,
        elapsedSinceStartMs: Long = 0L,
        deliver: (code: Int, response: JSONObject) -> Unit,
        eventValue: String = PayUFPLoggingConstants.PAYU_FP_EVENT_FAILED,
    ) {
        val errorResponse = PayUFPResponseMapper.mapErrorResponse(
            responseFlow,
            errorCode,
            errorMessage,
        )
        activity?.let { act ->
            PayUFPLoggingUtils.logError(
                act,
                logCategory,
                eventValue,
                errorCode,
                elapsedSinceStartMs,
                data = errorResponse.toString(),
            )
        }
        deliver(errorCode, errorResponse)
    }

    /**
     * OTP fallback path: success-shaped response, logged as otp_fallback_<code>, then callback.
     */
    fun deliverTransactionOtpFallback(
        context: Context,
        deliver: (code: Int, response: JSONObject) -> Unit,
        errorCode: Int = PayUFPConstants.PAYU_FP_CODE_BIOMETRIC_FAILED_OR_OTP,
        errorMessage: String? = PayUFPConstants.PAYU_FP_MSG_USER_OPTED_FOR_OTP,
        eventValue: String = PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK,
    ) {
        val response = PayUFPResponseMapper.mapSuccessResponse(
            ResponseFlow.PROCEED_WITH_OTP,
            code = errorCode,
            message = errorMessage ?: PayUFPConstants.PAYU_FP_MSG_USER_OPTED_FOR_OTP
        )
        PayUFPLoggingUtils.logError(
            context,
            PayUFPLoggingConstants.PAYU_FP_TRANSACTION,
            eventValue,
            errorCode,
            data = response.toString(),
        )
        deliver(errorCode, response)
    }

    fun notifyProceedWithOtp(
        activity: AppCompatActivity,
        deliver: (code: Int, response: JSONObject) -> Unit,
        errorCode: Int = PayUFPConstants.PAYU_FP_CODE_BIOMETRIC_FAILED_OR_OTP,
        eventValue: String = PayUFPLoggingConstants.PAYU_FP_TXN_OTP_FALLBACK,
    ) {
        PayUFPTransactionUiHelper.dismissAuthSelectionUi(activity)
        deliverTransactionOtpFallback(activity, deliver, errorCode, errorMessage = eventValue)
    }
}
