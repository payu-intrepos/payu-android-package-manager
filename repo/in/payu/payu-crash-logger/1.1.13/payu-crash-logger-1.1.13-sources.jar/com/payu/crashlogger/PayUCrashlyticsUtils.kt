package com.payu.crashlogger

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import com.payu.crashlogger.request.*
import org.json.JSONArray
import org.json.JSONObject
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.Exception


object PayUCrashlyticsUtils {
    private const val DEFAULT_LOG_TAG = "PAYU"
    private const val VERBOSE = Log.VERBOSE
    fun getOs(): Os {
        val androidVersion = Build.VERSION.SDK_INT.toString()
        val kernelVersion = System.getProperty("os.version") ?: ""
        val buildNumber = Build.FINGERPRINT
        return Os(buildNumber, kernelVersion, "Android", androidVersion)
    }

    fun getApp(context: Context): App {
        var versionNumber = 0
        var versionName = "0.0"
        try {
            val pInfo =
                context.packageManager.getPackageInfo(context.packageName, 0)
            versionName = pInfo.versionName
            versionNumber = pInfo.versionCode
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return App(versionNumber.toString(), context.packageName, versionName)
    }

    fun getDevice(context: Context): Device {
        val listOfArch = ArrayList<String>()
        val arch = System.getProperty("os.arch")
        if (arch != null) {
            listOfArch.add(arch)
        }
        val device = Device()

        device.bootTime =
            (System.currentTimeMillis() - SystemClock.elapsedRealtime()).toString()
        device.brand = Build.BRAND
        device.charging = isPlugged(context)
        device.connectionType = connectionType(context)

        val memInfo = getMemInfo(context)
        if (memInfo != null) {
            // in bytes
            device.memorySize = getMemorySize(memInfo)
            device.freeMemory = memInfo.availMem
            device.lowMemory = memInfo.lowMemory
            // there are runtime.totalMemory() and runtime.freeMemory(), but I kept the same for
            // compatibility
        }
        device.id = getAndroidId(context)
        device.language = Locale.getDefault().displayLanguage
        device.manufacturer = Build.MANUFACTURER
        device.model = Build.MODEL
        device.modelId = Build.ID
        device.name = getDeviceName(context)
        return device
    }

    fun getSdk(): Sdk {

        val sdk = Sdk()
        try {
            sdk.version = BuildConfig.VERSION_NAME
            if (null != BuildConfig.LIBRARY_PACKAGE_NAME)
                sdk.name = BuildConfig.LIBRARY_PACKAGE_NAME
            else
                sdk.name = javaClass.`package`?.name
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return sdk
    }

    private fun getDeviceName(context: Context): String? {
        return Settings.Global.getString(context.contentResolver, "device_name")
    }

    private fun isPlugged(context: Context): Boolean {
        var isPlugged: Boolean
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
        isPlugged =
            plugged == BatteryManager.BATTERY_PLUGGED_AC || plugged == BatteryManager.BATTERY_PLUGGED_USB
        isPlugged = isPlugged || plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS

        return isPlugged
    }

    private fun connectionType(context: Context): String {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && connectivityManager.activeNetwork != null) {
            val capabilities =
                connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
            if (capabilities != null) {
                when {
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                        return "mobile"
                    }

                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                        return "wifi"
                    }

                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                        return "ethernet"
                    }

                    else -> {
                        return "no internet"
                    }
                }
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    when (type) {
                        ConnectivityManager.TYPE_WIFI -> "wifi"
                        ConnectivityManager.TYPE_MOBILE -> "mobile"
                        ConnectivityManager.TYPE_ETHERNET -> "ethernet"
                        else -> "no internet"
                    }

                }
            }

        }
        return ""
    }


    @SuppressLint("SimpleDateFormat")
    fun getCurrentTimeStamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
        val timestamp = Timestamp(System.currentTimeMillis())
        return sdf.format(timestamp)
    }

    fun getCurrentThreads(threads: MutableMap<Thread, Array<StackTraceElement>>): List<ValueX>? {
        var result: MutableList<ValueX>? = null
        val currentThread = Thread.currentThread()
        if (threads.isNotEmpty()) {
            result = ArrayList()

            // https://issuetracker.google.com/issues/64122757
            if (!threads.containsKey(currentThread)) {
                threads[currentThread] = currentThread.stackTrace
            }

            for ((key, value) in threads) {
                result.add(getSentryThread(currentThread, value, key))
            }
        }

        return result
    }

    private fun getSentryThread(
        currentThread: Thread,
        stackFramesElements: Array<StackTraceElement>,
        thread: Thread
    ): ValueX {
        val sentryThread = ValueX()

        sentryThread.name = thread.name
        sentryThread.priority = thread.priority
        sentryThread.id = thread.id
        sentryThread.daemon = thread.isDaemon
        sentryThread.state = thread.state.name
        sentryThread.crashed = thread === currentThread
        sentryThread.current = (Looper.getMainLooper().thread.id == thread.id)

//        if ( frames != null && frames!!.size > 0) {
//            sentryThread.stacktrace = SentryStackTrace(frames)
//        }
        return sentryThread
    }


    fun getAndroidId(context: Context?): String? {
        // Android 29 has changed and -> Avoid using hardware identifiers, find another way in the
        // future
        val androidId: String? =
            Settings.Secure.getString(context?.contentResolver, Settings.Secure.ANDROID_ID)
        //    https://android-developers.googleblog.com/2011/03/identifying-app-installations.html
        if (androidId.isNullOrEmpty()
            || androidId.toLowerCase(Locale.ROOT).contentEquals("9774d56d682e549c")
        ) {

            return null
        }

        return androidId
    }

    private fun getMemorySize(memInfo: ActivityManager.MemoryInfo): Long {
        return memInfo.totalMem
        // using Runtime as a fallback
        // JVM in bytes too
    }

    private fun getMemInfo(context: Context): ActivityManager.MemoryInfo? {
        try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager?
            val memInfo = ActivityManager.MemoryInfo()
            if (actManager != null) {
                actManager.getMemoryInfo(memInfo)
                return memInfo
            }
            return null
        } catch (e: Throwable) {
            return null
        }

    }

    private fun getAbi(): String {
        return Build.CPU_ABI
    }

    private fun getAbi2(): String {
        return Build.CPU_ABI2
    }


    fun getRelease(context: Context): String? {
        val packageInfo = context.packageManager?.getPackageInfo(context.packageName, 0)
        if (packageInfo != null) {
            val versionCode = getVersionCode(packageInfo)
            return packageInfo.packageName + "@" + packageInfo.versionName + "+" + versionCode

        }
        return null
    }

    private fun getVersionCode(packageInfo: PackageInfo): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode.toString()
        } else getVersionCodeDep(packageInfo)
    }

    private fun getVersionCodeDep(packageInfo: PackageInfo): String {
        return packageInfo.versionCode.toString()
    }


    fun createRequest(request: PayUCrashReportRequest?): JSONObject {
        val sentryRequest = JSONObject()
        val userJsonObject = JSONObject()
        val contextJsonObject = JSONObject()
        val appJsonObject = JSONObject()
        val osJsonObject = JSONObject()
        val deviceJsonObject = JSONObject()
        val threadJsonObject = JSONObject()
        val expectionJsonObject = JSONObject()
        val sdkJsonObject = JSONObject()
        val debugMetaRequest = JSONObject()

        val device = request?.contexts?.device
        val os = request?.contexts?.os
        deviceJsonObject.put("battery_level", device?.batteryLevel)
        deviceJsonObject.put("boot_time", device?.bootTime)
        deviceJsonObject.put("brand", device?.brand)
        deviceJsonObject.put("charging", device?.charging)
        deviceJsonObject.put("connection_type", device?.connectionType)
        deviceJsonObject.put("free_memory", device?.freeMemory)
        deviceJsonObject.put("id", device?.id)
        deviceJsonObject.put("language", device?.language)
        deviceJsonObject.put("low_memory", device?.lowMemory)
        deviceJsonObject.put("manufacturer", device?.manufacturer)
        deviceJsonObject.put("memory_size", device?.memorySize)
        deviceJsonObject.put("model", device?.model)
        deviceJsonObject.put("model_id", device?.modelId)
        deviceJsonObject.put("name", device?.name)
        appJsonObject.put("app_build", request?.contexts?.app?.app_build)
        appJsonObject.put("app_identifier", request?.contexts?.app?.app_identifier)
        appJsonObject.put("app_version", request?.contexts?.app?.app_version)


        osJsonObject.put("build", os?.build)
        osJsonObject.put("kernel_version", os?.kernel_version)
        osJsonObject.put("name", os?.name)
        osJsonObject.put("version", os?.version)

        contextJsonObject.put("app", appJsonObject)
        contextJsonObject.put("device", deviceJsonObject)
        contextJsonObject.put("os", osJsonObject)

        userJsonObject.put("id", request?.user?.id)
        sentryRequest.put("event_id", request?.event_id)
//        sentryRequest.put("event_id", "ddc65f39b7357635763abb4f5695942218dcaf17c2")
        sentryRequest.put("timestamp", request?.timestamp)
        sentryRequest.put("release", request?.release)
        sentryRequest.put("level", request?.level)
        sentryRequest.put("platform", request?.platform)

        sdkJsonObject.put("version", request?.sdk?.version)
        sdkJsonObject.put("name", request?.sdk?.name)

        sentryRequest.put("sdk", sdkJsonObject)
        sentryRequest.put("user", userJsonObject)



        sentryRequest.put("contexts", contextJsonObject)
        val tagsJson = (request?.tags?.tagsMap as? Map<String, String>)?.let { JSONObject(it) }
        //add custom tags
        tagsJson?.put("source.sdk", request.sourceSdk)
        tagsJson?.put("source.sdk.version", request.release)
        tagsJson?.put("merchant.package", request.contexts?.app?.app_identifier)
        tagsJson?.put(
            "merchant.package.version",
            getMerchantAppVersion(
                request.contexts?.app?.app_identifier,
                request.contexts?.app?.app_version
            )
        )
        sentryRequest.put("tags", tagsJson)

        val listOfThreadValues = request?.threads?.values ?: arrayListOf()
        val jsonArrayValuesThreads = JSONArray()
        for (i in listOfThreadValues.indices) {
            try {
                val threadValueObject = JSONObject()
                threadValueObject.put("crashed", listOfThreadValues[i].crashed)
                threadValueObject.put("current", listOfThreadValues[i].current)
                threadValueObject.put("daemon", listOfThreadValues[i].daemon)
                threadValueObject.put("id", listOfThreadValues[i].id)
                threadValueObject.put("name", listOfThreadValues[i].name)
                threadValueObject.put("priority", listOfThreadValues[i].priority)
                threadValueObject.put("state", listOfThreadValues[i].state)
                jsonArrayValuesThreads.put(threadValueObject)
            } catch (e: Exception) {
                Log.d(DEFAULT_LOG_TAG, "Exception" + e.message)
            }

        }
        threadJsonObject.put("values", jsonArrayValuesThreads)
        sentryRequest.put("threads", threadJsonObject)

        val listOfExceptionValues = request?.exception?.values ?: arrayListOf()
        val jsonArrayExceptionValue = JSONArray()
        for (i in listOfExceptionValues.indices) {
            try {
                val exceptionValueObject = JSONObject()
                exceptionValueObject.put("module", listOfExceptionValues[i].module)
                exceptionValueObject.put("value", listOfExceptionValues[i].value)
                exceptionValueObject.put("thread_id", listOfExceptionValues[i].threadId)
                exceptionValueObject.put("type", listOfExceptionValues[i].type)
                val stackTraceJsonObject = JSONObject()
                val frameJSONArray = JSONArray()
                val framesList =
                    listOfExceptionValues[i].stacktrace?.frames?.asReversed() ?: arrayListOf()
                for (j in framesList.indices) {
                    val frameJSONObject = JSONObject()
                    frameJSONObject.put("native", framesList[j].native)
                    frameJSONObject.put("filename", framesList[j].filename)
                    frameJSONObject.put("function", framesList[j].function)
                    frameJSONObject.put("in_app", framesList[j].inApp)
                    frameJSONObject.put("lineno", framesList[j].lineno)
                    frameJSONObject.put("module", framesList[j].module)
                    frameJSONArray.put(frameJSONObject)
                }
                stackTraceJsonObject.put("frames", frameJSONArray)
                exceptionValueObject.put("stacktrace", stackTraceJsonObject)
                jsonArrayExceptionValue.put(exceptionValueObject)
            } catch (e: Exception) {
                Log.d(DEFAULT_LOG_TAG, "Exception" + e.message)
            }
        }

        expectionJsonObject.put("values", jsonArrayExceptionValue)
        sentryRequest.put("exception", expectionJsonObject)
        val debugMetaImageArray = JSONArray()
        val debugMetaTypeObj = JSONObject()
        debugMetaTypeObj.put("type", "proguard")
        debugMetaTypeObj.put("uuid", request?.mappingFileID)
        debugMetaImageArray.put(debugMetaTypeObj)
        debugMetaRequest.put("images", debugMetaImageArray)
        sentryRequest.put("debug_meta", debugMetaRequest)
//        log("Json request Exc " + expectionJsonObject)
//        PayUCrashlyticsUtils.log("Json request " + sentryRequest)
        return sentryRequest
    }

    fun getSentryUrl(context: Context): String? {
        var applicationInfo: ApplicationInfo? = null
        try {
            applicationInfo = context.packageManager.getApplicationInfo(
                context.packageName,
                PackageManager.GET_META_DATA
            )
            val bundle = applicationInfo.metaData
            return if (null != bundle)
                bundle.getString(
                    context.getString(R.string.payu_sentry_url),
                    "https://sentry.payu.in/api/32/store/"
                )
            else
                "https://sentry.payu.in/api/32/store/"
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        return ""
    }

    private fun getMerchantAppVersion(app_identifier: String?, app_version: String?): String {
        return "$app_identifier@$app_version"
    }

    fun getSentryKey(context: Context): String? {
        var applicationInfo: ApplicationInfo? = null
        try {
            applicationInfo = context.packageManager.getApplicationInfo(
                context.packageName,
                PackageManager.GET_META_DATA
            )
            val bundle = applicationInfo.metaData
            return if (null != bundle)
                bundle.getString(
                    context.getString(R.string.payu_sentry_key),
                    "b5df90d6741a4136914f1f83a996409a"
                )
            else "b5df90d6741a4136914f1f83a996409a"

        } catch (e: PackageManager.NameNotFoundException) {
            Log.v("Exception", e.message.toString())
        }
        return ""
    }

    fun log(message: String?) {
        if (message.isNullOrEmpty())
            return
        // Split by line, then ensure each line can fit into Log's maximum length.
        var i = 0
        val length = message.length
        while (i < length) {
            var newline = message.indexOf('\n', i)
            newline = if (newline != -1) newline else length
            do {
                val end = Math.min(newline, i + 4000)
                if (isLogEnabled(VERBOSE)) {

                    Log.v(DEFAULT_LOG_TAG, message.substring(i, end))
                }
                i = end
            } while (i < newline)
            i++
        }
    }

    private fun getStackFrames(elements: Array<StackTraceElement?>?): List<Frame>? {
        var sentryStackFrames: MutableList<Frame>? = null
        if (!elements.isNullOrEmpty()) {
            sentryStackFrames = ArrayList()
            for (item in elements) {
                if (item != null) {
                    val sentryStackFrame = Frame()
                    // https://docs.sentry.io/development/sdk-dev/features/#in-app-frames
                    sentryStackFrame.inApp = true
                    sentryStackFrame.module = item.className

                    sentryStackFrame.function = item.methodName
                    sentryStackFrame.filename = item.className
                    // Protocol doesn't accept negative line numbers.
                    // The runtime seem to use -2 as a way to signal a native method
                    if (item.lineNumber >= 0) {
                        sentryStackFrame.lineno = item.lineNumber
                    }
                    sentryStackFrame.native = item.isNativeMethod == true
                    sentryStackFrames.add(sentryStackFrame)
                }
            }
//            sentryStackFrames.reverse()
        }
        return sentryStackFrames
    }

    fun getPackageNameOfStrClass(className: String?): String {
        val listOfModule = className?.split(".")
        var packageName = ""
        if (null != listOfModule && listOfModule.size > 2) {
            for (i in 0..2) {
                packageName += listOfModule[i]
                if (i != 2) packageName += "."
            }
        }
        return packageName
    }

    fun getExceptionValue(
        exceptions: Deque<Value>?
    ): List<Value>? {
        return if (null != exceptions)
            ArrayList(exceptions)
        else
            null
    }

    fun extractExceptionQueue(throwable: Throwable?): Deque<Value> {
        val exceptions: Deque<Value> = ArrayDeque()
        val circularityDetector: MutableSet<Throwable> =
            HashSet()

        var thread: Thread? = null

        var currentThrowable: Throwable? = throwable

        // Stack the exceptions to send them in the reverse order
        while (currentThrowable != null && circularityDetector.add(currentThrowable)) {
            if (currentThrowable is ExceptionMechanismException) {
                // this is for ANR I believe
                val exceptionMechanismThrowable =
                    currentThrowable
//                exceptionMechanism = exceptionMechanismThrowable.exceptionMechanism
                currentThrowable = exceptionMechanismThrowable.throwable
                thread = exceptionMechanismThrowable.thread
            } else {
//                exceptionMechanism = null
                thread = Thread.currentThread()
            }
            val exception: Value =
                getSentryException(currentThrowable, thread)
            exceptions.add(exception)
            currentThrowable = currentThrowable?.cause
        }
        return exceptions
    }


    private fun getSentryException(
        throwable: Throwable?,
        thread: Thread?
    ): Value {
        val exceptionPackage = throwable?.javaClass?.getPackage()
        val fullClassName = throwable?.javaClass?.name
        val exception = Value()

        val exceptionMessage = throwable?.message
        val exceptionClassName = if (exceptionPackage != null) fullClassName?.replace(
            exceptionPackage.name + ".",
            ""
        ) else fullClassName
        val exceptionPackageName =
            exceptionPackage?.name
        val sentryStackTrace = Stacktrace()
        sentryStackTrace.frames = getStackFrames(throwable?.stackTrace)
        if (thread != null) exception.threadId = thread.id
        exception.stacktrace = sentryStackTrace
        exception.type = exceptionClassName
//        exception.mechanism = exceptionMechanism
        if (null != exceptionPackageName)
            exception.module = exceptionPackageName
        if (null != exceptionMessage)
            exception.value = exceptionMessage
        return exception
    }

    fun getSdkVersion(packageName: String): String {
        try {
            val upiWrapperClassLoader: ClassLoader? =
                CrashManager::class.java.classLoader
            val upiWrapperClass =
                upiWrapperClassLoader?.loadClass(packageName)
            log(
                "Version Name" + upiWrapperClass?.getField("VERSION_NAME")?.get(upiWrapperClass)
                    .toString()
            )
            return upiWrapperClass?.getField("VERSION_NAME")?.get(upiWrapperClass).toString()
        } catch (e: java.lang.Exception) {
            log(
                javaClass.canonicalName
                    .toString() + "Exception " + e.message
            )
            return ""
        }
    }


    private fun isLogEnabled(level: Int): Boolean {
        return Log.isLoggable(DEFAULT_LOG_TAG, level)
    }

    fun getMappingFileUUID(packageName: String?, context: Context?): String? {
        try {
            var applicationInfo: ApplicationInfo?
            try {
                applicationInfo = context?.packageManager?.getApplicationInfo(
                    context.packageName,
                    PackageManager.GET_META_DATA
                )
                val bundle = applicationInfo?.metaData
                return bundle?.getString("io.sentry.uuid.${packageName}", "")

            } catch (e: PackageManager.NameNotFoundException) {
                log(e.message.toString())
            }
            return ""
        } catch (e: java.lang.Exception) {
            log(
                javaClass.canonicalName
                    .toString() + "Exception " + e.message
            )
            return ""
        }
    }

    internal fun getSupportedPackageName(context: Context?): ArrayList<String> {
        val defaultPackageNamesPrefix = "com.payu."
        val packageList: ArrayList<String> = ArrayList()
        packageList.add(defaultPackageNamesPrefix)
        try {
            val applicationInfo: ApplicationInfo? = context?.packageManager?.getApplicationInfo(
                context.packageName,
                PackageManager.GET_META_DATA
            )
            val bundle = applicationInfo?.metaData
            if (null != bundle) {
                val externalPackages = bundle.getString(
                    context.getString(R.string.payu_sentry_package_name), "")
                if (externalPackages.isNullOrBlank().not()) {
                    val externalPackageList = externalPackages!!.split("|")
                    for (externalPackageName in externalPackageList) {
                        packageList.add(externalPackageName)
                    }
                }
            }
        } catch (e: PackageManager.NameNotFoundException) {
            Log.v("Exception", e.message.toString())
        }
        return packageList
    }

    internal fun isModuleSupportedToLog(context: Context?, module: String?): Boolean {
        val supportedPackageList = getSupportedPackageName(context)
        for (packageName in supportedPackageList) {
            if(packageName.trim().isNotBlank() &&  !module?.trim().isNullOrBlank()) {
                if (module?.contains(packageName) == true) return true
            }
        }
        return false
    }

}