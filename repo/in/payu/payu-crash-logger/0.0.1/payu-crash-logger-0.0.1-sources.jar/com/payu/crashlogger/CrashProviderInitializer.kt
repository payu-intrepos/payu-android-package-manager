package com.payu.crashlogger

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.startup.Initializer
class CrashProviderInitializer : Initializer<Unit> {
    override fun create(context: Context) {
        CrashManager.init(context)
    }

    override fun dependencies(): List<Class<out Initializer<*>>> {
        return emptyList()

    }

}
