package com.payu.crashlogger.network

import android.content.Context
import com.payu.crashlogger.BuildConfig
import com.payu.crashlogger.PayUCrashlyticsUtils
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.Closeable
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection


object PayUNetworkCall {

    fun fetchResponse(request: JSONObject, context: Context): JSONObject? {
        return if (!PayUCrashlyticsUtils.getSentryUrl(context).isNullOrEmpty()) {
            try {
                getHttpsConn(
                    PayUCrashlyticsUtils.getSentryUrl(context),
                    request,
                    -1, PayUCrashlyticsUtils.getSentryKey(context)
                )
            } catch (e: Exception) {
                request
            }
        } else {
            JSONObject()
        }

    }

    private fun getHttpsConn(
        strURL: String?,
        postData: JSONObject?,
        timeout: Int,
        sentryKey: String?
    ): JSONObject? {
        println("CrashAnalyticsJson getHttpsConn $postData")
        var response = JSONObject()
        val httpsURLConnection =
            getHttpsConn(strURL, postData?.toString(), timeout, null, sentryKey)

        var stream: BufferedInputStream? = null;
        try {
            if (null != httpsURLConnection) {
                PayUCrashlyticsUtils.log("Http Call to Server")
                var data = ""
                if (httpsURLConnection.responseCode == HttpURLConnection.HTTP_OK) {
                    stream = BufferedInputStream(httpsURLConnection.inputStream)
                    data = readStream(inputStream = stream)
                    response = JSONObject(data)
                    PayUCrashlyticsUtils.log("Data $data")
                    PayUCrashlyticsUtils.log("response $response")
                    println("CrashAnalyticsJson response $response")
                    println("CrashAnalyticsJson Data $data")


                } else {
                    PayUCrashlyticsUtils.log("Error ")
                    return postData
                }
                PayUCrashlyticsUtils.log("Http Response " + httpsURLConnection.responseCode)
            } else {
                PayUCrashlyticsUtils.log("Http null")
            }
        } catch (ex: Exception) {
            PayUCrashlyticsUtils.log("Ex " + ex.message)
            return null
        } finally {
            stream?.let {
                safeClose(it)
            }
        }

        return response
    }

    private fun readStream(inputStream: BufferedInputStream): String {
        val bufferedReader = BufferedReader(InputStreamReader(inputStream))
        val stringBuilder = StringBuilder()
        bufferedReader.forEachLine { stringBuilder.append(it) }
        return stringBuilder.toString()
    }

    private fun getHttpsConn(
        strURL: String?,
        postData: String?,
        timeout: Int,
        cookiesList: String?,
        sentryKey: String?
    ): HttpsURLConnection? {
        var outStream: OutputStream? = null
        try {
            val url = URL(strURL)
            val conn = url.openConnection() as HttpsURLConnection
            conn.doOutput = true
            conn.requestMethod = "POST"
            if (timeout != -1) {
                conn.connectTimeout = timeout
            }
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

            val header = "Sentry sentry_version=7" + ",sentry_client=" +
                    BuildConfig.LIBRARY_PACKAGE_NAME + "/" + BuildConfig.VERSION_NAME + ",sentry_key=" + sentryKey

            conn.setRequestProperty(
                "X-Sentry-Auth",
                header
            )
            if (postData != null) {
                conn.setRequestProperty("Content-Length", postData.length.toString())
            }
            if (cookiesList != null) {
                conn.setRequestProperty("Cookie", cookiesList)
            }
//            conn.sslSocketFactory = TLSSocketFactory()
            if (postData != null) {
                val postParamsByte = postData.toByteArray()
                outStream = conn.outputStream;
                outStream.write(postParamsByte)
            }
            return conn
        } catch (e: Exception) {
            PayUCrashlyticsUtils.log("Ex " + e.message)
            return null
        } finally {
            outStream?.let {
                safeClose(it)
            }
        }

    }

    private fun safeClose(fis: Closeable?) {
        if (fis != null) {
            try {
                fis.close()
            } catch (e: IOException) {
                PayUCrashlyticsUtils.log("Ex " + e.message)
            }
        }
    }


}