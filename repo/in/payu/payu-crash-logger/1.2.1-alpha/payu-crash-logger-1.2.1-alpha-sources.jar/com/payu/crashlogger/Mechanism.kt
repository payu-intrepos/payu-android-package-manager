package com.payu.crashlogger

class Mechanism @JvmOverloads constructor(@field:Transient val thread: Thread? = null) {
    var type: String? = null
    var isHandled: Boolean? = null

}