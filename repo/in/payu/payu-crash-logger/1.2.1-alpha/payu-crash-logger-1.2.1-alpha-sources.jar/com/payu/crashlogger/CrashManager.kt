package com.payu.crashlogger

import android.annotation.SuppressLint
import android.content.Context
import android.text.TextUtils
import com.payu.crashlogger.cache.PayUCrashLogsCache
import com.payu.crashlogger.network.PayUNetworkCall
import com.payu.crashlogger.request.*
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.locks.ReentrantLock
import kotlin.Exception
import kotlin.concurrent.withLock


@SuppressLint("StaticFieldLeak")
object CrashManager {
    private var versionMap = HashMap<String, String>()
    private var context: Context? = null
    private var contexts: Contexts? = null
    private val lock = ReentrantLock()

    private val coroutineException = CoroutineExceptionHandler { _, throwable ->
        PayUCrashlyticsUtils.log(throwable.message)
    }
    private val coroutineScope = CoroutineScope(Dispatchers.IO + coroutineException)
    fun init(context: Context): CrashManager {
        this.context = context
        initSDKVersions()
        cacheHandling()
        setupExceptionHandler()
        return this
    }

    private fun cacheHandling() {
        context?.let {
            val jsonArray =
                PayUCrashLogsCache.getInstance(it)?.getSavedLogsJsonArray()
            PayUCrashlyticsUtils.log(
                "SharedPreference Saved!!! " + "  Size" + jsonArray?.length()
            )
            if (jsonArray?.toString()?.isNotEmpty() == true) {
                for (i in 0 until jsonArray.length()) {
                   serverCallForCachedData(jsonArray[i] as JSONObject)
                }
            }
        }
    }

    private var jsonArraySave: JSONArray = JSONArray()

    private fun serverCallForCachedData(request: JSONObject) {
        coroutineScope.launch {
            context?.let {
                val response =
                    PayUNetworkCall.fetchResponse(request, it)
                lock.withLock {
                    if (null != response && response.has("contexts")) {
                        PayUCrashlyticsUtils.log("context---")


                        jsonArraySave.put(response)
                        PayUCrashlyticsUtils.log(
                            "SharedPreference  JSON Array Cache Size:${jsonArraySave.length()}"
                        )
                        PayUCrashLogsCache.getInstance(it)?.setJsonArrayLogs(jsonArraySave)
                    }
                }
            }
        }
    }


    private fun createCrashReportBean() {
        context?.let {
            val os = PayUCrashlyticsUtils.getOs()
            val device = PayUCrashlyticsUtils.getDevice(it)
            val app = PayUCrashlyticsUtils.getApp(it)
            contexts = Contexts(app, device, os)
        }
    }


    private fun setupExceptionHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            PayUCrashlyticsUtils.log(t.name)
//            lock.withLock {
//         val throwable =   getUnhandledThrowable(t,e)
            val payUCrashReportRequest = getRequestBeanForSentry(t, e)
            payUCrashReportRequest?.let { request ->
                context?.let {
                    val response = PayUCrashlyticsUtils.createRequest(
                        request
                    )
                    val jsonArray =
                        PayUCrashLogsCache.getInstance(it)
                            ?.getSavedLogsJsonArray()
                    jsonArray?.put(response)
                    PayUCrashlyticsUtils.log(
                        "SharedPreference After saving JSON Array ${jsonArray?.length()}"
                    )
                    if (jsonArray != null) {
                        PayUCrashLogsCache.getInstance(it)?.setJsonArrayLogs(jsonArray)
                    }
                    defaultHandler?.uncaughtException(t, e)
                } ?: defaultHandler?.uncaughtException(t, e)
            } ?: defaultHandler?.uncaughtException(t, e)
        }
    }

    private fun initSDKVersions() {

        val cbVersion = getCBVersion()
        if (!TextUtils.isEmpty(cbVersion))
            versionMap["cb"] = cbVersion

        val upiSdkVersion = PayUCrashlyticsUtils.getSdkVersion("com.payu.upisdk.BuildConfig")
        if (!TextUtils.isEmpty(upiSdkVersion))
            versionMap["upisdk"] = upiSdkVersion

        val pdSdkVersion = PayUCrashlyticsUtils.getSdkVersion("com.payu.india.BuildConfig")
        if (!TextUtils.isEmpty(pdSdkVersion))
            versionMap["pgsdk"] = pdSdkVersion

        val gpayVersion = PayUCrashlyticsUtils.getSdkVersion("com.payu.gpay.BuildConfig")
        if (!TextUtils.isEmpty(gpayVersion))
            versionMap["gpay"] = gpayVersion

        val phonepeVersion = PayUCrashlyticsUtils.getSdkVersion("com.payu.phonepe.BuildConfig")
        if (!TextUtils.isEmpty(phonepeVersion))
            versionMap["phonepe"] = phonepeVersion

        val olamoneyVersion = PayUCrashlyticsUtils.getSdkVersion("com.payu.olamoney.BuildConfig")
        if (!TextUtils.isEmpty(olamoneyVersion))
            versionMap["olamoney"] = olamoneyVersion

        val coreNetworkVersion =
            PayUCrashlyticsUtils.getSdkVersion("com.payu.socketverification.BuildConfig")
        if (!TextUtils.isEmpty(coreNetworkVersion))
            versionMap["core-network"] = coreNetworkVersion

        val packagelist = PayUCrashlyticsUtils.getSupportedPackageName(context)
        for (packageName in packagelist) {
            val versionSDK = PayUCrashlyticsUtils.getSdkVersion("$packageName.BuildConfig")
            versionMap[packageName] = versionSDK
        }
    }

    private fun getCBVersion(): String {
        return try {
            val className = "com.payu.custombrowser.Bank"
            val customClass = CrashManager::class.java.classLoader?.loadClass(className)
            val versionField = customClass?.getField("Version")
            return versionField?.get(null) as String
        } catch (e: Exception) {
            ""
        }
    }

    private fun getRequestBeanForSentry(t: Thread, e: Throwable): PayUCrashReportRequest? {

        val exception =
            PayUCrashlyticsUtils.getExceptionValue(PayUCrashlyticsUtils.extractExceptionQueue(e))
                ?.let { Exception(it) }
        var isPayUCrash = false
        val payUCrashReportRequest = PayUCrashReportRequest()
        if (exception != null) {
            for (i in exception.values.indices) {
                val stacktraceFrames = exception.values[i].stacktrace?.frames
                stacktraceFrames?.indices?.let { indices ->
                    for (j in indices) {
                        stacktraceFrames[j].module.let { module ->
                            if (PayUCrashlyticsUtils.isModuleSupportedToLog(
                                    context,
                                    module
                                )
                            ) {
                                val frame = stacktraceFrames[j]
                                PayUCrashlyticsUtils.log("Module Name " + frame.module)

                                frame.module?.let {
                                    frame.packageName =
                                        PayUCrashlyticsUtils.getPackageNameOfStrClass(it)
                                }


                                if (payUCrashReportRequest.release?.isEmpty() == true) {
                                    payUCrashReportRequest.sourceSdk = frame.packageName
                                    payUCrashReportRequest.release =
                                        frame.packageName + "@" + PayUCrashlyticsUtils.getSdkVersion(
                                            frame.packageName + ".BuildConfig"
                                        )
                                }

                                frame.packageName?.let { packageName ->
                                    if (!versionMap.containsKey(packageName)) {
                                        val sdkVersion =
                                            PayUCrashlyticsUtils.getSdkVersion(frame.packageName + ".BuildConfig")
                                        PayUCrashlyticsUtils.log("package " + frame.packageName + sdkVersion)
                                        if (!TextUtils.isEmpty(sdkVersion)) {
                                            versionMap[packageName] = sdkVersion
                                        }
                                    }
                                }

                                isPayUCrash = true
                                if (payUCrashReportRequest.mappingFileID == null) {
                                    payUCrashReportRequest.mappingFileID =
                                        PayUCrashlyticsUtils.getMappingFileUUID(
                                            frame.packageName,
                                            context
                                        )
                                }
                            }
                        }
                    }
                }

            }
        }

        if (!isPayUCrash) {
            return null
        }
        val platform = "java"
        val timestamp = PayUCrashlyticsUtils.getCurrentTimeStamp()
        val user = User()
        user.id = PayUCrashlyticsUtils.getAndroidId(context)
        val thread = Threads()

        thread.values = PayUCrashlyticsUtils.getCurrentThreads(Thread.getAllStackTraces())

        createCrashReportBean()
        payUCrashReportRequest.exception = exception
        payUCrashReportRequest.contexts = contexts
        val tags = Tags()
        tags.tagsMap = versionMap
        payUCrashReportRequest.tags = tags
        payUCrashReportRequest.threads = thread
        payUCrashReportRequest.timestamp = timestamp
        payUCrashReportRequest.user = user
        PayUCrashlyticsUtils.log("Release final " + payUCrashReportRequest.release)
        val sentryId = SentryId()
        payUCrashReportRequest.event_id = sentryId.toString()
//        payUCrashReportRequest.release = PayUCrashlyticsUtils.getRelease(context!!)
        payUCrashReportRequest.platform = platform
        payUCrashReportRequest.level = "fatal"
        payUCrashReportRequest.sdk = PayUCrashlyticsUtils.getSdk()
        return payUCrashReportRequest
    }

}