package com.payu.crashlogger.cache

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

class PayUCrashLogsCache private constructor(context: Context) {
    private var mPref: SharedPreferences? = null
    private var mEditor: SharedPreferences.Editor? = null

    fun getSavedLogsJsonArray(): JSONArray? {
        synchronized(this) {
            var jsonArray = JSONArray()
            val savedLogs = getSavedLogs()
            if (savedLogs.isNotEmpty()) {
                //SharedPreference is created with JSON Array
                /* this try catch is added to avoid malformed json exception, on migration of encrypted shared preference to shared preference */
                try {
                    jsonArray =
                        JSONArray(savedLogs)
                } catch (ex: Exception) {
                    return null
                }
            }
            saveLogs("")
            return jsonArray
        }

    }

    fun setJsonArrayLogs(jsonArray: JSONArray) {
        synchronized(this) {
            saveLogs(jsonArray.toString())
        }

    }

    private fun getSavedLogs(): String {
        return try {
            mPref?.getString(KEY_PAYU_LOGS, "") ?: ""
        } catch (e: Exception) {
            mPref?.edit()?.clear()?.apply()
            ""
        }
    }

    private fun saveLogs(value: String): Boolean? {
        mEditor?.putString(KEY_PAYU_LOGS, value)
        return mEditor?.commit()
    }

    init {
        mPref = context.getSharedPreferences(mPREF_NAME, Context.MODE_PRIVATE)
        mEditor = mPref?.edit()
    }

    companion object {
        @Volatile
        private var instance: PayUCrashLogsCache? = null
        private const val mPREF_NAME = "PAYU_CRASHLYTICS_APP_PREF"
        private const val KEY_PAYU_LOGS = "KEY_PAYU_LOGS"
        fun getInstance(context: Context): PayUCrashLogsCache {
            val checkInstance = instance
            if (checkInstance != null) {
                return checkInstance
            }

            return synchronized(this) {
                val checkInstanceAgain = instance
                if (checkInstanceAgain != null) {
                    checkInstanceAgain
                } else {
                    val created = PayUCrashLogsCache(context)
                    instance = created
                    created
                }
            }
        }
    }


}