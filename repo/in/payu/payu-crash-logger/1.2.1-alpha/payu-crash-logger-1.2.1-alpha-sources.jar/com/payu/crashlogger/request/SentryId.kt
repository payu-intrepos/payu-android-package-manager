package com.payu.crashlogger.request

import java.util.UUID

class SentryId {

    private val uuid: UUID

    @JvmOverloads
    constructor(uuid: UUID? = null) {
        var uuid = uuid
        if (uuid == null) {
            uuid = UUID.randomUUID()
        }
        this.uuid = uuid!!
    }

    constructor(sentryIdString: String?) {
        this.uuid = fromStringSentryId(sentryIdString)!!
    }

    override fun toString(): String {
        return uuid.toString().replace("-", "")
    }

    override fun equals(o: Any?): Boolean {
        if (this === o) return true
        if (o == null || javaClass != o.javaClass) return false
        val sentryId = o as SentryId?
        return uuid.compareTo(sentryId!!.uuid) == 0
    }

    override fun hashCode(): Int {
        return uuid.hashCode()
    }

    private fun fromStringSentryId(sentryIdString: String?): UUID? {
        var sentryIdString: String? = sentryIdString ?: return null

        if (sentryIdString!!.length == 32) {
            // expected format, SentryId is a UUID without dashes
            sentryIdString = StringBuilder(sentryIdString)
                .insert(8, "-")
                .insert(13, "-")
                .insert(18, "-")
                .insert(23, "-")
                .toString()
        }
        require(sentryIdString.length == 36) {
            ("String representation of SentryId has either 32 (UUID no dashes) "
                    + "or 36 characters long (completed UUID). Received: "
                    + sentryIdString)
        }

        return UUID.fromString(sentryIdString)
    }

    companion object {

        val EMPTY_ID = SentryId(UUID(0, 0))
    }
}

