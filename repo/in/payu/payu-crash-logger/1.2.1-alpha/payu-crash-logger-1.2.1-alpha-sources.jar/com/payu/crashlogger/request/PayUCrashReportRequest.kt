package com.payu.crashlogger.request

class PayUCrashReportRequest {
    var breadcrumbs: List<Any>? = null
    var contexts: Contexts? = null
    var event_id: String? = ""
    var exception: Exception? = null
    var level: String? = ""
    var platform: String? = ""
    var release: String? = ""
    var sdk: Sdk? = null
    var threads: Threads? = null
    var timestamp: String? = ""
    var user: User? = null
    var tags: Tags? = null
    var sourceSdk: String? = null
    var mappingFileID: String? = null
}

/*data class Extra(

)*/
data class Contexts(
    val app: App,
    val device: Device,
    val os: Os
)

data class Exception(
    val values: List<Value>
)

class Tags {
    var tagsMap: HashMap<String, String>? = null
}

class Sdk {
    var name: String? = ""
    var version: String? = ""
}

class Threads {
    var values: List<ValueX>? = null
}


class User {
    var id: String? = ""
}


data class App(
    val app_build: String,
    val app_identifier: String,
    val app_version: String
)

class Device {
    internal var batteryLevel: Double? = null
    internal var bootTime: String? = ""
    internal var brand: String? = ""
    internal var charging = false
    internal var connectionType: String? = ""
    internal var freeMemory: Long? = null
    internal var id: String? = ""
    internal var language: String? = ""
    internal var lowMemory: Boolean? = null
    internal var manufacturer: String? = ""
    internal var memorySize: Long? = null
    internal var model: String? = ""
    internal var modelId: String? = ""
    internal var name: String? = ""
}

data class Os(
    val build: String,
    val kernel_version: String,
    val name: String,
    val version: String
)

class Value {
    var module: String? = ""
    var stacktrace: Stacktrace? = null
    var threadId: Long? = null
    var type: String? = ""
    var value: String? = ""
}

class Stacktrace {
    var frames: List<Frame>? = ArrayList()
}

class Frame {
    var filename: String? = ""
    var function: String? = ""
    var inApp: Boolean = false
    var lineno: Int? = null
    var module: String? = ""
    var packageName: String? = ""
    var native: Boolean = false
}

data class Package(
    val name: String?,
    val version: String?
)

class ValueX {
    internal var crashed: Boolean = false
    internal var current: Boolean = false
    internal var daemon: Boolean = false
    internal var id: Long = 0
    internal var name: String? = ""
    internal var priority: Int = -1
    internal var state: String? = ""
}