package com.payu.crashlogger

class ExceptionMechanismException
/**
 * A [Throwable] that decorates another with a Sentry [Mechanism].
 *
 */(
    val exceptionMechanism: Mechanism, val throwable: Throwable?, val thread: Thread?
) : RuntimeException() {
    companion object {
        private const val serialVersionUID = 142345454265713915L
    }

}