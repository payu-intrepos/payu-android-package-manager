package com.payu.ppiscanner.network

import com.payu.ppiscanner.PayUQRScanner
import com.payu.ppiscanner.constants.APIConstants
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.TimeZone

object V2ApiUtils {

    private var date: String? = null
    private var authHeader: String? = null

    fun generateSigningString(jsonString: String?): String {
        val myDate = Date()
        val calendar = Calendar.getInstance()
        calendar.timeZone = TimeZone.getTimeZone(APIConstants.UTC)
        calendar.time = myDate
        calendar.add(Calendar.MINUTE, -330)
        val time = calendar.time
        val outputFmt =
            SimpleDateFormat(APIConstants.V2_API_TIME_FORMAT)
        date = outputFmt.format(time)
        return StringBuilder()
            .append(jsonString).append(APIConstants.PIPE_SEPARATOR).append(date)
            .append(APIConstants.PIPE_SEPARATOR).toString()
    }

    fun getAuthHeader(signature: String): HashMap<String, String> {
        val headerMap: HashMap<String, String> = HashMap()
        headerMap[APIConstants.DATE] = date!!
        headerMap[APIConstants.PAYU_CONTENT_TYPE] = APIConstants.APPLICATION_JSON
        authHeader = StringBuilder()
            .append(APIConstants.AUTH_HEADER_PARAM_1)
            .append(PayUQRScanner.scannerConfig.key)
            .append(APIConstants.AUTH_HEADER_PARAM_2)
            .append(signature)
            .append("\"").toString()
        headerMap[APIConstants.AUTHORIZATION] = authHeader!!
        return headerMap
    }
}