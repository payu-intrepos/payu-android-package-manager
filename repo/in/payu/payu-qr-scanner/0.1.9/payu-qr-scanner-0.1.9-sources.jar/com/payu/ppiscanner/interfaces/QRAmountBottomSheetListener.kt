package com.payu.ppiscanner.interfaces

interface QRAmountBottomSheetListener {
    fun proceedAndPay(amount: Double)
    fun onClose()
}