package com.payu.ppiscanner.utils

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import com.payu.assetprovider.enums.DrawableType
import com.payu.assetprovider.model.ImageDetails

object ImageViewUtils {
    fun setImage(imageView: ImageView?, result: ImageDetails?) {
        if (imageView == null || result == null) return
        if (result.drawableType == DrawableType.Bitmap)
            imageView.setImageBitmap(result.image as Bitmap)
        else if (result.drawableType == DrawableType.PictureDrawable) {
            imageView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            imageView.setImageDrawable(result.image as Drawable)
        }
    }
}