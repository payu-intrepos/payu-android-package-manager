package com.payu.ppiscanner

import android.annotation.SuppressLint
import android.content.Context
import android.util.DisplayMetrics
import android.view.Display
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.payu.ppiscanner.constants.PayuScannerConstants.Companion.BACK_CAMERA_UNAVAILABLE_ERROR_CODE
import com.payu.ppiscanner.constants.PayuScannerConstants.Companion.CAMERA_INITIALIZATION_FAILED_ERROR_CODE
import com.payu.ppiscanner.constants.PayuScannerConstants.Companion.USE_CASE_BINDING_FAILED_ERROR_CODE
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

typealias QRListener = (barcode: String?) -> Unit

class CameraHelper(
    private val owner: AppCompatActivity?,
    private val context: Context?,
    private val viewFinder: PreviewView?,
    private val onResult: (result: String) -> Unit,
    private val onError: (errorCode: Int, errorMessage: String) -> Unit
) {
    private var cameraExecutor: ExecutorService =
        Executors.newSingleThreadExecutor()
    private var lensFacing: Int = CameraSelector.LENS_FACING_BACK
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null

    //To start the camera
    fun start() {
        startCamera()
    }

    //To stop the camera
    fun stop() {
        cameraExecutor.shutdown()
    }

    private fun startCamera() {
        val cameraProviderFuture =
            ProcessCameraProvider.getInstance(context!!)
        cameraProvider = cameraProviderFuture.get()
        if (hasBackCamera()) {
            cameraProviderFuture.addListener({
                lensFacing = CameraSelector.LENS_FACING_BACK
                bindCameraUseCases()
            }, ContextCompat.getMainExecutor(context))
        } else {
            onError.invoke(BACK_CAMERA_UNAVAILABLE_ERROR_CODE, context.getString(R.string.payu_back_camera_unavailable))
            return
        }
    }

    private fun bindCameraUseCases() {
        if (cameraProvider == null) {
            onError.invoke(CAMERA_INITIALIZATION_FAILED_ERROR_CODE, context!!.getString(R.string.payu_camera_init_failed))
            return
        }
        val cameraProvider = cameraProvider!!
        val cameraSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val previewView = getPreviewUseCase()
        val barcodeRecognizer = getBarcodeAnalyzerUseCase(onResult)
        cameraProvider.unbindAll()
        try {

            camera = owner?.let {
                cameraProvider.bindToLifecycle(
                    it, cameraSelector, previewView, barcodeRecognizer
                )
            }
            if (viewFinder != null) {
                previewView.setSurfaceProvider(viewFinder.surfaceProvider)
            }
        } catch (exc: Exception) {
            onError.invoke(USE_CASE_BINDING_FAILED_ERROR_CODE, String.format(context!!.getString(R.string.payu_use_case_binding_failed), exc.toString()))
            return
        }
    }

    private fun aspectRatio(): Int {
        with(DisplayMetrics().also {
            viewFinder?.display?.getRealMetrics(it)
        }) {
            val previewRatio = max(
                widthPixels,
                heightPixels
            ).toDouble() / widthPixels.coerceAtMost(
                heightPixels
            )
            if (abs(previewRatio - RATIO_4_3_VALUE) <= abs(previewRatio - RATIO_16_9_VALUE)) {
                return AspectRatio.RATIO_4_3
            }
            return AspectRatio.RATIO_16_9
        }
    }

    private fun hasBackCamera() =
        cameraProvider?.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ?: false

    private fun getPreviewUseCase(): Preview {
        var rotation = 0
        var display: Display? = viewFinder?.display
        if (display != null) {
            rotation = display.rotation
        }
        return Preview.Builder()
            .setTargetAspectRatio(aspectRatio())
            .setTargetRotation(rotation)
            .build()
    }

    private fun getBarcodeAnalyzerUseCase(onResult: (result: String) -> Unit): ImageAnalysis {
        var rotation = 0
        val display: Display? = viewFinder?.display
        if (display != null) {
            rotation = display.rotation
        }
        val analyzer = ImageAnalysis.Builder().setTargetAspectRatio(aspectRatio())
            .setTargetRotation(rotation)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).setImageQueueDepth(10)
            .build()
        analyzer.setAnalyzer(cameraExecutor, BarcodeScanner { string ->
            string?.let { url ->
                println("BarcodeScanner url$url")
                onResult(url)
            }
        })
        return analyzer
    }

    private class BarcodeScanner(listener: QRListener? = null) : ImageAnalysis.Analyzer {
        private val listeners = ArrayList<QRListener>().apply { listener?.let { add(it) } }
        val options =
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()

        @SuppressLint("UnsafeExperimentalUsageError", "UnsafeOptInUsageError")
        override fun analyze(imageProxy: ImageProxy) {
            val mediaImage = imageProxy.image
            if (mediaImage != null) {
                val image = InputImage.fromMediaImage(
                    mediaImage,
                    imageProxy.imageInfo.rotationDegrees
                )
                val scanner = BarcodeScanning.getClient(options)
                scanner.process(image)
                    .addOnSuccessListener { barcodes ->
                        barcodes.forEach { barcode ->
                            listeners.forEach {
                                it(barcode.displayValue)
                            }
                        }
                        imageProxy.close()

                    }
                    .addOnFailureListener {
                        imageProxy.close()

                    }
            }
        }
    }

    companion object {
        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0
    }

}
