package com.payu.ppiscanner.model

enum class QRErrorType {
    INVALID_QR,
    INTERNET_ISSUE
}