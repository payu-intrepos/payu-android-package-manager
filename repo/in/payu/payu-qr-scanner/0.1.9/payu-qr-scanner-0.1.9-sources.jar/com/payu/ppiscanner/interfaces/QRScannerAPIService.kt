package com.payu.ppiscanner.interfaces

interface QRScannerAPIService {

    fun callAPI(request: Any, listener: PayUScannerAPICallback)
    fun generateHash(
        param: HashMap<String, String?>,
        scannerHashGeneratedListener: ScannerHashGeneratedListener
    )

}