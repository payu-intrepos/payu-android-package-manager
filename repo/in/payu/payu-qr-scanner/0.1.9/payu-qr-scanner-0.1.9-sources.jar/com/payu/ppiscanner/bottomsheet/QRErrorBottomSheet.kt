package com.payu.ppiscanner.bottomsheet

import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import com.payu.ppiscanner.R
import com.payu.ppiscanner.interfaces.QRErrorBottomSheetListener
import com.payu.ppiscanner.model.QRErrorType
import com.payu.ppiscanner.widgets.RoundedCornerBottomSheet

class QRErrorBottomSheet(
    private val fragmentManager: FragmentManager, val tag: String,
    private val roundedCornerBottomSheet: RoundedCornerBottomSheet
) {

    fun show() {
        roundedCornerBottomSheet.isCancelable = false
        roundedCornerBottomSheet.show(fragmentManager, tag)
    }

    fun close() {
        roundedCornerBottomSheet.dismissAllowingStateLoss()
    }

    class Builder(private val fragmentManager: FragmentManager, val tag: String, val type: QRErrorType) :
        RoundedCornerBottomSheet.OnBottomSheetListener {

        private lateinit var btnScanAgain: Button
        private lateinit var btnClose: ImageView
        private lateinit var image: ImageView
        private lateinit var tvTile: TextView
        private lateinit var tvSubtitle: TextView
        private lateinit var listener: QRErrorBottomSheetListener

        fun setListener(listener: QRErrorBottomSheetListener) {
            this.listener = listener
        }

        fun build(): QRErrorBottomSheet {

            val roundedCornerBottomSheet = RoundedCornerBottomSheet.newInstance(
                R.layout.payu_qr_error_bottomsheet
            )
            roundedCornerBottomSheet.setListener(this)
            return QRErrorBottomSheet(fragmentManager, tag, roundedCornerBottomSheet)

        }

        override fun getInflatedView(
            view: View,
            roundedCornerBottomSheet: RoundedCornerBottomSheet
        ) {
            btnScanAgain = view.findViewById(R.id.btn_scan_again)
            btnClose = view.findViewById(R.id.iv_payu_qr_bottomsheet_close)
            image = view.findViewById(R.id.iv_error_icon)
            tvTile = view.findViewById(R.id.tv_error_title)
            tvSubtitle = view.findViewById(R.id.tv_error_subtitle)

            if (type == QRErrorType.INVALID_QR) {
                image.setImageResource(R.drawable.ic_warning)
                tvTile.text = view.context.getString(R.string.payu_invalid_qr)
                tvSubtitle.text = view.context.getString(R.string.payu_invalid_qr_subtitle)
            } else if (type == QRErrorType.INTERNET_ISSUE) {
                image.setImageResource(R.drawable.ic_network_issue)
                tvTile.text = view.context.getString(R.string.payu_network_error)
                tvSubtitle.text = view.context.getString(R.string.payu_network_error_subtitle)
            }
            addListeners(view, roundedCornerBottomSheet)
        }

        override fun handleBottomSheetClose() {
        }

        private fun addListeners(v: View?, roundedCornerBottomSheet: RoundedCornerBottomSheet) {
            btnScanAgain.setOnClickListener {
                roundedCornerBottomSheet.dismissAllowingStateLoss()
                listener.rescanQR()
            }
            btnClose.setOnClickListener {
                roundedCornerBottomSheet.dismissAllowingStateLoss()
                listener.close()
            }

        }
    }
}