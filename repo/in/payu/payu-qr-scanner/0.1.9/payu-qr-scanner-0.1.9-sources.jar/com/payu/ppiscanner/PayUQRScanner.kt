package  com.payu.ppiscanner

import android.content.Context
import android.content.Intent
import androidx.annotation.Keep
import com.payu.ppiscanner.interfaces.PayUScannerListener

@Keep
object PayUQRScanner {
    internal var payUScannerListener: PayUScannerListener? = null
    internal lateinit var scannerConfig: PayUScannerConfig

    fun openScannerActivity(
        context: Context,
        scannerConfig: PayUScannerConfig,
        callback: PayUScannerListener
    ) {
        payUScannerListener = callback
        this.scannerConfig = scannerConfig

        val intent = Intent(context, ScanQRActivity::class.java)
        context.startActivity(intent)
    }
}