package com.payu.ppiscanner.interfaces

import androidx.annotation.Keep

@Keep
interface ScannerHashGeneratedListener {
    fun onHashGenerated(hash: HashMap<String, String?>)
}