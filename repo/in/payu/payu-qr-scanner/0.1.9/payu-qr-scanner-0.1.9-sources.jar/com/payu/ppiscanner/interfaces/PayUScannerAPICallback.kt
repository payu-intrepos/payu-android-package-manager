package com.payu.ppiscanner.interfaces

interface PayUScannerAPICallback {

    fun onSuccess(response: Any)
    fun onError(errorCode: Int, errorMessage: String)
}