package com.payu.ppiscanner.managers

import android.view.View
import com.payu.ppiscanner.widgets.RoundedCornerBottomSheet

abstract class BottomSheetManager: RoundedCornerBottomSheet.OnBottomSheetListener {
    private lateinit var view: View
    private lateinit var roundedCornerBottomSheet: RoundedCornerBottomSheet
    override fun getInflatedView(view: View, roundedCornerBottomSheet: RoundedCornerBottomSheet) {
        this.view = view
        this.roundedCornerBottomSheet = roundedCornerBottomSheet
        init()
    }
    abstract fun init()

    abstract override fun handleBottomSheetClose()
}