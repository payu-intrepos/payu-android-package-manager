package com.payu.ppiscanner.network

import com.payu.ppiscanner.PayUQRScanner
import com.payu.ppiscanner.constants.APIConstants
import com.payu.ppiscanner.constants.APIConstants.Companion.GET_OUTLET_API_QUERY_PARAM
import com.payu.ppiscanner.interfaces.PayUScannerAPICallback
import com.payu.ppiscanner.interfaces.PayUScannerAsyncTaskResponse
import com.payu.ppiscanner.interfaces.QRScannerAPIService
import com.payu.ppiscanner.interfaces.ScannerHashGeneratedListener
import com.payu.ppiscanner.model.OutletTxnDetails
import com.payu.ppiscanner.constants.PayUScannerErrorConstants
import com.payu.ppiscanner.constants.PayuScannerConstants
import com.payu.ppiscanner.constants.PayuScannerConstants.Companion.OUTLET_HASH
import org.json.JSONObject

class GetOutletDetailAPI: QRScannerAPIService {
    override fun callAPI(request: Any, callback: PayUScannerAPICallback) {

        val map =  HashMap<String, String?>()
        map[PayuScannerConstants.SCANNER_HASH_NAME] = OUTLET_HASH
        map[PayuScannerConstants.SCANNER_HASH_STRING] = V2ApiUtils.generateSigningString("")

        generateHash(
            map,
            object : ScannerHashGeneratedListener {
                override fun onHashGenerated(hash: HashMap<String, String?>) {

                    val networkData = PayUScannerNetworkData()

                    val getData = generateGetData(request as Int)

                    networkData.url =
                        if (PayUQRScanner.scannerConfig.isProduction) APIConstants.FEBE_BASE_URL.plus(
                            APIConstants.OUTLET_DETAIL_API_PATH
                        ) else
                            APIConstants.UAT_FEBE_BASE_URL.plus(
                                APIConstants.OUTLET_DETAIL_API_PATH
                            )
                    networkData.getRequest = getData

                    networkData.headerMap = V2ApiUtils.getAuthHeader(hash[OUTLET_HASH]!!)
                    networkData.contentType = APIConstants.APPLICATION_JSON

                    PayUScannerAPICall().makePostAPICall(
                        APIConstants.HTTP_REQUEST_TYPE_GET,
                        networkData,
                        object : PayUScannerAsyncTaskResponse {
                            override fun onSuccess(response: Any, executionTime: Long) {
                                val jsonObject = JSONObject(response.toString())
                                if (jsonObject.getInt(APIConstants.STATUS) == 1) {
                                    val parsedData = parseData(jsonObject)

                                    if (parsedData != null) {
                                        callback.onSuccess(parsedData)
                                    } else {
                                        callback.onError(
                                            PayUScannerErrorConstants.SDK_RESPONSE_STATUS_CODE_1,
                                            PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE
                                        )
                                    }
                                } else {
                                    callback.onError(
                                        PayUScannerErrorConstants.SDK_RESPONSE_STATUS_CODE_1,
                                        if (!jsonObject.optString(APIConstants.OUTLET_INFO_ERROR_MESSAGE)
                                                .isNullOrEmpty()
                                        ) jsonObject.optString(
                                            APIConstants.OUTLET_INFO_ERROR_MESSAGE
                                        ) else PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE
                                    )
                                }
                            }

                            override fun onFailure(errorCode: Int, errorMessage: String, executionTime: Long) {
                                callback.onError(errorCode, errorMessage)
                            }
                        }
                    )

                }

            }
        )
    }

    override fun generateHash(
        param: HashMap<String, String?>,
        scannerHashGeneratedListener: ScannerHashGeneratedListener
    ) {

        PayUQRScanner.payUScannerListener?.generateHash(param, scannerHashGeneratedListener)
    }

    private fun generateGetData(id: Int): HashMap<String, Any> {
        val map = HashMap<String, Any>()
        map[GET_OUTLET_API_QUERY_PARAM] = id.toString()
        return map
    }

    private fun parseData(jsonObject: JSONObject): OutletTxnDetails? {
        if (jsonObject.has(APIConstants.OUTLET_INFO_RESULT)) {
            val outletData = jsonObject.getJSONObject(APIConstants.OUTLET_INFO_RESULT)
            val outletTxnDetails = OutletTxnDetails()
            outletTxnDetails.id = outletData.optInt(APIConstants.OUTLET_INFO_ID)
            outletTxnDetails.merchantId = outletData.optInt(APIConstants.OUTLET_INFO_MERCHANT_ID)
            outletTxnDetails.outletName = outletData.getString(APIConstants.OUTLET_INFO_OUTLET_NAME)
            outletTxnDetails.isActive = outletData.optBoolean(APIConstants.OUTLET_INFO_IS_ACTIVE)
            return outletTxnDetails
        }
        return null
    }
}