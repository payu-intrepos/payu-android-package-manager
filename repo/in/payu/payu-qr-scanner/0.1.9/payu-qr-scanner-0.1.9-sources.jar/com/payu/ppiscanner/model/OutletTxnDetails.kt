package com.payu.ppiscanner.model

class OutletTxnDetails {
    var id: Int? = null
    var merchantId: Int? = null
    var outletName: String? = null
    var isActive: Boolean? = null
    var amount: Double? = null
}