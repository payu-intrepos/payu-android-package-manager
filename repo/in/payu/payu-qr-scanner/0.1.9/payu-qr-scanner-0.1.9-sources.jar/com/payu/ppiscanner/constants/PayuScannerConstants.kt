package com.payu.ppiscanner.constants

import androidx.annotation.Keep

@Keep
class PayuScannerConstants {
    @Keep
    companion object {
        const val EMPTY_STRING = ""

        const val OUTLET_HASH = "outlet_hash"
        const val SCANNER_HASH_NAME = "hashName"

        const val SCANNER_HASH_STRING = "hashString"

        const val LAYOUT_ID = "layoutId"
        const val BOTTOM_SHEET_FRAGMENT = "bottomSheetFragment"

        const val QR_DATA_OUTLET_KEY = "outletId"
        const val APP_SETTING_PACKAGE = "package"
        const val BACK_CAMERA_UNAVAILABLE_ERROR_CODE = 101
        const val CAMERA_INITIALIZATION_FAILED_ERROR_CODE = 102
        const val USE_CASE_BINDING_FAILED_ERROR_CODE = 103

    }
}