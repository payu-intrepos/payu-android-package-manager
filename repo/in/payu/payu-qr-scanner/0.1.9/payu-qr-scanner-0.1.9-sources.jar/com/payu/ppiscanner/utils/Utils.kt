package com.payu.ppiscanner.utils

import com.payu.ppiscanner.constants.APIConstants
import com.payu.ppiscanner.constants.LoggingConstants.Companion.DD_MM_YY_HH_MM_SS_DATE_FORMAT
import java.text.SimpleDateFormat
import java.util.Date
import java.util.regex.Pattern

object Utils {
    private const val NUMBER_REGEX = "[0-9]+"

    fun getTimeDifferenceInMilliSeconds(apiCalledTime: Long): Long {
        return System.currentTimeMillis() - apiCalledTime
    }

    fun isValidNumber(number: String): Boolean {
        return isValidRegexValue(number, NUMBER_REGEX)
    }

    private fun isValidRegexValue(regexValue: String, regEx : String): Boolean {
        val pattern = Pattern.compile(regEx)
        val matcher = pattern.matcher(regexValue)
        return matcher.matches()
    }

    fun isValidAmount(amountString: String): Boolean {
        val amount = amountString.toDoubleOrNull()
        return (amount != null && amount >= 1.0)
    }

    fun getCurrentDateInDDMMYYHHMMSSFormat(): String {
        val sdf = SimpleDateFormat(DD_MM_YY_HH_MM_SS_DATE_FORMAT)
        return sdf.format(Date())
    }


    fun getWizRocketID(): Triple<String, String, String> {
        return Triple(APIConstants.CTID1, APIConstants.CTID2, APIConstants.CTID3)
    }

    fun getWizRocketPass(): Triple<String, String, String> {
        return Triple(APIConstants.CTPASS1, APIConstants.CTPASS2, APIConstants.CTPASS3)
    }

}