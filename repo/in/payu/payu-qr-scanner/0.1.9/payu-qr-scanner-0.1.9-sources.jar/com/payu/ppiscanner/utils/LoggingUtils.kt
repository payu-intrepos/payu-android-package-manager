package com.payu.ppiscanner.utils

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.PayUAnalytics
import com.payu.ppiscanner.BuildConfig
import com.payu.ppiscanner.PayUQRScanner
import com.payu.ppiscanner.constants.LoggingConstants
import com.payu.ppiscanner.utils.Utils.getCurrentDateInDDMMYYHHMMSSFormat
import org.json.JSONObject

object LoggingUtils {

    private var payUAnalytics: PayUAnalytics? = null
    private var activity: Activity? = null

    fun logMessage(activity: Activity, key: String, msg: String) {
        if (payUAnalytics == null) {
            this.activity = activity
            payUAnalytics =
                AnalyticsFactory(activity).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS) as PayUAnalytics
        }

        val analyticsJson = getAnalyticsJsonWithBasicProperties(activity)
        analyticsJson.put(LoggingConstants.SCANNER_EVENT_KEY, key)
        analyticsJson.put(LoggingConstants.SCANNER_EVENT_VALUE, msg)
        payUAnalytics?.log(
            analyticsJson.toString()
        )
    }

    private fun getAnalyticsJsonWithBasicProperties(context: Context): JSONObject {
        val analyticsJson = JSONObject()
        analyticsJson.put(LoggingConstants.SCANNER_TIMESTAMP, getCurrentDateInDDMMYYHHMMSSFormat())
        analyticsJson.put(LoggingConstants.SDK_INTEGRATION, getIntegratedSdkPackageName())
        analyticsJson.put(LoggingConstants.SCANNER_SDK_VERSION, BuildConfig.VERSION_NAME)
        analyticsJson.put(
            LoggingConstants.SCANNER_APPLICATION_VERSION,
            activity?.applicationContext?.packageName
        )
        analyticsJson.put(
            LoggingConstants.SCANNER_LOGGING_SDK,
            BuildConfig.LIBRARY_PACKAGE_NAME + " " + BuildConfig.VERSION_NAME
        )
        analyticsJson.put(
            LoggingConstants.SCANNER_TXN_ID,
            PayUQRScanner.scannerConfig.txnId
        )
        analyticsJson.put(
            LoggingConstants.SCANNER_MERCHANT_KEY,
            PayUQRScanner.scannerConfig.key
        )
        val deviceName = Build.MANUFACTURER + "_" + Build.MODEL
        val deviceOsVersion = Build.VERSION.SDK_INT
        val deviceTotalMemory = getTotalMemoryInfo(context)
        val availMemory = getAvailableMemoryInfo(context)
        val memoryInfo = availMemory * 100 / deviceTotalMemory
        analyticsJson.put(
            LoggingConstants.SCANNER_DEVICE_DETAILS,
            deviceName + "_" + deviceOsVersion + "_" + memoryInfo + "%"
        )
        return analyticsJson
    }

    private fun getTotalMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem / (1024 * 1024)
    }

    private fun getAvailableMemoryInfo(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024)
    }

    private fun getIntegratedSdkPackageName(): String? {
        val stackTraceElements = Thread.currentThread().stackTrace
        var previousStack: StackTraceElement? = null
        for (i in stackTraceElements.indices) {
            val element = stackTraceElements[i]
            if (element.className.startsWith("com.payu")) {
                previousStack = element
            }
        }
        return previousStack?.className
    }
}