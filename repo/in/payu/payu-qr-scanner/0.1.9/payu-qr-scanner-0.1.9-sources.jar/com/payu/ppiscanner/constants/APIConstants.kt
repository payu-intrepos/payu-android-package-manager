package com.payu.ppiscanner.constants

import androidx.annotation.Keep

@Keep
class APIConstants {
    @Keep
    companion object {
        const val APPLICATION_JSON = "application/json"
        const val UTC = "UTC"
        const val V2_API_TIME_FORMAT = "EEE, dd MMM yyyy HH:mm:ss 'GMT'"
        const val PIPE_SEPARATOR = "|"
        const val DATE = "date"
        const val PAYU_CONTENT_TYPE = "Content-Type"
        const val AUTH_HEADER_PARAM_1 = "hmac username=\""
        const val AUTH_HEADER_PARAM_2 = "\", algorithm=\"sha512\", headers=\"date\", signature=\""
        const val AUTHORIZATION = "authorization"
        const val APPLICATION_FORM_URL_ENCODED = "application/x-www-form-urlencoded"

        const val FEBE_BASE_URL = "https://info.payu.in/"
        const val UAT_FEBE_BASE_URL = "https://pp22api.payu.in/"

        const val OUTLET_DETAIL_API_PATH = "api/v1/outlet"

        const val HTTP_REQUEST_TYPE_GET = "GET"
        const val HTTP_REQUEST_TYPE_POST = "POST"
        const val HEADER_ACCEPT = "accept"
        const val STATUS = "status"

        const val OUTLET_INFO_RESULT = "result"
        const val OUTLET_INFO_ID = "id"
        const val OUTLET_INFO_MERCHANT_ID = "merchantId"
        const val OUTLET_INFO_OUTLET_NAME = "outletName"
        const val OUTLET_INFO_IS_ACTIVE = "isActive"
        const val OUTLET_INFO_ERROR_MESSAGE = "message"
        const val INACTIVE_QR_ERROR_CODE = 105

        const val GET_OUTLET_API_QUERY_PARAM = "id"

        const val SUCCESS_API_CODE = 200
        const val BAD_REQUEST_API_CODE = 400

        //clevertap ids
        const val CTID1 = "WR7"
        const val CTID2 = "R6W"
        const val CTID3 = "646Z"
        const val CTPASS1 = "IOQ"
        const val CTPASS2 = "IIE"
        const val CTPASS3 = "OAUL"
    }
}