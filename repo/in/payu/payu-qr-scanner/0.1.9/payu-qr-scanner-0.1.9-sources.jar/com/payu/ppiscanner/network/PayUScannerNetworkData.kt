package com.payu.ppiscanner.network

import com.payu.ppiscanner.constants.APIConstants

class PayUScannerNetworkData {
    var url: String? = null
    var postRequest: String? = null
    var contentType: String = APIConstants.APPLICATION_FORM_URL_ENCODED
    var headerMap: HashMap<String, String>? = null
    var getRequest: HashMap<String, Any>? = null
}