package com.payu.ppiscanner.network

import android.os.Handler
import android.os.Looper
import com.payu.ppiscanner.BuildConfig
import com.payu.ppiscanner.constants.APIConstants
import com.payu.ppiscanner.interfaces.PayUScannerAsyncTaskResponse
import com.payu.ppiscanner.constants.PayUScannerErrorConstants
import com.payu.ppiscanner.constants.PayUScannerErrorConstants.Companion.REQUEST_BODY_CANNOT_BE_NULL
import com.payu.ppiscanner.constants.PayUScannerErrorConstants.Companion.REST_API_PATH_CANNOT_BE_NULL
import com.payu.ppiscanner.constants.PayUScannerErrorConstants.Companion.SDK_RESPONSE_STATUS_CODE_1
import com.payu.ppiscanner.constants.PayuScannerConstants
import com.payu.ppiscanner.utils.Utils
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class PayUScannerAPICall {
    private var call: Call? = null

    fun makePostAPICall(
        httpMethod: String,
        payUNetworkData: PayUScannerNetworkData,
        payUAsyncTaskResponse: PayUScannerAsyncTaskResponse
    ) {
        val startTime = System.currentTimeMillis()
        if (httpMethod == APIConstants.HTTP_REQUEST_TYPE_POST && payUNetworkData.postRequest.isNullOrEmpty()) {
            payUAsyncTaskResponse.onFailure(
                SDK_RESPONSE_STATUS_CODE_1,
                REQUEST_BODY_CANNOT_BE_NULL,
                Utils.getTimeDifferenceInMilliSeconds(startTime)
            )
            return
        }
        if (payUNetworkData.url.isNullOrEmpty()) {
            payUAsyncTaskResponse.onFailure(
                SDK_RESPONSE_STATUS_CODE_1,
                REST_API_PATH_CANNOT_BE_NULL,
                Utils.getTimeDifferenceInMilliSeconds(startTime)
            )
            return
        }
        val okHttpClientBuilder: OkHttpClient.Builder = OkHttpClient.Builder()
        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor()
            logging.setLevel(HttpLoggingInterceptor.Level.BODY)
            okHttpClientBuilder.addInterceptor(logging)
        }
        val client = okHttpClientBuilder.connectTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS).build()
        val mediaType: MediaType = payUNetworkData.contentType.toMediaType()

        val request: Request.Builder = Request.Builder()

        request.addHeader(APIConstants.HEADER_ACCEPT, APIConstants.APPLICATION_JSON)


        if (httpMethod == APIConstants.HTTP_REQUEST_TYPE_POST) {
            val body: RequestBody = payUNetworkData.postRequest!!.toRequestBody(mediaType)
            request.post(body)
            request.url(payUNetworkData.url!!)
        } else {
            var queryRequest = ""
            if (payUNetworkData.getRequest != null) {
                for ((key, value) in payUNetworkData.getRequest!!) {
                    queryRequest += "$key=$value&"
                }
            }
            request.url(payUNetworkData.url!! + "?${queryRequest.dropLast(1)}")
        }

        if (payUNetworkData.headerMap != null) {
            for ((key, value) in payUNetworkData.headerMap!!) {
                request.addHeader(key, value)

            }
        }
        call = client.newCall(request.build())
        call?.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                val handler = Handler(Looper.getMainLooper())
                val runnable = Runnable {
                    payUAsyncTaskResponse.onFailure(
                        SDK_RESPONSE_STATUS_CODE_1,
                        PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE,
                        Utils.getTimeDifferenceInMilliSeconds(startTime)
                    )
                }
                handler.post(runnable)
            }

            override fun onResponse(call: Call, response: Response) {
                val apiResponse = response.body?.string()
                val handler = Handler(Looper.getMainLooper())
                val runnable = Runnable {
                    if (response.code == PayUScannerErrorConstants.GATEWAY_TIMEOUT_ERROR_CODE) {
                        payUAsyncTaskResponse.onFailure(
                            PayUScannerErrorConstants.GATEWAY_TIMEOUT_ERROR_CODE,
                            PayUScannerErrorConstants.GATEWAY_TIMEOUT_ERROR_MESSAGE,
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    } else if (response.code >= PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_CODE) {
                        payUAsyncTaskResponse.onFailure(
                            PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_CODE,
                            PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE,
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    } else if (isValidJSON(apiResponse) && response.code == APIConstants.SUCCESS_API_CODE) {
                        payUAsyncTaskResponse.onSuccess(
                            if (apiResponse.isNullOrEmpty()) PayuScannerConstants.EMPTY_STRING else apiResponse,
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    } else if (isValidJSON(apiResponse) && response.code == APIConstants.BAD_REQUEST_API_CODE) {
                        payUAsyncTaskResponse.onFailure(
                            response.code,
                            if(JSONObject(apiResponse).optString(APIConstants.OUTLET_INFO_ERROR_MESSAGE).isNullOrEmpty())
                                PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE else JSONObject(apiResponse).optString(APIConstants.OUTLET_INFO_ERROR_MESSAGE),
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    } else {
                        payUAsyncTaskResponse.onFailure(
                            PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_CODE,
                            PayUScannerErrorConstants.SOMETHING_WENT_WRONG_ERROR_MESSAGE,
                            Utils.getTimeDifferenceInMilliSeconds(startTime)
                        )
                    }


                }
                handler.post(runnable)
            }
        })
    }

    private fun isValidJSON(response: String?): Boolean {
        try {
            JSONObject(response!!)
        } catch (e: Exception) {
            return false
        }
        return true
    }

}