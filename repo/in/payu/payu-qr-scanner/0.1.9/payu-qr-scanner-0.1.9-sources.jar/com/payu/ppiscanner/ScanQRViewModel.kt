package com.payu.ppiscanner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.ppiscanner.constants.APIConstants.Companion.INACTIVE_QR_ERROR_CODE
import com.payu.ppiscanner.interfaces.PayUScannerAPICallback
import com.payu.ppiscanner.model.OutletTxnDetails
import com.payu.ppiscanner.constants.LoggingConstants
import com.payu.ppiscanner.network.GetOutletDetailAPI
import com.payu.ppiscanner.constants.PayuScannerConstants
import com.payu.ppiscanner.utils.CleverTapLoggingUtils
import com.payu.ppiscanner.utils.ViewUtils

class ScanQRViewModel(
    application: Application
) : AndroidViewModel(application), PayUScannerAPICallback {

    private val _showAmountBottomSheetLiveData: MutableLiveData<OutletTxnDetails> =
        MutableLiveData<OutletTxnDetails>()
    val showAmountBottomSheetLiveData: LiveData<OutletTxnDetails> = _showAmountBottomSheetLiveData

    private val _onAPIFailureLiveData: MutableLiveData<Pair<Int, String>> =
        MutableLiveData<Pair<Int, String>>()
    val onAPIFailureLiveData: LiveData<Pair<Int, String>> = _onAPIFailureLiveData

    private val _onInvalidQRLiveData: MutableLiveData<Any> = MutableLiveData<Any>()
    val onInvalidQRLiveData: LiveData<Any> = _onInvalidQRLiveData

    private val _scannedQRWithAmount: MutableLiveData<OutletTxnDetails> =
        MutableLiveData<OutletTxnDetails>()
    val scannedQRWithAmount: LiveData<OutletTxnDetails> = _scannedQRWithAmount

    private val _noInternetLiveData: MutableLiveData<Any> = MutableLiveData()
    val noInternetLiveData: LiveData<Any> = _noInternetLiveData

    private val _keyErrorLiveData: MutableLiveData<String> = MutableLiveData()
    val keyErrorLiveData: LiveData<String> = _keyErrorLiveData

    init {
        if (PayUQRScanner.scannerConfig.key.isNullOrEmpty()) {
            val context = getApplication<Application>()
            _keyErrorLiveData.value =
                context.getString(R.string.payu_key_null_error)
        }
    }

    fun onQRScanResult(result: String) {
        var outletId: Int? = null
        val split1 = result.split("&")
        try {
            for (temp in split1) {
                if (temp.contains(PayuScannerConstants.QR_DATA_OUTLET_KEY)) {
                    val split2 = temp.split("=")
                    outletId = split2[1].toInt()
                }
            }
        } catch (ex: Exception) {

        }
        val context = getApplication<Application>()

        if (outletId == null) {
            _onInvalidQRLiveData.value = Any()
            CleverTapLoggingUtils.logAnalytics(
                context,
                LoggingConstants.QR_SCANNED,
                LoggingConstants.FAILURE
            )
        } else {
            CleverTapLoggingUtils.logAnalytics(
                context,
                LoggingConstants.QR_SCANNED,
                LoggingConstants.SUCCESS
            )
            onValidQRScanned(outletId)
        }
    }

    private fun onValidQRScanned(id: Int) {

        val context = getApplication<Application>()
        if (ViewUtils.isInternetAvailable(context)) {
            GetOutletDetailAPI().callAPI(id, this@ScanQRViewModel)
        } else {
            _noInternetLiveData.value = Any()
        }

    }

    override fun onSuccess(response: Any) {
        val outletTxnDetails = response as OutletTxnDetails

        if (outletTxnDetails.isActive == true) {
            if (PayUQRScanner.scannerConfig.amount == null || PayUQRScanner.scannerConfig.amount == 0.0) {
                _showAmountBottomSheetLiveData.value = outletTxnDetails
            } else {
                _scannedQRWithAmount.value = outletTxnDetails
            }
        } else {
            val context = getApplication<Application>()
             _onAPIFailureLiveData.value =  Pair(INACTIVE_QR_ERROR_CODE, context.getString(R.string.payu_inactive_qr_error))
            CleverTapLoggingUtils.logAnalytics(
                context,
                LoggingConstants.QR_SCANNED,
                LoggingConstants.FAILURE
            )
        }

    }

    override fun onError(errorCode: Int, errorMessage: String) {
        _onInvalidQRLiveData.value = Any()
    }
}