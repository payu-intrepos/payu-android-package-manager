package com.payu.ppiscanner

import android.Manifest
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.LifecycleCameraController
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import com.payu.ppiscanner.bottomsheet.QRAmountBottomSheet
import com.payu.ppiscanner.bottomsheet.QRErrorBottomSheet
import com.payu.ppiscanner.constants.LoggingConstants
import com.payu.ppiscanner.constants.PayUScannerErrorConstants
import com.payu.ppiscanner.constants.PayuScannerConstants
import com.payu.ppiscanner.constants.PayuScannerConstants.Companion.APP_SETTING_PACKAGE
import com.payu.ppiscanner.databinding.ActivityScanQrBinding
import com.payu.ppiscanner.interfaces.QRAmountBottomSheetListener
import com.payu.ppiscanner.interfaces.QRErrorBottomSheetListener
import com.payu.ppiscanner.model.QRErrorType
import com.payu.ppiscanner.utils.CleverTapLoggingUtils
import com.payu.ppiscanner.utils.LoggingUtils

class ScanQRActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanQrBinding
    private val PERMISSION_CAMERA_REQUEST_CODE = 200
    private lateinit var cameraHelper: CameraHelper
    private lateinit var activityLauncher: ActivityResultLauncher<Intent>

    private lateinit var viewModel: ScanQRViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanQrBinding.inflate(layoutInflater)
        setContentView(binding.root)
        CleverTapLoggingUtils.logAnalytics(this, LoggingConstants.QR_SCANNER_OPENED)
        initViewModel()
        initClickListeners()
        registerActivityLauncher()

        if (checkPermission()) {
            val cameraController =
                LifecycleCameraController(this)
            cameraController.bindToLifecycle(CustomLifecycle())

            resumeCamera()
        } else {
            requestCameraPermission()
        }

    }

    private fun registerActivityLauncher() {
        activityLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { requestCameraPermission() }
    }

    private fun initClickListeners() {
        binding.ivClose.setOnClickListener {
            finish()
        }
    }

    private fun initViewModel() {
        viewModel = ViewModelProvider(this).get(ScanQRViewModel::class.java)
        viewModel.showAmountBottomSheetLiveData.observe(this) { res ->

            binding.progressBar.visibility = View.GONE
            binding.qrPreviewView.visibility = View.GONE
            val amountBottomSheet = QRAmountBottomSheet.Builder(
                supportFragmentManager,
                PayuScannerConstants.BOTTOM_SHEET_FRAGMENT
            )

            amountBottomSheet.setListener(object : QRAmountBottomSheetListener {
                override fun proceedAndPay(amount: Double) {
                    res.amount = amount
                    PayUQRScanner.payUScannerListener?.onSuccess(res)
                    finish()
                }

                override fun onClose() {
                    finish()
                }
            })
            amountBottomSheet.setMerchantName(res.outletName)
            PayUQRScanner.scannerConfig.merchantLogoUrl?.let {
                amountBottomSheet.setImageUrl(it)
            }
            PayUQRScanner.scannerConfig.merchantLogoDrawable?.let {
                amountBottomSheet.setImageDrawable(it)
            }

            amountBottomSheet.build().show()
        }

        viewModel.scannedQRWithAmount.observe(this) {
            binding.progressBar.visibility = View.GONE
            PayUQRScanner.payUScannerListener?.onSuccess(it)
            finish()
        }

        viewModel.onAPIFailureLiveData.observe(this) { error ->
            binding.progressBar.visibility = View.GONE
            PayUQRScanner.payUScannerListener?.onFailure(error.first, error.second)
            finish()
        }

        viewModel.onInvalidQRLiveData.observe(this) {
            binding.progressBar.visibility = View.GONE
            binding.qrPreviewView.visibility = View.GONE
            val invalidBottomSheet = QRErrorBottomSheet.Builder(
                supportFragmentManager,
                PayuScannerConstants.BOTTOM_SHEET_FRAGMENT,
                QRErrorType.INVALID_QR
            )
            invalidBottomSheet.setListener(object : QRErrorBottomSheetListener {
                override fun rescanQR() {
                    binding.qrPreviewView.visibility = View.VISIBLE
                    resumeCamera()
                }

                override fun close() {
                    finish()
                }
            })
            invalidBottomSheet.build().show()
        }

        viewModel.noInternetLiveData.observe(this) {
            binding.progressBar.visibility = View.GONE
            binding.qrPreviewView.visibility = View.GONE
            val noInternetBottomSheet = QRErrorBottomSheet.Builder(
                supportFragmentManager,
                PayuScannerConstants.BOTTOM_SHEET_FRAGMENT,
                QRErrorType.INTERNET_ISSUE
            )
            noInternetBottomSheet.setListener(object : QRErrorBottomSheetListener {
                override fun rescanQR() {
                    binding.qrPreviewView.visibility = View.VISIBLE
                    resumeCamera()
                }

                override fun close() {
                    finish()
                }
            })
            noInternetBottomSheet.build().show()
        }

        viewModel.keyErrorLiveData.observe(this) {
            PayUQRScanner.payUScannerListener?.onFailure(
                PayUScannerErrorConstants.SDK_RESPONSE_STATUS_CODE_1,
                it
            )
            finish()
        }
    }

    private fun resumeCamera() {
        cameraHelper = CameraHelper(
            owner = this, context = this,
            viewFinder = binding.qrPreviewView,
            onResult = ::onResult,
            onError = ::onError
        )
        cameraHelper.start()
    }

    private fun onError(errorCode: Int, errorMessage: String) {
        PayUQRScanner.payUScannerListener?.onFailure(
            errorCode = errorCode,
            errorMessage = errorMessage
        )
    }

    private fun onResult(result: String) {
        cameraHelper.stop()

        LoggingUtils.logMessage(
            this,
            LoggingConstants.QR_SCANNER_KEY,
            result
        )
        binding.progressBar.visibility = View.VISIBLE
        viewModel.onQRScanResult(result)
    }

    private fun checkPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf<String>(Manifest.permission.CAMERA),
            PERMISSION_CAMERA_REQUEST_CODE
        )
    }

    class CustomLifecycle : LifecycleOwner {
        private val lifecycleRegistry: LifecycleRegistry = LifecycleRegistry(this)

        init {
            lifecycleRegistry.markState(Lifecycle.State.CREATED)
        }

        override fun getLifecycle(): Lifecycle {
            return lifecycleRegistry
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_CAMERA_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    val cameraController =
                        LifecycleCameraController(this)
                    cameraController.bindToLifecycle(CustomLifecycle())

                    resumeCamera()
                } else {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val showRationale =
                            shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
                        if (showRationale) {
                            showMessageOKCancel(
                                message = getString(R.string.payu_camera_permission_hint),
                                okListener = { dialog, which ->
                                    requestCameraPermission()
                                },
                                cancelListener = { dialog, which ->
                                    finish()
                                })
                        } else {
                            showMessageOKCancel(
                                message = getString(R.string.payu_camera_permission_mandatory),
                                okListener = { dialog, which ->
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        openSettingsForPermission()
                                    }
                                },
                                cancelListener = { dialog, which ->
                                    finish()
                                })
                        }

                    }
                }
            }
        }
    }

    private fun openSettingsForPermission() {

        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts(APP_SETTING_PACKAGE, packageName, null)
        intent.data = uri
        activityLauncher.launch(intent)
    }

    private fun showMessageOKCancel(
        message: String,
        okListener: DialogInterface.OnClickListener,
        cancelListener: DialogInterface.OnClickListener
    ) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(getString(R.string.payu_ok), okListener)
            .setNegativeButton(getString(R.string.payu_cancel), cancelListener)
            .setCancelable(false)
            .create()
            .show()
    }
}