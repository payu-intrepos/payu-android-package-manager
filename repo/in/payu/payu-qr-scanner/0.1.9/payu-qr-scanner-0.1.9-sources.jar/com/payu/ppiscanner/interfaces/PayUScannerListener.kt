package  com.payu.ppiscanner.interfaces

import androidx.annotation.Keep
import com.payu.ppiscanner.model.OutletTxnDetails

@Keep
interface PayUScannerListener{
    fun onSuccess(result: OutletTxnDetails)
    fun onFailure(errorCode: Int, errorMessage: String)

    fun generateHash(
        map: HashMap<String, String?>,
        scannerHashGeneratedListener: ScannerHashGeneratedListener
    )

}