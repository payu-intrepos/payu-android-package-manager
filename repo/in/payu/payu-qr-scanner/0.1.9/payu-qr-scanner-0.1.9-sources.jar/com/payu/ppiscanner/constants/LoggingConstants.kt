package com.payu.ppiscanner.constants

import androidx.annotation.Keep

@Keep
class LoggingConstants {
    @Keep
    companion object {

        const val SCANNER_EVENT_KEY = "event_key"
        const val SCANNER_EVENT_VALUE = "event_value"
        const val SCANNER_TIMESTAMP = "ts"
        const val SDK_INTEGRATION = "sdkIntegration"
        const val SCANNER_SDK_VERSION = "SDK version"
        const val SCANNER_APPLICATION_VERSION = "application_version"
        const val SCANNER_LOGGING_SDK = "loggingSDK"
        const val SCANNER_TXN_ID = "txnid"
        const val SCANNER_MERCHANT_KEY = "merchant_key"
        const val SCANNER_DEVICE_DETAILS = "device_details"
        const val DD_MM_YY_HH_MM_SS_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss"

        const val QR_SCANNER_KEY = "QR Scanner"
        const val QR_SCANNED = "QR Scanned"

        const val QR_SCANNER_OPENED = "QR scanner opened"
        const val QR_EVENT_NAME = "evtName"
        const val QR_IDENTITY = "identity"
        const val QR_TYPE = "type"
        const val QR_MERCHANT_IDENTIFIER = "Merchant Identifier"
        const val QR_DEVICE = "Device"
        const val QR_DEVICE_NAME = "Device name"
        const val QR_DEVICE_VERSION = "Device version"
        const val QR_EVENT = "event"
        const val QR_ANDROID = "Android"
        const val QR_SDK_VERSION = "SDK version"
        const val QR_TXNID = "Transaction identifier"
        const val QR_EVENT_DATA = "evtData"
        const val QR_PACKAGE_CORE = "com.payu.ppiscanner"
        const val QR_DEVICE_DETAILS_STATUS = "status"
        const val SUCCESS = "success"
        const val FAILURE = "failure"
    }
}