package com.payu.ppiscanner.widgets

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.payu.ppiscanner.R
import com.payu.ppiscanner.managers.BottomSheetManager
import com.payu.ppiscanner.constants.PayuScannerConstants

class RoundedCornerBottomSheet: BottomSheetDialogFragment() {
    override fun getTheme(): Int = R.style.PayU_BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

    var bottomSheetListener: OnBottomSheetListener? = null
    var layoutId: Int? = null

    fun setListener(bottomSheetListener: OnBottomSheetListener) {
        this.bottomSheetListener = bottomSheetListener
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (bottomSheetListener == null && context is OnBottomSheetListener) {
            this.bottomSheetListener = context
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            layoutId = it.getInt(PayuScannerConstants.LAYOUT_ID)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(layoutId!!, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         * @return A new instance of fragment RoundedCornerBottomSheet.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(layoutId: Int) =
            RoundedCornerBottomSheet().apply {
                arguments = Bundle().apply {
                    putInt(PayuScannerConstants.LAYOUT_ID, layoutId)
                }
            }

        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         * @return A new instance of fragment RoundedCornerBottomSheet.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(layoutId: Int, manager: BottomSheetManager) =
            RoundedCornerBottomSheet().apply {
                arguments = Bundle().apply {
                    putInt(PayuScannerConstants.LAYOUT_ID, layoutId)
                }
                bottomSheetListener = manager
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bottomSheetListener?.getInflatedView(view, this)
    }

    interface OnBottomSheetListener {
        fun getInflatedView(view: View, roundedCornerBottomSheet: RoundedCornerBottomSheet)
        fun handleBottomSheetClose()
    }

    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
        bottomSheetListener?.handleBottomSheetClose()
    }
}