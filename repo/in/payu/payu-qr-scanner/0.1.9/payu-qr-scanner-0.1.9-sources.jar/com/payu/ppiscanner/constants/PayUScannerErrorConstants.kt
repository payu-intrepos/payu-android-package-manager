package com.payu.ppiscanner.constants

import androidx.annotation.Keep

@Keep
class PayUScannerErrorConstants {
    @Keep
    companion object {
        const val SDK_RESPONSE_STATUS_CODE_1 = 1
        const val REQUEST_BODY_CANNOT_BE_NULL = "Request body missing"
        const val REST_API_PATH_CANNOT_BE_NULL = "API endpoint path missing"
        const val SOMETHING_WENT_WRONG_ERROR_MESSAGE = "Something went wrong, please try again"
        const val GATEWAY_TIMEOUT_ERROR_CODE = 504
        const val GATEWAY_TIMEOUT_ERROR_MESSAGE = "Gateway timeout."
        const val SOMETHING_WENT_WRONG_ERROR_CODE = 500
    }
}