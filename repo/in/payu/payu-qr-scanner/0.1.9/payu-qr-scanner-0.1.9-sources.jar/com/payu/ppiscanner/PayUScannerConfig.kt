package com.payu.ppiscanner

import androidx.annotation.Keep

@Keep
class PayUScannerConfig(
    var key: String?,
    var isProduction: Boolean,
    val amount: Double?,
    var primaryColor: String? = null,
    var baseTextColor: String? = null,
    var merchantLogoUrl: String? = null,
    var merchantLogoDrawable: Int? = null,
    var txnId: String? = null
)