package com.payu.ppiscanner.utils

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.view.View
import android.widget.Button
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.payu.ppiscanner.R

object ViewUtils {

    fun updateBackgroundColor(context: Context, view: View?, color: String?, defaultColor: Int) {
        if (!color.isNullOrEmpty() && HexColorValidator.validate(color)
            && view != null && view.background != null
        ) {
            val unwrappedDrawable: Drawable? =
                view.background
            val wrappedDrawable: Drawable = DrawableCompat.wrap(unwrappedDrawable!!)
            wrappedDrawable.mutate()
            DrawableCompat.setTint(wrappedDrawable, Color.parseColor(color))
        } else {
            val unwrappedDrawable: Drawable? =
                view?.background
            unwrappedDrawable?.let {
                val wrappedDrawable: Drawable = DrawableCompat.wrap(unwrappedDrawable)
                wrappedDrawable.mutate()
                DrawableCompat.setTint(wrappedDrawable, context.resources.getColor(defaultColor))
            }
        }
    }

    fun updateButtonTextColor(view: Button?, color: String?) {
        if (!color.isNullOrEmpty() && view != null &&
            !view.text.isNullOrEmpty() && HexColorValidator.validate(color)
        ) {
            view.setTextColor(Color.parseColor(color))
        }
    }

    fun isInternetAvailable(context: Context?): Boolean {
        var result = false

        if (context == null)
            return result

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            result = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_WIFI -> true
                        ConnectivityManager.TYPE_MOBILE -> true
                        ConnectivityManager.TYPE_ETHERNET -> true
                        else -> false
                    }

                }
            }
        }

        return result
    }

    fun updateStrokeColor(context: Context, view: View?, color: Int = R.color.payu_color_338f9dbd) {
        if (view != null && view.background != null) {
            val drawable: GradientDrawable = view.background as GradientDrawable
            drawable.mutate()
            drawable.setStroke(
                3,
                ContextCompat.getColor(context, color)
            )
        }
    }

    fun enableView(view: View?) {
        view?.alpha = 1f
        view?.isEnabled = true
    }

    fun disableView(view: View?) {
        view?.alpha = 0.5f
        view?.isEnabled = false
    }
}