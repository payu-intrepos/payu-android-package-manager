package com.payu.ppiscanner.interfaces

interface QRErrorBottomSheetListener {
    fun rescanQR()
    fun close()
}