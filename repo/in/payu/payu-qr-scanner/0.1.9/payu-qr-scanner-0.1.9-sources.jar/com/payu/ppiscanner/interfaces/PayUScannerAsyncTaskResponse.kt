package com.payu.ppiscanner.interfaces

interface PayUScannerAsyncTaskResponse {
    fun onSuccess(response: Any, executionTime: Long)
    fun onFailure(errorCode: Int, errorMessage: String, executionTime: Long)
}