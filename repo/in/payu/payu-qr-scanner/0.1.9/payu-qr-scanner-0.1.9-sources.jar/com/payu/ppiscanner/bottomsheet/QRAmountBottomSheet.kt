package com.payu.ppiscanner.bottomsheet

import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import com.payu.assetprovider.AssetManager
import com.payu.assetprovider.BitmapCallback
import com.payu.ppiscanner.PayUQRScanner
import com.payu.ppiscanner.R
import com.payu.ppiscanner.interfaces.QRAmountBottomSheetListener
import com.payu.ppiscanner.utils.DecimalDigitsInputFilter
import com.payu.ppiscanner.utils.ImageViewUtils
import com.payu.ppiscanner.utils.Utils
import com.payu.ppiscanner.utils.ViewUtils
import com.payu.ppiscanner.widgets.RoundedCornerBottomSheet


class QRAmountBottomSheet(
    private val fragmentManager: FragmentManager,
    private val tag: String,
    private val roundedCornerBottomSheet: RoundedCornerBottomSheet
) {
    fun show() {
        roundedCornerBottomSheet.isCancelable = false
        roundedCornerBottomSheet.show(fragmentManager, tag)
    }

    fun close() {
        roundedCornerBottomSheet.dismissAllowingStateLoss()
    }


    class Builder(private val fragmentManager: FragmentManager, val tag: String) :
        RoundedCornerBottomSheet.OnBottomSheetListener,
        View.OnFocusChangeListener {

        private lateinit var tvMerchantName: TextView
        private lateinit var tvErrorText: TextView
        private lateinit var ivMerchantLogo: ImageView
        private lateinit var ivClose: ImageView
        private lateinit var etAmount: EditText
        private lateinit var btnProceedToPay: Button
        private var merchantName: String? = null
        private var imageURL: String? = null
        private var imageDrawable: Int? = null
        private lateinit var listener: QRAmountBottomSheetListener

        fun setListener(listener: QRAmountBottomSheetListener) {
            this.listener = listener
        }

        fun setMerchantName(name: String?) {
            this.merchantName = name
        }
        fun setImageUrl(url: String) {
            this.imageURL = url
        }
        fun setImageDrawable(drawable: Int) {
            this.imageDrawable = drawable
        }

        fun build(): QRAmountBottomSheet {

            val roundedCornerBottomSheet = RoundedCornerBottomSheet.newInstance(
                R.layout.payu_amount_bottomsheet
            )
            roundedCornerBottomSheet.setListener(this)
            return QRAmountBottomSheet(fragmentManager, tag, roundedCornerBottomSheet)

        }

        override fun getInflatedView(
            view: View,
            roundedCornerBottomSheet: RoundedCornerBottomSheet
        ) {
            tvMerchantName = view.findViewById(R.id.tv_merchant_name)
            ivMerchantLogo = view.findViewById(R.id.iv_payu_qr_merchant_logo)
            etAmount = view.findViewById(R.id.et_payu_qr_bottomsheet_amount)
            ivClose = view.findViewById(R.id.iv_payu_qr_bottomsheet_close)
            tvErrorText = view.findViewById(R.id.tv_payu_qr_bottomsheet_error)
            btnProceedToPay = view.findViewById(R.id.btn_payu_qr_bottomsheet_proceedtopay)
            etAmount.onFocusChangeListener = this

            if (imageURL != null) {
                AssetManager.getInstance(ivMerchantLogo.context)
                    .getBitmapFromURL(imageURL!!, object : BitmapCallback {

                        override fun onBitmapReceived(
                            types: String,
                            data: com.payu.assetprovider.model.ImageDetails
                        ) {
                            ImageViewUtils.setImage(ivMerchantLogo, data)
                        }
                    })
            } else if (imageDrawable != null) {
                ivMerchantLogo.setImageResource(imageDrawable!!)
            } else {
                ivMerchantLogo.visibility = View.GONE
            }

            merchantName?.let {
                tvMerchantName.text = it
            }

            ViewUtils.updateBackgroundColor(
                btnProceedToPay.context,
                btnProceedToPay,
                PayUQRScanner.scannerConfig.primaryColor,
                R.color.payu_color_25272C
            )


            ViewUtils.updateButtonTextColor(
                btnProceedToPay,
                PayUQRScanner.scannerConfig.baseTextColor,
            )

            showValidAmountView()
            ViewUtils.disableView(btnProceedToPay)

            etAmount.filters = arrayOf<InputFilter>(DecimalDigitsInputFilter(10, 2))

            addListeners(view, roundedCornerBottomSheet)

            etAmount.requestFocus()
        }


        private fun addListeners(v: View?, roundedCornerBottomSheet: RoundedCornerBottomSheet) {

            etAmount.addTextChangedListener( object: TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun afterTextChanged(p0: Editable?) {
                    if (!Utils.isValidAmount(etAmount.text.toString())) {
                        setError("Invalid Amount")
                        ViewUtils.disableView(btnProceedToPay)
                    } else {
                        ViewUtils.enableView(btnProceedToPay)
                        showValidAmountView()
                    }
                }

            })

            btnProceedToPay.setOnClickListener {
                roundedCornerBottomSheet.dismiss()
                if (Utils.isValidAmount(etAmount.text.toString())) {
                    listener.proceedAndPay(etAmount.text.toString().toDouble())
                }
            }
            ivClose.setOnClickListener {
                listener.onClose()
            }

        }


        override fun handleBottomSheetClose() {

        }


        private fun showValidAmountView() {
            tvErrorText.text = ""
            ViewUtils.updateStrokeColor(
                etAmount.context,
                etAmount,
                R.color.payu_color_25272C
            )
            tvErrorText.visibility = View.GONE
        }


        private fun setError(message: String) {
            tvErrorText.text = message
            ViewUtils.updateStrokeColor(
                etAmount.context,
                etAmount,
                R.color.payu_color_de350b
            )
            tvErrorText.visibility = View.VISIBLE
        }

        override fun onFocusChange(p0: View?, p1: Boolean) {

        }
    }
}