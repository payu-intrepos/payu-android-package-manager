package com.payu.ppiscanner.utils

import android.content.Context
import android.os.Build
import com.payu.payuanalytics.analytics.factory.AnalyticsFactory
import com.payu.payuanalytics.analytics.model.AnalyticsConfig
import com.payu.payuanalytics.analytics.model.AnalyticsType
import com.payu.payuanalytics.analytics.model.ClevertapAnalytics
import com.payu.ppiscanner.BuildConfig
import com.payu.ppiscanner.PayUQRScanner
import com.payu.ppiscanner.constants.LoggingConstants
import org.json.JSONObject

object CleverTapLoggingUtils {
    private var clevertapAnalytics: ClevertapAnalytics? = null

    fun logAnalytics(
        context: Context,
        eventName: String,
        status: String = "",
    ) {

        if (clevertapAnalytics == null) {
            clevertapAnalytics =
                AnalyticsFactory(context, AnalyticsConfig().apply {
                    initiatorIdentifier = LoggingConstants.QR_PACKAGE_CORE
                    ctAccountId =
                        Utils.getWizRocketID().first + "-" + Utils.getWizRocketID().second + "-" + Utils.getWizRocketID().third
                    ctPassCode =
                        Utils.getWizRocketPass().first + "-" + Utils.getWizRocketPass().second + "-" + Utils.getWizRocketPass().third
                }).getAnalyticsClass(AnalyticsType.CLEVERTAP) as ClevertapAnalytics
        }

        val eventMap = HashMap<String, Any>()
        val eventData = HashMap<String, Any>()
        val txnId = PayUQRScanner.scannerConfig.txnId
        val merchantKey = PayUQRScanner.scannerConfig.key
        eventMap[LoggingConstants.QR_EVENT_NAME] = eventName
        eventMap[LoggingConstants.QR_IDENTITY] = txnId.plus(merchantKey)
        eventMap[LoggingConstants.QR_TYPE] = LoggingConstants.QR_EVENT
        if (!status.isEmpty())
            eventData[LoggingConstants.QR_DEVICE_DETAILS_STATUS] = status
        merchantKey?.let {
            eventData[LoggingConstants.QR_MERCHANT_IDENTIFIER] = it
        }
        eventData[LoggingConstants.QR_DEVICE] = LoggingConstants.QR_ANDROID
        eventData[LoggingConstants.QR_DEVICE_NAME] =
            Build.MANUFACTURER.plus(" " + Build.MODEL)
        eventData[LoggingConstants.QR_DEVICE_VERSION] = Build.VERSION.RELEASE
        eventData[LoggingConstants.QR_SDK_VERSION] = BuildConfig.VERSION_NAME
        txnId?.let {
            eventData[LoggingConstants.QR_TXNID] = it
        }

        eventMap[LoggingConstants.QR_EVENT_DATA] = eventData
        clevertapAnalytics?.log(JSONObject(eventMap as Map<*, *>?).toString())
    }

}