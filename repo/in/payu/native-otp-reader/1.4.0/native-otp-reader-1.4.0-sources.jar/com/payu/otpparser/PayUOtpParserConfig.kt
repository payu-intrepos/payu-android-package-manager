package com.payu.otpparser

object PayUOtpParserConfig {
    var otpCallback: OtpCallback? = null
}