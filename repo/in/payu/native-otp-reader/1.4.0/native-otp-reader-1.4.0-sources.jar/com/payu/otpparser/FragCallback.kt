package com.payu.otpparser
import android.content.Intent

interface FragCallback {
    fun onFragCallback(intent: Intent?, requestCode: Int)
}