package com.payu.otpparser

interface OtpHandlerCallback {

    fun lifeCycleOnDestroy()
}