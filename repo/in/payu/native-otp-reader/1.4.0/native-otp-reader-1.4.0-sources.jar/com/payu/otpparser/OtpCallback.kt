package com.payu.otpparser

interface OtpCallback {
    fun onOtpReceived(otp: String)
    fun onUserDenied()
}