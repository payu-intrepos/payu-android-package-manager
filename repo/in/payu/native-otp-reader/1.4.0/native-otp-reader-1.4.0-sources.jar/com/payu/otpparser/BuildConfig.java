/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.otpparser;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.otpparser";
  public static final String BUILD_TYPE = "release";
}
