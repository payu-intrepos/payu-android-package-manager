package com.payu.otpparser

import android.util.Log

object L {
    val isLogEnabled = Log.isLoggable("PAYU-OTP", Log.VERBOSE)
    fun v(message: String) {
        if (isLogEnabled) Log.v("PAYU-OTP", message)
    }

}