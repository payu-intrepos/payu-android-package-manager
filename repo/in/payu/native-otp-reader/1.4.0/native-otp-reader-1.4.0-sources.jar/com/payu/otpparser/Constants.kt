package com.payu.otpparser

object Constants {
    const val PACKAGE_NAME = "package_name"
    const val EVENT_KEY = "event_key"
    const val VALUE = "event_value"
    const val TIMESTAMP = "ts"
    const val VERSION_CODE = "application_version"
    const val OTP_PARSER_SDK_EVENT = "otp_parser_sdk_event"
    const val TXNID = "txnid"
    const val MERCHANT_KEY = "merchant_key"
    const val CONSENT_FAILURE = "consent_failure"
    const val OTP_FETCHED_CONSENT = "otp_fetched_consent"
    const val USER_DENIED_CONSENT = "user_denied_consent"
    const val PERMISSION_GRANTED_SMS_RECEIVE = "permission_granted_receiver"
    const val PERMISSION_DENIED_SMS_RECEIVE = "permission_denied_receiver"
    const val OTP_FETCHED_RECEIVER = "otp_fetched_receiver"
    const val OTP_FETCH_FAILED_RECEIVER = "otp_fetch_failed_receiver"
    const val REQUESTED_CONSENT_PERMISSION = "requested_consent_permission"
    const val REQUESTED_SMS_PERMISSION = "requested_sms_permission"
    const val PERMISSION_GRANTED_ALREADY = "permission_granted_already"
    const val NATIVE_SMS_READER_PERMISSION_ID = 101
}