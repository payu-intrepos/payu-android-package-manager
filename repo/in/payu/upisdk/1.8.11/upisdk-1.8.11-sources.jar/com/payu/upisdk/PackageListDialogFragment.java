package com.payu.upisdk;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.custombar.CircularProgressViewUpiSdk;
import com.payu.upisdk.upi.IValidityCheck;
import com.payu.upisdk.upiintent.PackageBean;
import com.payu.upisdk.upiintent.PackageListAdapter;
import com.payu.upisdk.upiintent.PaymentResponse;
import com.payu.upisdk.upiintent.PaymentResponseUpiSdkActivity;
import com.payu.upisdk.upiintent.UPIPaymentConstants;
import com.payu.upisdk.upiinterface.GenericUPICallbacks;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.PayUUpiUtil;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by himanshu.gupta on 07/05/18.
 * This Activity used as a dialog to show the list of UPI handling apps. The merchant can choose one of them for payment.
 * Also giving option to provide vpa for Collect flow.
 */
public class PackageListDialogFragment extends DialogFragment implements View.OnClickListener, TextWatcher, PayuNetworkAsyncTaskInterface, IValidityCheck {
    private RecyclerView recyclerView;
    private ArrayList<PackageBean> list;
    private LinearLayout layoutVpa;
    private LinearLayout layoutAppSelector;
    private LinearLayout llPayment;
    private LinearLayout llSeparator;
    private RelativeLayout rlInputVpa;
    private TextView tvMakePayment;
    private TextView tvHeading;
    private Activity mActivity;
    private PaymentResponse paymentResponse;
    boolean shouldEnableButton;
    private EditText editVpa;
    private UpiConfig upiConfig;
    private TextView tvVerifyVpa;
    private TextView tvVpaName;
    private ImageView ivVpaSuccess;
    private boolean isValidPaymentMethodPresent = true;
    private StringBuilder vpaRegex;
    private CircularProgressViewUpiSdk cbProgress;
    private String payeeName = "";
    private static GenericUPICallbacks genericUPICallbacks;

    public static PackageListDialogFragment newInstance(ArrayList<PackageBean> list, PaymentResponse paymentResponse, UpiConfig upiConfig, GenericUPICallbacks genericUPICallback) {
        PackageListDialogFragment packageListDialogFragment = new PackageListDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("list", list);
        bundle.putParcelable(UpiConstant.CB_CONFIG, upiConfig);
        bundle.putParcelable("paymentResponse", paymentResponse);
        packageListDialogFragment.setArguments(bundle);
        genericUPICallbacks = genericUPICallback;
        return packageListDialogFragment;
    }


    public PackageListDialogFragment() {
        setRetainInstance(true);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.cb_layout_generic_upi, container,
                false);
        initViews(rootView);
        if (null != getArguments() && null != getArguments().get("list"))
            list = getArguments().getParcelableArrayList("list");
        paymentResponse = getArguments().getParcelable("paymentResponse");
        upiConfig = getArguments().getParcelable(UpiConstant.CB_CONFIG);
        hideUPICollect();
        return rootView;
    }




    @Override
    public void show(FragmentManager manager, String tag) {
        try {
            FragmentTransaction ft = manager.beginTransaction();
            ft.add(this, tag);
            ft.commitAllowingStateLoss();
        } catch (IllegalStateException e) {
            Log.d("PAYU", "Exception", e);
        }
    }

    /**
     * @param rootView, View
     */
    private void initViews(View rootView) {
        //Inflated custom xml , can do whatever we require.
        recyclerView = rootView.findViewById(R.id.rvApps);
        layoutVpa = rootView.findViewById(R.id.ll_vpa);
        layoutAppSelector = rootView.findViewById(R.id.ll_app_selector);
        rlInputVpa = rootView.findViewById(R.id.rlInputVpa);
        llPayment = rootView.findViewById(R.id.llPayment);
        llSeparator = rootView.findViewById(R.id.ll_separator);
        editVpa = rootView.findViewById(R.id.edit_vpa);
        tvMakePayment = rootView.findViewById(R.id.tv_vpa_submit);
        tvHeading = rootView.findViewById(R.id.tvHeading);
        tvVerifyVpa = rootView.findViewById(R.id.tvVerifyVpa);
        tvVpaName = rootView.findViewById(R.id.tvVpaName);
        cbProgress = rootView.findViewById(R.id.upi_progressBar);
        ivVpaSuccess = rootView.findViewById(R.id.ivVpaSuccess);
    }

    private void showProgressBar() {
        cbProgress.setVisibility(View.VISIBLE);
        cbProgress.setIndeterminate(true);
        cbProgress.setColor(getResources().getColor(R.color.cb_progress_bar_color));
        cbProgress.startAnimation();
    }

    @Override
    public void onAttach(@NotNull Activity activity) {
        super.onAttach(activity);
        this.mActivity = activity;
        PayUUpiUtil.updateLayoutSecurity(requireActivity(), upiConfig != null && upiConfig.isProtectedScreen());
    }

    @Override
    public void onDetach() {
        super.onDetach();
        PayUUpiUtil.updateLayoutSecurity(requireActivity(), false);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (null != getDialog() && getDialog().getWindow() != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            getDialog().getWindow().setLayout(width, height);
            getDialog().getWindow().setGravity(Gravity.BOTTOM);
            getDialog().setCanceledOnTouchOutside(false);
            getDialog().getWindow().setWindowAnimations(
                    R.style.upi_sdk_dialog_slide_animation);
            if (mActivity != null) {
                final View rootView = mActivity.getWindow().getDecorView().getRootView();
                L.v("RootView " + rootView);
           /*     rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        Rect r = new Rect();
                        //r will be populated with the coordinates of your view that area still visible.
                        L.v("RootView onGlobalLayout "+rootView);
                        rootView.getWindowVisibleDisplayFrame(r);
                        int heightDiff = rootView.getRootView().getHeight() - (r.bottom - r.top);
                        L.v("RootView Height "+rootView.getRootView().getHeight()+"   Diff: "+heightDiff+ "    Bottom: "+r.bottom +"   Top: "+r.top);
                        if (heightDiff < rootView.getRootView().getHeight() / 4) { // if more than 100 pixels, its probably a keyboard...
                            // ... do something here ... \\
                            if (isEditVpa && editVpa.getText().toString().trim().isEmpty() && !isCollectShownAlways) {
                                isEditVpa = false;
                                hideUPICollect();
                            }
                        } else {
                            isEditVpa = true;
                            scrollView.post(new Runnable() {
                                @Override
                                public void run() {

                                    scrollView.fullScroll(View.FOCUS_DOWN);
                                    editVpa.requestFocus();
                                }
                            });
                        }
                    }
                });*/
            }
        } else {

            L.v("Else");
        }
        if (list != null && list.size() > 0) {
            layoutAppSelector.setVisibility(View.VISIBLE);
            recyclerView.setLayoutManager(new GridLayoutManager(mActivity, 3));
            recyclerView.setAdapter(new PackageListAdapter(list, mActivity, this, genericUPICallbacks));
        } else {
            if (null != UpiData.SINGLETON.getUpiConfig() && UpiData.SINGLETON.getUpiConfig().getDisableIntentSeamlessFailure() == UpiConfig.DISABLE && paymentResponse.getDisableIntentSeamlessFailure() != null && paymentResponse.getDisableIntentSeamlessFailure().equalsIgnoreCase("0")) {
                showUPICollect(false);
                layoutAppSelector.setVisibility(View.GONE);
                llSeparator.setVisibility(View.INVISIBLE);
            } else {
                isValidPaymentMethodPresent = false;
                getDialog().cancel();
            }

        }

        if (null != UpiData.SINGLETON.getUpiConfig() && UpiData.SINGLETON.getUpiConfig().getDisableIntentSeamlessFailure() == UpiConfig.DISABLE && paymentResponse.getDisableIntentSeamlessFailure() != null && paymentResponse.getDisableIntentSeamlessFailure().equalsIgnoreCase("0")) {
            showUPICollect(true);
            layoutVpa.setVisibility(View.VISIBLE);
            tvMakePayment.setEnabled(false);
            tvMakePayment.setOnClickListener(this);
        } else {
            layoutVpa.setVisibility(View.GONE);
            llSeparator.setVisibility(View.INVISIBLE);
        }
     /*   if (paymentResponse.getDisableIntentSeamlessFailure() != null && paymentResponse.getDisableIntentSeamlessFailure().equalsIgnoreCase("1")) {
            layoutVpa.setVisibility(View.GONE);
            llSeparator.setVisibility(View.INVISIBLE);
        } else {
            layoutVpa.setVisibility(View.VISIBLE);
            tvMakePayment.setEnabled(false);
            tvMakePayment.setOnClickListener(this);
        }*/
        if (paymentResponse.getCombineVerifyAndPayButton() != null && paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("1")) {
            tvVerifyVpa.setVisibility(View.GONE);
            disablePaymentButton();
        } else {
            tvVerifyVpa.setVisibility(View.GONE);
            tvVerifyVpa.setOnClickListener(this);
            tvMakePayment.setEnabled(false);
            tvMakePayment.setAlpha(0.35f);
        }
        vpaRegex = new StringBuilder();
        if (!TextUtils.isEmpty(paymentResponse.getVpaRegex())) {
            vpaRegex.append(paymentResponse.getVpaRegex());
            if (vpaRegex.charAt(0) == '/')
                vpaRegex.deleteCharAt(0);
            if (vpaRegex.charAt(vpaRegex.length() - 1) == '/')
                vpaRegex.deleteCharAt(vpaRegex.length() - 1);
        } else {
            vpaRegex.append(UPIPaymentConstants.VPA_REGEX_DEFAULT);
        }
        editVpa.addTextChangedListener(this);
        if (shouldEnableButton)
            enablePaymentButton();
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.tv_vpa_submit) {
            if (paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("1")) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Requesting Vpa tv_vpa_submit");
                requestValidateVPA();

            } else {
                L.v("Class Name: " + getClass().getCanonicalName() + "Proceed  Vpa tv_vpa_submit");
                proceedVPACollect();
            }
        } else if (view.getId() == R.id.tvVerifyVpa) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Proceed  Vpa tvVerifyVpa");
            requestValidateVPA();
        }/* else if (view.getId() == R.id.tvHeading) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Proceed  Vpa tvHeading");
            showUPICollect(true);
        }*/
    }

    @Override
    public void onPayuNetworkAsyncTaskResponse(String cbAsynTaskResponse, String webServiceType) {
        editVpa.setEnabled(true);
        tvMakePayment.setVisibility(View.VISIBLE);
        cbProgress.stopAnimation();
        cbProgress.setVisibility(View.GONE);
        L.v("PayeeName " + cbAsynTaskResponse);
        if (isValidVPA(cbAsynTaskResponse)) {
            if (paymentResponse.getCombineVerifyAndPayButton() != null && paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("1")) {
                proceedVPACollect();
            } else {
                shouldEnableButton = true;
                enablePaymentButton();
                tvVerifyVpa.setVisibility(View.GONE);
                payeeName = getMerchantName(cbAsynTaskResponse);

                if (payeeName != null && !payeeName.equalsIgnoreCase("null")) {
                    tvVpaName.setVisibility(View.VISIBLE);
                    tvVpaName.setTextColor(getResources().getColor(R.color.cb_item_color));
                    tvVpaName.setText(payeeName);
                } else {
                    tvVpaName.setVisibility(View.GONE);
                }
                ivVpaSuccess.setVisibility(View.VISIBLE);
            }

        } else {
            showInvalidVPAError();
            if (paymentResponse.getCombineVerifyAndPayButton() != null && !paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("1")) {
                tvVerifyVpa.setVisibility(View.VISIBLE);
                tvVerifyVpa.setBackgroundResource(android.R.color.transparent);
                tvVerifyVpa.setText(getResources().getString(R.string.cb_verify));
            }
        }
    }

    /*  */

    /**
     * Function to launch CustomBrowser to start UPI collect .
     */
    private void launchUpiBrowser() {
        String postData;
        if (payeeName != null)
            postData = "token=" + paymentResponse.getToken() + "&action=sdkFallback&customerVpa=" + editVpa.getText().toString().trim() + "&customerName=" + payeeName.trim();
        else
            postData = "token=" + paymentResponse.getToken() + "&action=sdkFallback&customerVpa=" + editVpa.getText().toString().trim();

        if (null != list && list.isEmpty()) {
            postData = postData.concat("&fallbackReasonCode=E1902");
        }

        L.v("Class Name: " + getClass().getCanonicalName() + "LaunchBrowserGoing to happen");
        try {
            Intent intent = new Intent(getActivity(), PaymentResponseUpiSdkActivity.class);
            upiConfig.setPaymentType(UpiConstant.UPI_COLLECT_GENERIC);
            intent.putExtra(UpiConstant.UPI_CONFIG, upiConfig);
            intent.putExtra(UpiConstant.POST_DATA_UPI_COLLECT_GENERIC, postData);
            intent.putExtra(UpiConstant.POST_DATA, upiConfig.getPayuPostData());
            intent.putExtra(UPIPaymentConstants.RETURN_URL, paymentResponse.getReturnUrl());
            intent.putExtra(UpiConstant.PAYMENT_TYPE, UpiConstant.UPI_COLLECT_GENERIC);
            intent.putExtra(UpiConstant.MERCHANT_KEY, upiConfig.getMerchantKey());
            intent.putExtra(UpiConstant.MERCHANT_RESPONSE_TIMEOUT, upiConfig.getMerchantResponseTimeout());

            mActivity.startActivity(intent);
            if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed())
                mActivity.finish();
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "launchUpiBrowser exception " + e.getMessage());
        }
//        if (mActivity != null && !mActivity.isFinishing())
//            ((PaymentResponseUpiSdkActivity) mActivity).loadUrl(postData);


    }

    @Override
    public void onCancel(@NotNull DialogInterface dialog) {
        super.onCancel(dialog);
        genericUPICallbacks.onDialogCancelled(isValidPaymentMethodPresent, UpiConstant.CUSTOMER_CLOSED_THE_INTENT_TRAY);
    }

    /**
     * Function to hide UPI collect option
     */
    private void hideUPICollect() {
        tvVpaName.setVisibility(View.GONE);
        llPayment.setVisibility(View.GONE);
    }

    /**
     * Function to show UPI collect option
     */
    private void showUPICollect(boolean isDeviceHaveUpiApp) {
        tvHeading.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        tvHeading.setOnClickListener(null);
        tvHeading.setCompoundDrawablePadding(0);
        rlInputVpa.setVisibility(View.VISIBLE);
        llPayment.setVisibility(View.VISIBLE);
        if (!isDeviceHaveUpiApp) {
            editVpa.requestFocus();
            showSoftKeyboard();
        }

    }

    /**
     * Function to check if VPA is valid
     *
     * @param response Response of validateVPA api
     * @return true if vpa is valid else false
     */
    private boolean isValidVPA(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            return jsonObject.has(UPIPaymentConstants.VPA_VALID) && (jsonObject.getInt(UPIPaymentConstants.VPA_VALID) == 1);
        } catch (JSONException e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "isValidVPA exception " + e.getMessage());
        }
        return false;
    }

    /**
     * Function to get name associated with VPA
     *
     * @param jsonResponse Response of validateVPA api
     * @return payeeAccountName if present else null
     */
    private String getMerchantName(String jsonResponse) {
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            if (jsonObject.has(UPIPaymentConstants.PAYER_ACCOUNT_NAME))
                return jsonObject.getString(UPIPaymentConstants.PAYER_ACCOUNT_NAME);
        } catch (JSONException e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "getMerchantName exception " + e.getMessage());
        }
        return null;
    }

    IValidityCheck iValidityCheck;

    private void requestValidateVPA() {
        iValidityCheck = this;
        if (UpiUtil.validateVpa(editVpa.getText().toString(), vpaRegex.toString())) {
            editVpa.setEnabled(false);
            showProgressBar();
            tvVerifyVpa.setVisibility(View.GONE);
            UpiData.SINGLETON.setiValidityCheck(this);
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                UpiData.SINGLETON.getPayUPICallback().onVpaEntered(editVpa.getText().toString(), iValidityCheck);

        } else {
            showInvalidVPAError();
        }
    }

    /**
     * Function to proceed for UPI collect
     */
    private void proceedVPACollect() {
        launchUpiBrowser();
        L.v("Class Name: " + getClass().getCanonicalName() + "Launch Browser");
        dismiss();
        PayUUpiUtil.updateLayoutSecurity(requireActivity(), false);
    }


    @Override
    public void onDestroyView() {
        //workaround for this issue: https://code.google.com/p/android/issues/detail?id=17423 (unable to retain instance after configuration change)
        if (getDialog() != null && getRetainInstance())
            getDialog().setDismissMessage(null);
        super.onDestroyView();
//        hideSoftKeyboard(editVpa);
    }

    @Override
    public void onSaveInstanceState(@NotNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        tvVpaName.setVisibility(View.GONE);
        if (UpiUtil.validateVpa(editVpa.getText().toString(), vpaRegex.toString())) {
            if (paymentResponse.getCombineVerifyAndPayButton() != null && paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("0")) {
                tvVerifyVpa.setVisibility(View.VISIBLE);
                shouldEnableButton = false;
                tvMakePayment.setEnabled(false);
                tvMakePayment.setAlpha(0.35f);
                ivVpaSuccess.setVisibility(View.INVISIBLE);
            } else {
                shouldEnableButton = true;
                tvMakePayment.setEnabled(true);
                tvMakePayment.setAlpha(1.0f);
            }
        } else {
            shouldEnableButton = false;
            tvMakePayment.setEnabled(false);
            tvMakePayment.setAlpha(0.35f);
            if (paymentResponse.getCombineVerifyAndPayButton() != null && paymentResponse.getCombineVerifyAndPayButton().equalsIgnoreCase("0")) {
                tvVerifyVpa.setVisibility(View.GONE);
            }
        }

    }

    /**
     * Function to disable Payment Button
     */
    private void disablePaymentButton() {
        tvMakePayment.setText(getResources().getString(R.string.cb_verify_and_proceed));
        tvMakePayment.setEnabled(false);
        tvMakePayment.setTextColor(getResources().getColor(android.R.color.white));
        tvMakePayment.setAlpha(0.35f);
        tvMakePayment.setOnClickListener(this);
    }

    /**
     * Function to enable Payment Button
     */
    private void enablePaymentButton() {
        if (isAdded()) {
            tvMakePayment.setTextColor(getResources().getColor(android.R.color.white));
            tvMakePayment.setText(getResources().getText(R.string.proceed_to_pay));
            tvMakePayment.setEnabled(true);
            tvMakePayment.setAlpha(1.0f);
        }
    }

    /**
     * Function to show invalid vpa error
     */
    private void showInvalidVPAError() {
        tvVpaName.setVisibility(View.VISIBLE);
        tvVpaName.setText(getResources().getString(R.string.cb_invalid_vpa));
        tvVpaName.setTextColor(Color.RED);
    }

    @Override
    public void onPause() {
        super.onPause();
        hideSoftKeyboard(editVpa);
    }

    /**
     * Hide Keyboard
     *
     * @param input, editText
     */
    protected void hideSoftKeyboard(EditText input) {
        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (null != imm)
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
    }

    /**
     * Show Keyboard
     */
    protected void showSoftKeyboard() {
        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (null != imm)
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    @Override
    public void verifyVpa(String verifyVpaHash) {
        UpiData.SINGLETON.setiValidityCheck(this);
        String postData = "key=" + upiConfig.getMerchantKey() + "&var1=" + editVpa.getText().toString().trim() + "&command=validateVPA&hash=" + verifyVpaHash;
        PayUNetworkAsyncTaskData asyncTaskData = new PayUNetworkAsyncTaskData();

        asyncTaskData.setHttpMethod("POST");
        //asyncTaskData.setUrl(UpiConstant.PRODUCTION_FETCH_DATA_URL);
        asyncTaskData.setUrl(upiConfig.getWebServiceUrl());
        asyncTaskData.setPostData(postData);
        new PayUNetworkAsyncTask(this, UpiConstant.VERIFY).execute(asyncTaskData);
    }


}
