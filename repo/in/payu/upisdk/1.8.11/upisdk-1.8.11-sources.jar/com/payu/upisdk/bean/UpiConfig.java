package com.payu.upisdk.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

import androidx.annotation.IntDef;

import com.payu.upisdk.util.UpiConstant;

public class UpiConfig implements Parcelable {
    public static final boolean TRUE_ = true;
    private String paymentType;
    private String transactionID;
    private boolean isPhonePeUserCacheEnabled;
    private String merchantKey;
    private String payuPostData;
    private int merchantResponseTimeout;
    private int gmsProviderUpdatedStatus;
    public static final int FALSE = -1;
    public static final int DISABLE = -1;
    public static final int TRUE = 0;
    private View progressDialogCustomView;
    private String packageNameForSpecificApp;
    private int disableIntentSeamlessFailure = FALSE;
    private String webServiceUrl = null;
    private String postUrl;
    private boolean isProduction = true;
    private boolean isProtectedScreen = true;

    public String getPackageNameForSpecificApp() {
        return packageNameForSpecificApp;
    }

    public void setPackageNameForSpecificApp(String packageNameForSpecificApp) {
        this.packageNameForSpecificApp = packageNameForSpecificApp;
    }

    @IntDef({TRUE, FALSE})
    public @interface DisableIntentSeamlessFailure {

    }

    public int getDisableIntentSeamlessFailure() {
        return disableIntentSeamlessFailure;
    }

    public void setDisableIntentSeamlessFailure(@DisableIntentSeamlessFailure int disableIntentSeamlessFailure) {
        this.disableIntentSeamlessFailure = disableIntentSeamlessFailure;
    }

    public int getMerchantResponseTimeout() {
        return merchantResponseTimeout;
    }

    public void setMerchantResponseTimeout(int merchantResponseTimeout) {
        this.merchantResponseTimeout = merchantResponseTimeout;
    }


    public boolean isPhonePeUserCacheEnabled() {
        return isPhonePeUserCacheEnabled;
    }

    public void setPhonePeUserCacheEnabled(boolean phonePeUserCacheEnabled) {
        isPhonePeUserCacheEnabled = phonePeUserCacheEnabled;
    }

    public UpiConfig() {
        this.merchantResponseTimeout = UpiConstant.MERCHANT_URL_LOADING_TIMEOUT;
        this.gmsProviderUpdatedStatus = FALSE;

    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPayuPostData() {
        return payuPostData;
    }

    public void setPayuPostData(String payuPostData) {
        this.payuPostData = payuPostData;
    }


    /**
     * Setter for merchant key.
     * it should take the values in the following order.
     * 2. {@link UpiConfig#setPayuPostData(String)}
     * 3. {@link UpiConfig#setMerchantKey(String)}
     *
     * @param merchantKey
     */
    public void setMerchantKey(String merchantKey) {
        /* this.merchantKey = Bank.keyAnalytics;*/
        if (null == this.merchantKey || this.merchantKey.trim().length() < 1) {
            this.merchantKey = merchantKey;
            // Bank.keyAnalytics = merchantKey;
        }
    }

    public String getMerchantKey() {
        return merchantKey;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.merchantKey);
        dest.writeString(this.payuPostData);
        dest.writeString(this.paymentType);
        dest.writeString(transactionID);
        dest.writeByte(this.isPhonePeUserCacheEnabled ? (byte) 1 : (byte) 0);
        dest.writeInt(this.merchantResponseTimeout);
        dest.writeInt(this.gmsProviderUpdatedStatus);
        dest.writeString(webServiceUrl);
        dest.writeString(postUrl);
        dest.writeInt(disableIntentSeamlessFailure);
        dest.writeString(packageNameForSpecificApp);
        dest.writeByte(this.isProduction ? (byte) 1 : (byte) 0);
        dest.writeByte((byte) (isProtectedScreen ? 1 : 0));
    }

    protected UpiConfig(Parcel in) {
        this.merchantKey = in.readString();
        this.payuPostData = in.readString();
        this.paymentType = in.readString();
        this.transactionID = in.readString();
        this.isPhonePeUserCacheEnabled = in.readByte() != 0;
        this.merchantResponseTimeout = in.readInt();
        this.gmsProviderUpdatedStatus = in.readInt();
        this.webServiceUrl = in.readString();
        this.postUrl = in.readString();
        this.disableIntentSeamlessFailure = in.readInt();
        this.packageNameForSpecificApp = in.readString();
        this.isProduction = in.readByte() != 0;
        this.isProtectedScreen = in.readByte() != 0;
    }

    public void setGmsProviderUpdatedStatus(int gmsProviderUpdatedStatus) {
        this.gmsProviderUpdatedStatus = gmsProviderUpdatedStatus;
    }

    public static final Parcelable.Creator<UpiConfig> CREATOR = new Parcelable.Creator<UpiConfig>() {
        @Override
        public UpiConfig createFromParcel(Parcel source) {
            return new UpiConfig(source);
        }

        @Override
        public UpiConfig[] newArray(int size) {
            return new UpiConfig[size];
        }
    };

    public View getProgressDialogCustomView() {
        return progressDialogCustomView;
    }

    public void setProgressDialogCustomView(View progressDialogCustomView) {
        this.progressDialogCustomView = progressDialogCustomView;
    }


    public String getWebServiceUrl() {
        return webServiceUrl;
    }

    public void setWebServiceUrl(String webServiceUrl) {
        this.webServiceUrl = webServiceUrl;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

    public boolean isProduction() {
        return isProduction;
    }

    public void setProduction(boolean production) {
        isProduction = production;
    }

    public boolean isProtectedScreen() {
        return isProtectedScreen;
    }

    public void setProtectedScreen(boolean protectedScreen) {
        isProtectedScreen = protectedScreen;
    }
}
