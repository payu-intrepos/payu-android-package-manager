package com.payu.upisdk.upiintent;

import static androidx.fragment.app.DialogFragment.STYLE_NORMAL;

import static com.payu.upisdk.util.UpiAnalyticsConstant.PAYU_UPI_LIFECYCLE_STATE;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.ColorInt;
import androidx.fragment.app.FragmentActivity;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.interfaces.PayUSocketEventListener;
import com.payu.socketverification.socket.SocketHandler;
import com.payu.socketverification.socket.SocketPaymentResponse;
import com.payu.socketverification.widgets.PayUProgressDialog;
import com.payu.upisdk.PackageListDialogFragment;
import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.R;
import com.payu.upisdk.Upi;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.upi.UpiWebInterface;
import com.payu.upisdk.upiinterface.GenericUPICallbacks;
import com.payu.upisdk.util.AnalyticsUpiUnit;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.PayUUpiUtil;
import com.payu.upisdk.util.StatusBarUtils;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import org.jetbrains.annotations.NotNull;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


/**
 * @author shahbaz.ahmmod
 * This is the only activity in upisdk. Decision to make payment is handled here.
 * Payment types are: Phonepe, Collect, Generic Intent, Sampay and Tez for now. We are sending the payment data from Upi class{@link Upi}
 * In case of collect flow. Showing webview here and listening @javascriptinterface methods in {@link UpiWebInterface}
 */
public class PaymentResponseUpiSdkActivity extends FragmentActivity implements GenericUPICallbacks, PayUSocketEventListener {
    PaymentHandler paymentHandler;
    private String postData;
    ArrayList<PackageBean> packageBeanList;
    ArrayList<PackageBean> filteredList;
    private PayUAnalytics analytics;
    private String mPaymentType;
    private PaymentOption paymentOptionEnum;
    private WebView mCollectWebView;
    private UpiConfig upiConfig;
    private Boolean isUpiAppAlreadyOpen = false;
    private PaymentResponse paymentResponse;
    private static String mReturnUrl;
    private String errorReason = "";
    private int statusCode = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (null != savedInstanceState) {
            analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : saved instance is not null");
            upiConfig = savedInstanceState.getParcelable(UpiConstant.UPI_CONFIG);
            paymentResponse = savedInstanceState.getParcelable(UpiConstant.PAYMENT_RESPONSE);
            isUpiAppAlreadyOpen = savedInstanceState.getBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED);
            if (isUpiAppAlreadyOpen && upiConfig != null && paymentResponse != null) {
                analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : restoring payment handler");
                postData = upiConfig.getPayuPostData();
                analytics = AnalyticsUpiUnit.getInstance(getApplicationContext());
                if (!TextUtils.isEmpty(paymentResponse.getReturnUrl())) {
                    UpiData.SINGLETON.setVerifyUrl(paymentResponse.getReturnUrl());
                }
                String token = paymentResponse.getToken();
                if (!TextUtils.isEmpty(token)) {
                    paymentHandler = new PaymentHandler(this, postData, token);
                } else {
                    paymentHandler = new PaymentHandler(this, postData);
                }
                analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : payment Handler restored");
            } else {
                finish();
                return;
            }
        }

        if (getIntent() != null && getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getExtras();
            upiConfig = bundle.getParcelable(UpiConstant.UPI_CONFIG);
            SocketHandler.getInstance().onActivityCreated(this, this);
            if (null != upiConfig) {
                postData = upiConfig.getPayuPostData();
                mPaymentType = upiConfig.getPaymentType();
                upiConfig.setProgressDialogCustomView(UpiData.SINGLETON.getPayUCustomDialogView());
                makeActivityTransparentExceptCollectFlow();
                setContentView(R.layout.activity_payment_response);
                @ColorInt int color = androidx.core.content.ContextCompat.getColor(this, R.color.payu_upi_primary_color_dark); // #4E5F4E
                StatusBarUtils.setStatusBarColor(this, color);
                this.analytics = AnalyticsUpiUnit.getInstance(getApplicationContext());
                mCollectWebView = findViewById(R.id.wvCollect);
                analyticsLogging(UpiConstant.PAYMENT_OPTION, mPaymentType.toLowerCase());
                if (!isUpiAppAlreadyOpen || paymentResponse == null) {
                    analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : handlePaymentFlow triggered");
                    handlePaymentFlow();
                }
            }
        }

        PayUUpiUtil.updateLayoutSecurity(this, upiConfig != null && upiConfig.isProtectedScreen());
    }

    @Override
    protected void onRestoreInstanceState(@NotNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : onRestoreInstanceState");
        upiConfig = savedInstanceState.getParcelable(UpiConstant.UPI_CONFIG);
        paymentResponse = savedInstanceState.getParcelable(UpiConstant.PAYMENT_RESPONSE);
        isUpiAppAlreadyOpen = savedInstanceState.getBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED);
        analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : onRestoreInstanceState bundle is not null");
    }

    private void makeActivityTransparentExceptCollectFlow() {
        if (UpiConstant.UPI_COLLECT.equalsIgnoreCase(mPaymentType) || UpiConstant.UPI_COLLECT_GENERIC.equalsIgnoreCase(mPaymentType)) {
            setTheme(R.style.upi_sdk_opaque_screen);
        }
    }

    /**
     * Handling payment types. There will be one of these payment types.
     */
    private void handlePaymentFlow() {
        analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE, mPaymentType.toUpperCase());
        switch (mPaymentType.toLowerCase()) {
            case UpiConstant.UPI_COLLECT:
            case UpiConstant.UPI_COLLECT_TPV:
            case UpiConstant.TEZOMNI:
            case UpiConstant.TEZ_TPV:
                setCollectWebViewSettings();

                if (mPaymentType.equalsIgnoreCase(UpiConstant.UPI_COLLECT_TPV))
                    paymentOptionEnum = PaymentOption.UPI_COLLECT_TPV;
                else if (mPaymentType.equalsIgnoreCase(UpiConstant.TEZ_TPV))
                    paymentOptionEnum = PaymentOption.TEZ_TPV;
                else if (mPaymentType.equalsIgnoreCase(UpiConstant.TEZOMNI))
                    paymentOptionEnum = PaymentOption.TEZ_OMNI;
                else
                    paymentOptionEnum = PaymentOption.UPI_COLLECT;

                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for UpiCollect >>> " + paymentOptionEnum.getPackageName());
                L.v("Class Name: " + getClass().getCanonicalName() + "PostDataUpiSdk " + postData);
                showProgressDialog();
                String url = upiConfig.getPostUrl();
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE_STATE, UpiAnalyticsConstant.LAUNCHED);
                analyticsLogging(UpiAnalyticsConstant.TEZTPV_URL, url);
                analyticsLogging(UpiAnalyticsConstant.TEZTPV_POST_DATA, upiConfig.getPayuPostData());
                postUrlWebView(url, postData);
                break;

            case UpiConstant.UPI_COLLECT_GENERIC:
                Upi.isRecreating = true;
                setCollectWebViewSettings();
                showProgressDialog();
                paymentOptionEnum = PaymentOption.UPI_COLLECT_GENERIC;
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for UpiCollect >>> " + paymentOptionEnum.getPackageName());
                if (null != getIntent() && null != getIntent().getExtras() && null != getIntent().getStringExtra(UpiConstant.POST_DATA_UPI_COLLECT_GENERIC) && null != getIntent().getStringExtra(UPIPaymentConstants.RETURN_URL)) {
                    String postDataCollectGerenicIntent = getIntent().getExtras().getString(UpiConstant.POST_DATA_UPI_COLLECT_GENERIC);
                    mReturnUrl = getIntent().getStringExtra(UPIPaymentConstants.RETURN_URL);
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE_STATE_0, UpiAnalyticsConstant.LAUNCHED);
                    analyticsLogging(UpiAnalyticsConstant.UPI_GENERIC_URL, mReturnUrl);
                    analyticsLogging(UpiAnalyticsConstant.UPI_GENERIC_POST_DATA, postDataCollectGerenicIntent);
                    postUrlWebView(mReturnUrl, postDataCollectGerenicIntent);
                } else {
                    analyticsLogging(UpiAnalyticsConstant.LAUNCH_ERROR, UpiConstant.LAUNCH_ERROR);
                }
                break;
            case UpiConstant.UPI_INTENT_S:
            case UpiConstant.UPI_INTENT_TPV:
                if (mPaymentType.equalsIgnoreCase(UpiConstant.UPI_INTENT_TPV))
                    paymentOptionEnum = PaymentOption.UPI_INTENT_TPV;
                else
                    paymentOptionEnum = PaymentOption.UPI_INTENT;

                PayUUpiUtil.setUpiPackageName(upiConfig.getPackageNameForSpecificApp());
                if (!isFinishing() && !isDestroyed()) {
                    if (null != paymentResponse && null != paymentResponse.getToken())
                        paymentHandler = new PaymentHandler(this, postData, paymentResponse.getToken());
                    if (!isUpiAppAlreadyOpen) {
                        paymentHandler = new PaymentHandler(this, postData);
                        getUPIPackagesList();
                        analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE_STATE_1, UpiAnalyticsConstant.LAUNCHED);
                        paymentHandler.initiatePayment();
                    } else {
                        analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE_STATE_2, UpiAnalyticsConstant.UPI_APP_ALREADY_OPEN);
                    }
                } else {
                    analyticsLogging(UpiAnalyticsConstant.LAUNCH_ERROR_0, UpiConstant.LAUNCH_ERROR);
                }
                break;

        }
    }

    /**
     * setting for webview collect. Javascript interface enabling.
     * {@link UpiWebInterface} to handle @javascriptinterface methods
     */
    private void setCollectWebViewSettings() {
        if (mCollectWebView != null) {
            mCollectWebView.getSettings().setJavaScriptEnabled(true);
            mCollectWebView.addJavascriptInterface(new UpiWebInterface(this, analytics, upiConfig), "PayU");
            mCollectWebView.setVisibility(View.GONE);
            mCollectWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_PAGE_STARTED, url);
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_PAGE_FINISHED, url);
                    hideProgressDialog();
                }

                @Override
                public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                    super.onReceivedHttpError(view, request, errorResponse);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_HTTP_ERROR, request.getUrl().toString());
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    super.onReceivedError(view, request, error);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_ERROR, request.getUrl().toString());
                }

                @Override
                public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                    super.onReceivedSslError(view, handler, error);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_SSL_ERROR, error.getUrl());
                }
            });

        }

    }

    private PayUProgressDialog progressDialog;

    /**
     * Showing Dialog {@link PayUProgressDialog}
     */
    private void showProgressDialog() {
        if (!isFinishing() && !isDestroyed()) {
            if (null == progressDialog)
                progressDialog = new PayUProgressDialog(this, UpiData.SINGLETON.getPayUCustomDialogView());
            progressDialog.setCancelable(false);
            if (null == UpiData.SINGLETON.getPayUCustomDialogView()) {
                if (!isFinishing() && !isDestroyed()) {
                    progressDialog.setPayUDialogSettings(this);
                    progressDialog.show();
                }
            }
        }
    }

    /**
     * Hiding the PayU progress dialog {@link PayUProgressDialog}
     */
    private void hideProgressDialog() {
        if (null != progressDialog && progressDialog.isShowing()
                && !isDestroyed() && !isFinishing()) {
            progressDialog.dismiss();
            progressDialog = null;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == UPIPaymentConstants.PAYMENT_REQUEST_CODE) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Result code " + resultCode + " Data  " + data);
            statusCode = resultCode;
            String pspResponse = getPaymentResponse(data);
            if (resultCode == RESULT_OK && data != null) {//data is null in case of whatsapp payment
                String status = getPaymentStatus(data);
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_APP_RESPONSE, "Status_" + status + "_|_" + UpiAnalyticsConstant.PAYMENT_APP_RESPONSE + ": " + pspResponse);

                if (status != null && !status.equalsIgnoreCase(UpiConstant.SUCCESS)) {
                    L.v("Payment App response " + status);
                    //If status is not success and is not null call verify since we can't wait for long time for backend to response.
                    status = UpiConstant.FAILURE;
                    errorReason = UpiConstant.GET_RESPONSE_FROM_PSP;
                    if (paymentHandler != null) {
                        paymentHandler.verifyPayment(status, errorReason);
                    } else {
                        analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment on success path");
                    }
                } else {
                    status = UpiConstant.FAILURE;
                    makeDecisionForSocketAndHttp(status, errorReason);
                    L.v("Class Name: " + getClass().getCanonicalName() + "Return " + status);
                }

            } else {
                analyticsLogging(UPIPaymentConstants.CANCEL, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP.trim() + "_&_resultCode_" + resultCode);
                L.v("Class Name: " + getClass().getCanonicalName() + "Cancel return");
                if (paymentHandler != null) {
                    paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP);
                } else {
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment on cancel path");
                }
            }
        }
    }

    /**
     * Get Payment Status received from UPI App
     *
     * @param data Intent
     * @return Value of {@link UPIPaymentConstants#STATUS}
     */
    private String getPaymentStatus(Intent data) {
        if (data.hasExtra(UPIPaymentConstants.STATUS)) {
            return data.getStringExtra(UPIPaymentConstants.STATUS);
        } else if (data.hasExtra(UPIPaymentConstants.RESPONSE)) {  //Some apps doesn't send status as key in intent but definitely send response key.
            String response = data.getStringExtra(UPIPaymentConstants.RESPONSE);
            HashMap<String, String> responseMap = UpiUtil.getDataFromPostData(response);
            return responseMap.get(UPIPaymentConstants.STATUS);
        }
        return null;
    }

    private String getPaymentResponse(Intent data) {
        if (data != null && data.hasExtra(UPIPaymentConstants.RESPONSE)) {
            String response = data.getStringExtra(UPIPaymentConstants.RESPONSE);
            return response;
        }
        return null;
    }

    /**
     * Making decision whether we need to verify using http or socket connection using upiPushDisabled value. It's "0" or "1"
     *
     * @param verifyHttpStatus
     */
    private void makeDecisionForSocketAndHttp(String verifyHttpStatus, String errorReason) {
        analyticsLogging(UpiAnalyticsConstant.UPI_SOCKET, UpiAnalyticsConstant.PUSH_ENABLED);
        if (null != paymentResponse && null != paymentResponse.getSocketParams() && paymentResponse.getSocketParams().getUpiPushDisabled() != null && paymentResponse.getSocketParams().getUpiPushDisabled().equals("0")) {
            //upiPushDisabled = 0 means, upi push is enabled so create socket connection.
            makeSocketConnection();
        } else {
            analyticsLogging(UpiAnalyticsConstant.CB_VERFIY_WAY, UpiAnalyticsConstant.VERIFY_USING_HTTP);
            if (paymentHandler != null) {
                paymentHandler.verifyPayment(verifyHttpStatus, errorReason);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment in makeDecisionForSocketAndHttp");
            }
        }
    }

    private SocketPaymentResponse socketPaymentResponseVSocketVerification;

    /**
     * Making Socket connection..
     */
    private void makeSocketConnection() {
        analyticsLogging(UpiAnalyticsConstant.VERIFY_TYPE, UpiAnalyticsConstant.SOCKET);
        socketPaymentResponseVSocketVerification = new SocketPaymentResponse();
        createSocketVerificationInstances();
        if (null != socketPaymentResponseVSocketVerification && null != socketPaymentResponseVSocketVerification.getTxnId())
            SocketHandler.getInstance().createSocket(socketPaymentResponseVSocketVerification, this, this);
    }

    /**
     * Creating instance for Socket.
     */
    private void createSocketVerificationInstances() {
        if (null != paymentResponse) {
            socketPaymentResponseVSocketVerification.setReferenceId(paymentResponse.getReferenceId());
            if (null != upiConfig && null != upiConfig.getTransactionID())
                socketPaymentResponseVSocketVerification.setTxnId(upiConfig.getTransactionID());
            socketPaymentResponseVSocketVerification.setUpiPushDisabled(paymentResponse.getSocketParams().getUpiPushDisabled());
            socketPaymentResponseVSocketVerification.setUpiServicePollInterval(paymentResponse.getSocketParams().getUpiServicePollInterval());
            socketPaymentResponseVSocketVerification.setSdkUpiPushExpiry(paymentResponse.getSocketParams().getSdkUpiPushExpiry());
            socketPaymentResponseVSocketVerification.setSdkUpiVerificationInterval(paymentResponse.getSocketParams().getSdkUpiVerificationInterval());
            socketPaymentResponseVSocketVerification.setPushServiceUrl(paymentResponse.getSocketParams().getPushServiceUrl());
        }
    }

    @Override
    public void onResponse(PaymentResponse paymentResponse) {
        this.paymentResponse = paymentResponse;
        if (null == paymentResponse) { //We don't get valid response from Backend might be Merchant Setting issue.
            sendingErrorListener(UpiAnalyticsConstant.PAYMENT_RESPONSE_NULL);
        } else if (!isMandatoryParamsAvailable()) { //Seems like backend is down.
            if (paymentResponse.getStatus() == 0 && TextUtils.isEmpty(paymentResponse.getResult())) {
                String base64Response = UpiUtil.getBase64DecodedString(paymentResponse.getResult()); //Seems like PG is down
                if (base64Response == null) {
                    sendingErrorListener(UpiAnalyticsConstant.BASE64_RESPONSE_NULL);
                } else {

                  if (UpiData.SINGLETON.getPayUPICallback() != null)
                    UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(base64Response, null);
                  if (!isFinishing() && !isDestroyed())
                    finish();
                }
            } else {
                sendingErrorListener(UpiAnalyticsConstant.PAYMENT_STATUS_ZERO_AND_RESULT_BLANK);
            }

        } else if (paymentOptionEnum == PaymentOption.TEZ) {
            String TEZ_PACKAGE = "com.google.android.apps.nbu.paisa.user";
            if (paymentHandler != null) {
                paymentHandler.makePayment(TEZ_PACKAGE);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping makePayment for TEZ flow");
            }
        } else if (paymentOptionEnum == PaymentOption.UPI_INTENT || paymentOptionEnum == PaymentOption.UPI_INTENT_TPV) {
            if (!isFinishing() && !isDestroyed() && !isUpiAppAlreadyOpen) {
                if (upiConfig.getPackageNameForSpecificApp() != null && upiConfig.getPackageNameForSpecificApp().length() > 0) {
                    onAppSelected(upiConfig.getPackageNameForSpecificApp(), UpiUtil.getVersionName(upiConfig.getPackageNameForSpecificApp(), this));
                } else {
                    mReturnUrl = paymentResponse.getReturnUrl();
                    filteredList = new ArrayList<>();
                    if (paymentResponse.getApps() != null && paymentResponse.getApps().size() > 0) {
                        for (PackageBean bean : paymentResponse.getApps()) {
                            Iterator<PackageBean> iterator = packageBeanList.iterator();
                            while (iterator.hasNext()) {
                                PackageBean packageBean = iterator.next();
                                if (packageBean.equals(bean)) {
                                    packageBean.setPackageName(bean.getPackageName());
                                    filteredList.add(packageBean);
                                    iterator.remove();
                                }
                            }
                        }
                    }
                    if (filteredList != null && packageBeanList != null)
                        filteredList.addAll(packageBeanList);
                    PackageListDialogFragment packageListDialogFragment = PackageListDialogFragment.newInstance(filteredList, paymentResponse, upiConfig, this);
                    packageListDialogFragment.setStyle(STYLE_NORMAL, R.style.UpiSdkFullScreenDialogStyle);
                    packageListDialogFragment.setRetainInstance(true);
                    packageListDialogFragment.show(getSupportFragmentManager(), "packageList");
                    isUpiAppAlreadyOpen = true;
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_APP, UPIPaymentConstants.PACKAGE_LIST);

                }
            } else {
                analyticsLogging(UPIPaymentConstants.ACTIVITY_2, UpiAnalyticsConstant.ACTIVITY_FINISHED);
            }
        } else {
            //We don't get valid response from Backend might be Merchant Setting issue.
            sendingErrorListener(UpiAnalyticsConstant.INVALID_RESPONSE);
        }

    }

    /**
     * Getting list of packages for UPI apps. Showing using fragment {@link PackageListDialogFragment}
     */
    private void getUPIPackagesList() {
        packageBeanList = new ArrayList<>();
        Intent intent = new Intent();
        intent.setData(Uri.parse(UPIPaymentConstants.UPI_INTENT_PREFIX));
        List<ResolveInfo> resolveInfos = getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo resolveInfo : resolveInfos) {
            PackageInfo packageInfo;
            try {
                L.v("UPI Installed App....... " + resolveInfo.activityInfo.packageName);
                packageInfo = getPackageManager().getPackageInfo(resolveInfo.activityInfo.packageName, 0);
                String name = (String) getPackageManager().getApplicationLabel(packageInfo.applicationInfo);
                packageBeanList.add(new PackageBean(name, packageInfo.packageName));
            } catch (PackageManager.NameNotFoundException e) {
                L.v("getUPIPackagesList - PackageManager.NameNotFoundException" + e.getMessage());
            }
        }
    }

    @Override
    public void onAppSelected(String packageName, String versionName) {
        if (upiConfig != null && null != paymentOptionEnum ) {
            analyticsLogging(UpiAnalyticsConstant.PAYMENT_APP, UpiAnalyticsConstant.PACKAGENAME_ + packageName + UpiAnalyticsConstant._VERSION_NAME_ + versionName);
        }
        if (paymentHandler != null) {
            paymentHandler.makePayment(packageName);
        } else {
            analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping makePayment in onAppSelected");
        }
    }

    @Override
    public void onDialogCancelled(boolean isValidPaymentMethodPresent, String cancelReason) {
        if (isValidPaymentMethodPresent) {
            if (statusCode != RESULT_OK) {
                if (paymentHandler != null) {
                    paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, cancelReason);
                } else {
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment in onDialogCancelled cancel");
                }
            }
            analyticsLogging(UpiAnalyticsConstant.BACK_BUTTON_CANCEL_CLICK, "statusCode_" + statusCode + "_&_cancelReason_" + cancelReason.trim());


        } else {
            analyticsLogging(UpiAnalyticsConstant.PAYMENT_TYPE_STATE_3, UpiAnalyticsConstant.NO_UPI_APPS_PRESENT);
            if (paymentHandler != null) {
                paymentHandler.verifyPayment(UPIPaymentConstants.FAILURE, UPIPaymentConstants.NO_UPI_APPS_PRESENT);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment in onDialogCancelled no upi apps");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PayUUpiUtil.updateLayoutSecurity(this, false);
        L.v("Class Name: " + getClass().getCanonicalName() + "OnDestroy ");
        SocketHandler.getInstance().onActivityDestroyed(this);
        cleanUp();
        if (!Upi.isRecreating) {

            if (UpiData.SINGLETON.getPayUPICallback() != null)
                UpiData.SINGLETON.getPayUPICallback().onPaymentTerminate();
        } else {

            Upi.isRecreating = false;
        }

    }

    private void cleanUp() {
        if (null != paymentHandler)
            paymentHandler.cleanUp();
        if (null != alertDialog)
            alertDialog.dismiss();
        if (null != progressDialog) {
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            progressDialog = null;
        }
        L.v("Class Name: " + getClass().getCanonicalName() + "Is recreating " + Upi.isRecreating);
    }

    @Override
    public void onBackPressed() {
        confirmationDialog();
    }


    /**
     * Creating confirmation dialog.
     */
    private void confirmationDialog() {
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (i == DialogInterface.BUTTON_POSITIVE) {

                    L.v("Class Name: " + getClass().getCanonicalName() + "getPayUUpiSdkCallback " + " used when doing through Upi Sdk  " + UpiData.SINGLETON.getPayUPICallback());
                    postToPaytxn();

                    if (UpiData.SINGLETON.getPayUPICallback() != null)
                        UpiData.SINGLETON.getPayUPICallback().onBackApprove();

                    if (!isFinishing() && !isDestroyed())
                        finish();
                } else if (i == DialogInterface.BUTTON_NEGATIVE) {

                    dialogInterface.dismiss();
                    if (null != UpiData.SINGLETON.getPayUPICallback()) {
                        UpiData.SINGLETON.getPayUPICallback().onBackDismiss();
                    }
                }
            }
        };

        if (!isFinishing() && !isDestroyed()) {
            AlertDialog.Builder builder = UpiUtil.getAlertDialog(PaymentResponseUpiSdkActivity.this, onClickListener, "Ok", "Cancel", null, getString(R.string.do_you_really_want_to_cancel_the_transaction));
            if (null != UpiData.SINGLETON.getPayUPICallback()) {
                UpiData.SINGLETON.getPayUPICallback().onBackButton(builder);
                alertDialog = builder.create();
                alertDialog.show();
            }
        }
    }

    private AlertDialog alertDialog;

//    /**
//     * Load URL for VPA from dialog.
//     *
//     * @param postData
//     */
//    public void loadUrl(String postData) {
//        setCollectWebViewSettings();
//        isWebOpened = true;
//        showProgressDialog();
//        L.v("Class Name: " + getClass().getCanonicalName() + "loadURl to happen");
//        setTheme(R.style.upi_sdk_opaque_screen);
//        postUrlWebView(mReturnUrl, postData);
//    }

    private void postUrlWebView(String url, String postData) {
        L.v("Class Name: " + getClass().getCanonicalName() + "URL web " + url);
        L.v("Class Name: " + getClass().getCanonicalName() + "Postdata web " + postData);
        if (mCollectWebView != null) {
            getWindow().setLayout(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
            analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_POST_URL, url);
            mCollectWebView.setVisibility(View.VISIBLE);
            mCollectWebView.postUrl(url, postData.getBytes());


        }
    }

    @Override
    public void getSocketResult(String merchantResponse, String payuResponse, String resultType, boolean isLongPooling) {
        if (resultType.equals(UPIPaymentConstants.SUCCESS)) {
            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                analyticsLogging(UpiAnalyticsConstant.SOCKET_TRXN_STATUS, UpiAnalyticsConstant.SUCCESS_TRANSACTION);
                UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(payuResponse, null);
            } else {
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentSuccess");
            }
        } else {

            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                analyticsLogging(UpiAnalyticsConstant.SOCKET_TRXN_STATUS_0, UpiAnalyticsConstant.FAILURE_TRANSACTION);
                UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(payuResponse, null);
            } else {
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentFailure");
            }
        }

        if (!isFinishing() && !isDestroyed())
            finish();
    }

    @Override
    public void errorReceived(int issueCode, String errorMessage) {
        L.v("Class Name: " + getClass().getCanonicalName() + "Error Received " + errorMessage);
        analyticsLogging(UpiAnalyticsConstant.SOCKET_CANCEL, UpiAnalyticsConstant.TECHNICAL_ERROR_AND_ERROR_MESSAGE + ": " + errorMessage);

        if (issueCode == UpiConstant.SOCKET_NOT_CREATED) {
            //TODO: Need to change transactionStatus dn errorStatus
            if (null != paymentHandler)
                paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, UpiAnalyticsConstant.TECHNICAL_ERROR);
        } else {
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(issueCode, errorMessage);
            else
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentSuccess");
          if (!isFinishing() && !isDestroyed())
            finish();
        }
    }

    @Override
    public void transactionCancelled() {
        onDialogCancelled(true, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP);
    }

    @Override
    public void onSocketCreated() {
        SocketHandler.getInstance().startSocketEvents(upiConfig.getMerchantKey(), upiConfig.getTransactionID(), this, upiConfig.getProgressDialogCustomView());

    }

    private boolean isMandatoryParamsAvailable() {
        return !TextUtils.isEmpty(paymentResponse.getReturnUrl()) && !TextUtils.isEmpty(paymentResponse.getMerchantVpa()) && !TextUtils.isEmpty(paymentResponse.getReferenceId());
    }

    private void sendingErrorListener(String errorDetails) {
        L.v("Class Name: " + getClass().getCanonicalName() + " Err " + UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE);
        analyticsLogging(UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT, "ErrorDetails_" + errorDetails + "_|_ErrorCode: " + UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE);

        if (UpiData.SINGLETON.getPayUPICallback() != null)
            UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE, UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT);

        if (!this.isFinishing() && !this.isDestroyed())
            finish();
    }

    @Override
    protected void onSaveInstanceState(@NotNull Bundle outState) {
        super.onSaveInstanceState(outState);
        analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Activity : onSaveInstanceState outState storing values");
        outState.putParcelable(UpiConstant.UPI_CONFIG, upiConfig);
        outState.putParcelable(UpiConstant.PAYMENT_RESPONSE, paymentResponse);
        outState.putBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED, isUpiAppAlreadyOpen);
    }

    @Override
    protected void onPause() {
        super.onPause();

        SocketHandler.getInstance().onActivityPaused(this);
    }

    /**
     * Called when transaction is cancelled on backpress
     * update the status of transaction to 'user cancelled'
     */
    protected void postToPaytxn() {
        Thread updateTxn = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = new UpiUtil().getHttpsConn(UpiConstant.PAYMENT_URL + "/" + UpiConstant.PAYU_PAYTXN, null, -1, new UpiUtil().getCookieList(UpiConstant.PAYMENT_URL));
                    if (!(conn.getResponseCode() == 200)) {
                        L.v("BackButtonClick - Successful post to Paytxn");
                        analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN, UpiConstant.SUCCESS);
                    } else {
                        L.v("BackButtonClick - UnSuccessful post to Paytxn");
                        analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN, UpiConstant.FAILURE);
                    }
                } catch (Exception e) {
                    L.v("BackButtonClick Exception - " + e.getMessage());
                    analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN_WITH_EXCEPTION, UpiConstant.FAILURE);
                }
            }
        });
        updateTxn.setPriority(Thread.MAX_PRIORITY);
        updateTxn.start();
    }


    void analyticsLogging(String key, String value) {
        try {
            if(analytics == null){
                this.analytics = AnalyticsUpiUnit.getInstance(getApplicationContext());
            }
            if (upiConfig != null) {
                analytics.log(UpiUtil.getLogMessage(
                        PaymentResponseUpiSdkActivity.this.getApplicationContext(),
                        key,
                        value,
                        upiConfig.getMerchantKey(),
                        upiConfig.getTransactionID()));
            }
        } catch (Exception e) {
            L.v("Class Name:getTransactionID " + key + " " + value + e.getMessage());
        }
    }
}
