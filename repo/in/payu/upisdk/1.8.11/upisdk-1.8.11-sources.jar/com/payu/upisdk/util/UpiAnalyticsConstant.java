// The MIT License (MIT)
//
// Copyright (c) 2014-2015 PayU India
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package com.payu.upisdk.util;

/**
 * Created by Shahbaz
 * Constants for analytics.
 */

public class UpiAnalyticsConstant {

    public static final String SUCCESS_TRANSACTION = "success_transaction";
    public static final String SUCCESS_TRANSACTION_UPI_SDK_PHONE_PE = "success_transaction_upi_sdk_phonepe";
    public static final String SUCCESS_TRANSACTION_UPI_SDK_GPAY = "success_transaction_upi_sdk_gpay";
    public static final String FAILURE_TRANSACTION = "failure_transaction";
    public static final String FAILURE_TRANSACTION_UPI_SDK_PHONE_PE = "failure_transaction_upi_sdk_phonepe";
    public static final String FAILURE_TRANSACTION_UPI_SDK_GPAY = "failure_transaction_upi_sdk_gpay";
    public static final String TRNX_STATUS_UPI_MODULE_NOT_SUPPORTED = "trnx_status_upi_module_not_supported";

    public static final String MERCHANT_KEY = "merchant_key";
    public static final String TRANSACTION_ID = "txnid";


    //Event Analyitcs
    public static final String PACKAGE_NAME = "package_name";
    public static final String KEY = "event_key";
    public static final String VALUE = "event_value";
    public static final String TIMESTAMP = "ts";
    public static final String VERSION_CODE = "application_version";

    //Key for Event PayUAnalytics
    public static final String TRNX_STATUS = "trxn_status_upi_sdk";
    public static final String TRNX_STATUS_VERIFY_PAYMENT_RESPONSE = "trnx_status_verify_payment_response";
    public static final String TRNX_STATUS_FAILURE_TRANSACTION = "trnx_status_failure_transaction";
    public static final String TRNX_STATUS_CANCEL_TRANSACTION = "trnx_status_cancel_transaction";
    public static final String TRNX_STATUS_ONFAILURE = "trnx_status_onFailure";
    public static final String TRNX_STATUS_ONPAYUFAILURE = "trnx_status_onPayuFailure";
    public static final String TRNX_STATUS_ONPAYUSUCCESS = "trnx_status_onPayuSuccess";
    public static final String TRNX_STATUS_ONSUCCESS = "trnx_status_onSuccess";
    public static final String BACK_BUTTON_CANCEL_CLICK = "back_button_cancel";
    public static final String PAYMENT_APP = "_payment_app";
    public static final String _PAYMENT_APP_RESPONSE = "_payment_app_response";
    public static final String PAYMENT_APP_RESPONSE = "payment_app_response";


    // Keys set
    public static final String CB_VERFIY_WAY = "long_polling_from";
    public static final String RESULT_IS_EMPTY = "result_is_empty";
    public static final String VERIFY_USING_HTTP = "verify_using_http";
    public static final String NO_UPI_APPS_PRESENT = "No Upi apps present and collect disabled.";


    public static final String SDK_VERSION_NAME = "upi_sdk_version";
    public static final String CB_VERSION_NAME = "cb_version_name";
    public static final String DEVICE_OS_VERSION = "os_version";
    public static final String NETWORK_INFO = "network_info";
    public static final String NETWORK_STRENGTH = "network_strength";
    public static final String DEVICE_RESOLUTION = "resolution";
    public static final String DEVICE_MANUFACTURE = "device_manufacturer";
    public static final String DEVICE_MODEL = "device_model";
    public static final String TXN_ERROR_REASON = "txn_error_reason";
    public static final String MAKEPAYMENT = "makepayment";
    public static final String MAKEPAYMENT_0 = "makepayment";
    public static final String HANDLE_NON_UPI_PHONE_PE = "handle_non_upi_phone_pe";
    public static final String HANDLE_NON_UPI_TEZ = "handle_non_upi_tez";
    public static final String GPAY_MAKEPAYMENT = "gpaywrapper_makePayment";
    public static final String SOCKET = "socket";
    public static final String SOCKET_CANCEL = "socket_cancel";
    public static final String SOCKET_TRXN_STATUS = "socket_trxn_status_upi_sdk";
    public static final String SOCKET_TRXN_STATUS_0 = "socket_trxn_status_upi_sdk_0";
    public static final String TEZTPV_URL ="teztpv_url";
    public static final String UPI_GENERIC_URL ="upi_generic_url";
    public static final String TEZTPV_POST_DATA = "teztpv_post_data";
    public static final String UPI_GENERIC_POST_DATA = "upi_generic_postdata";
    public static final String NON_UPI_FLOWS =  "non_upi_flows";
    public static final String INITIATE_PAYMENT_FAILED =  "initiatePayment_failed";
    public static final String INITIATE_PAYMENT_URL =  "initiatePayment_url";
    public static final String INTENT_URI ="intent_uri_to_psp_app";
    public static final String INITIATE_PAYMENT_POST_DATA = "initiatePayment_post_data";
    public static final String INITIATE_PAYMENT_RESPONSE = "initiatePayment_response_payu_be";
    public static final String SDK_INTEGRATION = "sdkIntegration";
    public static final String ORIGIN_SDK = "originSDK";
    public static final String DEVICE_DETAILS = "device_details";
    public static final String PAYMENT_TYPE = "paymentType";
    public static final String PAYMENT_TYPE_STATE = "payment_type_state";
    public static final String PAYMENT_TYPE_STATE_0 = "payment_type_state_0";
    public static final String PAYMENT_TYPE_STATE_1 = "payment_type_state_1";
    public static final String PAYMENT_TYPE_STATE_2 = "payment_type_state_2";
    public static final String PAYMENT_TYPE_STATE_3 = "payment_type_state_3";
    public static final String LAUNCH_ERROR = "launch_error";
    public static final String LAUNCH_ERROR_0 = "launch_error_0";
    public static final String ON_MERCHANT_URL_FINISHED = "onMerchantUrlFinished_isSuccessTransaction";
    public static final String PACKAGENAME_ = "packageName_";
    public static final String _VERSION_NAME_ = "_version_name_";
    public static final String MAKEPAYMENT_EXCEPTION = "makepayment_exception";
    public static final String MAKEPAYMENT_EXCEPTION_0 = "makepayment_exception_0";
    public static final String INVALID_RESPONSE = "invalid_response";
    public static final String PAYMENT_STATUS_ZERO_AND_RESULT_BLANK = "paymentStatus_zero_&_paymentResult_blank";
    public static final String BASE64_RESPONSE_NULL = "base64Response_null";
    public static final String PAYMENT_RESPONSE_NULL = "paymentResponse_null";
    public static final String _LAUNCHED = "_launched";
    public static final String LAUNCHED = "launched";
    public static final String UPI_APP_ALREADY_OPEN = "_upi_app_already_open";
    public static final String VERIFY_TYPE = "verify_type";
    public static final String UPI_SOCKET = "upi_socket";
    public static final String PUSH_ENABLED = "push_enabled";
    public static final String TECHNICAL_ERROR = "Technical Error";
    public static final String TECHNICAL_ERROR_AND_ERROR_MESSAGE = "technical_error_&_error_message";
    public static final String PAYU_POST_PAYTXN = "post_pay_txn";
    public static final String PAYU_POST_PAYTXN_WITH_EXCEPTION = "post_pay_txn_exception";
    public static final String PAYMENT_RESPONSE_FIELDS = "payment_response_fields";
    public static final String PAYU_UPI_SDK_PAYMENT_MODE = "upi_sdk_payment_mode";
    public static final String MAKE_SEAMLESS_PAYMENT = "makeSeamlessPayment_called";
    public static final String MAKE_PAYMENT = "makePayment_called";
    public static final String INVOKING_APP_NOT_INSTALLED = "invoking_app_not_installed";
    public static final String UPI_NOT_ENABLED_ON_APP = "upi_not_enabled_on_application";
    public static final String CHECK_PAYMENT_NOT_CALLED = "forget_to_call_checkForPaymentAvailability";
    public static final String CHECK_PAYMENT_NOT_CALLED_PAYMENT_NAME = "forget_to_call_checkForPaymentAvailability_paymentName";
    public static final String ACTIVITY_FINISHED = "activity_finished";
    public static final String NOT_INITIATE = "initiatePayment_is_not_initiated";
    public static final String REQUEST_CODE = "requestCode";
    public static final String ERROR_RESPONSE_FAILED = "error_callback_failed";
    public static final String ACTIVITY_NOT_FOUND = "activity_not_found";
    public static final String DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED = "DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED";
    public static final String ACTIVITY_RESOLVE_FAILED = "activity_resolve_failed";
    public static final String UPI_COLLECT_POST_URL = "upiCollect_postUrlWebView";
    public static final String UPI_COLLECT_HTTP_ERROR = "upiCollect_onReceivedHttpError";
    public static final String UPI_COLLECT_ERROR = "upiCollect_onReceivedError";
    public static final String UPI_COLLECT_SSL_ERROR = "upiCollect_onReceivedSslError";
    public static final String UPI_COLLECT_PAGE_FINISHED = "upiCollect_onPageFinished";
    public static final String UPI_COLLECT_PAGE_STARTED = "upiCollect_onPageStarted";

    public static final String PAYU_UPI_FRAGMENT_INVALID_STATE = "invalid_fragment_state ";
    public static final String PAYMENT_HANDLER_NULL = "payment_handler_null";

    public static final String PAYU_UPI_LIFECYCLE_STATE = "payu_upi_lifecycle_state";



}