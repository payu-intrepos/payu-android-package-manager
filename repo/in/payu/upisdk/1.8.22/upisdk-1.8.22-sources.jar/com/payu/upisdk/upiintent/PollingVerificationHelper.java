package com.payu.upisdk.upiintent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.KeyEvent;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.interfaces.IVerifyResponse;
import com.payu.socketverification.polling.PollingVerify;
import com.payu.socketverification.util.NetworkUtil;
import com.payu.socketverification.util.PayUSocketInfo;
import com.payu.socketverification.widgets.PayUProgressDialog;
import com.payu.upisdk.R;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;

/**
 * Helper class for handling polling verification when UPI apps return immediately.
 * Used by both PaymentResponseUpiSdkActivity and PaymentResponseUpiSdkFragment.
 */
public class PollingVerificationHelper {

    private PollingVerify currentPollingVerify;
    private PayUProgressDialog progressDialog;
    private final Activity activity;
    private final PaymentResponse paymentResponse;
    private final UpiConfig upiConfig;
    private final PayUAnalytics analytics;
    private final PaymentHandler paymentHandler;
    private final LifecycleCallback lifecycleCallback;

    /**
     * Interface to check lifecycle state (different for Activity vs Fragment)
     */
    public interface LifecycleCallback {
        boolean isAlive();
        void onAnalyticsLog(String key, String value);
    }

    public PollingVerificationHelper(
            Activity activity,
            PaymentResponse paymentResponse,
            UpiConfig upiConfig,
            PayUAnalytics analytics,
            PaymentHandler paymentHandler,
            LifecycleCallback lifecycleCallback
    ) {
        this.activity = activity;
        this.paymentResponse = paymentResponse;
        this.upiConfig = upiConfig;
        this.analytics = analytics;
        this.paymentHandler = paymentHandler;
        this.lifecycleCallback = lifecycleCallback;
    }

    private AlertDialog cancelConfirmationDialog;

    /**
     * Shows the polling progress dialog. The dialog is intentionally NOT cancelable so the system
     * BACK key does not silently cancel/fail the transaction. Instead we intercept BACK with a key
     * listener and ask the user "Do you really want to cancel the transaction?" before doing anything.
     */
    public void showCancelableProgressDialog() {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        if (progressDialog == null) {
            progressDialog = new PayUProgressDialog(activity, UpiData.SINGLETON.getPayUCustomDialogView());
        }

        progressDialog.setCancelable(false);
        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
                        return true;
                    }
                    if (cancelConfirmationDialog != null && cancelConfirmationDialog.isShowing()) {
                        return true;
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                    builder.setCancelable(false);
                    builder.setMessage(activity.getString(R.string.do_you_really_want_to_cancel_the_transaction));
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            disposePolling();
                            hideProgressDialog();
                            if (paymentHandler != null) {
                                if (lifecycleCallback != null) {
                                    lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.PAYU_UPI_LIFECYCLE_STATE,
                                            UpiAnalyticsConstant.TXN_CANCELLED_BY_PRESS_BACK_BUTTON);
                                }
                                paymentHandler.verifyPayment(UPIPaymentConstants.FAILURE, UPIPaymentConstants.TXN_CANCELLED_BY_PRESS_BACK_BUTTON);
                            } else {
                                if (lifecycleCallback != null) {
                                    lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.SOCKET_TRXN_STATUS,
                                            UpiAnalyticsConstant.TXN_CANCELLED_BY_PRESS_BACK_BUTTON);
                                }
                                if (UpiData.SINGLETON.getPayUPICallback() != null) {
                                    UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(null, null);
                                }
                            }
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    cancelConfirmationDialog = builder.create();
                    cancelConfirmationDialog.show();
                    return true;
                }
                return false;
            }
        });

        if (UpiData.SINGLETON.getPayUCustomDialogView() == null) {
            if (!activity.isFinishing() && !activity.isDestroyed()) {
                progressDialog.setPayUDialogSettings(activity);
                progressDialog.show();
            }
        }
    }

    /**
     * Hides the progress dialog if showing
     */
    public void hideProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()
                && activity != null && !activity.isDestroyed() && !activity.isFinishing()) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    /**
     * Start long polling to verify payment status when app returns immediately
     */
    public void startLongPollingVerification() {
        if (paymentResponse == null || paymentResponse.getSocketParams() == null) {
            if (lifecycleCallback != null) {
                lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, 
                        "paymentResponse or socketParams is null for polling");
            }
            if (paymentHandler != null) {
                paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP);
            }
            return;
        }

        PayUSocketInfo socketInfo = new PayUSocketInfo();
        socketInfo.setReferenceId(paymentResponse.getReferenceId());
        socketInfo.setPushServiceUrl(paymentResponse.getSocketParams().getPushServiceUrl());

        String pollInterval = paymentResponse.getSocketParams().getUpiServicePollInterval();
        if (pollInterval != null && !pollInterval.isEmpty()) {
            socketInfo.setUpiServicePollInterval(Long.parseLong(pollInterval));
        }

        String pushExpiry = paymentResponse.getSocketParams().getSdkUpiPushExpiry();
        if (pushExpiry != null && !pushExpiry.isEmpty()) {
            socketInfo.setSdkUpiPushExpiry(Long.parseLong(pushExpiry));
        }

        IVerifyResponse verifyResponseCallback = new IVerifyResponse() {
            @Override
            public void getVerifyResponse(boolean isFinished, String response) {
                L.v("PollingVerify response: " + response);
                
                if (lifecycleCallback != null) {
                    lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.CB_VERFIY_WAY, 
                            "polling_response_received_isFinished_" + isFinished);
                }
                
                if (lifecycleCallback != null && !lifecycleCallback.isAlive()) {
                    if (lifecycleCallback != null) {
                        lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.ACTIVITY_FINISHED, 
                                "polling_callback_ignored_lifecycle_dead");
                    }
                    return;
                }
                currentPollingVerify = null;
                hideProgressDialog();
                if (UpiData.SINGLETON.getPayUPICallback() != null) {
                    String status = NetworkUtil.getTransactionStatus(response);
                    if (lifecycleCallback != null) {
                        lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.TRNX_STATUS, 
                                "polling_verify_status_" + status);
                    }
                    
                    if (status != null && UPIPaymentConstants.SUCCESS.equalsIgnoreCase(status)) {
                        if (lifecycleCallback != null) {
                            lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.TRNX_STATUS_ONSUCCESS, 
                                    "polling_verify_success");
                        }
                        UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(response, null);
                    } else {
                        if (lifecycleCallback != null) {
                            lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.TRNX_STATUS_ONFAILURE, 
                                    "polling_verify_failure_status_" + status);
                        }
                        UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(response, null);
                    }
                } else {
                    if (lifecycleCallback != null) {
                        lifecycleCallback.onAnalyticsLog(UpiAnalyticsConstant.ERROR_RESPONSE_FAILED, 
                                "PayUPICallback_is_null");
                    }
                }
            }
        };


        currentPollingVerify = new PollingVerify();
        currentPollingVerify.startLongPolling(
                activity,
                socketInfo,
                verifyResponseCallback,
                analytics,
                upiConfig.getMerchantKey(),
                upiConfig.getTransactionID()
        );
    }

    /**
     * Dispose the polling handler if active
     */
    public void disposePolling() {
        if (currentPollingVerify != null) {
            currentPollingVerify.disposePollingHandler();
            currentPollingVerify = null;
        }
    }

    /**
     * Convenience method to show dialog and start polling together
     */
    public void startPollingWithDialog() {
        showCancelableProgressDialog();
        startLongPollingVerification();
    }
}
