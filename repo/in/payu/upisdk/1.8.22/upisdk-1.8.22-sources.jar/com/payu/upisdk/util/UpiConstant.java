package com.payu.upisdk.util;


import java.util.HashSet;
import java.util.Set;

public interface UpiConstant {
    String MERCHANT_KEY = "merchantid";
    String TEZ = "TEZ";
    String TEZ_S = "tez";
    String TEZ_TPV = "teztpv";
    String UPI_INTENT = "INTENT";
    String UPI_INTENT_S = "intent";
    String UPI_INTENT_TPV = "inttpv";
    String INTENT = "INTENT";
    String UPI_COLLECT = "upi";
    String UPI_COLLECT_TPV = "upitpv";
    String UPI_COLLECT_GENERIC = "upi_generic";
    String PHONEPE = "PPINTENT";
    String PHONEPE_S = "ppintent";
    String SAMPAY = "SAMPAY";
    String SAMPAY_S = "sampay";
    String TEZOMNI = "tezomni";

    // PayU url (payment option url)
    String PAYMENT_URL = "https://secure.payu.in";
    String TEST_URL = "https://test.payu.in";
    String _PAYMENT = "/_payment";
    String PRODUCTION_FETCH_DATA_URL = "https://info.payu.in";
    String MERCHANT_POST_SERVICE_FORM = "/merchant/postservice.php?form=2";

    // Payment url


    // mobile dedicated test env

    //https://mpi.onlinesbi.com/electraSECURE/vbv/MPIACSResponse.jsp
    String CB_CONFIG = "cb_config";

    String POST_DATA = "postData";
    String NONE = "none";
    String UPI_CONFIG = "upiConfig";
    String POST_DATA_UPI_COLLECT_GENERIC = "postdata_collect";

    // configurable merhant key.
    String KEY = "key";
    // payment mandatory parms

    String TXNID = "txnid";

    //For PaymentOptionWrapper
    String PAYMENT_OPTION_SUCCESS = "onPaymentOptionSuccess";
    String PAYMENT_SUCCESS = "onPaymentSuccess";
    String PAYMENT_OPTION_FAILURE = "onPaymentOptionFailure";
    String PAYMENT_FAILURE = "onPaymentFailure";
    String PAYMENT_OPTION_INIT_SUCCESS = "onPaymentOptionInitialisationSuccess";
    String PAYMENT_OPTION_INIT_FAILURE = "onPaymentOptionInitialisationFailure";
    String PAYMENT_INIT_SUCCESS = "onPaymentInitialisationSuccess";
    String PAYMENT_INIT_FAILURE = "onPaymentInitialisationFailure";
    String ON_GPAY_ERROR_RECEIVED = "onGpayErrorReceived";
    String ON_PAYMENT_TERMINATE = "onPaymentTerminate";
    String ON_BACK_APPROVE = "onBackApprove";
    String ON_BACK_DISMISS = "onBackDismiss";

  int DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED = 1025;
  int NOT_PROVIDED_COMPLETE_INFO = 1022;
  int CHECK_PAYMENT_NOT_CALLED = 1021;
  int SOCKET_NOT_CREATED = 1003;
  int MISSING_PARAMS = 1006;
  int INVOKING_APP_NOT_INSTALLED_CODE = 1004;
  int INVOKING_APP_NOT_ONBOARDED_CODE = 1005;
  String CHECK_PAYMENT_NOT_CALLED_MSG = "Forget to call checkForPaymentAvailability";
  String INVOKING_APP_NOT_INSTALLED_MESSAGE = "Invoking App not Installed: ";
  String INVOKING_APP_NOT_ONBOARDED_MESSAGE = "UPI is not enabled on application: ";
  String PROVIDED_UPI_CONFIG_NULL = "UpiConfig must not be null! ";
  String NOT_PROVIDED_COMPLETE_INFO_KEY = "NOT_PROVIDED_COMPLETE_INFO";
  String NOT_PROVIDED_COMPLETE_INFO_KEY_UPI_CONFIG = "not_provided_complete_info_key_upi_config";
  String NOT_PROVIDED_COMPLETE_INFO_KEY_EXCPEPTION = "not_provided_complete_info_key_excpeption";
  String NOT_PROVIDED_COMPLETE_INFO_KEY_PAYMENT_OPTION = "not_provided_complete_info_key_payment_option";
  String NOT_PROVIDED_COMPLETE_INFO_KEY_MERCHANT_KEY = "not_provided_complete_info_key_merchant_key";
  //Payment Related Details Api call
  String PAYMENT_TYPE = "payment_type";
  String MERCHANT_RESPONSE_TIMEOUT = "merchantResponseTimeout";
  //Error Code

    // status
    String SUCCESS = "SUCCESS";
    String FAILURE = "FAILURE";
    String SUBMITTED = "SUBMITTED";

    //Keys for Device Tracking for transaction
    String SDK_VERSION_NAME = "upi_sdk_version";
    String CB_VERSION_NAME = "cb_version_name";


    // for bundle
    @Deprecated
    String PAYMENT_DEFAULT_PARAMS = "payment_default_params";

    // sets and lists

    Set<String> PG_SET = new HashSet<>();


    // payment mode params
    String BANK_CODE = "bankcode";

    String UPI = "upi";
    String UPITPV = "UPITPV";
    String TEZTPV = "TEZTPV";
    String INTTPV = "INTTPV";
    String SAMSUNG_PAY = "SAMPAY";
    String PHONEPE_INTENT = "PPINTENT";
    String PAYMENT_RESPONSE = "payment_response";
    String IS_UPI_APP_ALREADY_OPENED = "is_upi_app_already_opened";
    String TITLE = "title";
    String VALUE = "value";
    String IMAGE = "image";
    String DATA = "data";
    String PAYU_PAYMENT_PARAMS = "payu_payment_params";
    String HASHES = "hashes";
    String VALIDATE_VPA = "validate_vpa";
    String VPA = "vpa";
    String PAYMENT = "payment";

    class INIT {
        static {
            //PG_SET
            PG_SET.add(UPI);
            PG_SET.add(TEZ);
            PG_SET.add(SAMSUNG_PAY);
            PG_SET.add(PHONEPE_INTENT);
            PG_SET.add(INTENT);

        }

        INIT() {
        }
    }
    String VERIFY = "VERIFY";
    String PAYU_PAYTXN = "paytxn";
    String PAYMENT_OPTION = "payment_option";
    String INITIATE = "_initiate";
    String UPI_INTENT_DATA = "upi://pay?pa=";

    //For Samsung Pay Wrapper
    String SAMSUNGPAY_SUCCESS = "onSamsungPaySuccess";
    String SAMSUNGPAY_FAILURE = "onSamsungPayFailure";
    String SAMSUNGPAY_INIT_SUCCESS = "onSamsungPayInitialisationSuccess";
    String SAMSUNGPAY_INIT_FAILURE = "onSamsungPayInitialisationFailure";
    int MERCHANT_URL_LOADING_TIMEOUT = 10000;
    String LAUNCH_ERROR = "_launch_error";
    String PHONEPE_PACKAGE = "com.payu.phonepe.PhonePe";
    String GPAY_PACKAGE = "com.payu.gpay.GPay";
    String SAMSANGPAY_PACKAGE = "com.payu.samsungpay.PayUSamsungPay";
    String PAYU_WEB_SERVICE_URL = "payu_web_service_url";
    String PAYU_POST_URL = "payu_post_url";

    //Analytics
    String PLATFORM_KEY = "platform";
    String PLATFORM_VALUE = "android";
    String SDK_PLATFORM_KEY = "sdk_platform";
    String NAME_KEY = "name";
    String NAME_VALUE = "upisdk";
    String VERSION_KEY = "version";
    String COMMAND_REQUEST = "command_request";
    String CUSTOMER_CANCELLED_ON_PSP_APP = "Customer cancelled on PSP App";
    String CUSTOMER_CLOSED_THE_INTENT_TRAY = "Customer closed the intent tray";
    String COMMAND = "command";
    String GET_RESPONSE_FROM_PSP = "response_from_psp";
    String CP_UPI_INTENT_PREFIX = "upi://pay?";
    String MANDATORY_PRAMS_NOT_PASSED = "Mandatory parameters not passed";
    String ERROR_IN_API_RESPONSE = "Unable to receive correct API response";
    String CP_VALIDATE_AUTO_PAY_VPA = "validateautopayvpa";


    String PACKAGE_ID_PHONEPE = "com.phonepe.app";
    String PACKAGE_ID_PAYTM = "net.one97.paytm";
    String PACKAGE_ID_BHIM = "in.org.npci.upiapp";
    String PACKAGE_ID_AMAZONPAY = "in.amazon.mShop.android.shopping";
    String PACKAGE_ID_GOOGLEPAY = "com.google.android.apps.nbu.paisa.user";
    String PACKAGE_ID_WHATSAPP = "com.whatsapp";
    String PACKAGE_ID_FIMONEY = "com.epifi.paisa";
    String PACKAGE_ID_JUPITER = "money.jupiter";
    String PACKAGE_ID_SLICE = "indwin.c3.shareapp";
    String PACKAGE_ID_MOBIKWIK = "com.mobikwik_new";
    String PACKAGE_ID_GOKIWI = "in.gokiwi.kiwitpap";
    String PACKAGE_ID_CRED = "com.dreamplug.androidapp";
    String PACKAGE_ID_BAJAJPAY = "org.altruist";
    String PACKAGE_ID_FLIPKART= "com.flipkart.android";

    String UPI_APPNAME_PHONEPE = "phonepe";
    String UPI_APPNAME_PAYTM = "paytm";
    String UPI_APPNAME_BHIM = "bhim";
    String UPI_APPNAME_AMAZONPAY = "amazonpay";
    String UPI_APPNAME_GOOGLEPAY = "googlepay";
    String UPI_APPNAME_WHATSAPP = "whatsapp";
    String UPI_APPNAME_FIMONEY = "fimoney";
    String UPI_APPNAME_JUPITER = "jupiter";
    String UPI_APPNAME_SLICE = "slice";
    String UPI_APPNAME_MOBIKWIK = "mobikwik";
    String UPI_APPNAME_GOKIWI = "gokiwi";
    String UPI_APPNAME_CRED = "cred";
    String UPI_APPNAME_BAJAJPAY = "bajajpay";
    String UPI_APPNAME_FLIPKART= "flipkart";

    String PAYU_IS_PROD = "isProduction";
    String PAYU_ENVIRONMENT= "environment";


}
