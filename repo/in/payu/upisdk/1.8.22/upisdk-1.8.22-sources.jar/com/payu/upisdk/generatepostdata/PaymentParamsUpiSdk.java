//    Copyright (c) 2014 - 2015 payu@india.com
//
//    Permission is hereby granted, free of charge, to any person obtaining a copy
//    of this software and associated documentation files (the "Software"), to deal
//    in the Software without restriction, including without limitation the rights
//    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//    copies of the Software, and to permit persons to whom the Software is
//    furnished to do so, subject to the following conditions:
//
//    The above copyright notice and this permission notice shall be included in
//    all copies or substantial portions of the Software.
//
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//    THE SOFTWARE.

package com.payu.upisdk.generatepostdata;

import android.os.Parcel;

import com.payu.paymentparamhelper.PaymentParams;

/**
 * Created by Shahbaz
 * Since its parcelable you can pass it through intent with out any difficult.
 */
public class PaymentParamsUpiSdk extends PaymentParams {

    protected PaymentParamsUpiSdk(Parcel in) {
        super(in);
    }

    public PaymentParamsUpiSdk() {
    }

    public static final Creator<PaymentParamsUpiSdk> CREATOR = new Creator<PaymentParamsUpiSdk>() {
        @Override
        public PaymentParamsUpiSdk createFromParcel(Parcel in) {
            return new PaymentParamsUpiSdk(in);
        }

        @Override
        public PaymentParamsUpiSdk[] newArray(int size) {
            return new PaymentParamsUpiSdk[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}
