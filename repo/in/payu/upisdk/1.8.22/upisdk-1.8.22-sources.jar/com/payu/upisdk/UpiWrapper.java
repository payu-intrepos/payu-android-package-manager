package com.payu.upisdk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;

import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallback;
import com.payu.upisdk.callbacks.PayUUPICallbackInterface;
import com.payu.upisdk.upi.IValidityCheck;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiUtil;

import java.lang.reflect.Proxy;

public class UpiWrapper {

    private final PayUUPICallbackInterface
            wrapperListener;
    private final Upi upi;
    private final PayUUPICallback payUUPICallback = new PayUUPICallback() {

        @Override
        public void onVpaEntered(String vpa, IValidityCheck iValidityCheck) {
            L.v("Class Name: " + getClass().getCanonicalName() + "onVpaEntered upisdk/Upiwrapper vpa " + vpa);
            wrapperListener.onVpaEntered(vpa, iValidityCheck);
        }

        @Override
        public void onPaymentFailure(String payuResult, String merchantResponse) {
            super.onPaymentFailure(payuResult, merchantResponse);
            L.v("Class Name: " + getClass().getCanonicalName() + "onPaymentFailure  upisdk/upiwrapper payuResult " + payuResult + "  merchamtResponse  " + merchantResponse);
            wrapperListener.onPaymentFailure(payuResult, merchantResponse);
        }

        @Override
        public void onPaymentSuccess(String payuResult, String merchantResponse) {
            super.onPaymentSuccess(payuResult, merchantResponse);
            L.v("Class Name: " + getClass().getCanonicalName() + "onPaymentSuccess  upisdk/upiwrapper payuResult " + payuResult + "  merchamtResponse  " + merchantResponse);
            wrapperListener.onPaymentSuccess(payuResult, merchantResponse);

        }

        @Override
        public void isPaymentOptionAvailable(boolean isAvailable, String paymentType) {
            L.v("Class Name: " + getClass().getCanonicalName() + "isPaymentOptionAvailable upisdk/upiwrapper isAvailable " + isAvailable + "  PaymentType " + paymentType);
            //  super.isPaymentOptionAvailable(isAvailable, paymentType);
            wrapperListener.isPaymentOptionAvailable(isAvailable, paymentType);
        }

        @Override
        public void isPaymentOptionAvailable(boolean isAvailable, PaymentOption paymentOption) {
            L.v("Class Name: " + getClass().getCanonicalName() + " | isPaymentOptionAvailable  upisdk/upiwrapper isAvailable: " + isAvailable);
            super.isPaymentOptionAvailable(isAvailable, paymentOption);
            wrapperListener.isPaymentOptionAvailable(isAvailable, paymentOption.getPaymentName());
        }

        @Override
        public void onPaymentTerminate() {
            L.v("Class Name: " + getClass().getCanonicalName() + " | onPaymentTerminate  upisdk/upiwrapper");
            super.onPaymentTerminate();
            wrapperListener.onPaymentTerminate();
        }

        @Override
        public void onUpiErrorReceived(int code, String errorMsg) {
            L.v("Class Name: " + getClass().getCanonicalName() + " | onUpiErrorReceived upisdk/upiwrapper errorCode: " + code + " | errorMsg: " + errorMsg);
            super.onUpiErrorReceived(code, errorMsg);
            wrapperListener.onUpiErrorReceived(code, errorMsg);
        }

        @Override
        public void onBackApprove() {
            L.v("Class Name: " + getClass().getCanonicalName() + " | onBackApprove  upisdk/upiwrapper");
            super.onBackApprove();
            wrapperListener.onBackApprove();
        }

        @Override
        public void onBackDismiss() {
            L.v("Class Name: " + getClass().getCanonicalName() + " | onBackDismiss  upisdk/upiwrapper");
            super.onBackDismiss();
            wrapperListener.onBackDismiss();
        }

        @Override
        public void onBackButton(AlertDialog.Builder alertDialogBuilder) {
            L.v("Class Name: " + getClass().getCanonicalName() + " | onBackButton  upisdk/upiwrapper");
            super.onBackButton(alertDialogBuilder);
            wrapperListener.onBackButton(alertDialogBuilder);
        }
    };

    /**
     * Entry point for CustomBrowser to initiate Upisdk through Reflection.
     *
     * @param handler
     */
    public UpiWrapper(java.lang.reflect.InvocationHandler handler) {
        wrapperListener = (PayUUPICallbackInterface) Proxy.newProxyInstance(
                PayUUPICallbackInterface.class.getClassLoader(),
                new Class[]{PayUUPICallbackInterface.class},
                handler);
        // UpiData.SINGLETON.setPayUUPICallbackInterface(wrapperListener);
        this.upi = Upi.getInstance();
    }

    /**
     * Function to make payment using CB UpiWrapper
     *
     * @param postData Post Data
     */
    public void makePayment(Activity activity, String postData, Boolean isUserCacheEnabled,
                            String paymentType, Integer merchantResponseTimeout, Integer gmsEnableValue, View customProgressDialogView,
                            String postUrl) {
        UpiConfig upiConfig = new UpiConfig();
        upiConfig.setMerchantResponseTimeout(merchantResponseTimeout);
        upiConfig.setPayuPostData(postData);
        upiConfig.setPaymentType(paymentType);
        upiConfig.setPostUrl(postUrl);
        upiConfig.setGmsProviderUpdatedStatus(gmsEnableValue);
        upiConfig.setPhonePeUserCacheEnabled(isUserCacheEnabled);
        upiConfig.setTransactionID(UpiUtil.getDataFromPostData(postData).get("txnid"));
        upiConfig.setMerchantKey(UpiUtil.getDataFromPostData(postData).get("key"));
        upiConfig.setProgressDialogCustomView(customProgressDialogView);
//        UpiData.SINGLETON.setPayUCustomDialogView(customProgressDialogView);

        upi.makePayment(payUUPICallback, activity, upiConfig);
    }

    /**
     * Function to make payment using CB UpiWrapper
     *
     * @param postData Post Data
     */
    public Fragment makeSeamlessPayment(String postData, Boolean isUserCacheEnabled,
                                        String paymentType, Integer merchantResponseTimeout, Integer gmsEnableValue, View customProgressDialogView,
                                        String postUrl, Context context) {
        UpiConfig upiConfig = new UpiConfig();
        upiConfig.setMerchantResponseTimeout(merchantResponseTimeout);
        upiConfig.setPayuPostData(postData);
        upiConfig.setPaymentType(paymentType);
        upiConfig.setPostUrl(postUrl);
        upiConfig.setGmsProviderUpdatedStatus(gmsEnableValue);
        upiConfig.setPhonePeUserCacheEnabled(isUserCacheEnabled);
        upiConfig.setTransactionID(UpiUtil.getDataFromPostData(postData).get("txnid"));
        upiConfig.setMerchantKey(UpiUtil.getDataFromPostData(postData).get("key"));
        upiConfig.setProgressDialogCustomView(customProgressDialogView);
//        UpiData.SINGLETON.setPayUCustomDialogView(customProgressDialogView);

        return upi.makeSeamlessPayment(payUUPICallback, upiConfig, context);
    }

    public void makePayment(Activity activity, View customProgressDialogView, Bundle bundle) {

        UpiConfig upiConfig = new UpiConfig();
        if (bundle.getInt("merchantResponseTimeout") > 0)
            upiConfig.setMerchantResponseTimeout(bundle.getInt("merchantResponseTimeout"));
        String postData = bundle.getString("payuPostData");
        upiConfig.setPayuPostData(postData);
        upiConfig.setPaymentType(bundle.getString("paymentType"));
        upiConfig.setPostUrl(bundle.getString("postURL"));
        upiConfig.setGmsProviderUpdatedStatus(bundle.getInt("gmsProviderUpdatedStatus"));
        upiConfig.setPhonePeUserCacheEnabled(bundle.getBoolean("isPhonePeUserCacheEnabled"));
        upiConfig.setTransactionID(UpiUtil.getDataFromPostData(postData).get("txnid"));
        upiConfig.setMerchantKey(UpiUtil.getDataFromPostData(postData).get("key"));
        upiConfig.setProgressDialogCustomView(customProgressDialogView);
        upiConfig.setDisableIntentSeamlessFailure(bundle.getInt("disableIntentSeamlessFailure"));
        upiConfig.setPackageNameForSpecificApp(bundle.getString("packageNameForSpecificApp"));
        upiConfig.setProtectedScreen(bundle.getBoolean("isProtectedScreen"));

        UpiData.SINGLETON.setPayUCustomDialogView(customProgressDialogView);
        upi.makePayment(payUUPICallback, activity, upiConfig);
    }

    public Fragment makeSeamlessPayment(View customProgressDialogView, Bundle bundle, Context context) {

        UpiConfig upiConfig = new UpiConfig();
        if (bundle.getInt("merchantResponseTimeout") > 0)
            upiConfig.setMerchantResponseTimeout(bundle.getInt("merchantResponseTimeout"));
        String postData = bundle.getString("payuPostData");
        upiConfig.setPayuPostData(postData);
        upiConfig.setPaymentType(bundle.getString("paymentType"));
        upiConfig.setPostUrl(bundle.getString("postURL"));
        upiConfig.setGmsProviderUpdatedStatus(bundle.getInt("gmsProviderUpdatedStatus"));
        upiConfig.setPhonePeUserCacheEnabled(bundle.getBoolean("isPhonePeUserCacheEnabled"));
        upiConfig.setTransactionID(UpiUtil.getDataFromPostData(postData).get("txnid"));
        upiConfig.setMerchantKey(UpiUtil.getDataFromPostData(postData).get("key"));
        upiConfig.setProgressDialogCustomView(customProgressDialogView);
        upiConfig.setDisableIntentSeamlessFailure(bundle.getInt("disableIntentSeamlessFailure"));
        upiConfig.setPackageNameForSpecificApp(bundle.getString("packageNameForSpecificApp"));
        upiConfig.setProtectedScreen(bundle.getBoolean("isProtectedScreen"));
        upiConfig.setProduction(bundle.getBoolean("isProduction"));
        upiConfig.setGenericIntent(bundle.getBoolean("isGenericIntent"));

        UpiData.SINGLETON.setPayUCustomDialogView(customProgressDialogView);
        return upi.makeSeamlessPayment(payUUPICallback, upiConfig, context);
    }

    /**
     * Checking the payment availability from Custom Browser.
     *
     * @param context
     * @param paymentOptionHash
     * @param user_credentials
     * @param paymentType
     */
    public void checkForPaymentAvailability(Context context, String paymentOptionHash, String user_credentials, String paymentType, String merchantKey) {
        upi.checkForPaymentAvailability((Activity) context, paymentType, payUUPICallback, paymentOptionHash, user_credentials, merchantKey);
    }

    /**
     * Utility function to call verifyVpa from other SDK using reflection
     *
     * @param verifyVpaHash
     */
    public void verifyVpa(String verifyVpaHash) {
        if (UpiData.SINGLETON.getiValidityCheck() != null) {
            UpiUtil.setUpiConfigData();
            UpiData.SINGLETON.getiValidityCheck().verifyVpa(verifyVpaHash);
        }
    }

}

