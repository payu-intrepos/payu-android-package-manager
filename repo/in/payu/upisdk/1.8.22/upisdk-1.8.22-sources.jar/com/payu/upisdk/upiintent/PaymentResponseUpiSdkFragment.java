package com.payu.upisdk.upiintent;

import static android.app.Activity.RESULT_OK;
import static androidx.fragment.app.DialogFragment.STYLE_NORMAL;

import static com.payu.upisdk.util.UpiAnalyticsConstant.PAYU_UPI_LIFECYCLE_STATE;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.interfaces.FragmentListener;
import com.payu.socketverification.interfaces.PayUSocketEventListener;
import com.payu.socketverification.socket.SocketHandler;
import com.payu.socketverification.socket.SocketPaymentResponse;
import com.payu.upisdk.PackageListDialogFragment;
import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.R;
import com.payu.upisdk.Upi;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.OnBackButtonListener;
import com.payu.upisdk.callbacks.WebViewListener;
import com.payu.upisdk.upi.UpiWebInterface;
import com.payu.upisdk.upiinterface.GenericUPICallbacks;
import com.payu.upisdk.util.AnalyticsUpiUnit;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.PayUUpiUtil;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import org.jetbrains.annotations.NotNull;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class PaymentResponseUpiSdkFragment extends Fragment implements GenericUPICallbacks, WebViewListener, OnBackButtonListener {
    PaymentHandler paymentHandler;
    private String postData;
    ArrayList<PackageBean> packageBeanList;
    ArrayList<PackageBean> filteredList;
    private PayUAnalytics analytics;
    private String mPaymentType;
    private PaymentOption paymentOptionEnum;
    private WebView mCollectWebView;
    private RelativeLayout rlWebView;
    private UpiConfig upiConfig;
    private Boolean isUpiAppAlreadyOpen = false;
    private PaymentResponse paymentResponse;
    private static String mReturnUrl;
    private String errorReason = "";
    private int statusCode = 0;
    private PollingVerificationHelper pollingHelper;

    public static long upiIntentTime = 0;
    public static void startUpiIntentTimer() {
        upiIntentTime = System.currentTimeMillis();
    }



  private UpiWebInterface upiWebInterface;

    private PaymentResponseUpiSdkFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragmen_payment_response, container, false);
        mCollectWebView = view.findViewById(R.id.wvCollect);
        rlWebView = view.findViewById(R.id.rlWebView);
        return view;
    }

    public static PaymentResponseUpiSdkFragment newInstance(Bundle bundle) {
        PaymentResponseUpiSdkFragment fragment = new PaymentResponseUpiSdkFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle bundle = getArguments();
        PayUUpiUtil.updateLayoutSecurity(requireActivity(), upiConfig != null && upiConfig.isProtectedScreen(requireActivity().getApplicationContext()));
        if (bundle != null) {
            upiConfig = bundle.getParcelable(UpiConstant.UPI_CONFIG);
            SocketHandler.getInstance().onActivityCreated(getActivity(), getPayUSocketEventListener());

            if (null != savedInstanceState) {
                analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : saved instance is not null");

                if (null != savedInstanceState.get(UpiConstant.IS_UPI_APP_ALREADY_OPENED))
                    isUpiAppAlreadyOpen = savedInstanceState.getBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED);

                if (null != savedInstanceState.get(UpiConstant.UPI_CONFIG))
                    upiConfig = savedInstanceState.getParcelable(UpiConstant.UPI_CONFIG);

                if (null != savedInstanceState.get(UpiConstant.PAYMENT_RESPONSE))
                    paymentResponse = savedInstanceState.getParcelable(UpiConstant.PAYMENT_RESPONSE);
            }

            if (null != upiConfig) {
                postData = upiConfig.getPayuPostData();
                mPaymentType = upiConfig.getPaymentType();
                upiConfig.setProgressDialogCustomView(UpiData.SINGLETON.getPayUCustomDialogView());
//                makeActivityTransparentExceptCollectFlow();
                this.analytics = AnalyticsUpiUnit.getInstance(getContext());
                analyticsLogging(UpiConstant.PAYMENT_OPTION, mPaymentType.toLowerCase());
                if (!isUpiAppAlreadyOpen || paymentResponse == null) {
                    analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : handlePaymentFlow triggered");
                    handlePaymentFlow();
                } else {
                    analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : restoring payment handler");
                    postData = upiConfig.getPayuPostData();
                    if (!TextUtils.isEmpty(paymentResponse.getReturnUrl())) {
                        UpiData.SINGLETON.setVerifyUrl(paymentResponse.getReturnUrl());
                    }
                    String token = paymentResponse.getToken();
                    if (!TextUtils.isEmpty(token)) {
                        paymentHandler = new PaymentHandler(requireActivity(), postData, token);
                    } else {
                        paymentHandler = new PaymentHandler(requireActivity(), postData);
                    }
                    analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : payment Handler restored");
                }
            }
        }
      view.setFocusableInTouchMode(true);
      view.requestFocus();
      view.setOnKeyListener(new View.OnKeyListener() {
        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
          if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
            onBackButtonClicked();
            return true;
          }
          return false;
        }
      });

    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : onViewStateRestored");
        if(savedInstanceState != null) {
            analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : onViewStateRestored bundle is not null");
            upiConfig = savedInstanceState.getParcelable(UpiConstant.UPI_CONFIG);
            paymentResponse = savedInstanceState.getParcelable(UpiConstant.PAYMENT_RESPONSE);
            isUpiAppAlreadyOpen = savedInstanceState.getBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED);
        }
    }

    private PayUSocketEventListener getPayUSocketEventListener() {
        return new PayUSocketEventListener() {
            @Override
            public void getSocketResult(String merchantResponse, String payuResponse, String resultType, boolean isLongPooling) {
                PaymentResponseUpiSdkFragment.this.getSocketResult(merchantResponse, payuResponse, resultType, isLongPooling);
            }

            @Override
            public void errorReceived(int issueCode, String errorMessage) {
                PaymentResponseUpiSdkFragment.this.errorReceived(issueCode, errorMessage);
            }

            @Override
            public void transactionCancelled() {
                PaymentResponseUpiSdkFragment.this.transactionCancelled();
            }

            @Override
            public void onSocketCreated() {
                PaymentResponseUpiSdkFragment.this.onSocketCreated();
            }
        };
    }

    /**
     * Handling payment types. There will be one of these payment types.
     */
    private void handlePaymentFlow() {
        switch (mPaymentType.toLowerCase()) {
            case UpiConstant.UPI_COLLECT:
            case UpiConstant.UPI_COLLECT_TPV:
            case UpiConstant.TEZOMNI:
            case UpiConstant.TEZ_TPV:
                setCollectWebViewSettings();

                if (mPaymentType.equalsIgnoreCase(UpiConstant.UPI_COLLECT_TPV))
                    paymentOptionEnum = PaymentOption.UPI_COLLECT_TPV;
                else if (mPaymentType.equalsIgnoreCase(UpiConstant.TEZ_TPV))
                    paymentOptionEnum = PaymentOption.TEZ_TPV;
                else if (mPaymentType.equalsIgnoreCase(UpiConstant.TEZOMNI))
                    paymentOptionEnum = PaymentOption.TEZ_OMNI;
                else
                    paymentOptionEnum = PaymentOption.UPI_COLLECT;

                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for UpiCollect >>> " + paymentOptionEnum.getPackageName());
                L.v("Class Name: " + getClass().getCanonicalName() + "PostDataUpiSdk " + postData);
                showProgressDialog();
                String url = upiConfig.getPostUrl();
                if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
                    analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(), paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiAnalyticsConstant._LAUNCHED);
                    analyticsLogging(UpiAnalyticsConstant.TEZTPV_URL, url);
                    analyticsLogging(UpiAnalyticsConstant.TEZTPV_POST_DATA, upiConfig.getPayuPostData());
                }

                postUrlWebView(url, postData);
                break;

            case UpiConstant.UPI_COLLECT_GENERIC:
                Upi.isRecreating = true;
                setCollectWebViewSettings();
                showProgressDialog();
                paymentOptionEnum = PaymentOption.UPI_COLLECT_GENERIC;
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for UpiCollect >>> " + paymentOptionEnum.getPackageName());
                Bundle bundle = getArguments();
                if (null != bundle && null != bundle.getString(UpiConstant.POST_DATA_UPI_COLLECT_GENERIC) && null != bundle.getString(UPIPaymentConstants.RETURN_URL)) {
                    String postDataCollectGerenicIntent = bundle.getString(UpiConstant.POST_DATA_UPI_COLLECT_GENERIC);
                    mReturnUrl = bundle.getString(UPIPaymentConstants.RETURN_URL);
                    if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
                        analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(), paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiAnalyticsConstant._LAUNCHED);
                        analyticsLogging(UpiAnalyticsConstant.UPI_GENERIC_URL, mReturnUrl);
                        analyticsLogging(UpiAnalyticsConstant.UPI_GENERIC_POST_DATA, postDataCollectGerenicIntent);
                    }
                    postUrlWebView(mReturnUrl, postDataCollectGerenicIntent);
                } else {
                    if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
                        analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(),
                                paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiConstant.LAUNCH_ERROR);
                    }
                }
                break;
            case UpiConstant.UPI_INTENT_S:
            case UpiConstant.UPI_INTENT_TPV:
                if (mPaymentType.equalsIgnoreCase(UpiConstant.UPI_INTENT_TPV))
                    paymentOptionEnum = PaymentOption.UPI_INTENT_TPV;
                else
                    paymentOptionEnum = PaymentOption.UPI_INTENT;

                PayUUpiUtil.setUpiPackageName(upiConfig.getPackageNameForSpecificApp());
                if (null != paymentResponse && null != paymentResponse.getToken())
                    paymentHandler = new PaymentHandler(requireActivity(), postData, paymentResponse.getToken(), this, getFragmentListener());
                if (!isUpiAppAlreadyOpen) {
                    paymentHandler = new PaymentHandler(requireActivity(), postData, this, getFragmentListener());
                    getUPIPackagesList();
                    if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
                        analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(), paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiAnalyticsConstant._LAUNCHED);
                    }
                    paymentHandler.initiatePayment();
                } else {
                    if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
                        analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(),
                                paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiAnalyticsConstant.UPI_APP_ALREADY_OPEN);
                    }
                }
                break;

        }
    }

    private FragmentListener getFragmentListener() {
        return new FragmentListener() {
            @Override
            public void onPaymentFinished() {

            }
        };
    }

    /**
     * setting for webview collect. Javascript interface enabling.
     * {@link UpiWebInterface} to handle @javascriptinterface methods
     */
    private void setCollectWebViewSettings() {
        upiWebInterface = new UpiWebInterface(getActivity(), analytics, upiConfig, this);
        if (mCollectWebView != null) {
            mCollectWebView.getSettings().setJavaScriptEnabled(true);
            mCollectWebView.addJavascriptInterface(upiWebInterface, "PayU");
            mCollectWebView.setVisibility(View.GONE);
            mCollectWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_PAGE_STARTED, url);
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_PAGE_FINISHED, url);
                    hideProgressDialog();
                }

                @Override
                public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                    super.onReceivedHttpError(view, request, errorResponse);
                    if (request != null && request.getUrl() != null)
                        analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_HTTP_ERROR, request.getUrl().toString());
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    super.onReceivedError(view, request, error);
                    if (request != null && request.getUrl() != null)
                        analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_ERROR, request.getUrl().toString());
                }

                @Override
                public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                    super.onReceivedSslError(view, handler, error);
                    if (error != null && error.getUrl() != null)
                        analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_SSL_ERROR, error.getUrl());
                }

                @Override
              public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                view.setFocusableInTouchMode(true);
                view.requestFocus();
                view.setOnKeyListener(new View.OnKeyListener() {
                  @Override
                  public boolean onKey(View v, int keyCode, KeyEvent event) {
                    if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                      onBackButtonClicked();
                      return true;
                    }
                    return false;
                  }
                });
                super.doUpdateVisitedHistory(view, url, isReload);
              }
            });

        }

    }

    private com.payu.socketverification.widgets.PayUProgressDialog progressDialog;

    /**
     * Showing Dialog {@link com.payu.socketverification.widgets.PayUProgressDialog}
     */
    private void showProgressDialog() {
        if (null == progressDialog)
            progressDialog = new com.payu.socketverification.widgets.PayUProgressDialog(getContext(), UpiData.SINGLETON.getPayUCustomDialogView());
        progressDialog.setCancelable(false);
        if (null == UpiData.SINGLETON.getPayUCustomDialogView()) {
            progressDialog.setPayUDialogSettings(getContext());
            progressDialog.show();
        }

    }

    /**
     * Hiding the PayU progress dialog {@link com.payu.socketverification.widgets.PayUProgressDialog}
     */
    private void hideProgressDialog() {
        if (null != progressDialog && progressDialog.isShowing()) {
            progressDialog.dismiss();
            progressDialog = null;
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase() + " " , "ResultCode" + resultCode + "_|_" + "data" + "_" + data);

        if (requestCode == UPIPaymentConstants.PAYMENT_REQUEST_CODE) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Result code " + resultCode + " Data  " + data);
            statusCode = resultCode;
            String pspResponse = getPaymentResponse(data);
            if (resultCode == RESULT_OK && data != null) {//data is null in case of whatsapp payment
                String status = getPaymentStatus(data);
                if (null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey())
                    analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase() + " " + UpiAnalyticsConstant._PAYMENT_APP_RESPONSE, "Status_" + status + "_|_" + UpiAnalyticsConstant.PAYMENT_APP_RESPONSE + "_" + pspResponse);
                if (status != null && !status.equalsIgnoreCase(UpiConstant.SUCCESS) && !status.equalsIgnoreCase(UpiConstant.SUBMITTED)) {
                    L.v("Payment App response " + status);
                    //If status is not success and is not null call verify since we can't wait for long time for backend to response.
                    status = UpiConstant.FAILURE;
                    errorReason = UpiConstant.GET_RESPONSE_FROM_PSP;
                    if (paymentHandler != null) {
                        paymentHandler.verifyPayment(status, errorReason);
                    } else {
                        analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment on success path");
                    }
                } else {
                    status = UpiConstant.FAILURE;
                    L.v("Class Name: " + getClass().getCanonicalName() + "Return " + status);
                    makeDecisionForSocketAndHttp(status, errorReason);
                }

            } else {
                analyticsLogging(UPIPaymentConstants.CANCEL, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP.trim() +"_&_" + UpiAnalyticsConstant.REQUEST_CODE + "_" + resultCode);
                L.v("Class Name: " + getClass().getCanonicalName() + "Cancel return");
                if (paymentHandler != null) {
                    paymentHandler.handleCancelPath(upiIntentTime, () -> {
                        analyticsLogging(UPIPaymentConstants.PSP_AS_NEW_TASK, "PSP app launched as new task");
                        initPollingHelperIfNeeded();
                        if (pollingHelper != null) {
                            pollingHelper.startPollingWithDialog();
                        }
                    });
                } else {
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment on cancel path");
                }
            }
        }
    }

    private void initPollingHelperIfNeeded() {
        if (pollingHelper == null && paymentResponse != null && getActivity() != null) {
            pollingHelper = new PollingVerificationHelper(
                    getActivity(),
                    paymentResponse,
                    upiConfig,
                    analytics,
                    paymentHandler,
                    new PollingVerificationHelper.LifecycleCallback() {
                        @Override
                        public boolean isAlive() {
                            return getActivity() != null && isAdded();
                        }

                        @Override
                        public void onAnalyticsLog(String key, String value) {
                            analyticsLogging(key, value);
                        }
                    }
            );
        }
    }

    /**
     * Get Payment Status received from UPI App
     *
     * @param data Intent
     * @return Value of {@link com.payu.upisdk.upiintent.UPIPaymentConstants#STATUS}
     */
    private String getPaymentStatus(Intent data) {
        if (data.hasExtra(UPIPaymentConstants.STATUS)) {
            return data.getStringExtra(UPIPaymentConstants.STATUS);
        } else if (data.hasExtra(UPIPaymentConstants.RESPONSE)) {  //Some apps doesn't send status as key in intent but definitely send response key.
            String response = data.getStringExtra(UPIPaymentConstants.RESPONSE);
            HashMap<String, String> responseMap = UpiUtil.getDataFromPostData(response);
            return responseMap.get(UPIPaymentConstants.STATUS);
        }
        return null;
    }

    private String getPaymentResponse(Intent data) {
        if (data != null && data.hasExtra(UPIPaymentConstants.RESPONSE)) {
            String response = data.getStringExtra(UPIPaymentConstants.RESPONSE);
            return response;
        }
        return null;
    }

    /**
     * Making decision whether we need to verify using http or socket connection using upiPushDisabled value. It's "0" or "1"
     *
     * @param verifyHttpStatus
     */
    private void makeDecisionForSocketAndHttp(String verifyHttpStatus, String errorReason) {
        analyticsLogging(UpiAnalyticsConstant.UPI_SOCKET, UpiAnalyticsConstant.PUSH_ENABLED);
        if (null != paymentResponse && null != paymentResponse.getSocketParams() && paymentResponse.getSocketParams().getUpiPushDisabled() != null && paymentResponse.getSocketParams().getUpiPushDisabled().equals("0")) {
            //upiPushDisabled = 0 means, upi push is enabled so create socket connection.
            makeSocketConnection();
        } else {
            analyticsLogging(UpiAnalyticsConstant.CB_VERFIY_WAY, UpiAnalyticsConstant.VERIFY_USING_HTTP);
            if (paymentHandler != null) {
                paymentHandler.verifyPayment(verifyHttpStatus, errorReason);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment on makeDecisionForSocketAndHttp path");
            }
        }
    }

    private SocketPaymentResponse socketPaymentResponseVSocketVerification;

    /**
     * Making Socket connection..
     */
    private void makeSocketConnection() {
        analyticsLogging(UpiAnalyticsConstant.VERIFY_TYPE, UpiAnalyticsConstant.SOCKET);
        socketPaymentResponseVSocketVerification = new SocketPaymentResponse();
        createSocketVerificationInstances();
        if (null != socketPaymentResponseVSocketVerification && null != socketPaymentResponseVSocketVerification.getTxnId())
            SocketHandler.getInstance().createSocket(socketPaymentResponseVSocketVerification, requireActivity(), getPayUSocketEventListener());
    }

    /**
     * Creating instance for Socket.
     */
    private void createSocketVerificationInstances() {
        if (null != paymentResponse) {
            socketPaymentResponseVSocketVerification.setReferenceId(paymentResponse.getReferenceId());
            if (null != upiConfig && null != upiConfig.getTransactionID())
                socketPaymentResponseVSocketVerification.setTxnId(upiConfig.getTransactionID());
            socketPaymentResponseVSocketVerification.setUpiPushDisabled(paymentResponse.getSocketParams().getUpiPushDisabled());
            socketPaymentResponseVSocketVerification.setUpiServicePollInterval(paymentResponse.getSocketParams().getUpiServicePollInterval());
            socketPaymentResponseVSocketVerification.setSdkUpiPushExpiry(paymentResponse.getSocketParams().getSdkUpiPushExpiry());
            socketPaymentResponseVSocketVerification.setSdkUpiVerificationInterval(paymentResponse.getSocketParams().getSdkUpiVerificationInterval());
            socketPaymentResponseVSocketVerification.setPushServiceUrl(paymentResponse.getSocketParams().getPushServiceUrl());
        }
    }

    @Override
    public void onResponse(PaymentResponse paymentResponse) {
        this.paymentResponse = paymentResponse;
        if (null == paymentResponse) { //We don't get valid response from Backend might be Merchant Setting issue.
            sendingErrorListener(UpiAnalyticsConstant.PAYMENT_RESPONSE_NULL);
        } else if (!isMandatoryParamsAvailable()) { //Seems like backend is down.
            if (paymentResponse.getStatus() == 0 && TextUtils.isEmpty(paymentResponse.getResult())) {
                String base64Response = UpiUtil.getBase64DecodedString(paymentResponse.getResult()); //Seems like PG is down
                if (base64Response == null) {
                    sendingErrorListener(UpiAnalyticsConstant.BASE64_RESPONSE_NULL);
                } else {

                    if (UpiData.SINGLETON.getPayUPICallback() != null)
                        UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(base64Response, null);
                }
            } else {
                sendingErrorListener(UpiAnalyticsConstant.PAYMENT_STATUS_ZERO_AND_RESULT_BLANK);
            }

        } else if (paymentOptionEnum == PaymentOption.TEZ) {
            String TEZ_PACKAGE = "com.google.android.apps.nbu.paisa.user";
            if (paymentHandler != null) {
                paymentHandler.makePayment(TEZ_PACKAGE, this);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping makePayment for TEZ flow");
            }
        } else if (paymentOptionEnum == PaymentOption.UPI_INTENT || paymentOptionEnum == PaymentOption.UPI_INTENT_TPV) {
            if (!isUpiAppAlreadyOpen) {
                if (!requireActivity().isDestroyed() && !requireActivity().isFinishing() && upiConfig.isGenericIntent()) {
                    try {
                        paymentHandler.makePaymentViaGenericIntent(this);
                    } catch (Exception e) {
                        if (paymentHandler != null) {
                            analyticsLogging(UpiAnalyticsConstant.PAYU_GENERIC_INTENT, UpiAnalyticsConstant.NO_UPI_APPS_PRESENT);
                            paymentHandler.verifyPayment(UPIPaymentConstants.FAILURE, UPIPaymentConstants.NO_UPI_APPS_PRESENT);
                        } else {
                            analyticsLogging(UpiAnalyticsConstant.SOCKET_TRXN_STATUS, UpiAnalyticsConstant.NO_UPI_APPS_PRESENT);
                            L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentFailure");
                        }
                    }
                } else if (upiConfig.getPackageNameForSpecificApp() != null && upiConfig.getPackageNameForSpecificApp().length() > 0) {
                    onAppSelected(upiConfig.getPackageNameForSpecificApp(), UpiUtil.getVersionName(upiConfig.getPackageNameForSpecificApp(), getContext()));
                } else {
                    mReturnUrl = paymentResponse.getReturnUrl();
                    filteredList = new ArrayList<>();
                    if (paymentResponse.getApps() != null && paymentResponse.getApps().size() > 0) {
                        for (PackageBean bean : paymentResponse.getApps()) {
                            Iterator<PackageBean> iterator = packageBeanList.iterator();
                            while (iterator.hasNext()) {
                                PackageBean packageBean = iterator.next();
                                if (packageBean.equals(bean)) {
                                    packageBean.setPackageName(bean.getPackageName());
                                    filteredList.add(packageBean);
                                    iterator.remove();
                                }
                            }
                        }
                    }
                    if (filteredList != null && packageBeanList != null)
                        filteredList.addAll(packageBeanList);
                    PackageListDialogFragment packageListDialogFragment = PackageListDialogFragment.newInstance(filteredList, paymentResponse, upiConfig, this);
                    packageListDialogFragment.setStyle(STYLE_NORMAL, R.style.UpiSdkFullScreenDialogStyle);
                    packageListDialogFragment.setRetainInstance(true);
                    packageListDialogFragment.show(getActivity().getSupportFragmentManager(), "packageList");
                    isUpiAppAlreadyOpen = true;
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_APP, UPIPaymentConstants.PACKAGE_LIST);

                }
            } else {
                analyticsLogging(UPIPaymentConstants.ACTIVITY, UpiAnalyticsConstant.ACTIVITY_FINISHED);
            }
        } else {
            //We don't get valid response from Backend might be Merchant Setting issue.
            sendingErrorListener(UpiAnalyticsConstant.INVALID_RESPONSE);
        }

    }

    /**
     * Getting list of packages for UPI apps. Showing using fragment {@link PackageListDialogFragment}
     */
    private void getUPIPackagesList() {
        packageBeanList = new ArrayList<>();
        Intent intent = new Intent();
        intent.setData(Uri.parse(UPIPaymentConstants.UPI_INTENT_PREFIX));
        List<ResolveInfo> resolveInfos = getContext().getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo resolveInfo : resolveInfos) {
            PackageInfo packageInfo;
            try {
                L.v("UPI Installed App....... " + resolveInfo.activityInfo.packageName);
                packageInfo = getContext().getPackageManager().getPackageInfo(resolveInfo.activityInfo.packageName, 0);
                String name = (String) getContext().getPackageManager().getApplicationLabel(packageInfo.applicationInfo);
                packageBeanList.add(new PackageBean(name, packageInfo.packageName));
            } catch (PackageManager.NameNotFoundException e) {
                L.v("UPI Installed App....... PackageManager.NameNotFoundException");
            }
        }
    }

    @Override
    public void onAppSelected(String packageName, String versionName) {
        if (upiConfig != null && null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey()) {
            analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase() + UpiAnalyticsConstant.PAYMENT_APP, UpiAnalyticsConstant.PACKAGENAME_ + packageName + UpiAnalyticsConstant._VERSION_NAME_ + versionName);
        }
        if (paymentHandler != null) {
            paymentHandler.makePayment(packageName, this);
        } else {
            analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping makePayment in onAppSelected");
        }
    }

    @Override
    public void onDialogCancelled(boolean isValidPaymentMethodPresent, String cancelReason) {
        if (isValidPaymentMethodPresent) {
            if (statusCode != RESULT_OK) {
                if (paymentHandler != null) {
                    paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, cancelReason);
                } else {
                    analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment in onDialogCancelled cancel");
                }
            }
            if (upiConfig != null && null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey())
                analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(), UpiAnalyticsConstant.BACK_BUTTON_CANCEL_CLICK + "_statusCode: " + statusCode + " | cancelReason: " + cancelReason);

        } else {
            if (upiConfig != null && null != paymentOptionEnum && null != paymentOptionEnum.getAnalyticsKey())
                analyticsLogging(paymentOptionEnum.getAnalyticsKey().toLowerCase(), UpiAnalyticsConstant.NO_UPI_APPS_PRESENT);
            if (paymentHandler != null) {
                paymentHandler.verifyPayment(UPIPaymentConstants.FAILURE, UPIPaymentConstants.NO_UPI_APPS_PRESENT);
            } else {
                analyticsLogging(UpiAnalyticsConstant.PAYMENT_HANDLER_NULL, "skipping verifyPayment in onDialogCancelled no upi apps");
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        L.v("Class Name: " + getClass().getCanonicalName() + "OnDestroy ");
        SocketHandler.getInstance().onActivityDestroyed(getActivity());
        cleanUp();
        if (!Upi.isRecreating) {

            if (UpiData.SINGLETON.getPayUPICallback() != null)
                UpiData.SINGLETON.getPayUPICallback().onPaymentTerminate();
        } else {

            Upi.isRecreating = false;
        }

        PayUUpiUtil.updateLayoutSecurity(requireActivity(), false);
        rlWebView = null;
    }

    private void cleanUp() {
        if (null != paymentHandler)
            paymentHandler.cleanUp();
        if (null != alertDialog)
            alertDialog.dismiss();
        if (null != progressDialog) {
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            progressDialog = null;
        }
        L.v("Class Name: " + getClass().getCanonicalName() + "Is recreating " + Upi.isRecreating);
    }


    @Override
    public void onBackButtonClicked() {
        confirmationDialog();
    }




    /**
     * Creating confirmation dialog.
     */
    private void confirmationDialog() {
        DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (i == DialogInterface.BUTTON_POSITIVE) {

                    L.v("Class Name: " + getClass().getCanonicalName() + "getPayUUpiSdkCallback " + " used when doing through Upi Sdk  " + UpiData.SINGLETON.getPayUPICallback());
                    postToPaytxn();

                    if (UpiData.SINGLETON.getPayUPICallback() != null)
                        UpiData.SINGLETON.getPayUPICallback().onBackApprove();

                } else if (i == DialogInterface.BUTTON_NEGATIVE) {

                    dialogInterface.dismiss();
                    if (null != UpiData.SINGLETON.getPayUPICallback()) {
                        UpiData.SINGLETON.getPayUPICallback().onBackDismiss();
                    }
                }
            }
        };

        AlertDialog.Builder builder = UpiUtil.getAlertDialog(getActivity(), onClickListener, "Ok", "Cancel", null, getString(R.string.do_you_really_want_to_cancel_the_transaction));
        if (null != UpiData.SINGLETON.getPayUPICallback()) {
            UpiData.SINGLETON.getPayUPICallback().onBackButton(builder);
            alertDialog = builder.create();
            alertDialog.show();
        }

    }

    private AlertDialog alertDialog;

//    /**
//     * Load URL for VPA from dialog.
//     *
//     * @param postData
//     */
//    public void loadUrl(String postData) {
//        setCollectWebViewSettings();
//        isWebOpened = true;
//        showProgressDialog();
//        L.v("Class Name: " + getClass().getCanonicalName() + "loadURl to happen");
//        setTheme(R.style.upi_sdk_opaque_screen);
//        postUrlWebView(mReturnUrl, postData);
//    }

    private void postUrlWebView(String url, String postData) {
        L.v("Class Name: " + getClass().getCanonicalName() + "URL web " + url);
        L.v("Class Name: " + getClass().getCanonicalName() + "Postdata web " + postData);
        if (mCollectWebView != null) {
            getActivity().getWindow().setLayout(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
            mCollectWebView.setVisibility(View.VISIBLE);
            analyticsLogging(UpiAnalyticsConstant.UPI_COLLECT_POST_URL, url);
            mCollectWebView.postUrl(url, postData.getBytes());
//            DisplayMetrics displayMetrics = new DisplayMetrics();
//            requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//            int screenHeight = displayMetrics.heightPixels;
//            ViewGroup.LayoutParams layoutParams = rlWebView.getLayoutParams();
//            layoutParams.height =(screenHeight * 80)/100;
//            rlWebView.setLayoutParams(layoutParams);

        }
    }

  @Override
  public void onResume() {
    super.onResume();
    setShouldExecuteActionImmediately(true, true);
  }

    public void getSocketResult(String merchantResponse, String payuResponse, String resultType, boolean isLongPooling) {
        UpiWebInterface.PendingAction pendingAction = () -> {
        if (resultType.equals(UPIPaymentConstants.SUCCESS)) {
            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                analyticsLogging(UpiAnalyticsConstant.SOCKET_TRXN_STATUS, UpiAnalyticsConstant.SUCCESS_TRANSACTION);
                UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(payuResponse, null);
            } else {
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentSuccess");
            }
        } else {

            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                analyticsLogging(UpiAnalyticsConstant.SOCKET_TRXN_STATUS, UpiAnalyticsConstant.FAILURE_TRANSACTION);
                UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(payuResponse, null);
            } else {
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentFailure");
            }
        }
        if (UpiData.SINGLETON.getPayUPICallback() != null)
            UpiData.SINGLETON.getPayUPICallback().onBackApprove();
        };

        if(upiWebInterface != null) {
            upiWebInterface.setAction(pendingAction);
            upiWebInterface.executeAnyPendingAction();
        } else
            pendingAction.run();

    }


    public void errorReceived(int issueCode, String errorMessage) {
        L.v("Class Name: " + getClass().getCanonicalName() + "Error Received " + errorMessage);
        analyticsLogging(UpiAnalyticsConstant.SOCKET_CANCEL, UpiAnalyticsConstant.TECHNICAL_ERROR_AND_ERROR_MESSAGE + ": " + errorMessage);

        if (issueCode == UpiConstant.SOCKET_NOT_CREATED) {
            //TODO: Need to change transactionStatus dn errorStatus
            if (null != paymentHandler)
                paymentHandler.verifyPayment(UPIPaymentConstants.CANCEL, UpiAnalyticsConstant.TECHNICAL_ERROR);
        } else {
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(issueCode, errorMessage);
            else
                L.v("Class Name: " + getClass().getCanonicalName() + "Upi callback class should not be null onPaymentSuccess");

        }
    }


    public void transactionCancelled() {
        onDialogCancelled(true, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP);
    }


    public void onSocketCreated() {
        SocketHandler.getInstance().startSocketEvents(upiConfig.getMerchantKey(), upiConfig.getTransactionID(), getPayUSocketEventListener(), upiConfig.getProgressDialogCustomView());

    }

    private boolean isMandatoryParamsAvailable() {
        return !TextUtils.isEmpty(paymentResponse.getReturnUrl()) && !TextUtils.isEmpty(paymentResponse.getMerchantVpa()) && !TextUtils.isEmpty(paymentResponse.getReferenceId());
    }

    private void sendingErrorListener(String errorDetails) {
        L.v("Class Name: " + getClass().getCanonicalName() + " Err " + UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE);
        analyticsLogging(UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT, "ErrorDetails_" + errorDetails + "_|_ErrorCode: " + UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE);

        if (UpiData.SINGLETON.getPayUPICallback() != null)
            UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT_CODE, UPIPaymentConstants.MERCHANT_INFO_NOT_PRESENT);

    }

    @Override
    public void onSaveInstanceState(@NotNull Bundle outState) {
        super.onSaveInstanceState(outState);
        analyticsLogging(PAYU_UPI_LIFECYCLE_STATE, "Fragment : onSaveInstanceState outState storing values");
        outState.putParcelable(UpiConstant.UPI_CONFIG, upiConfig);
        outState.putParcelable(UpiConstant.PAYMENT_RESPONSE, paymentResponse);
        outState.putBoolean(UpiConstant.IS_UPI_APP_ALREADY_OPENED, isUpiAppAlreadyOpen);
    }

    private void setShouldExecuteActionImmediately(Boolean shouldExecuteActionImmediately, Boolean executeNow){
        if(upiWebInterface != null) {
            upiWebInterface.setShouldExecuteActionImmediately(shouldExecuteActionImmediately);
            if(executeNow)
                upiWebInterface.executeAnyPendingAction();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        setShouldExecuteActionImmediately(false, false);
        SocketHandler.getInstance().onActivityPaused(getActivity());
    }

  @Override
  public void onStop() {
    super.onStop();
    setShouldExecuteActionImmediately(false, false);
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    setShouldExecuteActionImmediately(false, false);
  }

    /**
     * Called when transaction is cancelled on backpress
     * update the status of transaction to 'user cancelled'
     */
    protected void postToPaytxn() {
        Thread updateTxn = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = new UpiUtil().getHttpsConn(UpiConstant.PAYMENT_URL + "/" + UpiConstant.PAYU_PAYTXN, null, -1, new UpiUtil().getCookieList(UpiConstant.PAYMENT_URL));
                    if (!(conn.getResponseCode() == 200)) {
                        L.v("BackButtonClick - UnSuccessful post to Paytxn");
                        analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN, UpiConstant.SUCCESS);
                    } else {
                        L.v("BackButtonClick - Successful post to Paytxn");
                        analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN, UpiConstant.FAILURE);
                    }
                } catch (Exception e) {
                    L.v("BackButtonClick Exception - " + e.getMessage());
                    analyticsLogging(UpiAnalyticsConstant.PAYU_POST_PAYTXN_WITH_EXCEPTION, UpiConstant.FAILURE);
                }
            }
        });
        updateTxn.setPriority(Thread.MAX_PRIORITY);
        updateTxn.start();
    }


    void analyticsLogging(String key, String value) {
        try {
            if (analytics == null) {
                this.analytics = AnalyticsUpiUnit.getInstance(requireContext());
            }
            if (upiConfig != null) {
                analytics.log(UpiUtil.getLogMessage(getContext(),
                        key,
                        value,
                        upiConfig.getMerchantKey(),
                        upiConfig.getTransactionID()));
            } else {
                Log.d("analyticsLogging", "analyticsLogging analytics" + (null != analytics) + " upiConfig " + (upiConfig != null));
            }
        } catch (Exception e) {
            Log.d("analyticsLogging","Class Name:getTransactionID " + key + " " + value + e.getMessage());
        }
    }

    @Override
    public void onPaymentFinished() {
//        onBackPressed();
    }


}
