package com.payu.upisdk.wrapper;

import android.app.Activity;
import android.content.Context;

import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallback;


public abstract class PaymentOptionWrapper {

    protected PayUUPICallback cbListener;

    public abstract void checkForPaymentOptionAvailability(Context context, String paymentOptionHash, String merchantKey, String user_credentials) throws Exception;

    public abstract void makePayment(Activity activity, UpiConfig upiConfig) throws Exception;

    public abstract void makePayment(Activity activity, String postData);

}
