package com.payu.upisdk.util;

import static com.payu.upisdk.util.UpiUtil.getAnalyticsConfig;

import android.content.Context;

import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;

public class AnalyticsUpiUnit {
    private static PayUAnalytics instancePayuAnalytics;

    public static PayUAnalytics getInstance(Context context) {
        if (instancePayuAnalytics == null) {
            instancePayuAnalytics = (PayUAnalytics) new AnalyticsFactory(context, getAnalyticsConfig(AnalyticsType.PAYU_ANALYTICS.name())).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);
        }
        return instancePayuAnalytics;
    }
}


