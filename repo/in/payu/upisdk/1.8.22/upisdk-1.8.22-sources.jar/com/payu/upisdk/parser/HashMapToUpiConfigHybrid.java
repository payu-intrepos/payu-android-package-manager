package com.payu.upisdk.parser;

import com.payu.paymentparamhelper.PayuConstants;
import com.payu.paymentparamhelper.PayuUtils;
import com.payu.paymentparamhelper.PostData;
import com.payu.paymentparamhelper.parser.HashMapToPostDataHybrid;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.util.PayUUpiUtil;
import com.payu.upisdk.util.UpiConstant;

import java.util.HashMap;

public class HashMapToUpiConfigHybrid {
    private final HashMap<String, Object> paymentParams;
    private boolean status = false;
    private String message = "";
    private UpiConfig upiConfig;

    public HashMapToUpiConfigHybrid(HashMap<String, Object> paymentParams) {
        this.paymentParams = paymentParams;
    }

    public boolean isStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public UpiConfig getUpiConfig() {
        return upiConfig;
    }

    public HashMapToUpiConfigHybrid parse() {
        ParserValidator validator = ParserValidator.paymentValidation(paymentParams);
        if (!validator.isValid()) {
            this.status = false;
            this.message = validator.getMessage();
            return this;
        }
        String packageName = PayuUtils.valueOf(paymentParams.get(ParserConstants.PACKAGE_NAME));
        String paymentMode = PayuUtils.valueOf(paymentParams.get(ParserConstants.PAYMENT_MODE));
        PostData postData = new HashMapToPostDataHybrid(paymentParams).parse(paymentMode);
        if (postData.getStatus().equals(PayuConstants.SUCCESS)) {
            String txnId = PayuUtils.valueOf(paymentParams.get(ParserConstants.TRANSACTION_ID));
            String key = PayuUtils.valueOf(paymentParams.get(ParserConstants.KEY));
            UpiConfig upiConfig = new UpiConfig();
            upiConfig.setPayuPostData(postData.getResult());
            upiConfig.setPaymentType(paymentMode);
            upiConfig.setTransactionID(txnId);
            upiConfig.setMerchantKey(key);
            upiConfig.setPackageNameForSpecificApp(packageName);
            upiConfig.setDisableIntentSeamlessFailure(PayuUtils.parseInt(PayuUtils.valueOf(paymentParams.get(ParserConstants.DISABLE_INTENT_SEAMLESS_FAILURE))));
            upiConfig.setMerchantResponseTimeout(PayuUtils.parseInt(PayuUtils.valueOf(paymentParams.get(ParserConstants.MERCHANT_RESPONSE_TIMEOUT))));
            upiConfig.setPhonePeUserCacheEnabled(Boolean.parseBoolean(String.valueOf(paymentParams.get(ParserConstants.PHONE_PE_USER_CACHE_ENABLED))));
            upiConfig.setPostUrl(PayuUtils.valueOf(paymentParams.get(ParserConstants.POST_URL)));
            upiConfig.setWebServiceUrl(PayuUtils.valueOf(paymentParams.get(ParserConstants.WEB_SERVICE_URL)));
            if (paymentParams.containsKey(UpiConstant.PAYU_IS_PROD))
                upiConfig.setProduction(Boolean.parseBoolean(PayuUtils.valueOf(paymentParams.get(UpiConstant.PAYU_IS_PROD))));
            else if (paymentParams.containsKey(UpiConstant.PAYU_ENVIRONMENT)) {
                upiConfig.setProduction(
                        "0".equals(PayuUtils.valueOf(paymentParams.get(UpiConstant.PAYU_ENVIRONMENT)))
                );
            }
            this.upiConfig = upiConfig;
            this.status = true;
            return this;
        }
        this.status = false;
        this.message = postData.getResult();
        return this;

    }

}
