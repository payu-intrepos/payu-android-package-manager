package com.payu.upisdk;

import android.annotation.SuppressLint;
import android.view.View;

import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallback;
import com.payu.upisdk.upi.IValidityCheck;
import com.payu.upisdk.wrapper.SamsungPayWrapper;

import java.util.HashSet;
import java.util.Set;

public enum UpiData {
    @SuppressLint("StaticFieldLeak") SINGLETON;

    private View payUCustomDialogView;
    private SamsungPayWrapper samsungPayWrapper;
    private UpiConfig upiConfig;
    private IValidityCheck iValidityCheck;
    private final Set<String> paymentOptionSet = new HashSet<>();
    private PayUUPICallback payUPICallback;
    private String verifyUrl;

    public String getVerifyUrl() {
        return verifyUrl;
    }

    public void setVerifyUrl(String verifyUrl) {
        this.verifyUrl = verifyUrl;
    }

    public View getPayUCustomDialogView() {
        return payUCustomDialogView;
    }

    public void setPayUCustomDialogView(View payUCustomDialogView) {
        this.payUCustomDialogView = payUCustomDialogView;
    }

    public UpiConfig getUpiConfig() {
        return upiConfig;
    }

    public void setUpiConfig(UpiConfig upiConfig) {
        this.upiConfig = upiConfig;
    }

    public SamsungPayWrapper getSamsungPayWrapper() {
        return samsungPayWrapper;
    }

    public void setSamsungPayWrapper(SamsungPayWrapper samsungPayWrapper) {
        this.samsungPayWrapper = samsungPayWrapper;
    }

    /**
     * Put PaymentOption payment name to the set.
     *
     * @param paymentOption, PaymentOption String
     */
    public void setPaymentOption(String paymentOption) {
        paymentOptionSet.add(paymentOption);
    }

    /**
     * Remove PaymentOption payment name from the set.
     *
     * @param paymentOption, Payment Option String
     * @return boolean removal
     */
    public void removePaymentOption(String paymentOption) {
        paymentOptionSet.remove(paymentOption);
    }


    /**
     * Getter of PayU  Callback
     *
     * @return {@link PayUUPICallback}
     */
    public PayUUPICallback getPayUPICallback() {
        return payUPICallback;
    }

    /**
     * Setter of PayU Upi Callback
     *
     * @param payUPICallback {@link PayUUPICallback}
     */
    public void setPayUPICallback(PayUUPICallback payUPICallback) {
        this.payUPICallback = payUPICallback;
    }

    public IValidityCheck getiValidityCheck() {
        return iValidityCheck;
    }

    public void setiValidityCheck(IValidityCheck iValidityCheck) {
        this.iValidityCheck = iValidityCheck;
    }

    /**
     * Check whether user checked this method for availability or not.
     *
     * @param paymentOptionName, PaymentOptionName String
     * @return
     */
    public boolean isPaymentOptionAvailabilityCalled(String paymentOptionName) {
        return paymentOptionSet.contains(paymentOptionName);
    }
}
