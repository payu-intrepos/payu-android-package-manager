package com.payu.upisdk.upiinterface;

import com.payu.upisdk.upiintent.PaymentResponse;

public interface GenericUPICallbacks {
    void onResponse(PaymentResponse paymentResponse);

    void onAppSelected(String packageName, String versionName);

    void onDialogCancelled(boolean isValidPaymentMethodPresent, String cancelReason);
}
