package com.payu.upisdk.callbacks;

public interface WebViewListener {
    void onPaymentFinished();
}
