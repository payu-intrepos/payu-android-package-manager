package com.payu.upisdk.generatepostdata;

import android.content.Context;

import com.payu.paymentparamhelper.PaymentParams;
import com.payu.paymentparamhelper.PaymentPostParams;
import com.payu.paymentparamhelper.PostData;

/**
 * Generating Payment postdata for get rid of pg SDK.
 */
public class PostDataGenerate extends PaymentPostParams {
//    private PaymentParamsUpiSdk mPaymentParams;
//    private String mPaymentMode;
//    private Context applicationContext;

    private PostDataGenerate(PostDataBuilder postDataBuilder) {
        super((PaymentParams) postDataBuilder.mPaymentParams, postDataBuilder.mPaymentMode);
//        this.mPaymentParams = postDataBuilder.mPaymentParams;
//        this.applicationContext = postDataBuilder.applicationContext;
//        this.mPaymentMode = postDataBuilder.mPaymentMode;
    }

    public static class PostDataBuilder {

        private PaymentParamsUpiSdk mPaymentParams;
        private String mPaymentMode;

        public PostDataBuilder(Context context) {
        }

        public PostDataBuilder setPaymentParamUpiSdk(PaymentParamsUpiSdk mPaymentParams) {
            this.mPaymentParams = mPaymentParams;
            return this;
        }

        public PostDataBuilder setPaymentMode(String mPaymentMode) {
            this.mPaymentMode = mPaymentMode;
            return this;
        }


      /*  public PostDataBuilder setContext(Context applicationContext) {
            this.applicationContext = applicationContext;
            return this;
        }*/

        public PostDataGenerate build() {
            return new PostDataGenerate(this);
        }
    }

    @Override
    public String toString() {
        return getPaymentPostParams().getResult();
    }

    public PostData getPaymentPostParams() {
        return super.getPaymentPostParams();
    }


}
