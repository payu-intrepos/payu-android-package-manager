package com.payu.upisdk.upiintent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.payu.upisdk.PackageListDialogFragment;
import com.payu.upisdk.R;
import com.payu.upisdk.upiinterface.GenericUPICallbacks;
import com.payu.upisdk.util.UpiUtil;

import java.util.List;

/**
 * Created by himanshu.gupta on 07/05/18.
 */

public class PackageListAdapter extends RecyclerView.Adapter<PackageListAdapter.PackageViewHolder> {

    private final List<PackageBean> packageBeanList;
    private final Context context;
    private final GenericUPICallbacks callbacks;
    private final PackageListDialogFragment fragment;

    public PackageListAdapter(List<PackageBean> packageBeanList, Context context, PackageListDialogFragment packageListDialogFragment, GenericUPICallbacks genericUPICallbacks) {
        this.packageBeanList = packageBeanList;
        this.context = context;
        this.callbacks =  genericUPICallbacks;
        this.fragment = packageListDialogFragment;
    }


    @NonNull
    @Override
    public PackageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cb_layout_package_list, parent, false);
        return new PackageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PackageViewHolder holder, int position) {
        final PackageBean packageBean = packageBeanList.get(holder.getAdapterPosition());
        holder.packageName.setText(packageBean.getPackageName());
        holder.packageDrawable.setImageDrawable(UpiUtil.getAppIcon(this.context, packageBean.getPackageId()));
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment.dismiss();
                callbacks.onAppSelected(packageBean.getPackageId(), packageBean.getVersionName());
            }
        });

    }


    @Override
    public int getItemCount() {
        return packageBeanList.size();
    }

    static class PackageViewHolder extends RecyclerView.ViewHolder {
        final ImageView packageDrawable;
        final TextView packageName;
        final LinearLayout relativeLayout;

        public PackageViewHolder(View itemView) {
            super(itemView);
            relativeLayout = (LinearLayout) itemView;
            packageDrawable = itemView.findViewById(R.id.image);
            packageName = itemView.findViewById(R.id.text);
        }
    }
}
