package com.payu.upisdk.upiintent;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.FragmentListener;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;
import com.payu.socketverification.socket.SocketPaymentResponse;
import com.payu.socketverification.util.PayUNetworkConstant;
import com.payu.socketverification.widgets.PayUProgressDialog;
import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.R;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallback;
import com.payu.upisdk.factory.PaymentOptionFactory;
import com.payu.upisdk.upiinterface.GenericUPICallbacks;
import com.payu.upisdk.util.AnalyticsUpiUnit;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.PayUUpiUtil;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;
import com.payu.upisdk.wrapper.GPayWrapper;
import com.payu.upisdk.wrapper.PaymentOptionWrapper;
import com.payu.upisdk.wrapper.PhonePeWrapper;
import com.payu.upisdk.wrapper.SamsungPayWrapper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


/**
 * Created by himanshu.gupta on 17/01/18.
 */
public class PaymentHandler implements PayuNetworkAsyncTaskInterface {
    private final String TAG = getClass().getSimpleName();
    private Activity mActivity;
    private String postData;
    private com.payu.socketverification.widgets.PayUProgressDialog progressDialog;
    private String verifyPaymentUrl;
    private String merchantVpa;
    private String merchantName;
    private String intentUri;
    private String referenceId;
    private UpiUtil upiUtil;
    private Timer transactionTimeout;
    private GenericUPICallbacks callbacks;
    private FragmentListener fragmentListener;
    private String amount;
    private boolean isGenericPayment;
    private String token;
    private final PayUAnalytics analytics;
    private String merchantKey;
    // private View progressDialogCustomView;

    PaymentHandler(Activity mActivity, String postData) {
        this.mActivity = mActivity;
        this.postData = postData;
        this.upiUtil = new UpiUtil();
        this.callbacks = (GenericUPICallbacks) mActivity;
        PaymentOption payment = upiUtil.getSupportedPayment(postData);
        this.isGenericPayment = payment == PaymentOption.UPI_INTENT || payment == PaymentOption.UPI_INTENT_TPV || payment == PaymentOption.TEZ_TPV;
        this.analytics = AnalyticsUpiUnit.getInstance(mActivity.getApplicationContext());
    }

    PaymentHandler(Activity mActivity, String postData, String token) {
        this.token = token;
        this.mActivity = mActivity;
        this.postData = postData;
        this.upiUtil = new UpiUtil();
        this.callbacks = (GenericUPICallbacks) mActivity;
        PaymentOption payment = upiUtil.getSupportedPayment(postData);
        this.isGenericPayment = payment == PaymentOption.UPI_INTENT;
        this.analytics = AnalyticsUpiUnit.getInstance(mActivity.getApplicationContext());
    }

    PaymentHandler(Activity mActivity, String postData, Fragment fragment, FragmentListener fragmentListener) {
        this.mActivity = mActivity;
        this.postData = postData;
        this.upiUtil = new UpiUtil();
        this.callbacks = (GenericUPICallbacks) fragment;
        this.fragmentListener = fragmentListener;
        PaymentOption payment = upiUtil.getSupportedPayment(postData);
        this.isGenericPayment = payment == PaymentOption.UPI_INTENT || payment == PaymentOption.UPI_INTENT_TPV || payment == PaymentOption.TEZ_TPV;
        this.analytics = AnalyticsUpiUnit.getInstance(mActivity.getApplicationContext());
    }

    PaymentHandler(Activity mActivity, String postData, String token, Fragment fragment, FragmentListener fragmentListener) {
        this.token = token;
        this.mActivity = mActivity;
        this.postData = postData;
        this.upiUtil = new UpiUtil();
        this.callbacks = (GenericUPICallbacks) fragment;
        this.fragmentListener = fragmentListener;
        PaymentOption payment = upiUtil.getSupportedPayment(postData);
        this.isGenericPayment = payment == PaymentOption.UPI_INTENT;
        this.analytics = AnalyticsUpiUnit.getInstance(mActivity.getApplicationContext());
    }

    public PaymentHandler(Context context) {
        this.mActivity = (Activity) context;
        this.analytics = AnalyticsUpiUnit.getInstance(mActivity.getApplicationContext());
    }

    void initiatePayment() {
        showProgressDialog();
        PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
        browserAsyncTaskData.setHttpMethod(PayUNetworkConstant.METHOD_TYPE_POST);
        String postDataInitiatePayment = postData.concat("&" + UPIPaymentConstants.TXN_S2S_FLOW + "=2");
        if (!postData.toUpperCase().contains(UPIPaymentConstants.UPI_APP_NAME.toUpperCase())) {
            postDataInitiatePayment = postDataInitiatePayment.concat("&" + UPIPaymentConstants.UPI_APP_NAME + "=" + PayUUpiUtil.getNameFromPackageName());
        }
        browserAsyncTaskData.setPostData(postDataInitiatePayment);
        if (null != UpiData.SINGLETON.getUpiConfig()) {
            String url = UpiData.SINGLETON.getUpiConfig().getPostUrl();
            browserAsyncTaskData.setUrl(url);
            analyticsLogging(UpiAnalyticsConstant.INITIATE_PAYMENT_URL, url, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            analyticsLogging(UpiAnalyticsConstant.INITIATE_PAYMENT_POST_DATA, browserAsyncTaskData.getPostData(), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));

            new PayUNetworkAsyncTask(this, UpiConstant.INITIATE).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);
        } else {
            if (null != UpiData.SINGLETON.getPayUPICallback()) {
                UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, UpiConstant.PROVIDED_UPI_CONFIG_NULL + TAG);
                analyticsLogging(UpiAnalyticsConstant.INITIATE_PAYMENT_FAILED, UpiAnalyticsConstant.NOT_INITIATE + "_&_" + UpiAnalyticsConstant.REQUEST_CODE + "_" + UPIPaymentConstants.PAYMENT_REQUEST_CODE, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            } else {
                analyticsLogging(UpiAnalyticsConstant.INITIATE_PAYMENT_FAILED, UpiAnalyticsConstant.ERROR_RESPONSE_FAILED + "_&_" + UpiAnalyticsConstant.REQUEST_CODE + "_" + UPIPaymentConstants.PAYMENT_REQUEST_CODE, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            }
        }
    }

    /**
     * Calling UPI app using Intent.
     *
     * @param packageName, string packagename
     */
    void makePayment(String packageName) {
        Intent intent = new Intent();
        intent.setPackage(packageName);
        L.v("Class Name: " + getClass().getCanonicalName() + "Package name Generic Intent " + packageName);
        intent.setAction(Intent.ACTION_VIEW);
        String txnAmount = TextUtils.isEmpty(amount) ? upiUtil.getDataFromPostData(postData, UPIPaymentConstants.AMOUNT) : amount;
        Uri uri;
        if (null != intentUri && intentUri.length() > 0) {

            if (intentUri.startsWith(UPIPaymentConstants.UPI_PREFIX)) {
                uri = Uri.parse(intentUri);
            } else {
                uri = Uri.parse(UPIPaymentConstants.UPI_INTENT_PREFIX + intentUri);
            }
            intent.setData(uri);
        } else {
            uri = Uri.parse(upiUtil.getUPIIntent(merchantVpa, merchantName, txnAmount,
                    upiUtil.getDataFromPostData(postData, UPIPaymentConstants.TXNID), referenceId, UPIPaymentConstants.CURRENCY_INR));
            intent.setData(uri);
        }
        if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
            analyticsLogging(UpiAnalyticsConstant.INTENT_URI, uri.toString(), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            if (intent.resolveActivity(mActivity.getPackageManager()) != null) {
                analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UPIPaymentConstants.ACTIVITY_STARTED + "_&_" + UpiAnalyticsConstant.REQUEST_CODE + "_" + UPIPaymentConstants.PAYMENT_REQUEST_CODE, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
                mActivity.startActivityForResult(intent, UPIPaymentConstants.PAYMENT_REQUEST_CODE);
                startTimer();
            } else {
                analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UpiAnalyticsConstant.ACTIVITY_RESOLVE_FAILED, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            }
        } else {
            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UpiAnalyticsConstant.ACTIVITY_FINISHED, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
        }
    }

    /**
     * Calling UPI app using Intent.
     *
     * @param packageName, string packagename
     */
    void makePayment(String packageName, Fragment fragment) {
        if (fragment == null || !fragment.isAdded() || fragment.isDetached() || fragment.getActivity() == null) {
            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UpiAnalyticsConstant.PAYU_UPI_FRAGMENT_INVALID_STATE, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            return;
        }
        Intent intent = new Intent();
        intent.setPackage(packageName);
        L.v("Class Name: " + getClass().getCanonicalName() + "Package name Generic Intent " + packageName);
        intent.setAction(Intent.ACTION_VIEW);
        String txnAmount = TextUtils.isEmpty(amount) ? upiUtil.getDataFromPostData(postData, UPIPaymentConstants.AMOUNT) : amount;
        Uri uri;
        if (null != intentUri && intentUri.length() > 0) {

            if (intentUri.startsWith(UPIPaymentConstants.UPI_PREFIX)) {
                uri = Uri.parse(intentUri);
            } else {
                uri = Uri.parse(UPIPaymentConstants.UPI_INTENT_PREFIX + intentUri);
            }
            intent.setData(uri);
        } else {
            uri = Uri.parse(upiUtil.getUPIIntent(merchantVpa, merchantName, txnAmount,
                    upiUtil.getDataFromPostData(postData, UPIPaymentConstants.TXNID), referenceId, UPIPaymentConstants.CURRENCY_INR));
            intent.setData(uri);
        }
        analyticsLogging(UpiAnalyticsConstant.INTENT_URI, uri.toString(), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));

        if (intent.resolveActivity(fragment.requireActivity().getPackageManager()) != null) {
            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT,   UPIPaymentConstants.ACTIVITY_STARTED + "_&_" + UpiAnalyticsConstant.REQUEST_CODE + "_" + UPIPaymentConstants.PAYMENT_REQUEST_CODE, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            PaymentResponseUpiSdkFragment.startUpiIntentTimer();
            fragment.startActivityForResult(intent, UPIPaymentConstants.PAYMENT_REQUEST_CODE);
            startTimer();
        } else {
            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UpiAnalyticsConstant.ACTIVITY_NOT_FOUND, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
        }

    }

    void makePaymentViaGenericIntent(Fragment fragment) {
        Uri uri;
        if (intentUri.startsWith(UPIPaymentConstants.UPI_PREFIX)) {
            uri = Uri.parse(intentUri);
        } else {
            uri = Uri.parse(UPIPaymentConstants.UPI_INTENT_PREFIX + intentUri);
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(uri);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);

        Intent chooserIntent = Intent.createChooser(intent, "Pay with");

        if (chooserIntent.resolveActivity(fragment.requireActivity().getPackageManager()) != null) {
            fragment.startActivityForResult(intent, UPIPaymentConstants.PAYMENT_REQUEST_CODE);
        }
    }

    /**
     * Method called when we try to make payment directly through Upi SDK.
     *
     * @param activity,           Activity instance
     * @param paymentOption,      PaymentOption enum
     * @param payUUpiSdkCallback, PayUUPICallback
     * @param paymentOptionHash,  paymentOptionHashpaymentOptionHash String hash
     * @param user_credentials,   user credentials
     */
    public void checkForPaymentAvailability(Activity activity, @NonNull PaymentOption paymentOption, @NonNull PayUUPICallback payUUpiSdkCallback,
                                            String paymentOptionHash, String merchantKey, String user_credentials) {
        mActivity = activity;
        this.merchantKey = merchantKey;
        UpiUtil.setUpiConfigData();
        if (merchantKey != null) {
            try {

                UpiData.SINGLETON.setPayUPICallback(payUUpiSdkCallback);
                analyticsLogging(UpiConstant.PAYMENT_OPTION, "checkForPaymentAvailability_"+paymentOption, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
                switch (paymentOption) {

                    case PHONEPE:
                        if (UpiUtil.isPaymentModuleAvailable(paymentOption)) {
                            PaymentOptionWrapper genericWrapper = new PaymentOptionFactory(paymentOption).getPaymentWrapper();
                            genericWrapper.checkForPaymentOptionAvailability(activity, paymentOptionHash, merchantKey, user_credentials);
                        } else {
                            upiModuleIsNotImported(paymentOption, payUUpiSdkCallback, R.string.payu_phonepe_module_is_not_imported);
                        }
                        break;

                    case TEZ:
                        if (UpiUtil.isPaymentModuleAvailable(paymentOption)) {
                            PaymentOptionWrapper genericWrapper = new PaymentOptionFactory(paymentOption).getPaymentWrapper();
                            genericWrapper.checkForPaymentOptionAvailability(activity, paymentOptionHash, merchantKey, user_credentials);
                        } else {
                            upiModuleIsNotImported(paymentOption, payUUpiSdkCallback, R.string.payu_gpay_module_is_not_imported);
                        }
                        break;

                    case SAMSUNGPAY:
                        if (UpiUtil.isPaymentModuleAvailable(paymentOption)) {

                            PaymentOptionWrapper samsungWrapper = new PaymentOptionFactory(paymentOption).getPaymentWrapper();
                            UpiData.SINGLETON.setSamsungPayWrapper((SamsungPayWrapper) samsungWrapper);
                            samsungWrapper.checkForPaymentOptionAvailability(activity, paymentOptionHash, merchantKey, user_credentials);
                        } else {
                            upiModuleIsNotImported(paymentOption, payUUpiSdkCallback, R.string.payu_samsung_module_is_not_imported);
                        }
                        break;


                    case UPI_INTENT:
                    case TEZ_OMNI:
                    case UPI_COLLECT_GENERIC:
                        payUUpiSdkCallback.isPaymentOptionAvailable(true, paymentOption);
                        break;
                    default: {
                        analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY_PAYMENT_OPTION, activity.getString(R.string.please_provide_payment_type_in_manifest), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
                        payUUpiSdkCallback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, activity.getString(R.string.please_provide_payment_type_in_manifest));
                    }
                }

            } catch (Exception e) {
                analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY_EXCPEPTION, activity.getString(R.string.please_provide_payment_type_in_manifest), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
                payUUpiSdkCallback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, activity.getString(R.string.please_provide_payment_type_in_manifest));
            }
        } else {
            analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY_MERCHANT_KEY, activity.getString(R.string.please_provide_merchant_key_in_manifest), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            payUUpiSdkCallback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, activity.getString(R.string.please_provide_merchant_key_in_manifest));

        }
    }

    private void upiModuleIsNotImported(@NonNull PaymentOption paymentOption, @NonNull PayUUPICallback payUUpiSdkCallback, int stringId) {
        if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed())
            payUUpiSdkCallback.onUpiErrorReceived(UpiConstant.DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED, mActivity.getString(stringId));
        analyticsLogging(UPIPaymentConstants.STATUS, UpiAnalyticsConstant.DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
        payUUpiSdkCallback.isPaymentOptionAvailable(false, paymentOption);
    }

    /**
     * @param callback,  PayUUPICallback instance
     * @param upiConfig, UpiConfig object
     */
    public Fragment makeSeamlessPayment(PayUUPICallback callback, UpiConfig upiConfig, Context context) {
        if (callback == null)
            throw new IllegalStateException("PayUUPICallback must not be null");
        if (upiConfig == null)
            throw new IllegalStateException("Merchant info is null");
        if (upiConfig.getMerchantKey() != null) {
            upiConfig.setPayuPostData(new UpiUtil().getAnalyticsAddedPostData(upiConfig.getPayuPostData()));
            UpiData.SINGLETON.setUpiConfig(upiConfig);
            UpiData.SINGLETON.setPayUPICallback(callback);
            upiConfig.setPaymentType(UpiUtil.getDataFromPostData(upiConfig.getPayuPostData()).get(UpiConstant.BANK_CODE));
            if (upiConfig.getPaymentType() != null && !upiConfig.getPaymentType().isEmpty()) {
                if (upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_INTENT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.INTTPV)
                        || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_COLLECT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPITPV)
                        || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZTPV) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZOMNI)) {
                    if ((upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_INTENT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.INTTPV))
                            && !TextUtils.isEmpty(upiConfig.getPackageNameForSpecificApp())
                            && (!UpiUtil.isAppInstalled(upiConfig.getPackageNameForSpecificApp(), context)
                            || !UpiUtil.isUserOnboardedOnUpi(upiConfig.getPackageNameForSpecificApp(), context))) {
                        if (!UpiUtil.isAppInstalled(upiConfig.getPackageNameForSpecificApp(), context)) {
                            analyticsLogging(UpiAnalyticsConstant.INVOKING_APP_NOT_INSTALLED, upiConfig.getPackageNameForSpecificApp(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                            callback.onUpiErrorReceived(UpiConstant.INVOKING_APP_NOT_INSTALLED_CODE, UpiConstant.INVOKING_APP_NOT_INSTALLED_MESSAGE + upiConfig.getPackageNameForSpecificApp());
                        } else if (!UpiUtil.isUserOnboardedOnUpi(upiConfig.getPackageNameForSpecificApp(), context)) {
                            analyticsLogging(UpiAnalyticsConstant.UPI_NOT_ENABLED_ON_APP, upiConfig.getPackageNameForSpecificApp(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                            callback.onUpiErrorReceived(UpiConstant.INVOKING_APP_NOT_ONBOARDED_CODE, UpiConstant.INVOKING_APP_NOT_ONBOARDED_MESSAGE + upiConfig.getPackageNameForSpecificApp());
                        }
                    } else {
                        analyticsLogging(UpiAnalyticsConstant.PAYU_UPI_SDK_PAYMENT_MODE, UpiAnalyticsConstant.MAKE_SEAMLESS_PAYMENT, upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        return start(callback, upiConfig);
                    }
                } else {
                    if (upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZ) || UpiData.SINGLETON.isPaymentOptionAvailabilityCalled(upiConfig.getPaymentType())) {
                        handleNonUPIFlows(upiConfig);
                    } else {
                        Toast.makeText(context, UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " for " + upiConfig.getPaymentType(), Toast.LENGTH_SHORT).show();
                        analyticsLogging(UpiAnalyticsConstant.CHECK_PAYMENT_NOT_CALLED, UpiAnalyticsConstant.PAYMENT_TYPE + "_" + upiConfig.getPaymentType(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        callback.onUpiErrorReceived(UpiConstant.CHECK_PAYMENT_NOT_CALLED, UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " for " + upiConfig.getPaymentType());
                    }
                }
            } else {
                analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY, context.getString(R.string.please_provide_merchant_key_in_manifest), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                callback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, context.getString(R.string.please_provide_payment_type_in_manifest));
            }

        } else {
            analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY, context.getString(R.string.please_provide_merchant_key_in_manifest), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
            callback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, context.getString(R.string.please_provide_merchant_key_in_manifest));
        }
        return null;
    }

    /**
     * @param callback,  PayUUPICallback instance
     * @param activity,  Activity instance
     * @param upiConfig, UpiConfig object
     */
    public void makePayment(PayUUPICallback callback, Activity activity, UpiConfig upiConfig) {
        if (callback == null)
            throw new IllegalStateException("PayUUPICallback must not be null");
        if (upiConfig == null)
            throw new IllegalStateException("Merchant info is null");
        if (upiConfig.getMerchantKey() != null) {
            upiConfig.setPayuPostData(new UpiUtil().getAnalyticsAddedPostData(upiConfig.getPayuPostData()));
            UpiData.SINGLETON.setUpiConfig(upiConfig);
            UpiData.SINGLETON.setPayUPICallback(callback);
            upiConfig.setPaymentType(UpiUtil.getDataFromPostData(upiConfig.getPayuPostData()).get(UpiConstant.BANK_CODE));
            if (upiConfig.getPaymentType() != null && !upiConfig.getPaymentType().isEmpty()) {
                if (upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_INTENT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.INTTPV)
                        || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_COLLECT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPITPV)
                        || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZTPV) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZOMNI)) {
                    if ((upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.UPI_INTENT) || upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.INTTPV))
                            && !TextUtils.isEmpty(upiConfig.getPackageNameForSpecificApp())
                            && (!UpiUtil.isAppInstalled(upiConfig.getPackageNameForSpecificApp(), activity)
                            || !UpiUtil.isUserOnboardedOnUpi(upiConfig.getPackageNameForSpecificApp(), activity))) {
                        if (!UpiUtil.isAppInstalled(upiConfig.getPackageNameForSpecificApp(), activity)) {
                            analyticsLogging(UpiAnalyticsConstant.INVOKING_APP_NOT_INSTALLED, upiConfig.getPackageNameForSpecificApp(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                            callback.onUpiErrorReceived(UpiConstant.INVOKING_APP_NOT_INSTALLED_CODE, UpiConstant.INVOKING_APP_NOT_INSTALLED_MESSAGE + upiConfig.getPackageNameForSpecificApp());
                        } else if (!UpiUtil.isUserOnboardedOnUpi(upiConfig.getPackageNameForSpecificApp(), activity)) {
                            analyticsLogging(UpiAnalyticsConstant.UPI_NOT_ENABLED_ON_APP, upiConfig.getPackageNameForSpecificApp(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                            callback.onUpiErrorReceived(UpiConstant.INVOKING_APP_NOT_ONBOARDED_CODE, UpiConstant.INVOKING_APP_NOT_ONBOARDED_MESSAGE + upiConfig.getPackageNameForSpecificApp());
                        }
                    } else {
                        analyticsLogging(UpiAnalyticsConstant.PAYU_UPI_SDK_PAYMENT_MODE, UpiAnalyticsConstant.MAKE_PAYMENT, upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        startActivity(callback, activity, upiConfig);
                    }
                } else {
                    if (upiConfig.getPaymentType().equalsIgnoreCase(UpiConstant.TEZ) || UpiData.SINGLETON.isPaymentOptionAvailabilityCalled(upiConfig.getPaymentType())) {
                        this.mActivity = activity;
                        handleNonUPIFlows(upiConfig);
                    } else {
                        Toast.makeText(activity.getApplicationContext(), UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " for " + upiConfig.getPaymentType(), Toast.LENGTH_SHORT).show();
                        analyticsLogging(UpiAnalyticsConstant.CHECK_PAYMENT_NOT_CALLED, UpiAnalyticsConstant.PAYMENT_TYPE + "_" + upiConfig.getPaymentType(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        callback.onUpiErrorReceived(UpiConstant.CHECK_PAYMENT_NOT_CALLED, UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " for " + upiConfig.getPaymentType());
                    }
                }
            } else {
                analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY, activity.getString(R.string.please_provide_merchant_key_in_manifest), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                callback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, activity.getString(R.string.please_provide_payment_type_in_manifest));
            }

        } else {
            analyticsLogging(UpiConstant.NOT_PROVIDED_COMPLETE_INFO_KEY, activity.getString(R.string.please_provide_merchant_key_in_manifest), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
            callback.onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, activity.getString(R.string.please_provide_merchant_key_in_manifest));
        }

    }

    /**
     * @param callback,  PayUUPICallback instance
     * @param upiConfig, Upiconfig object
     */
    private Fragment start(PayUUPICallback callback, UpiConfig upiConfig) {
        UpiData.SINGLETON.setPayUPICallback(callback);
        UpiData.SINGLETON.setPayUCustomDialogView(upiConfig.getProgressDialogCustomView());

        this.merchantKey = upiConfig.getMerchantKey();
        if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
            UpiUtil.setUpiConfigData();
            UpiUtil.deviceAnalytics(merchantKey, mActivity, upiConfig.getPayuPostData());
            try {
                analyticsLogging(UPIPaymentConstants.ACTIVITY, UPIPaymentConstants.ACTIVITY_STARTED,
                        upiConfig.getMerchantKey(),
                        upiConfig.getTransactionID());

                upiConfig.setTransactionID(UpiUtil.getDataFromPostData(upiConfig.getPayuPostData()).get("txnid"));
                Bundle bundle = new Bundle();
                bundle.putParcelable(UpiConstant.UPI_CONFIG, upiConfig);
                return PaymentResponseUpiSdkFragment.newInstance(bundle);
            } catch (Exception e) {
                L.v("Class Name: " + getClass().getCanonicalName() + "startActivity: " + e.getMessage());
                return null;
            }
        } else {
            analyticsLogging(UPIPaymentConstants.ACTIVITY, UpiAnalyticsConstant.ACTIVITY_FINISHED,
                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY),
                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            return null;
        }
    }


    /**
     * @param callback,  PayUUPICallback instance
     * @param activity,  Activity instance
     * @param upiConfig, Upiconfig object
     */
    private void startActivity(PayUUPICallback callback, Activity activity, UpiConfig upiConfig) {
        UpiData.SINGLETON.setPayUPICallback(callback);
        UpiData.SINGLETON.setPayUCustomDialogView(upiConfig.getProgressDialogCustomView());

        this.mActivity = activity;
        this.merchantKey = upiConfig.getMerchantKey();
        if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
            UpiUtil.setUpiConfigData();
            UpiUtil.deviceAnalytics(merchantKey, mActivity, upiConfig.getPayuPostData());
            try {
                analyticsLogging(UPIPaymentConstants.ACTIVITY, TAG + UPIPaymentConstants.ACTIVITY_STARTED,
                        upiConfig.getMerchantKey(),
                        upiConfig.getTransactionID());

                Intent intent = new Intent(activity, PaymentResponseUpiSdkActivity.class);
                upiConfig.setTransactionID(UpiUtil.getDataFromPostData(upiConfig.getPayuPostData()).get("txnid"));
                intent.putExtra(UpiConstant.UPI_CONFIG, upiConfig);
                mActivity.startActivity(intent);
            } catch (Exception e) {
                L.v("Class Name: " + getClass().getCanonicalName() + "startActivity: " + e.getMessage());
            }
        } else {
            analyticsLogging(UPIPaymentConstants.ACTIVITY_0, UpiAnalyticsConstant.ACTIVITY_FINISHED,
                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY),
                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
        }
    }

    /**
     * Utility function to start transaction timer
     */
    private void startTimer() {
        if (transactionTimeout != null)
            new UpiUtil().cancelTimer(transactionTimeout);
        transactionTimeout = new Timer();
        //20 Minutes
        long TRANSACTION_TIMEOUT = 20 * 60 * 1000;
        transactionTimeout.schedule(new TimerTask() {
            @Override
            public void run() {
                if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
                    mActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            verifyPayment(UPIPaymentConstants.FAILURE, "timeout");
                        }
                    });
                }
            }
        }, TRANSACTION_TIMEOUT);
    }

    void verifyPayment(final String transactionStatus, final String errorReason) {
        String url = null;
        if (null == verifyPaymentUrl) {
            if (null != UpiData.SINGLETON.getVerifyUrl())
                url = UpiData.SINGLETON.getVerifyUrl();
        } else
            url = verifyPaymentUrl;
        if (null != url) {
            showProgressDialog();
            String verifyPostData;
            if (!isGenericPayment) {
                verifyPostData = UPIPaymentConstants.TRANSACTION_STATUS + "=" + transactionStatus + "&" + UPIPaymentConstants.FAILURE_REASON + "=" + errorReason;
            } else {
                String action = transactionStatus.equalsIgnoreCase(UPIPaymentConstants.CANCEL) ? "cancelTxn" : (transactionStatus.equalsIgnoreCase(UPIPaymentConstants.FAILURE)) ? "failTxn" : "finish";
                verifyPostData = UPIPaymentConstants.TOKEN + "=" + token + "&" + UPIPaymentConstants.ACTION + "=" + action + "&" + UPIPaymentConstants.FAILURE_REASON + "=" + errorReason;
            }
            if (!transactionStatus.equalsIgnoreCase(UpiConstant.SUCCESS)) {
                if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                    analyticsLogging(UpiAnalyticsConstant.TXN_ERROR_REASON, errorReason.trim(), UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            }
            PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
            browserAsyncTaskData.setHttpMethod(com.payu.socketverification.util.PayUNetworkConstant.METHOD_TYPE_POST);
            browserAsyncTaskData.setPostData(verifyPostData);
            // browserAsyncTaskData.setContentType(com.payu.socketverification.util.PayUNetworkConstant.CONTENT_TYPE_APPLICATION_JSON);

            browserAsyncTaskData.setUrl(url);
            if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
                analyticsLogging(UPIPaymentConstants.TRANSACTION_STATUS, errorReason.trim(),
                        UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY),
                        UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
            }

            new PayUNetworkAsyncTask(this, PayUNetworkConstant.VERIFY).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);
        }
    }

    /**
     * Interface for handling immediate app return scenario (e.g., Kotak811)
     */
    public interface ImmediateReturnCallback {
        void onImmediateReturn();
    }

    /**
     * Handles the cancel path when UPI app returns.
     * If app returned immediately (< 500ms), calls the callback for polling.
     * Otherwise, calls verifyPayment directly.
     *
     * @param upiIntentStartTime The time when UPI intent was started
     * @param immediateReturnCallback Callback to handle immediate return case (start polling)
     */
    public void handleCancelPath(long upiIntentStartTime, ImmediateReturnCallback immediateReturnCallback) {
        if (System.currentTimeMillis() - upiIntentStartTime > 500) {
            // Normal cancel - verify payment
            verifyPayment(UPIPaymentConstants.CANCEL, UpiConstant.CUSTOMER_CANCELLED_ON_PSP_APP);
        } else {
            // App returned immediately (likely opened in new task like Kotak811)
            // Let caller handle polling
            if (immediateReturnCallback != null) {
                immediateReturnCallback.onImmediateReturn();
            }
        }
    }

    /**
     * Parses the api response to create list of Upi apps
     *
     * @param appArray JSONArray of backend prioritised apps
     * @return List of PackageBean having backend prioritised apps along with installed apps
     */
    private List<PackageBean> parseAppResponse(JSONArray appArray) {
        if (null != appArray && appArray.length() > 0) {
            List<PackageBean> result = new ArrayList<>();
            for (int i = 0; i < appArray.length(); i++) {
                try {
                    JSONObject jsonObject = appArray.getJSONObject(i);
                    PackageBean object = new PackageBean(jsonObject.optString(UPIPaymentConstants.NAME),
                            jsonObject.optString(UPIPaymentConstants.PACKAGE));
                    result.add(object);

                } catch (JSONException e) {
                    L.v("Class Name: " + getClass().getCanonicalName() + "parseAppResponse exception " + e.getMessage());
                }

            }
            return result;
        }
        return null;
    }

    /**
     * Function to parse backend Verify api response
     *
     * @param response Verify api response
     * @return {@link UPIPaymentConstants#FAILURE}or{@link UPIPaymentConstants#SUCCESS}
     */
    private String getTransactionStatus(String response) {
        return getPaymentStatus(response, UPIPaymentConstants.STATUS);
    }

    /**
     * Function to parse backend Verify Api response
     *
     * @param response Api response
     * @return UnMapped Status value
     */
    private String getTransactionUnmappedStatus(String response) {
        return getPaymentStatus(response, UPIPaymentConstants.UNMAPPEDSTATUS);
    }

    @NonNull
    private String getPaymentStatus(String response, String status) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.has(UPIPaymentConstants.RESULT)) {
                JSONObject resultObject = jsonObject.getJSONObject(UPIPaymentConstants.RESULT);
                if (resultObject.has(status.toLowerCase()))
                    return resultObject.getString(status.toLowerCase());
            }
        } catch (JSONException e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "getPaymentStatus: " + e.getMessage());
            return UPIPaymentConstants.FAILURE;
        }
        return UPIPaymentConstants.FAILURE;
    }

    @Override
    public void onPayuNetworkAsyncTaskResponse(String cbAsynTaskResponse, String webServiceType) {
        if (null != progressDialog && progressDialog.isShowing() && mActivity != null && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
            try {
                progressDialog.dismiss();
                progressDialog = null;
            } catch (IllegalArgumentException | WindowManager.BadTokenException bte) {
                if (null != bte.getMessage())
                    L.v("Caught Exception " + bte.getMessage());
            }

        }
        if (null != cbAsynTaskResponse && null != webServiceType) {
            switch (webServiceType) {
                case UpiConstant.INITIATE:
                    L.v("Class Name: " + getClass().getCanonicalName() + "cbAsynTaskResponse: " + cbAsynTaskResponse);

                    // callbacks.onResponse(paymentResponse);
                    JSONObject jsonObject;
                    try {
                        jsonObject = new JSONObject(cbAsynTaskResponse);
                        merchantName = jsonObject.optString(UPIPaymentConstants.MERCHANT_NAME);
                        intentUri = jsonObject.optString(UPIPaymentConstants.INTENT_URI_DATA);
                        verifyPaymentUrl = jsonObject.optString(UPIPaymentConstants.RETURN_URL);
                        UpiData.SINGLETON.setVerifyUrl(verifyPaymentUrl);
                        merchantVpa = jsonObject.optString(UPIPaymentConstants.MERCHANT_VPA);
                        referenceId = jsonObject.optString(UPIPaymentConstants.REFERENCE_ID);
                        amount = jsonObject.optString(UPIPaymentConstants.AMOUNT);
                        String txnId = jsonObject.optString(UPIPaymentConstants.TXNID);
                        token = jsonObject.optString(UPIPaymentConstants.TOKEN);
                        String upiPushDisabled = jsonObject.optString(UPIPaymentConstants.UPI_PUSH_DISABLED);
                        String pushServiceUrl = jsonObject.optString(UPIPaymentConstants.PUSH_SERVICE_URL);
                        String upiServicePollInterval = jsonObject.optString(UPIPaymentConstants.UPI_SERVICE_POLL_INTERVAL);
                        String sdkUpiPushExpiry = jsonObject.optString(UPIPaymentConstants.SDK_UPI_PUSH_EXPIRY);
                        String sdkUpiVerificationInterval = jsonObject.optString(UPIPaymentConstants.SDK_UPI_VERIFICATION_INTERVAL);

                        String disableIntentSeamlessFailure = jsonObject.optString(UPIPaymentConstants.DISABLE_INTENT_SEAMLESS_FAILURE);
                        String combineVerifyAndPayButton = jsonObject.optString(UPIPaymentConstants.COMBINE_VERIFY_AND_PAY_BUTTON);
                        List<PackageBean> apps = parseAppResponse(jsonObject.optJSONArray(UPIPaymentConstants.APPS));
                        String vpaRegex = jsonObject.optString(UPIPaymentConstants.VPA_REGEX);
                        String result = jsonObject.optString(UPIPaymentConstants.RESULT);
                        String message = jsonObject.optString(UPIPaymentConstants.MESSAGE);
                        int status = jsonObject.optInt(UPIPaymentConstants.STATUS.toLowerCase());

                        String paymentResponseStr = merchantName + "_|_" + intentUri + "_|_" + verifyPaymentUrl + "_|_" + merchantVpa + "_|_" + referenceId + "_|_"
                                + amount + "_|_" + token + "_|_" + txnId + "_|_" + upiPushDisabled + "_|_" + pushServiceUrl + "_|_" + upiServicePollInterval + "_|_"
                                + sdkUpiPushExpiry + "_|_" + sdkUpiVerificationInterval + "_|_" + disableIntentSeamlessFailure + "_|_" + combineVerifyAndPayButton + "_|_"
                                + result + "_|_" + result + "_|_" + message + "_|_" + status;

                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(
                                    UpiAnalyticsConstant.INITIATE_PAYMENT_RESPONSE, paymentResponseStr,
                                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), txnId);

//                        if (TextUtils.isEmpty(merchantName) || TextUtils.isEmpty(verifyPaymentUrl) || TextUtils.isEmpty(merchantVpa) || TextUtils.isEmpty(referenceId))
//                            callbacks.onResponse(null);
                        PaymentResponse paymentResponse = new PaymentResponse();
                        paymentResponse.setMerchantName(merchantName);
                        paymentResponse.setMerchantVpa(merchantVpa);
                        paymentResponse.setReferenceId(referenceId);
                        paymentResponse.setReturnUrl(verifyPaymentUrl);
                        paymentResponse.setAmount(amount);
                        paymentResponse.setToken(token);
                        paymentResponse.setReturnUrl(verifyPaymentUrl);
                        if (!(TextUtils.isEmpty(combineVerifyAndPayButton) || combineVerifyAndPayButton.equalsIgnoreCase("null")))
                            paymentResponse.setCombineVerifyAndPayButton(combineVerifyAndPayButton);
                        paymentResponse.setDisableIntentSeamlessFailure(disableIntentSeamlessFailure);
                        paymentResponse.setTxnId(txnId);
                        paymentResponse.setApps(apps);
                        paymentResponse.setVpaRegex(vpaRegex);
                        SocketPaymentResponse socketParams = new SocketPaymentResponse();
                        socketParams.setUpiPushDisabled(upiPushDisabled);
                        socketParams.setPushServiceUrl(pushServiceUrl);
                        socketParams.setUpiServicePollInterval(upiServicePollInterval);
                        socketParams.setSdkUpiPushExpiry(sdkUpiPushExpiry);
                        socketParams.setSdkUpiVerificationInterval(sdkUpiVerificationInterval);
                        paymentResponse.setSocketParams(socketParams);
                        paymentResponse.setResult(result);
                        paymentResponse.setMessage(message);
                        paymentResponse.setStatus(status);


                        callbacks.onResponse(paymentResponse);
                    } catch (JSONException e) {
                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(
                                    UpiAnalyticsConstant.PAYMENT_RESPONSE_FIELDS, UpiAnalyticsConstant.PAYMENT_RESPONSE_NULL,
                                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY),
                                    UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
                        callbacks.onResponse(null);
                        L.v("Class Name: " + getClass().getCanonicalName() + "onPayuNetworkAsyncTaskResponse: " + e.getMessage());
                    }

                    break;

                case UpiConstant.VERIFY:

                    String result = UpiUtil.getBase64DecodedString(cbAsynTaskResponse);
                    L.v("Class Name: " + getClass().getCanonicalName() + "Verify Result " + result);
                    L.v("Class Name: " + getClass().getCanonicalName() + "Verify Response " + cbAsynTaskResponse);
                    if (!TextUtils.isEmpty(result)) {
                        String status = getTransactionStatus(result);
                        String unmappedStatus = getTransactionUnmappedStatus(result);
                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(UpiAnalyticsConstant.TRNX_STATUS_VERIFY_PAYMENT_RESPONSE, result, upiUtil.getDataFromPostData(postData, UpiConstant.KEY), upiUtil.getDataFromPostData(postData, UPIPaymentConstants.TXNID));
                        if (status.equalsIgnoreCase(UPIPaymentConstants.SUCCESS)) {
                            if (UpiData.SINGLETON.getPayUPICallback() != null)
                                UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(result, null);
                        } else {
                            if (UpiData.SINGLETON.getPayUPICallback() != null)
                                UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(result, null);

                        }
                    } else {
                        L.v("Class Name: " + getClass().getCanonicalName() + "Status Failure PaymentHandler upisdk ");
                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(UpiAnalyticsConstant.TRNX_STATUS_FAILURE_TRANSACTION,  UpiAnalyticsConstant.RESULT_IS_EMPTY, upiUtil.getDataFromPostData(postData, UpiConstant.KEY), upiUtil.getDataFromPostData(postData, UPIPaymentConstants.TXNID));

                        if (UpiData.SINGLETON.getPayUPICallback() != null)
                            UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(null, null);

                    }
                    if (transactionTimeout != null)
                        new UpiUtil().cancelTimer(transactionTimeout);
                    if (fragmentListener != null) {
                        fragmentListener.onPaymentFinished();
                    } else if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                        mActivity.finish();

                    break;

                case UpiConstant.COMMAND_REQUEST:
                    if (null != UpiData.SINGLETON.getPayUPICallback())
                        UpiData.SINGLETON.getPayUPICallback().onCommandResponse(cbAsynTaskResponse, COMMAND_NAME);
//                Toast.makeText(mActivity, "Reponse: "+cbAsynTaskResponse, Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    /**
     * Function to show Progress Dialog
     */
    private void showProgressDialog() {
        try {
            if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
                if (null == progressDialog)
                    progressDialog = new PayUProgressDialog(mActivity, UpiData.SINGLETON.getPayUCustomDialogView());
                progressDialog.setCancelable(false);
                if (null == UpiData.SINGLETON.getPayUCustomDialogView())
                    progressDialog.setPayUDialogSettings(mActivity);
                if (null != progressDialog && !progressDialog.isShowing() && null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed())
                    progressDialog.show();
            }
        } catch (Exception exception) {
            L.v("Class Name: " + getClass().getCanonicalName() + "showProgressDialog exception: " + exception.getMessage());
        }
    }

    /**
     * Handling payment types. There will be one of these payment types.
     */
    private void handleNonUPIFlows(UpiConfig upiConfig) {
        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
            analyticsLogging(UpiAnalyticsConstant.NON_UPI_FLOWS, UpiAnalyticsConstant.LAUNCHED, upiConfig.getMerchantKey(), upiConfig.getTransactionID());
        UpiUtil.setUpiConfigData();
        PaymentOption paymentOptionEnum = null;
        switch (upiConfig.getPaymentType().toLowerCase()) {
            case UpiConstant.PHONEPE_S:
                paymentOptionEnum = PaymentOption.PHONEPE;
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for PhonePe >>> " + paymentOptionEnum.getPackageName());
                PhonePeWrapper phonePeWrapper = new PhonePeWrapper();
                try {
                    if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                        analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT, UpiAnalyticsConstant.HANDLE_NON_UPI_PHONE_PE, upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                    phonePeWrapper.makePayment(mActivity, upiConfig);
                } catch (Exception e) {
                    if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                        analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT_EXCEPTION,  UpiAnalyticsConstant.CHECK_PAYMENT_NOT_CALLED_PAYMENT_NAME + "-" + paymentOptionEnum.getPaymentName(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                    UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UpiConstant.CHECK_PAYMENT_NOT_CALLED, UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " " + paymentOptionEnum.getPaymentName());
                }
                break;
            case UpiConstant.TEZ_S:
                paymentOptionEnum = PaymentOption.TEZ;
                L.v("Class Name: " + getClass().getCanonicalName() + "Payment Started for TEZ >>> " + paymentOptionEnum.getPackageName());
                if (UpiUtil.isPaymentModuleAvailable(paymentOptionEnum)) {
                    GPayWrapper gPayWrapper = new GPayWrapper();
                    try {
                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT_0,  UpiAnalyticsConstant.HANDLE_NON_UPI_TEZ, upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        gPayWrapper.makePayment(mActivity, upiConfig);
                    } catch (Exception e) {
                        if (null != mActivity && !mActivity.isDestroyed() && !mActivity.isFinishing())
                            analyticsLogging(UpiAnalyticsConstant.MAKEPAYMENT_EXCEPTION_0,  UpiAnalyticsConstant.CHECK_PAYMENT_NOT_CALLED_PAYMENT_NAME + "-" + paymentOptionEnum.getPaymentName(), upiConfig.getMerchantKey(), upiConfig.getTransactionID());
                        UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UpiConstant.CHECK_PAYMENT_NOT_CALLED, UpiConstant.CHECK_PAYMENT_NOT_CALLED_MSG + " " + paymentOptionEnum.getPaymentName());
                    }
                } else {
                    if (null != UpiData.SINGLETON.getPayUPICallback())
                        UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UpiConstant.DEVICE_NOT_SUPPORTED_OR_MODULE_NOT_IMPORTED, mActivity.getString(R.string.payu_gpay_module_is_not_imported));
                }
                break;
            case UpiConstant.SAMPAY_S:
                paymentOptionEnum = PaymentOption.SAMSUNGPAY;
                L.v("Class Name: " + getClass().getCanonicalName() + " | Payment Started for SamPay >>> " + paymentOptionEnum.getPackageName());
                if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed())
                    new PaymentOptionFactory(PaymentOption.SAMSUNGPAY).getPaymentWrapper().makePayment(mActivity, postData);
                break;
        }
    }

    public void cleanUp() {
        if (null != progressDialog && !progressDialog.isShowing()) {
            progressDialog.dismiss();
            progressDialog = null;
        }
        mActivity = null;
    }

    private String COMMAND_NAME = "payu_command";

    public void getCommandResponse(String postData, @NonNull PayUUPICallback payUUpiSdkCallback) {
        if (postData == null)
            throw new IllegalStateException("Postdata must not be null");

        if (null != mActivity && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
            UpiData.SINGLETON.setPayUPICallback(payUUpiSdkCallback);
            UpiUtil.setUpiConfigData();
            PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
            browserAsyncTaskData.setHttpMethod(com.payu.socketverification.util.PayUNetworkConstant.METHOD_TYPE_POST);
            browserAsyncTaskData.setPostData(postData);
            if (!TextUtils.isEmpty(UpiUtil.getDataFromPostData(postData).get(UpiConstant.COMMAND)))
                COMMAND_NAME = UpiUtil.getDataFromPostData(postData).get(UpiConstant.COMMAND);

            L.v("Class Name: " + getClass().getCanonicalName() + "Command Url " + UpiData.SINGLETON.getUpiConfig().getWebServiceUrl());
            L.v("Class Name: " + getClass().getCanonicalName() + "Command Postdata " + postData);
            browserAsyncTaskData.setUrl(UpiData.SINGLETON.getUpiConfig().getWebServiceUrl());
            if (null != UpiData.SINGLETON.getUpiConfig() && null != UpiData.SINGLETON.getUpiConfig().getWebServiceUrl())
                new PayUNetworkAsyncTask(this, UpiConstant.COMMAND_REQUEST).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);
        } else {
            analyticsLogging(UPIPaymentConstants.ACTIVITY_1, UpiAnalyticsConstant.ACTIVITY_FINISHED, UpiUtil.getDataFromPostData(postData).get(UpiConstant.KEY), UpiUtil.getDataFromPostData(postData).get(UpiConstant.TXNID));
        }
    }

    /**
     *
     * @param key Key must be static and unique
     * @param value key and value must be unique identifiers
     * @param merchantKey
     * @param transactionId
     */
    void analyticsLogging(String key, String value, String merchantKey, String transactionId) {
        try {
            if (null != analytics) {
                analytics.log(UpiUtil.getLogMessage(
                        mActivity.getApplicationContext(),
                        key,
                        value,
                        merchantKey,
                        transactionId));
            }
        } catch (Exception e) {
            L.v("Class analyticsLogging: " + key + " " + value + " " + e.getMessage());
        }
    }
}
