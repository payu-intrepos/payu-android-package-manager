package com.payu.upisdk.util;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.core.graphics.ColorUtils;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public final class StatusBarUtils {

    private static final String SCRIM_TAG = "statusBarScrimView";

    private StatusBarUtils() {}


    /** @return true if background color is LIGHT (so you should use DARK icons) */
    public static boolean isColorLight(@ColorInt int color) {
        // If translucent, approximate by compositing over black
        if (Color.alpha(color) < 255) {
            color = ColorUtils.compositeColors(color, Color.BLACK);
        }
        // 0..1, higher = lighter
        double l = ColorUtils.calculateLuminance(color);
        return l >= 0.5; // tweak to 0.45–0.55 if you prefer
    }

    public static void setStatusBarColor(@NonNull Activity activity,
                                         @ColorInt int color) {
        Window window = activity.getWindow();
        boolean lightStatusBar = isColorLight(color);
        if (Build.VERSION.SDK_INT >= 35) {
            // Edge-to-edge is the default look; status bar is transparent → draw our own scrim.
            WindowCompat.setDecorFitsSystemWindows(window, false);
            applyStatusBarScrim(activity, color);
            setLightIcons(window, lightStatusBar);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30–34: standard path
            window.setStatusBarColor(color);
            setLightIcons(window, lightStatusBar);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // API 29
            window.setStatusBarColor(color);
            window.setStatusBarContrastEnforced(false);
            setLightIconsPreR(window, lightStatusBar);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // API 23–28
            window.setStatusBarColor(color);
            setLightIconsPreR(window, lightStatusBar);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // API 21–22
            window.setStatusBarColor(color);
        }
    }

    private static void applyStatusBarScrim(@NonNull Activity activity, @ColorInt int color) {
        final ViewGroup content = activity.findViewById(android.R.id.content);

        // Reuse if already added
        View scrim = content.findViewWithTag(SCRIM_TAG);
        if (scrim == null) {
            scrim = new View(activity);
            scrim.setTag(SCRIM_TAG);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0, // height set via insets
                    Gravity.TOP
            );
            content.addView(scrim, lp);
        }

        scrim.setBackgroundColor(color);
        scrim.bringToFront();

        // Size the scrim to the status bar height
        final View scrimRef = scrim; // effectively final for lambda
        ViewCompat.setOnApplyWindowInsetsListener(scrimRef, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            ViewGroup.LayoutParams p = v.getLayoutParams();
            if (p.height != top) {
                p.height = top;
                v.setLayoutParams(p);
            }
            return insets;
        });
        ViewCompat.requestApplyInsets(content);
    }

    private static void setLightIcons(@NonNull Window window, boolean light) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            setLightIconsPreR(window, light);
        }
    }

    private static void setLightIconsPreR(@NonNull Window window, boolean light) {
        View decor = window.getDecorView();
        int flags = decor.getSystemUiVisibility();
        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        decor.setSystemUiVisibility(flags);
    }
}
