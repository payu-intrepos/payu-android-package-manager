package com.payu.upisdk.wrapper;

import android.app.Activity;
import android.content.Context;

import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Created by Shahbaz Ahmed
 */

public class SamsungPayWrapper extends com.payu.upisdk.wrapper.PaymentOptionWrapper {
    private Object samsungWrapperObject;
    private UpiUtil upiUtil;
    private UpiConfig upiConfig;

    /**
     * Function to check for SamsungPay availability
     *
     * @param context           Context
     * @param paymentOptionHash Payment Related Details Hash
     * @param merchantKey       Merchant Key
     * @param user_credentials  User Credentials
     */
    @Override
    public void checkForPaymentOptionAvailability(Context context, String paymentOptionHash, String merchantKey, String user_credentials) {
        if (UpiData.SINGLETON.getPayUPICallback() != null)
            this.cbListener = UpiData.SINGLETON.getPayUPICallback();
        try {
            ClassLoader samsungWrapperClassLoader = SamsungPayWrapper.class.getClassLoader();
            Class samsungWrapperClass = samsungWrapperClassLoader.loadClass("com.payu.samsungpay.SamsungWrapper");
            Constructor samsungWrapperConstructor = samsungWrapperClass.getDeclaredConstructor(java.lang.reflect.InvocationHandler.class);
            samsungWrapperConstructor.setAccessible(true);
            samsungWrapperObject = samsungWrapperConstructor.newInstance(cbCallback);
            Method method = samsungWrapperObject.getClass().getMethod("checkSamsungPayAvailability", String.class, String.class, String.class, Context.class);
            method.invoke(samsungWrapperObject, paymentOptionHash, merchantKey, user_credentials, context);
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "Sampay ca exception " + e.getMessage());
        }
    }

    @Override
    public void makePayment(Activity activity, UpiConfig upiConfig) {
        try {
            this.upiUtil = new UpiUtil();
            this.upiConfig = upiConfig;
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                this.cbListener = UpiData.SINGLETON.getPayUPICallback();
            upiUtil.setUPICBSdkVersion(UpiConstant.SAMSANGPAY_PACKAGE);
            Method method = samsungWrapperObject.getClass().getMethod("makePayment", Activity.class, String.class);
            method.invoke(samsungWrapperObject, activity, upiConfig.getPayuPostData());
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "makePayment exception " + e.getMessage());
        }
    }

    @Override
    public void makePayment(Activity activity, String postData) {
        try {
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                this.cbListener = UpiData.SINGLETON.getPayUPICallback();
            this.upiUtil = new UpiUtil();
            this.upiConfig = new UpiConfig();
            upiConfig.setPayuPostData(postData);
            Method method = samsungWrapperObject.getClass().getMethod("makePayment", Activity.class, String.class);
            L.v("Class Name: " + getClass().getCanonicalName() + "Sampay Methods" + Arrays.toString(samsungWrapperObject.getClass().getMethods()));
            L.v("Class Name: " + getClass().getCanonicalName() + "Sampay Methods Length" + samsungWrapperObject.getClass().getMethods().length);
            method.invoke(samsungWrapperObject, activity, postData);

        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "makePayment exception " + e.getMessage());
        }
    }

    private final java.lang.reflect.InvocationHandler cbCallback = new java.lang.reflect.InvocationHandler() {
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) {

            if (method.getName().equalsIgnoreCase(UpiConstant.SAMSUNGPAY_SUCCESS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Sampay PAYMENT_OPTION_SUCCESS");
                if (cbListener != null)
                    cbListener.onPaymentSuccess(args[0] + "", null);
//                if (UpiData.SINGLETON.getPayUPICallback() != null)
//                    UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(args[0] + "", null);

//                if (activity!=null && !activity.isFinishing()&& !activity.isDestroyed())
//                    activity.finish();
            } else if (method.getName().equalsIgnoreCase(UpiConstant.SAMSUNGPAY_FAILURE)) {
                if (cbListener != null)
                    cbListener.onPaymentFailure(args[0] + "", null);

//                if (activity!=null && !activity.isFinishing()&& !activity.isDestroyed())
//                    activity.finish();
            } else if (method.getName().equalsIgnoreCase(UpiConstant.SAMSUNGPAY_INIT_SUCCESS)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Sampay ispaymentoption available init sucess upidk samsung");
                if (cbListener != null)
                    UpiData.SINGLETON.setPaymentOption(PaymentOption.SAMSUNGPAY.getPaymentName());
                UpiData.SINGLETON.setSamsungPayWrapper(SamsungPayWrapper.this);
                cbListener.isPaymentOptionAvailable(true, PaymentOption.SAMSUNGPAY);
            } else if (method.getName().equalsIgnoreCase(UpiConstant.SAMSUNGPAY_INIT_FAILURE)) {
                L.v("Class Name: " + getClass().getCanonicalName() + "Sampay ispaymentoption available init failure upidk sam wrapper 0: " + args[0] + "  1:" + args[1]);
                if (cbListener != null)
                    cbListener.isPaymentOptionAvailable(false, PaymentOption.SAMSUNGPAY);
                UpiData.SINGLETON.removePaymentOption(PaymentOption.SAMSUNGPAY.getPaymentName());
            }
            return null;
        }
    };
}
