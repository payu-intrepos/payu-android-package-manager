package com.payu.upisdk;

import static com.payu.upisdk.util.UpiConstant.PHONEPE;
import static com.payu.upisdk.util.UpiConstant.SAMPAY;
import static com.payu.upisdk.util.UpiConstant.TEZ;
import static com.payu.upisdk.util.UpiConstant.TEZOMNI;
import static com.payu.upisdk.util.UpiConstant.UPI_COLLECT;
import static com.payu.upisdk.util.UpiConstant.UPI_INTENT;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.payu.paymentparamhelper.PayuErrors;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallback;
import com.payu.upisdk.parser.HashMapToUpiConfigHybrid;
import com.payu.upisdk.parser.ParserValidator;
import com.payu.upisdk.upiintent.PaymentHandler;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import org.json.JSONObject;

import java.util.HashMap;

public class Upi {

    private static volatile Upi instance;
    public static String cbVersion; //To be set by reflection
    public static boolean isRecreating;

    /**
     * This method called when we try to make payment through CustomBrowser
     *
     * @param callback, instance of listener to send back the response.
     * @param activity, Activity object
     */
    public void makePayment(PayUUPICallback callback, Activity activity, UpiConfig upiConfig) {
        PaymentHandler paymentHandler = new PaymentHandler(activity);
        paymentHandler.makePayment(callback, activity, upiConfig);
    }

    /**
     * This method called when we try to make payment through CustomBrowser
     *
     * @param callback, instance of listener to send back the response.
     */
    public Fragment makeSeamlessPayment(PayUUPICallback callback, UpiConfig upiConfig, Context context) {
        PaymentHandler paymentHandler = new PaymentHandler(context);
        return paymentHandler.makeSeamlessPayment(callback, upiConfig, context);
    }

    /**
     * This method called when we try to make payment through CustomBrowser
     *
     * @param callback,  instance of listener to send back the response.
     * @param activity,  Activity object
     * @param upiParams, hashMap upiconfigs object
     */
    public void makePayment(PayUUPICallback callback, Activity activity, HashMap<String, Object> upiParams) {
        HashMapToUpiConfigHybrid parser = new HashMapToUpiConfigHybrid(upiParams).parse();
        if (!parser.isStatus()) {
            callback.onUpiErrorReceived(PayuErrors.MISSING_PARAMETER_EXCEPTION, parser.getMessage());
            return;
        }
        makePayment(callback, activity, parser.getUpiConfig());
    }

  public Fragment makeSeamlessPayment(PayUUPICallback callback, Activity activity, HashMap<String, Object> upiParams) {
    HashMapToUpiConfigHybrid parser = new HashMapToUpiConfigHybrid(upiParams).parse();
    if (!parser.isStatus()) {
      callback.onUpiErrorReceived(PayuErrors.MISSING_PARAMETER_EXCEPTION, parser.getMessage());
      return null;
    }
    return makeSeamlessPayment(callback, parser.getUpiConfig(),activity);
  }


    private Upi() {
    }


    /**
     * SINGLETON
     *
     * @return, Upi Instance
     */

    public static Upi getInstance() {
        if (instance == null) {
            synchronized (Upi.class) {
                if (instance == null)
                    instance = new Upi();
                return instance;
            }
        }
        return instance;
    }

    /**
     * Called when try to make payment through CustomBrowser.
     *
     * @param activity,          Activity object
     * @param paymentType,       Payment Type
     * @param payUUPICallback,   PayUUPICallback object
     * @param paymentOptionHash, paymentOptionHash
     * @param user_credentials,  user_credentials
     * @param merchantKey        Merchant Key
     */
    void checkForPaymentAvailability(Activity activity, @NonNull String paymentType, @NonNull PayUUPICallback payUUPICallback,
                                     String paymentOptionHash, String user_credentials, String merchantKey) {
        L.v("Class Name: " + getClass().getCanonicalName() + "CheckPayment payment Type " + paymentType);
        UpiUtil.setUpiConfigData();
        PaymentOption paymentOptionEnum = null;
        UpiData.SINGLETON.setPayUPICallback(payUUPICallback);
        switch (paymentType) {
            case PHONEPE:
                paymentOptionEnum = PaymentOption.PHONEPE;
                break;
            case TEZ:
                paymentOptionEnum = PaymentOption.TEZ;
                break;
            case SAMPAY:
                paymentOptionEnum = PaymentOption.SAMSUNGPAY;
                break;
            case UPI_COLLECT:
                paymentOptionEnum = PaymentOption.UPI_COLLECT;
                break;
            case UPI_INTENT:
                paymentOptionEnum = PaymentOption.UPI_INTENT;
                break;
            case TEZOMNI:
                paymentOptionEnum = PaymentOption.TEZ_OMNI;
                break;
        }
        if (null != paymentOptionEnum)
            checkForPaymentAvailability(activity, paymentOptionEnum, payUUPICallback, paymentOptionHash, merchantKey, user_credentials);
    }

    /**
     * Method called when we try to make payment directly through Upi SDK.
     *
     * @param activity,          Activity instance
     * @param paymentOption
     * @param payUUpiSdkCallback
     * @param paymentOptionHash
     * @param user_credentials
     */
    public void checkForPaymentAvailability(Activity activity, @NonNull PaymentOption paymentOption, @NonNull PayUUPICallback payUUpiSdkCallback, String paymentOptionHash, String merchantKey, String user_credentials) {

        PaymentHandler paymentHandler = new PaymentHandler(activity);
        paymentHandler.checkForPaymentAvailability(activity, paymentOption, payUUpiSdkCallback, paymentOptionHash, merchantKey, user_credentials);

    }

    /**
     * Method called when we try to make payment directly through Upi SDK.
     *
     * @param activity,          Activity instance
     * @param paymentOption
     * @param payUUpiSdkCallback
     * @param paymentOptionHash
     * @param user_credentials
     */
    public void checkForPaymentAvailability(Activity activity, @NonNull PaymentOption paymentOption, @NonNull PayUUPICallback payUUpiSdkCallback, String paymentOptionHash, String merchantKey, String user_credentials, boolean isProduction) {
        UpiConfig upiConfig = new UpiConfig();
        upiConfig.setProduction(isProduction);
        UpiData.SINGLETON.setUpiConfig(upiConfig);
        PaymentHandler paymentHandler = new PaymentHandler(activity);
        paymentHandler.checkForPaymentAvailability(activity, paymentOption, payUUpiSdkCallback, paymentOptionHash, merchantKey, user_credentials);

    }

    /**
     * Method called when we try to make payment directly through Upi SDK.
     *
     * @param activity
     * @param postData
     * @param payUUpiSdkCallback
     */
    public void getCommandResponse(Activity activity, String postData, @NonNull PayUUPICallback payUUpiSdkCallback) {

        PaymentHandler paymentHandler = new PaymentHandler(activity);
        paymentHandler.getCommandResponse(postData, payUUpiSdkCallback);

    }

    /**
     * Method called when we try to make payment directly through Upi SDK.
     *
     * @param activity
     * @param postData
     * @param payUUpiSdkCallback
     */
    public void getCommandResponse(Activity activity, String postData, boolean isProduction, @NonNull PayUUPICallback payUUpiSdkCallback) {
        UpiConfig upiConfig = new UpiConfig();
        upiConfig.setProduction(isProduction);
        UpiData.SINGLETON.setUpiConfig(upiConfig);
        PaymentHandler paymentHandler = new PaymentHandler(activity);
        paymentHandler.getCommandResponse(postData, payUUpiSdkCallback);
    }

    public void validateVPA(Activity activity, HashMap<String, Object> payuPaymentParams, @NonNull PayUUPICallback payUUPICallback) {
        ParserValidator validator = ParserValidator.validateVPAParams(payuPaymentParams);
        if (!validator.isValid()) {
            payUUPICallback.onUpiErrorReceived(PayuErrors.MISSING_PARAMETER_EXCEPTION, validator.getMessage());
            return;
        }
        String hash = String.valueOf(((HashMap<String, Object>) payuPaymentParams.get(UpiConstant.HASHES)).get(UpiConstant.VALIDATE_VPA));
        String key = String.valueOf(payuPaymentParams.get(UpiConstant.KEY));
        String vpa = String.valueOf(payuPaymentParams.get(UpiConstant.VPA));
        boolean isProduction = Boolean.parseBoolean(String.valueOf(payuPaymentParams.get(UpiConstant.PAYU_IS_PROD)));
        HashMap<String, String> map = new HashMap<>();
        map.put(UpiConstant.CP_VALIDATE_AUTO_PAY_VPA, "1");
        String postData =
                "key=" + key + "&var1=" + vpa + "&var2=" + new JSONObject(map) +
                        "&command=validateVPA&hash=" + hash;


        UpiConfig upiConfig = new UpiConfig();
        upiConfig.setPayuPostData(postData);
        upiConfig.setMerchantKey(key);
        upiConfig.setProduction(isProduction);
        UpiData.SINGLETON.setUpiConfig(upiConfig);
        getCommandResponse(activity, postData, payUUPICallback);
    }


}
