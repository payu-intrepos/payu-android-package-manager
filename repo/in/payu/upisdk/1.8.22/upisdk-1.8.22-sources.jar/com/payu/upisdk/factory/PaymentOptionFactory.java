package com.payu.upisdk.factory;


import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.wrapper.GPayWrapper;
import com.payu.upisdk.wrapper.PaymentOptionWrapper;
import com.payu.upisdk.wrapper.PhonePeWrapper;
import com.payu.upisdk.wrapper.SamsungPayWrapper;

public class PaymentOptionFactory {
    private final PaymentOption paymentOption;
    private PaymentOptionWrapper paymentOptionWrapper;

    public PaymentOptionFactory(PaymentOption paymentOption) {
        this.paymentOption = paymentOption;
    }

    public PaymentOptionWrapper getPaymentWrapper() {
        switch (paymentOption) {
            case PHONEPE:
                paymentOptionWrapper = getPhonePeWrapper();
                break;
            case SAMSUNGPAY:
                paymentOptionWrapper = getSamsungPayWrapper();
                break;
            case TEZ:
                paymentOptionWrapper = getTezWrapper();
                break;

            default:
                break;
        }
        return paymentOptionWrapper;
    }

    private PaymentOptionWrapper getTezWrapper() {

        return new GPayWrapper();
    }

    private PaymentOptionWrapper getPhonePeWrapper() {
        return new PhonePeWrapper();
    }


    private PaymentOptionWrapper getSamsungPayWrapper() {
        // return  new SamsungPayWrapper();
        if (UpiData.SINGLETON.getSamsungPayWrapper() == null) {
            return new SamsungPayWrapper();
        } else {
            return UpiData.SINGLETON.getSamsungPayWrapper();
        }
    }

}
