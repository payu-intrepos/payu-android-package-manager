package com.payu.upisdk.parser;

import android.text.TextUtils;

import com.payu.paymentparamhelper.PayuConstants;
import com.payu.paymentparamhelper.PayuErrors;
import com.payu.upisdk.util.UpiConstant;

import java.util.HashMap;

public class ParserValidator {
    private boolean valid;
    private String message;

    private ParserValidator(boolean valid, String message) {
        this.valid = valid;
        this.message = message;

    }

    public boolean isValid() {
        return valid;
    }

    public String getMessage() {
        return message;
    }


    private static ParserValidator sendValidation(boolean status, String message) {
        return new ParserValidator(status, message);
    }


    private static ParserValidator hasHash(HashMap<String, Object> payuPaymentParams, String key) {
        if (!payuPaymentParams.containsKey(UpiConstant.HASHES)) {
            return new ParserValidator(false, PayuErrors.MANDATORY_PARAM_HASH_IS_MISSING);
        }
        if (!(payuPaymentParams.get(UpiConstant.HASHES) instanceof HashMap)
                || !(((HashMap<String, Object>) payuPaymentParams.get(UpiConstant.HASHES)).containsKey(key))) {
            return sendValidation(false, PayuErrors.MANDATORY_PARAM_PREIX + ParserConstants.HASHES + "->" + key + PayuErrors.IS_MISSING_POSTIX);
        }
        return sendValidation(true, "");
    }

    private static ParserValidator isUPIParamsValid(HashMap<String, Object> payuPaymentParams) {

        if (!payuPaymentParams.containsKey(UpiConstant.KEY)
                || TextUtils.isEmpty(String.valueOf(payuPaymentParams.get(ParserConstants.KEY)))) {
            return sendValidation(false, PayuErrors.MANDATORY_PARAM_KEY_IS_MISSING);
        }

        if (String.valueOf(payuPaymentParams.get(ParserConstants.PAYMENT_MODE)).equals(PayuConstants.UPI)
                && (!payuPaymentParams.containsKey(UpiConstant.VPA)
                || TextUtils.isEmpty(String.valueOf(payuPaymentParams.get(UpiConstant.VPA))))) {
            return sendValidation(false, PayuErrors.INVALID_VPA_MESSAGE);
        }
        return sendValidation(true, "");
    }

    public static ParserValidator validateVPAParams(HashMap<String, Object> payuPaymentParams) {
        ParserValidator validator = isUPIParamsValid(payuPaymentParams);
        if (!validator.isValid()) {
            return validator;
        }
        validator = hasHash(payuPaymentParams, UpiConstant.VALIDATE_VPA);
        if (!validator.isValid()) {
            return validator;
        }
        return sendValidation(true, "");
    }


    public static ParserValidator paymentValidation(HashMap<String, Object> payuPaymentParams) {
        ParserValidator validator = isUPIParamsValid(payuPaymentParams);
        if (!validator.isValid()) {
            return validator;
        }
        validator = hasHash(payuPaymentParams, UpiConstant.PAYMENT);
        if (!validator.isValid()) {
            return validator;
        }
        if (!payuPaymentParams.containsKey(ParserConstants.PAYMENT_MODE) ||
                TextUtils.isEmpty(String.valueOf(payuPaymentParams.get(ParserConstants.PAYMENT_MODE)))
                || (!payuPaymentParams.get(ParserConstants.PAYMENT_MODE).equals(PayuConstants.UPI_INTENT)
                && !payuPaymentParams.get(ParserConstants.PAYMENT_MODE).equals(PayuConstants.UPI)
                && !payuPaymentParams.get(ParserConstants.PAYMENT_MODE).equals(PayuConstants.INTTPV)
        )
        ) {
            return sendValidation(false, PayuErrors.MANDATORY_PARAM_PAYMENT_MODE_IS_MISSING + ParserConstants.VALID_PAYMENT_MODES);
        }
        return sendValidation(true, "");
    }
}
