// The MIT License (MIT)
//
// Copyright (c) 2014-2015 PayU India
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package com.payu.upisdk.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.webkit.CookieManager;

import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsConfig;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUDeviceAnalytics;
import com.payu.upisdk.BuildConfig;
import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.R;
import com.payu.upisdk.Upi;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.upiintent.UPIPaymentConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by minie on 29/6/15.
 * Contains cb's utility functions.
 */
public class UpiUtil {

    private static final String TAG = "UpiUtil";
    public static String SDK_INTEGRATION_PACKAGE_NAME = null;

    public static AnalyticsConfig getAnalyticsConfig(String type) {
        AnalyticsConfig analyticsConfig = new AnalyticsConfig();
        analyticsConfig.setInitiatorIdentifier(BuildConfig.LIBRARY_PACKAGE_NAME.concat(type));
        return analyticsConfig;
    }

    /**
     * Return system current time of system
     *
     * @return system current time in string
     */
    public static String getSystemCurrentTime() {
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return df.format(currentDate);
        } catch (Exception ignored) {

        }
        return "";
    }

    /**
     * Provide JSONObject for analytics
     *
     * @param context        application context
     * @param key            analytics event ket
     * @param value          event value
     * @param sdkMerchantKey merchant key
     * @param trnxID         transaction  ID
     * @return
     */
    public static String getLogMessage(Context context, String key, String value, String sdkMerchantKey, String trnxID) {
        try {
            JSONObject eventAnalytics = new JSONObject();
            eventAnalytics.put(UpiAnalyticsConstant.TRANSACTION_ID, trnxID);
            eventAnalytics.put(UpiAnalyticsConstant.MERCHANT_KEY, sdkMerchantKey);
            eventAnalytics.put(UpiAnalyticsConstant.KEY, key);
            eventAnalytics.put(UpiAnalyticsConstant.VALUE, URLEncoder.encode(value, "UTF-8"));
            eventAnalytics.put(UpiAnalyticsConstant.PACKAGE_NAME, context.getPackageName());
            eventAnalytics.put(UpiAnalyticsConstant.TIMESTAMP, getSystemCurrentTime());
            if (!TextUtils.isEmpty(Upi.cbVersion))
                eventAnalytics.put(UpiConstant.CB_VERSION_NAME, Upi.cbVersion);
            eventAnalytics.put(UpiConstant.SDK_VERSION_NAME, BuildConfig.VERSION_NAME + "");
            eventAnalytics.put(UpiAnalyticsConstant.VERSION_CODE, getVersionCode(context));
            if (SDK_INTEGRATION_PACKAGE_NAME == null) {
                SDK_INTEGRATION_PACKAGE_NAME = getIntegratedSdkPackageName();
            }
            eventAnalytics.put(UpiAnalyticsConstant.SDK_INTEGRATION, SDK_INTEGRATION_PACKAGE_NAME);
            eventAnalytics.put(UpiAnalyticsConstant.ORIGIN_SDK, getOriginSdkPackageName());
            String deviceName = Build.MANUFACTURER.toUpperCase() + "(" + Build.MODEL+")";
            int deviceOsVersion = Build.VERSION.SDK_INT;
            Long deviceTotalMemory = getTotalMemoryInfo(context);
            Long availMemory = getAvailableMemoryInfo(context);
            Long memoryInfo = availMemory * 100 / deviceTotalMemory;

            eventAnalytics.put(UpiAnalyticsConstant.DEVICE_DETAILS, deviceName+"_Android("+deviceOsVersion+")_Memory("+memoryInfo+"% Free)");
            L.v(eventAnalytics.toString());
            return eventAnalytics.toString();
        } catch (Exception e) {

            return "{}";
        }
    }

    private static String getOriginSdkPackageName() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        StackTraceElement previousStack = null;
        for (int i = 0; i < stackTraceElements.length; i++) {
            StackTraceElement element = stackTraceElements[i];
            if (element.getClassName().startsWith("com.payu")) {
                previousStack = element;
                break;
            }
        }
        return previousStack != null ? previousStack.getClassName() : null;
    }

    private static String getIntegratedSdkPackageName() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        StackTraceElement previousStack = null;
        for (int i = 0; i < stackTraceElements.length; i++) {
            StackTraceElement element = stackTraceElements[i];
            if (element.getClassName().startsWith("com.payu")) {
                previousStack = element;
            }
        }
        return previousStack != null ? previousStack.getClassName() : null;
    }

    private static Long getTotalMemoryInfo(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return memoryInfo.totalMem / (1024 * 1024);
    }

    private static Long getAvailableMemoryInfo(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return memoryInfo.availMem / (1024 * 1024);
    }

    /***
     * Return HttpsURLConnection object
     *
     * @param strURL   postURL
     * @param postData data to be posted
     * @param timeout timeout
     * @param cookiesList list of cookie
     * @return connection object
     */
    public HttpsURLConnection getHttpsConn(String strURL, String postData, int timeout, String cookiesList) {
        try {
            URL url = new URL(strURL);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            if (timeout != -1) {
                conn.setConnectTimeout(timeout);
            }
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            if (postData != null) {
                conn.setRequestProperty("Content-Length", String.valueOf(postData.length()));
            }
            if (cookiesList != null) {
                conn.setRequestProperty("Cookie", cookiesList);
            }
            conn.setSSLSocketFactory(new TLSSocketFactory());
            conn.setDoOutput(true);
            if (postData != null) {
                byte[] postParamsByte = postData.getBytes();
                conn.getOutputStream().write(postParamsByte);
            }
            return conn;
        } catch (Exception e) {

            return null;
        }
    }


    /**
     * Cancel timer
     *
     * @param timer timer object
     */
    public void cancelTimer(Timer timer) {
        if (timer != null) {
            timer.cancel();
            timer.purge();
        }
    }

    // Todo: Remove this method use  public HashMap getDataFromPostData(String postData) instead
    @Deprecated
    public String getDataFromPostData(String postData, String key) {
        String[] list = postData.split("&");
        for (String item : list) {
            String[] items = item.split("=");
            if (items.length >= 2) {
                String id = items[0];
                if (id.equalsIgnoreCase(key)) {
                    return items[1];
                }
            }
        }
        return "";
    }

    /**
     * Using Hash map to get all the post data key and value.
     * Later we can use this methods to parase non payu's post data.
     *
     * @param postData
     * @return
     */
    public static HashMap<String, String> getDataFromPostData(String postData) {
        HashMap<String, String> postParamsMap = new HashMap<>();
        if (null != postData) {
            StringTokenizer tokens = new StringTokenizer(postData, "&");
            while (tokens.hasMoreTokens()) {
                String[] keyValue = tokens.nextToken().split("=");
                if (null != keyValue && keyValue.length > 0 && null != keyValue[0]) {
                    postParamsMap.put(keyValue[0], keyValue.length > 1 ? keyValue[1] : "");
                }
            }
        }
        return postParamsMap;
    }

    public static String getDeviceDensity(Activity activity) {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.densityDpi + "";
    }

    /**
     * Method to get the Base64 Decoded String value
     *
     * @param data - Base64 encoded String
     * @return Base64 decoded String/null in case of Invalid Base64
     */
    public static String getBase64DecodedString(String data) {
        try {
            return new String(Base64.decode(data, Base64.DEFAULT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }


    /**
     * Checks if the module for payment option passed in argument is available
     *
     * @param paymentOption paymentOption like, TEZAPP,etc
     * @return true, if module is available else false
     */
    public static boolean isPaymentModuleAvailable(PaymentOption paymentOption) {
        try {
            UpiUtil.class.getClassLoader().loadClass(paymentOption.getClassName());
            return true;
        } catch (ClassNotFoundException e) {
            L.e("Please import " + paymentOption.getPackageName() + " to make Payment by " + paymentOption.toString());
            return false;
        }
    }

    /**
     * Calculate network status
     *
     * @param context
     * @return
     */

    public static String getNetworkStatus(Context context) {
        try {
            if (null != context) {
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo info = cm.getActiveNetworkInfo();
                if (info == null || !info.isConnected())
                    return "Not connected"; //not connected
                if (info.getType() == ConnectivityManager.TYPE_WIFI)
                    return "WIFI";
                if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                    int networkType = info.getSubtype();
                    switch (networkType) {
                        case TelephonyManager.NETWORK_TYPE_GPRS:
                            return "GPRS";
                        case TelephonyManager.NETWORK_TYPE_EDGE:
                            return "EDGE";
                        case TelephonyManager.NETWORK_TYPE_CDMA:
                            return "CDMA";
                        case TelephonyManager.NETWORK_TYPE_1xRTT:
                        case TelephonyManager.NETWORK_TYPE_IDEN: //api<8 : replace by 11
                            return "2G";
                        case TelephonyManager.NETWORK_TYPE_UMTS:
                        case TelephonyManager.NETWORK_TYPE_EVDO_0:
                        case TelephonyManager.NETWORK_TYPE_EVDO_A:
                        case TelephonyManager.NETWORK_TYPE_HSDPA:
                        case TelephonyManager.NETWORK_TYPE_HSUPA:
                        case TelephonyManager.NETWORK_TYPE_HSPA:
                            return "HSPA";
                        case TelephonyManager.NETWORK_TYPE_EVDO_B: //api<9 : replace by 14
                        case TelephonyManager.NETWORK_TYPE_EHRPD:  //api<11 : replace by 12
                        case TelephonyManager.NETWORK_TYPE_HSPAP:  //api<13 : replace by 15
                            return "3G";
                        case TelephonyManager.NETWORK_TYPE_LTE:    //api<11 : replace by 13
                            return "4G";
                        default:
                            return "?";
                    }
                }
            }
        } catch (Exception e) {
            return "?";
        }
        return "?";
    }

    public static String getVersionCode(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            L.v("Version name " + pInfo.versionName);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            L.v("UpiUtil:getVersionCode: NameNotFoundException: " + e.getMessage());
        } catch (RuntimeException exception) {
            // getPackageInfo throws the RuntimeException when the api failed to retrieve data.
            // https://android.googlesource.com/platform/frameworks/base/+/37960c7/core/java/android/app/ApplicationPackageManager.java
            // The root cause could be the provider is not allowed to contact by external app or
            //  app got deleted in background during the process.
            L.d(TAG + "- RuntimeException " + exception.getMessage());
        }
        return "";
    }

    public PaymentOption getSupportedPayment(String postData) {
        if (null != postData) {
            String paymentMethod = getDataFromPostData(postData, UPIPaymentConstants.BANK_CODE);

            for (PaymentOption payment : PaymentOption.values()) {
                if (payment.getPaymentName().equalsIgnoreCase(paymentMethod)) {
                    return payment;
                }
            }
        }
        return null;
    }

    public String getUPIIntent(String payeeVpa, String payeeName, String amount, String transactionId, String transactionRefId, String currency) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(UPIPaymentConstants.UPI_INTENT_PREFIX);
        stringBuilder.append(UPIPaymentConstants.PAYEEE_ADDRESS);
        stringBuilder.append("=");
        stringBuilder.append(payeeVpa);
        stringBuilder.append("&");
        stringBuilder.append(UPIPaymentConstants.PAYEE_NAME);
        stringBuilder.append("=");
        stringBuilder.append(payeeName);
        stringBuilder.append("&");
        stringBuilder.append(UPIPaymentConstants.TRANSACTION_AMOUNT);
        stringBuilder.append("=");
        stringBuilder.append(amount);
        stringBuilder.append("&");
        stringBuilder.append(UPIPaymentConstants.TRANSACTION_REF_ID);
        stringBuilder.append("=");
        stringBuilder.append(transactionRefId);
        stringBuilder.append("&");
        stringBuilder.append(UPIPaymentConstants.TRANSACTIONID);
        stringBuilder.append("=");
        stringBuilder.append(transactionId);
        stringBuilder.append("&");
        stringBuilder.append(UPIPaymentConstants.CURRENCY);
        stringBuilder.append("=");
        stringBuilder.append(currency);
//        stringBuilder.append("&");
//        stringBuilder.append("tn");
//        stringBuilder.append("=");
//        stringBuilder.append("Notes");
        return stringBuilder.toString();
    }

    public static boolean validateVpa(String vpa, String regex) {
        if (TextUtils.isEmpty(vpa))
            return false;
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(vpa.trim()).matches();
    }

    public static AlertDialog.Builder getAlertDialog(Activity activity, DialogInterface.OnClickListener onClickDialog, String positiveText, String negativeText, String title, String message) {
        AlertDialog.Builder alertbox = new AlertDialog.Builder(activity, R.style.upi_sdk_dialog);
        if (onClickDialog != null) {
            if (title != null)
                alertbox.setTitle(title);
            if (message != null)
                alertbox.setMessage(message);
            if (positiveText != null)
                alertbox.setPositiveButton(positiveText, onClickDialog);
            if (negativeText != null)
                alertbox.setNegativeButton(negativeText, onClickDialog);
        }
        return alertbox;

    }

    /**
     * set the analytics key for the analytics of events and device
     *
     * @param value analytics key
     */
    private void setVariableReflection(String className, String value, String varName) {
        try {

            if (value != null && !value.trim().equals("")) {
                Class aClass = Class.forName(className);
                Field field = aClass.getDeclaredField(varName);
                field.setAccessible(true);
                field.set(null, value);
                field.setAccessible(false);
            }
        } catch (Exception ignored) {

        }
    }

    /**
     * Function to set CB/UPI sdk version in 3rd Party SDKs
     */
    public void setUPICBSdkVersion(String className) {
        setVariableReflection(className, Upi.cbVersion, UpiConstant.CB_VERSION_NAME);
        setVariableReflection(className, BuildConfig.VERSION_NAME, UpiConstant.SDK_VERSION_NAME);
    }

    /**
     *
     */
    public static void setUpiConfigData() {
        UpiConfig upiConfig = UpiData.SINGLETON.getUpiConfig();
        String postUrl =  getPostUrl(upiConfig);
        String webServiceUrl =  getWebServiceUrl(upiConfig);
        if (upiConfig == null) {
            upiConfig = new UpiConfig();
        }
        upiConfig.setWebServiceUrl(webServiceUrl);
        upiConfig.setPostUrl(postUrl);
        UpiData.SINGLETON.setUpiConfig(upiConfig);
    }


    private static String getPostUrl(UpiConfig upiConfig) {
        return (upiConfig != null && upiConfig.getPostUrl() != null) ? upiConfig.getPostUrl() : getPostUrlFromEnvironment(upiConfig);
    }

    private static String getPostUrlFromEnvironment(UpiConfig upiConfig) {
        String postUrl = (upiConfig != null && !upiConfig.isProduction()) ? UpiConstant.TEST_URL : UpiConstant.PAYMENT_URL;
        return postUrl + UpiConstant._PAYMENT;
    }

    private static String getWebServiceUrl(UpiConfig upiConfig) {
        String webServiceUrl = (upiConfig != null && upiConfig.getWebServiceUrl() != null) ? upiConfig.getWebServiceUrl() : getWebServiceUrlFromEnvironment(upiConfig);
        return webServiceUrl + UpiConstant.MERCHANT_POST_SERVICE_FORM;
    }

    private static String getWebServiceUrlFromEnvironment(UpiConfig upiConfig) {
        return (upiConfig != null && !upiConfig.isProduction()) ? UpiConstant.TEST_URL : UpiConstant.PRODUCTION_FETCH_DATA_URL;
    }

    public static void deviceAnalytics(String sdkMerchantKey, Activity activity, String postData) {
        JSONObject deviceDetails = new JSONObject();
        PayUDeviceAnalytics payuDeviceAnalytics;
        try {

            deviceDetails.put(UpiAnalyticsConstant.TRANSACTION_ID, UpiUtil.getDataFromPostData(postData).get("txnid"));
            deviceDetails.put(UpiAnalyticsConstant.MERCHANT_KEY, sdkMerchantKey);
            deviceDetails.put(UpiAnalyticsConstant.DEVICE_OS_VERSION, Build.VERSION.SDK_INT + "");
            deviceDetails.put(UpiAnalyticsConstant.DEVICE_RESOLUTION, UpiUtil.getDeviceDensity(activity));
            deviceDetails.put(UpiAnalyticsConstant.DEVICE_MANUFACTURE, Build.MANUFACTURER);
            deviceDetails.put(UpiAnalyticsConstant.DEVICE_MODEL, Build.MODEL);
            deviceDetails.put(UpiAnalyticsConstant.NETWORK_INFO, UpiUtil.getNetworkStatus(activity.getApplicationContext()));
            deviceDetails.put(UpiAnalyticsConstant.SDK_VERSION_NAME, BuildConfig.VERSION_NAME + "");
            deviceDetails.put(UpiAnalyticsConstant.CB_VERSION_NAME, Upi.cbVersion);
            deviceDetails.put(UpiAnalyticsConstant.PACKAGE_NAME, activity.getPackageName());
            deviceDetails.put(UpiAnalyticsConstant.NETWORK_STRENGTH, UpiUtil.getNetworkStatus(activity));
            payuDeviceAnalytics = (PayUDeviceAnalytics) new AnalyticsFactory(activity.getApplicationContext(), getAnalyticsConfig(AnalyticsType.PAYU_ANALYTICS.name())).getAnalyticsClass(AnalyticsType.PAYU_DEVICE_ANALYTICS);
            payuDeviceAnalytics.log(deviceDetails.toString());
        } catch (JSONException ignored) {

        }
    }

    /**
     * Check is selected application is installed or not
     *
     * @param packageName Application to check if it is installed or not
     * @param context     Context
     * @return True in case application is present else false
     */
    public static boolean isAppInstalled(String packageName, Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
            L.v("UpiUtil: isAppInstalled: NameNotFoundException: " + ignored.getMessage());
        } catch (RuntimeException exception) {
            // getPackageInfo throws the RuntimeException when the api failed to retrieve data.
            // https://android.googlesource.com/platform/frameworks/base/+/37960c7/core/java/android/app/ApplicationPackageManager.java
            // The root cause could be the provider is not allowed to contact by external app or
            //  app got deleted in background during the process.
            L.d(TAG + "- RuntimeException " + exception.getMessage());
        }
        return false;
    }

    /**
     * Check if user is on-boarded on UPI platform on selected app instead of checking app is installed or not.
     *
     * @param packageName Application package name
     * @param context     Context
     * @return Returns true in case App is eligible for UPI payment else false.
     */
    public static boolean isUserOnboardedOnUpi(String packageName, Context context) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setPackage(packageName);
        intent.setData(Uri.parse(UpiConstant.UPI_INTENT_DATA));
        return context.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null;
    }

    /**
     * Get Application's icon drawable
     *
     * @param context     Application Context
     * @param packageName Application Package Id
     * @return Drawable if Application installed else null
     */
    public static Drawable getAppIcon(Context context, String packageName) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            return context.getPackageManager().getApplicationIcon(packageInfo.applicationInfo);
        } catch (PackageManager.NameNotFoundException e) {
            L.v("UpiUtil: getAppIcon: NameNotFoundException: " + e.getMessage());
            return null;
        } catch (RuntimeException exception) {
            // getPackageInfo throws the RuntimeException when the api failed to retrieve data.
            // https://android.googlesource.com/platform/frameworks/base/+/37960c7/core/java/android/app/ApplicationPackageManager.java
            // The root cause could be the provider is not allowed to contact by external app or
            //  app got deleted in background during the process.
            L.d(TAG + "- RuntimeException " + exception.getMessage());
            return null;
        }
    }

    /**
     * Add analytics data to SharedPreference to be used by all SDKs before pushing to server.
     *
     * @param postData Merchant's PostData
     */
    public String getAnalyticsAddedPostData(String postData) {
        JSONArray jsonArray;
        String jsonArrayValue = "";
        HashMap<String, String> hashMap = getDataFromPostData(postData);
        if (hashMap.containsKey(UpiConstant.SDK_PLATFORM_KEY)) {
            jsonArrayValue = hashMap.get(UpiConstant.SDK_PLATFORM_KEY);
        }
        try {
            if (!TextUtils.isEmpty(jsonArrayValue)) {
                jsonArray = new JSONArray(jsonArrayValue);
            } else {
                jsonArray = new JSONArray();
            }
            JSONObject object = new JSONObject();
            object.put(UpiConstant.PLATFORM_KEY, UpiConstant.PLATFORM_VALUE);
            object.put(UpiConstant.NAME_KEY, UpiConstant.NAME_VALUE);
            object.put(UpiConstant.VERSION_KEY, BuildConfig.VERSION_NAME);
            jsonArray.put(object);
        } catch (JSONException e) {
            return convertHashMapToPostData(hashMap);
        }
        hashMap.put(UpiConstant.SDK_PLATFORM_KEY, jsonArray.toString());
        return convertHashMapToPostData(hashMap);
    }

    private String convertHashMapToPostData(HashMap<String, String> hashMap) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String key : hashMap.keySet()) {
            stringBuilder.append(key);
            stringBuilder.append("=");
            stringBuilder.append(hashMap.get(key));
            stringBuilder.append("&");
        }
        return stringBuilder.toString().substring(0, stringBuilder.lastIndexOf("&"));
    }

    public static String getVersionName(String packageName, Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo pInfo = pm.getPackageInfo(packageName, 0);
            L.v("PackageName: " + packageName + " App version: " + pInfo.versionName);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            L.v("UpiUtil: getVersionName: NameNotFoundException: " + e.getMessage());

        } catch (RuntimeException exception) {
            // getPackageInfo throws the RuntimeException when the api failed to retrieve data.
            // https://android.googlesource.com/platform/frameworks/base/+/37960c7/core/java/android/app/ApplicationPackageManager.java
            // The root cause could be the provider is not allowed to contact by external app or
            //  app got deleted in background during the process.
            L.d(TAG + "- RuntimeException " + exception.getMessage());
        }
        return "";
    }

    /**
     * Return list of cookie of the given domain
     *
     * @param domainName name of domain
     * @return cookie string
     */
    public String getCookieList(String domainName) {
        StringBuilder cookieString = new StringBuilder();

        try {
            CookieManager cookieManager = CookieManager.getInstance();
            String cookies = cookieManager.getCookie(domainName); // return string of all cookie for the given domain
            if (cookies != null) {
                String[] temp = cookies.split(";");
                for (String ar1 : temp) {
                    String[] cookiesNameValue = ar1.split("=");
                    cookieString.append(cookiesNameValue[0]).append("=").append(cookiesNameValue[1]).append(";");
                }
            }
            if (cookieString.length() > 0) {
                cookieString = new StringBuilder(cookieString.substring(0, cookieString.length() - 1));
            }
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "getCookieList exception " + e.getMessage());
            return null;
        }
        return cookieString.toString();
    }

}
