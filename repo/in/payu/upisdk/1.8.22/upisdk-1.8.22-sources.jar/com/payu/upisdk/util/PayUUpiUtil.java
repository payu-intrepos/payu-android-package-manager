package com.payu.upisdk.util;

import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_AMAZONPAY;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_BAJAJPAY;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_BHIM;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_CRED;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_FIMONEY;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_FLIPKART;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_GOKIWI;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_GOOGLEPAY;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_JUPITER;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_MOBIKWIK;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_PAYTM;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_PHONEPE;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_SLICE;
import static com.payu.upisdk.util.UpiConstant.PACKAGE_ID_WHATSAPP;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_AMAZONPAY;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_BAJAJPAY;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_BHIM;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_CRED;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_FIMONEY;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_FLIPKART;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_GOKIWI;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_GOOGLEPAY;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_JUPITER;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_MOBIKWIK;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_PAYTM;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_PHONEPE;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_SLICE;
import static com.payu.upisdk.util.UpiConstant.UPI_APPNAME_WHATSAPP;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.WindowManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PayUUpiUtil {

    public static String upiPackageName;

    public static void setUpiPackageName(String upiPackageName) {
        PayUUpiUtil.upiPackageName = upiPackageName;
    }

    public static String getNameFromPackageName() {

        if (getUPIAppNamesMap().containsKey(upiPackageName)) {
            return getUPIAppNamesMap().get(upiPackageName);
        } else {
            return upiPackageName;
        }
    }

    private static HashMap<String, String> getUPIAppNamesMap() {
        HashMap<String, String> name = new HashMap<>();
        name.put(PACKAGE_ID_PHONEPE, UPI_APPNAME_PHONEPE);
        name.put(PACKAGE_ID_PAYTM, UPI_APPNAME_PAYTM);
        name.put(PACKAGE_ID_BHIM, UPI_APPNAME_BHIM);
        name.put(PACKAGE_ID_AMAZONPAY, UPI_APPNAME_AMAZONPAY);
        name.put(PACKAGE_ID_GOOGLEPAY, UPI_APPNAME_GOOGLEPAY);
        name.put(PACKAGE_ID_WHATSAPP, UPI_APPNAME_WHATSAPP);
        name.put(PACKAGE_ID_FIMONEY, UPI_APPNAME_FIMONEY);
        name.put(PACKAGE_ID_JUPITER, UPI_APPNAME_JUPITER);
        name.put(PACKAGE_ID_SLICE, UPI_APPNAME_SLICE);
        name.put(PACKAGE_ID_MOBIKWIK, UPI_APPNAME_MOBIKWIK);
        name.put(PACKAGE_ID_GOKIWI, UPI_APPNAME_GOKIWI);
        name.put(PACKAGE_ID_CRED, UPI_APPNAME_CRED);
        name.put(PACKAGE_ID_BAJAJPAY, UPI_APPNAME_BAJAJPAY);
        name.put(PACKAGE_ID_FLIPKART, UPI_APPNAME_FLIPKART);
        return name;
    }

    public static ArrayList<JSONObject> getInstalledUpiAppsList(Context context) {
        if (context == null)
            return null;

        ArrayList<JSONObject> packageList = new ArrayList<JSONObject>();
        Intent intent = new Intent();
        intent.setData(Uri.parse(UpiConstant.CP_UPI_INTENT_PREFIX));
        List<ResolveInfo> resolveInfos = context.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo resolveInfo : resolveInfos) {
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(resolveInfo.activityInfo.packageName, 0);
                Drawable packageDrawable =
                        context.getPackageManager().getApplicationIcon(packageInfo.applicationInfo);
                String name = (String)
                        context.getPackageManager().getApplicationLabel(packageInfo.applicationInfo);

                JSONObject packageItem = new JSONObject();
                packageItem.put(UpiConstant.VALUE, packageInfo.packageName);
                packageItem.put(UpiConstant.TITLE, name);
                packageItem.put(UpiConstant.IMAGE, packageDrawable);
                packageList.add(packageItem);
            } catch (PackageManager.NameNotFoundException | JSONException e) {
                return new ArrayList<>();
            }
        }
        return packageList;
    }

    public static void updateLayoutSecurity(Activity activity, Boolean isSecure) {
        if (isSecure) {
            activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
    }
}
