package com.payu.upisdk.callbacks;

import android.app.AlertDialog;

import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.upi.IValidityCheck;


/**
 * @author shahbaz.ahmmod
 * Callback class to pass result back to merchant application.
 */

public class PayUUPICallback implements PayUUPICallbackInterface {

    @Override
    public void isPaymentOptionAvailable(boolean isAvailable, String paymentType) {

    }

    @Override
    public void isPaymentOptionAvailable(boolean isAvailable, PaymentOption paymentOption) {

    }

    @Override
    public void onVpaEntered(String vpa, IValidityCheck iValidityCheck) {

    }

    @Override
    public void onPaymentFailure(String payuResult, String merchantResponse) {

    }

    @Override
    public void onPaymentTerminate() {

    }

    @Override
    public void onPaymentSuccess(String payuResult, String merchantResponse) {

    }

    @Override
    public void onUpiErrorReceived(int code, String errorMsg) {

    }

    @Override
    public void onBackButton(AlertDialog.Builder alertDialogBuilder) {

    }

    @Override
    public void onBackApprove() {

    }

    @Override
    public void onBackDismiss() {

    }

    @Override
    public void onCommandResponse(String payuCommandResponse, String command) {

    }
}
