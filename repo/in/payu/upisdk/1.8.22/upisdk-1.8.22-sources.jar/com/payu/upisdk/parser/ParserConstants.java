package com.payu.upisdk.parser;


public class ParserConstants {
    public static final String PACKAGE_NAME = "package_name";
    public static final String PAYMENT_MODE = "payment_mode";
    public static final String KEY = "key";
    public static final String TRANSACTION_ID = "transaction_id";
    public static final String HASHES = "hashes";
    public static final String VALID_PAYMENT_MODES = " ( ex: INTENT | upi)";
    public static final Object DISABLE_INTENT_SEAMLESS_FAILURE = "disable_intent_seamless_failure";
    public static final Object MERCHANT_RESPONSE_TIMEOUT = "merchant_response_timeout";
    public static final Object PHONE_PE_USER_CACHE_ENABLED = "phone_pe_user_cache_enabled";
    public static final Object POST_URL = "post_url";
    public static final Object WEB_SERVICE_URL = "web_service_url";
}
