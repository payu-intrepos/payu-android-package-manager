package com.payu.upisdk.wrapper;

import android.app.Activity;
import android.content.Context;
import android.view.View;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.PayUUPICallbackInterface;
import com.payu.upisdk.upiintent.UPIPaymentConstants;
import com.payu.upisdk.util.AnalyticsUpiUnit;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class PhonePeWrapper extends com.payu.upisdk.wrapper.PaymentOptionWrapper {
    private Object phonepeWrapperObject;
    private PayUAnalytics analytics;
    private WeakReference<Activity> activity;
    private UpiConfig upiConfig;
    private UpiUtil upiUtil;

    /**
     * Reflection Callback mapping with PayUUpiSdkCallback and wrapper callback and SamsungPay Wrapper Callback
     */
    private final java.lang.reflect.InvocationHandler cbCallback = new java.lang.reflect.InvocationHandler() {
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) {
            if (method.getName().equalsIgnoreCase(UpiConstant.PAYMENT_OPTION_SUCCESS)) {
                analyticsTagging(UpiAnalyticsConstant.SUCCESS_TRANSACTION_UPI_SDK_PHONE_PE);
                if (cbListener != null)
                    cbListener.onPaymentSuccess(args[0] + "", args[1] + "");
//          if (null!=activity && activity.get()!=null && !activity.get().isFinishing()&& !activity.get().isDestroyed())
//                activity.get().finish();
            } else if (method.getName().equalsIgnoreCase(UpiConstant.PAYMENT_OPTION_FAILURE)) {
                analyticsTagging(UpiAnalyticsConstant.FAILURE_TRANSACTION_UPI_SDK_PHONE_PE);
                L.v("Classname :" + getClass().getCanonicalName() + " PAYMENT_OPTION_FAILURE");
                if (cbListener != null)
                    cbListener.onPaymentFailure(args[0] + "", args[1] + "");
//             if (null!=activity && activity.get()!=null && !activity.get().isFinishing()&& !activity.get().isDestroyed())
//                activity.get().finish();
            } else if (method.getName().equalsIgnoreCase(UpiConstant.PAYMENT_OPTION_INIT_SUCCESS)) {
                analyticsTagging(UpiConstant.PAYMENT_OPTION_INIT_SUCCESS);
                L.v("Class Name: " + getClass().getCanonicalName() + "ispaymentoption available init sucess upidk phonepewrapper");
                if (cbListener != null)
                    cbListener.isPaymentOptionAvailable(true, PaymentOption.PHONEPE);
                UpiData.SINGLETON.setPaymentOption(PaymentOption.PHONEPE.getPaymentName());

            } else if (method.getName().equalsIgnoreCase(UpiConstant.PAYMENT_OPTION_INIT_FAILURE)) {
                analyticsTagging(UpiConstant.PAYMENT_OPTION_INIT_FAILURE);
                L.v("Class Name: " + getClass().getCanonicalName() + "PAYMENT_OPTION_INIT_FAILURE upidk phonepewrapper cbListerenr " + cbListener);
                L.v("Class Name: " + getClass().getCanonicalName() + "Value " + args[0] + "");
                if (cbListener != null) {
                    cbListener.isPaymentOptionAvailable(false, PaymentOption.PHONEPE);
                }
                UpiData.SINGLETON.removePaymentOption(PaymentOption.PHONEPE.getPaymentName());
            } else if (method.getName().equalsIgnoreCase(UpiConstant.ON_BACK_APPROVE)) {
                analyticsTagging(UpiConstant.ON_BACK_APPROVE);
                if (cbListener != null) {
                    cbListener.onBackApprove();
                }
            } else if (method.getName().equalsIgnoreCase(UpiConstant.ON_BACK_DISMISS)) {
                analyticsTagging(UpiConstant.ON_BACK_DISMISS);
                if (cbListener != null) {
                    cbListener.onBackDismiss();
                }
            } else if (method.getName().equalsIgnoreCase(UpiConstant.ON_PAYMENT_TERMINATE)) {
                analyticsTagging(UpiConstant.ON_PAYMENT_TERMINATE);
                if (cbListener != null) {
                    cbListener.onPaymentTerminate();
                }
            }
            return null;
        }
    };

    private void analyticsTagging(String value) {
        try {
            if (null != activity && !activity.get().isFinishing() && !activity.get().isDestroyed())
                analytics.log(UpiUtil.getLogMessage(activity.get().getApplicationContext(), UpiAnalyticsConstant.TRNX_STATUS, value, upiUtil.getDataFromPostData(upiConfig.getPayuPostData(), UpiConstant.KEY), upiUtil.getDataFromPostData(upiConfig.getPayuPostData(), UPIPaymentConstants.TXNID)));
        } catch (Exception e) {
            L.v("Class analyticsLogging: " + UpiAnalyticsConstant.TRNX_STATUS + " " + value + " " + e.getMessage());
        }
    }

    /**
     * Function to make payment by phonepe
     *
     * @param activity  activity context
     * @param upiConfig {@link UpiConfig}
     */
    @Override
    public void makePayment(Activity activity, UpiConfig upiConfig) throws Exception {
        try {
            if (UpiData.SINGLETON.getPayUPICallback() != null)
                this.cbListener = UpiData.SINGLETON.getPayUPICallback();
            if (null == phonepeWrapperObject)
                initPhonePe();
            this.activity = new WeakReference<>(activity);
            this.upiUtil = new UpiUtil();
            this.upiConfig = upiConfig;
            this.analytics = AnalyticsUpiUnit.getInstance(activity.getApplicationContext());
            L.v("Class Name: " + getClass().getCanonicalName() + " Postdata " + upiConfig.getPayuPostData());
            upiUtil.setUPICBSdkVersion(UpiConstant.PHONEPE_PACKAGE);
            Method method = phonepeWrapperObject.getClass().getMethod("makePayment", Activity.class, String.class, Boolean.class, View.class);
            method.invoke(phonepeWrapperObject, activity, upiConfig.getPayuPostData(), upiConfig.isPhonePeUserCacheEnabled() == UpiConfig.TRUE_, upiConfig.getProgressDialogCustomView());

        } catch (Exception e) {
            L.v("Class name " + getClass().getCanonicalName() + " Exception " + e.getMessage());
            throw new Exception(e);
        }
    }

    @Override
    public void makePayment(Activity activity, String postData) {

    }

    private void initPhonePe() throws Exception {
        try {
            ClassLoader phonepeWrapperClassLoader = PhonePeWrapper.class.getClassLoader();
            Class phonepeWrapperClass = phonepeWrapperClassLoader.loadClass("com.payu.phonepe.PhonePeWrapper");
            Constructor phonepeWrapperConstructor = phonepeWrapperClass.getDeclaredConstructor(java.lang.reflect.InvocationHandler.class);
            phonepeWrapperConstructor.setAccessible(true);
            phonepeWrapperObject = phonepeWrapperConstructor.newInstance(cbCallback);
        } catch (Exception e) {
            L.v("Class name " + getClass().getCanonicalName() + " Exception " + e.getMessage());
            throw new Exception(e);
        }
    }

    public PhonePeWrapper(java.lang.reflect.InvocationHandler handler) {
        PayUUPICallbackInterface wrapperListener = (PayUUPICallbackInterface) Proxy.newProxyInstance(
                PayUUPICallbackInterface.class.getClassLoader(),
                new Class[]{PayUUPICallbackInterface.class},
                handler);

    }

    public PhonePeWrapper() {

    }

    /**
     * Function to check for phonepe availability
     *
     * @param context           Context
     * @param paymentOptionHash Payment Related Details Hash
     * @param merchantKey       Merchant Key
     * @param user_credentials  User Credentials
     */
    @Override
    public void checkForPaymentOptionAvailability(Context context, String paymentOptionHash, String merchantKey, String user_credentials) throws Exception {
        if (UpiData.SINGLETON.getPayUPICallback() != null)
            this.cbListener = UpiData.SINGLETON.getPayUPICallback();
        try {
            initPhonePe();
            L.v("Class Name: " + getClass().getCanonicalName() + " PaymentOptionHash " + paymentOptionHash + "\n" + " Merchant key " + merchantKey + "\n" + "User credentials " + user_credentials);

            Method method = phonepeWrapperObject.getClass().getMethod("checkForPaymentAvailability", Context.class, String.class, String.class, String.class);
            method.invoke(phonepeWrapperObject, context, paymentOptionHash, merchantKey, user_credentials);
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + "checkForPaymentOptionAvailability exception " + e.getCause());
            throw new Exception(e);
        }
    }
}
