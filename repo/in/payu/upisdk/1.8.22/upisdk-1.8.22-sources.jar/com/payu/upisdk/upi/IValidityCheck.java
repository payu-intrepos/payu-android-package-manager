package com.payu.upisdk.upi;

/**
 * We use this interface to interact with merchant to entered the hash for VPA validation.
 */
public interface IValidityCheck {

    void verifyVpa(String hash);
}
