package com.payu.upisdk.callbacks;

public interface HandleBackPress {
    void onBackPressed();
}
