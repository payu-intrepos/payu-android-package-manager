package com.payu.upisdk;

/**
 * Define Payment options
 */
public enum PaymentOption {

    UPI_INTENT("INTENT", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "GENERIC_INTENT"),
    UPI_INTENT_TPV("INTTPV", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "GENERIC_INTENT_TPV"),
    UPI_COLLECT("upi", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "UPI_COLLECT"),
    UPI_COLLECT_TPV("UPITPV", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "UPI_COLLECT_TPV"),
    UPI_COLLECT_GENERIC("COLLECT_GENERIC", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "UPI_COLLECT_GENERIC"),
    TEZ("Tez", "com.payu.gpay.GPayWrapper", "com.payu.gpay", "TEZ"),
    TEZ_TPV("TEZTPV", "com.payu.gpay.GPayWrapper", "com.payu.gpay", "TEZ_TPV"),
    PHONEPE("PPINTENT", "com.payu.phonepe.PhonePeWrapper", "com.payu.phonepe", "PHONEPE"),
    SAMSUNGPAY("SAMPAY", "com.payu.samsungpay.SamsungWrapper", "com.payu.samsungpay", "SAMSUNGPAY"),
    TEZ_OMNI("tezomni", "com.payu.upisdk.UpiWrapper", "com.payu.upisdk", "TEZ_OMNI"),;

    private final String paymentName;//Resembles with Bankcode with Backend
    private final String className;//Resembles with Bankcode with Backend
    private final String packageName;
    private final String analyticsKey;

    /**
     * @param paymentName  BankCode for payment
     * @param className    Class Name of other package
     * @param packageName  Package of Payment
     * @param analyticsKey Analytics Key value
     */
    PaymentOption(String paymentName, String className, String packageName, String analyticsKey) {
        this.paymentName = paymentName;
        this.packageName = packageName;
        this.analyticsKey = analyticsKey;
        this.className = className;
    }

    public String getClassName() {
        return className;
    }

    public String getPaymentName() {
        return paymentName;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getAnalyticsKey() {
        return analyticsKey;
    }
}
