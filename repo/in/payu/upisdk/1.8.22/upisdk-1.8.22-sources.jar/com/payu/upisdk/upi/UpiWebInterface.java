package com.payu.upisdk.upi;

import android.app.Activity;
import android.content.Intent;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.upisdk.R;
import com.payu.upisdk.UpiData;
import com.payu.upisdk.bean.UpiConfig;
import com.payu.upisdk.callbacks.WebViewListener;
import com.payu.upisdk.util.L;
import com.payu.upisdk.util.UpiAnalyticsConstant;
import com.payu.upisdk.util.UpiConstant;
import com.payu.upisdk.util.UpiUtil;

/**
 * '
 * Here we are handing the Collect flow.
 * This class has all the @JavascriptInterface methods.
 */
public class UpiWebInterface {
    private final Activity activity;
    private CountDownTimer countDownTimer;
    private String payuReponse;
    private final PayUAnalytics payUAnalytics;

    private Boolean isSuccessTransaction = Boolean.FALSE;
    private String merchantResponse;
    private final UpiConfig upiConfig;
    private WebViewListener webViewListener;

    private PendingAction actionable;
    private Boolean shouldExecuteActionImmediately = true;

    public interface PendingAction {
        void run();
    }

    public void setAction(PendingAction actionable) {
        this.actionable = actionable;
    }

    public void setShouldExecuteActionImmediately(Boolean shouldExecuteActionImmediately) {
        this.shouldExecuteActionImmediately = shouldExecuteActionImmediately;
    }

    public void executeAnyPendingAction() {
        if (actionable != null && shouldExecuteActionImmediately) {
            actionable.run();
            actionable = null;
        }
    }

    /**
     * @param activity
     * @param payUAnalytics
     * @param upiConfig
     */
    public UpiWebInterface(Activity activity, PayUAnalytics payUAnalytics, UpiConfig upiConfig) {
        this.activity = activity;
        this.payUAnalytics = payUAnalytics;
        this.upiConfig = upiConfig;
    }

    /**
     * @param activity
     * @param payUAnalytics
     * @param upiConfig
     */
    public UpiWebInterface(Activity activity, PayUAnalytics payUAnalytics, UpiConfig upiConfig, WebViewListener webViewListener) {
        this.activity = activity;
        this.payUAnalytics = payUAnalytics;
        this.upiConfig = upiConfig;
        this.webViewListener = webViewListener;
    }

    /**
     * @param result json data of post param.
     *               call back function from furl - failure transaction.
     *               keep the value in {@link #merchantResponse}
     *               set result ok, and send the received data.
     * @param result json string
     */

    @JavascriptInterface
    public void onFailure(String result) {
        L.v("Class Name: " + getClass().getCanonicalName() + " | onFailure: " + result);
        merchantResponse = result;
        addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS_ONFAILURE, result);
        onMerchantUrlFinished();
    }

    /**
     * Attempt to deprecate furl.
     * Javascript call from payu server.
     * Lets keep the data in local variable and pass it to calling activity.
     *
     * @param result json string result of failure transaction
     */
    @JavascriptInterface
    public void onPayuFailure(String result) {
        L.v("Class Name: " + getClass().getCanonicalName() + " | onPayuFailure: " + result);

        if (activity != null) {
            addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS_ONPAYUFAILURE,  result);
            isSuccessTransaction = false;
            payuReponse = result;
        }
        createTimer();
        // cancelTransactionNotification();

    }

    private void createTimer() {
        if (null != UpiData.SINGLETON.getUpiConfig()) {

            callTimer();
        } else {
            actionable = () -> {
                if (null != UpiData.SINGLETON.getPayUPICallback())
                    UpiData.SINGLETON.getPayUPICallback().onUpiErrorReceived(UpiConstant.NOT_PROVIDED_COMPLETE_INFO, UpiConstant.PROVIDED_UPI_CONFIG_NULL + getClass().getSimpleName());
            };
            executeAnyPendingAction();
        }
    }

    /**
     * Call back from surl - sucess transaction
     * with no argument.
     * just send empty string back to calling activity
     */
    @JavascriptInterface
    public void onSuccess() {
        onSuccess("");
    }

    /**
     * Attempt to deprecate surl.
     * Javascript interface call from payu server.
     * Lets keep the data in local variable and pass it to main activity.
     *
     * @param result json data of post param.
     */

    @JavascriptInterface
    public void onPayuSuccess(final String result) {

        isSuccessTransaction = true;
        addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS_ONPAYUSUCCESS , result);
        payuReponse = result;
        L.v("Class Name: " + getClass().getCanonicalName() + " | onPayUSuccess " + result);
        createTimer();
    }

    /**
     * Logging events with txnid and package name.
     * Mixpannel used only in debug mode.
     *
     * @param key   analytics event key
     * @param value analytics event value
     */
    private void addEventAnalytics(String key, String value) {
        try {
            if (!TextUtils.isEmpty(value)) {
                payUAnalytics.log(UpiUtil.getLogMessage(activity.getApplicationContext(), key, value.toLowerCase(), upiConfig.getMerchantKey(), upiConfig.getTransactionID()));
            }
        } catch (Exception e) {
            L.v("Class Name: " + getClass().getCanonicalName() + " | Exception" + e.getMessage());
        }
    }

    /**
     * call back function from surl - success transaction.
     * keep the data in {@link #merchantResponse}
     * set result ok, and send the received data.
     *
     * @param result success result received from surl
     */
    @JavascriptInterface
    public void onSuccess(String result) {
      L.v("Class Name: " + getClass().getCanonicalName() + "onSuccess " + result);
      isSuccessTransaction = true;
      merchantResponse = result;
      addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS_ONSUCCESS , result);
      onMerchantUrlFinished();
    }

    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    public void onCancel() {
        L.v("Class Name: " + getClass().getCanonicalName() + " | onCancel ");
        onCancel("");
    }

    /**
     * will be called in case of curl
     * mostly handled by furl
     */
    @JavascriptInterface
    public void onCancel(final String result) {
        L.v("Class Name: " + getClass().getCanonicalName() + " | onCancel: " + result);
        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS_CANCEL_TRANSACTION , result);
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!activity.isFinishing() && !activity.isDestroyed()) {
                        Intent intent = new Intent();
                        intent.putExtra(activity.getString(R.string.cb_result), result);
                        activity.setResult(Activity.RESULT_CANCELED, intent);
                        upiConfig.setPaymentType(UpiConstant.NONE);

                        if (!activity.isFinishing() && !activity.isDestroyed())
                            activity.finish();
                    }
                }
            });
        }
    }


    /**
     * Just to make sure we finish activity even if the merchant's url got into trouble,
     * should be called from
     */
    private void callTimer() {
        countDownTimer = new CountDownTimer(UpiData.SINGLETON.getUpiConfig().getMerchantResponseTimeout(), 1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!activity.isFinishing() && !activity.isDestroyed()) {

                                onMerchantUrlFinished();

                            }
                        }
                    });
                }
            }
        }.start();
    }


    /**
     * This function takes care of sending the data back to calling activity with the status, merchantResponse, payuresponse.
     */

    private void onMerchantUrlFinished() {
        if (null != countDownTimer)
            countDownTimer.cancel();

        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            addEventAnalytics(UpiAnalyticsConstant.TRNX_STATUS, UpiAnalyticsConstant.ON_MERCHANT_URL_FINISHED + ": " + isSuccessTransaction);

            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    actionable = () -> {
                        if (!activity.isFinishing() && !activity.isDestroyed()) {

                        if (isSuccessTransaction) {

                            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                                UpiData.SINGLETON.getPayUPICallback().onPaymentSuccess(payuReponse, merchantResponse);
                            } else {
                                L.v("Class Name: " + getClass().getCanonicalName() + "| No PayUUpiSdkCallback found, used when trying payment through CB, please assign a callback: com.payu.upisdk.UpiData.setPayUPICallback(PayUUPICallback payUPICallback)");
                            }

                        } else {
                            if (UpiData.SINGLETON.getPayUPICallback() != null) {
                                UpiData.SINGLETON.getPayUPICallback().onPaymentFailure(payuReponse, merchantResponse);
                            } else {
                                L.v("Class Name: " + getClass().getCanonicalName() + " | No PayUUpiSdkCallback found, used when trying payment through UPI SDK, please assign a callback: com.payu.upisdk.UpiData.setPayUPICallback(PayUUPICallback payUPICallback)");
                            }

                        }
                        upiConfig.setPaymentType(UpiConstant.NONE);
                        if (webViewListener != null) {
                            webViewListener.onPaymentFinished();
                        } else if (!activity.isFinishing() && !activity.isDestroyed())
                            activity.finish();
                    }
                };
                    executeAnyPendingAction();
                }
            });
        }
    }
}
