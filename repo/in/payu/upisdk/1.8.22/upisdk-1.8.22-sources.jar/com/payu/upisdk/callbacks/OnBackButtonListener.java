package com.payu.upisdk.callbacks;

public interface OnBackButtonListener {
    public void onBackButtonClicked();
}
