package com.payu.upisdk.callbacks;

import android.app.AlertDialog;

import com.payu.upisdk.PaymentOption;
import com.payu.upisdk.upi.IValidityCheck;

/**
 * @author shahbaz.ahmmod
 */
public interface PayUUPICallbackInterface {

    void isPaymentOptionAvailable(boolean isAvailable, String paymentType);

    void isPaymentOptionAvailable(boolean isAvailable, PaymentOption paymentOption);

    void onPaymentFailure(String payuResult, String merchantResponse);

    void onPaymentTerminate();

    void onPaymentSuccess(String payuResult, String merchantResponse);

    void onUpiErrorReceived(int code, String errorMsg);

    void onVpaEntered(String vpa, IValidityCheck iValidityCheck);

    void onBackButton(AlertDialog.Builder alertDialogBuilder);

    void onBackApprove();

    void onBackDismiss();

    void onCommandResponse(String payuCommandResponse, String command);
}
