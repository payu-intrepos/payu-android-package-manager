package com.payu.upisdk.upiintent;

/**
 * Created by himanshu.gupta on 18/01/18.
 */

public interface UPIPaymentConstants {
    //Error Code
    int MERCHANT_INFO_NOT_PRESENT_CODE = 1002;
    //Error Messages
    String MERCHANT_INFO_NOT_PRESENT = "MERCHANT_INFO_NOT_PRESENT";
    String ACTIVITY = "activity";
    String ACTIVITY_0  = "activity_0";
    String ACTIVITY_1  = "activity_1";
    String ACTIVITY_2  = "activity_2";
    String ACTIVITY_STARTED = "_activity_started";
    String ACTIVITY_STARTED_CODE101 = "_activity_started_code_101";
    String PACKAGE_LIST = "show_PackageListDialog";

    //Payment Method Supported
    int PAYMENT_REQUEST_CODE = 101;
    String MERCHANT_NAME = "merchantName";
    String INTENT_URI_DATA = "intentURIData";
    String MERCHANT_VPA = "merchantVpa";
    String RETURN_URL = "returnUrl";
    String REFERENCE_ID = "referenceId";
    String AMOUNT = "amount";
    String BANK_CODE = "bankcode";
    String TRANSACTION_STATUS = "txnStatus";
    String FAILURE_REASON = "failureReason";
    String TXN_S2S_FLOW = "txn_s2s_flow";
    String TXNID = "txnId";
    String DISABLE_INTENT_SEAMLESS_FAILURE = "disableIntentSeamlessFailure";
    String COMBINE_VERIFY_AND_PAY_BUTTON = "intentSdkCombineVerifyAndPayButton";
    String TOKEN = "token";
    String APPS = "apps";
    String ACTION = "action";
    String NAME = "name";
    String PACKAGE = "package";
    String VPA_REGEX = "vpaRegex";
    String VPA_REGEX_DEFAULT = "^[^@]+@[^@]+$";

    //UPI Intent Data
    String PAYEE_NAME = "pn";
    String PAYEEE_ADDRESS = "pa";
    String TRANSACTIONID = "tid";
    String TRANSACTION_REF_ID = "tr";
    String TRANSACTION_AMOUNT = "am";
    String UPI_INTENT_PREFIX = "upi://pay?";
    String UPI_PREFIX = "upi://";

    //Tez Bundle Key
    String STATUS = "Status";
    String SUCCESS = "success";
    String FAILURE = "failure";
    String CANCEL = "cancel";
    String UNMAPPEDSTATUS = "unmappedstatus";

    String PSP_AS_NEW_TASK = "pspAsNewTask";

    //Generic Payment Key
    String VPA_VALID = "isVPAValid";
    String PAYER_ACCOUNT_NAME = "payerAccountName";
    String RESULT = "result";
    //Generic Payment Error Message
    String NO_UPI_APPS_PRESENT = "No Upi apps present and collect disabled.";
    String TXN_CANCELLED_BY_PRESS_BACK_BUTTON= "Transaction cancelled by pressing back button.";

    String UPI_PUSH_DISABLED = "upiPushDisabled";
    String PUSH_SERVICE_URL = "pushServiceUrl";
    String UPI_SERVICE_POLL_INTERVAL = "upiServicePollInterval";
    String SDK_UPI_PUSH_EXPIRY = "sdkUpiPushExpiry";
    String SDK_UPI_VERIFICATION_INTERVAL = "sdkUpiVerificationInterval";
    String CURRENCY_INR = "INR";
    String CURRENCY = "cu";
    String MESSAGE = "message";

    String RESPONSE = "response";
    String UPI_APP_NAME = "upiAppName";
}
