package com.payu.payuanalytics.analytics.manager

import android.content.Context
import android.util.Log
import com.payu.payuanalytics.analytics.model.BaseAnalytics
import com.payu.payuanalytics.analytics.network.UploadTask
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant.PA_ANALYTICS_BUFFER_KEY
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsUtil
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import java.util.concurrent.Executors

class AnalyticsDataManager constructor(
    context: Context,
    val baseAnalytics: BaseAnalytics
) {
    companion object {
        // Shared across ALL AnalyticsDataManager instances (PayU/Clevertap/Device analytics)
        // so a burst of log() calls never spawns more than this single background thread.
        private val analyticsExecutor = Executors.newSingleThreadExecutor()

        // Typed as java.lang.Object (not Any) so wait()/notifyAll() are callable directly:
        // Kotlin's Any intentionally does not expose those java.lang.Object monitor methods.
        private val bufferLock = Object()
        private val fileLockMonitor = Object()
        private val pendingCrashBuffers =
            Collections.synchronizedList(mutableListOf<CrashBufferEntry>())

        @Volatile
        private var crashHandlerRegistered = false
    }

    private data class CrashBufferEntry(
        val context: Context,
        val fileName: String,
        val sharedPrefKey: String
    )

    private val TAG = AnalyticsDataManager::class.simpleName
    private val mcontext: Context?
    private val fileName: String
    private val sharedPrefKey: String

    @Volatile
    private var mainFileLocked = false
    private var mTimer: Timer? = null

    // Lock for buffer file(shared preference)
    @Volatile
    private var mBufferLock = false

    private var isTimerCancelled = false

    /**
     * set lock on main file. Blocks (via monitor wait) instead of busy-spinning
     * until the lock is released.
     */
    private fun setLock() {
        synchronized(fileLockMonitor) {
            while (mainFileLocked) {
                fileLockMonitor.wait()
            }
            mainFileLocked = true
        }
    }

    /**
     * release lock on main file
     */
    private fun releaseLock() {
        synchronized(fileLockMonitor) {
            mainFileLocked = false
            fileLockMonitor.notifyAll()
        }
    }

    /**
     * Blocks (via monitor wait) until the main file lock is released, without acquiring it.
     */
    private fun awaitUnlock() {
        synchronized(fileLockMonitor) {
            while (mainFileLocked) {
                fileLockMonitor.wait()
            }
        }
    }

    /**
     * Adding log information to a local file.
     *
     * @param msg json string
     */
    fun log(msg: String) {
        // Route every event through the single shared executor instead of creating
        // a new thread/executor per call.
        analyticsExecutor.execute {
            if (mainFileLocked) {
                //store in buffer, if main file is in use
                storeInBuffer(msg)
            } else {
                setLock()
                try {
                    val newObject = JSONObject(msg)
                    val temp = readFileInputStream(mcontext, fileName, Context.MODE_PRIVATE)
                    val jsonArray = if (temp.equals("", ignoreCase = true)) {
                        JSONArray()
                    } else {
                        JSONArray(temp)
                    }
                    mcontext?.openFileOutput(fileName, Context.MODE_PRIVATE)?.use { fileOutputStream ->
                        jsonArray.put(jsonArray.length(), newObject)
                        fileOutputStream.write(jsonArray.toString().toByteArray())
                    }
                } catch (e: IOException) {
                    Log.d(javaClass.simpleName, "log:IOException${e.localizedMessage}")
                    storeInBuffer(msg)
                } catch (e: JSONException) {
                    Log.d(javaClass.simpleName, "log:JSONException${e.localizedMessage}")
                } catch (e: Throwable) {
                    Log.d(javaClass.simpleName, "log:Throwable${e.localizedMessage}")
                } finally {
                    releaseLock()
                    resetTimer()
                }
            }
        }
    }

    /**
     * Add log information to buffer. Runs on the caller's thread (the shared
     * analyticsExecutor) using a real monitor instead of spawning a new Thread per event.
     *
     * @param msg json string
     */
    private fun storeInBuffer(msg: String) {
        synchronized(bufferLock) {
            while (mBufferLock) {
                bufferLock.wait()
            }
            mBufferLock = true
            try {
                val str = PayUAnalyticsUtil.getStringSharedPreference(
                    mcontext,
                    fileName,
                    sharedPrefKey
                )
                val jsonArray = if (!str.isNullOrEmpty()) {
                    JSONArray(str)
                } else {
                    JSONArray()
                }
                jsonArray.put(JSONObject(msg))
                PayUAnalyticsUtil.setStringSharedPreference(
                    mcontext,
                    fileName,
                    sharedPrefKey,
                    jsonArray.toString()
                )
            } catch (e: Throwable) {
                Log.d(javaClass.simpleName, "storeInBuffer:Throwable${e.localizedMessage}")
            } finally {
                mBufferLock = false
                bufferLock.notifyAll()
            }
        }
    }

    /**
     * Manages timer and sends the information to server
     */
    private fun resetTimer() {
        cancelTimer()
        mTimer = Timer()
        isTimerCancelled = false
        try {
            mTimer?.schedule(object : TimerTask() {
                override fun run() {
                    sendEventsToAnalyticsPortal()
                }
            }, baseAnalytics.timerDelay)
        } catch (e: Throwable) {
            Log.d(TAG, e.message.toString())
        }
    }

    /**
     * Cancel timer
     * */
    fun cancelTimer() {
        if (mTimer != null && !isTimerCancelled) {
            mTimer?.cancel()
            mTimer?.purge()
            isTimerCancelled = true
        }
    }

    /**
     * This will send events to Analytics portal
     */
    private fun sendEventsToAnalyticsPortal() {
        awaitUnlock()
        setLock()
        if (PayUAnalyticsUtil.checkNetwork(mcontext) && mcontext != null) {
            var temp = ""
            try {
                temp = readFileInputStream(mcontext, fileName, Context.MODE_PRIVATE)
            } finally {
                try {
                    var tempJsonArray = if (temp.isNotEmpty()) {
                        JSONArray(temp)
                    } else {
                        JSONArray()
                    }

                    // Copy buffer file data in file
                    val bufferData = PayUAnalyticsUtil.getStringSharedPreference(
                        mcontext,
                        fileName,
                        sharedPrefKey
                    )
                    if ((bufferData?.length ?: 0) > 1) {
                        synchronized(bufferLock) {
                            mBufferLock = true
                            try {
                                val analyticsBufferArray = JSONArray(bufferData)
                                tempJsonArray = copyBufferToFile(tempJsonArray, analyticsBufferArray)
                            } finally {
                                mBufferLock = false
                                bufferLock.notifyAll()
                            }
                        }
                    }

                    // upload main file events to server
                    if (tempJsonArray.length() > 0) {
                        UploadTask(baseAnalytics, tempJsonArray.toString(), baseAnalytics).push()
                    } else {
                        if (mTimer != null) {
                            mTimer?.cancel()
                        }
                        releaseLock()
                    }
                } catch (e: Throwable) {
                    Log.d(javaClass.simpleName, "sendEventsToAnalyticsPortal:Throwable${e.localizedMessage}")
                    releaseFileLockAndResetTimer()
                }
            }
        } else {
            releaseLock()
        }
    }

    /**
     * This will push all pending events to analytics portal
     */
    fun pushAllPendingEvents() {
        analyticsExecutor.execute { sendEventsToAnalyticsPortal() }
    }

    /**
     * Releases file lock and resets the timer
     */
    private fun releaseFileLockAndResetTimer() {
        releaseLock()
        if ((PayUAnalyticsUtil.getStringSharedPreference(mcontext, fileName, sharedPrefKey)
                ?.length ?: 0) > 1
        ) {
            resetTimer()
        }
    }

    /**
     * Read input stream from given file
     * base activity context
     *
     * @param fileName    file name
     * @param contextMode define access to file
     * @return data read from file
     */
    fun readFileInputStream(
        mContext: Context?,
        fileName: String,
        contextMode: Int
    ): String {
        return try {
            val file = File(mContext?.filesDir, fileName)
            if (!file.exists()) { // create the file if not created yet.
                mContext?.openFileOutput(fileName, contextMode)?.close()
                return ""
            }
            mContext?.openFileInput(fileName)?.use { inputStream ->
                String(inputStream.readBytes())
            } ?: ""
        } catch (e: FileNotFoundException) {
            Log.d(javaClass.simpleName, "readFileInputStream:FileNotFoundException${e.localizedMessage}")
            ""
        } catch (e: IOException) {
            Log.d(javaClass.simpleName, "readFileInputStream:IOException${e.localizedMessage}")
            ""
        } catch (e: Throwable) {
            Log.d(javaClass.simpleName, "readFileInputStream:Throwable${e.localizedMessage}")
            ""
        }
    }

    /**
     * Copy buffer analytics file to main analytics file
     *
     * @param fileJsonArray   main analytics file events
     * @param bufferJsonArray buffer analytics file events
     * @return fileJsonArray + bufferJsonArray(if buffer file data is successfully) else return fileJsonArray
     */
    private fun copyBufferToFile(fileJsonArray: JSONArray, bufferJsonArray: JSONArray): JSONArray {
        var fileOutputStream: FileOutputStream? = null
        return try {
            val mergeJsonArray = JSONArray(fileJsonArray.toString())
            for (i in 0 until bufferJsonArray.length()) {
                mergeJsonArray.put(bufferJsonArray.getJSONObject(i))
            }
            fileOutputStream = mcontext?.openFileOutput(fileName, Context.MODE_PRIVATE)
            fileOutputStream?.write(mergeJsonArray.toString().toByteArray())
            if (mcontext != null) {
                PayUAnalyticsUtil.deleteSharedPrefKey(mcontext, fileName, sharedPrefKey)
            }
            mergeJsonArray
        } catch (e: Throwable) {
            Log.d(javaClass.simpleName, "copyBufferToFile:Throwable${e.localizedMessage}")
            // return main file array if not able to merge main and buffer file
            fileJsonArray
        } finally {
            try {
                fileOutputStream?.close()
            } catch (e: IOException) {
                Log.d(javaClass.simpleName, "copyBufferToFile:IOException${e.localizedMessage}")
            }
        }
    }

    /**
     * Constructor
     *
     * @param context  instance of base activity
     * @param filename name of file for analytics event
     */
    init {
        mcontext = context
        fileName = baseAnalytics.analyticsFileName.plus(baseAnalytics.analyticsConfig.initiatorIdentifier)
        sharedPrefKey = PA_ANALYTICS_BUFFER_KEY.plus(baseAnalytics.analyticsConfig.initiatorIdentifier)
        pendingCrashBuffers.add(
            CrashBufferEntry(context.applicationContext, fileName, sharedPrefKey)
        )
        registerCrashHandlerOnce()
    }

    /**
     * Registers a single, process-wide uncaught exception handler no matter how many
     * AnalyticsDataManager instances (PayU/Clevertap/Device analytics) get created.
     * Previously every instance replaced the default handler, chaining N handlers that
     * each ran blocking file I/O synchronously on whichever thread crashed (including
     * the main thread), which is what turned a background crash into an ANR.
     */
    private fun registerCrashHandlerOnce() {
        synchronized(AnalyticsDataManager::class.java) {
            if (crashHandlerRegistered) return
            crashHandlerRegistered = true

            val defaultUEH = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
                try {
                    // Defer the buffer flush to the shared background executor so the
                    // crashing thread (which may be the main thread) is never blocked
                    // on file I/O before the default handler runs.
                    analyticsExecutor.execute {
                        pendingCrashBuffers.forEach { entry ->
                            flushBufferOnCrash(entry)
                        }
                    }
                } catch (_: Throwable) {
                }

                // Always call the previous default handler (e.g. Crashlytics) so crash
                // reporting behaves exactly as before.
                defaultUEH?.uncaughtException(thread, ex)
            }
        }
    }

    /**
     * Persists any buffered (not-yet-flushed) events for one analytics instance so they
     * survive process death. Uses commit() (via deleteSharedPrefKeySync) instead of
     * apply() since apply() is async and may not complete before the process dies.
     */
    private fun flushBufferOnCrash(entry: CrashBufferEntry) {
        try {
            val bufferedData = PayUAnalyticsUtil.getStringSharedPreference(
                entry.context,
                entry.fileName,
                entry.sharedPrefKey
            )
            if ((bufferedData?.length ?: 0) <= 0) return

            val bufferJsonArray = JSONArray(bufferedData)
            val jsonArray = JSONArray()
            for (i in 0 until bufferJsonArray.length()) {
                jsonArray.put(bufferJsonArray.getJSONObject(i))
            }
            entry.context.openFileOutput(entry.fileName, Context.MODE_PRIVATE).use { fileOutputStream ->
                fileOutputStream.write(jsonArray.toString().toByteArray())
            }
            PayUAnalyticsUtil.deleteSharedPrefKeySync(entry.context, entry.fileName, entry.sharedPrefKey)
        } catch (e: Throwable) {
            Log.e(TAG, "flushBufferOnCrash: ${e.message}")
        }
    }

    fun onEventsLoggedSuccessful(response: Response) {
        // if we are able to post the data to server then delete file
        mcontext?.deleteFile(fileName)
        releaseFileLockAndResetTimer()
    }

    fun onEventsLoggedFailed() {
        //events didn't processed, try to send events in next batch
        releaseFileLockAndResetTimer()
    }
}
