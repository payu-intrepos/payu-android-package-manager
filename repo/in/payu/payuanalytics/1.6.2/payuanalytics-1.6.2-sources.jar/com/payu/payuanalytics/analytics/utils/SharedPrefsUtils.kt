package com.payu.payuanalytics.analytics.utils


import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.util.Log
import androidx.core.content.edit

object SharedPrefsUtils {

    private fun getSharedPref(
        context: Context,
        fileName: String
    ): SharedPreferences {
        EncryptionUtils.getKeys(context)
        return context.getSharedPreferences(fileName, MODE_PRIVATE)
    }


    fun storeStringInSharedPreferences(
        context: Context,
        key: String?,
        value: String?,
        fileName: String
    ) {
        val sharedPreferences = getSharedPref(context, fileName)
        val editor = sharedPreferences.edit()
        value?.let { nonNullValue ->
            editor?.putString(
                key,
                EncryptionUtils.encrypt(
                    context,
                    nonNullValue
                ).toString()
            )
        }
        editor?.apply()
    }

    fun getStringFromSharedPreferences(context: Context, key: String?, fileName: String): String? {
        try {
            val sharedPreferences = getSharedPref(context, fileName)
            var decodedString: String? = null
            key?.let { nonNullKey ->
                decodedString = sharedPreferences.getString(nonNullKey, "")
                decodedString = decodedString?.let { nonNullDecodedString ->
                    EncryptionUtils.decrypt(context, nonNullDecodedString)
                }
            }
            return decodedString
        } catch (e: Exception) {
            removeAllFromSharedPref(context, fileName)
            return ""
        }
    }

    /**
     * Simple helper method to remove all the keys from given shared pref file.
     *
     * @param context
     * @param prefName
     */
    private fun removeAllFromSharedPref(context: Context, prefName: String) {
        try {
            val settings: SharedPreferences = getSharedPref(context, prefName)
            settings.edit()?.clear()?.apply()
        } catch (e: java.lang.Exception) {
            Log.d(
                this.javaClass.simpleName,
                "removeAllFromSharedPref:Exception" + e.localizedMessage
            )
        }
    }

    fun deleteFromSharedPreferences(context: Context, key: String?, fileName: String) {
        val sharedPreferences = getSharedPref(context, fileName)
        val editor = sharedPreferences.edit()
        editor?.remove(key)
        editor?.apply()
    }

    /**
     * Synchronous (commit()) delete, used only on the crash-flush path since apply()
     * is async and may not complete before the process dies.
     */
    fun deleteFromSharedPreferencesSync(context: Context, key: String?, fileName: String) {
        try {
            val sharedPreferences = getSharedPref(context, fileName)
            sharedPreferences.edit(commit = true) { remove(key) }
        } catch (e: Exception) {
            Log.e(javaClass.simpleName, "deleteFromSharedPreferencesSync failed: ${e.message}")
        }
    }

}