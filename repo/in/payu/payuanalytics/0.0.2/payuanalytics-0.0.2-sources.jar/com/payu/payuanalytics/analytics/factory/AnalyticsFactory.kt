package com.payu.payuanalytics.analytics.factory

import android.content.Context
import android.webkit.URLUtil
import com.payu.payuanalytics.R
import com.payu.payuanalytics.analytics.model.*
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant

class AnalyticsFactory @JvmOverloads constructor(
    val context: Context,
    var analyticsConfig: AnalyticsConfig = AnalyticsConfig()
) {

    fun getAnalyticsClass(type: AnalyticsType) = when (type) {
        AnalyticsType.CLEVERTAP -> {
            if (!analyticsConfig.ctAccountId.isNullOrEmpty() && !analyticsConfig.ctPassCode.isNullOrEmpty()) ClevertapAnalytics.getInstance(
                context,
                getUrl(type),
                analyticsConfig,
                getHeaders()
            )
            else throw RuntimeException(context.getString(R.string.account_id_and_passcode_is_required_for_clevertap))
        }

        AnalyticsType.PAYU_ANALYTICS -> PayUAnalytics.getInstance(
            context,
            getUrl(type),
            analyticsConfig,
            getHeaders()
        )

        AnalyticsType.PAYU_DEVICE_ANALYTICS -> PayUDeviceAnalytics.getInstance(
            context,
            getUrl(type),
            analyticsConfig,
            getHeaders()
        )
    }

    private fun getUrl(analyticsType: AnalyticsType): String {
        return if (analyticsType == AnalyticsType.CLEVERTAP) {
            analyticsConfig.urlString ?: ""

        } else {
            if (!analyticsConfig.urlString.isNullOrEmpty() && URLUtil.isValidUrl(
                    analyticsConfig.urlString
                )
            ) analyticsConfig.urlString ?: ""
            else if (analyticsConfig.isProduction) PayUAnalyticsConstant.PA_PRODUCTION_URL
            else PayUAnalyticsConstant.PA_TEST_URL
        }

    }

    private fun getHeaders(): HashMap<String, String> {
        return analyticsConfig.headers.ifEmpty { HashMap<String, String>() }
    }
}