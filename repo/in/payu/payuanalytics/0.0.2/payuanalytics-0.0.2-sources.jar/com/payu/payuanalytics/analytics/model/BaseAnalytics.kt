package com.payu.payuanalytics.analytics.model

import android.content.Context
import com.payu.payuanalytics.analytics.listener.OnEventsLogListener
import com.payu.payuanalytics.analytics.manager.AnalyticsDataManager
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant
import okhttp3.Request
import okhttp3.Response

abstract class BaseAnalytics(
    val context: Context,
    val url: String,
    val analyticsConfig: AnalyticsConfig,
    val headers: HashMap<String, String>
) : OnEventsLogListener {

    var analyticsFileName: String? = BaseAnalytics::class.java.canonicalName
    var timerDelay: Long = PayUAnalyticsConstant.PA_TIMER_DELAY
    private val analyticsDataManager = AnalyticsDataManager(context, this)

    init {
        // Propagate the debug flag to the companion so standalone utility
        // objects (EncryptionUtils, SharedPrefsUtils, etc.) also honour it.
        AnalyticsConfig.debugEnabled = analyticsConfig.isDebugEnabled
    }

    open fun getRequest(builder: Request.Builder, postData: String): Request.Builder {
        return builder
    }

    open fun log(eventData: String) {
        analyticsDataManager.log(eventData)
    }

    open fun cancelTimer() {
        analyticsDataManager.cancelTimer()
    }

    /**
     * Callback method triggered when events are logged successfully
     * */
    override fun onEventsLoggedSuccessful(response: Response) {
        analyticsDataManager.onEventsLoggedSuccessful(response)
    }

    /**
     * Callback method triggered when events couldn't be logged
     * */
    override fun onEventsLoggedFailed() {
        analyticsDataManager.onEventsLoggedFailed()
    }
}