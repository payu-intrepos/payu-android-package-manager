package com.payu.payuanalytics.analytics.utils

import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import com.payu.payuanalytics.analytics.model.AnalyticsConfig
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object EncryptionUtils {

    const val PAYU_AES_GCM_NO_PADDING: String = "AES/GCM/NoPadding"
    private const val ENCRYPTION_ALGORITHM = "AES"
    private const val KEYSTORE_PROVIDER_ANDROID_KEYSTORE: String = "AndroidKeyStore"
//    private const val mAlias: String = "PayUKeyAlias"
    const val PAYU_ENCRYPTION_KEY_GCM: String = "payu_encryption_key_gcm"

    var GCM_IV_LENGTH: Int = 12 // 12 bytes is recommended for GCM

    var GCM_TAG_LENGTH: Int = 128 // 128-bit authentication tag


//    @JvmStatic
//    fun createKeys(context: Context): SecretKey? {
//        try {
//            val kpGenerator: KeyGenerator = KeyGenerator.getInstance(
//                ENCRYPTION_ALGORITHM,
//                KEYSTORE_PROVIDER_ANDROID_KEYSTORE
//            )
//
//            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
//                val spec = KeyPairGeneratorSpec.Builder(context)
//                    .setAlias(mAlias)
//                    .build()
//                kpGenerator.init(spec)
//            }
//
//            return kpGenerator.generateKey()
//        } catch (e: Exception) {
//            if (AnalyticsConfig.debugEnabled) Log.d(
//                "TAG",
//                "createKey:Exception" + e.localizedMessage
//            )
//        }
//        return null
//    }

//    @JvmStatic
//    fun getKeys(context: Context): SecretKey? {
//        try {
//            val ks =
//                KeyStore.getInstance(KEYSTORE_PROVIDER_ANDROID_KEYSTORE)
//            // If no input stream is needed, we still need to call load()
//            ks.load(null)
//            // Load the existing key pair from the Android Key Store
//            val existingKey = ks.getEntry(
//                mAlias,
//                null
//            ) as KeyStore.SecretKeyEntry
//            return existingKey.secretKey
//        } catch (e: java.lang.Exception) {
//            if (AnalyticsConfig.debugEnabled) Log.d(
//                "TAG",
//                "getKeys:Exception" + e.localizedMessage
//            )
//            return createKeys(context)
//        }
//    }

    @JvmStatic
    fun encrypt(context: Context?, data: String): String? {
        try {
            val secretKey = getSecretKey(context)
            if (secretKey == null) {
                if (AnalyticsConfig.debugEnabled) Log.e("EncryptionUtils", "Failed to get secret key")
                return data
            }

            // Initialize cipher with AES/GCM/NoPadding
            val cipher =
                Cipher.getInstance(PAYU_AES_GCM_NO_PADDING)

            // Let the cipher generate a secure random IV
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)

            // Get the IV that was generated
            val iv = cipher.iv

            // Encrypt the data
            val encrypted = cipher.doFinal(data.toByteArray(StandardCharsets.UTF_8))

            // Combine IV + encrypted data
            val combined = ByteArray(iv.size + encrypted.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encrypted, 0, combined, iv.size, encrypted.size)

            // Encode to Base64
            return Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: java.lang.Exception) {
            if (AnalyticsConfig.debugEnabled) Log.e("EncryptionUtils", "Encryption error", e)
            return data
        }
    }

    @JvmStatic
    fun getSecretKey(context: Context?): SecretKey? {
        try {
            val keyStore =
                KeyStore.getInstance(KEYSTORE_PROVIDER_ANDROID_KEYSTORE)
            keyStore.load(null)

            // Check if key already exists
            if (keyStore.containsAlias(PAYU_ENCRYPTION_KEY_GCM)) {
                val entry = keyStore.getEntry(
                    PAYU_ENCRYPTION_KEY_GCM,
                    null
                )
                if (entry is KeyStore.SecretKeyEntry) {
                    return entry.secretKey
                }
            }

            // Generate a new key if it doesn't exist
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val keyGenerator: KeyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    KEYSTORE_PROVIDER_ANDROID_KEYSTORE
                )

                val builder = KeyGenParameterSpec.Builder(
                    PAYU_ENCRYPTION_KEY_GCM,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .setKeySize(256)

                keyGenerator.init(builder.build())
                return keyGenerator.generateKey()
            }
        } catch (e: java.lang.Exception) {
            if (AnalyticsConfig.debugEnabled) Log.e("EncryptionUtils", "Error getting secret key", e)
            return null
        }
        return null
    }

    @JvmStatic
    fun decrypt(context: Context?, encryptedData: String?): String? {
        if (encryptedData == null || encryptedData.trim { it <= ' ' }.isEmpty()) {
            if (AnalyticsConfig.debugEnabled) Log.d("EncryptionUtils", "Empty encrypted data")
            return encryptedData
        }

        if (AnalyticsConfig.debugEnabled) Log.d("EncryptionUtils", "Encrypted data: $encryptedData")

        try {
            val secretKey = getSecretKey(context)
            if (secretKey == null) {
                if (AnalyticsConfig.debugEnabled) Log.d("EncryptionUtils", "Failed to get secret key for decryption")
                return encryptedData
            }

            // Decode Base64
            val encryptedBytes = Base64.decode(encryptedData, Base64.NO_WRAP)

            // Check length: IV (12) + tag (16) + ciphertext
            if (encryptedBytes.size <= GCM_IV_LENGTH + 16) {
                if (AnalyticsConfig.debugEnabled) Log.d("EncryptionUtils", "Invalid encrypted data format: too short")
                return encryptedData
            }

            // Extract IV (first 12 bytes)
            val iv = ByteArray(GCM_IV_LENGTH)
            System.arraycopy(
                encryptedBytes,
                0,
                iv,
                0,
                GCM_IV_LENGTH
            )

            // Extract ciphertext + tag
            val encryptedSize: Int =
                encryptedBytes.size - GCM_IV_LENGTH
            val encrypted = ByteArray(encryptedSize)
            System.arraycopy(
                encryptedBytes,
                GCM_IV_LENGTH,
                encrypted,
                0,
                encryptedSize
            )

            // Init cipher for decryption
            val cipher =
                Cipher.getInstance(PAYU_AES_GCM_NO_PADDING)
            val spec = GCMParameterSpec(
                GCM_TAG_LENGTH,
                iv
            )
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            // Decrypt
            val decrypted = cipher.doFinal(encrypted)
            return String(decrypted, StandardCharsets.UTF_8)
        } catch (e: java.lang.Exception) {
            if (AnalyticsConfig.debugEnabled) Log.e("EncryptionUtils", "Decryption error: " + e.message, e)
            return encryptedData
        }
    }


}