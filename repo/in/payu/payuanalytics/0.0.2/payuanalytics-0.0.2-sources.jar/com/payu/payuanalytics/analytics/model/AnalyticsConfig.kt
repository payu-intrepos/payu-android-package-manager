package com.payu.payuanalytics.analytics.model

class AnalyticsConfig() {
    var isProduction: Boolean = true
    var ctAccountId: String? = null
    var ctPassCode: String? = null
    var initiatorIdentifier: String = "DEFAULT"
    var urlString: String? = null
    var headers: HashMap<String, String> = HashMap()

    var isDebugEnabled: Boolean = false


    companion object {
        // Read by standalone utility objects (EncryptionUtils, SharedPrefsUtils)
        // that hold no reference to a config instance. Always set via isDebugEnabled above.
        @Volatile internal var debugEnabled: Boolean = false
    }
}