package com.payu.payuanalytics.analytics.network

import android.util.Log
import com.payu.payuanalytics.analytics.listener.OnEventsLogListener
import com.payu.payuanalytics.analytics.model.BaseAnalytics
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException

class UploadTask(
    val baseAnalytics: BaseAnalytics,
    val postData: String,
    val onEventsLogListener: OnEventsLogListener
) {

    fun push() {
        val client = OkHttpClient()
        val requestBody = postData.toRequestBody("application/json".toMediaTypeOrNull())
        val requestBuilder = Request.Builder()
            .url(baseAnalytics.url)
            .post(requestBody)
        for ((key, value) in baseAnalytics.headers) {
            requestBuilder.addHeader(key, value)
        }
        val request = baseAnalytics.getRequest(requestBuilder, postData).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (baseAnalytics.analyticsConfig.isDebugEnabled) Log.d(this.javaClass.simpleName, "kibana log onFailure")
                onEventsLogListener.onEventsLoggedFailed()
            }

            override fun onResponse(call: Call, response: Response) {
                if (baseAnalytics.analyticsConfig.isDebugEnabled) Log.d(this.javaClass.simpleName, "kibana log onResponse ${response.isSuccessful}")
                onEventsLogListener.onEventsLoggedSuccessful(response)
            }

        })

    }
}