package com.payu.payuanalytics.analytics.model

import android.content.Context
import android.util.Log
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject

class PayUAnalytics private constructor(
    context: Context,
    url: String,
    analyticsConfig: AnalyticsConfig,
    headers: HashMap<String, String>
) : BaseAnalytics(context, url, analyticsConfig, headers) {

    private val TAG = PayUAnalytics::class.simpleName

    companion object {
        private var INSTANCE: PayUAnalytics? = null

        /**
         * keep only one object
         *
         * @param context  instance of base activity
         * @param url analytics url
         * @return PayUAnalytics instance.
         */
        fun getInstance(context: Context, url: String, analyticsConfig: AnalyticsConfig, headers: HashMap<String, String>): PayUAnalytics {
            if (INSTANCE == null) {
                synchronized(PayUAnalytics::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = PayUAnalytics(context, url, analyticsConfig, headers)
                    }
                }
            }
            return INSTANCE!!
        }
    }

    init {
        analyticsFileName = PayUAnalytics::class.java.canonicalName
    }

    override fun getRequest(builder: Request.Builder, postData: String): Request.Builder {
        val finalPostData = PayUAnalyticsConstant.PA_COMMAND_EVENT_ANALYTICS_PARAM + postData
        builder.post(finalPostData.toRequestBody(PayUAnalyticsConstant.PA_CONTENT_TYPE_FORM_URL_ENCODED.toMediaTypeOrNull()))
        return builder
    }

    override fun onEventsLoggedSuccessful(response: Response) {
        if (response.code == 200) {
            super.onEventsLoggedSuccessful(
                response
            )
        } else {
            if (analyticsConfig.isDebugEnabled) Log.d(TAG, "json Object doesn't have " + PayUAnalyticsConstant.PA_STATUS)
            super.onEventsLoggedFailed(
            )
        }

    }
}