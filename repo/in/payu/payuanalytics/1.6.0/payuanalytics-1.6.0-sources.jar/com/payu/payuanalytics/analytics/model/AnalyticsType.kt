package com.payu.payuanalytics.analytics.model

enum class AnalyticsType {
    CLEVERTAP,
    PAYU_ANALYTICS,
    PAYU_DEVICE_ANALYTICS
}