package com.payu.payuanalytics.analytics.utils

import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.util.*
import javax.crypto.*
import javax.crypto.spec.GCMParameterSpec
import javax.security.auth.x500.X500Principal

object KeystoreCryptoUtil {

    private const val AES_ALIAS = "CompatAesKey"
    private const val RSA_ALIAS = "CompatRsaKey"
    private const val PREFS_NAME = "crypto_prefs"
    private const val PREF_AES_WRAPPED = "wrapped_aes"
    private const val PREF_DATA = "encrypted_data"

    private val keyStore: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    // --- Key Management ---

    private fun generateAesKey() {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            AES_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        keyGenerator.generateKey()
    }

    private fun getAesKey(): SecretKey {
        if (!keyStore.containsAlias(AES_ALIAS)) {
            generateAesKey()
        }
        return keyStore.getKey(AES_ALIAS, null) as SecretKey
    }

    private fun generateRsaKeyPair(context: Context) {
        if (!keyStore.containsAlias(RSA_ALIAS)) {
            val start = Calendar.getInstance()
            val end = Calendar.getInstance().apply { add(Calendar.YEAR, 25) }

            val spec = KeyPairGeneratorSpec.Builder(context)
                .setAlias(RSA_ALIAS)
                .setSubject(X500Principal("CN=$RSA_ALIAS"))
                .setSerialNumber(BigInteger.ONE)
                .setStartDate(start.time)
                .setEndDate(end.time)
                .build()

            val kpg = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore")
            kpg.initialize(spec)
            kpg.generateKeyPair()
        }
    }

    private fun wrapAesKey(secretKey: SecretKey): ByteArray {
        val publicKey = keyStore.getCertificate(RSA_ALIAS).publicKey

        // Prefer OAEP if available
        val transformation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
        } else {
            "RSA/ECB/PKCS1Padding"
        }

        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.WRAP_MODE, publicKey)
        return cipher.wrap(secretKey)
    }

    private fun unwrapAesKey(wrappedKey: ByteArray): SecretKey {
        val privateKey = keyStore.getKey(RSA_ALIAS, null)

        val transformation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
        } else {
            "RSA/ECB/PKCS1Padding"
        }

        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.UNWRAP_MODE, privateKey)
        return cipher.unwrap(wrappedKey, "AES", Cipher.SECRET_KEY) as SecretKey
    }

    private fun getOrCreateSecretKey(context: Context): SecretKey {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getAesKey()
        } else {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wrappedBase64 = prefs.getString(PREF_AES_WRAPPED, null)

            if (wrappedBase64 != null) {
                val wrappedKey = android.util.Base64.decode(wrappedBase64, android.util.Base64.DEFAULT)
                unwrapAesKey(wrappedKey)
            } else {
                generateRsaKeyPair(context)
                val newAesKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
                val wrappedKey = wrapAesKey(newAesKey)
                prefs.edit().putString(
                    PREF_AES_WRAPPED,
                    android.util.Base64.encodeToString(wrappedKey, android.util.Base64.DEFAULT)
                ).apply()
                newAesKey
            }
        }
    }

    // --- Encrypt / Decrypt ---

    @JvmStatic
    fun encryptToPrefs(context: Context, plainText: String): String {
        val secretKey = getOrCreateSecretKey(context)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)

        val iv = cipher.iv
        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        // Store as Base64(iv:ciphertext)
        val ivB64 = android.util.Base64.encodeToString(iv, android.util.Base64.NO_WRAP)
        val ctB64 = android.util.Base64.encodeToString(cipherText, android.util.Base64.NO_WRAP)
        val combined = "$ivB64:$ctB64"
        return combined
    }

    @JvmStatic
    fun decryptFromPrefs(context: Context, data: String): String? {

        val parts = data.split(":")
        if (parts.size != 2) return null

        val iv = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP)
        val cipherText = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP)

        val secretKey = getOrCreateSecretKey(context)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

        val plainBytes = cipher.doFinal(cipherText)
        return String(plainBytes, Charsets.UTF_8)
    }
}

