// The MIT License (MIT)
//
// Copyright (c) 2014-2015 PayU India
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
package com.payu.payuanalytics.analytics.utils

/**
 * Constants for analytics.
 */
object PayUAnalyticsConstant {

    //Analytics urls
    const val PA_TEST_URL = "https://mobiletest.payu.in/merchant/MobileAnalytics"
    const val PA_PRODUCTION_URL = "https://info.payu.in/merchant/MobileAnalytics"
    const val PA_CLEVERTAP_URL = "https://in.api.clevertap.com/1/upload"

    // analytics buffer file - shared preference key
    const val PA_ANALYTICS_BUFFER_KEY = "analytics_buffer_key"
    const val PA_DEFAULT_ANALYTICS_FILE_NAME = "com.payu.payuanalytics.DefaultAnalyticsFile"
    const val PA_COMMAND_EVENT_ANALYTICS_PARAM = "command=EventAnalytics&data="
    const val PA_COMMAND_DEVICE_ANALYTICS_PARAM = "command=DeviceAnalytics&data="
    const val PA_CT_DATA_PARAM = "d"
    const val PA_STATUS: String = "status"
    const val PA_TIMER_DELAY: Long = 5000
    const val PA_TXN_ID = "txnid"
    const val PA_PAYU_MERCHANT_TRANSACTION_ID = "payu_merchant_txnid"
    const val PA_CT_ACCOUNT_ID = "X-CleverTap-Account-Id"
    const val PA_CT_PASSCODE = "X-CleverTap-Passcode"
    const val PA_CONTENT_TYPE_JSON = "application/json"
    const val PA_CONTENT_TYPE_FORM_URL_ENCODED = "application/x-www-form-urlencoded"
}