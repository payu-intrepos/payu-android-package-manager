package com.payu.payuanalytics.analytics.model

import android.content.Context
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsUtil
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONException
import org.json.JSONObject

class PayUDeviceAnalytics private constructor(
    context: Context,
    url: String,
    analyticsConfig: AnalyticsConfig,
    headers: HashMap<String, String>
) : BaseAnalytics(context, url, analyticsConfig, headers) {

    companion object {
        private var INSTANCE: PayUDeviceAnalytics? = null

        /**
         * keep only one object
         *
         * @param context  instance of base activity
         * @param url analytics url
         * @return PayUDeviceAnalytics instance
         */
        fun getInstance(
            context: Context,
            url: String,
            analyticsConfig: AnalyticsConfig,
            headers: HashMap<String, String>
        ): PayUDeviceAnalytics {
            if (INSTANCE == null) {
                synchronized(PayUDeviceAnalytics::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = PayUDeviceAnalytics(context, url, analyticsConfig, headers)
                    }
                }
            }
            return INSTANCE!!
        }
    }

    init {
        analyticsFileName = PayUDeviceAnalytics::class.java.canonicalName
    }

    override fun getRequest(builder: Request.Builder, postData: String): Request.Builder {
        val finalPostData = PayUAnalyticsConstant.PA_COMMAND_DEVICE_ANALYTICS_PARAM + postData
        builder.post(finalPostData.toRequestBody(PayUAnalyticsConstant.PA_CONTENT_TYPE_FORM_URL_ENCODED.toMediaTypeOrNull()))
        return builder
    }

    override fun log(data: String) {
        if (shouldLog(context, data)) {
            PayUAnalyticsUtil.setStringSharedPreference(
                context,
                PayUAnalyticsConstant.PA_ANALYTICS_BUFFER_KEY,
                PayUAnalyticsConstant.PA_PAYU_MERCHANT_TRANSACTION_ID,
                getTxnIdFromJson(data)
            )
            super.log(data)
        }
    }

    override fun onEventsLoggedSuccessful(response: Response) {
        response.body?.let {
            val jsonObject = JSONObject(it.string())
            if (jsonObject.has(PayUAnalyticsConstant.PA_STATUS)) super.onEventsLoggedSuccessful(
                response
            )
        }
    }

    private fun getTxnIdFromJson(msg: String?): String {
        var txnId = ""
        try {
            val jsonObject = JSONObject(msg!!)
            txnId = jsonObject.getString(PayUAnalyticsConstant.PA_TXN_ID)

        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return txnId
    }

    private fun shouldLog(context: Context, msg: String?): Boolean {
        try {
            val txnId = getTxnIdFromJson(msg)
            if (PayUAnalyticsUtil.getStringSharedPreference(
                    context,
                    PayUAnalyticsConstant.PA_ANALYTICS_BUFFER_KEY,
                    PayUAnalyticsConstant.PA_PAYU_MERCHANT_TRANSACTION_ID
                ) != txnId
            ) {
                return true
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return false
    }
}