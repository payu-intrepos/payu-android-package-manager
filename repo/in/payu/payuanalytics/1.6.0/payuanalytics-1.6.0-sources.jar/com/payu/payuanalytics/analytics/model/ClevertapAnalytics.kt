package com.payu.payuanalytics.analytics.model

import android.content.Context
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class ClevertapAnalytics private constructor(
    context: Context,
    url: String,
    analyticsConfig: AnalyticsConfig,
    headers: HashMap<String, String>
) : BaseAnalytics(context, url, analyticsConfig, headers) {

    companion object {
        private var INSTANCE: ClevertapAnalytics? = null

        /**
         * keep only one object
         *
         * @param context  instance of base activity
         * @param url analytics url
         * @param analyticsConfig analytics configuration
         * @return ClevertapAnalytics instance.
         */
        fun getInstance(
            context: Context,
            url: String,
            analyticsConfig: AnalyticsConfig,
            headers: HashMap<String, String>
        ): ClevertapAnalytics {
            if (INSTANCE == null) {
                synchronized(ClevertapAnalytics::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = ClevertapAnalytics(context, url, analyticsConfig, headers)
                    }
                }
            }
            return INSTANCE!!
        }
    }

    init {
        analyticsFileName = ClevertapAnalytics::class.java.canonicalName
    }

    override fun getRequest(builder: Request.Builder, postData: String): Request.Builder {
        builder.addHeader(PayUAnalyticsConstant.PA_CT_ACCOUNT_ID, analyticsConfig.ctAccountId!!)
        builder.addHeader(PayUAnalyticsConstant.PA_CT_PASSCODE, analyticsConfig.ctPassCode!!)

        val finalJsonObject = JSONObject()
        try {
            finalJsonObject.put(PayUAnalyticsConstant.PA_CT_DATA_PARAM, JSONArray(postData))
        } catch (e: JSONException) {
        }

        builder.post(
            finalJsonObject.toString()
                .toRequestBody(PayUAnalyticsConstant.PA_CONTENT_TYPE_JSON.toMediaTypeOrNull())
        )
        return builder
    }
}