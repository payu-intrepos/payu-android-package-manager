package com.payu.payuanalytics.analytics.listener

import okhttp3.Response

interface OnEventsLogListener {
    fun onEventsLoggedSuccessful(response: Response)
    fun onEventsLoggedFailed()
}