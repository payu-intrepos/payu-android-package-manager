package com.payu.payuanalytics.analytics.manager

import android.content.Context
import android.util.Log
import com.payu.payuanalytics.analytics.model.BaseAnalytics
import com.payu.payuanalytics.analytics.network.UploadTask
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsConstant.PA_ANALYTICS_BUFFER_KEY
import com.payu.payuanalytics.analytics.utils.PayUAnalyticsUtil
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import java.util.concurrent.Executors

class AnalyticsDataManager constructor(
    context: Context,
    val baseAnalytics: BaseAnalytics
) {
    private val TAG = AnalyticsDataManager::class.simpleName
    private val mcontext: Context?
    private val fileName: String
    private val sharedPrefKey: String

    @Volatile
    private var mainFileLocked = false
    private var mTimer: Timer? = null

    // Lock for buffer file(shared preference)
    @Volatile
    private var mBufferLock = false

    private var isTimerCancelled = false

    /**
     * set lock on main file
     */
    @Synchronized
    private fun setLock() {
        while (mainFileLocked);
        mainFileLocked = true
    }

    /**
     * release lock on main file
     */
    private fun releaseLock() {
        mainFileLocked = false
    }

    /**
     * Adding log information to a local file.
     *
     * @param msg json string
     */
    fun log(msg: String) {
        // check if main file is lock
        if (mainFileLocked) {
            //store in buffer, if main file is in use
            storeInBuffer(msg)
        } else {
            // read main file add new analytics event to it
            val runnable = Runnable { //wait till main file is in use
                while (mainFileLocked);
                setLock()
                try {
                    val newobject = JSONObject(msg)
                    val jsonArray: JSONArray
                    val temp = readFileInputStream(mcontext, fileName, Context.MODE_PRIVATE)
                    jsonArray = if (temp.equals(
                            "",
                            ignoreCase = true
                        )
                    ) JSONArray() else JSONArray(temp)
                    val fileOutputStream = mcontext?.openFileOutput(fileName, Context.MODE_PRIVATE)
                    jsonArray.put(jsonArray.length(), newobject)
                    fileOutputStream?.write(jsonArray.toString().toByteArray())
                    fileOutputStream?.close()
                } catch (e: IOException) {
                    Log.d(this.javaClass.simpleName,"log:IOException"+e.localizedMessage)
                    storeInBuffer(msg)
                } catch (e: JSONException) {
                    Log.d(this.javaClass.simpleName,"log:JSONException"+e.localizedMessage)
                } catch (e: Exception) {
                    Log.d(this.javaClass.simpleName,"log:Exception"+e.localizedMessage)
                } finally {
                    releaseLock()
                    resetTimer()
                }
            }
            val executor = Executors.newSingleThreadExecutor()
            executor.submit(runnable)
        }
    }

    /**
     * Add log information to buffer
     *
     * @param msg json string
     */
    private fun storeInBuffer(msg: String) {
        Thread {
            synchronized(this) {
                try {
                    Log.d(this.javaClass.simpleName, "if locked - $msg")
                    // wait till buffer file is in use
                    while (mBufferLock);
                    mBufferLock = true
                    //read events from buffer file
                    val str: String? = PayUAnalyticsUtil.getStringSharedPreference(
                        mcontext,
                        fileName,
                        sharedPrefKey
                    )
                    val jsonArray: JSONArray
                    jsonArray = if (str != null && !str.equals("", ignoreCase = true)) {
                        JSONArray(str)
                    } else {
                        JSONArray()
                    }
                    val newAnalyticsEvent = JSONObject(msg)

                    // add new analytics event to buffer file
                    jsonArray.put(newAnalyticsEvent)
                    Log.d(this.javaClass.simpleName, "saving in buffer - $jsonArray")
                    PayUAnalyticsUtil.setStringSharedPreference(
                        mcontext,
                        fileName,
                        sharedPrefKey,
                        jsonArray.toString()
                    )
                } catch (e: Exception) {
                    Log.d(this.javaClass.simpleName,"storeinbuffer:Exception"+e.localizedMessage)

                } finally {
                    mBufferLock = false
                }
            }
        }.start()
    }

    /**
     * Manages timer and sends the information to server
     */
    /**
     * Manages timer and sends the information to server
     */
    private fun resetTimer() {
        cancelTimer()
        mTimer = Timer()
        isTimerCancelled = false
        try {
        mTimer?.schedule(object : TimerTask() {
            override fun run() {
                sendEventsToAnalyticsPortal()
            }
        }, baseAnalytics.timerDelay)
        } catch (e: Exception) {
            Log.d(TAG, e.message.toString())
    }

    }
    /**
     * Cancel timer
     * */
     fun cancelTimer() {
        if (mTimer != null && !isTimerCancelled) {
            mTimer?.cancel()
            mTimer?.purge()
            isTimerCancelled = true
        }
    }

    /**
     * This will send events to Analytics portal
     */
    private fun sendEventsToAnalyticsPortal() {
        Log.d(this.javaClass.simpleName, "send events")
        //wait till main file is in use
        while (mainFileLocked);
        setLock()
        if (PayUAnalyticsUtil.checkNetwork(mcontext) && mcontext != null) {
            var temp = ""
            try {
                temp = readFileInputStream(mcontext, fileName, Context.MODE_PRIVATE)
            } finally {
                // temp is a json array.
                // mBuffer is a json array again.
                try {
                    // file data converted to json array
                    var tempJsonArray: JSONArray
                    if (temp != null && !temp.equals("", ignoreCase = true)) {
                        tempJsonArray = JSONArray(temp)
                    } else {
                        tempJsonArray = JSONArray()
                    }

                    // Copy buffer file data in file
                    if ((PayUAnalyticsUtil.getStringSharedPreference(
                            mcontext,
                            fileName,
                            sharedPrefKey
                        )?.length ?: 0) > 1
                    ) {
                        // lock buffer file
                        mBufferLock = true
                        val analyticsBufferArray: JSONArray = JSONArray(
                            PayUAnalyticsUtil.getStringSharedPreference(
                                mcontext,
                                fileName,
                                sharedPrefKey
                            ) ?: ""
                        )
                        tempJsonArray = copyBufferToFile(tempJsonArray, analyticsBufferArray)
                    }

                    // upload main file events to server
                    if (tempJsonArray.length() > 0) {
                        Log.d(this.javaClass.simpleName, "uploading - $tempJsonArray")
                        UploadTask(baseAnalytics, tempJsonArray.toString(), baseAnalytics).push()
                    } else {
                        Log.d(this.javaClass.simpleName, "cancel timer")
                        if (mTimer != null) {
                            mTimer?.cancel()
                        }
                        releaseLock()
                    }
                } catch (e: Exception) {
                    Log.d(this.javaClass.simpleName,"sendEventsToAnalyticsPortal:Exception"+e.localizedMessage)
                    releaseFileLockAndResetTimer()
                }
            }
        } else releaseLock()

    }

    /**
     * This will push all pending events to analytics portal
     */
    fun pushAllPendingEvents() {
        val runnable = Runnable { sendEventsToAnalyticsPortal() }
        val executor = Executors.newSingleThreadExecutor()
        executor.submit(runnable)
    }

    /**
     * Releases file lock and resets the timer
     */
    private fun releaseFileLockAndResetTimer() {
        // release lock on main file
        releaseLock()

        // reset timer if buffer has some events to log
        if ((PayUAnalyticsUtil.getStringSharedPreference(mcontext, fileName, sharedPrefKey)
                ?.length ?: 0) > 1
        ) {
            resetTimer()
        }
    }

    /**
     * Read input stream from given file
     * base activity context
     *
     * @param fileName    file name
     * @param contextMode define access to file
     * @return data read from file
     */
    fun readFileInputStream(
        mContext: Context?,
        fileName: String,
        contextMode: Int
    ): String { //how to handle first parameter as it can be both context or activity
        var c: Int
        var temp = ""
        try {
            val file = File(mContext?.filesDir, fileName)
            if (!file.exists()) { // create the file if not created yet.
                mContext?.openFileOutput(fileName, contextMode)
            }
            val fileInputStream = mContext?.openFileInput(fileName)
            fileInputStream?.let {
                while (fileInputStream.read().also { c = it } != -1) {
                    temp += c.toChar().toString()
                }
                fileInputStream.close()
            }
        } catch (e: FileNotFoundException) {
            Log.d(this.javaClass.simpleName,"readFileInputStream:FileNotFoundException"+e.localizedMessage)
        } catch (e: IOException) {
            Log.d(this.javaClass.simpleName,"readFileInputStream:IOException"+e.localizedMessage)
        } catch (e: Exception) {
            Log.d(this.javaClass.simpleName,"readFileInputStream:Exception"+e.localizedMessage)
        }
        return temp
    }

    /**
     * Copy buffer analytics file to main analytics file
     *
     * @param fileJsonArray   main analytics file events
     * @param bufferJsonArray buffer analytics file events
     * @return fileJsonArray + bufferJsonArray(if buffer file data is successfully) else return fileJsonArray
     */
    private fun copyBufferToFile(fileJsonArray: JSONArray, bufferJsonArray: JSONArray): JSONArray {
        var fileOutputStream: FileOutputStream? = null
        return try {

            // combining both main file json array and buffer array
            val mergeJsonArray = JSONArray(fileJsonArray.toString())
            for (i in 0 until bufferJsonArray.length()) {
                val jsonObject = bufferJsonArray.getJSONObject(i)
                mergeJsonArray.put(jsonObject)
            }
            fileOutputStream = mcontext?.openFileOutput(fileName, Context.MODE_PRIVATE)
            fileOutputStream?.let {
                fileOutputStream.write(mergeJsonArray.toString().toByteArray())
                if (mcontext != null) {
                    PayUAnalyticsUtil.deleteSharedPrefKey(mcontext, fileName, sharedPrefKey)
                }
            }
            mergeJsonArray
        } catch (e: Exception) {
            Log.d(this.javaClass.simpleName,"copyBufferToFile:Exception"+e.localizedMessage)
            // return main file array if not able to merge main and buffer file
            fileJsonArray
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close()
                } catch (e: IOException) {
                    Log.d(this.javaClass.simpleName,"copyBufferToFile:IOException"+e.localizedMessage)

                }
            }
            //release lock on buffer file
            mBufferLock = false
        }
    }

    /**
     * Constructor
     *
     * @param context  instance of base activity
     * @param filename name of file for analytics event
     */
    init {
        mcontext = context
        fileName =
            baseAnalytics.analyticsFileName.plus(baseAnalytics.analyticsConfig.initiatorIdentifier)
        sharedPrefKey = PA_ANALYTICS_BUFFER_KEY.plus(baseAnalytics.analyticsConfig.initiatorIdentifier)
        val defaultUEH = Thread.getDefaultUncaughtExceptionHandler()
        val uncaughtExceptionHandler = Thread.UncaughtExceptionHandler { thread, ex ->
            while (mainFileLocked);
            setLock()
            try {
                val fileOutputStream = mcontext.openFileOutput(fileName, Context.MODE_PRIVATE)
                val c: Int = (PayUAnalyticsUtil.getStringSharedPreference(
                    mcontext,
                    fileName,
                    sharedPrefKey
                )?.length ?: 0)
                if (c > 0) {
                    val jsonArray = JSONArray()
                    val bufferJsonArray: JSONArray = JSONArray(
                        PayUAnalyticsUtil.getStringSharedPreference(
                            mcontext,
                            fileName,
                            sharedPrefKey
                        ).toString()
                    )
                    for (i in 0 until bufferJsonArray.length()) {
                        val jsonObject = bufferJsonArray.getJSONObject(i)
                        jsonArray.put(jsonArray.length(), jsonObject)
                    }
                    fileOutputStream.write(jsonArray.toString().toByteArray())
                    PayUAnalyticsUtil.deleteSharedPrefKey(
                        context,
                        fileName,
                        sharedPrefKey
                    )
                }
                fileOutputStream.close()
            } catch (e: IOException) {
                Log.d(this.javaClass.simpleName,"init:IOException"+e.localizedMessage)
            } catch (e: Exception) {
                Log.d(this.javaClass.simpleName,"init:Exception"+e.localizedMessage)
            }
            releaseLock()
            defaultUEH.uncaughtException(thread, ex)
        }
        Thread.setDefaultUncaughtExceptionHandler(uncaughtExceptionHandler)
    }

    fun onEventsLoggedSuccessful(response: Response) {
        // if we are able to post the data to server then delete file
        mcontext?.deleteFile(fileName)
        releaseFileLockAndResetTimer()
    }

    fun onEventsLoggedFailed() {
        //events didn't processed, try to send events in next batch
        releaseFileLockAndResetTimer()
    }
}