package com.payu.payuanalytics.analytics.utils

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.lang.reflect.Array

object JsonUtils {
    /**
     * This method coverts a map to JSONObject
     *
     * @param data map to be converted
     * @return converted JSONObject
     */
    fun mapToJson(data: Map<*, *>): JSONObject {
        val `object` = JSONObject()
        for ((key1, value) in data) {
            /*
             * Deviate from the original by checking that keys are non-null and
             * of the proper type. (We still defer validating the values).
             */
            val key = key1 as String? ?: throw NullPointerException("key == null")
            try {
                `object`.put(key, wrap(value))
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }
        return `object`
    }

    /**
     * This method converts collection passed as argument to JSONArray
     *
     * @param data collection to be converted
     * @return JSONArray of data
     */
    fun collectionToJson(data: Collection<*>?): JSONArray {
        val jsonArray = JSONArray()
        if (data != null) {
            for (aData in data) {
                jsonArray.put(wrap(aData))
            }
        }
        return jsonArray
    }

    /**
     * This method converts array passed as argument to JSONArray
     *
     * @param data collection to be converted
     * @return JSONArray of data
     */
    @Throws(JSONException::class)
    fun arrayToJson(data: Any): JSONArray {
        if (!data.javaClass.isArray) {
            throw JSONException("Not a primitive data: " + data.javaClass)
        }
        val length = Array.getLength(data)
        val jsonArray = JSONArray()
        for (i in 0 until length) {
            jsonArray.put(wrap(Array.get(data, i)))
        }
        return jsonArray
    }

    /**
     * This method checks if the object passed is a JSONArray or JSONObject, if yes it returns the same
     * else convert the object to JSON format.
     *
     * @param o object to check
     * @return Object converted to JSON form
     */
    private fun wrap(o: Any?): Any? {
        if (o == null) {
            return null
        }
        if (o is JSONArray || o is JSONObject) {
            return o
        }
        try {
            if (o is Collection<*>) {
                return collectionToJson(o as Collection<*>?)
            } else if (o.javaClass.isArray) {
                return arrayToJson(o)
            }
            if (o is Map<*, *>) {
                return mapToJson(o)
            }
            if (o is Boolean ||
                o is Byte ||
                o is Char ||
                o is Double ||
                o is Float ||
                o is Int ||
                o is Long ||
                o is Short ||
                o is String
            ) {
                return o
            }
            if ((o.javaClass.getPackage() != null) && (o.javaClass.getPackage()!!.name.startsWith("java."))) {
                return o.toString()
            }
        } catch (ignored: Exception) {
        }
        return null
    }
}