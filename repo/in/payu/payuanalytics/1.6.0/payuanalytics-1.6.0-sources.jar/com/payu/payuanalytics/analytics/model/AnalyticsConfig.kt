package com.payu.payuanalytics.analytics.model

class AnalyticsConfig() {
    var isProduction: Boolean = true
    var ctAccountId: String? = null
    var ctPassCode: String? = null
    var initiatorIdentifier: String = "DEFAULT"
    var urlString: String? = null
    var headers: HashMap<String, String> = HashMap()
}