package com.payu.threedsbase.data.apiResponse

class PArsResponse {
    var cavv: String? = null
    var eci: String? = null
    var threeDSTransID: String? = null
    var threeDSVersion: String? = null
    var threeDSServerTransID: String? = null
    var threeDSTransStatus: String? = null
    var acsSignedContent: String? = null
    var acsReferenceNumber: String? = null
    var acsTransID: String? = null
    var threeDSTransStatusReason: String? = null
    var payU3DS2MfaParam: PayU3DS2MFAParam? = null
}