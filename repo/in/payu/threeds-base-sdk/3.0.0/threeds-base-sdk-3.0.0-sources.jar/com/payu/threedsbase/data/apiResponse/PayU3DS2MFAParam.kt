package com.payu.threedsbase.data.apiResponse

import com.payu.threedsbase.Utils.masked

class PayU3DS2MFAParam {
    var messageType: String? = null
    var name: String? = null
    var id: String? = null
    var criticalityIndicator: Boolean = false
    var status: String? = null
    var issuerImage: String? = null
    var psImage: String? = null
    var tdyClientId: String? = null
    var tdyCardId: String? = null
    var data: String? = null

    override fun toString(): String {
        return "PayU3DS2MFAParam(messageType=$messageType, name=$name, id=$id, criticalityIndicator=$criticalityIndicator, status=$status, issuerImage=$issuerImage, psImage=$psImage, tdyClientId=$tdyClientId, tdyCardId=$tdyCardId, data=${data?.masked()})"
    }
}

