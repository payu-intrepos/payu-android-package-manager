package com.payu.threedsbase.data

data class ACSActionParams(
    var acsTransactionID: String?,
    var acsRenderingType: String?,
    var challengeData: String? = null
)