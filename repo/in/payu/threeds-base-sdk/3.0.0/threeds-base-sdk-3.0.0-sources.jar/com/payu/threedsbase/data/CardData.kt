package com.payu.threedsbase.data

import com.payu.threedsbase.enums.CardScheme

data class CardData(var cardScheme: CardScheme?, var threeDSVersion: String?)