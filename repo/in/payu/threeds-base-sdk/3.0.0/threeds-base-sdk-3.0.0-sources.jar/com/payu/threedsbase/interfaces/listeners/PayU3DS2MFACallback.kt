package com.payu.threedsbase.interfaces.listeners

interface PayU3DS2MFACallback : PayU3DS2BaseCallback {
    fun mfaRegistrationStatus(response: Any?)
}
