package com.payu.threedsbase.data

import com.payu.threedsbase.enums.DeviceSeverity

data class PayU3DS2DeviceWarning(
    val id: String?,
    val message: String?,
    val severity: DeviceSeverity?
)