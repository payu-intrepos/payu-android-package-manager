package com.payu.threedsbase.data

class ErrorResponse {
    var errorCode: Int? = null
    var errorMessage: String? = null
}