package com.payu.threedsbase.Utils


fun String.masked(): String {
    if (length <= 8) return this
    return "${take(4)}***${takeLast(4)}"
}
