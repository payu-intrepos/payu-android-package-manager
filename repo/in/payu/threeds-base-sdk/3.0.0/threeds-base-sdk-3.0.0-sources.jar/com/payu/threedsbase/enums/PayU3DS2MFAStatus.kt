package com.payu.threedsbase.enums

enum class PayU3DS2MFAStatus {
    INITIATED,
    SUCCESS,
    FAILED
}
