package com.payu.threedsbase.data

import com.payu.threedsbase.Utils.masked

data class PArqResponse(
    val sdkAppID: String,
    val sdkEncData: String,
    val crv: String,
    val kty: String,
    val x: String,
    val y: String,
    val sdkTransID: String,
    val sdkReferenceNumber: String,
    val mfaVersion: String

) {
    override fun toString(): String {
        return "PArqResponse(sdkAppID='$sdkAppID', sdkEncData='${sdkEncData.masked()}', crv='$crv', kty='$kty', x='${x.masked()}', y='${y.masked()}', sdkTransID='$sdkTransID', sdkReferenceNumber='$sdkReferenceNumber', mfaVersion='$mfaVersion')"
    }
}