package com.payu.threedsbase.interfaces.listeners

interface FallbackPostDataListener {
    fun onFallbackPostDataGenerated(fallbackPostData: String?)
}