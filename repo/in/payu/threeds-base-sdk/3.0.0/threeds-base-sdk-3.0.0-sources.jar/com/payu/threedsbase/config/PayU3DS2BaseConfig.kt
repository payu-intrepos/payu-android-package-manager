package com.payu.threedsbase.config

open class PayU3DS2BaseConfig {
    var isProduction: Boolean = true
    var merchantResponseTimeout: Long = 15000
}
