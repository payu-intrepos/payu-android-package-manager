package com.payu.threedsbase.data.apiResponse

class BinInfoResponse {
    var issuingBank: String? = null
    var bin: String? = null
    var category: String? = null
    var cardType: String? = null
    var isDomestic: String? = null
    var isAtmPinCard: String? = null
    var isSiSupported: Int? = null
    var isOtpOnTheFly: Int? = null
    var messageVersion: String? = null
    var oobEligible: Boolean = false

    override fun toString(): String {
        return "BinInfoResponse(issuingBank=$issuingBank, bin=$bin, category=$category, cardType=$cardType, isDomestic=$isDomestic, isAtmPinCard=$isAtmPinCard, isSiSupported=$isSiSupported, isOtpOnTheFly=$isOtpOnTheFly, messageVersion=$messageVersion, oobEligible=$oobEligible)"
    }
}
