package com.payu.threedsbase.data

data class PayU3DS2Response(val status: Int, val errorMessage: String?, val result: Any?)
