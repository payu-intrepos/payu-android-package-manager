package com.payu.threedsbase.enums


enum class PayU3DS2MFARequestType {
    REGISTRATION,
    DEREGISTRATION
}