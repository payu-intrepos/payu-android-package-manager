package com.payu.threedsbase.data

data class ImageDetails(
    val mediumQualityURL: String?,
    val highQualityURL: String?,
    val extraHighQualityURL: String?
)