package com.payu.threedsbase.enums

enum class APICommand {
    BinInfo,
    InitiatePayment,
    AuthorizePayment,
    ChallengeFlow,
    AuthenticatePayment
}