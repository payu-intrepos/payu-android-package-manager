package com.payu.threedsbase.interfaces.listeners

interface PayU3DS2BaseCallback : PayU3DS2StatusUpdateCallback{
    fun onSuccess(response: Any)
    fun onError(errorCode: Int, errorMessage: String)
}