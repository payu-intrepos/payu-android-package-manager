package com.payu.threedsbase.data.apiRequest

data class CardBinInfoRequest(
    val cardDetails: String,
    val isSI: Boolean
) {
    override fun toString(): String {
        return "CardBinInfoRequest(cardDetails='$cardDetails', isSI=$isSI)"
    }
}