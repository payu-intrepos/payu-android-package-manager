package com.payu.threedsbase.enums

enum class PayUCurrency(val value: String) {
    INR("₹");

    fun getCurrency(): String {
        return value
    }
}