package com.payu.threedsbase.data

import com.payu.threedsbase.enums.ACSActionType

data class PayU3DS2ACSResponse(
    val message: String?,
    val acsActionType: ACSActionType,
    val headlessData: HeadlessData?
)