package com.payu.threedsbase.enums

enum class TransactionFlowType(val value: String) {
    Challenge("C"),
    Frictionless("Y");
}