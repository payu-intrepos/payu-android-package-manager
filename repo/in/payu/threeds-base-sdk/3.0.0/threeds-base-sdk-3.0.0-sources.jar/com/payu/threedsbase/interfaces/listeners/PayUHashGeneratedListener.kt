package com.payu.threedsbase.interfaces.listeners

interface PayUHashGeneratedListener {
    fun onHashGenerated(map: HashMap<String,String>)
}