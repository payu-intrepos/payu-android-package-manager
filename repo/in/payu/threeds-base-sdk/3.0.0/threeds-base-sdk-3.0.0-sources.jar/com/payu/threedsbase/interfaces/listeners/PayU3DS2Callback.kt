package com.payu.threedsbase.interfaces.listeners

interface PayU3DS2Callback : PayU3DS2BaseCallback {
    fun generateHash(
        map: HashMap<String, String>,
        hashGenerationListener: PayUHashGeneratedListener
    )
}