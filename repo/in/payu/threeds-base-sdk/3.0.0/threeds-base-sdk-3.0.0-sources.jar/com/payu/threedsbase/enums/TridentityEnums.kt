package com.payu.threedsbase.enums


enum class AuthType {
    BIOMETRIC, OTP, USER_CANCELLED
}

enum class TridentityFlow {
    /**
     *  Represents the registration flow.
     */
    REGISTRATION,
    /**
     * Represents the transaction flow.
     */
    TRANSACTION,
    /**
     * Represents a flow initiated out-of-band (OOB).
     */
    OOB_INITIATED,

    /**
     *  Represents the de-registration flow.
     */
    DEREGISTRATION
}