package com.payu.threedsbase.enums

enum class PayU3DSDeregisterType {
    AUTO,
    MANUAL
}
