package com.payu.threedsbase.enums

enum class CardScheme {
    VISA,
    MASTERCARD
}