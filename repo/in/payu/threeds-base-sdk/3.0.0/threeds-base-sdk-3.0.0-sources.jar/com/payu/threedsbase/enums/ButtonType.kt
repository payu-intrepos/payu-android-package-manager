package com.payu.threedsbase.enums

enum class ButtonType {
    VERIFY,
    NEXT,
    CANCEL,
    RESEND,
    CONTINUE
}