package com.payu.threedsbase.enums

enum class DeviceSeverity {
    LOW,
    MEDIUM,
    HIGH
}