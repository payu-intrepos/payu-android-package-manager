package com.payu.threedsbase.data

import com.payu.threedsbase.Utils.masked
import com.payu.threedsbase.data.apiResponse.PayU3DS2MFAParam

data class ChallengeParameter(
    val acsSignedContent: String,
    val acsRefNumber: String,
    val acsTransactionID: String,
    val threeDSServerTransactionID: String,
    val payU3DS2MfaParam: PayU3DS2MFAParam? = null


) {
    override fun toString(): String {
        return "ChallengeParameter(acsSignedContent='${acsSignedContent.masked()}', acsRefNumber='$acsRefNumber', acsTransactionID='$acsTransactionID', threeDSServerTransactionID='$threeDSServerTransactionID', payU3DS2MfaParam=$payU3DS2MfaParam)"
    }
}