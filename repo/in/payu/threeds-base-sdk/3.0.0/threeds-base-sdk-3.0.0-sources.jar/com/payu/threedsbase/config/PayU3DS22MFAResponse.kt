package com.payu.threedsbase.config

import com.payu.threedsbase.constants.APIConstants.Companion.MFA_RESPONSE_DEREGISTRATION_TYPE
import com.payu.threedsbase.constants.APIConstants.Companion.MFA_RESPONSE_MESSAGE
import com.payu.threedsbase.constants.APIConstants.Companion.MFA_RESPONSE_STATUS
import com.payu.threedsbase.constants.APIConstants.Companion.MFA_RESPONSE_TIMEOUT
import com.payu.threedsbase.constants.APIConstants.Companion.MFA_RESPONSE_TYPE
import com.payu.threedsbase.enums.PayU3DS2MFARequestType
import com.payu.threedsbase.enums.PayU3DS2MFAStatus
import com.payu.threedsbase.enums.PayU3DSDeregisterType
import org.json.JSONObject

data class PayU3DS2MFAResponse(
    val type: PayU3DS2MFARequestType,
    val status: PayU3DS2MFAStatus,
    val message: String? = null,
    val timeout: Int? = 0,
    val deregistrationType: PayU3DSDeregisterType? = null
) {
    /**
     * Converts PayU3DS2MFAResponse to JSONObject
     * @return JSONObject representation of the MFA response
     */
    fun toJSONObject(): JSONObject = JSONObject().apply {
        put(MFA_RESPONSE_TYPE, type.name)
        put(MFA_RESPONSE_STATUS, status.name)
        put(MFA_RESPONSE_MESSAGE, message)
        put(MFA_RESPONSE_TIMEOUT, timeout)
        deregistrationType?.let { put(MFA_RESPONSE_DEREGISTRATION_TYPE, it.name) }
    }

    /**
     * Converts PayU3DS2MFAResponse to JSON string
     * @return JSON string representation of the MFA response
     */
    fun toJSONString(): String = toJSONObject().toString()
}
