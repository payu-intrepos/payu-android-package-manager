package com.payu.threedsbase.enums

enum class ACSActionType {
    SUBMIT,
    RESEND,
    CANCEL
}