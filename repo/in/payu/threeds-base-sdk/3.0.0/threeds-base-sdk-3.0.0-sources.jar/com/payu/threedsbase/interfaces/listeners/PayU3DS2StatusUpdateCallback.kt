package com.payu.threedsbase.interfaces.listeners

import org.json.JSONObject

interface PayU3DS2StatusUpdateCallback {
    fun onStatusUpdate(response: JSONObject) {
    }
}