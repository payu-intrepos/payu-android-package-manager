package com.payu.threedsbase.data

data class HeadlessData(
    val acsTransactionID: String?,
    val acsRenderingType: String?,
    val issuerImage: ImageDetails?,
    val networkImage: ImageDetails?
)
