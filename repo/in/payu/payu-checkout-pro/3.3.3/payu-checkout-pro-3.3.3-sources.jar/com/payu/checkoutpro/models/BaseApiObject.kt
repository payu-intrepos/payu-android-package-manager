package com.payu.checkoutpro.models

import com.payu.checkoutpro.utils.CommonUtils
import com.payu.india.Model.PayuConfig
import com.payu.paymentparamhelper.PaymentParams

abstract class BaseApiObject(
    protected val payuBizparams: PaymentParams,
) {
    internal val payuConfig: PayuConfig = CommonUtils.preparePayUConfig()

    open fun cancelQuickPayTask() { }

}