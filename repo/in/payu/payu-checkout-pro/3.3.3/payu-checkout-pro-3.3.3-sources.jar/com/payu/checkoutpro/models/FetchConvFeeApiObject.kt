package com.payu.checkoutpro.models


import com.payu.base.listeners.OnValidateOfferListener
import com.payu.base.models.AdditionalCharge
import com.payu.base.models.CFandAdditionalCharges
import com.payu.base.models.InternalConfig
import com.payu.base.models.PayUPaymentParams
import com.payu.base.models.PayUSIParams
import com.payu.base.models.SelectedOfferInfo
import com.payu.base.models.VariableDynamics
import com.payu.checkoutpro.utils.CommonUtils
import com.payu.checkoutpro.utils.ParserUtils
import com.payu.checkoutpro.utils.ParserUtils.getSIDetails
import com.payu.checkoutpro.utils.PayUCheckoutProConstants
import com.payu.checkoutpro.utils.V2ApRequestParser
import com.payu.checkoutpro.utils.V2ApiResponseParser
import com.payu.india.Interfaces.V2ApiResponseListener
import com.payu.india.Model.ApiResponse
import com.payu.india.Model.fetchConvenienceFee.CommonDynamicAttributes
import com.payu.india.Model.fetchConvenienceFee.FetchConvFeeRequest
import com.payu.india.Model.fetchConvenienceFee.FetchConvFeeResponse
import com.payu.india.Model.fetchConvenienceFee.VariableDynamicAttributes
import com.payu.india.Model.validateOffer.ValidateOfferRequest
import com.payu.india.Payu.PayuConstants
import com.payu.india.Tasks.V2ApiTask
import com.payu.paymentparamhelper.PaymentParams
import com.payu.paymentparamhelper.siparams.SIParamsDetails
import com.payu.ui.model.managers.CFManager
import com.payu.ui.model.utils.Utils
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FetchConvFeeApiObject(
    internal val payuBizParams: PaymentParams,
    payUPaymentParams: PayUPaymentParams,
    private val mode: String,
    private val variableDynamicList: ArrayList<VariableDynamics>,
    private val includeOfferRequest: Boolean,
    private val onFetchConvFeeResponse: (CFandAdditionalCharges, SelectedOfferInfo) -> Unit?
) : V2BaseApiObject(payUPaymentParams, payuBizParams),
    V2ApiResponseListener<ApiResponse<FetchConvFeeResponse>> {

    private val payuPaymentParams = payUPaymentParams
    private var isAutoApply: Boolean = true

    override fun callApi() {
        val commonDynamicAttributes =  CommonDynamicAttributes(CFManager.getModeForCF(mode), PayuConstants.PAYU_CAPTURE)
        InternalConfig.disableConvFeeCompounding?.let {
            commonDynamicAttributes.isDisableConvFeeCompounding = it
        }
        InternalConfig.compoundingPercentage?.let {
            if(it.isNotEmpty()){
                commonDynamicAttributes.compoundingPercentage = it
            }
        }
        val dynamicAttributesList = variableDynamicList.map {
            VariableDynamicAttributes(it.combinationKey, it.ibiboCode)
        }


        val timestampFormat = PayUCheckoutProConstants.CP_TIME_FORMAT
        val currentTimestamp = SimpleDateFormat(timestampFormat, Locale.US).format(Date())

        val fetchConvFeeRequest = FetchConvFeeRequest.Builder().setPayuId(payuBizParams.txnId)
            .setMerchantKey(payuBizParams.key)
            .setAmount(payuBizParams.amount.toDoubleOrNull() ?: 0.0)
            .setSource(PayuConstants.PAYU_SOURCE_ANDROID_SDK.uppercase()).setTimeStamp(currentTimestamp)
            .setRequestId(payuBizparams.txnId+System.currentTimeMillis())
            .setCommonDynamicAttributes(commonDynamicAttributes)
            .setValidateOfferRequest(if (includeOfferRequest) getValidateOfferReq() else null)
            .setSi(payuBizparams.siParams != null)
            .setPricingCFEnable(Utils.isPricingLiveModeEnabled(CFManager.getPaymentModeNameForCF(mode)))
            .setAdditionalCharge(payuPaymentParams.additionalCharges)
            .setPercentageAdditionalCharges(payuPaymentParams.percentageAdditionalCharges)
            .setSiDetails(getSIDetails(payuPaymentParams.payUSIParams))
            .setFreeTrial(payuPaymentParams.payUSIParams?.isFreeTrial)
            .setSiTxn(payuPaymentParams.payUSIParams != null)
            .setVariableDynamicAttributesList(dynamicAttributesList).build()
        val v2ApiTask = V2ApiTask(payuBizparams.key, payuConfig)
        v2ApiTask.fetchConvFeeDetails(fetchConvFeeRequest, this, this)
    }

    override fun getHashName() = PayuConstants.PAYU_FETCH_CONV_F
    override fun onApiResponse(apiResponse: ApiResponse<FetchConvFeeResponse>?) {
        val cfAndAdditionalCharges = CFandAdditionalCharges()
        apiResponse?.payuResponse?.convFeeChargesMap?.let { convFeeChargesMap ->
            val cfData = V2ApiResponseParser.updateConvFeeResponse(
                convFeeChargesMap, false
            )
            cfAndAdditionalCharges.feeCombinations = cfData
        }

        apiResponse?.payuResponse?.convFeeSIChargesMap?.let { convFeeChargesMap ->
            val cfData = V2ApiResponseParser.updateConvFeeResponse(
                convFeeChargesMap, true
            )
            cfAndAdditionalCharges.feeCombinationsSi = cfData
        }

        if(apiResponse?.payuResponse?.convenienceFee.isNullOrEmpty().not() || apiResponse?.payuResponse?.gst.isNullOrEmpty().not())
            cfAndAdditionalCharges.additionalCharge = AdditionalCharge(
                apiResponse?.payuResponse?.convenienceFee,
                apiResponse?.payuResponse?.gst
            )

        onFetchConvFeeResponse.invoke(cfAndAdditionalCharges, V2ApiResponseParser.getSelectedOfferInfo(
            apiResponse?.payuResponse?.validateOfferDetails,
            payuPaymentParams,
            payuBizparams
        ))
    }

    private fun getValidateOfferReq(): ValidateOfferRequest {
        var offersKeyList: JSONArray ?= JSONArray()
        InternalConfig.userSelectedOfferInfo?.let {
            if (!it.isSkuOffer) {
                offersKeyList = JSONArray()
                offersKeyList?.put(it.offerKey)
                this.isAutoApply = false
            }
        }
        val enforceOfferKeys = payuPaymentParams.enforcementOfferKeys
        if (InternalConfig.userSelectedOfferInfo == null && enforceOfferKeys.isNullOrEmpty()
                .not()
        ) {
            offersKeyList = JSONArray()
            enforceOfferKeys?.filter { it.trim().isNotEmpty() }?.forEach { key ->
                offersKeyList?.put(key)
            }
            if((offersKeyList?.length() ?: 0) <= 0){
                offersKeyList = null
            }
        }

        val (sku, isAutoApplied) =
            if (InternalConfig.userSelectedOfferInfo == null || InternalConfig.userSelectedOfferInfo?.isSkuOffer == true) ParserUtils.getSkuJson(payuPaymentParams, isAutoApply)
            else Pair(null, isAutoApply)
        isAutoApply = isAutoApplied
        startTime = System.currentTimeMillis()

        return V2ApRequestParser.getValidateOfferReq(
            payuBizparams,
            offersKeyList,
            sku,
            payuBizparams.userToken,
            payuBizparams.cardNumber,
            payuBizparams.cardToken,
            payuBizparams.category,
            payuBizparams.paymentCode,
            isAutoApply
        )
    }

}