package com.payu.checkoutpro.models

enum class PayuSdk {
    OLAMONEY {
        override fun getClassName() = "com.payu.olamoney.OlaMoney"
    },
    OTP_ASSIST {
        override fun getClassName() = "com.payu.otpassist.PayUOtpAssist"
    },
    UPI {
        override fun getClassName() = "com.payu.upisdk.UpiWrapper"
    },
    QR_SCANNER {
        override fun getClassName() = "com.payu.ppiscanner.PayUQRScanner"
    };

    abstract fun getClassName(): String
}
