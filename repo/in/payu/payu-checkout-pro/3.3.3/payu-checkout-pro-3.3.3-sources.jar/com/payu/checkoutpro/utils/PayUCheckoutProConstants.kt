package com.payu.checkoutpro.utils

import com.payu.india.Payu.PayuConstants

object PayUCheckoutProConstants {


    const val CP_NAME_VALUE: String = "PayUCheckoutPro"
    const val CP_FIRST_NAME: String = "first_name"
    const val CP_EMAIL: String = "email"
    const val CP_SURL = "surl"
    const val CP_FURL = "furl"
    const val CP_UDF1 = "udf1"
    const val CP_UDF2 = "udf2"
    const val CP_UDF3 = "udf3"
    const val CP_UDF4 = "udf4"
    const val CP_UDF5 = "udf5"
    const val CP_PAYU_RESPONSE = "payuResponse"
    const val CP_MERCHANT_RESPONSE = "merchantResponse"
    const val CP_ENACH_FEEDBACK_URL = "enachFeedbackUrl"
    const val CP_OLAM = "OLAM"
    const val CP_PG = "pg"
    const val CP_BANK_CODE = "bankCode"
    const val CP_HASH_STRING = "hashString"
    const val CP_HASH_NAME = "hashName"
    const val CP_HASH_TYPE = "hashType"
    const val CP_V2_HASH = "V2"
    const val CP_GET_OFFER_DETAILS = "get_all_offer_details"
    const val CP_VALIDATE_OFFER_DETAILS = "validate_offer_details"
    const val CP_OLA_MONEY_ELIGIBILITY = "get_eligible_payment_options"
    const val CP_GET_CHECKOUT_DETAILS_VAR1 = "get_checkout_details_var1"
    const val CP_CHECK_BALANCE_VAR1 = "check_balance_var1"
    const val CP_VPA_VALIDATION = "validateVPA"
    const val CP_CHECK_ELIGIBILITY_VAR1 = "check_eligibility_var1"
    const val CP_OLA_MONEY_ELIGIBILITY_ERROR_MESSAGE = "No Ola Money account found with this number"
    const val CP_VALIDATE_VPA_ERROR_MESSAGE = "Invalid VPA"
    const val CP_STATUS = "status"
    const val CP_SUCCESS = "success"
    const val CP_FAILURE = "failure"
    const val CP_UNKNOWN = "unknown"
    const val CP_IS_VPA_VALID = "isVPAValid"
    const val CP_PAYER_ACCOUNT_NAME = "payerAccountName"
    const val CP_UPI_INTENT_PREFIX = "upi://pay?"
    const val CP_GOOGLE_PAY_PACKAGE_NAME = "com.google.android.apps.nbu.paisa.user"
    const val CP_GOOGLE_PAY_CLASS_NAME = "com.payu.gpay.GPayWrapper"
    const val CP_PHONEPE_CLASS_NAME = "com.payu.phonepe.PhonePeWrapper"
    const val CP_PHONEPE_PACKAGE_NAME = "com.phonepe.app"
    const val CP_OTP_ASSIST_PACKAGE_NAME = "com.payu.otpassist.OtpAssistFragment"
    const val CP_UPI_PACKAGE_NAME = "com.payu.upisdk.upiintent.PaymentResponseUpiSdkFragment"
    const val CP_CBPACKAGE_NAME = "com.payu.custombrowser.CBFragment"
    const val CP_DEBIT_CARD = "Debit Card"
    const val CP_CREDIT_CARD = "Credit Card"
    const val CP_CARDLESS = "Cardless EMI"
    const val CP_NETBANKING = "NETBANKING"
    const val CP_DC = "dc"
    const val CP_CC = "cc"
    const val CP_NB = "nb"
    const val CP_OTHER = "other"
    const val CP_CARD_LESS = "cardless"
    const val CP_INDUSIND = "Indusind"
    const val CP_AUBANK = "AU Bank"
    const val CP_ONECARD = "One Card"
    const val CP_AUSF = "AUSF"
    const val CP_ONEC = "ONEC"
    const val CP_INDUS = "INDUS"
    const val CP_AXIS = "Axis"
    const val CP_HDFC = "Hdfc"
    const val CP_ICICI = "Icici"
    const val CP_KOTAK = "Kotak"
    const val CP_BOB = "Bob"
    const val CP_FEDD = "FEDED"
    const val CP_FED = "Federal"
    const val CP_AXISD = "AXISD"
    const val CP_HDFCD = "HDFCD"
    const val CP_ICICID = "ICICID"
    const val CP_KOTAKD = "KOTAKD"
    const val CP_BOBD = "BOBD"

    const val CP_BAJFINSERV = "Bajaj Finserv"
    const val CP_BAJFINSERV_EMI_CARD = "Bajaj Finserv EMI Card"
    const val CP_BAJFIN = "BAJFIN"
    const val CP_PHONEPE = "PhonePe"
    const val PHONEPE = "PHONEPE"
    const val CP_PAYZAPP = "PayZapp"
    const val CP_GOOGLE_PAY = "Google Pay"
    const val CP_PAYTM_NAME = "Paytm"
    const val CP_LAZYPAY_NAME = "LazyPay"
    const val CP_SODEXO_NAME = "Pluxee"
    const val CP_LAZYPAY = "LAZYPAY"
    const val CP_ZEST = "ZEST"
    const val CP_PAYTM = "PAYTM"
    const val CP_OLAMONEY = "OlaMoney(Postpaid+Wallet)"
    const val CP_PPINTENT = "PPINTENT"
    const val CP_PPINAPP = "PPINAPP"
    const val CP_PPSDKLES = "PPSDKLES"
    const val CP_WALLETS = "Wallets"
    const val CP_BNPL = "Buy Now Pay Later"
    const val CP_BNPL_CODE = "bnpl"
    const val CP_PHONEPE_BANKCODE = "PHONEPE"
    const val CP_PAYZAPP_BANKCODE = "PAYZ"
    const val CP_BAJAJ_2_BANKCODE = "BAJFIN02"
    const val CP_BAJAJ_3_BANKCODE = "BAJFIN03"
    const val CP_BAJAJ_6_BANKCODE = "BAJFIN06"
    const val CP_BAJAJ_9_BANKCODE = "BAJFIN09"
    const val CP_BAJAJ_12_BANKCODE = "BAJFIN12"
    const val CP_IS_L1_OPTION = "isL1Option"
    const val CP_UPI_APP_NAME = "upiAppName"
    const val CP_KEY_ASSET_GOOGLE_PAY = "google_pay"
    const val CP_VAS_FOR_MOBILE_SDK = PayuConstants.VAS_FOR_MOBILE_SDK
    const val CP_PAYMENT_RELATED_DETAILS_FOR_MOBILE_SDK =
        PayuConstants.PAYMENT_RELATED_DETAILS_FOR_MOBILE_SDK
    const val CP_PAYMENT_HASH = PayuConstants.PAYMENT_SOURCE
    const val CP_DEFAULT = PayuConstants.DEFAULT
    const val CP_GET_EMI_AMOUNT_ACCORDING_TO_INTEREST =
        PayuConstants.API_GET_EMI_AMOUNT_ACCORDING_INTEREST
    const val CP_ELIGIBLE_BINS_FOR_EMI = PayuConstants.ELIGIBLE_BINS_FOR_EMI
    const val CP_CHECK_OFFER_DETAILS = PayuConstants.CHECK_OFFER_DETAILS
    const val CP_DEFAULT_ERROR_CODE = 111
    const val CP_ANALYTICS_DATA = "analyticsData"
    const val CP_OFFER_KEYS = "offerKeys"
    const val CP_GET_CHECKOUT_DETAILS = PayuConstants.GET_CHECKOUT_DETAILS
    const val CP_CHECK_BALANCE = "check_balance"
    const val CP_SI_PAYMENT_HASH = PayuConstants.SI_PAYMENT_SOURCE
    const val CP_TPV_PAYMENT_HASH = PayuConstants.TPV_PAYMENT_SOURCE
    const val CP_WEALTH_TECH_PAYMENT_SOURCE = PayuConstants.PAYU_WEALTH_TECH_PAYMENT_SOURCE

    const val CP_MERCHANT_ACCESS_KEY = "merchantAccessKey"
    const val CP_LOOKUP_API_HASH = "lookup_api_hash"
    const val CP_LOOKUP_API_POST_DATA = "lookup_post_data"
    const val CP_ERROR_SIGNATURE_MISMATCHED = "Signature Mismatched"
    const val CP_BASE_CURRENCY_VALUE = "INR"
    const val CP_RETRY_SDK = "&sdk_retry=1"
    const val GOOGLE_PAY = "Google Pay"
    const val CALCULATE_EMI_HASH_NAME = "calculate_emi_hash"

    const val SCANNER_OUTLET_HASH = "outlet_hash"

    //Error Codes
    const val CP_ERROR_INVALID_MERCHANT_ACCESS_KEY_CODE = 18
    const val CP_ERROR_PAYMENT_MODE_NOT_ALLOWED = 19
    const val CP_ERROR_INVALID_BENEFICIARY_DETAILS= 20
    const val CP_ERROR_INVALID_BENEFICIARY_DETAILS_MESSAGE= "Invalid Beneficiary Details"
    const val CP_ERROR_INVALID_ADDRESS_DETAILS= 21
    const val CP_ERROR_INVALID_ADDRESS_DETAILS_MESSAGE= "For OPGSP Merchant lastname, address1, address2, city, state, country, pincode and Invoice ID as UDF5 is mandatory"

    const val CP_KEY_SUB_TYPE = "subType"
    const val CP_KEY_EMI_CODE = "emiCode"
    const val CP_EMI = "emi"
    const val CP_FETCH_OFFERS = "fetch_offers"
    const val CP_CHECK_BALANCE_HASH = "check_balance"
    const val CP_IS_UPISI = "isUPISI"
    const val CP_ENACH_AMOUNT = "enach_amount"
    const val CP_PAYMENT_TYPE = "payment_type"
    const val CP_CARD_TYPE = "card_type"
    const val ENFORCED_IBIBOCODE = "enforce_ibiboCode"
    const val CP_CARD_SCHEME = "card_scheme"
    const val SODEXO_SOURCE_ID = "SodexoSourceId"
    const val SODEXO_CARD = "Pluxee Card"
    const val PLUXEE = "Pluxee"
    const val SODEXO = "Sodexo"
    const val MC = "MC"
    const val SODEXO_CHECK_BALANCE_API_TIMEOUT = 8000

    const val CONFIG_RESPONSE_KEY = "result"
    const val SHARED_PREFERENCE_KEY = "CheckoutProPreference"
    const val SP_CONFIG_KEY = "checkoutpro_config"

    const val CP_IS_AUTO_PAY_VALID = "isAutoPayVPAValid"
    const val CP_AUTO_PAY_VALIDATE_ERROR_MESSAGE = "Auto Pay is not supported on this VPA"
    const val CP_VALIDATE_AUTO_PAY_VPA = "validateautopayvpa"
    const val CP_POST_SALT = "postSalt"
    const val CP_CLICK_EVENT = "click"
    const val CP_MOBILE_SOURCE = "mobile_footer"
    const val CP_TWID = "TWID"
    const val CP_GET = "GET"
    const val SDK_CONFIGURATION = PayuConstants.SDK_CONFIGURATION
    const val VERIFY_PAYMENT = PayuConstants.VERIFY_PAYMENT
    const val PAYU_SIGNING_STRING = "signing_string"
    const val PAYU_UNMAPPED_STATUS = "unmappedstatus"
    const val PAYU_FAILED = "failed"

    //NetBank Bank Codes
    const val SBIB = "SBIB"
    const val HDFB = "HDFB"
    const val ICIB = "ICIB"
    const val AXIB = "AXIB"
    const val PNBB = "PNBB"
    const val PAYU_162B = "162B"

    //SI NetBank Bank Codes
    const val SBINENCC = "SBINENCC"
    const val HDFCENCC = "HDFCENCC"
    const val ICICENCC = "ICICENCC"
    const val UTIBENCC = "UTIBENCC"
    const val PUNBENCC = "PUNBENCC"
    const val KKBKENCC = "KKBKENCC"

    //CC Emi Bank Code
    const val SBI_CC = "SBI"
    const val HDFC_CC = "HDFC"
    const val ICICI_CC = "ICICI"
    const val KOTAK_CC = "KOTAK"
    const val AXIS_CC = "AXIS"

    //DC Emi Bank Code
    const val SBI_DC = "SBI"
    const val HDFC_DC = "HDFCD"
    const val ICICI_DC = "ICICID"
    const val KOTAK_DC = "KOTAKD"
    const val AXIS_DC = "AXISD"

    const val PAYUBIZAPILAYER = "PayUbizApiLayer"
    const val MAKEPAYMENTAPIOBJECT = "MakePaymentApiObject"
    const val WEBSERVICEAPIOBJECT = "WebServiceApiObject"
    const val COMMONUTILS = "CommonUtils"
    const val PARSERUTILS = "ParserUtils"
    const val PAYMENT_PARAM_MISSING = "Payment param missing"
    const val CP_OLAMONEY_CLASS_NAME = "com.payu.olamoney.OlaMoney"

    const val CP_BHIM = "BHIM"

    //Global Vault Constants
    const val CP_USERTOKEN = "userToken"
    const val CP_TOKEN = "token"
    const val CP_RESPONSE_CODE = "responseCode"
    const val CP_RESPONSE_MESSAGE = "responseMessage"
    const val CP_UUID = "uuid"
    const val CP_MOBILE_NUMBER = "mobileNumber"
    const val CP_OTP = "otp"
    const val CP_PAYMENT_OPTIONS = "payment_options"
    const val REQUEST_TYPE = "quickpay"
    const val QUICKPAY_EVENT = "quickPayEvent"
    const val CP_AMAZON_PAY = "Amazon Pay"
    const val CP_GPAY = "GPay"
    const val CP_NULL = "null"
    const val CP_NA = "NA"

    //CLW Constants
    const val WALLET_IDENTIFIER = "walletIdentifier"
    const val MOBILE = "mobile"
    const val IBIBO_CODE = "ibibo_code"
    const val WALLET_URN = "walletUrn"
    const val PAY = "PAY"
    const val CLW = "CLW"
    const val CP_WALLET = "Wallet"
    const val CP_NOT_FOUND ="Not Found"

    const val CP_TRUE = "true"

    // calculateEmi constant

    const val CP_TRANSACTION_AMOUNT = "transactionAmount"
    const val CP_EMI_AMOUNT = "emiAmount"
    const val CP_ADDITIONAL_COST = "additionalCost"
    const val CP_BANK_RATE = "bankRate"
    const val CP_BANK_CHARGE = "bankCharge"
    const val CP_CARDTYPE = "cardType"
    const val CP_TENURE = "tenure"
    const val CP_LOAN_AMOUNT = "loanAmount"
    const val CP_OFFER_DISCOUNT = "offerDiscount"
    const val CP_TOTAL = "total"
    const val CP_CASHBACK = "cashback"
    const val CP_INSTANT = "instant"
    const val CP_NCE_DISCOUNT = "nceDiscount"
    const val CP_TOTAL_PAYABLE = "totalPayableAmount"
    const val CP_SUBVENTION_AMOUNT = "subventionAmount"
    const val CP_EMI_VALUE = "emi_value"
    const val CP_EMI_INTEREST_PAID = "emi_interest_paid"
    const val CP_AMOUNT = "amount"
    const val CP_OFFERS = "offers"
    const val MYSTERY_OFFER = "MYSTERY_OFFER"
    const val CP_DEBIT_CARD_EMI = "debitCard"
    const val CP_CREDIT_CARD_EMI = "creditCard"
    const val CP_CARD_LESS_EMI = "cardLess"
    const val CP_IS_NO_COST_EMI = "isNoCostEmi"
    const val CP_BANKS = "banks"
    const val CP_TENURE_OPTION = "tenureOption"
    const val CP_PAYMENT_CODE = "paymentCode"
    const val CP_EMI_PROCESSING_FEE = "processingFee"
    const val CP_FEE = "fee"
    const val CP_P_FEE_MESSAGE = "message"

    const val AMAZON = "Amazon"
    const val CRED = "CRED"
    const val GPAY = "GPay"
    const val PHONE_PE = "PhonePe"
    const val PAYTM = "Paytm"
    const val CP_QR_SCANNER_ERROR_MESSAGE = "QR Scanner SDK not available"
    const val CP_HASH_NOT_NULL = "Hash cannot be null or empty"

    const val CP_CASH_CARD = "cashcard"

    const val CP_DEVICE_ID = "deviceId"

    const val CP_DELETE_SAVED_OPTIONS = "deleteSavedOptions"

    const val CP_SAVED_OPTION_NOT_DELETED = "Saved Option not Deleted , Please try again"
    const val CP_G_PAY = "GooglePay"

    const val PAYU_NAVIGATION_HANDLER = "payu_navigation_handler"

    const val GLOBAL_VAULT_USER_TOKEN_PREF = "userTokenPref"
    const val CP_PHONE_PE_MIN_VERSION = 94033
    const val CP_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss"

    const val CP_MESSAGE_CODE = "messageCode"
    const val CP_RESPONSE_DATE_TIME = "responseDateTime"
    const val CP_CLIENT_TXN_ID = "clientTxnID"
    const val CP_BANK_ID = "bankId"
    const val CP_MPIN_EXPIRY_TIME = "mpinExpiryTime"
    const val CP_TOKEN_EXPIRY_TIME = "tokenExpiryTime"
    val CP_SET = "SET"
    private val CP_FORGOT = "FORGOT"
    const val PAYU_SHOW_CB_TOOLBAR = "showCbToolbar"
    const val PAYU_MERCHANT_SMS_PERMISSION = "merchantSmsPermission"
    const val PAYU_AUTO_SELECT_OTP = "autoSelectOtp"
    const val PAYU_AUTO_APPROVE = "autoApprove"
    const val PAYU_SURE_PAY_COUNT = "surePayCount"
    const val PAYU_EXIT_CONFIRMATION_ON_PAYMENT = "showExitConfirmationOnPaymentScreen"
    const val PAYU_MERCHANT_RESPONSE_TIMEOUT = "merchantResponseTimeout"
    const val PAYU_WAITING_TIME = "waitingTime"
    const val PAYU_ENABLE_SSL_DIALOG = "enableSslDialog"
    const val PAYU_PAYMENT_MODES_ORDER = "paymentModesOrder"
    const val PAYU_CART_DETAILS = "cartDetails"
    const val PAYU_CUSTOM_NOTE_DETAILS = "customNoteDetails"
    const val PAYU_EXIT_CONFIRMATION_ON_CHECKOUT = "showExitConfirmationOnCheckoutScreen"
    const val PAYU_MERCHANT_NAME = "merchantName"
    const val PAYU_MERCHANT_LOGO = "merchantLogo"
    const val PAYU_ENFORCE_PAYMENT_LIST = "enforcePaymentList"
    const val PAYU_MERCHANT_LOGO_URL = "merchantLogoUrl"
    const val PAYU_PRIMARY_COLOR = "primaryColor"
    const val PAYU_PRIMARY_COLOR_DARK = "primaryColorDark"
    const val PAYU_PRIMARY_COLOR_ACCENT = "primaryColorAccent"
    const val PAYU_BASE_TEXT_COLOR = "baseTextColor"
    const val PAYU_SHOW_MERCHANT_LOGO = "showMerchantLogo"
    const val PAYU_ENABLE_SAVED_CARD = "enableSavedCard"
    const val PAYU_IS_QR_SCAN = "isQrScan"
    const val PAYU_ENABLE_RE_OPTIONS = "enableREOptions"
    const val PAYU_UPI_APPS_ORDER = "upiAppsOrder"

    const val SDK_NAME_CHECKOUT_PRO_WRAPPER = "PayUCheckoutProWrapper"

    const val CP_ISSUE_CODE = "issueCode"
    const val CP_ERROR_MESSAGE = "errorMessage"
    const val CP_SOMETHING_WENT_WRONG_ERROR_MESSAGE = "Something went wrong, please try again"

    const val PAYU_AES_GCM_NO_PADDING: String = "AES/GCM/NoPadding"

    const val CP_REVISED_PRINCIPAL = "revisedPrincipal"

    const val PAYU_CP_CB_CALLBACK = "CB Callback"

    const val PAYU_PAYMENT_TERMINATED= "Payment Terminated"
    const val PAYU_ON_CB_ERROR= "On CB Error Received"
    const val PAYU_ON_BACK_BUTTON= "CB - On Back Button"
    const val PAYU_ON_BACK_APPROVE= "CB - On Back Approve"


}