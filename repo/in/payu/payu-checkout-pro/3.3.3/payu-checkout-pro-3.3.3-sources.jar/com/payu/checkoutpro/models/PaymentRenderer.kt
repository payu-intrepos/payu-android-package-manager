package com.payu.checkoutpro.models

import androidx.fragment.app.Fragment
import com.payu.paymentparamhelper.PaymentParams

abstract class PaymentRenderer(payuBizparams: PaymentParams) :
    BaseApiObject(payuBizparams) {
    abstract fun render(map: HashMap<String, String?>): Fragment?
    abstract fun getHashName(): String

}