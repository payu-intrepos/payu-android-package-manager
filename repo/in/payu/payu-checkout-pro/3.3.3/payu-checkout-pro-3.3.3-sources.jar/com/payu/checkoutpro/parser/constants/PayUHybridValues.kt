package com.payu.checkoutpro.parser.constants

object PayUHybridValues {
    object Error {
        const val HASH_NOT_GENERATED_ERROR = "The value of generate Hash is not valid"
        const val ACTIVITY_OR_CONTEXT_NULL = "Current Context cannot run with Activity null"
        const val HASH_NOT_GENERATED_ERROR_CODE = 100
        const val GENERIC_ERROR_CODE = 101
        const val NULL_CONTEXT_ERROR_CODE = 200
        const val SOME_ERROR_OCCURRED = "Some error occurred..."


    }
}