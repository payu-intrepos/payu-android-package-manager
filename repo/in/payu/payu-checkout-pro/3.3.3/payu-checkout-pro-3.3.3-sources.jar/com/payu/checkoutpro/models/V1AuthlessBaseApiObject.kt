package com.payu.checkoutpro.models

import com.payu.paymentparamhelper.PaymentParams

/**
 * To perform requests that do not require Hash
 */
abstract class V1AuthlessBaseApiObject(
    protected val payUPaymentParams: Any,
    payuBizparams: PaymentParams, listener: Any?
) : BaseApiObject(payuBizparams) {
    abstract fun callApi()
}