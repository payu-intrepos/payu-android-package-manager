package com.payu.checkoutpro.models

import com.payu.base.models.PaymentState

class EnforcementManager(var enforcelist: ArrayList<HashMap<String, String>>) {
    var nbManager: NBManager = NBManager(enforcelist)
    var upiManager: UpiManager = UpiManager(enforcelist)

    fun getNextStateFromManager(): PaymentState? {
        var state: PaymentState? = null
        nbManager.setNextChain(upiManager)
        upiManager.setNextChain(null)
        state = nbManager.getNextPaymentState()
        return state
    }
}