package com.payu.checkoutpro.listeners

interface PayUInternalHashGenerationListener {
    fun onHashGenerated(map: HashMap<String, String?>)

}