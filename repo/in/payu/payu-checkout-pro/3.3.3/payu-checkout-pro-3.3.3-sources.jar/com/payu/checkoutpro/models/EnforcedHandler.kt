package com.payu.checkoutpro.models

import com.payu.base.models.PaymentState
import java.util.*

abstract class EnforcedHandler {
    var manager: EnforcedHandler? = null
    abstract fun getNextPaymentState(): PaymentState?
    fun setNextChain(enforcedHandler: EnforcedHandler? = null) {
        manager = enforcedHandler
    }
}
