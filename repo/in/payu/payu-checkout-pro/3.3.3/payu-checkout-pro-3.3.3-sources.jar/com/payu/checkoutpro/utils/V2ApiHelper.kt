package com.payu.checkoutpro.utils

import com.payu.india.Payu.PayuConstants

object V2ApiHelper {

    fun getHeaderHashMap(
        walletIdentifier: String,
        bankCode: String
    ): HashMap<String, String> {
        val headerMap: HashMap<String, String> = HashMap()
        headerMap[PayuConstants.WALLET_IDENTIFIER] = walletIdentifier
        headerMap[PayuConstants.PAYU_IBIBOCODE] = bankCode
        return headerMap;
    }
}