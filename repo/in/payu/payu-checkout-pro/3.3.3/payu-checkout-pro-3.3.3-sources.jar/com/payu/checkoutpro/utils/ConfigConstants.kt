package com.payu.checkoutpro.utils

object ConfigConstants {
    const val CP_MERCHANT_NAME: String = "merchantName"
    const val CP_MERCHANT_LOGO_URL: String = "merchantLogo"
    const val CP_AUTO_APPROVE: String = "autoApprove"
    const val CP_AUTO_SELECT_OTP: String = "autoSelectOtp"
    const val CP_SHOW_EXIT_CONFIRMATION_ON_PAYMENT_SCREEN: String =
        "showExitConfirmationOnPaymentScreen"
    const val CP_SHOW_TOOLBAR: String = "showToolbar"
    const val CP_MERCHANT_SMS_PERMISSION: String = "merchantSmsPermission"
    const val CP_MERCHANT_EXIT_CONFIRMATION_ON_CHECKOUT_SCREEN: String =
        "showExitConfirmationOnCheckoutScreen"
    const val CP_MERCHANT_RESPONSE_TIMEOUT: String = "merchantResponseTimeout"
    const val CP_MERCHANT_WAITING_TIMEOUT: String = "waitingTime"
    const val CP_PAYMENT_MODE_ORDER: String = "paymentModesOrder"
    const val CP_MERCHANT_APP_VERSION: String = "app_version"
    const val CP_PRIMARY_COLOR: String = "primaryColor"
    const val CP_PRIMARY_COLOR_DARK: String = "primaryColorDark"
    const val CP_PRIMARY_COLOR_ACCENT: String = "primaryColorAccent"
    const val CP_BASE_TEXT_COLOR: String = "baseTextColor"


    const val CP_ENFORCED_PAYMENT_MODE: String = "enforcePaymentList"
    const val CP_CUSTOM_NOTE_DETAILS: String = "customNoteDetails"
    const val CP_PAYMENT_TYPE: String = "paymentType"
    const val CP_KEY: String = "key"
    const val CP_VALUE: String = "value"
    const val CP_UPI_APP_ORDER: String = "upiAppsOrder"

}