package com.payu.checkoutpro.listeners

interface NavigationHandlerListener<in T> {
    fun onResultReceived(result: T)
}