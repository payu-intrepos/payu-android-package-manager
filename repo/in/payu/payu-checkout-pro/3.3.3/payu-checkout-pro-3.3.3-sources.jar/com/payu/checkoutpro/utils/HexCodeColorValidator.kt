package com.payu.checkoutpro.utils

import java.util.regex.Matcher
import java.util.regex.Pattern

object HexCodeColorValidator {

    private var pattern: Pattern? = null
    private var matcher: Matcher? = null

    private val HEX_PATTERN = "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"

    init {
        pattern = Pattern.compile(HEX_PATTERN)
    }

    fun validate(hexColorCode: String?): Boolean {
        matcher = pattern!!.matcher(hexColorCode)
        return matcher!!.matches()
    }
}