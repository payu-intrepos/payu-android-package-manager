package com.payu.checkoutpro.models

import com.payu.base.models.PaymentState
import com.payu.base.models.PaymentType
import com.payu.checkoutpro.utils.PayUCheckoutProConstants

class UpiManager(var enforceList: ArrayList<HashMap<String, String>>) : EnforcedHandler() {
    override fun getNextPaymentState(): PaymentState? {
        var paymentState: PaymentState? = null
        for (list in enforceList) {
            if (list[PayUCheckoutProConstants.CP_PAYMENT_TYPE] == PaymentType.UPI.name)
                paymentState = null
            else
                continue
        }
        if (paymentState != null)
            return paymentState
        else
            return null
    }
}