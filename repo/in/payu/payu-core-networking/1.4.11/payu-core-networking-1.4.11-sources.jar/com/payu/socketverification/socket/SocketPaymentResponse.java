package com.payu.socketverification.socket;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author shahbaz.ahmmod
 * Bean class to get payment related params.
 */
public class SocketPaymentResponse implements Parcelable {
    public static final Creator<SocketPaymentResponse> CREATOR = new Creator<SocketPaymentResponse>() {
        @Override
        public SocketPaymentResponse createFromParcel(Parcel in) {
            return new SocketPaymentResponse(in);
        }

        @Override
        public SocketPaymentResponse[] newArray(int size) {
            return new SocketPaymentResponse[size];
        }
    };
    private String referenceId;
    private String txnId;
    private String upiPushDisabled;
    private String pushServiceUrl;
    private String upiServicePollInterval;
    private String sdkUpiPushExpiry;
    private String sdkUpiVerificationInterval;

    protected SocketPaymentResponse(Parcel in) {
        referenceId = in.readString();
        txnId = in.readString();
        upiPushDisabled = in.readString();
        pushServiceUrl = in.readString();
        upiServicePollInterval = in.readString();
        sdkUpiPushExpiry = in.readString();


    }

    public SocketPaymentResponse() {
    }

    public String getUpiPushDisabled() {
        return upiPushDisabled;
    }

    public void setUpiPushDisabled(String upiPushDisabled) {
        this.upiPushDisabled = upiPushDisabled;
    }

    public String getPushServiceUrl() {
        return pushServiceUrl;
    }

    public void setPushServiceUrl(String pushServiceUrl) {
        this.pushServiceUrl = pushServiceUrl;
    }

    public String getUpiServicePollInterval() {
        return upiServicePollInterval;
    }

    public void setUpiServicePollInterval(String upiServicePollInterval) {
        this.upiServicePollInterval = upiServicePollInterval;
    }

    public String getSdkUpiPushExpiry() {
        return sdkUpiPushExpiry;
    }

    public void setSdkUpiPushExpiry(String sdkUpiPushExpiry) {
        this.sdkUpiPushExpiry = sdkUpiPushExpiry;
    }

    public String getSdkUpiVerificationInterval() {
        return sdkUpiVerificationInterval;
    }

    public void setSdkUpiVerificationInterval(String sdkUpiVerificationInterval) {
        this.sdkUpiVerificationInterval = sdkUpiVerificationInterval;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(referenceId);
        parcel.writeString(txnId);
        parcel.writeString(upiPushDisabled);
        parcel.writeString(pushServiceUrl);
        parcel.writeString(upiServicePollInterval);
        parcel.writeString(sdkUpiPushExpiry);
    }

}
