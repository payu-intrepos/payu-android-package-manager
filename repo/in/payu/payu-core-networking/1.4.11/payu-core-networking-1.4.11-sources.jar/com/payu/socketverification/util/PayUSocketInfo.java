package com.payu.socketverification.util;

/**
 * Saving and transmitting SocketInfo contains
 */
public class PayUSocketInfo {
    private String referenceId;
    private String pushServiceUrl;
    private long sdkUpiPushExpiry = 20;
    private long sdkUpiVerificationInterval = 5;
    private long upiServicePollInterval = 5;

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getPushServiceUrl() {
        return pushServiceUrl;
    }

    public void setPushServiceUrl(String pushServiceUrl) {
        this.pushServiceUrl = pushServiceUrl;
    }

    public long getSdkUpiPushExpiry() {
        return sdkUpiPushExpiry;
    }

    public void setSdkUpiPushExpiry(long sdkUpiPushExpiry) {
        this.sdkUpiPushExpiry = sdkUpiPushExpiry;
    }

    public long getSdkUpiVerificationInterval() {
        return sdkUpiVerificationInterval;
    }

    public void setSdkUpiVerificationInterval(long sdkUpiVerificationInterval) {
        this.sdkUpiVerificationInterval = sdkUpiVerificationInterval;
    }

    public long getUpiServicePollInterval() {
        return upiServicePollInterval;
    }

    public void setUpiServicePollInterval(long upiServicePollInterval) {
        this.upiServicePollInterval = upiServicePollInterval;
    }

}
