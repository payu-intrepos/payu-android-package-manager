// The MIT License (MIT)
//
// Copyright (c) 2014-2015 PayU India
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package com.payu.socketverification.util;

/**
 * Created by minie on 30/6/15.
 * Constants for analytics.
 */

public class PayUNetworkAnalyticsConstant {

//    public static final String SUCCESS_TRANSACTION = "success_transaction";
//    public static final String FAILURE_TRANSACTION = "failure_transaction";

    //Keys for Device Tracking for transaction
    public static final String MERCHANT_KEY = "merchant_key";
    public static final String TRANSACTION_ID = "txnid";

    //Event Analyitcs
    public static final String BANK_NAME = "bank";
    public static final String PAKAGE_NAME = "package_name";
    public static final String KEY = "event_key";
    public static final String VALUE = "event_value";
    public static final String PAGE_TYPE = "page_type";
    public static final String PAYU_ID = "payu_id";
    public static final String TIMESTAMP = "ts";

    //Key for Event CBAnalytics
//    public static final String TRNX_STATUS = "trxn_status";
    public static final String VERSION_CODE = "version_code";
    public static final String SET_SOCKET = "_setSocket";
    public static final String INIT_SOCKET = "_initSocket";
    public static final String DISCONNECT_SOCKET = "_disconnectSocket";
    public static final String TRANSACTION_CANCELLED = "_onTranscationCancelled";
}