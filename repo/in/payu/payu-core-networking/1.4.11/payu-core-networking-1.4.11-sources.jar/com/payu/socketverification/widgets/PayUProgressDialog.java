package com.payu.socketverification.widgets;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.payu.socketverification.R;
import com.payu.socketverification.util.UIUtils;

import java.util.Timer;


/**
 * Created by himanshu.gupta on 28/12/17.
 */

public class PayUProgressDialog extends Dialog {

    Timer timerProgress = null;
    ImageView ivProgress;
    private TextView tvMessage;
    private Activity mActivity;
    private View layout = null;

    /**
     * Displaying Payuloader.
     *
     * @param context base activity context
     * @param view    Custom Progress Dialog Layout if any
     */
    public PayUProgressDialog(Context context, View view) {
        super(context, R.style.Theme_AppCompat_Light_NoActionBar);
        this.mActivity = (Activity) context;
        LayoutInflater mInflater = LayoutInflater.from(context);
        if (null != view) {
            layout = view;
            if (view.getParent() != null) {
                ViewGroup parent = (ViewGroup) view.getParent();
                parent.removeView(view);
            }
            setContentView(layout);
        } else {
            //Default PayU progress Dialog
            layout = mInflater.inflate(R.layout.payu_prog_dialog_upisdk, null, false);
            setContentView(layout);
            tvMessage = (TextView) layout.findViewById(R.id.tvMessage);
            ivProgress = (ImageView) layout.findViewById(R.id.upi_payu_loader);
            UIUtils.applyLoopingAnimatedVectorDrawable(ivProgress, this.mActivity);
        }
        setCancelable(true);
        setCanceledOnTouchOutside(false);

    }

    /**
     * Returns drawable from resource id.
     *
     * @param context currentContext
     * @param resID   resourceId
     * @return drawable
     */

    /**
     * Init PayU Progress Dialog Default Loader Settings
     *
     * @param context
     */
    public void setPayUDialogSettings(Context context) {
    }

    public void setText(String text) {
    }
}
