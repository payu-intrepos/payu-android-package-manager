package com.payu.socketverification.socket;

import static com.payu.socketverification.util.PayUNetworkAnalyticsConstant.DISCONNECT_SOCKET;
import static com.payu.socketverification.util.PayUNetworkAnalyticsConstant.INIT_SOCKET;
import static com.payu.socketverification.util.PayUNetworkAnalyticsConstant.SET_SOCKET;
import static com.payu.socketverification.util.PayUNetworkAnalyticsConstant.TRANSACTION_CANCELLED;
import static com.payu.socketverification.util.PayUNetworkPaymentConstants.SERVER_ERROR_MESSAGE_FINISH;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.bean.SocketData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.FragmentListener;
import com.payu.socketverification.interfaces.IVerifyResponse;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;
import com.payu.socketverification.polling.PollingVerify;
import com.payu.socketverification.socketclient.client.PayUSocket;
import com.payu.socketverification.socketclient.emitter.PayUEmitter;
import com.payu.socketverification.util.L;
import com.payu.socketverification.util.NetworkUtil;
import com.payu.socketverification.util.PayUNetworkConstant;
import com.payu.socketverification.util.PayUNetworkPaymentConstants;
import com.payu.socketverification.util.PayUSocketInfo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.UnknownHostException;


/**
 * Created by Shahbaz
 * <p>
 * This class is used to create the socket once we get the event of payment.
 * Socket is used to get the verification from PayU server regarding the transaction.
 * If socket fails, we would be working with https call.
 * <p>
 * New Check status flow:
 * Based on upiPushDisabled, a config level flag:
 * <p>
 * If push service is disabled, then poll to biz.
 * Else:
 * try to bind socket
 * If Unsuccessful, then poll to upi service through https
 * Else wait for socket event and redirect user, while pinging service every SLEEP_TIME seconds.
 * finish call to biz/service after EXPIRY depending upon upiPushDisabled
 * <p>
 * pushConfiguration must have:
 * 1. pushServiceUrl (url of deployed service).
 * 2. servicePollInterval (poll interval in-case socket fails). Default = 5 sec
 * 3. sleepTime (between each verify call). Default = 30 sec
 * 4. expiry. Default = 300 sec
 * 5. payuId
 */


public class VerifyHandler extends SocketBase implements IVerifyResponse, PayuNetworkAsyncTaskInterface {
    private static long TIME = 30000;
    private static volatile VerifyHandler INSTANCE;
    private static int errorCounter = 0;
    private final String TAG = "VerifyHandler";
    private Activity activity;
    private FragmentListener fragmentListener;
    private PayUSocket mSocket;
    private Handler handler;
    private Handler bottomLevelHandler;
    private IVerifyResponse iVerifyResponse;
    private PollingVerify pollingVerify;
    private PayUAnalytics analytics;
    private String merchantKey;
    private String txnId;

    /**
     * Saving and transmitting SocketInfo contains
     */
    private PayUSocketInfo payUSocketInfo;

    private VerifyHandler() {
        payUSocketInfo = new PayUSocketInfo();
    }

    /**
     * @return return object of VerifyHandler
     */
    public static VerifyHandler getInstance() {
        if (INSTANCE == null) {
            synchronized (VerifyHandler.class) {
                if (INSTANCE == null) {
                    INSTANCE = new VerifyHandler();
                }
            }
        }
        return INSTANCE;
    }

    @Override
    public void onPayuNetworkAsyncTaskResponse(String payUAsynTaskResponse, String webServiceType) {

        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.SOCKET_VERIFY, PayUNetworkConstant.FINISH_USING_HTTP, null, merchantKey, txnId, null));

        try {
            memoryFreeUp();
            JSONObject jsonObject = new JSONObject(payUAsynTaskResponse);
            if (jsonObject.has(PayUNetworkConstant.RESULT_KEY)) {
                if (!PayUNetworkConstant.PENDING_STATUS_LIST.contains(jsonObject.getString(PayUNetworkConstant.RESULT_KEY).toLowerCase())) {
                    sendingResultBack(NetworkUtil.getBase64DecodedString(jsonObject.getString(PayUNetworkConstant.RESULT_KEY)), EventType.FINISH);

                }
            }
        } catch (JSONException | IllegalArgumentException | OutOfMemoryError | NullPointerException | IOException e) {
            if (null != SocketData.SINGLETON.getPayUSocketEventListener() && pollingVerify != null) {
                pollingVerify.disposePollingHandler();
                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, e.getMessage());
            }
            disconnectSocket();
            //    CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onCBErrorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, e.getMessage());
        }
    }

    /**
     * @param socket
     * @param context
     * @param socketPaymentResponse
     * @param analytics
     * @param merchantKey
     * @param txnId
     * @param customProgressView
     */
    public void setSocket(PayUSocket socket, Activity context, SocketPaymentResponse socketPaymentResponse, PayUAnalytics analytics, String merchantKey, String txnId, View customProgressView, FragmentListener fragmentListener) {
        this.analytics = analytics;
        this.mSocket = socket;
        this.merchantKey = merchantKey;
        this.txnId = txnId;
        this.activity = context;
        this.fragmentListener = fragmentListener;
        iVerifyResponse = this;
        setProgressDialogCustomView(customProgressView);
        handler = new Handler();
        bottomLevelHandler = new Handler();
        replacePayUSocketInfo(socketPaymentResponse);
        this.analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET,
                TAG + SET_SOCKET, null, merchantKey, txnId, null));
    }

    private void replacePayUSocketInfo(SocketPaymentResponse socketPaymentResponse) {
        if (socketPaymentResponse != null) {
            if (socketPaymentResponse.getSdkUpiPushExpiry() != null) {
                payUSocketInfo.setSdkUpiPushExpiry(Long.parseLong(socketPaymentResponse.getSdkUpiPushExpiry()));
            }
            if (socketPaymentResponse.getSdkUpiVerificationInterval() != null) {
                payUSocketInfo.setSdkUpiVerificationInterval(Long.parseLong(socketPaymentResponse.getSdkUpiVerificationInterval()));
            }
            if (socketPaymentResponse.getUpiServicePollInterval() != null) {
                payUSocketInfo.setUpiServicePollInterval(Long.parseLong(socketPaymentResponse.getUpiServicePollInterval()));
            }
            if (socketPaymentResponse.getReferenceId() != null) {
                payUSocketInfo.setReferenceId(socketPaymentResponse.getReferenceId());
            }
            if (socketPaymentResponse.getPushServiceUrl() != null) {
                payUSocketInfo.setPushServiceUrl(socketPaymentResponse.getPushServiceUrl());
            }

        }
    }

    /**
     *
     */
    private void removeHandler() {
        if (bottomLevelHandler != null && bottomLevelRunnable != null)
            bottomLevelHandler.removeCallbacks(bottomLevelRunnable);

        if (handler != null && topLevelRunnable != null)
            handler.removeCallbacks(topLevelRunnable);
        handler = null;
        bottomLevelHandler = null;
    }

    /**
     * close the socket
     * Since an Android Activity has its own lifecycle,
     * we should carefully manage the state of the socket also to avoid problems like memory leaks.
     */
    public void disconnectSocket() {
        if (mSocket != null && getEmitterListner(EventType.ON_CONNECT) != null && getEmitterListner(EventType.ON_CONNECT_ERROR) != null && getEmitterListner(EventType.ON_DISCONNECT) != null &&
                getEmitterListner(EventType.ON_UPI_UPDATE) != null && getEmitterListner(EventType.ON_UPI_VERIFICATION_RESPONSE) != null) {
            mSocket.off(PayUSocket.EVENT_CONNECT, getEmitterListner(EventType.ON_CONNECT));
            mSocket.off(PayUSocket.EVENT_DISCONNECT, getEmitterListner(EventType.ON_DISCONNECT));
            mSocket.off(PayUSocket.EVENT_CONNECT_ERROR, getEmitterListner(EventType.ON_CONNECT_ERROR));
            mSocket.off(PayUNetworkConstant.UPI_UPDATE_EVENT, getEmitterListner(EventType.ON_UPI_UPDATE));
            mSocket.off(PayUNetworkConstant.UPI_VERIFICATION_RESPONSE_EVENT, getEmitterListner(EventType.ON_UPI_VERIFICATION_RESPONSE));
            mSocket.disconnect();

            if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET,
                        TAG + DISCONNECT_SOCKET, null, merchantKey, txnId, null));
            }
        } else {
            L.v("Disconnect socket. Some fields are null");
        }
        hideProgressDialog();
    }    /**
     * Runnable to emit "upi-verification" Socket event after sdkUpiVerificationInterval
     */
    private Runnable bottomLevelRunnable = new Runnable() {
        @Override
        public void run() {
            // perform the sending message attempt.
            if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {

                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mSocket != null)
                            mSocket.emit(PayUNetworkConstant.UPI_VERFICATION_EVENT, payUSocketInfo.getReferenceId());

                        if (bottomLevelHandler != null && bottomLevelRunnable != null)
                            bottomLevelHandler.postDelayed(bottomLevelRunnable, payUSocketInfo.getSdkUpiVerificationInterval() * 1000);
                    }
                });
            }
        }
    };

    /**
     * Initialize the socket.
     */
    public void initSocket() {
        if (mSocket != null) {
            mSocket.on(PayUSocket.EVENT_CONNECT, getEmitterListner(EventType.ON_CONNECT));
            mSocket.on(PayUSocket.EVENT_DISCONNECT, getEmitterListner(EventType.ON_DISCONNECT));
            mSocket.on(PayUSocket.EVENT_CONNECT_ERROR, getEmitterListner(EventType.ON_CONNECT_ERROR));
            mSocket.connect();

            if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET,
                        TAG + INIT_SOCKET, null, merchantKey, txnId, null));
                showProgressDialog(activity);
            }
        }
    }    /**
     * Disconnect Socket connect after certain time period.
     * Here also disconnecting Socket and handler
     */
    private Runnable topLevelRunnable = new Runnable() {
        @Override
        public void run() {
            removeHandler();
            callFinishAPI();
        }
    };

    /**
     * dismissing progress dialog.
     */
    private void hideProgressDialog() {
        errorCounter = 0;
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            hideProgressDialog(activity);
    }

    private void checkConnectionAgain() {
        L.v("1 error counter " + errorCounter);
        if (errorCounter == 4) {
            // hideProgressDialog();
//            if (socketVerifyConfig != null)
            startLongPolling();
        }
    }

    /**
     * @param eventType
     * @return
     */
    private PayUEmitter.Listener getEmitterListner(final EventType eventType) {

        return new PayUEmitter.Listener() {
            @Override
            public void call(final Object... args) {
                try {
                    if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                switch (eventType) {

                                    case ON_CONNECT:
                                        if (mSocket != null) {
                                            if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                                analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, PayUNetworkConstant.SOCKET_CONNECTED, null, merchantKey, txnId, null));

                                            mSocket.on(PayUNetworkConstant.UPI_UPDATE_EVENT, getEmitterListner(EventType.ON_UPI_UPDATE));
                                            mSocket.on(PayUNetworkConstant.UPI_VERIFICATION_RESPONSE_EVENT, getEmitterListner(EventType.ON_UPI_VERIFICATION_RESPONSE));
                                            startPolling();
                                            if (handler != null && bottomLevelHandler != null && topLevelRunnable != null && bottomLevelRunnable != null) {
                                                handler.postDelayed(topLevelRunnable, payUSocketInfo.getSdkUpiPushExpiry() * 1000);
                                                bottomLevelHandler.postDelayed(bottomLevelRunnable, payUSocketInfo.getSdkUpiVerificationInterval() * 1000);
                                                L.v("Socket connected...");

                                            } else {
                                                L.v(this.getClass().getCanonicalName() + " Null Handler...");
                                            }
                                        } else {
                                            L.v(this.getClass().getCanonicalName() + " Socket is Null...");
                                        }

                                        break;

                                    case ON_CONNECT_ERROR:
                                        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, PayUNetworkConstant.SOCKET_CONNECTION_ERROR, null, merchantKey, txnId, null));

                                        errorCounter++;
                                      if (args != null && args.length > 0 && !(args[0] instanceof UnknownHostException)) {
                                            checkConnectionAgain();
                                        } else {
                                            if (!NetworkUtil.isNetworkAvailable(activity))
                                                sendingResultBack(null, EventType.ON_CONNECT_ERROR);
                                            else
                                                checkConnectionAgain();
                                        }
                                        break;


                                    case ON_DISCONNECT:
                                        L.v("Verify Handler Socket disconnected...");
                                        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, PayUNetworkConstant.SOCKET_DISCONNECTED, null, merchantKey, txnId, null));

                                        mSocket.close();
                                        break;

                                    case ON_UPI_UPDATE:
                                      if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, EventType.ON_UPI_UPDATE.name(), null, merchantKey, txnId, null));
                                        try {
                                            pollingVerify.disposePollingHandlerOnSocketResponse();
                                            JSONObject data = (JSONObject) args[0];
                                            L.v("onUpiUpdateEvent " + data);
                                            parseSocketResponse(data, EventType.ON_UPI_UPDATE);
                                        } catch (Exception e) {
                                            if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                                analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), EventType.ON_UPI_UPDATE.name(), e.getMessage(), null, merchantKey, txnId, null));
                                            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                                                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "OnUpiUpdate " + e.getMessage());
                                            L.v("Exception onUpiUpdate " + e.getMessage() + getClass().getCanonicalName());
                                        }
                                        break;

                                    case ON_UPI_VERIFICATION_RESPONSE:
                                      if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, EventType.ON_UPI_VERIFICATION_RESPONSE.name(), null, merchantKey, txnId, null));
                                        try {
                                            pollingVerify.disposePollingHandlerOnSocketResponse();
                                            JSONObject dataVerification = (JSONObject) args[0];
                                            L.v("onUpiVerificationResponseEvent " + dataVerification);
                                            parseSocketResponse(dataVerification, EventType.ON_UPI_VERIFICATION_RESPONSE);
                                        } catch (Exception e) {
                                            L.v("Exception onUpiVerification response  " + e.getMessage() + getClass().getCanonicalName());
                                            if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                                                analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), EventType.ON_UPI_VERIFICATION_RESPONSE.name(), e.getMessage(), null, merchantKey, txnId, null));
                                            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                                                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "onUpiVerificationResponseEvent " + e.getMessage());

                                        }

                                        break;
                                }
                            }

                        });
                    }
                } catch (Exception e) {
                    if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                        SocketData.SINGLETON.getPayUSocketEventListener()
                                .errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, SERVER_ERROR_MESSAGE_FINISH);
                    }
                }
            }
        };
    }

    /**
     * Starting Long polling.
     * We call this method when our socket connection failed.
     */
    private void startLongPolling() {
        pollingVerify = new PollingVerify();
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            pollingVerify.startLongPolling(activity, payUSocketInfo, iVerifyResponse, analytics, merchantKey, txnId);
    }

    /**
     * short polling in parallel of nimble socket
     */
    private void startPolling() {
        pollingVerify = new PollingVerify();
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            pollingVerify.startShortPolling(activity, merchantKey, txnId, analytics, payUSocketInfo, iVerifyResponse);
    }

    /**
     * Parsing socket response data.
     *
     * @param data
     */
    private void parseSocketResponse(JSONObject data, EventType eventType) {
        if (data != null) {
            if (data.has(PayUNetworkConstant.RESULT_KEY)) {
                try {
                    if (!PayUNetworkConstant.PENDING_STATUS_LIST.contains(data.getString(PayUNetworkConstant.RESULT_KEY).toLowerCase())) {
                        sendingResultBack(NetworkUtil.getBase64DecodedString(data.get(PayUNetworkConstant.RESULT_KEY).toString()), eventType);
                    }
                } catch (JSONException | IllegalArgumentException | OutOfMemoryError | NullPointerException | IOException e) {
                    if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                        SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "Parsing " + e.getMessage());
                    //   CustomBrowserData.SINGLETON.getPayuCustomBrowserCallback().onCBErrorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "Parsing " + e.getMessage());
                    L.v("JSONException " + e.getMessage());

                }
            } else {
                L.v("Result key not found in socket response...");
            }
        } else {
            sendingResultBack(null, null);
        }
    }

    /**
     * @param isFinished
     * @param response   Getting the Verify response after all the events done.
     *                   Calling the CustomBrowserListener from here.
     */
    @Override
    public void getVerifyResponse(boolean isFinished, String response) {
        L.v("getVerifyResponse   " + response);
        sendingResultBack(response, EventType.POLLING);

    }

    private synchronized void sendingResultBack(String response, EventType eventType) {
        String analyticsText = null;
        switch (eventType) {
            case POLLING:
                analyticsText = "completed_via_long_polling";
                break;
            case ON_UPI_UPDATE:
                analyticsText = "completed_via_update_event";
                break;
            case ON_UPI_VERIFICATION_RESPONSE:
                analyticsText = "completed_via_verification_response";
                break;
            case ON_CONNECT_ERROR:
                analyticsText = "socket_connection_error";
                break;

        }
        hideProgressDialog();
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, analyticsText, null, merchantKey, txnId, null));

        if (!TextUtils.isEmpty(response)) {
            String status = NetworkUtil.getTransactionStatus(response);

            if (status.equalsIgnoreCase(PayUNetworkPaymentConstants.FAILURE)) {
                if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                    SocketData.SINGLETON.getPayUSocketEventListener().getSocketResult(null, response, PayUNetworkPaymentConstants.FAILURE, false);
                memoryFreeUp();
            } else {
                if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                    SocketData.SINGLETON.getPayUSocketEventListener().getSocketResult(null, response, PayUNetworkPaymentConstants.SUCCESS, false);
                memoryFreeUp();
            }
        } else {
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().getSocketResult(null, response, PayUNetworkPaymentConstants.CANCEL, false);
             memoryFreeUp();
            if (fragmentListener != null) {
                fragmentListener.onPaymentFinished();
            } else if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
                activity.finish();

        }
        if (null != SocketData.SINGLETON.getPayUSocketEventListener()){
            SocketData.SINGLETON.setPayUSocketEventListener(null);
        }

    }

    /**
     * Calling upi/finish API.
     * When we didn't get the final response after the max time limit too, we call this API.
     */
    private void callFinishAPI() {
        PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();

        browserAsyncTaskData.setHttpMethod(PayUNetworkConstant.METHOD_TYPE_POST);
        JSONObject requestJsonObject = new JSONObject();
        try {
            requestJsonObject.put(PayUNetworkConstant.PAYU_ID_KEY, payUSocketInfo.getReferenceId());
        } catch (JSONException e) {
            //parseSocketResponse(null, null);
            L.v("JSONException " + e.getMessage());
        }
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed())
            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, PayUNetworkConstant.FINISH_USING_HTTP, null, merchantKey, txnId, null));


        browserAsyncTaskData.setPostData(String.valueOf(requestJsonObject));
        browserAsyncTaskData.setContentType(PayUNetworkConstant.CONTENT_TYPE_APPLICATION_JSON);
        browserAsyncTaskData.setUrl(payUSocketInfo.getPushServiceUrl() + PayUNetworkConstant.SOCKET_FINISH);
        new PayUNetworkAsyncTask(this, PayUNetworkConstant.FINISH).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);

    }

    public void memoryFreeUp() {
        disconnectSocket();
        removeHandler();
        //Kill Long Polling also as user has cancelled the transaction
        if (null != pollingVerify) {
            pollingVerify.disposePollingHandler();
            pollingVerify = null;
        }
    }

    @Override
    public void onTranscationCancelled() {
        memoryFreeUp();

        if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
            analytics.log(NetworkUtil.getLogMessage(activity.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET,
                    TAG + TRANSACTION_CANCELLED, null, merchantKey, txnId, null));
        }

        if (null != SocketData.SINGLETON.getPayUSocketEventListener())
            SocketData.SINGLETON.getPayUSocketEventListener().transactionCancelled();
        activity = null;
        INSTANCE = null;
    }

    enum EventType {
        ON_CONNECT,
        ON_CONNECT_ERROR,
        ON_DISCONNECT,
        ON_UPI_UPDATE,
        ON_UPI_VERIFICATION_RESPONSE,
        POLLING,
        FINISH
    }

    /*  */




}

