package com.payu.socketverification.socket;

import android.app.Activity;
import android.util.Log;
import android.view.View;

import com.payu.payuanalytics.analytics.factory.AnalyticsFactory;
import com.payu.payuanalytics.analytics.model.AnalyticsConfig;
import com.payu.payuanalytics.analytics.model.AnalyticsType;
import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.BuildConfig;
import com.payu.socketverification.bean.SocketData;
import com.payu.socketverification.interfaces.ActivityCallbacks;
import com.payu.socketverification.interfaces.FragmentListener;
import com.payu.socketverification.interfaces.PayUSocketEventListener;
import com.payu.socketverification.util.L;
import com.payu.socketverification.util.PayUNetworkConstant;
import com.payu.socketverification.util.PayUNetworkPaymentConstants;

import java.net.URISyntaxException;

import com.payu.socketverification.socketclient.client.PayUIO;
import com.payu.socketverification.socketclient.client.PayUSocket;
import com.payu.socketverification.socketclient.engineio.client.transports.PayUWebSocket;


/**
 * Created by Shahbaz
 * <p>
 * This class is used to create the socket once we get the event of GPay payment.
 * Socket is used to get the verification from PayU server regarding the transaction.
 * If socket fails, we would be working with https call.
 */
public class SocketHandler extends SocketBase implements ActivityCallbacks {
    private static volatile SocketHandler instance;
    private PayUSocket mSocket;
    private SocketPaymentResponse socketPaymentResponse;
    private Activity activity;
    private FragmentListener fragmentListener;

    private SocketHandler() {
    }

    /**
     * Creating instance of SocketHandler
     * Singleton
     *
     * @return SocketHandler
     */
    public static SocketHandler getInstance() {
        if (instance == null) {
            synchronized (SocketHandler.class) {
                if (instance == null)
                    instance = new SocketHandler();
                return instance;
            }
        }
        return instance;
    }

    /**
     * @param socketPaymentResponse
     * @param activity
     */
    public void createSocket(SocketPaymentResponse socketPaymentResponse, Activity activity, PayUSocketEventListener payUSocketEventListener) {
        try {
            PayUIO.Options opts = new PayUIO.Options();
            opts.reconnection = true;
            opts.reconnectionAttempts = 3;
            opts.transports = new String[]{PayUWebSocket.NAME};
            String url = socketPaymentResponse.getPushServiceUrl() + PayUNetworkConstant.UPI_RESPONSE_PARAM + socketPaymentResponse.getReferenceId();
            this.activity = activity;
            L.v("Socket URL > " + url);
            this.socketPaymentResponse = socketPaymentResponse;
            mSocket = PayUIO.socket(url, opts);
            SocketData.SINGLETON.setPayUSocketEventListener(payUSocketEventListener);
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().onSocketCreated();
        } catch (URISyntaxException e) {
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, PayUNetworkConstant.SOCKET_NOT_CREATED_MESSAGE);
            L.v("Exception " + e.getMessage());
        }


    }

    /**
     * @param socketPaymentResponse
     * @param activity
     */
    public void createSocket(SocketPaymentResponse socketPaymentResponse, Activity activity, PayUSocketEventListener payUSocketEventListener, FragmentListener fragmentListener) {
        try {
            PayUIO.Options opts = new PayUIO.Options();
            opts.reconnection = true;
            opts.reconnectionAttempts = 3;
            opts.transports = new String[]{PayUWebSocket.NAME};
            String url = socketPaymentResponse.getPushServiceUrl() + PayUNetworkConstant.UPI_RESPONSE_PARAM + socketPaymentResponse.getReferenceId();
            this.activity = activity;
            this.fragmentListener = fragmentListener;
            L.v("Socket URL > " + url);
            this.socketPaymentResponse = socketPaymentResponse;
            mSocket = PayUIO.socket(url, opts);
            SocketData.SINGLETON.setPayUSocketEventListener(payUSocketEventListener);
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().onSocketCreated();
        } catch (URISyntaxException e) {
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, PayUNetworkConstant.SOCKET_NOT_CREATED_MESSAGE);
            L.v("Exception " + e.getMessage());
        }


    }

    /**
     * @param merchantKey
     * @param txnId
     * @param payUSocketEventListener
     * @param customProgressDialogView
     */
    public void startSocketEvents(String merchantKey, String txnId, PayUSocketEventListener payUSocketEventListener, View customProgressDialogView) {
        L.v("Start Socket Events ");
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
            AnalyticsConfig analyticsConfig = getAnalyticsConfig(AnalyticsType.PAYU_ANALYTICS.name());
            PayUAnalytics payUAnalytics = (PayUAnalytics) new AnalyticsFactory(activity, analyticsConfig).getAnalyticsClass(AnalyticsType.PAYU_ANALYTICS);

            SocketData.SINGLETON.setPayUSocketEventListener(payUSocketEventListener);
            if (mSocket != null && null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                VerifyHandler.getInstance().setSocket(mSocket, activity, socketPaymentResponse, payUAnalytics, merchantKey, txnId, customProgressDialogView, fragmentListener);
                VerifyHandler.getInstance().initSocket();
            } else {
                if (null != payUSocketEventListener)
                    payUSocketEventListener.errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, PayUNetworkConstant.SOCKET_NULL_MESSAGE);
            }
        }
    }

    private AnalyticsConfig getAnalyticsConfig(String type) {
        AnalyticsConfig analyticsConfig = new AnalyticsConfig();
        analyticsConfig.setInitiatorIdentifier(BuildConfig.LIBRARY_PACKAGE_NAME.concat(type));
        return analyticsConfig;
    }

    @Override
    public void onTranscationCancelled() {

    }

    @Override
    public void onActivityResume(Activity reference) {

    }

    @Override
    public void onActivityPaused(Activity reference) {
        Log.v("PAYU", "Socket onActivityPaused");
//        if (null!=SocketBase.progressDialog && SocketBase.progressDialog.isShowing()){
//            SocketBase.progressDialog.dismiss();
//            SocketBase.progressDialog = null;
//        }
    }

    @Override
    public void onActivityStopped(Activity reference) {
        Log.v("PAYU", "Socket onActivityStopped");
        if (null != SocketBase.progressDialog && SocketBase.progressDialog.isShowing()) {
            SocketBase.progressDialog.dismiss();
            SocketBase.progressDialog = null;
        }
    }

    @Override
    public void onActivityCreated(Activity reference, PayUSocketEventListener payUSocketEventListener) {
        SocketData.SINGLETON.setPayUSocketEventListener(payUSocketEventListener);
    }

    /**
     * Free up the resources.
     *
     * @param reference
     */
    @Override
    public void onActivityDestroyed(Activity reference) {
        Log.v("PAYU", "Socket onActivityDestroyed");
        if (null != SocketBase.progressDialog && SocketBase.progressDialog.isShowing()) {
            SocketBase.progressDialog.dismiss();
            SocketBase.progressDialog = null;
        }
        SocketData.SINGLETON.setPayUSocketEventListener(null);
        VerifyHandler.getInstance().onTranscationCancelled();
        activity = null;
        instance = null;
    }
}
