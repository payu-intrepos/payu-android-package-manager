package com.payu.socketverification.socketclient.client;

/**
 * Acknowledgement.
 */
public interface PayUAck {

    public void call(Object... args);

}

