package com.payu.socketverification.socketclient.engineio.client;


import com.payu.socketverification.socketclient.emitter.PayUEmitter;
import com.payu.socketverification.socketclient.engineio.parser.PayUPacket;
import com.payu.socketverification.socketclient.engineio.parser.PayUParser;
import com.payu.socketverification.socketclient.thread.PayUEventThread;
import com.payu.socketverification.socketclient.utf8.PayUUTF8Exception;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.net.Proxy;
import java.util.Map;

public abstract class PayUTransport extends PayUEmitter {

    protected enum ReadyState {
        OPENING, OPEN, CLOSED, PAUSED;

        @Override
        public String toString() {
            return super.toString().toLowerCase();
        }
    }

    public static final String EVENT_OPEN = "open";
    public static final String EVENT_CLOSE = "close";
    public static final String EVENT_PACKET = "packet";
    public static final String EVENT_DRAIN = "drain";
    public static final String EVENT_ERROR = "error";
    public static final String EVENT_REQUEST_HEADERS = "requestHeaders";
    public static final String EVENT_RESPONSE_HEADERS = "responseHeaders";

    public boolean writable;
    public String name;
    public Map<String, String> query;

    protected boolean secure;
    protected boolean timestampRequests;
    protected int port;
    protected String path;
    protected String hostname;
    protected String timestampParam;
    protected SSLContext sslContext;
    protected PayUSocket socket;
    protected HostnameVerifier hostnameVerifier;
    protected Proxy proxy;
    protected String proxyLogin;
    protected String proxyPassword;

    protected ReadyState readyState;

    public PayUTransport(Options opts) {
        this.path = opts.path;
        this.hostname = opts.hostname;
        this.port = opts.port;
        this.secure = opts.secure;
        this.query = opts.query;
        this.timestampParam = opts.timestampParam;
        this.timestampRequests = opts.timestampRequests;
        this.sslContext = opts.sslContext;
        this.socket = opts.socket;
        this.hostnameVerifier = opts.hostnameVerifier;
        this.proxy = opts.proxy;
        this.proxyLogin = opts.proxyLogin;
        this.proxyPassword = opts.proxyPassword;
    }

    protected PayUTransport onError(String msg, Exception desc) {
        // TODO: handle error
        Exception err = new PayUEngineIOException(msg, desc);
        this.emit(EVENT_ERROR, err);
        return this;
    }

    public PayUTransport open() {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (PayUTransport.this.readyState == ReadyState.CLOSED || PayUTransport.this.readyState == null) {
                    PayUTransport.this.readyState = ReadyState.OPENING;
                    PayUTransport.this.doOpen();
                }
            }
        });
        return this;
    }

    public PayUTransport close() {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (PayUTransport.this.readyState == ReadyState.OPENING || PayUTransport.this.readyState == ReadyState.OPEN) {
                    PayUTransport.this.doClose();
                    PayUTransport.this.onClose();
                }
            }
        });
        return this;
    }

    public void send(final PayUPacket[] packets) {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (PayUTransport.this.readyState == ReadyState.OPEN) {
                    try {
                        PayUTransport.this.write(packets);
                    } catch (PayUUTF8Exception err) {
                        throw new RuntimeException(err);
                    }
                } else {
                    throw new RuntimeException("Transport not open");
                }
            }
        });
    }

    protected void onOpen() {
        this.readyState = ReadyState.OPEN;
        this.writable = true;
        this.emit(EVENT_OPEN);
    }

    protected void onData(String data) {
        this.onPacket(PayUParser.decodePacket(data));
    }

    protected void onData(byte[] data) {
        this.onPacket(PayUParser.decodePacket(data));
    }

    protected void onPacket(PayUPacket packet) {
        this.emit(EVENT_PACKET, packet);
    }

    protected void onClose() {
        this.readyState = ReadyState.CLOSED;
        this.emit(EVENT_CLOSE);
    }

    abstract protected void write(PayUPacket[] packets) throws PayUUTF8Exception;

    abstract protected void doOpen();

    abstract protected void doClose();


    public static class Options {

        public String hostname;
        public String path;
        public String timestampParam;
        public boolean secure;
        public boolean timestampRequests;
        public int port = -1;
        public int policyPort = -1;
        public Map<String, String> query;
        public SSLContext sslContext;
        public HostnameVerifier hostnameVerifier;
        protected PayUSocket socket;
        public Proxy proxy;
        public String proxyLogin;
        public String proxyPassword;
    }
}
