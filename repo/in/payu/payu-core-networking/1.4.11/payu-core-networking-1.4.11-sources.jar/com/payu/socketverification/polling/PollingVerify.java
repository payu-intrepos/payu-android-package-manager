package com.payu.socketverification.polling;

import static com.payu.socketverification.util.PayUNetworkAnalyticsConstant.TRANSACTION_CANCELLED;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.View;

import com.payu.payuanalytics.analytics.model.PayUAnalytics;
import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.bean.SocketData;
import com.payu.socketverification.core.PayUNetworkAsyncTask;
import com.payu.socketverification.interfaces.IVerifyResponse;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;
import com.payu.socketverification.socket.SocketBase;
import com.payu.socketverification.util.L;
import com.payu.socketverification.util.NetworkUtil;
import com.payu.socketverification.util.PayUNetworkConstant;
import com.payu.socketverification.util.PayUNetworkPaymentConstants;
import com.payu.socketverification.util.PayUSocketInfo;
import com.payu.socketverification.widgets.PayUProgressDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;


/**
 * ]
 * Implemeing long polling through this class.
 * calling server call every upiServicePollInterval time. It's configuration from backend. If time exceeds, then call /upi/finish API.
 */
public class PollingVerify extends SocketBase implements PayuNetworkAsyncTaskInterface {
    private Activity reference;
    private IVerifyResponse iVerifyResponse;
    private PayUSocketInfo socketPayuInfo;
    private PayuNetworkAsyncTaskInterface customBrowserAsyncTaskInterface;
    private Handler handler;
    private Handler handlerLongPolling;
    private PayUProgressDialog progressDialog;
    private View progressDialogCustomView;
    private PayUAnalytics analytics;
    private int forcedCounterNeeded = -1;
    private int currentVerifyCounter = 1;
    private String merchantKey;
    private String txnId;

    /**
     * It will start the long polling. calling server call every upiServicePollInterval time. It's configuration from backend/
     *
     * @param activity
     * @param socketResponsePayUInfo
     * @param iVerifyResponse
     */
    public void startLongPolling(Activity activity, PayUSocketInfo socketResponsePayUInfo, IVerifyResponse iVerifyResponse, PayUAnalytics cbAnalytics, String merchantKey, String txnId) {
        L.v("Start Long polling....");
        this.analytics = cbAnalytics;
        this.iVerifyResponse = iVerifyResponse;
        reference = activity;
        this.socketPayuInfo = socketResponsePayUInfo;
        this.merchantKey = merchantKey;
        this.txnId = txnId;
        handler = new Handler();
        forcedCounterNeeded = getForcedCounterNeedHandler();
        handlerLongPolling = new Handler();
        customBrowserAsyncTaskInterface = this;
        handler.postDelayed(topLevelRunnable, Long.valueOf(socketResponsePayUInfo.getSdkUpiPushExpiry()) * 1000);
//        showProgressDialog();
        if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
            analyticsLogging(PayUNetworkConstant.SOCKET_DISCONNECTED, merchantKey, txnId);

        callAPI(PayUNetworkConstant.VERIFY);
    }

    public void startShortPolling(Activity activity, String merchantKey, String txnId, PayUAnalytics cbAnalytics, PayUSocketInfo socketResponsePayUInfo, IVerifyResponse iVerifyResponse) {
        L.v("Start short polling....");
        this.analytics = cbAnalytics;
        this.iVerifyResponse = iVerifyResponse;
        reference = activity;
        this.socketPayuInfo = socketResponsePayUInfo;
        this.merchantKey = merchantKey;
        this.txnId = txnId;
        forcedCounterNeeded = getForcedCounterNeedHandler();
        handlerLongPolling = new Handler();
        customBrowserAsyncTaskInterface = this;
        handlerLongPolling.postDelayed(longPollingRunnable, Long.valueOf(socketResponsePayUInfo.getUpiServicePollInterval()) * 1000);
        if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
            analyticsLogging(PayUNetworkConstant.SOCKET_SHORT_POLLING, merchantKey, txnId);

    }

    public int getForcedCounterNeedHandler() {

        int forcedCounter = 0;

        try {
            forcedCounter = (int) ((socketPayuInfo.getSdkUpiVerificationInterval()) / (socketPayuInfo.getUpiServicePollInterval()));
        } catch (Exception e) {
            L.v("socketPayuInfo" + e.getMessage());
        }

        return forcedCounter;
    }

    /**
     * @param type This method calls webservice for http verify call or finish call.
     *             type -> 1. VERIFY   2.FINISH
     *             Call finish API when we didn't get result after the max time limit.
     */
    private void callAPI(String type) {
        PayUNetworkAsyncTaskData browserAsyncTaskData = new PayUNetworkAsyncTaskData();
        browserAsyncTaskData.setHttpMethod(PayUNetworkConstant.METHOD_TYPE_POST);
        JSONObject requestJsonObject = new JSONObject();
        try {
            requestJsonObject.put(PayUNetworkConstant.PAYU_ID_KEY, socketPayuInfo.getReferenceId());

        } catch (JSONException e) {
            L.v(e.getMessage());
            if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "Parsing " + e.getMessage());
            disposePollingHandler();
            if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
                analytics.log(NetworkUtil.getLogMessage(reference.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, PayUNetworkConstant.ERROR + PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE + "_Parsing " + e.getMessage(), null, merchantKey, txnId, null));

        }

        if (type.equals(PayUNetworkConstant.VERIFY)) {
            // browserAsyncTaskData.setUrl("https://nimbletest.payu.in:5032/upi/verify");
            browserAsyncTaskData.setUrl(socketPayuInfo.getPushServiceUrl() + PayUNetworkConstant.SOCKET_VERIFY);
            L.v("Force Count Needed " + forcedCounterNeeded);
            L.v("Force Count current " + currentVerifyCounter);
            if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
                analyticsLogging(PayUNetworkConstant.SOCKET_VERIFY, merchantKey, txnId);

            if (currentVerifyCounter == forcedCounterNeeded) {
                currentVerifyCounter = 1;
                try {
                    requestJsonObject.put(PayUNetworkConstant.FORCE, true);
                } catch (JSONException e) {
                    if (null != SocketData.SINGLETON.getPayUSocketEventListener()) {
                        SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, "Verify Polling " + e.getMessage());
                    }
                    L.v(e.getMessage());
                    disposePollingHandler();
                }
            } else {
                try {
                    requestJsonObject.put(PayUNetworkConstant.FORCE, false);
                } catch (JSONException e) {
                    L.v(e.getMessage());
                }
                currentVerifyCounter++;
            }

        } else {
            if (reference != null && !reference.isFinishing() && !reference.isDestroyed()) {
                analyticsLogging(PayUNetworkConstant.FINISH_USING_HTTP, merchantKey, txnId);
            }
            browserAsyncTaskData.setUrl(socketPayuInfo.getPushServiceUrl() + PayUNetworkConstant.SOCKET_FINISH);
        }
        if (NetworkUtil.isNetworkAvailable(reference.getBaseContext())) {
            browserAsyncTaskData.setPostData(String.valueOf(requestJsonObject));
            browserAsyncTaskData.setContentType(PayUNetworkConstant.CONTENT_TYPE_APPLICATION_JSON);
            new PayUNetworkAsyncTask(customBrowserAsyncTaskInterface, type).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, browserAsyncTaskData);
        }
// 4 is ket to check 3 times. i.e 15 second of delay.
        else if (type.equals(PayUNetworkConstant.VERIFY) && currentVerifyCounter <= 4) {
          handlerLongPolling.postDelayed(longPollingRunnable, socketPayuInfo.getUpiServicePollInterval() * 1000);
        } else {
          if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
            analyticsLogging(PayUNetworkPaymentConstants.INTERNET_ERROR_MESSAGE, merchantKey, txnId);
          SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.INTERNET_ERROR, PayUNetworkPaymentConstants.INTERNET_ERROR_MESSAGE);
        }
    }


    private void analyticsLogging(String value, String merchantKey, String txnId) {
        try {
            analytics.log(NetworkUtil.getLogMessage(reference.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, value, null, merchantKey, txnId, null));
        } catch (Exception e) {
            L.v("Class analyticsLogging: key" + PayUNetworkConstant.UPI_SOCKET + " value" + value + " " + e.getMessage());
        }
    }


    /**
     * @param payUAsynTaskResponse
     * @param webServiceType
     */
    @Override
    public void onPayuNetworkAsyncTaskResponse(String payUAsynTaskResponse, String webServiceType) {

        if (iVerifyResponse != null) {
            if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
                analytics.log(NetworkUtil.getLogMessage(reference.getApplicationContext(), PayUNetworkConstant.UPI_SOCKET, "webServiceType_" + webServiceType + "_Response_" + payUAsynTaskResponse, null, merchantKey, txnId, null));
            //  delayThenHit();
            switch (webServiceType) {
                case PayUNetworkConstant.VERIFY:
                    try {
                        if (payUAsynTaskResponse != null) {
                            JSONObject jsonObject = new JSONObject(payUAsynTaskResponse);
                            if (jsonObject.has(PayUNetworkConstant.RESULT_KEY)) {
                                if (PayUNetworkConstant.PENDING_STATUS_LIST.contains(jsonObject.getString(PayUNetworkConstant.RESULT_KEY).toLowerCase())) {

                                    if (longPollingRunnable != null && handlerLongPolling != null)
                                        handlerLongPolling.postDelayed(longPollingRunnable, socketPayuInfo.getUpiServicePollInterval() * 1000);

                                } else if (iVerifyResponse != null) {
                                    iVerifyResponse.getVerifyResponse(true, NetworkUtil.getBase64DecodedString(jsonObject.get(PayUNetworkConstant.RESULT_KEY).toString()));
                                    disposePollingHandler();
                                }
                            } else {
                                if (longPollingRunnable != null && handlerLongPolling != null)
                                    handlerLongPolling.postDelayed(longPollingRunnable, socketPayuInfo.getUpiServicePollInterval() * 1000);

                            }
                        }
                    } catch (JSONException | IllegalArgumentException | OutOfMemoryError | NullPointerException | IOException e) {
                        if (null != SocketData.SINGLETON.getPayUSocketEventListener())
                            SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, e.getMessage());
                        L.v("Jsonexception " + e.getMessage());
                        disposePollingHandler();
                    }
                    break;

                case PayUNetworkConstant.FINISH:
                    currentVerifyCounter = 1;
                    L.v("Finish response " + payUAsynTaskResponse);

                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject(payUAsynTaskResponse);
                        if (jsonObject.has(PayUNetworkConstant.RESULT_KEY)) {
                            if (PayUNetworkConstant.PENDING_STATUS_LIST.contains(jsonObject.getString(PayUNetworkConstant.RESULT_KEY).toLowerCase())) {

                                if (longPollingRunnable != null && handlerLongPolling != null)
                                    handlerLongPolling.postDelayed(longPollingRunnable, socketPayuInfo.getUpiServicePollInterval() * 1000);

                            } else if (iVerifyResponse != null) {
                                iVerifyResponse.getVerifyResponse(true, NetworkUtil.getBase64DecodedString(jsonObject.get(PayUNetworkConstant.RESULT_KEY).toString()));
                                disposePollingHandler();
                            }
                        }
                    } catch (JSONException | IllegalArgumentException | OutOfMemoryError | NullPointerException | IOException e) {
                        SocketData.SINGLETON.getPayUSocketEventListener().errorReceived(PayUNetworkPaymentConstants.SOCKET_CONNECTION_ISSUE_CODE, PayUNetworkPaymentConstants.SERVER_ERROR_MESSAGE_FINISH);
                        L.v("Jsonexception " + e.getMessage());
                    }

                    disposePollingHandler();
                    if (null != reference && !reference.isFinishing() && !reference.isDestroyed()) {
                        reference.finish();
                    }
                    break;
            }
        } else {
            if (reference != null && !reference.isFinishing() && !reference.isDestroyed())
                analyticsLogging("iVerifyResponse " + (iVerifyResponse == null), merchantKey, txnId);

        }
    }

    /**
     * Showing progress dialog while doing network task
     */

    private void showProgressDialog() {
        showProgressDialog(reference);
    }

    /**
     * dismissing progress dialog.
     */
    private void hideProgressDialog() {
        hideProgressDialog(reference);

    }

    /**
     * removing the handler and make it null to free the memory.
     */
    public void disposePollingHandler() {
        if (handler != null && topLevelRunnable != null) {
            handler.removeCallbacks(topLevelRunnable);
            handler = null;
            topLevelRunnable = null;
        }
        if (handlerLongPolling != null && longPollingRunnable != null) {
            handlerLongPolling.removeCallbacks(longPollingRunnable);
            handlerLongPolling = null;
            longPollingRunnable = null;
        }
    }    /**
     * Call upi/finish API when max time limit exceeds.
     */
    private Runnable topLevelRunnable = new Runnable() {
        @Override
        public void run() {
            callAPI(PayUNetworkConstant.FINISH);
        }
    };

    @Override
    public void onTranscationCancelled() {
        analyticsLogging(TRANSACTION_CANCELLED, merchantKey, txnId);
        disposePollingHandler();
        if (null != SocketData.SINGLETON.getPayUSocketEventListener())
            SocketData.SINGLETON.getPayUSocketEventListener().transactionCancelled();

    }
    private Runnable longPollingRunnable = new Runnable() {
        @Override
        public void run() {
            L.v("Post Delayed... ");
            callAPI(PayUNetworkConstant.VERIFY);


        }
    };

    /**
     * removing the handler and make it null to free the memory in case of on UPI Socket response comes.
     */
    public void disposePollingHandlerOnSocketResponse() {
        disposePollingHandler();
        if (iVerifyResponse != null) iVerifyResponse = null;
    }
}
