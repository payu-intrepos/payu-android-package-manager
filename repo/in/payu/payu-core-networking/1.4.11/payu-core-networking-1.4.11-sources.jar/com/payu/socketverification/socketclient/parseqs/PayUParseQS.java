package com.payu.socketverification.socketclient.parseqs;


import com.payu.socketverification.socketclient.global.PayUGlobal;

import java.util.HashMap;
import java.util.Map;

public class PayUParseQS {

    private PayUParseQS() {}

    public static String encode(Map<String, String> obj) {
        StringBuilder str = new StringBuilder();
        for (Map.Entry<String, String> entry : obj.entrySet()) {
            if (str.length() > 0) str.append("&");
            str.append(PayUGlobal.encodeURIComponent(entry.getKey())).append("=")
                    .append(PayUGlobal.encodeURIComponent(entry.getValue()));
        }
        return str.toString();
    }

    public static Map<String, String> decode(String qs) {
        Map<String, String> qry = new HashMap<String, String>();
        String[] pairs = qs.split("&");
        for (String _pair : pairs) {
            String[] pair = _pair.split("=");
            qry.put(PayUGlobal.decodeURIComponent(pair[0]),
                    pair.length > 1 ? PayUGlobal.decodeURIComponent(pair[1]) : "");
        }
        return qry;
    }
}
