package com.payu.socketverification.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.payu.socketverification.util.PayUNetworkConstant;

/**
 * Created by shahbaz.ahmmod
 * <p>
 * Simple bean to contain network api call data.
 * it contains http method, url, postData, and content type.
 * default method is GET and contentType is HTTP_URLENCODED.
 */

public class PayUNetworkAsyncTaskData implements Parcelable {

    public static final Creator<PayUNetworkAsyncTaskData> CREATOR = new Creator<PayUNetworkAsyncTaskData>() {
        @Override
        public PayUNetworkAsyncTaskData createFromParcel(Parcel in) {
            return new PayUNetworkAsyncTaskData(in);
        }

        @Override
        public PayUNetworkAsyncTaskData[] newArray(int size) {
            return new PayUNetworkAsyncTaskData[size];
        }
    };
    private String httpMethod;
    private String url;
    private String postData;
    private String contentType;

    public PayUNetworkAsyncTaskData(Parcel in) {
        httpMethod = in.readString();
        url = in.readString();
        postData = in.readString();
        contentType = in.readString();
    }

    public PayUNetworkAsyncTaskData() {
        this.httpMethod = "GET";
        this.contentType = PayUNetworkConstant.HTTP_URLENCODED;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPostData() {
        return postData;
    }

    public void setPostData(String postData) {
        this.postData = postData;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(httpMethod);
        parcel.writeString(url);
        parcel.writeString(postData);
        parcel.writeString(contentType);
    }
}
