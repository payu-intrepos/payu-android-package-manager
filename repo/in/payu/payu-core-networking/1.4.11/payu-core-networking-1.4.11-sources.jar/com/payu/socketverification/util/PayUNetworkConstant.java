package com.payu.socketverification.util;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public interface PayUNetworkConstant {

    // Generic Async task
    String HTTP_URLENCODED = "application/x-www-form-urlencoded";

    // command for API
    String DEVICE_ANALYTICS = "DeviceAnalytics"; // device analytics command for API


    int VERIFY_HTTP_TIMEOUT = 120000;
    int SOCKET_NULL = 1004;
    //Error Messages
    String SOCKET_NOT_CREATED_MESSAGE = "Socket is not created ";
    String SOCKET_NULL_MESSAGE = "Socket is null, please create socket before calling startSocketEvents()";


    //Payment Related Details Api call

    // for bundle
    @Deprecated
    String PAYMENT_DEFAULT_PARAMS = "payment_default_params";

    String UPI_VERFICATION_EVENT = "upi-verification";
    String UPI_UPDATE_EVENT = "upi-update";
    String UPI_VERIFICATION_RESPONSE_EVENT = "upi-verification-response";
    String VERIFY = "VERIFY";
    String SOCKET_FINISH = "/upi/finish";
    String METHOD_TYPE_POST = "POST";
    String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    String PAYU_ID_KEY = "payuId";
    String RESULT_KEY = "result";
    String FINISH = "FINISH";
    String UPI_RESPONSE_PARAM = "/upi-response?payuId=";
    List<String> PENDING_STATUS_LIST = new ArrayList<>(Arrays.asList("pending", "rnf", "no data found"));
    String SOCKET_VERIFY = "/upi/verify";
    //UPI Socket Analytics
    String UPI_SOCKET = "upi_socket";
    String FINISH_USING_HTTP = "finish_using_http";
    String SOCKET_CONNECTED = "socket_connected";
    String SOCKET_CONNECTION_ERROR = "socket_connection_error";
    String SOCKET_DISCONNECTED = "socket_disconnected";
    String SOCKET_SHORT_POLLING = "socket_short_polling";
    String FORCE = "force";
    String ERROR = "error";

    String ASYNC_TASK_ILLEGAL_STATE_EXCEPTION_MESSAGE_1 = "Cannot execute task:"
            + " the task is already running.";

    String ASYNC_TASK_ILLEGAL_STATE_EXCEPTION_MESSAGE_2 = "Cannot execute task:"
            + " the task has already been executed "
            + "(a task can be executed only once)";

}
