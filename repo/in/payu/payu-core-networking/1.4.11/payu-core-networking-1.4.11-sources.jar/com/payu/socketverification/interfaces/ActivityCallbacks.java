package com.payu.socketverification.interfaces;

import android.app.Activity;


public interface ActivityCallbacks {
    void onActivityResume(Activity reference);

    void onActivityPaused(Activity reference);

    void onActivityStopped(Activity reference);

    void onActivityCreated(Activity reference, PayUSocketEventListener payUSocketEventListener);

    void onActivityDestroyed(Activity reference);
}
