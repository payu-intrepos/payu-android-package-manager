package com.payu.socketverification.util;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.vectordrawable.graphics.drawable.Animatable2Compat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;

import com.payu.socketverification.R;

public class UIUtils {
    public static void applyLoopingAnimatedVectorDrawable(ImageView ivProgress, Context context) {
        final AnimatedVectorDrawableCompat anim = AnimatedVectorDrawableCompat.create(context, R.drawable.payu_loader);
        ivProgress.setImageDrawable(anim);

        if (anim != null) {
            anim.registerAnimationCallback(new Animatable2Compat.AnimationCallback() {
                @Override
                public void onAnimationEnd(Drawable drawable) {
                    anim.start();
                }
            });
            anim.start();
        }
    }
}
