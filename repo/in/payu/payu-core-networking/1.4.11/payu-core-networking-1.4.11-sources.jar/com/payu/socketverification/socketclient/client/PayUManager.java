package com.payu.socketverification.socketclient.client;

import com.payu.socketverification.socketclient.backo.PayUBackoff;
import com.payu.socketverification.socketclient.emitter.PayUEmitter;
import com.payu.socketverification.socketclient.parser.PayUPacket;
import com.payu.socketverification.socketclient.parser.PayUParser;
import com.payu.socketverification.socketclient.thread.PayUEventThread;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.net.URI;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manager class represents a connection to a given Socket.IO server.
 */
public class PayUManager extends PayUEmitter {

    private static final Logger logger = Logger.getLogger(PayUManager.class.getName());

    /*package*/ enum ReadyState {
        CLOSED, OPENING, OPEN
    }

    /**
     * Called on a successful connection.
     */
    public static final String EVENT_OPEN = "open";

    /**
     * Called on a disconnection.
     */
    public static final String EVENT_CLOSE = "close";

    public static final String EVENT_PACKET = "packet";
    public static final String EVENT_ERROR = "error";

    /**
     * Called on a connection error.
     */
    public static final String EVENT_CONNECT_ERROR = "connect_error";

    /**
     * Called on a connection timeout.
     */
    public static final String EVENT_CONNECT_TIMEOUT = "connect_timeout";

    /**
     * Called on a successful reconnection.
     */
    public static final String EVENT_RECONNECT = "reconnect";

    /**
     * Called on a reconnection attempt error.
     */
    public static final String EVENT_RECONNECT_ERROR = "reconnect_error";

    public static final String EVENT_RECONNECT_FAILED = "reconnect_failed";

    public static final String EVENT_RECONNECT_ATTEMPT = "reconnect_attempt";

    public static final String EVENT_RECONNECTING = "reconnecting";

    public static final String EVENT_PING = "ping";

    public static final String EVENT_PONG = "pong";

    /**
     * Called when a new transport is created. (experimental)
     */
    public static final String EVENT_TRANSPORT = Engine.EVENT_TRANSPORT;

    /*package*/ static SSLContext defaultSSLContext;
    /*package*/ static HostnameVerifier defaultHostnameVerifier;

    /*package*/ ReadyState readyState;

    private boolean _reconnection;
    private boolean skipReconnect;
    private boolean reconnecting;
    private boolean encoding;
    private int _reconnectionAttempts;
    private long _reconnectionDelay;
    private long _reconnectionDelayMax;
    private double _randomizationFactor;
    private PayUBackoff backoff;
    private long _timeout;
    private Set<PayUSocket> connecting = new HashSet<PayUSocket>();
    private Date lastPing;
    private URI uri;
    private List<PayUPacket> packetBuffer;
    private Queue<PayUOn.Handle> subs;
    private Options opts;
    /*package*/ com.payu.socketverification.socketclient.engineio.client.PayUSocket engine;
    private PayUParser.Encoder encoder;
    private PayUParser.Decoder decoder;

    /**
     * This HashMap can be accessed from outside of EventThread.
     */
    /*package*/ ConcurrentHashMap<String, PayUSocket> nsps;


    public PayUManager() {
        this(null, null);
    }

    public PayUManager(URI uri) {
        this(uri, null);
    }

    public PayUManager(Options opts) {
        this(null, opts);
    }

    public PayUManager(URI uri, Options opts) {
        if (opts == null) {
            opts = new Options();
        }
        if (opts.path == null) {
            opts.path = "/socket.io";
        }
        if (opts.sslContext == null) {
            opts.sslContext = defaultSSLContext;
        }
        if (opts.hostnameVerifier == null) {
            opts.hostnameVerifier = defaultHostnameVerifier;
        }
        this.opts = opts;
        this.nsps = new ConcurrentHashMap<String, PayUSocket>();
        this.subs = new LinkedList<PayUOn.Handle>();
        this.reconnection(opts.reconnection);
        this.reconnectionAttempts(opts.reconnectionAttempts != 0 ? opts.reconnectionAttempts : Integer.MAX_VALUE);
        this.reconnectionDelay(opts.reconnectionDelay != 0 ? opts.reconnectionDelay : 1000);
        this.reconnectionDelayMax(opts.reconnectionDelayMax != 0 ? opts.reconnectionDelayMax : 5000);
        this.randomizationFactor(opts.randomizationFactor != 0.0 ? opts.randomizationFactor : 0.5);
        this.backoff = new PayUBackoff()
                .setMin(this.reconnectionDelay())
                .setMax(this.reconnectionDelayMax())
                .setJitter(this.randomizationFactor());
        this.timeout(opts.timeout);
        this.readyState = ReadyState.CLOSED;
        this.uri = uri;
        this.encoding = false;
        this.packetBuffer = new ArrayList<PayUPacket>();
        this.encoder = new PayUParser.Encoder();
        this.decoder = new PayUParser.Decoder();
    }

    private void emitAll(String event, Object... args) {
        this.emit(event, args);
        for (PayUSocket socket : this.nsps.values()) {
            socket.emit(event, args);
        }
    }

    /**
     * Update `socket.id` of all sockets
     */
    private void updateSocketIds() {
        for (PayUSocket socket : this.nsps.values()) {
            socket.id = this.engine.id();
        }
    }

    public boolean reconnection() {
        return this._reconnection;
    }

    public PayUManager reconnection(boolean v) {
        this._reconnection = v;
        return this;
    }

    public int reconnectionAttempts() {
        return this._reconnectionAttempts;
    }

    public PayUManager reconnectionAttempts(int v) {
        this._reconnectionAttempts = v;
        return this;
    }

    public final long reconnectionDelay() {
        return this._reconnectionDelay;
    }

    public PayUManager reconnectionDelay(long v) {
        this._reconnectionDelay = v;
        if (this.backoff != null) {
            this.backoff.setMin(v);
        }
        return this;
    }

    public final double randomizationFactor() {
        return this._randomizationFactor;
    }

    public PayUManager randomizationFactor(double v) {
        this._randomizationFactor = v;
        if (this.backoff != null) {
            this.backoff.setJitter(v);
        }
        return this;
    }

    public final long reconnectionDelayMax() {
        return this._reconnectionDelayMax;
    }

    public PayUManager reconnectionDelayMax(long v) {
        this._reconnectionDelayMax = v;
        if (this.backoff != null) {
            this.backoff.setMax(v);
        }
        return this;
    }

    public long timeout() {
        return this._timeout;
    }

    public PayUManager timeout(long v) {
        this._timeout = v;
        return this;
    }

    private void maybeReconnectOnOpen() {
        // Only try to reconnect if it's the first time we're connecting
        if (!this.reconnecting && this._reconnection && this.backoff.getAttempts() == 0) {
            this.reconnect();
        }
    }

    public PayUManager open(){
        return open(null);
    }

    /**
     * Connects the client.
     *
     * @param fn callback.
     * @return a reference to this object.
     */
    public PayUManager open(final OpenCallback fn) {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                logger.fine(String.format("readyState %s", PayUManager.this.readyState));
                if (PayUManager.this.readyState == ReadyState.OPEN || PayUManager.this.readyState == ReadyState.OPENING) return;

                logger.fine(String.format("opening %s", PayUManager.this.uri));
                PayUManager.this.engine = new Engine(PayUManager.this.uri, PayUManager.this.opts);
                final com.payu.socketverification.socketclient.engineio.client.PayUSocket socket = PayUManager.this.engine;
                final PayUManager self = PayUManager.this;
                PayUManager.this.readyState = ReadyState.OPENING;
                PayUManager.this.skipReconnect = false;

                // propagate transport event.
                socket.on(Engine.EVENT_TRANSPORT, new Listener() {
                    @Override
                    public void call(Object... args) {
                        self.emit(PayUManager.EVENT_TRANSPORT, args);
                    }
                });

                final PayUOn.Handle openSub = PayUOn.on(socket, Engine.EVENT_OPEN, new Listener() {
                    @Override
                    public void call(Object... objects) {
                        self.onopen();
                        if (fn != null) fn.call(null);
                    }
                });

                PayUOn.Handle errorSub = PayUOn.on(socket, Engine.EVENT_ERROR, new Listener() {
                    @Override
                    public void call(Object... objects) {
                        Object data = objects.length > 0 ? objects[0] : null;
                        logger.fine("connect_error");
                        self.cleanup();
                        self.readyState = ReadyState.CLOSED;
                        self.emitAll(EVENT_CONNECT_ERROR, data);
                        if (fn != null) {
                            Exception err = new PayUSocketIOException("Connection error",
                                    data instanceof Exception ? (Exception) data : null);
                            fn.call(err);
                        } else {
                            // Only do this if there is no fn to handle the error
                            self.maybeReconnectOnOpen();
                        }
                    }
                });

                if (PayUManager.this._timeout >= 0) {
                    final long timeout = PayUManager.this._timeout;
                    logger.fine(String.format("connection attempt will timeout after %d", timeout));

                    final Timer timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            PayUEventThread.exec(new Runnable() {
                                @Override
                                public void run() {
                                    logger.fine(String.format("connect attempt timed out after %d", timeout));
                                    openSub.destroy();
                                    socket.close();
                                    socket.emit(Engine.EVENT_ERROR, new PayUSocketIOException("timeout"));
                                    self.emitAll(EVENT_CONNECT_TIMEOUT, timeout);
                                }
                            });
                        }
                    }, timeout);

                    PayUManager.this.subs.add(new PayUOn.Handle() {
                        @Override
                        public void destroy() {
                            timer.cancel();
                        }
                    });
                }

                PayUManager.this.subs.add(openSub);
                PayUManager.this.subs.add(errorSub);

                PayUManager.this.engine.open();
            }
        });
        return this;
    }

    private void onopen() {
        logger.fine("open");

        this.cleanup();

        this.readyState = ReadyState.OPEN;
        this.emit(EVENT_OPEN);

        final com.payu.socketverification.socketclient.engineio.client.PayUSocket socket = this.engine;
        this.subs.add(PayUOn.on(socket, Engine.EVENT_DATA, new Listener() {
            @Override
            public void call(Object... objects) {
                Object data = objects[0];
                if (data instanceof String) {
                    PayUManager.this.ondata((String)data);
                } else if (data instanceof byte[]) {
                    PayUManager.this.ondata((byte[])data);
                }
            }
        }));
        this.subs.add(PayUOn.on(socket, Engine.EVENT_PING, new Listener() {
            @Override
            public void call(Object... objects) {
                PayUManager.this.onping();
            }
        }));
        this.subs.add(PayUOn.on(socket, Engine.EVENT_PONG, new Listener() {
            @Override
            public void call(Object... objects) {
                PayUManager.this.onpong();
            }
        }));
        this.subs.add(PayUOn.on(socket, Engine.EVENT_ERROR, new Listener() {
            @Override
            public void call(Object... objects) {
                PayUManager.this.onerror((Exception)objects[0]);
            }
        }));
        this.subs.add(PayUOn.on(socket, Engine.EVENT_CLOSE, new Listener() {
            @Override
            public void call(Object... objects) {
                PayUManager.this.onclose((String)objects[0]);
            }
        }));
        this.subs.add(PayUOn.on(this.decoder, PayUParser.Decoder.EVENT_DECODED, new Listener() {
            @Override
            public void call(Object... objects) {
                PayUManager.this.ondecoded((PayUPacket) objects[0]);
            }
        }));
    }

    private void onping() {
        this.lastPing = new Date();
        this.emitAll(EVENT_PING);
    }

    private void onpong() {
        this.emitAll(EVENT_PONG,
                null != this.lastPing ? new Date().getTime() - this.lastPing.getTime() : 0);
    }

    private void ondata(String data) {
        this.decoder.add(data);
    }

    private void ondata(byte[] data) {
        this.decoder.add(data);
    }

    private void ondecoded(PayUPacket packet) {
        this.emit(EVENT_PACKET, packet);
    }

    private void onerror(Exception err) {
        logger.log(Level.FINE, "error", err);
        this.emitAll(EVENT_ERROR, err);
    }

    /**
     * Initializes {@link PayUSocket} instances for each namespaces.
     *
     * @param nsp namespace.
     * @return a socket instance for the namespace.
     */
    public PayUSocket socket(String nsp) {
        PayUSocket socket = this.nsps.get(nsp);
        if (socket == null) {
            socket = new PayUSocket(this, nsp);
            PayUSocket _socket = this.nsps.putIfAbsent(nsp, socket);
            if (_socket != null) {
                socket = _socket;
            } else {
                final PayUManager self = this;
                final PayUSocket s = socket;
                socket.on(PayUSocket.EVENT_CONNECTING, new Listener() {
                    @Override
                    public void call(Object... args) {
                        self.connecting.add(s);
                    }
                });
                socket.on(PayUSocket.EVENT_CONNECT, new Listener() {
                    @Override
                    public void call(Object... objects) {
                        s.id = self.engine.id();
                    }
                });
            }
        }
        return socket;
    }

    /*package*/ void destroy(PayUSocket socket) {
        this.connecting.remove(socket);
        if (!this.connecting.isEmpty()) return;

        this.close();
    }

    /*package*/ void packet(PayUPacket packet) {
        logger.fine(String.format("writing packet %s", packet));
        final PayUManager self = this;

        if (!self.encoding) {
            self.encoding = true;
            this.encoder.encode(packet, new PayUParser.Encoder.Callback() {
                @Override
                public void call(Object[] encodedPackets) {
                    for (Object packet : encodedPackets) {
                        if (packet instanceof String) {
                            self.engine.write((String)packet);
                        } else if (packet instanceof byte[]) {
                            self.engine.write((byte[])packet);
                        }
                    }
                    self.encoding = false;
                    self.processPacketQueue();
                }
            });
        } else {
            self.packetBuffer.add(packet);
        }
    }

    private void processPacketQueue() {
        if (!this.packetBuffer.isEmpty() && !this.encoding) {
            PayUPacket pack = this.packetBuffer.remove(0);
            this.packet(pack);
        }
    }

    private void cleanup() {
        logger.fine("cleanup");

        PayUOn.Handle sub;
        while ((sub = this.subs.poll()) != null) sub.destroy();

        this.packetBuffer.clear();
        this.encoding = false;
        this.lastPing = null;

        this.decoder.destroy();
    }

    /*package*/ void close() {
        logger.fine("disconnect");
        this.skipReconnect = true;
        this.reconnecting = false;
        if (this.readyState != ReadyState.OPEN) {
            // `onclose` will not fire because
            // an open event never happened
            this.cleanup();
        }
        this.backoff.reset();
        this.readyState = ReadyState.CLOSED;
        if (this.engine != null) {
            this.engine.close();
        }
    }

    private void onclose(String reason) {
        logger.fine("onclose");
        this.cleanup();
        this.backoff.reset();
        this.readyState = ReadyState.CLOSED;
        this.emit(EVENT_CLOSE, reason);

        if (this._reconnection && !this.skipReconnect) {
            this.reconnect();
        }
    }

    private void reconnect() {
        if (this.reconnecting || this.skipReconnect) return;

        final PayUManager self = this;

        if (this.backoff.getAttempts() >= this._reconnectionAttempts) {
            logger.fine("reconnect failed");
            this.backoff.reset();
            this.emitAll(EVENT_RECONNECT_FAILED);
            this.reconnecting = false;
        } else {
            long delay = this.backoff.duration();
            logger.fine(String.format("will wait %dms before reconnect attempt", delay));

            this.reconnecting = true;
            final Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    PayUEventThread.exec(new Runnable() {
                        @Override
                        public void run() {
                            if (self.skipReconnect) return;

                            logger.fine("attempting reconnect");
                            int attempts = self.backoff.getAttempts();
                            self.emitAll(EVENT_RECONNECT_ATTEMPT, attempts);
                            self.emitAll(EVENT_RECONNECTING, attempts);

                            // check again for the case socket closed in above events
                            if (self.skipReconnect) return;

                            self.open(new OpenCallback() {
                                @Override
                                public void call(Exception err) {
                                    if (err != null) {
                                        logger.fine("reconnect attempt error");
                                        self.reconnecting = false;
                                        self.reconnect();
                                        self.emitAll(EVENT_RECONNECT_ERROR, err);
                                    } else {
                                        logger.fine("reconnect success");
                                        self.onreconnect();
                                    }
                                }
                            });
                        }
                    });
                }
            }, delay);

            this.subs.add(new PayUOn.Handle() {
                @Override
                public void destroy() {
                    timer.cancel();
                }
            });
        }
    }

    private void onreconnect() {
        int attempts = this.backoff.getAttempts();
        this.reconnecting = false;
        this.backoff.reset();
        this.updateSocketIds();
        this.emitAll(EVENT_RECONNECT, attempts);
    }


    public static interface OpenCallback {

        public void call(Exception err);
    }


    private static class Engine extends com.payu.socketverification.socketclient.engineio.client.PayUSocket {

        Engine(URI uri, Options opts) {
            super(uri, opts);
        }
    }

    public static class Options extends com.payu.socketverification.socketclient.engineio.client.PayUSocket.Options {

        public boolean reconnection = true;
        public int reconnectionAttempts;
        public long reconnectionDelay;
        public long reconnectionDelayMax;
        public double randomizationFactor;

        /**
         * Connection timeout (ms). Set -1 to disable.
         */
        public long timeout = 20000;
    }
}
