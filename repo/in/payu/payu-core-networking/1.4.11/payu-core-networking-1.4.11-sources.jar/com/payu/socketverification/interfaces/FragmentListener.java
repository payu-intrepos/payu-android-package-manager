package com.payu.socketverification.interfaces;

public interface FragmentListener {
    void onPaymentFinished();
}
