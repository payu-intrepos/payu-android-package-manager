package com.payu.socketverification.util;

/**
 * Created by himanshu.gupta on 18/01/18.
 */

public interface PayUNetworkPaymentConstants {
    //Payment Method Supported
    String ACTION = "action";

    //Tez Bundle Key
    String STATUS = "Status";
    String SUCCESS = "success";
    String FAILURE = "failure";
    String CANCEL = "cancel";

    String RESULT = "result";
    int SOCKET_CONNECTION_ISSUE_CODE = 1003;
    int SERVER_ERROR = 1004;

    int INTERNET_ERROR = 1007;
    String INTERNET_ERROR_MESSAGE = "No internet connection";
    String SERVER_ERROR_MESSAGE_FINISH = "Server Error while finishing";
}
