package com.payu.socketverification.socketclient.client;


import com.payu.socketverification.socketclient.parser.PayUParser;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;


public class PayUIO {

    private static final Logger logger = Logger.getLogger(PayUIO.class.getName());

    private static final ConcurrentHashMap<String, PayUManager> managers = new ConcurrentHashMap<String, PayUManager>();

    /**
     * Protocol version.
     */
    public static int protocol = PayUParser.protocol;

    public static void setDefaultSSLContext(SSLContext sslContext) {
        PayUManager.defaultSSLContext = sslContext;
    }

    public static void setDefaultHostnameVerifier(HostnameVerifier hostnameVerifier) {
        PayUManager.defaultHostnameVerifier = hostnameVerifier;
    }

    private PayUIO() {}

    public static PayUSocket socket(String uri) throws URISyntaxException {
        return socket(uri, null);
    }

    public static PayUSocket socket(String uri, Options opts) throws URISyntaxException {
        return socket(new URI(uri), opts);
    }

    public static PayUSocket socket(URI uri) {
        return socket(uri, null);
    }

    /**
     * Initializes a {@link PayUSocket} from an existing {@link PayUManager} for multiplexing.
     *
     * @param uri uri to connect.
     * @param opts options for socket.
     * @return {@link PayUSocket} instance.
     */
    public static PayUSocket socket(URI uri, Options opts) {
        if (opts == null) {
            opts = new Options();
        }

        URL parsed = PayUUrl.parse(uri);
        URI source;
        try {
            source = parsed.toURI();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        String id = PayUUrl.extractId(parsed);
        String path = parsed.getPath();
        boolean sameNamespace = managers.containsKey(id)
                && managers.get(id).nsps.containsKey(path);
        boolean newConnection = opts.forceNew || !opts.multiplex || sameNamespace;
        PayUManager io;

        if (newConnection) {
            logger.fine(String.format("ignoring socket cache for %s", source));
            io = new PayUManager(source, opts);
        } else {
            if (!managers.containsKey(id)) {
                logger.fine(String.format("new io instance for %s", source));
                managers.putIfAbsent(id, new PayUManager(source, opts));
            }
            io = managers.get(id);
        }

        return io.socket(parsed.getPath());
    }


    public static class Options extends PayUManager.Options {

        public boolean forceNew;

        /**
         * Whether to enable multiplexing. Default is true.
         */
        public boolean multiplex = true;
    }
}
