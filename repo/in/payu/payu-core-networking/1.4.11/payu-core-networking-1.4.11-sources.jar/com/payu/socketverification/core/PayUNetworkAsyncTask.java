package com.payu.socketverification.core;

import com.payu.socketverification.bean.PayUNetworkAsyncTaskData;
import com.payu.socketverification.core.base.PayUAsyncTask;
import com.payu.socketverification.interfaces.PayuNetworkAsyncTaskInterface;
import com.payu.socketverification.util.L;
import com.payu.socketverification.util.NetworkUtil;
import com.payu.socketverification.util.PayUNetworkConstant;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by franklin.michael on 23/06/16.
 * <p>
 * Custom browser Generic async task.
 * Should be initialized with {@link PayuNetworkAsyncTaskInterface}
 * The response will be send the implemented class as string.
 * PayUNetworkAsyncTask takes {@link PayUNetworkAsyncTaskData} as input.
 */

public class PayUNetworkAsyncTask extends PayUAsyncTask<PayUNetworkAsyncTaskData, String, String> {

    private PayuNetworkAsyncTaskInterface mPayuNetworkAsyncTaskInterface;
    private String webServiceType;

    private PayUNetworkAsyncTask() {
    } // no object without interface

    public PayUNetworkAsyncTask(PayuNetworkAsyncTaskInterface payuNetworkAsyncTaskInterface, String webserviceType) {
        mPayuNetworkAsyncTaskInterface = payuNetworkAsyncTaskInterface;
        this.webServiceType = webserviceType;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    /**
     * following should be the possitions
     *
     * @param payUNetworkAsyncTaskData
     * @return
     */
    @Override
    protected String doInBackground(PayUNetworkAsyncTaskData... payUNetworkAsyncTaskData) {
        PayUNetworkAsyncTaskData mPayUNetworkAsyncTaskData = payUNetworkAsyncTaskData[0];
        InputStream responseInputStream = null;
        try {
            URL url = new URL(mPayUNetworkAsyncTaskData.getUrl());
            L.v("URL Verify UPI " + url);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod(mPayUNetworkAsyncTaskData.getHttpMethod());
            conn.setSSLSocketFactory(new TLSSocketFactory());
            conn.setConnectTimeout(PayUNetworkConstant.VERIFY_HTTP_TIMEOUT);
            conn.setRequestProperty("Content-Type", mPayUNetworkAsyncTaskData.getContentType());
            conn.setRequestProperty("Content-Length", "" + (null != mPayUNetworkAsyncTaskData.getPostData() ? mPayUNetworkAsyncTaskData.getPostData().length() : 0));
            byte[] postParamsByte = mPayUNetworkAsyncTaskData.getPostData().getBytes();
            L.v("Request Data Verify: " + mPayUNetworkAsyncTaskData.getPostData());
            conn.getOutputStream().write(postParamsByte);
            responseInputStream = conn.getInputStream();
            StringBuffer responseStringBuffer = new StringBuffer();
            byte[] byteContainer = new byte[1024];
            for (int i; (i = responseInputStream.read(byteContainer)) != -1; ) {
                responseStringBuffer.append(new String(byteContainer, 0, i));
            }
            L.v("VPA Verify Response " + responseStringBuffer.toString());
            return responseStringBuffer.toString();
        } catch (Exception e) {
            L.v(" Verify Error " + e.getMessage());
            return e.getMessage();
        } finally {
            if (responseInputStream != null)
                NetworkUtil.safeClose(responseInputStream);
        }
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        mPayuNetworkAsyncTaskInterface.onPayuNetworkAsyncTaskResponse(s, webServiceType);
    }
}
