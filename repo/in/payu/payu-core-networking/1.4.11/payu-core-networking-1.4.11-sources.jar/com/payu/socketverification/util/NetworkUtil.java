// The MIT License (MIT)
//
// Copyright (c) 2014-2015 PayU India
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package com.payu.socketverification.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Base64;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

/**
 * Created by minie on 29/6/15.
 * Contains cb's utility functions.
 */
public class NetworkUtil {

    private static final String TAG = NetworkUtil.class.getSimpleName();


    /**
     * Return system current time of system
     *
     * @return system current time in string
     */
    public static String getSystemCurrentTime() {
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String date = df.format(currentDate);
            return date;
        } catch (Exception e) {
            L.v("Version name " + e.getMessage());
        }
        return "";
    }

    /**
     * Provide JSONObject for analytics
     *
     * @param context        application context
     * @param key            analytics event ket
     * @param value          event value
     * @param bank           name of the bank
     * @param sdkMerchantKey merchant key
     * @param trnxID         transaction  ID
     * @return
     */
    public static String getLogMessage(Context context, String key, String value, String bank, String sdkMerchantKey, String trnxID, String pageType) {
        try {
            JSONObject eventAnalytics = new JSONObject();
            //   eventAnalytics.put(PayUNetworkAnalyticsConstant.PAYU_ID, getCookie(PayUNetworkConstant.PAYUID, context));
            eventAnalytics.put(PayUNetworkAnalyticsConstant.TRANSACTION_ID, trnxID);
            eventAnalytics.put(PayUNetworkAnalyticsConstant.MERCHANT_KEY, sdkMerchantKey);
            eventAnalytics.put(PayUNetworkAnalyticsConstant.PAGE_TYPE, (pageType == null ? "" : pageType));
            eventAnalytics.put(PayUNetworkAnalyticsConstant.KEY, key);
            eventAnalytics.put(PayUNetworkAnalyticsConstant.VALUE, URLEncoder.encode(value, "UTF-8"));
            eventAnalytics.put(PayUNetworkAnalyticsConstant.BANK_NAME, (bank == null ? "" : bank));
            eventAnalytics.put(PayUNetworkAnalyticsConstant.PAKAGE_NAME, context.getPackageName());
            eventAnalytics.put(PayUNetworkAnalyticsConstant.TIMESTAMP, getSystemCurrentTime());
            eventAnalytics.put(PayUNetworkAnalyticsConstant.VERSION_CODE, getVersionCode(context));
            return eventAnalytics.toString();
        } catch (Exception e) {
            L.v("Version name " + e.getMessage());
            return "{}";
        }
    }


    /**
     * Function to find whether network is available or not.
     *
     * @param context application context
     * @return true if network available else false
     */
    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected());
    }

    /**
     * Method to get the Base64 Decoded String value
     *
     * @param data - Base64 encoded String
     * @return Base64 decoded String
     */
    public static String getBase64DecodedString(String data) throws IllegalArgumentException, OutOfMemoryError, NullPointerException, IOException {
        return new String(Base64.decode(data, Base64.DEFAULT));
    }

    /**
     * @param response
     * @return
     */
    public static String getTransactionStatus(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.has(PayUNetworkPaymentConstants.RESULT)) {
                JSONObject resultObject = jsonObject.getJSONObject(PayUNetworkPaymentConstants.RESULT);
                if (resultObject.has(PayUNetworkPaymentConstants.STATUS.toLowerCase()))
                    return resultObject.getString(PayUNetworkPaymentConstants.STATUS.toLowerCase());
            }
        } catch (JSONException e) {
            L.v("Version name " + e.getMessage());
            return PayUNetworkPaymentConstants.FAILURE;
        }
        return PayUNetworkPaymentConstants.FAILURE;
    }

    public static String getVersionCode(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            L.v("Version name " + pInfo.versionName);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            L.v("Version name " + e.getMessage());
        }
        return "";
    }

    /**
     * Cancel timer
     *
     * @param timer timer object
     */
    public void cancelTimer(Timer timer) {
        if (timer != null) {
            timer.cancel();
            timer.purge();
        }
    }

    public static void safeClose(InputStream inputStream) {
        try {
            inputStream.close();
        } catch (IOException e) {
            Log.d(TAG, "Exception: " + e.getMessage());
        }
    }
}
