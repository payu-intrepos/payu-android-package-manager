package com.payu.socketverification.socket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;

import com.payu.socketverification.R;
import com.payu.socketverification.util.L;
import com.payu.socketverification.widgets.PayUProgressDialog;


public abstract class SocketBase {
    /**
     * Showing PayU progress dialog while doing network task
     */
    public static PayUProgressDialog progressDialog;
    View progressDialogCustomView;

    public void showProgressDialog(final Activity activity) {
        L.v("Showing Progress Bar");
        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            if (null == progressDialog)
                progressDialog = new PayUProgressDialog(activity, progressDialogCustomView);
            progressDialog.setCancelable(false);
            L.v("Progress Dialog " + progressDialog);
            if (null == progressDialogCustomView)
                progressDialog.setPayUDialogSettings(activity);
            L.v("Progress Dialog showing" + progressDialog);
            if (null != progressDialog && !progressDialog.isShowing() && null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
                try {
                    progressDialog.show();
                } catch (IllegalStateException | WindowManager.BadTokenException bte) {
                    if (null != bte.getMessage())
                        L.v("Caught Exception " + bte.getMessage());
                }

                progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_BACK) {
                            dialog.dismiss();
                            showCancelAlertDialog(activity);
                        }
                        return true;
                    }
                });
            }
        }
    }

    public void hideProgressDialog(Activity activity) {
        if (null != progressDialog && progressDialog.isShowing() && !activity.isFinishing()) {
            progressDialog.dismiss();
        }
        progressDialog = null;
    }

    /**
     * Show Alert Dialog to cancel the transaction on Back Press.
     *
     * @param activity
     */
    private void showCancelAlertDialog(final Activity activity) {
        if (null != activity && !activity.isFinishing() && !activity.isDestroyed()) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity, R.style.payu_network_dialog);
            alertDialog.setCancelable(false);
            alertDialog.setMessage("Do you really want to cancel the transaction ?");
            alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    onTranscationCancelled();
                    try {
                        dialog.dismiss();
                    } catch (IllegalArgumentException | WindowManager.BadTokenException bte) {
                        if (null != bte.getMessage())
                            L.v("Caught Exception " + bte.getMessage());
                    }
                }
            });
            alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try {
                        dialog.dismiss();
                    } catch (IllegalArgumentException | WindowManager.BadTokenException bte) {
                        if (null != bte.getMessage())
                            L.v("Caught Exception " + bte.getMessage());
                    }
                    showProgressDialog(activity);
                }
            });
            alertDialog.show();
        }
    }

    //Need to update Handler when user press
    public abstract void onTranscationCancelled();

    public View getProgressDialogCustomView() {
        return progressDialogCustomView;
    }

    public void setProgressDialogCustomView(View progressDialogCustomView) {
        this.progressDialogCustomView = progressDialogCustomView;
    }
}
