package com.payu.socketverification.interfaces;

public interface IVerifyResponse {

    void getVerifyResponse(boolean isFinished, String response);
}


