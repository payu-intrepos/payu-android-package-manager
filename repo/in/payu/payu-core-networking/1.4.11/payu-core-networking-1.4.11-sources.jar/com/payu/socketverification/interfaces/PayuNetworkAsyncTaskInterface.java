package com.payu.socketverification.interfaces;

/**
 * Created by franklin.michael on 23/06/16.
 */

public interface PayuNetworkAsyncTaskInterface {
    void onPayuNetworkAsyncTaskResponse(String payUAsyncTaskResponse, String webServiceType);
}
