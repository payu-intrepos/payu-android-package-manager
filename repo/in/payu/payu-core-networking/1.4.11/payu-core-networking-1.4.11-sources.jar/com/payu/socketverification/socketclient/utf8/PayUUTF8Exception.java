package com.payu.socketverification.socketclient.utf8;

import java.io.IOException;

public class PayUUTF8Exception extends IOException {

    public PayUUTF8Exception() {
        super();
    }

    public PayUUTF8Exception(String message) {
        super(message);
    }

    public PayUUTF8Exception(String message, Throwable cause) {
        super(message, cause);
    }

    public PayUUTF8Exception(Throwable cause) {
        super(cause);
    }
}
