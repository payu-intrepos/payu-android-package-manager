package com.payu.socketverification.socketclient.parser;


public class PayUPacket<T> {

    public int type = -1;
    public int id = -1;
    public String nsp;
    public T data;
    public int attachments;

    public PayUPacket() {}

    public PayUPacket(int type) {
        this.type = type;
    }

    public PayUPacket(int type, T data) {
        this.type = type;
        this.data = data;
    }
}
