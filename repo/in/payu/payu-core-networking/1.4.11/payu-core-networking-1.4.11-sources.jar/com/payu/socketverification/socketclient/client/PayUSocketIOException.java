package com.payu.socketverification.socketclient.client;

public class PayUSocketIOException extends Exception {

    public PayUSocketIOException() {
        super();
    }

    public PayUSocketIOException(String message) {
        super(message);
    }

    public PayUSocketIOException(String message, Throwable cause) {
        super(message, cause);
    }

    public PayUSocketIOException(Throwable cause) {
        super(cause);
    }
}
