package com.payu.socketverification.socketclient.client;

import com.payu.socketverification.socketclient.emitter.PayUEmitter;

public class PayUOn {

    private PayUOn() {}

    public static Handle on(final PayUEmitter obj, final String ev, final PayUEmitter.Listener fn) {
        obj.on(ev, fn);
        return new Handle() {
            @Override
            public void destroy() {
                obj.off(ev, fn);
            }
        };
    }

    public static interface Handle {

        public void destroy();
    }
}
