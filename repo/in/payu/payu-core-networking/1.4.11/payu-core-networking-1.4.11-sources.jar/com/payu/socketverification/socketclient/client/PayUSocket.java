package com.payu.socketverification.socketclient.client;

import com.payu.socketverification.socketclient.emitter.PayUEmitter;
import com.payu.socketverification.socketclient.hasbinary.PayUHasBinary;
import com.payu.socketverification.socketclient.parser.PayUPacket;
import com.payu.socketverification.socketclient.parser.PayUParser;
import com.payu.socketverification.socketclient.thread.PayUEventThread;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The socket class for Socket.IO Client.
 */
public class PayUSocket extends PayUEmitter {

    private static final Logger logger = Logger.getLogger(PayUSocket.class.getName());

    /**
     * Called on a connection.
     */
    public static final String EVENT_CONNECT = "connect";

    public static final String EVENT_CONNECTING = "connecting";

    /**
     * Called on a disconnection.
     */
    public static final String EVENT_DISCONNECT = "disconnect";

    /**
     * Called on a connection error.
     *
     * <p>Parameters:</p>
     * <ul>
     *   <li>(Exception) error data.</li>
     * </ul>
     */
    public static final String EVENT_ERROR = "error";

    public static final String EVENT_MESSAGE = "message";

    public static final String EVENT_CONNECT_ERROR = PayUManager.EVENT_CONNECT_ERROR;

    public static final String EVENT_CONNECT_TIMEOUT = PayUManager.EVENT_CONNECT_TIMEOUT;

    public static final String EVENT_RECONNECT = PayUManager.EVENT_RECONNECT;

    public static final String EVENT_RECONNECT_ERROR = PayUManager.EVENT_RECONNECT_ERROR;

    public static final String EVENT_RECONNECT_FAILED = PayUManager.EVENT_RECONNECT_FAILED;

    public static final String EVENT_RECONNECT_ATTEMPT = PayUManager.EVENT_RECONNECT_ATTEMPT;

    public static final String EVENT_RECONNECTING = PayUManager.EVENT_RECONNECTING;

    public static final String EVENT_PING = PayUManager.EVENT_PING;

    public static final String EVENT_PONG = PayUManager.EVENT_PONG;

    protected static Map<String, Integer> events = new HashMap<String, Integer>() {{
        put(EVENT_CONNECT, 1);
        put(EVENT_CONNECT_ERROR, 1);
        put(EVENT_CONNECT_TIMEOUT, 1);
        put(EVENT_CONNECTING, 1);
        put(EVENT_DISCONNECT, 1);
        put(EVENT_ERROR, 1);
        put(EVENT_RECONNECT, 1);
        put(EVENT_RECONNECT_ATTEMPT, 1);
        put(EVENT_RECONNECT_FAILED, 1);
        put(EVENT_RECONNECT_ERROR, 1);
        put(EVENT_RECONNECTING, 1);
        put(EVENT_PING, 1);
        put(EVENT_PONG, 1);
    }};

    /*package*/ String id;

    private volatile boolean connected;
    private int ids;
    private String nsp;
    private PayUManager io;
    private Map<Integer, PayUAck> acks = new HashMap<Integer, PayUAck>();
    private Queue<PayUOn.Handle> subs;
    private final Queue<List<Object>> receiveBuffer = new LinkedList<List<Object>>();
    private final Queue<PayUPacket<JSONArray>> sendBuffer = new LinkedList<PayUPacket<JSONArray>>();

    public PayUSocket(PayUManager io, String nsp) {
        this.io = io;
        this.nsp = nsp;
    }

    private void subEvents() {
        if (this.subs != null) return;

        final PayUManager io = PayUSocket.this.io;
        PayUSocket.this.subs = new LinkedList<PayUOn.Handle>() {{
            add(PayUOn.on(io, PayUManager.EVENT_OPEN, new Listener() {
                @Override
                public void call(Object... args) {
                    PayUSocket.this.onopen();
                }
            }));
            add(PayUOn.on(io, PayUManager.EVENT_PACKET, new Listener() {
                @Override
                public void call(Object... args) {
                    PayUSocket.this.onpacket((PayUPacket<?>) args[0]);
                }
            }));
            add(PayUOn.on(io, PayUManager.EVENT_CLOSE, new Listener() {
                @Override
                public void call(Object... args) {
                    PayUSocket.this.onclose(args.length > 0 ? (String) args[0] : null);
                }
            }));
        }};
    }

    /**
     * Connects the socket.
     */
    public PayUSocket open() {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (PayUSocket.this.connected) return;

                PayUSocket.this.subEvents();
                PayUSocket.this.io.open(); // ensure open
                if (PayUManager.ReadyState.OPEN == PayUSocket.this.io.readyState) PayUSocket.this.onopen();
                PayUSocket.this.emit(EVENT_CONNECTING);
            }
        });
        return this;
    }

    /**
     * Connects the socket.
     */
    public PayUSocket connect() {
        return this.open();
    }

    /**
     * Send messages.
     *
     * @param args data to send.
     * @return a reference to this object.
     */
    public PayUSocket send(final Object... args) {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                PayUSocket.this.emit(EVENT_MESSAGE, args);
            }
        });
        return this;
    }

    /**
     * Emits an event. When you pass {@link PayUAck} at the last argument, then the acknowledge is done.
     *
     * @param event an event name.
     * @param args data to send.
     * @return a reference to this object.
     */
    @Override
    public PayUEmitter emit(final String event, final Object... args) {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (events.containsKey(event)) {
                    PayUSocket.super.emit(event, args);
                    return;
                }

                List<Object> _args = new ArrayList<Object>(args.length + 1);
                _args.add(event);
                _args.addAll(Arrays.asList(args));

                JSONArray jsonArgs = new JSONArray();
                for (Object arg : _args) {
                    jsonArgs.put(arg);
                }
                int parserType = PayUHasBinary.hasBinary(jsonArgs) ? PayUParser.BINARY_EVENT : PayUParser.EVENT;
                PayUPacket<JSONArray> packet = new PayUPacket<JSONArray>(parserType, jsonArgs);

                if (_args.get(_args.size() - 1) instanceof PayUAck) {
                    logger.fine(String.format("emitting packet with ack id %d", PayUSocket.this.ids));
                    PayUSocket.this.acks.put(PayUSocket.this.ids, (PayUAck)_args.remove(_args.size() - 1));
                    jsonArgs = remove(jsonArgs, jsonArgs.length() - 1);
                    packet.data = jsonArgs;
                    packet.id = PayUSocket.this.ids++;
                }

                if (PayUSocket.this.connected) {
                    PayUSocket.this.packet(packet);
                } else {
                    PayUSocket.this.sendBuffer.add(packet);
                }
            }
        });
        return this;
    }

    private static JSONArray remove(JSONArray a, int pos) {
        JSONArray na = new JSONArray();
        for (int i = 0; i < a.length(); i++){
            if (i != pos) {
                Object v;
                try {
                    v = a.get(i);
                } catch (JSONException e) {
                    v = null;
                }
                na.put(v);
            }
        }
        return na;
    }

    /**
     * Emits an event with an acknowledge.
     *
     * @param event an event name
     * @param args data to send.
     * @param payUAck the acknowledgement to be called
     * @return a reference to this object.
     */
    public PayUEmitter emit(final String event, final Object[] args, final PayUAck payUAck) {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                List<Object> _args = new ArrayList<Object>() {{
                    add(event);
                    if (args != null) {
                        addAll(Arrays.asList(args));
                    }
                }};
                
                JSONArray jsonArgs = new JSONArray();
                for (Object _arg : _args) {
                    jsonArgs.put(_arg);
                }
                int parserType = PayUHasBinary.hasBinary(jsonArgs) ? PayUParser.BINARY_EVENT : PayUParser.EVENT;
                PayUPacket<JSONArray> packet = new PayUPacket<JSONArray>(parserType, jsonArgs);

                logger.fine(String.format("emitting packet with ack id %d", ids));
                PayUSocket.this.acks.put(ids, payUAck);
                packet.id = ids++;

                PayUSocket.this.packet(packet);
            }
        });
        return this;
    }

    private void packet(PayUPacket packet) {
        packet.nsp = this.nsp;
        this.io.packet(packet);
    }

    private void onopen() {
        logger.fine("transport is open - connecting");

        if (!"/".equals(this.nsp)) {
            this.packet(new PayUPacket(PayUParser.CONNECT));
        }
    }

    private void onclose(String reason) {
        logger.fine(String.format("close (%s)", reason));
        this.connected = false;
        this.id = null;
        this.emit(EVENT_DISCONNECT, reason);
    }

    private void onpacket(PayUPacket<?> packet) {
        if (!this.nsp.equals(packet.nsp)) return;

        switch (packet.type) {
            case PayUParser.CONNECT:
                this.onconnect();
                break;

            case PayUParser.EVENT: {
                @SuppressWarnings("unchecked")
                PayUPacket<JSONArray> p = (PayUPacket<JSONArray>) packet;
                this.onevent(p);
                break;
            }

            case PayUParser.BINARY_EVENT: {
                @SuppressWarnings("unchecked")
                PayUPacket<JSONArray> p = (PayUPacket<JSONArray>) packet;
                this.onevent(p);
                break;
            }

            case PayUParser.ACK: {
                @SuppressWarnings("unchecked")
                PayUPacket<JSONArray> p = (PayUPacket<JSONArray>) packet;
                this.onack(p);
                break;
            }

            case PayUParser.BINARY_ACK: {
                @SuppressWarnings("unchecked")
                PayUPacket<JSONArray> p = (PayUPacket<JSONArray>) packet;
                this.onack(p);
                break;
            }

            case PayUParser.DISCONNECT:
                this.ondisconnect();
                break;

            case PayUParser.ERROR:
                this.emit(EVENT_ERROR, packet.data);
                break;
        }
    }

    private void onevent(PayUPacket<JSONArray> packet) {
        List<Object> args = new ArrayList<Object>(Arrays.asList(toArray(packet.data)));
        logger.fine(String.format("emitting event %s", args));

        if (packet.id >= 0) {
            logger.fine("attaching ack callback to event");
            args.add(this.ack(packet.id));
        }

        if (this.connected) {
            if (args.isEmpty()) return;
            String event = args.remove(0).toString();
            super.emit(event, args.toArray());
        } else {
            this.receiveBuffer.add(args);
        }
    }

    private PayUAck ack(final int id) {
        final PayUSocket self = this;
        final boolean[] sent = new boolean[] {false};
        return new PayUAck() {
            @Override
            public void call(final Object... args) {
                PayUEventThread.exec(new Runnable() {
                    @Override
                    public void run() {
                        if (sent[0]) return;
                        sent[0] = true;
                        logger.fine(String.format("sending ack %s", args.length != 0 ? args : null));

                        JSONArray jsonArgs = new JSONArray();
                        for (Object arg : args) {
                            jsonArgs.put(arg);
                        }

                        int type = PayUHasBinary.hasBinary(jsonArgs)
                            ? PayUParser.BINARY_ACK : PayUParser.ACK;
                        PayUPacket<JSONArray> packet = new PayUPacket<JSONArray>(type, jsonArgs);
                        packet.id = id;
                        self.packet(packet);
                    }
                });
            }
        };
    }

    private void onack(PayUPacket<JSONArray> packet) {
        PayUAck fn = this.acks.remove(packet.id);
        if (fn != null) {
            logger.fine(String.format("calling ack %s with %s", packet.id, packet.data));
            fn.call(toArray(packet.data));
        } else {
            logger.fine(String.format("bad ack %s", packet.id));
        }
    }

    private void onconnect() {
        this.connected = true;
        this.emit(EVENT_CONNECT);
        this.emitBuffered();
    }

    private void emitBuffered() {
        List<Object> data;
        while ((data = this.receiveBuffer.poll()) != null) {
            String event = (String)data.get(0);
            super.emit(event, data.toArray());
        }
        this.receiveBuffer.clear();

        PayUPacket<JSONArray> packet;
        while ((packet = this.sendBuffer.poll()) != null) {
            this.packet(packet);
        }
        this.sendBuffer.clear();
    }

    private void ondisconnect() {
        logger.fine(String.format("server disconnect (%s)", this.nsp));
        this.destroy();
        this.onclose("io server disconnect");
    }

    private void destroy() {
        if (this.subs != null) {
            // clean subscriptions to avoid reconnection
            for (PayUOn.Handle sub : this.subs) {
                sub.destroy();
            }
            this.subs = null;
        }

        this.io.destroy(this);
    }

    /**
     * Disconnects the socket.
     *
     * @return a reference to this object.
     */
    public PayUSocket close() {
        PayUEventThread.exec(new Runnable() {
            @Override
            public void run() {
                if (PayUSocket.this.connected) {
                    logger.fine(String.format("performing disconnect (%s)", PayUSocket.this.nsp));
                    PayUSocket.this.packet(new PayUPacket(PayUParser.DISCONNECT));
                }

                PayUSocket.this.destroy();

                if (PayUSocket.this.connected) {
                    PayUSocket.this.onclose("io client disconnect");
                }
            }
        });
        return this;
    }

    /**
     * Disconnects the socket.
     *
     * @return a reference to this object.
     */
    public PayUSocket disconnect() {
        return this.close();
    }

    public PayUManager io() {
        return this.io;
    }

    public boolean connected() {
        return this.connected;
    }

    /**
     * A property on the socket instance that is equal to the underlying engine.io socket id.
     *
     * The value is present once the socket has connected, is removed when the socket disconnects and is updated if the socket reconnects.
     *
     * @return a socket id
     */
    public String id() {
        return this.id;
    }

    private static Object[] toArray(JSONArray array) {
        int length = array.length();
        Object[] data = new Object[length];
        for (int i = 0; i < length; i++) {
            Object v;
            try {
                v = array.get(i);
            } catch (JSONException e) {
                logger.log(Level.WARNING, "An error occured while retrieving data from JSONArray", e);
                v = null;
            }
            data[i] = JSONObject.NULL.equals(v) ? null : v;
        }
        return data;
    }
}

