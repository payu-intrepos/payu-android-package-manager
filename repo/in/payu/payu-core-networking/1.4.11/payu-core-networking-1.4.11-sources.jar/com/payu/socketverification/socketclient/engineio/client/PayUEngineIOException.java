package com.payu.socketverification.socketclient.engineio.client;

public class PayUEngineIOException extends Exception {

    public String transport;
    public Object code;

    public PayUEngineIOException() {
        super();
    }

    public PayUEngineIOException(String message) {
        super(message);
    }

    public PayUEngineIOException(String message, Throwable cause) {
        super(message, cause);
    }

    public PayUEngineIOException(Throwable cause) {
        super(cause);
    }
}
