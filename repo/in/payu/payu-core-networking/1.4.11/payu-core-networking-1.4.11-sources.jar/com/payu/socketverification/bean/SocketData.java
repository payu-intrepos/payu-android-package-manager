package com.payu.socketverification.bean;

import com.payu.socketverification.interfaces.PayUSocketEventListener;

public enum SocketData {
    SINGLETON;
    PayUSocketEventListener payUSocketEventListener;
    private boolean isloggingEnabled;
    private int logsLevel;

    public boolean isloggingEnabled() {
        return isloggingEnabled;
    }

    public void setLoggingEnabled(boolean isloggingEnabled) {
        this.isloggingEnabled = isloggingEnabled;
    }

    public int getLogsLevel() {
        return logsLevel;
    }

    public void setLogsLevel(int logsLevel) {
        this.logsLevel = logsLevel;
    }

    public PayUSocketEventListener getPayUSocketEventListener() {
        return payUSocketEventListener;
    }

    public void setPayUSocketEventListener(PayUSocketEventListener payUSocketEventListener) {
        this.payUSocketEventListener = payUSocketEventListener;
    }
}
