package com.payu.socketverification.interfaces;

public interface PayUSocketEventListener {
    void getSocketResult(String merchantResponse, String payuResponse, String resultType, boolean isLongPooling);

    void errorReceived(int issueCode, String errorMessage);

    void transactionCancelled();

    void onSocketCreated();
}
