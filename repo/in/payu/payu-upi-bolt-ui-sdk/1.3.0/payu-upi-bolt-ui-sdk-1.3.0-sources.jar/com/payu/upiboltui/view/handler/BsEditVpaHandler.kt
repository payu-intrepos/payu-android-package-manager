package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PayUValidateUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener

class BsEditVpaHandler {

    private var tvErrorTextUPISetup: TextView? = null
    private lateinit var payuButton: TextView
    private lateinit var progressBarBtn: ProgressBar
    private var buttonText: String? = null

    fun init(
        view: View,
        payButtonText: String,
        onPayClick: (vpa: String) -> Unit
    ) {
        val etPhoneUPISetup: EditText? = view.findViewById(R.id.etPhoneUPISetup)
        tvErrorTextUPISetup = view.findViewById(R.id.tvErrorTextUPISetup)
        progressBarBtn = view.findViewById(R.id.cpbProgressBarBtn)
        tvErrorTextUPISetup?.visibility = View.GONE
        payuButton = view.findViewById(R.id.payuButton)
        val bankHandle = view.findViewById<TextView>(R.id.tvUpiHandleUPISetup)
        payuButton.text = payButtonText
        buttonText = payButtonText

        etPhoneUPISetup?.doAfterTextChanged {
            hideError()
        }

        payuButton.setAvoidMultiClickListener {
            etPhoneUPISetup?.text?.toString()?.let {
                if (!PayUValidateUtils.validateVPA(etPhoneUPISetup.text.toString())) {
                    setErrorVisible(view.context.getString(R.string.payu_invalid_vpa_error))
                    return@let
                }
                payuButton.text = ""
                progressBarBtn.isVisible = true
                payuButton.isClickable = false
                onPayClick.invoke(it)
            } ?: kotlin.run {
                setErrorVisible(view.context.getString(R.string.payu_empty_vpa_error))
            }
        }

        bankHandle.text = "@${InternalConfig.bankHandle}"
    }

    fun setErrorVisible(text: String) {
        tvErrorTextUPISetup?.visibility = View.VISIBLE
        tvErrorTextUPISetup?.text = text
        payuButton.text = buttonText
        progressBarBtn.isVisible = false
        payuButton.isClickable = true
    }

    private fun hideError() {
        tvErrorTextUPISetup?.isVisible = false
    }
}