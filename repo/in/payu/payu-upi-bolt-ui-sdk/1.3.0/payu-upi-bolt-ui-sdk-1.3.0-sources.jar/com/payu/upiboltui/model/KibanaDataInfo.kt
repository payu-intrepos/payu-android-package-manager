package com.payu.upiboltui.model

import com.payu.upibolt.utils.AnalyticsUtils

data class KibanaDataInfo(
    val eventKey: String,
    val eventData: String,
    val eventType: AnalyticsUtils.EventType = AnalyticsUtils.EventType.Info,
    val eventSeverity: AnalyticsUtils.EventSeverity = AnalyticsUtils.EventSeverity.Low,
    val status: String? = null,
    val code: String? = null,
    val time: Long? = null,
    val screenName: String? = null,
    val name: String? = null
)
