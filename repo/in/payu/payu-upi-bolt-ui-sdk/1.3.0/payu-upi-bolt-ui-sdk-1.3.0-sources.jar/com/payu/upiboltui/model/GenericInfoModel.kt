package com.payu.upiboltui.model

import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

data class GenericInfoModel(
    val title: String,
    val message: String,
    val buttonText: String,
    val isErrorImgVisible: Boolean,
    val nextAction: UpiPluginAction = UpiPluginAction.GENERIC_INFO,
    val retryData: Any? = null,
    val parentBs: FixedRoundedCornerBottomSheet? = null,
    val isCancelable: Boolean = true,
    val negativeBtnText: String? = null,
    val negativeBtnAction: UpiPluginAction? = null,
    val showProgress: Boolean = false
    )
