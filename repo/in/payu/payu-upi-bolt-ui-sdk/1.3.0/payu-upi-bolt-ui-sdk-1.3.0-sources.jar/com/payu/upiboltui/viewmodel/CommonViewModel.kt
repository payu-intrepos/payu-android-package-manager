package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.constants.payUEventScreenMap
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.model.ManageAccountModel
import com.payu.upiboltui.model.ManagementScreenType
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.model.WelcomeScreenModel
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.BankListErrorBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.BankSelectionBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.CancelConfirmationBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.CommonLoaderBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.DeRegisterAccountsBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.DeleteAccountConfirmationBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.GenericInfoBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.LinkedAccountBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.MPinSetupBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.ManageAccountBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.ManagementOptionsBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.MobileVerificationBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.MobileVerifiedBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.RaiseDisputeBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.RaiseDisputeTypeListBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.SimSelectionBottomSheet
import com.payu.upiboltui.view.bottomSheetFragments.TransactionDetailsBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.UpdateVpaBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.VerifyPaymentBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.WelcomeScreenBSFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.view.bottomSheetFragments.AddAccountSelectionBSFragment
import org.json.JSONObject

class CommonViewModel(application: Application) : AndroidViewModel(application) {
    private val hideLinkedAccountBSLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val hideLinkedAccountBSLoaderLiveData: LiveData<Event<Boolean>> =
        hideLinkedAccountBSLoaderMutableLiveData

    private val hideSetMPinBSLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val hideSetMPinBSLoaderLiveData: LiveData<Event<Boolean>> = hideSetMPinBSLoaderMutableLiveData

    private val hideRaiseDisputeLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val hideRaiseDisputeLoaderLiveData: LiveData<Event<Boolean>> =
        hideRaiseDisputeLoaderMutableLiveData

    private val hideDeregisterAccountLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val hideDeregisterAccountLoaderLiveData: LiveData<Event<Boolean>> =
        hideDeregisterAccountLoaderMutableLiveData

    private val cancelTimerMutableLiveData: MutableLiveData<Event<Boolean>> = MutableLiveData()
    val cancelTimerLiveData: LiveData<Event<Boolean>> = cancelTimerMutableLiveData


    private val showFetchLinkedAccountsLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showFetchLinkedAccountsLoaderLiveData: LiveData<Event<Boolean>> =
        showFetchLinkedAccountsLoaderMutableLiveData

    private val showBankListLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showBankListLoaderLiveData: LiveData<Event<Boolean>> =
        showBankListLoaderMutableLiveData

    private val showPayLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showPayLoaderLiveData: LiveData<Event<Boolean>> =
        showPayLoaderMutableLiveData

    private val vpaMutableLiveData = MutableLiveData<Event<NetworkResponse<Any>>>()
    val vpaLiveData: LiveData<Event<NetworkResponse<Any>>> = vpaMutableLiveData

    private val showUpdateVpaErrorMutableLiveData: MutableLiveData<Event<String>> =
        MutableLiveData()
    val showUpdateVpaErrorLiveData: LiveData<Event<String>> =
        showUpdateVpaErrorMutableLiveData

    private val updateOtpVerifyMsgMutableLiveData: MutableLiveData<Event<String>> =
        MutableLiveData()
    val updateOtpVerifyMsgLiveData: LiveData<Event<String>> =
        updateOtpVerifyMsgMutableLiveData

    private val otpTimeoutMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val otpTimeoutLiveData: LiveData<Event<Boolean>> = otpTimeoutMutableLiveData

    private var startTime: Long? = null

    private var isNavigationEnforced = false

    fun setIsNavigationEnforced(isNavigationEnforced: Boolean) {
        this.isNavigationEnforced = isNavigationEnforced
    }

    fun getIsNavigationEnforced(): Boolean = isNavigationEnforced

    fun setStartTime() {
        startTime = System.currentTimeMillis()
    }

    fun getStartTime(): Long? {
        return startTime
    }

    fun hideLinkedAccountBSLoader() {
        hideLinkedAccountBSLoaderMutableLiveData.value = Event(true)
    }

    fun hideSetMPinBSLoader() {
        hideSetMPinBSLoaderMutableLiveData.value = Event(true)
    }

    fun hideRaiseDisputeLoader() {
        hideRaiseDisputeLoaderMutableLiveData.value = Event(true)
    }

    fun hideDeregisterAccountLoader() {
        hideDeregisterAccountLoaderMutableLiveData.value = Event(true)
    }

    fun setLoaderForFetchLinkedAccounts(value: Boolean) {
        showFetchLinkedAccountsLoaderMutableLiveData.value = Event(value)
    }

    fun setLoaderForFetchBankList(value: Boolean) {
        showBankListLoaderMutableLiveData.value = Event(value)
    }

    fun setPayLoader(value: Boolean) {
        showPayLoaderMutableLiveData.value = Event(value)
    }

    fun setUpdateVpaState(value: NetworkResponse<Any>) {
        vpaMutableLiveData.value = Event(value)
    }

    fun cancelTimer() {
        cancelTimerMutableLiveData.value = Event(true)
    }

    fun showUpdateVpaError(error: String) {
        showUpdateVpaErrorMutableLiveData.value = Event(error)
    }

    fun showOtpListenStarted(msg: String) {
        updateOtpVerifyMsgMutableLiveData.value = Event(msg)
    }

    fun otpTimeout(timeout: Boolean) {
        otpTimeoutMutableLiveData.value = Event(timeout)
    }


    fun getFragment(
        upiFixedBottomSheetData: UpiFixedBottomSheetData
    ): FixedRoundedCornerBottomSheet? {
        var fragment: FixedRoundedCornerBottomSheet? = null
        var screenType: String? = null
        when (upiFixedBottomSheetData.pluginAction) {
            UpiPluginAction.LINKED_ACCOUNT -> {
                val data = upiFixedBottomSheetData.data as? MutableList<LinkedAccountsUIModel>?
                data?.let {
                    fragment =
                        LinkedAccountBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = CLConstant.PAYU_EVENT_TYPE_REPEAT
            }

            UpiPluginAction.MANAGE_ACCOUNT -> {
                val data = upiFixedBottomSheetData.data as? ManageAccountModel?
                data?.let {
                    fragment =
                        ManageAccountBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION -> {
                val data = upiFixedBottomSheetData.data as? PayUCustomerBankAccounts?
                data?.let {
                    fragment = DeleteAccountConfirmationBSFragment.newInstance(
                        data = data,
                        upiFixedBottomSheetData
                    )
                }
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.MANAGEMENT_OPTIONS -> {
                fragment = ManagementOptionsBSFragment.newInstance(upiFixedBottomSheetData)
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.RAISE_DISPUTE -> {
                val data = upiFixedBottomSheetData.data as? PayUTransactionHistory?
                data?.let {
                    fragment =
                        RaiseDisputeBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.TRANSACTION_DETAILS -> {
                val data = upiFixedBottomSheetData.data as? PayUTransactionHistory?
                data?.let {
                    fragment = TransactionDetailsBSFragment.newInstance(
                        data = data,
                        upiFixedBottomSheetData
                    )
                }
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.WELCOME_SCREEN -> {
                val data = upiFixedBottomSheetData.data as? WelcomeScreenModel?
                data?.let {
                    fragment =
                        WelcomeScreenBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.BANK_LIST_ERROR_SCREEN -> {
                fragment = BankListErrorBSFragment.newInstance(upiFixedBottomSheetData)
            }

            UpiPluginAction.MOBILE_VERIFICATION -> {
                fragment = MobileVerificationBSFragment.newInstance(upiFixedBottomSheetData)
            }

            UpiPluginAction.MOBILE_VERIFIED -> {
                val data = upiFixedBottomSheetData.data as? UpiPluginAction
                fragment = data?.let {
                    MobileVerifiedBSFragment.newInstance(
                        data = it,
                        upiFixedBottomSheetData
                    )
                }
            }

            UpiPluginAction.BANK_SELECTION -> {
                val data = upiFixedBottomSheetData.data as? ArrayList<PayUBankData>?
                data?.let {
                    fragment =
                        BankSelectionBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.UPDATE_VPA -> {
                val data = upiFixedBottomSheetData.data as? PayUAccountDetail?
                data?.let {
                    fragment = UpdateVpaBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.M_PIN_SETUP -> {
                val data = upiFixedBottomSheetData.data as? PayUCustomerBankAccounts?
                data?.let {
                    fragment = MPinSetupBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS -> {
                fragment = DeRegisterAccountsBSFragment.newInstance(upiFixedBottomSheetData)
                screenType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            }

            UpiPluginAction.GENERIC_INFO, UpiPluginAction.NETWORK_ERROR -> {
                val data = upiFixedBottomSheetData.data as? GenericInfoModel?
                data?.let {
                    fragment =
                        GenericInfoBSFragment.newInstance(data = data, upiFixedBottomSheetData)
                }
            }

            UpiPluginAction.COMMON_LOADER -> {
                fragment = CommonLoaderBSFragment.newInstance(upiFixedBottomSheetData)
            }

            UpiPluginAction.VERIFY_PAYMENT -> {
                val data = upiFixedBottomSheetData.data as? Boolean?
                data?.let {
                    fragment = VerifyPaymentBSFragment.newInstance(
                        isCancellingTxn = data,
                        upiFixedBottomSheetData
                    )
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.CANCEL_CONFIRMATION -> {
                val data = upiFixedBottomSheetData.data as? GenericInfoModel?
                data?.let {
                    fragment = CancelConfirmationBSFragment.newInstance(
                        data = data,
                        upiFixedBottomSheetData
                    )
                }
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.SIM_SELECTION -> {
                fragment = SimSelectionBottomSheet.newInstance(
                    upiFixedBottomSheetData
                )
                screenType = upiFixedBottomSheetData.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            }

            UpiPluginAction.RAISE_DISPUTE_TYPE_LIST -> {
                fragment = RaiseDisputeTypeListBSFragment.newInstance(upiFixedBottomSheetData)
            }

            UpiPluginAction.ADD_ACCOUNT_SELECTION -> {
                fragment = AddAccountSelectionBSFragment.newInstance(upiFixedBottomSheetData)
            }

            else -> {}
        }

        screenType?.let {
            upiFixedBottomSheetData.ctFlowType = screenType
            payUEventScreenMap[upiFixedBottomSheetData.pluginAction]?.let { screenName ->
                val map = HashMap<String, Any>().apply {
                    this[CLConstant.PAYU_CT_SCREEN] = screenName
                }
                AnalyticsUtils.setCTLogsForUPIWithData(
                    getApplication(), CLConstant.PAYU_CT_SCREEN_OPENED, map, screenType
                )
                PayUUtils.logKibanaEvents(
                    getApplication(),
                    eventKey = CLConstant.PAYU_CT_SCREEN_OPENED,
                    eventData = JSONObject().apply { put(CLConstant.PAYU_EVENT_TYPE, screenType) }.toString(),
                    screenName = screenName,
                    eventType = AnalyticsUtils.EventType.Info
                )
            }
        }
        return fragment
    }


    fun getUpiPluginActionForManagementScreenType(managementScreenType: ManagementScreenType): UpiPluginAction {
        return when (managementScreenType) {
            ManagementScreenType.TRANSACTIONHISTORY -> UpiPluginAction.TRANSACTION_HISTORY
            ManagementScreenType.MANAGEUPIACCOUNTS -> UpiPluginAction.MANAGE_ACCOUNT
            ManagementScreenType.DISPUTE -> UpiPluginAction.RAISE_DISPUTE_LIST
            ManagementScreenType.DEREGISTERUPI -> UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CONFIRMATION
            ManagementScreenType.ALL -> UpiPluginAction.MANAGEMENT_OPTIONS
        }
    }
}