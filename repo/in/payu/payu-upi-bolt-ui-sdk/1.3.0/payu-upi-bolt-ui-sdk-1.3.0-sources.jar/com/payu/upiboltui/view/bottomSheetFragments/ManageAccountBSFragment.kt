package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.ManageAccountModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsHeaderSubHeaderIvHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class ManageAccountBSFragment : BaseBottomSheetFragment() {
    private var manageAccountModel: ManageAccountModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            manageAccountModel = it.getParcelable(DATA)
        }
    }
    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        val model = manageAccountModel
        if (model != null) {
            if (model.account.bankAccounts.vpa.isNullOrEmpty().not()
                && model.account.bankAccounts.mbeba == PayUUpiConstant.PAYU_VALUE_Y
            ) {
                val layoutResetUPIPin =
                    view.findViewById<ConstraintLayout>(R.id.layout_primary_account)
                layoutResetUPIPin.visibility = View.VISIBLE

                val restPinHandler = BsHeaderSubHeaderIvHandler()
                restPinHandler.init(
                    layoutResetUPIPin,
                    R.drawable.payu_refresh,
                    context.getString(R.string.payu_reset_upi_pin),
                    context.getString(R.string.payu_reset_current_pin),
                    true
                )

                layoutResetUPIPin.setAvoidMultiClickListener {
                    logCTClickEvent(CLConstant.PAYU_CT_RESET_MPIN, model.account)
                    upiFixedBottomSheetData?.upiBoltListener?.onClick(
                        UpiPluginAction.M_PIN_SETUP, model.account
                    )
                }
                val layoutChangeUPIPin =
                    view.findViewById<ConstraintLayout>(R.id.layout_change_pin)
                layoutChangeUPIPin.visibility = View.VISIBLE

                val changePinHandler = BsHeaderSubHeaderIvHandler()
                changePinHandler.init(
                    layoutChangeUPIPin,
                    R.drawable.ic_payu_change_pin,
                    context.getString(R.string.payu_change_upi_pin),
                    context.getString(R.string.payu_change_current_pin),
                    true
                )
                layoutChangeUPIPin.setAvoidMultiClickListener {
                    logCTClickEvent(CLConstant.PAYU_CT_CHANGE_MPIN, model.account)
                    upiFixedBottomSheetData?.upiBoltListener?.onClick(
                        UpiPluginAction.CHANGE_PIN,
                        model.account
                    )
                }

                val layoutCheckBalance =
                    view.findViewById<ConstraintLayout>(R.id.layout_payment_info)
                layoutCheckBalance.visibility = View.VISIBLE

                val layoutAccountBalance = view.findViewById<CardView>(R.id.cvAccountBalance)
                val tvBankName = view.findViewById<TextView>(R.id.tvBankName)
                val tvBankAccountNumber =
                    view.findViewById<TextView>(R.id.tvBankAccountNumber)
                val tvAccountBalance = view.findViewById<TextView>(R.id.tvAccountBalance)
                val tvCheckBalanceError =
                    view.findViewById<TextView>(R.id.tvCheckBalanceError)

                if (model.checkBalanceError == UpiPluginAction.CHECK_BALANCE_ERROR) {
                    layoutAccountBalance.visibility = View.VISIBLE
                    layoutCheckBalance.visibility = View.VISIBLE

                    tvBankName.text = model.account.bankName
                    tvAccountBalance.visibility = View.GONE
                    tvCheckBalanceError.visibility = View.VISIBLE
                    tvCheckBalanceError.text = model.errorMessage
                } else if (model.balance != null) {
                    layoutAccountBalance.visibility = View.VISIBLE
                    layoutCheckBalance.visibility = View.GONE

                    tvBankName.text = model.account.bankName
                    tvBankAccountNumber.visibility = View.VISIBLE
                    tvAccountBalance.visibility = View.VISIBLE
                    tvCheckBalanceError.visibility = View.GONE
                    tvBankAccountNumber.text =
                        getString(R.string.payu_bolt_upi_id, model.account.bankAccounts.vpa)
                    tvAccountBalance.text = context.getString(
                        R.string.payu_rupees_symbol,
                        PayUUtils.formatAmount(model.balance.toString())
                    )
                } else {
                    layoutAccountBalance.visibility = View.GONE
                }

                val checkBalanceIvHandler = BsHeaderSubHeaderIvHandler()
                checkBalanceIvHandler.init(
                    layoutCheckBalance,
                    R.drawable.payu_check_balance,
                    context.getString(R.string.payu_check_balance),
                    context.getString(R.string.payu_check_balance_description),
                    true
                )
                layoutCheckBalance.setAvoidMultiClickListener {
                    logCTClickEvent(CLConstant.PAYU_CT_CHECK_BALANCE, model.account)
                    upiFixedBottomSheetData?.upiBoltListener?.onClick(
                        UpiPluginAction.CHECK_BALANCE,
                        model.account
                    )
                }
            }
        }

        val layoutDeleteAccount =
            view.findViewById<ConstraintLayout>(R.id.layout_delete_account)
        layoutDeleteAccount.visibility = View.VISIBLE

        val btHeader = view.findViewById<ConstraintLayout>(R.id.btHeader)
        btHeader.background =
            ContextCompat.getDrawable(context, R.drawable.payu_rounded_corner_flat_f9fafe)

        BottomSheetHeader(
            view,
            context.getString(R.string.payu_manage_account),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        val bsHeaderSubHeaderIvHandler = BsHeaderSubHeaderIvHandler()

        bsHeaderSubHeaderIvHandler.init(
            layoutDeleteAccount,
            R.drawable.payu_delete,
            context.getString(R.string.payu_delete_account),
            context.getString(R.string.payu_delete_account_info),
            true
        )
        layoutDeleteAccount.setAvoidMultiClickListener {
            model?.account?.let { logCTClickEvent(CLConstant.PAYU_CT_DELETE_ACCOUNT, it) }
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION,
                model?.account
            )

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun logCTClickEvent(eventName: String, account: PayUCustomerBankAccounts) {
        val map = HashMap<String, Any>().apply {
            account.bankAccounts.accountNo?.let {
                this[CLConstant.PAYU_CT_ACCOUNT] = it
            }
        }
        logCTAEvent(
            eventName, CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNT_OPTIONS,
            map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
    }

    companion object {
        @JvmStatic
        fun newInstance(
            data: ManageAccountModel,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            ManageAccountBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}