package com.payu.upiboltui.model

enum class ManagementScreenType {
    ALL,
    TRANSACTIONHISTORY,
    MANAGEUPIACCOUNTS,
    DISPUTE,
    DEREGISTERUPI
}