package com.payu.upiboltui.view.handler

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.listeners.InputWatcher
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import java.util.Calendar
import java.util.Date

internal class BsPinSetupHandler : InputWatcher {

    private var etCard: EditText? = null
    private var etExpiry: EditText? = null
    private var cardNumber: String = ""
    private var cardErrorText: TextView? = null
    private var expiryErrorText: TextView? = null
    private var context: Context? = null
    private var view: View? = null
    private var btnUpiSetup: ConstraintLayout? = null
    private var progressBarBtn: ProgressBar? = null
    private var payuButton: TextView? = null
    private var tvHeaderSubtext: TextView? = null

    private var expiryTextWatcher: TextWatcher? = object : TextWatcher {
        override fun beforeTextChanged(
            s: CharSequence?,
            start: Int,
            count: Int,
            after: Int
        ) {
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        }

        override fun afterTextChanged(s: Editable?) {
            expiryErrorText?.isVisible = false
            if (s != null) {
                formatExpiry(s)
            }
            removeExpiryFocus()
        }

    }

    private var cardTextWatcher: TextWatcher? = object : TextWatcher {
        override fun beforeTextChanged(
            s: CharSequence?,
            start: Int,
            count: Int,
            after: Int
        ) {
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        }

        override fun afterTextChanged(s: Editable?) {
            cardErrorText?.isVisible = false
            if (s != null) {
                formatCardNumber(s)
            }
            if (etCard?.text?.length == 7) {
                etCard?.clearFocus()
                if (removeExpiryFocus().not()) {
                    etExpiry?.requestFocus()
                }
            }
        }
    }

    private fun removeExpiryFocus(): Boolean {
        if (etExpiry?.text?.length == 7) {
            etExpiry?.clearFocus()
            context?.let { ctxt ->
                view?.let { vw ->
                    PayUAndroidUtils.hideSoftKeyboard(ctxt, vw)
                    return true
                }
            }
        }
        return false
    }

    fun init(
        view: View,
        context: Context,
        fixedRoundedCornerBottomSheet: FixedRoundedCornerBottomSheet,
        upiBoltListener: PayUUPIBoltOnClickListener?,
        onSetupClick: (cardNumber: String, expiry: String) -> Unit
    ) {
        this.context = context
        this.view = view
        val layoutCard: ConstraintLayout? = view.findViewById(R.id.layoutCard)
        val layoutExpiry: ConstraintLayout? = view.findViewById(R.id.layoutExpiry)
        etCard = layoutCard?.findViewById(R.id.etSetMPinInput)
        etCard?.hint = PayUUPIBoltUiConstant.PAYU_CARD_HINT
        etCard?.addTextChangedListener(cardTextWatcher)
        etExpiry = layoutExpiry?.findViewById(R.id.etSetMPinInput)
        etExpiry?.hint = PayUUPIBoltUiConstant.PAYU_EXPIRY_HINT
        etExpiry?.addTextChangedListener(expiryTextWatcher)

        val tvCardText: TextView? = layoutCard?.findViewById(R.id.tvSetMPinItemHeader)
        val tvExpiryText: TextView? = layoutExpiry?.findViewById(R.id.tvSetMPinItemHeader)
        btnUpiSetup = view.findViewById(R.id.btnUpiSetup)
        payuButton = view.findViewById(R.id.payuButton)
        progressBarBtn = view.findViewById(R.id.cpbProgressBarBtn)
        cardErrorText = layoutCard?.findViewById(R.id.tvErrorTextUPISetup)
        expiryErrorText = layoutExpiry?.findViewById(R.id.tvErrorTextUPISetup)
        tvHeaderSubtext = view.findViewById(R.id.tvHeaderSubtext)
        btnUpiSetup?.background =
            ContextCompat.getDrawable(context, R.drawable.payu_rounded_corner_grey)
        payuButton?.text = context.getString(R.string.proceed)
        tvExpiryText?.text = context.getString(R.string.payu_expiry)
        tvCardText?.text = context.getString(R.string.payu_your_debit_card_s_last_6_digits)

        BottomSheetHeader(
            view,
            context.getString(R.string.payu_set_mpin_header),
            bottomSheet = fixedRoundedCornerBottomSheet,
            boltListener = upiBoltListener
        )

        btnUpiSetup?.setAvoidMultiClickListener {
            cardErrorText?.isVisible = false
            expiryErrorText?.isVisible = false
            val expiry = getValidExpiryDate(etExpiry?.text?.toString())
            if (cardNumber.isEmpty()) {
                cardErrorText?.isVisible = true
                cardErrorText?.text = context.getString(R.string.payu_empty_card_number_error)
            } else if (expiry.isNullOrEmpty()) {
                expiryErrorText?.isVisible = true
                expiryErrorText?.text = context.getString(R.string.payu_invalid_card_expiry_error)
            } else {
                payuButton?.text = ""
                btnUpiSetup?.isClickable = false
                progressBarBtn?.isVisible = true
                onSetupClick.invoke(cardNumber, expiry)
            }
        }

        tvHeaderSubtext?.text = context.getString(R.string.payu_set_mpin_sub_header)
        tvHeaderSubtext?.isVisible = true
    }

    private fun formatCardNumber(editable: Editable) {
        // Remove any non-digit characters
        val cleanedCardNumber = editable.toString().replace("\\D".toRegex(), "")
        cardNumber = cleanedCardNumber

        // Check if the cleaned card number has the required length
        if (cleanedCardNumber.length <= 6) {
            val formattedText = StringBuilder()

            // Append the first two characters
            if (cleanedCardNumber.length > 1) {
                formattedText.append(cleanedCardNumber, 0, 2)
            } else {
                formattedText.append(cleanedCardNumber)
            }

            // Append a space if there is a third character
            if (cleanedCardNumber.length >= 3) {
                formattedText.append(" ")
            }

            // Append the remaining characters
            if (cleanedCardNumber.length > 2) {
                formattedText.append(cleanedCardNumber.substring(2))
            }

            // Update the EditText with the formatted text
            etCard?.removeTextChangedListener(cardTextWatcher)
            editable.replace(0, editable.length, formattedText.toString())
            etCard?.setText(formattedText.toString())
            if (formattedText.toString().length >= 3) {
                etCard?.setSelection(editable.length + 1)
            } else {
                etCard?.setSelection(editable.length)
            }
            etCard?.addTextChangedListener(cardTextWatcher)
        } else {
            // Reset the EditText if the input is not valid
            etCard?.error = etCard?.context?.getString(R.string.payu_invalid_card_number)
        }
    }

    private fun formatExpiry(editable: Editable) {
        // Remove any non-digit characters
        val cleanedCardNumber = editable.toString().replace("/", "")

        // Check if the cleaned card number has the required length
        if (cleanedCardNumber.length <= 6) {
            val formattedText = StringBuilder()

            // Append the first two characters
            if (cleanedCardNumber.length > 1) {
                formattedText.append(cleanedCardNumber, 0, 2)
            } else {
                formattedText.append(cleanedCardNumber)
            }

            // Append a space if there is a third character
            if (cleanedCardNumber.length >= 3) {
                formattedText.append("/")
            }

            // Append the remaining characters
            if (cleanedCardNumber.length > 2) {
                formattedText.append(cleanedCardNumber.substring(2))
            }

            // Update the EditText with the formatted text
            etExpiry?.removeTextChangedListener(expiryTextWatcher)
            editable.replace(0, editable.length, formattedText.toString())
            etExpiry?.setText(formattedText.toString())
            if (formattedText.toString().length >= 3) {
                etExpiry?.setSelection(editable.length + 1)
            } else {
                etExpiry?.setSelection(editable.length)
            }
            etExpiry?.addTextChangedListener(expiryTextWatcher)
        } else {
            // Reset the EditText if the input is not valid
            etExpiry?.error = etExpiry?.context?.getString(R.string.payu_invalid_expiry)
        }
    }

    override fun onInputReceived(input: String, inputType: Int) {
        when (inputType) {
            R.id.etSetMPinInput -> etExpiry?.setText(input)
        }
    }

    private fun getValidExpiryDate(expiry: String?): String? {
        if (expiry.isNullOrEmpty()) return null
        val calendar = Calendar.getInstance()
        calendar.time = Date()
        val currentMonth = calendar.get(Calendar.MONTH) + 1 // Month starting from 0 in Calendar.MONTH
        val currentYear = calendar.get(Calendar.YEAR)
        try {
            val list = expiry.split("/")
            val month = list[0].toInt()
            if (month == 0) {
                return null
            }
            if (list[1].length > 4 || list[1].length == 1) {
                return null
            }
            val year = getValidExpiryYear(list[1]).toInt()
            return if (year < currentYear || (month < currentMonth && year == currentYear)) {
                null
            } else {
                "$month/$year"
            }
        } catch (ex: Exception) {
            return null
        }
    }

    fun hideProgressLoader() {
        payuButton?.text = context?.getString(R.string.proceed)
        btnUpiSetup?.isClickable = true
        progressBarBtn?.isVisible = false
    }

    private fun getValidExpiryYear(year: String): String {
        return when (year.length) {
            2 -> "20${year}"
            3 -> "2${year}"
            else -> year
        }
    }
}