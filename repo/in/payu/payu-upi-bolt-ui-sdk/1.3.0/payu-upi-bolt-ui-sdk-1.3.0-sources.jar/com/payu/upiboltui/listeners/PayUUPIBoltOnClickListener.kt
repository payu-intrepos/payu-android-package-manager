package com.payu.upiboltui.listeners

import com.payu.upiboltui.model.UpiPluginAction

interface PayUUPIBoltOnClickListener {
    fun onClick(screenType: UpiPluginAction?, result: Any? = null)
}