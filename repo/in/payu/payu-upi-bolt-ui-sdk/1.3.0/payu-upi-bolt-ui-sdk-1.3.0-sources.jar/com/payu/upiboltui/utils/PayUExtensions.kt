package com.payu.upiboltui.utils

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import androidx.annotation.DrawableRes
import com.payu.upiboltui.model.ImageDetails
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal object PayUExtensions {

    /**
     * Loads image asynchronously using coroutines without blocking the UI thread.
     * This is the preferred method for RecyclerView adapters.
     * 
     * @param url The image URL to load
     * @param placeholder Placeholder drawable resource ID
     * @param scope CoroutineScope to launch the image loading coroutine
     * @param onImageLoaded Optional callback when image is loaded
     * @return Job that can be cancelled when view is recycled
     */
    fun ImageView.loadImageUrlAsync(
        url: String?, 
        @DrawableRes placeholder: Int,
        scope: CoroutineScope,
        onImageLoaded: ((Bitmap?) -> Unit)? = null
    ): Job? {
        // Set placeholder immediately
        setImageResource(placeholder)
        
        if (url.isNullOrEmpty()) {
            return null
        }
        
        // Launch async image loading
        return scope.launch(Dispatchers.Main) {
            try {
                // Load image on IO thread
                val bitmap = withContext(Dispatchers.IO) {
                    loadImageBitmap(url)
                }
                
                // Update UI on main thread
                bitmap?.let {
                    setImageBitmap(it)
                    onImageLoaded?.invoke(it)
                } ?: run {
                    // If loading failed, keep placeholder
                    onImageLoaded?.invoke(null)
                }
            } catch (e: Exception) {
                // On error, keep placeholder
                onImageLoaded?.invoke(null)
            }
        }
    }

    /**
     * Loads image bitmap from URL on background thread.
     * This is a suspend function that should be called from a coroutine.
     */
    private suspend fun loadImageBitmap(url: String): Bitmap? {
        return withContext(Dispatchers.IO) {
            var connection: java.net.HttpURLConnection? = null
            try {
                val stringUrl = java.net.URL(url)
                connection = stringUrl.openConnection() as java.net.HttpURLConnection
                connection.connect()
                android.graphics.BitmapFactory.decodeStream(connection.inputStream)
            } catch (e: Exception) {
                android.util.Log.d(
                    PayUExtensions::class.simpleName,
                    "Exception while Fetching Image: ${e.message}"
                )
                null
            } finally {
                connection?.disconnect()
            }
        }
    }

    /**
     * @deprecated This method blocks the UI thread. Use loadImageUrlAsync instead.
     */
    @Deprecated("Use loadImageUrlAsync for non-blocking image loading")
    fun ImageView.loadImageUrl(url: String?, @DrawableRes placeholder: Int) {
        setImageResource(placeholder)
        if(url.isNullOrEmpty().not()) {
            val result = FetchImageFromURLTask().execute(url).get()
            result?.image?.let {
                setImageBitmap(it)
            }
        }
    }

    /**
     * @deprecated This method blocks the UI thread. Use loadImageUrlAsync instead.
     */
    @Deprecated("Use loadImageUrlAsync for non-blocking image loading")
    fun ImageView.setImage(imageView: ImageView?, url: String?, @DrawableRes placeholder: Int) {
        if(url.isNullOrEmpty().not()) {
            val result = FetchImageFromURLTask().execute(url).get()
            if (imageView == null || result == null) return
//        if (result.type == DrawableType.Bitmap)
            imageView.setImageBitmap(result.image as Bitmap)
        }

//        else if (result.type == DrawableType.PictureDrawable) {
//            imageView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
//            imageView.setImageDrawable(result.image as Drawable)
//        }
    }

    fun String.formatAccountNumber(): String {
        if (length >= 4) {
            return "**${substring(length - 4, length)}"
        }
        return this
    }
}