package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.upiboltui.R
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.utils.PayUUtils

class BottomSheetFooter(view: View) {

    private var ivFooterBankLogo: ImageView? = null
    private var tvFooterBankLogoSeparator: TextView? = null

    init {
        ivFooterBankLogo = view.findViewById(R.id.ivFooterBankLogo)
        tvFooterBankLogoSeparator = view.findViewById(R.id.tvFooterBankLogoSeparator)
        val bhimLogo = view.findViewById<ImageView>(R.id.ivFooterBhimLogo)

        ivFooterBankLogo?.visibility = View.VISIBLE
        tvFooterBankLogoSeparator?.visibility = View.VISIBLE
        if (InternalConfig.config?.pluginTypes?.first() == PluginType.AXIS
            || InternalConfig.config?.issuingBanks?.first() == PluginType.AXIS.pluginName) { // AXIS
            ivFooterBankLogo?.setImageResource(R.drawable.axis_logo)
        } else if (InternalConfig.config?.pluginTypes?.first() == PluginType.HDFC
            || InternalConfig.config?.issuingBanks?.first() == PluginType.HDFC.pluginName) { // HDFC
            ivFooterBankLogo?.setImageResource(R.drawable.hdfc_logo)
        }
        bhimLogo.setImageResource(
            if (PayUUtils.isOnlyBhimPgSelected())
                R.drawable.bhim_vega_logo
            else
                R.drawable.payu_bhim_logo
        )
    }
}