package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsHeaderSubHeaderIvHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class ManagementOptionsBSFragment : BaseBottomSheetFragment() {


    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        val transactionHistoryLayout =
            view.findViewById<ConstraintLayout>(R.id.layout_payment_info)
        val manageAccountLayout =
            view.findViewById<ConstraintLayout>(R.id.layout_primary_account)
        val queryLayout =
            view.findViewById<ConstraintLayout>(R.id.layout_change_pin)
        val layoutDeleteAccount =
            view.findViewById<ConstraintLayout>(R.id.layout_delete_account)

        manageAccountLayout.visibility = View.VISIBLE
        queryLayout.visibility = View.VISIBLE
        layoutDeleteAccount.visibility = View.VISIBLE
        transactionHistoryLayout.visibility = View.VISIBLE


        val btHeader = view.findViewById<ConstraintLayout>(R.id.btHeader)
        btHeader.background =
            ContextCompat.getDrawable(context, R.drawable.payu_rounded_corner_flat_f9fafe)
        BottomSheetHeader(
            view,
            context.getString(R.string.payu_manage_upi),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val bsHeaderSubHeaderIvHandler = BsHeaderSubHeaderIvHandler()
        bsHeaderSubHeaderIvHandler.init(
            transactionHistoryLayout,
            R.drawable.payu_receipt,
            context.getString(R.string.payu_transaction_history),
            context.getString(R.string.payu_view_all_transaction),
            true
        )

        transactionHistoryLayout.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_SCREEN_TXN_HISTORY,
                CLConstant.PAYU_CT_SCREEN_MANAGEMENT,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.TRANSACTION_HISTORY)
        }

        bsHeaderSubHeaderIvHandler.init(
            manageAccountLayout,
            R.drawable.payu_settings,
            context.getString(R.string.payu_manage_upi_accounts),
            context.getString(R.string.payu_manage_upi_accounts_description),
            true
        )

        manageAccountLayout.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNTS,
                CLConstant.PAYU_CT_SCREEN_MANAGEMENT,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.MANAGE_ACCOUNT)
        }

        bsHeaderSubHeaderIvHandler.init(
            queryLayout,
            R.drawable.payu_query,
            context.getString(R.string.payu_query_dispute),
            context.getString(R.string.payu_view_all_concern),
            true
        )

        queryLayout.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_SCREEN_VIEW_DISPUTES,
                CLConstant.PAYU_CT_SCREEN_MANAGEMENT,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.RAISE_DISPUTE_LIST)
        }

        bsHeaderSubHeaderIvHandler.init(
            layoutDeleteAccount,
            R.drawable.payu_ic_deregister_accounts,
            context.getString(R.string.payu_deregister_all_accounts),
            context.getString(R.string.payu_deregister_all_accounts_description),
            true
        )

        layoutDeleteAccount.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_SCREEN_DEREGISTER_UPI,
                CLConstant.PAYU_CT_SCREEN_MANAGEMENT,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CONFIRMATION)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {
        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            ManagementOptionsBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}