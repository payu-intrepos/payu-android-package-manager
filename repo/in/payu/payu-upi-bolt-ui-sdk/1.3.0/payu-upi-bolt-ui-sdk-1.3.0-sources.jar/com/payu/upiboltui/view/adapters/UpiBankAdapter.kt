package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.IinLogoMap
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrl
import com.payu.upiboltui.utils.setAvoidMultiClickListener


internal class UpiBankAdapter(
    var bankData: List<PayUBankData>,
    private val upiBoltListener: PayUUPIBoltOnClickListener?,
    private val onNoItemsFound: (isVisible: Boolean, query: String?) -> Unit
) : RecyclerView.Adapter<UpiBankAdapter.ViewHolder>() {

    private var TAG = javaClass.simpleName
    private var filteredBankData: ArrayList<PayUBankData> = ArrayList()

    init {
        bankData.forEach {
            filteredBankData.add(it)
        }
    }


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view: View = inflater.inflate(R.layout.upi_bank_selection_screen_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.ivRightArrow.visibility = View.VISIBLE

        val url = filteredBankData[position].logo
        val logoUrl =
            if (url.isNullOrEmpty() && IinLogoMap.containsKey(filteredBankData[position].iin))
                IinLogoMap[filteredBankData[position].iin]
            else
                url
        holder.ivBankLogo.loadImageUrl(logoUrl, R.drawable.payu_netbanking)

        holder.tvBankName.text = filteredBankData[position].bankName
        holder.rlBankItem.setAvoidMultiClickListener {
            upiBoltListener?.onClick(
                UpiPluginAction.BANK_SELECTION_DONE,
                filteredBankData[position]
            )
        }
    }

    override fun getItemCount(): Int {
        return filteredBankData.size
    }

    fun getFilter(): Filter {
        return bankFilter
    }

    private val bankFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val filteredList: ArrayList<PayUBankData> = ArrayList()
            if (constraint.isNullOrEmpty()) {
                bankData.let { filteredList.addAll(it) }
            } else {
                val query = constraint.toString().trim().lowercase()
                bankData.forEach {
                    if (it.bankName.lowercase().contains(query)) {
                        filteredList.add(it)
                    }
                }
            }
            val results = FilterResults()
            results.values = filteredList
            return results
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            if (results?.values is ArrayList<*>) {
                val list = results.values as ArrayList<PayUBankData>
                if (list.isNotEmpty()) {
                    onNoItemsFound.invoke(true, constraint?.toString())
                    filteredBankData.clear()
                    filteredBankData.addAll(list)
                    notifyDataSetChanged()
                } else {
                    onNoItemsFound.invoke(false, constraint?.toString())
                }
            }
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivBankLogo: ImageView = itemView.findViewById(R.id.ivBankLogo)
        var tvBankName: TextView = itemView.findViewById(R.id.tvBankName)
        var rlBankItem: ConstraintLayout = itemView.findViewById(R.id.rlBankItem)
        var ivRightArrow: ImageView = itemView.findViewById(R.id.ivRightArrow)

    }
}