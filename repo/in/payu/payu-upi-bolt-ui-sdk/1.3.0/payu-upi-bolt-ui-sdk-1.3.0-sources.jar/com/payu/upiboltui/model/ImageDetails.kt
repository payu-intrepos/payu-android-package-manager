package com.payu.upiboltui.model

import android.graphics.Bitmap

data class ImageDetails(
    val imageUrl: String? = null,
    val defaultDrawableId: Int? = null,
    val updatedOn: Long? = null,
    var image: Bitmap? = null
)
