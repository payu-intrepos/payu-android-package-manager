package com.payu.upiboltui.utils

import android.content.Context
import android.os.CountDownTimer
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.BuildConfig
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.model.InternalConfig
import org.json.JSONArray
import org.json.JSONObject
import java.util.HashMap

class PaymentManager {

    private var txnTimer: CountDownTimer? = null
    private var hashCallTimerCount = 0
    private var apiCallTimerCount = 0
    private var verifyResponse: PayUUPIBoltResponse? = null
    private var verifyCallback: PayUUPIBoltCallBack? = null
    private var startTime: Long = 0

    fun makePayment(
        context: Context,
        accountData: PayUAccountDetail,
        payUUPIProCallBack: PayUUPIBoltCallBack,
        ctFlowType: String
    ) {
        val paymentParams = InternalConfig.paymentParams

        if (paymentParams != null) {
            paymentParams.accountDetail = accountData
            paymentParams.additionalParams = hashMapOf(
                PayUUpiConstant.ANALYTICS_DATA to getAnalyticsString()
            )
            startTime = System.currentTimeMillis()
            logCTPaymentEvent(
                context,
                CLConstant.PAYU_CT_PAYMENT_STATUS,
                CLConstant.PAYU_CT_INITIATED,
                ctFlowType, amount = paymentParams.amount,
                txnId = paymentParams.txnId
            )
            PayUUPIBoltUI.getCoreInstance()?.pay(paymentParams, object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    logCTPaymentEvent(
                        context, CLConstant.PAYU_CT_PAYMENT_STATUS,
                        CLConstant.PAYU_EVENT_SUCCESS, ctFlowType,
                        amount = paymentParams.amount,
                        txnId = paymentParams.txnId
                    )
                    payUUPIProCallBack.onPayUSuccess(response)
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    val status = if (response.code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE)
                        CLConstant.PAYU_EVENT_CANCELLED
                    else
                        CLConstant.PAYU_EVENT_FAILURE
                    logCTPaymentEvent(
                        context, CLConstant.PAYU_CT_PAYMENT_STATUS,
                        status, ctFlowType,
                        amount = paymentParams.amount, response.message,
                        txnId = paymentParams.txnId, code = response.code.toString()
                    )
                    payUUPIProCallBack.onPayUFailure(response)
                }
            })
        } else {
            val response = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_PAY,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE
            )
            logCTPaymentEvent(
                context, CLConstant.PAYU_CT_PAYMENT_STATUS,
                CLConstant.PAYU_EVENT_FAILURE,
                ctFlowType,
                response.message,
                code = response.code.toString()
            )
            payUUPIProCallBack.onPayUFailure(response)
        }
    }

    fun verifyPayment(
        context: Context,
        payUUPIProCallBack: PayUUPIBoltCallBack,
        timeout: Long = PayUUpiConstant.CHECK_STATUS_TIMEOUT,
        ctFlowType: String
    ) {
        startTime = System.currentTimeMillis()
        logCTPaymentEvent(
            context,
            CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
            CLConstant.PAYU_CT_INITIATED,
            ctFlowType, amount = InternalConfig.paymentParams?.amount,
            txnId = InternalConfig.paymentParams?.txnId
        )

        hashCallTimerCount = 0
        apiCallTimerCount = 0
        verifyResponse = null
        txnTimer = PayUAndroidUtils.getCountDownTimer(timeout, PayUUpiConstant.CHECK_STATUS_TIME_INTERVAL, onTimerFinish = {

//            Log.d("verifypayment", "timeout - ${verifyResponse?.code} ${verifyResponse?.message} ${verifyResponse?.result.toString()}")
            verifyResponse?.let { response ->
                if (response.code == PayUResponseCodes.PAYU_SUCCESS_STATUS) {
                    logCTPaymentEvent(
                        context,
                        CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
                        CLConstant.PAYU_EVENT_SUCCESS,
                        ctFlowType,
                        amount = InternalConfig.paymentParams?.amount,
                        verifyCount = apiCallTimerCount,
                        txnId = InternalConfig.paymentParams?.txnId
                    )
                    payUUPIProCallBack.onPayUSuccess(response)
                } else {
                    logCTPaymentEvent(
                        context,
                        CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        ctFlowType, amount = InternalConfig.paymentParams?.amount,
                        response.message, apiCallTimerCount,
                        txnId = InternalConfig.paymentParams?.txnId,
                        code = response.code.toString()
                    )
                    payUUPIProCallBack.onPayUFailure(response)
                }
            }
        }, onInterval = {
            if (hashCallTimerCount > PayUUpiConstant.HASH_TIMOUT_COUNT
                && (verifyResponse == null || verifyResponse?.message == PayUResponseMessages.HASH_NOT_RECEIVED)) {
                cancelVerify()
                val response = PayUUPIBoltResponse(
                    PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS,
                    PayUResponseCodes.HASH_NOT_RECEIVED_CODE,
                    PayUResponseMessages.HASH_NOT_RECEIVED
                )
                logCTPaymentEvent(
                    context,
                    CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
                    CLConstant.PAYU_EVENT_FAILURE,
                    ctFlowType, amount = InternalConfig.paymentParams?.amount,
                    response.message, apiCallTimerCount,
                    txnId = InternalConfig.paymentParams?.txnId,
                    code = response.code.toString()
                )
                payUUPIProCallBack.onPayUFailure(response)
            } else {
//                Log.d("verifypayment", "hashcount - $hashCallTimerCount")
                hashCallTimerCount += 1
                callCheckStatusAPI(context, ctFlowType, payUUPIProCallBack)
            }
        })
        txnTimer?.start()
    }

    private fun callCheckStatusAPI(context: Context, ctFlowType: String, payUUPIProCallBack: PayUUPIBoltCallBack) {

        val callBack = object : PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                response.result?.let {
//                    Log.d("verifypayment", "response - ${response.code} ${response.message} ${response.result?.toString()}")
                    val resultJson = JSONObject(it.toString())
                    when (val status = resultJson.getString(PayUUpiConstant.VERIFY_STATUS)) {
                        PayUUpiConstant.VERIFY_STATUS_SUCCESS -> {
                            cancelVerify()
                            logCTPaymentEvent(
                                context,
                                CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
                                CLConstant.PAYU_EVENT_SUCCESS,
                                ctFlowType,
                                amount = InternalConfig.paymentParams?.amount,
                                verifyCount = apiCallTimerCount,
                                txnId = InternalConfig.paymentParams?.txnId
                            )
                            payUUPIProCallBack.onPayUSuccess(
                                PayUUPIBoltResponse(
                                    PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS,
                                    PayUResponseCodes.PAYU_SUCCESS_STATUS,
                                    response.message,
                                    resultJson.toString()
                                )
                            )
                        }

                        PayUUpiConstant.VERIFY_STATUS_FAILURE -> {
                            cancelVerify()
                            logCTPaymentEvent(
                                context,
                                CLConstant.PAYU_CT_VERIFY_PAYMENT_STATUS,
                                CLConstant.PAYU_EVENT_FAILURE,
                                ctFlowType, amount = InternalConfig.paymentParams?.amount,
                                response.message, apiCallTimerCount,
                                txnId = InternalConfig.paymentParams?.txnId,
                                code = PayUResponseCodes.PAYU_FAILED_STATUS.toString()
                            )
                            payUUPIProCallBack.onPayUFailure(
                                PayUUPIBoltResponse(
                                    PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS,
                                    PayUResponseCodes.PAYU_FAILED_STATUS,
                                    response.message, resultJson.toString()
                                )
                            )
                        }

                        else -> {
                            verifyResponse = PayUUPIBoltResponse(
                                PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS,
                                PayUResponseCodes.PAYU_SUCCESS_STATUS,
                                response.message, resultJson.toString()
                            )
                        }
                    }
                }
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                if (verifyResponse == null) {
                    verifyResponse = response
                }
            }
        }
        if (InternalConfig.paymentParams?.txnId.isNullOrEmpty().not()) {
            verifyCallback = callBack
            PayUUPIBoltUI.getCoreInstance()
                ?.verifyTransactionStatus(InternalConfig.paymentParams?.txnId ?: "", callBack)
            apiCallTimerCount += 1
//        Log.d("verifypayment", "apicount - $apiCallTimerCount")
        } else {
            cancelVerify()
        }
    }

    fun cancelVerify() {
        txnTimer?.cancel()
        verifyCallback = null
    }

    private fun logCTPaymentEvent(
        context: Context,
        eventName: String,
        status: String,
        type: String,
        amount: String? = null,
        message: String? = null,
        verifyCount: Int = 0,
        txnId: String? = null,
        code: String? = null
    ) {
        val map = HashMap<String, Any>().apply {
            message?.let { this[CLConstant.PAYU_CT_MESSAGE] = message }
            if (verifyCount > 0) {
                this[CLConstant.PAYU_CT_VERIFICATION_COUNT] = verifyCount
            }
        }
        AnalyticsUtils.setCTLogsForUPIWithData(
            context, eventName, map, type, status = status, txnId = txnId
        )
        PayUUtils.logKibanaEvents(
            context, eventName,
            JSONObject().apply {
                put(CLConstant.PAYU_EVENT_TYPE, type)
                message?.let {
                    put(CLConstant.PAYU_CT_MESSAGE, it)
                }
                if (verifyCount > 0) {
                    put(CLConstant.PAYU_CT_VERIFICATION_COUNT, verifyCount)
                }
            }.toString(),
            eventType = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventType.Error else AnalyticsUtils.EventType.Info,
            eventSeverity = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventSeverity.High else AnalyticsUtils.EventSeverity.Low,
            status = status,
            code = code,
            amount = amount,
            time = if (status == CLConstant.PAYU_CT_INITIATED) null else System.currentTimeMillis() - startTime,
            txnId = txnId
        )
    }

    private fun getAnalyticsString(): String {
        val analyticsJsonArray = JSONArray()

        val analyticsJsonObject = JSONObject()
        analyticsJsonObject.put(PayUUpiConstant.NAME_KEY, PayUUpiConstant.PAYU_BOLT_UI_SDK_NAME)
        analyticsJsonObject.put(PayUUpiConstant.PLATFORM_KEY, PayUUpiConstant.PLATFORM_VALUE)
        analyticsJsonObject.put(PayUUpiConstant.VERSION_KEY, BuildConfig.VERSION_NAME)
        analyticsJsonArray.put(analyticsJsonObject)
        return analyticsJsonArray.toString()
    }

}
