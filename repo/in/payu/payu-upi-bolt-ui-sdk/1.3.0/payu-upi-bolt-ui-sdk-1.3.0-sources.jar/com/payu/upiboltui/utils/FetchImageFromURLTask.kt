package com.payu.upiboltui.utils

import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.util.Log
import com.payu.upiboltui.model.ImageDetails
import java.net.HttpURLConnection
import java.net.URL


class FetchImageFromURLTask: AsyncTask<String?, Void?, ImageDetails?>() {

    override fun doInBackground(vararg url: String?): ImageDetails {
        val stringUrl = URL(url[0])
        var connection: HttpURLConnection? = null
        return try {
            connection = stringUrl.openConnection() as HttpURLConnection
            connection.connect()
            ImageDetails(image = BitmapFactory.decodeStream(connection.inputStream))
        } catch (e: Exception) {
            Log.d(FetchImageFromURLTask::class.simpleName,"Exception while Fetching Image : " + e.message)
            return ImageDetails(image = null)
        } finally {
            connection?.disconnect()
        }
    }
}
