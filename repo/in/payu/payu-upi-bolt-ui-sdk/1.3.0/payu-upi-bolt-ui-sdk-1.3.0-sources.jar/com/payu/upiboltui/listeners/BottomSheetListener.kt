package com.payu.upiboltui.listeners

import android.view.View
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

interface BottomSheetListener {

    fun getInflatedView(view: View, roundedCornerBottomSheet: FixedRoundedCornerBottomSheet)
    fun handleBottomSheetClose()

    fun handleBottomSheetBackPress()

    fun handleBottomSheetUpdate()
}