package com.payu.upiboltui.viewmodel

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.listeners.OTPVerificationInterface
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.PayUSimInfo
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.KibanaDataInfo
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.model.WelcomeScreenModel
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

internal open class HandshakeBaseViewModel(application: Application) :
    AndroidViewModel(application) {

    protected val showBottomSheet: MutableLiveData<Event<PayUBottomSheetInfo>> = MutableLiveData()
    val showBottomSheetLiveData: LiveData<Event<PayUBottomSheetInfo>> = showBottomSheet

    val hideBottomSheet: MutableLiveData<String?> = MutableLiveData()

    protected val hideLoaderMutableLiveData: MutableLiveData<Boolean> = MutableLiveData()
    val hideLoaderLiveData: LiveData<Boolean> = hideLoaderMutableLiveData

    private val showSettingErrorMutableLiveData = MutableLiveData<Event<Any>>()
    val showSettingErrorLiveData: LiveData<Event<Any>> = showSettingErrorMutableLiveData

    private val requestPermissionMutableLiveData = MutableLiveData<Event<Any>>()
    val requestPermissionLiveData: LiveData<Event<Any>> = requestPermissionMutableLiveData

    protected val flowCompleteMutableLiveData: MutableLiveData<Boolean> = MutableLiveData()
    val flowCompleteLiveData: LiveData<Boolean> = flowCompleteMutableLiveData

    private val logKibanaMutableLiveData = MutableLiveData<Event<KibanaDataInfo>>()
    val logKibanaDataLiveData: LiveData<Event<KibanaDataInfo>> = logKibanaMutableLiveData

    private val otpVerifyMsgMutableLiveData = MutableLiveData<Event<String>>()
    val otpVerifyMsgLiveData: LiveData<Event<String>> = otpVerifyMsgMutableLiveData

    private val otpTimeoutMutableLiveData: MutableLiveData<Event<Boolean>> = MutableLiveData()
    val otpTimeoutLiveData: LiveData<Event<Boolean>> = otpTimeoutMutableLiveData

    // Fixed: Use SupervisorJob to prevent one failure from cancelling all coroutines
    // and properly cancel on ViewModel cleanup to prevent memory leaks
    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    protected var linkedAccounts: ArrayList<PayUCustomerBankAccounts>? = null

    var action: UpiPluginAction? = null
    var hasSmsConsentShown = false

    private val handShakeTimer = PayUAndroidUtils.getCountDownTimer(
        PayUUpiConstant.BINDING_TIMEOUT_MILLIS,
        onTimerFinish = {
            sendMerchantCallback(
                PayUUPIBoltResponse(
                    getResponseType(),
                    PayUResponseCodes.PAYU_TRANSACTION_TIMEOUT_CODE,
                    PayUResponseMessages.PAYU_TRANSACTION_TIMEOUT_MESSAGE
                ), false
            )
        })

    private fun cancelTimer() {
        handShakeTimer.cancel()
    }

    fun initUPISetUpScreen(
        nextAction: UpiPluginAction,
        nextActionData: Any? = null,
        isNewInstance: Boolean = false
    ) {
        val model = WelcomeScreenModel(
            nextAction,
            PayUUPIBoltUI.getCoreInstance()?.hasPermissions() ?: false,
            nextActionData
        )
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_bolt_welcome_screen,
                UpiPluginAction.WELCOME_SCREEN,
                UpiPluginAction.WELCOME_SCREEN.name,
                model, isNewInstance = isNewInstance,
                ctFlowType = InternalConfig.ctFlowType
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showMobileVerificationScreen(
        flowType: String,
        simInfo: PayUSimInfo,
        onCancel: () -> Unit
    ) {
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.mobile_verification_screen,
            UpiPluginAction.MOBILE_VERIFICATION,
            UpiPluginAction.MOBILE_VERIFICATION.name,
            data = simInfo,
            onUserCancel = onCancel,
            showExitConfirmation = true,
            ctFlowType = flowType
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    internal fun showMobileVerifiedScreen(flowType: String, nextAction: UpiPluginAction?) {
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.upi_verifying_no_screen,
            UpiPluginAction.MOBILE_VERIFIED,
            UpiPluginAction.MOBILE_VERIFIED.name,
            nextAction,
            ctFlowType = flowType
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    internal fun showCommonBSLoaderScreen(onCancel: (() -> Unit)? = null) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_verifying_no_screen,
                UpiPluginAction.COMMON_LOADER,
                UpiPluginAction.COMMON_LOADER.name,
                showExitConfirmation = true,
                onUserCancel = onCancel
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    internal fun showGenericInfoScreen(
        model: GenericInfoModel,
        pluginAction: UpiPluginAction = UpiPluginAction.GENERIC_INFO,
        isNewInstance: Boolean = false
    ) {
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            pluginAction, pluginAction.name,
            model, isNewInstance = isNewInstance
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun showVerifyPaymentScreen(ctFlowType: String, isCancellingTxn: Boolean = false) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_verifying_payment_screen,
                UpiPluginAction.VERIFY_PAYMENT,
                UpiPluginAction.VERIFY_PAYMENT.name,
                isCancellingTxn,
                showExitConfirmation = true,
                ctFlowType = ctFlowType
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    internal fun showBanksListScreen(
        bankData: ArrayList<PayUBankData>,
        isNewInstance: Boolean = false,
        ctFlowType: String
    ) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.bank_selection_bottomsheet,
                UpiPluginAction.BANK_SELECTION,
                UpiPluginAction.BANK_SELECTION.name,
                bankData, isNewInstance = isNewInstance,
                ctFlowType = ctFlowType
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun ensureHandshake() {
        if (PayUUPIBoltUI.getCoreInstance()?.hasPermissions() == true) {
            startHandshake()
        } else {
            if (hasSmsConsentShown) {
                requestPermissionMutableLiveData.value = Event(Any())
            } else {
                hasSmsConsentShown = true
                initUPISetUpScreen(UpiPluginAction.REQUEST_PERMISSION)
            }
        }
    }

    fun startHandshake() {
        val startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_SUBSCRIPTION_INFO_STATUS,
            CLConstant.PAYU_CT_INITIATED,
            type = InternalConfig.ctFlowType
        )
        PayUUPIBoltUI.getCoreInstance()?.getSubscriberInfo(InternalConfig.config?.getPhone() ?: "", object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_SUBSCRIPTION_INFO_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime = startTime, InternalConfig.ctFlowType
                )
                (response.result as? ArrayList<PayUSimInfo>)?.let { simInfoList ->
                    doHandshake(simInfoList)
                } ?: run {
                    sendMerchantCallback(
                        PayUUPIBoltResponse(
                            getResponseType(),
                            PayUResponseCodes.PAYU_SIM_INFO_NOT_AVAILABLE,
                            PayUResponseMessages.PAYU_SIM_INFO_NOT_AVAILABLE_MESSAGE
                        ), false
                    )
                }
            }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_SUBSCRIPTION_INFO_STATUS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime = startTime, InternalConfig.ctFlowType,
                        message = response.message, code = response.code.toString()
                    )
                    handleErrorResponse(response)
                }
            })
    }

    private fun doHandshake(subscriptions: List<PayUSimInfo>) {
        val size = subscriptions.size
        if (size > 0) {
            if (size == 1) {
                val slotIndex = 0
                checkDeviceBindingStatus(subscriptions[slotIndex])
            } else {
                showSimSelectionScreen(subscriptions)
            }
        } else {
            sendMerchantCallback(
                PayUUPIBoltResponse(
                    getResponseType(),
                    PayUResponseCodes.PAYU_SIM_INFO_NOT_AVAILABLE,
                    PayUResponseMessages.PAYU_SIM_INFO_NOT_AVAILABLE_MESSAGE
                ), false
            )
        }
    }

    private fun showSimSelectionScreen(subscriptions: List<PayUSimInfo>) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.sim_selection_bottom_sheet,
                UpiPluginAction.SIM_SELECTION,
                UpiPluginAction.SIM_SELECTION.name,
                 data = subscriptions,
                ctFlowType = InternalConfig.ctFlowType
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun checkDeviceBindingStatus(simInfo: PayUSimInfo) {
        PayUUPIBoltUI.getCoreInstance()?.checkDeviceBinding(
            simInfo.mobileNumber, simInfo.subscriberId, object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    prepareHandShakeData(simInfo, true)
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    if (response.code == PayUResponseCodes.PAYU_DEVICE_BINDING_FAILED) {
                        val registeredMobile =
                            getRegisteredMobileNumber()
                        if (registeredMobile.isNullOrEmpty().not()) {
                            val context = getApplication<Application>()
                            val model = GenericInfoModel(
                                context.getString(R.string.verify_device_error),
                                context.getString(
                                    R.string.payu_device_binding_consent_message,
                                    PayUUtils.getDisplayMobileNumber(registeredMobile ?: "")
                                ),
                                context.getString(R.string.payu_okay),
                                true,
                                UpiPluginAction.DEVICE_BINDING_PROCEED,
                                retryData = simInfo,
                                isCancelable = false,
                                negativeBtnText = context.getString(R.string.payu_cancel),
                                negativeBtnAction = UpiPluginAction.DEVICE_BINDING_FAILED
                            )
                            showGenericInfoScreen(model)
                        } else {
                            if (hasSmsConsentShown) {
                                prepareHandShakeData(simInfo, false)
                            } else {
                                hasSmsConsentShown = true
                                initUPISetUpScreen(UpiPluginAction.MOBILE_VERIFICATION, simInfo)
                            }
                        }
                    } else {
                        response.responseType = getResponseType()
                        sendMerchantCallback(response, false)
                    }
                }
            }
        )
    }

    fun prepareHandShakeData(simInfo: PayUSimInfo, deviceBindingExists: Boolean) {
        val context = getApplication<Application>()
            val onCancel = {
                cancelTimer()
            }

            if (deviceBindingExists) {
                showCommonBSLoaderScreen(onCancel)
            } else {
                showMobileVerificationScreen(InternalConfig.ctFlowType, simInfo, onCancel)
            }
        val startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_HANDSHAKE,
            CLConstant.PAYU_CT_INITIATED,
            type = InternalConfig.ctFlowType
        )
        InternalConfig.isUserRegistrationStarted = true
        InternalConfig.config?.setPhone(simInfo.mobileNumber)
        PayUUPIBoltUI.getCoreInstance()?.checkDeviceStatus(
            simInfo.subscriberId, simInfo.mobileNumber, object : OTPVerificationInterface {
                override fun onOTPListenerStarted() {
                    cancelTimer()
                    // Fixed: Add error handling to prevent uncaught exceptions
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        try {
                            otpVerifyMsgMutableLiveData.value =
                                Event(context.getString(R.string.waiting_for_otp))
                        } catch (e: Exception) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_HANDSHAKE,
                                CLConstant.PAYU_EVENT_FAILURE,
                                type = InternalConfig.ctFlowType,
                                message = e.message
                            )
                        }
                    }
                }

                override fun onTimeElapsed() {
                    // Fixed: Add error handling to prevent uncaught exceptions
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        try {
                            otpTimeoutMutableLiveData.value = Event(true)
                        } catch (e: Exception) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_HANDSHAKE,
                                CLConstant.PAYU_EVENT_FAILURE,
                                type = InternalConfig.ctFlowType,
                                message = e.message
                            )                        }
                    }
                }

                override fun onOTPReceived() {
                    handShakeTimer.start()
                    // Fixed: Add error handling to prevent uncaught exceptions
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        try {
                            otpVerifyMsgMutableLiveData.value =
                                Event(context.getString(R.string.verifying_otp))
                        } catch (e: Exception) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_HANDSHAKE,
                                CLConstant.PAYU_EVENT_FAILURE,
                                type = InternalConfig.ctFlowType,
                                message = e.message
                            )
                        }
                    }
                }
            },
            callback = object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    cancelTimer()
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_HANDSHAKE,
                        CLConstant.PAYU_EVENT_SUCCESS,
                        startTime, InternalConfig.ctFlowType
                    )
                    if (deviceBindingExists) {
                        navigateAfterHandshake()
                    } else {
                        showMobileVerifiedScreen(InternalConfig.ctFlowType, action)
                    }
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_HANDSHAKE,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime, InternalConfig.ctFlowType,
                        message = response.message,
                        code = response.code.toString()
                    )

                    cancelTimer()
                    if (response.code == PayUResponseCodes.PAYU_FAILED_STATUS
                        || response.code == PayUResponseCodes.PERMISSION_MISSING_ERROR_CODE
                        || response.code == PayUResponseCodes.PAYU_DEVICE_NOT_SUPPORTED_CODE
                        || response.code == PayUResponseCodes.PAYU_MOBILE_NUMBER_MISMATCHED
                    ) {
                        handleErrorResponse(response)
                    } else {
                        val title = context.getString(
                            if (deviceBindingExists)
                                R.string.payu_some_error_occurred
                            else {
                                R.string.payu_verification_failed
                            }
                        )
                        val message = context.getString(
                            if (deviceBindingExists)
                                R.string.payu_fetching_details_failed_msg
                            else
                                R.string.payu_verification_failed_msg
                        )
                        val model = GenericInfoModel(
                            title, response.message ?: message,
                            context.getString(R.string.payu_try_again),
                            true,
                            UpiPluginAction.MOBILE_VERIFICATION, simInfo
                        )
                        showGenericInfoScreen(model)
                    }
                }
            }
        )
        handShakeTimer.start()
    }

    protected open fun handleErrorResponse(error: PayUUPIBoltResponse, data: Any? = null) {
        when (error.responseType) {
            PayUResponseTypes.REQUEST_SIM_INFO, PayUResponseTypes.REQUEST_SDK_HANDSHAKE -> {
                error.responseType = getResponseType()
                sendMerchantCallback(error, false)
            }

            PayUResponseTypes.PAYU_SHOW_SETTING -> {
                showSettingErrorMutableLiveData.value = Event(Any())
            }

            PayUResponseTypes.DEFAULT_FAILURE -> {
                hideLoaderMutableLiveData.value = true
                showApiFailureBottomSheet(action ?: UpiPluginAction.GENERIC_INFO)
            }
        }
    }

    protected fun handleDeviceBindingFailed(error: PayUUPIBoltResponse): Boolean {
        val context = getApplication<Application>()
        val response = PayUUPIBoltResponse(
            PayUResponseTypes.REQUEST_TRANSACTION,
            error.code, error.message
        )
        if (error.code == PayUResponseCodes.PAYU_SIM_INFO_NOT_AVAILABLE) {
            val model = GenericInfoModel(
                context.getString(R.string.payu_sim_info_not_found_title),
                context.getString(R.string.payu_sim_info_not_found_error),
                context.getString(R.string.payu_okay),
                true,
                UpiPluginAction.DEVICE_BINDING_FAILED,
                isCancelable = false,
                retryData = response
            )
            hideLoaderMutableLiveData.value = true
            showGenericInfoScreen(model)
            return true
        } else if (error.code == PayUResponseCodes.PAYU_DEVICE_BINDING_FAILED) {
            if (getRegisteredMobileNumber() != null) {
                val model = GenericInfoModel(
                    context.getString(R.string.verify_device_error),
                    context.getString(
                        R.string.payu_device_binding_consent_message,
                        PayUUtils.getDisplayMobileNumber(getRegisteredMobileNumber() ?: "")
                    ),
                    context.getString(R.string.payu_okay),
                    true,
                    UpiPluginAction.DEVICE_BINDING_PROCEED,
                    retryData = error.result as? PayUSimInfo,
                    isCancelable = false,
                    negativeBtnText = context.getString(R.string.payu_cancel),
                    negativeBtnAction = UpiPluginAction.DEVICE_BINDING_FAILED
                )
                hideLoaderMutableLiveData.value = true
                showGenericInfoScreen(model)
                return true
            } else {
                val model = GenericInfoModel(
                    context.getString(R.string.verify_device_error),
                    context.getString(
                        R.string.payu_sms_permission_consent_message,
                        InternalConfig.appName
                    ),
                    context.getString(R.string.payu_okay),
                    true,
                    UpiPluginAction.DEVICE_BINDING_FAILED,
                    isCancelable = false,
                    retryData = response
                )
                hideLoaderMutableLiveData.value = true
                showGenericInfoScreen(model)
                return true
            }

        }
        return false
    }

    internal open fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean = false,
        popBackStackUntil: String? = null
    ) {
        hideBottomSheet.value = popBackStackUntil
        flowCompleteMutableLiveData.value = true
        PayUUtils.sendMerchantCallback(
            getApplication(), response, isSuccess, isUserCancelled, InternalConfig.ctFlowType
        )
    }

    protected open fun navigateAfterHandshake() {}

    fun getResponseType(): Int {
        return if (action == UpiPluginAction.LINKED_ACCOUNT) {
            PayUResponseTypes.REQUEST_TRANSACTION
        } else {
            PayUResponseTypes.REQUEST_MANAGE
        }
    }

    fun showCancelConfirmationScreen(
        ctFlowType: String,
        fixedRoundedCornerBottomSheet: FixedRoundedCornerBottomSheet? = null
    ) {
        showBottomSheet.value = Event(
            PayUUtils.getCancelConfirmationBSInfo(
                getApplication(), ctFlowType, fixedRoundedCornerBottomSheet
            )
        )
    }

    internal open fun callCancelTransactionApi() {
        val startTime = System.currentTimeMillis()
        val flowType = InternalConfig.ctFlowType
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_CANCEL_TXN_STATUS,
            CLConstant.PAYU_CT_INITIATED, type = flowType
        )
        logUserRegisteredEvent(CLConstant.PAYU_CT_STATUS_NOT_REGISTERED)
        action = UpiPluginAction.CANCEL_CONFIRMATION
        PayUUPIBoltUI.getCoreInstance()?.cancelTransaction(object : PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CANCEL_TXN_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS, startTime, flowType
                )
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CANCEL_TXN_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS, startTime, flowType,
                    message = response.message, code = response.code.toString()
                )
            }
        })
    }

    protected fun cancelTxnAfterDelay(response: PayUUPIBoltResponse, ctFlowType: String) {
        showVerifyPaymentScreen(ctFlowType, true)
        // Fixed: Use coroutine instead of Handler.postDelayed to prevent memory leaks
        // and ensure proper cancellation when ViewModel is cleared
        coroutineScope.launch(Dispatchers.Main) {
            try {
                delay(2000)
                response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                response.result = true
                callCancelTransactionApi()
                sendMerchantCallback(
                    response,
                    false,
                    isUserCancelled = true,
                    popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CANCEL_TXN_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS, 0, ctFlowType,
                    message = e.message, code = response.code.toString()
                )
            } catch (e: Exception) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CANCEL_TXN_STATUS,
                    CLConstant.PAYU_EVENT_FAILURE, 0, ctFlowType,
                    message = e.message, code = response.code.toString()
                )
            }
        }
    }

    internal fun logKibanaData(kibanaDataInfo: KibanaDataInfo) {
        logKibanaMutableLiveData.value = Event(kibanaDataInfo)
    }

    protected fun showApiFailureBottomSheet(
        action: UpiPluginAction = UpiPluginAction.GENERIC_INFO,
        data: Any? = null,
        isNewInstance: Boolean = false
    ) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.api_failure_error), "",
            context.getString(R.string.payu_try_again),
            true,
            action,
            isCancelable = false,
            retryData = data
        )
        showGenericInfoScreen(model, isNewInstance = isNewInstance)
    }

    fun getCTFlowType(): String {
        return if (action == UpiPluginAction.LINKED_ACCOUNT) {
            if(PayUUPIBoltUI.getCoreInstance()?.getRegisteredMobile().isNullOrEmpty()) {
                CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            } else {
                CLConstant.PAYU_EVENT_TYPE_REPEAT
            }
        } else {
            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        }
    }

    fun getRegisteredMobileNumber(): String? {
        return PayUUPIBoltUI.getCoreInstance()?.getRegisteredMobile()
    }

    fun showNetworkErrorBtSheet() {
        val context = getApplication<Application>()
        val title = context.getString(
            R.string.payu_network_error
        )
        val message = context.getString(
            R.string.payu_network_error_text
        )
        val model = GenericInfoModel(
            title, message,
            context.getString(R.string.payu_okay),
            true,
            UpiPluginAction.NETWORK_ERROR
        )
        showGenericInfoScreen(
            model,
            UpiPluginAction.NETWORK_ERROR,
            isNewInstance = true
        )
    }

    protected fun logCTApiStatusEvent(
        eventName: String,
        status: String,
        startTime: Long = 0,
        type: String,
        count: Int = 0,
        message: String? = null,
        code: String? = null,
        additionalInfo: HashMap<String, String>? = null
    ) {
        val map = HashMap<String, Any>().apply {
            if (count > 0) {
                this[CLConstant.PAYU_CT_COUNT] = count
            }
            message?.let {
                this[CLConstant.PAYU_CT_MESSAGE] = message
            }
            additionalInfo?.let { putAll(it) }
        }
        AnalyticsUtils.setCTLogsForUPIWithData(
            getApplication(), eventName, map, type = type, startTime = startTime, status = status
        )
        PayUUtils.logKibanaEvents(
            getApplication(),
            eventKey = eventName,
            eventData = JSONObject().apply {
                if (count > 0) {
                    put(CLConstant.PAYU_CT_COUNT, count)
                }
                message?.let {
                    put(CLConstant.PAYU_CT_MESSAGE, message)
                }
                put(CLConstant.PAYU_EVENT_TYPE, type)
                additionalInfo?.let {
                    it.entries.forEach { entry ->
                        put(entry.key, entry.value)
                    }
                }
            }.toString(),
            eventType = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventType.Error else AnalyticsUtils.EventType.Info,
            eventSeverity = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventSeverity.High else AnalyticsUtils.EventSeverity.Low,
            status = status,
            code = code,
            time = if (status == CLConstant.PAYU_CT_INITIATED) null else System.currentTimeMillis() - startTime
        )
    }

    protected fun getValidErrorMessage(error: String?, fallbackError: String): String {
        return if (error.isNullOrEmpty() || error.length <= 4) {
            fallbackError
        } else {
            error
        }
    }

    fun logVpaStatus(account: PayUCustomerBankAccounts) {
        val context = getApplication<Application>()
        val vpaStatus = if (account.bankAccounts.vpa.isNullOrEmpty())
            CLConstant.PAYU_CT_VPA_NOT_SET
        else
            CLConstant.PAYU_CT_VPA_ALREADY_SET
        PayUUtils.logKibanaEvents(
            context,
            CLConstant.PAYU_CT_UPI_ID_STATUS,
            JSONObject().apply {
                put(CLConstant.PAYU_CT_ACCOUNT, account.bankAccounts.accountNo)
                put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
            }.toString(),
            status = vpaStatus
        )
    }

    fun logMpinStatus(account: PayUCustomerBankAccounts) {
        val context = getApplication<Application>()
        val mpinStatus = if (account.bankAccounts.mbeba.equals(PayUUPIBoltUiConstant.MBEBA_Y))
            CLConstant.PAYU_CT_MPIN_ALREADY_SET
        else
            CLConstant.PAYU_CT_MPIN_NOT_SET
        PayUUtils.logKibanaEvents(
            context,
            CLConstant.PAYU_CT_MPIN_STATUS,
            JSONObject().apply {
                put(CLConstant.PAYU_CT_ACCOUNT, account.bankAccounts.accountNo)
                put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
            }.toString(),
            status = mpinStatus
        )
    }

    fun logUserRegisteredEvent(
        status: String,
        additionalInfo: HashMap<String, String>? = null
    ) {
        if (InternalConfig.ctFlowType == CLConstant.PAYU_EVENT_TYPE_REGISTRATION
            && InternalConfig.isUserRegisteredEventLogged.not() && InternalConfig.isUserRegistrationStarted
        ) {
            InternalConfig.isUserRegisteredEventLogged = true
            logCTApiStatusEvent(
                CLConstant.PAYU_CT_HANDSHAKE, status,
                type = InternalConfig.ctFlowType,
                additionalInfo = additionalInfo
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Fixed: Properly cancel coroutines to prevent memory leaks and resource exhaustion
        coroutineScope.cancel()
        cancelTimer()
    }
}