package com.payu.upiboltui.constants

object PayUUPIBoltUiConstant {

    const val BANK_SELECTION_SCREEN = "BANK_SELECTION_SCREEN"

    const val BANK_DATA = "BankData"
    const val DATA = "DATA"

    const val MBEBA_Y = "Y"

    const val PAYU_DD_MM_YYYY = "dd/MM/yyyy"
    const val PAYU_DD_MMMM = "dd MMMM yyyy"
    const val PAYU_TIME = "dd/MM/yyyy hh:mm:ss a"
    const val PAYU_TIME_QUERY = "dd/MM/yyyy hh:mm:ss"
    const val PAYU_DATE_TIME_TXN_HISTORY = "dd/MM/yyyy | hh:mm a"
    const val PAYU_TIME_QUERY_LIST = "dd/MM/yyyy | hh:mm"
    const val PAYU_TIME_TXN_DETAILS = "dd/MM/yyyy  hh:mm a"
    const val PAYU_TIME_TXN_HISTORY = "hh:mm a"

    const val PAYU_CARD_HINT = "XX XXXX"
    const val PAYU_EXPIRY_HINT = "MM/YY"

    const val PAYU_A_C = "a/c"
    const val PAYU_N = "N"

    const val ROOT_FRAGMENT = "RootFragment"

    const val PAYU_MOBILE_VERIFICATION_CLOSE_BUTTON_TIMEOUT: Long = 1000 * 10
}