package com.payu.upiboltui.view.bottomSheetFragments.base

import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.constants.payUEventScreenMap
import com.payu.upiboltui.listeners.BottomSheetListener
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.AnimatorUtil
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PayUUtils.logKibanaEvents
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.CommonViewModel
import org.json.JSONObject

data class UpiFixedBottomSheetData(
    var pluginAction: UpiPluginAction? = null,
    var upiBoltListener: PayUUPIBoltOnClickListener? = null,
    val data: Any? = null,
    val onClose: (() -> Unit)? = null,
    val showExitConfirmation: Boolean = false,
    val layoutId: Int? = null,
    val tag: String? = null,
    val isNewInstance: Boolean = false,
    var ctFlowType: String? = null
)

open class BaseBottomSheetFragment : FixedRoundedCornerBottomSheet(), BottomSheetListener {
    var upiFixedBottomSheetData: UpiFixedBottomSheetData? = null
    private var timer: CountDownTimer? = null
    private var commonViewModel: CommonViewModel? = null

    fun getCommonViewModel() = commonViewModel

    override fun onAttach(context: Context) {
        super.onAttach(context)
        bottomSheetListener = this
        initViewModel()
    }

    private fun initViewModel() {
        commonViewModel = ViewModelProvider(
            requireActivity(),
            BaseViewModelFactory(
                requireActivity().application
            )
        )[CommonViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return upiFixedBottomSheetData?.layoutId?.let {
            inflater.inflate(it, container, false)
        }
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        view.findViewById<ViewGroup>(R.id.btTpView)?.let {
            AnimatorUtil.fadeInAnimationOnView(it)
        }
    }

    override fun handleBottomSheetClose() {
        upiFixedBottomSheetData?.onClose?.invoke()
        if (PayUAndroidUtils.isLastFragmentShowing(activity?.supportFragmentManager)
                .not()
            && upiFixedBottomSheetData?.pluginAction != UpiPluginAction.CANCEL_CONFIRMATION
        ) {
            val responseType =
                if (upiFixedBottomSheetData?.pluginAction == UpiPluginAction.MANAGEMENT_OPTIONS) {
                    PayUResponseTypes.REQUEST_MANAGE
                } else {
                    PayUResponseTypes.REQUEST_TRANSACTION
                }
            upiFixedBottomSheetData?.ctFlowType?.let { flowType ->
                payUEventScreenMap[upiFixedBottomSheetData?.pluginAction]?.let { screenName ->
                    val map = HashMap<String, Any>().apply {
                        this[CLConstant.PAYU_CT_SCREEN] = screenName
                    }
                    logCTAEvent(
                        CLConstant.PAYU_CT_CLOSED, screenName, map, flowType
                    )
                }
            }
            val response = PayUUPIBoltResponse(
                responseType,
                PayUResponseCodes.PAYU_USER_CANCELLED_CODE,
                PayUResponseMessages.PAYU_USER_CANCELLED_MESSAGE
            )
            PayUUtils.sendMerchantCallback(
                requireContext(),
                response,
                isSuccess = false,
                isUserCancelled = true,
                flowType = upiFixedBottomSheetData?.ctFlowType ?: ""
            )
        }
    }

    override fun handleBottomSheetBackPress() {
        upiFixedBottomSheetData?.ctFlowType?.let { flowType ->
            payUEventScreenMap[upiFixedBottomSheetData?.pluginAction]?.let { screenName ->
                logCTAEvent(
                    CLConstant.PAYU_CT_BACK,
                    screenName,
                    type = flowType
                )
            }
        }
        if (PayUAndroidUtils.isLastFragmentShowing(activity?.supportFragmentManager)
                .not()
            || upiFixedBottomSheetData?.showExitConfirmation == true
        ) {
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.CANCEL_CONFIRMATION,
                this
            )
        } else {
            dialog?.cancel()
        }
    }

    override fun handleBottomSheetUpdate() {
        commonViewModel?.cancelTimer()
    }

    protected fun setBottomSheetCancelable(header: BottomSheetHeader) {
        // enabling close button and back press after timeout
        header.setCloseButtonVisibility(false)
        timer = PayUAndroidUtils.getCountDownTimer(
            PayUUPIBoltUiConstant.PAYU_MOBILE_VERIFICATION_CLOSE_BUTTON_TIMEOUT,
            onTimerFinish = {
                header.setCloseButtonVisibility(true)
            })
        timer?.start()
    }

    fun cancelTimer() {
        timer?.cancel()
    }

    protected fun logCTAEvent(
        name: String,
        screenName: String,
        map: HashMap<String, Any> = HashMap(),
        type: String
    ) {
        logKibanaEvents(
            requireContext(), CLConstant.PAYU_CT_CTA_CLICKED,
            JSONObject().apply {
                map.forEach { entry ->
                    put(entry.key, entry.value)
                }
                put(CLConstant.PAYU_EVENT_TYPE, type)
                put(CLConstant.PAYU_CT_NAME, name)
            }.toString(),
            screenName = screenName,
            name = name
        )
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(), name, type, map, screenName = screenName
        )
    }
}