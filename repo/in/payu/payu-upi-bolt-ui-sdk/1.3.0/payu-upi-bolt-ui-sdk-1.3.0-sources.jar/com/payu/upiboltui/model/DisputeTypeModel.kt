package com.payu.upiboltui.model

import com.payu.commonmodelssdk.model.response.PayUDisputeType
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory

data class DisputeTypeModel(
    val txnHistory: PayUTransactionHistory,
    val disputeTypeList: List<PayUDisputeType>
)
