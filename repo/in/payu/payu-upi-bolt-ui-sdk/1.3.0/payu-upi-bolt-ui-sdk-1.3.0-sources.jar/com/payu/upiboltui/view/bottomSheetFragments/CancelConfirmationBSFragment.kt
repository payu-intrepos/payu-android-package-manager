package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import org.json.JSONObject


class CancelConfirmationBSFragment : BaseBottomSheetFragment() {
    private var model: GenericInfoModel? = null

    private fun initViews(view: View){
        val btnAction: TextView = view.findViewById(R.id.btnOk)
        val btnCancel: TextView = view.findViewById(R.id.btnCancel)
        val messageTv = view.findViewById<TextView>(R.id.textView2)

        val header = BottomSheetHeader(
            view,
            header = model?.title,
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener,
            isErrorImgVisible = model?.isErrorImgVisible == true,
            showBhimGradientOnHeader = false
        )
        header.setCloseButtonVisibility(model?.isCancelable == true)

        btnAction.text = model?.buttonText
        btnCancel.text = model?.negativeBtnText
        messageTv.text = model?.message
        btnAction.setAvoidMultiClickListener {
            upiFixedBottomSheetData?.ctFlowType?.let { flowType ->
                logCTClickEvent(flowType, CLConstant.PAYU_CT_YES, model?.parentBs is VerifyPaymentBSFragment)
            }
            dialog?.cancel()
            BottomSheetStackManager.closeAllBottomSheets()
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.CANCEL_CONFIRMATION_DONE)
        }
        btnCancel.setAvoidMultiClickListener {
            upiFixedBottomSheetData?.ctFlowType?.let { flowType ->
                logCTClickEvent(flowType, CLConstant.PAYU_CT_NO, model?.parentBs is VerifyPaymentBSFragment)
            }
            dialog?.cancel()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun logCTClickEvent(flowType: String, name: String, isTxnInitiated: Boolean) {
        val txnInitiated = if (isTxnInitiated)
            CLConstant.PAYU_CT_YES
        else
            CLConstant.PAYU_CT_NO
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_CT_SCREEN] = CLConstant.PAYU_CT_SCREEN_CANCEL_CONFIRMATION
            this[CLConstant.PAYU_CT_TXN_INITIATED] = txnInitiated
        }
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(), name, flowType, map
        )
        PayUUtils.logKibanaEvents(
            requireContext(),
            CLConstant.PAYU_CT_CTA_CLICKED,
            JSONObject().apply {
                put(CLConstant.PAYU_EVENT_TYPE, flowType)
                put(CLConstant.PAYU_CT_NAME, name)
                put(CLConstant.PAYU_CT_SCREEN, CLConstant.PAYU_CT_SCREEN_CANCEL_CONFIRMATION)
                put(CLConstant.PAYU_CT_TXN_INITIATED, txnInitiated)
            }.toString(),
            screenName = CLConstant.PAYU_CT_SCREEN_CANCEL_CONFIRMATION,
            name = name
        )
    }

    companion object {

        @JvmStatic
        fun newInstance(
            data: GenericInfoModel,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            CancelConfirmationBSFragment().apply {
                this.model = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}