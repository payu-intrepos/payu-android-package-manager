package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.model.response.PayUDisputeType
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.setAvoidMultiClickListener

class DisputeTypeListAdapter(
    private val items: List<PayUDisputeType>,
    private val onItemSelected: (item: PayUDisputeType) -> Unit
) : RecyclerView.Adapter<DisputeTypeListAdapter.DisputeTypeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DisputeTypeViewHolder {
        return DisputeTypeViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.layout_dispute_type_item, parent, false)
        )
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: DisputeTypeViewHolder, position: Int) {
        holder.title.text = items[position].disputeTypeDesc
        holder.divider.isVisible = position != items.size - 1
    }

    inner class DisputeTypeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val parentLayout: ConstraintLayout = itemView.findViewById(R.id.root_dispute_type)
        val title: TextView = itemView.findViewById(R.id.tv_dispute_type)
        val divider: View = itemView.findViewById(R.id.divider)

        init {
            parentLayout.setAvoidMultiClickListener {
                onItemSelected.invoke(items[adapterPosition])
            }
        }
    }
}