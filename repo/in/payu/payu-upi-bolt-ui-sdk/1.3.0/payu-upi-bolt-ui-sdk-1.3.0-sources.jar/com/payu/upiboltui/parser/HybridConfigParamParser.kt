

package com.payu.upiboltui.parser

import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams
import com.payu.upibolt.parser.HybridConfigKeys
import com.payu.upibolt.parser.HybridParamParser.getPaymentParams
import com.payu.upibolt.parser.HybridParamParser.returnNullErrorOrValue
import com.payu.upiboltui.model.PayUUPIBoltUIConfig

object HybridConfigParamParser {

    fun parseMapToPayUUPIBoltPaymentParams(map: Map<String, Any>): Pair<String?, PayUUPIBoltPaymentParams?> {
        return Pair(null, getPaymentParams(map, null))
    }

    fun parseMapToConfig(map: Map<String, Any>): Pair<String?, PayUUPIBoltUIConfig?> {
        val list = ArrayList<PluginType>()
        val pluginTypesValues : ArrayList<String>? = map[HybridConfigKeys.PLUGIN_TYPES] as? ArrayList<String>
        pluginTypesValues?.forEach {
            list.add(PluginType.valueOf(it))
        }
        return try {
            Pair(
                null,
                    PayUUPIBoltUIConfig(
                        merchantName = returnNullErrorOrValue(
                            HybridConfigKeys.MERCHANT_NAME,
                            map[HybridConfigKeys.MERCHANT_NAME] as? String
                        ),
                        merchantKey = returnNullErrorOrValue(
                            HybridConfigKeys.MERCHANT_KEY,
                            map[HybridConfigKeys.MERCHANT_KEY] as? String
                        ),
                        phone = returnNullErrorOrValue(
                            HybridConfigKeys.PHONE,
                            map[HybridConfigKeys.PHONE] as? String
                        ),
                        email = returnNullErrorOrValue(
                            HybridConfigKeys.EMAIL,
                            map[HybridConfigKeys.EMAIL] as? String
                        ),
                        requestId = returnNullErrorOrValue(
                            HybridConfigKeys.REQUEST_ID,
                            map[HybridConfigKeys.REQUEST_ID] as? String
                        ),
                        pluginTypes = list,
                        isProduction = map[HybridConfigKeys.IS_PRODUCTION] as? Boolean ?: true,
                        isProtectedScreen = map[HybridConfigKeys.IS_PROTECTED_SCREEN] as? Boolean ?: true,
                        excludedBanksIINs = map[HybridConfigKeys.EXCLUDED_BANKS_IINS] as? List<String>,
                        issuingBanks = map[HybridConfigKeys.ISSUING_BANKS] as? List<String>
                    )
            )
        } catch (e: Exception) {
            Pair(e.message, null)
        }

    }
}
