package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.upiboltui.R
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.WelcomeScreenModel
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsSubmitButtonHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class WelcomeScreenBSFragment : BaseBottomSheetFragment() {
    private var data: WelcomeScreenModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.get("") as? WelcomeScreenModel?
        }
    }

    private fun initViews(view: View) {
        val context = view.context
        BottomSheetFooter(view)
        val ivBoltLogo: AppCompatImageView = view.findViewById(R.id.upi_bolt_icon)
        val tvMsg1: TextView = view.findViewById(R.id.tvUpiWelcomeHeader1)
        val tvMsg2: TextView = view.findViewById(R.id.tvUpiWelcomeHeader2)

        BottomSheetHeader(
            view, header = context.getString(R.string.setup_upi_bolt),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val model = data as WelcomeScreenModel
        ivBoltLogo.setImageResource(
            if (PayUUtils.isOnlyBhimPgSelected())
                R.drawable.bhim_vega_logo
            else
                R.drawable.payu_upi_bolt_icon
        )
        tvMsg1.text = context.getString(R.string.payu_faster_payments_text)

        val message = String.format(
            "%s%s",
            context.getString(R.string.payu_sms_send_text),
            if (model.hasPermissions.not())
                " ${context.getString(R.string.payu_sms_permission_text, InternalConfig.appName)}"
            else ""
        )
        tvMsg2.text = message

        val bsSubmitButtonHandler = BsSubmitButtonHandler()
        bsSubmitButtonHandler.init(
            view,
            payButtonText = context.getString(R.string.payu_setup_upi),
            upiBoltListener = upiFixedBottomSheetData?.upiBoltListener,
            screenType = model.nextAction,
            result = model.nextActionData,
            onButtonClickListenerForLogs = {
                logCTAEvent(
                    CLConstant.PAYU_CT_DEVICE_BINDING_CONTINUE,
                    CLConstant.PAYU_CT_SCREEN_WELCOME,
                    type = CLConstant.PAYU_EVENT_TYPE_REGISTRATION
                )
            }
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {

        @JvmStatic
        fun newInstance(
            data: WelcomeScreenModel,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            WelcomeScreenBSFragment().apply {
                this.data = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}