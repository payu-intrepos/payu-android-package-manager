package com.payu.upiboltui

import android.content.Context
import android.widget.Toast
import androidx.annotation.Keep
import androidx.fragment.app.FragmentActivity
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.KibanaConstants
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.listeners.ApiFailedCallback
import com.payu.commonmodelssdk.listeners.ApiRetryCallback
import com.payu.commonmodelssdk.listeners.PayUHashGenerationListener
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.PayUUPIBolt
import com.payu.upibolt.listeners.PluginInterface
import com.payu.upibolt.models.PayUUPIBoltConfig
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.listeners.PayUUPIBoltUICallback
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.ManagementScreenType
import com.payu.upiboltui.model.PayUUPIBoltUIConfig
import com.payu.upiboltui.parser.HybridConfigParamParser
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PayUValidateUtils
import org.json.JSONObject


@Keep
class PayUUPIBoltUI private constructor() {

    private lateinit var bolt: PayUUPIBolt
    var core: PluginInterface? = null
        private set
        get() {
            return bolt.core
        }

    private lateinit var upiBoltUiHandler: UPIBoltUiHandler
    private var activity: FragmentActivity? = null // TODO should be removed in future release

    @Keep
    companion object {

        @Volatile
        private var boltUI: PayUUPIBoltUI? = null

        /**
         * function to return ui sdk object to call its all function
         * */
        @Keep
        @JvmStatic
        fun getInstance(
            activity: FragmentActivity,
            config: PayUUPIBoltUIConfig,
            hashGenerationListener: PayUHashGenerationListener
        ): PayUUPIBoltUI {
            return synchronized(this) {
                payUUPIBoltUI(config, activity, hashGenerationListener)
            }
        }


        @Keep
        @JvmStatic
        fun getInstance(
            activity: FragmentActivity,
            configMap: Map<String, Any>,
            hashGenerationListener: PayUHashGenerationListener
        ): PayUUPIBoltUI? { synchronized(this) {
            boltUI ?: kotlin.run {
                val configPair = HybridConfigParamParser.parseMapToConfig(configMap)
                val configValue = configPair.second
                if (configValue != null) {
                    return payUUPIBoltUI(configValue, activity, hashGenerationListener)
                }
            }
        }
            return boltUI
        }

        private fun payUUPIBoltUI(
            config: PayUUPIBoltUIConfig,
            activity: FragmentActivity,
            hashGenerationListener: PayUHashGenerationListener
        ): PayUUPIBoltUI {
            InternalConfig.config = config
            InternalConfig.refId = config.requestId
            InternalConfig.appName =
                activity.packageManager.getApplicationLabel(activity.applicationInfo)
                    .toString()
            boltUI = PayUUPIBoltUI()
            boltUI?.activity = activity
            boltUI?.upiBoltUiHandler = UPIBoltUiHandler(activity)
            boltUI?.bolt =
                PayUUPIBolt.getInstance(
                    activity,
                    PayUUPIBoltConfig(
                        config.merchantKey, config.email, config.isProduction,
                        config.pluginTypes, config.requestId, config.issuingBanks,
                        boltUI?.getApiFailureCallback(activity)
                    ),
                    hashGenerationListener
                )
            PayUUtils.logKibanaEvents(
                activity,
                CLConstant.PAYU_CT_SDK_STATE,
                PayUUtils.prepareInitParamsJson(config).toString(),
                eventType = AnalyticsUtils.EventType.Info,
                eventSeverity = AnalyticsUtils.EventSeverity.Low,
                status = CLConstant.PAYU_CT_INITIATED
            )
            AnalyticsUtils.setCTLogsForUPIWithData(
                activity,
                CLConstant.PAYU_CT_SDK_STATE,
                status = CLConstant.PAYU_CT_INITIATED
            )
            return boltUI!!
        }


        @JvmStatic
        fun reset(context: Context) {
            InternalConfig.clearAll()
            PayUUPIBolt.reset(context)
            boltUI = null
            PayUUtils.logKibanaEvents(
                context, CLConstant.PAYU_CT_SDK_STATE, "",
                eventType = AnalyticsUtils.EventType.Info,
                eventSeverity = AnalyticsUtils.EventSeverity.Low,
                status = CLConstant.PAYU_CT_RESET
            )
            AnalyticsUtils.setCTLogsForUPIWithData(
                context,
                CLConstant.PAYU_CT_SDK_STATE,
                status = CLConstant.PAYU_CT_RESET
            )
        }

        internal fun getCoreInstance(): PluginInterface? {
            return boltUI?.core
        }
    }

    /**
     * function to register user and pay
     * */
    fun registerAndPay(
        paymentParams: PayUUPIBoltPaymentParams,
        callback: PayUUPIBoltUICallback
    ) {

    callRegisterAndPay(paymentParams, callback)
    }

    fun registerAndPay(
        paymentParamsMap: Map<String, Any>,
        callback: PayUUPIBoltUICallback
    ) {
        val paymentParamsPair =
            HybridConfigParamParser.parseMapToPayUUPIBoltPaymentParams(paymentParamsMap)
        val paymentParams = paymentParamsPair.second
        if (paymentParams != null) {
            callRegisterAndPay(paymentParams, callback)

        } else {
            val error = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_TRANSACTION,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                paymentParamsPair.first
            )
            callback.onPayUFailure(error)
        }
    }

    private fun callRegisterAndPay(paymentParams: PayUUPIBoltPaymentParams, callback: PayUUPIBoltUICallback){
        /**
         * validate PayUUISdkInitParams
         * */
        val initParamResult = PayUValidateUtils.validateSDKInitParams(InternalConfig.config)
        /**
         * validate PayUPaymentParams
         * */
        val paymentParamResult = PayUValidateUtils.validatePayUPaymentParams(paymentParams)
        activity?.applicationContext?.let {
            PayUUtils.logKibanaEvents(
                it, KibanaConstants.PAYU_BOLT_REGISTER_METHOD,
                paymentParams.toJsonObject(isMask = true, shouldExclude = true).toString()
            )
        }
        if (initParamResult.first && paymentParamResult.first) {
            InternalConfig.paymentParams = paymentParams
            InternalConfig.callback = callback
            upiBoltUiHandler.launchRegisterAndPay()
        } else if (!initParamResult.first) {
            val error = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_TRANSACTION,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE + initParamResult.second
            )
            callback.onPayUFailure(error)
        } else {
            val error = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_TRANSACTION,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                paymentParamResult.second
            )
            callback.onPayUFailure(error)
        }
    }


    /**
     * function to open manage options like manage account, txnHistory, query list ..
     * */

    fun openUPIManagement(
        managementScreenType: ManagementScreenType = ManagementScreenType.ALL,
        callback: PayUUPIBoltUICallback
    ) {
        /**
         * validate PayUUISdkInitParams
         * */

        val initParamResult = PayUValidateUtils.validateSDKInitParams(InternalConfig.config)
        if (initParamResult.first) {
            InternalConfig.callback = callback
            upiBoltUiHandler.launchManagementOptions(managementScreenType)
        } else {
            val error = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_MANAGE,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE + initParamResult.second
            )
            callback.onPayUFailure(error)
        }
    }

    /**
     * function to check if merchant is onBoarded for sdk use
     * */
    fun isUpiBoltEnabled(callback: (PayUUPIBoltResponse) -> Unit) {
        /**
         * validate PayUUISdkInitParams
         * */
        val initParamResult = PayUValidateUtils.validateSDKInitParams(InternalConfig.config)
        if (initParamResult.first) {
            upiBoltUiHandler.isUPIBoltAvailable(callback = callback)
        } else {
            val error = PayUUPIBoltResponse(
                PayUResponseTypes.REQUEST_UPI_BOLT,
                PayUResponseCodes.PAYU_FAILED_STATUS,
                PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE + initParamResult.second
            )
            callback.invoke(error)
        }
    }

    fun isRegistered(pg: String, callback: (Boolean) -> Unit) {
        activity?.let {
            bolt.isRegistered(it, pg, callback)
        }
    }

    fun clearData(pg: String) {
        activity?.let {
            bolt.clearData(it, pg)
        }
        core?.clearData()
    }

    private fun getApiFailureCallback(context: Context) = object : ApiFailedCallback {
        override fun onApiFailed(
            response: PayUUPIBoltResponse, retryCallback: ApiRetryCallback, apiCount: Int
        ) {
            if (apiCount < 3) {
                if (response.code == PayUResponseCodes.PAYU_DEVICE_REGISTRATION_FAILED) {
                    retryCallback.retry(true)
                } else {
                    when (response.responseType) {
                        PayUResponseTypes.REQUEST_PAY -> {
                            Toast.makeText(
                                context, context.getString(R.string.payment_retry_msg), Toast.LENGTH_SHORT
                            ).show()
                            retryCallback.retry(true)
                        }
                    }
                }
            } else {
                retryCallback.retry(false)
            }
        }
    }
}