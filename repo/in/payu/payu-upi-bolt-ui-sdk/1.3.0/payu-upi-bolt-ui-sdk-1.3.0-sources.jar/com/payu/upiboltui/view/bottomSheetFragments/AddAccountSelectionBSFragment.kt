package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upiboltui.R
import com.payu.upiboltui.model.AddAccountSelectionModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.AddAccountSelectionAdapter
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class AddAccountSelectionBSFragment : BaseBottomSheetFragment(){

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initViews(view: View) {
        BottomSheetHeader(
            view,
            view.context.getString(R.string.payu_select_account),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_select_account)
        val continueBtn: ConstraintLayout = view.findViewById(R.id.btnAddAccount)
        val btn = continueBtn.findViewById<TextView>(R.id.payuButton)
        btn?.text = requireContext().getString(R.string.payu_continue)
        (upiFixedBottomSheetData?.data as? AddAccountSelectionModel)?.let {
            val accountsList = ArrayList<PayUCustomerBankAccounts>()
            it.accounts.forEach { account ->
                accountsList.add(account)
            }
            recyclerView.adapter = AddAccountSelectionAdapter(
                it.bank.logo ?: "",
                it.bank.bankName,
                accountsList
            )
        }
        continueBtn.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_SELECT_ACCOUNT_CONFIRM,
                CLConstant.PAYU_CT_SCREEN_ADD_MORE_ACCOUNTS,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.ADD_ACCOUNT_SELECTION,
                (recyclerView.adapter as? AddAccountSelectionAdapter)?.getSelectedItem()
            )
        }

    }

    companion object {

        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            AddAccountSelectionBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}