package com.payu.upiboltui.view.fragments

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.PorterDuff
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.UPIBoltUiHandler
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PayUUtils.logKibanaEvents
import com.payu.upiboltui.utils.ScreenSecurityManager
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.CommonViewModel
import org.json.JSONObject

internal open class BaseFragment : Fragment(), PayUUPIBoltOnClickListener {

    private lateinit var progressDialog: AlertDialog
    private var upiFixedBottomSheetData: UpiFixedBottomSheetData? = null

    private var commonViewModel: CommonViewModel? = null
    fun getCommonViewModel() = commonViewModel
    protected var ctScreenName: String? = null
    private var shouldProtect: Boolean = true



    override fun onAttach(context: Context) {
        shouldProtect =
            InternalConfig.config?.shouldProtectScreen(requireActivity().applicationContext) == true
        super.onAttach(context)
        initViewModel()
    }

    private fun initViewModel(){
        commonViewModel = ViewModelProvider(
            requireActivity(),
            BaseViewModelFactory(
                requireActivity().application
            )
        )[CommonViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (shouldProtect) {
            ScreenSecurityManager.enable(activity?.window)
        }
        (activity as? AppCompatActivity)?.supportActionBar?.hide()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rootLayout = view.findViewById<ConstraintLayout>(R.id.root_layout)
        val ivBackIcon = view.findViewById<ImageView>(R.id.ivBackIcon)
        val tvHeader = view.findViewById<TextView>(R.id.tvHeader)
        rootLayout?.background =
            AppCompatResources.getDrawable(
                view.context,
                if (PayUUtils.isOnlyBhimPgSelected())
                    R.drawable.payu_fs_bg_bhim_gradient
                else
                    R.drawable.payu_background_black_white
            )
        val tintColor = if (PayUUtils.isOnlyBhimPgSelected())
            R.color.payu_color_000000
        else
            R.color.payu_color_FFFFFF
        ivBackIcon?.setColorFilter(
            ContextCompat.getColor(view.context, tintColor),
            PorterDuff.Mode.MULTIPLY
        )
        tvHeader?.setTextColor(ContextCompat.getColor(view.context, tintColor))

        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    logCTAEvent(
                        CLConstant.PAYU_CT_BACK,
                        ctScreenName ?: "",
                        type = getCTFlowType()
                    )
                    closeCurrentFragment()
                }
            }
        )
        ctScreenName?.let { screenName ->
            val map = HashMap<String, Any>().apply {
                this[CLConstant.PAYU_CT_SCREEN] = screenName
            }
            AnalyticsUtils.setCTLogsForUPIWithData(
                requireContext(), CLConstant.PAYU_CT_SCREEN_OPENED, map, getCTFlowType()
            )
            logKibanaEvents(
                requireContext(),
                eventKey = CLConstant.PAYU_CT_SCREEN_OPENED,
                eventData = JSONObject().apply { put(CLConstant.PAYU_EVENT_TYPE, getCTFlowType()) }.toString(),
                screenName = screenName,
                eventType = AnalyticsUtils.EventType.Info
            )
        }
        initProgressDialog()
    }

    private fun initProgressDialog() {
        progressDialog = AlertDialog.Builder(context, R.style.PayU_ProgressDialogTheme)
            .setView(R.layout.layout_progress_dialog)
            .create()
        progressDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    protected fun showLoader() {
        progressDialog.show()
    }

    protected fun hideLoader() {
        progressDialog.cancel()
    }

    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        when (screenType) {
            UpiPluginAction.DEVICE_BINDING_FAILED -> {
                val response = PayUUPIBoltResponse(
                    PayUResponseTypes.REQUEST_TRANSACTION,
                    PayUResponseCodes.PAYU_DEVICE_BINDING_FAILED,
                    PayUResponseMessages.PAYU_DEVICE_BINDING_FAILED_MESSAGE
                )
                sendMerchantCallback(response, false)
            }

            UpiPluginAction.CANCEL_CONFIRMATION -> {
                closeCurrentFragment(result as FixedRoundedCornerBottomSheet)
            }

            UpiPluginAction.CANCEL_CONFIRMATION_DONE -> {
                callCancelTransactionApi()
                val responseType = if (this@BaseFragment is UpiSetupFragment) {
                    PayUResponseTypes.REQUEST_TRANSACTION
                } else {
                    PayUResponseTypes.REQUEST_MANAGE
                }
                ctScreenName?.let { screenName ->
                    val map = HashMap<String, Any>().apply {
                        this[CLConstant.PAYU_CT_SCREEN] = screenName
                    }
                    AnalyticsUtils.logClevertapCTAClickedEvent(
                        requireContext(), CLConstant.PAYU_CT_CLOSED, getCTFlowType(),
                        map, screenName
                    )
                    logKibanaEvents(
                        requireContext(),
                        CLConstant.PAYU_CT_CTA_CLICKED,
                        JSONObject().apply {
                            put(CLConstant.PAYU_CT_SCREEN, screenName)
                            put(CLConstant.PAYU_EVENT_TYPE, getCTFlowType())
                            put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_CLOSED)
                        }.toString(),
                        screenName = screenName,
                        name = CLConstant.PAYU_CT_CLOSED
                    )
                }
                sendMerchantCallback(
                    PayUUPIBoltResponse(
                        responseType,
                        PayUResponseCodes.PAYU_USER_CANCELLED_CODE,
                        PayUResponseMessages.PAYU_USER_CANCELLED_MESSAGE
                    ), isSuccess = false, isUserCancelled = true
                )
            }

            UpiPluginAction.GENERIC_INFO, UpiPluginAction.NETWORK_ERROR -> {
                hideBottomSheet()
            }

            else -> {}
        }
    }

    protected open fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean = false
    ) {}

    protected fun showManageOptions(){
        activity?.let { UPIBoltUiHandler(it).showManageOptionsUI() }
    }

    protected open fun closeCurrentFragment(bottomSheet: FixedRoundedCornerBottomSheet? = null) {}

    protected open fun callCancelTransactionApi() {}

    protected fun hideBottomSheet(popBackStackUntil: String? = null) {
        BottomSheetStackManager.popBackStack(popBackStackUntil, true)
    }

    protected fun showBottomSheet(info: PayUBottomSheetInfo) {
        upiFixedBottomSheetData =  UpiFixedBottomSheetData(
            info.pluginAction, this,
            data = info.data, onClose = info.onUserCancel,
            showExitConfirmation = info.showExitConfirmation,
            layoutId = info.layout, tag = info.tag, isNewInstance = info.isNewInstance,
            ctFlowType = info.ctFlowType
        )
        upiFixedBottomSheetData?.let { data ->
            val fragment = commonViewModel?.getFragment(upiFixedBottomSheetData = data)
            if (fragment != null) {
                activity?.let {
                    if (data.isNewInstance)
                        BottomSheetStackManager.addBottomSheet(
                            it,
                            fragment,
                            data.tag ?: ""
                        )
                    else
                        BottomSheetStackManager.replace(
                            it,
                            fragment,
                            data.tag ?: ""
                        )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (shouldProtect) {
            ScreenSecurityManager.disable(activity?.window)
        }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED)
        (activity as? AppCompatActivity)?.supportActionBar?.show()
    }

    private fun getCTFlowType(): String {
        return if (ctScreenName == CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNTS) {
            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        } else {
            InternalConfig.ctFlowType
        }
    }

    protected fun logCTAEvent(
        name: String,
        screenName: String,
        map: HashMap<String, Any> = HashMap(),
        type: String = getCTFlowType()
    ) {
        logKibanaEvents(
            requireContext(), CLConstant.PAYU_CT_CTA_CLICKED,
            JSONObject().apply {
                map.forEach { entry ->
                    put(entry.key, entry.value)
                }
                put(CLConstant.PAYU_EVENT_TYPE, type)
                put(CLConstant.PAYU_CT_NAME, name)
            }.toString(),
            screenName = screenName,
            name = name
        )
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(), name, type, map, screenName
        )
    }

}
