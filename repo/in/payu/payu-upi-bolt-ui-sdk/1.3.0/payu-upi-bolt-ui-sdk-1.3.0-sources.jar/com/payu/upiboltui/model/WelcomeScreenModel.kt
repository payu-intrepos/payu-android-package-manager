package com.payu.upiboltui.model

data class WelcomeScreenModel(
    val nextAction: UpiPluginAction,
    val hasPermissions: Boolean,
    val nextActionData: Any? = null
)
