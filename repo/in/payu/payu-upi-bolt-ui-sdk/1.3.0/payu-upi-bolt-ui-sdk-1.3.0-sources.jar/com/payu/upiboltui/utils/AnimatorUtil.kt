package com.payu.upiboltui.utils

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.appcompat.widget.AppCompatImageView
import androidx.vectordrawable.graphics.drawable.Animatable2Compat
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.payu.upiboltui.R


internal object AnimatorUtil {

    internal fun moveViewOnYaxisFromCurrent(dialog: BottomSheetDialog, currentHeight: Int) {
        val peekHeight = (Resources.getSystem().displayMetrics.heightPixels * 75) / 100
        ObjectAnimator.ofInt(
            dialog.behavior, "peekHeight",
            currentHeight, peekHeight
        )
            .apply {
                duration = 600
                start()
            }
    }

    internal fun moveViewOnYaxis(dialog: BottomSheetDialog) {
        val peekHeight = (Resources.getSystem().displayMetrics.heightPixels * 75) / 100
        ObjectAnimator.ofInt(
            dialog.behavior, "peekHeight",
            peekHeight
        )
            .apply {
                duration = 600
                start()
            }
    }

    internal fun fadeOutAnimationOnView(dialog: BottomSheetDialog){
       val objectAnimator = ObjectAnimator.ofFloat(
            dialog.window?.decorView,
            "alpha", 1f, 0f
        )
        objectAnimator.setDuration(200).interpolator = LinearInterpolator()
        objectAnimator.repeatMode = ValueAnimator.REVERSE
        objectAnimator.repeatCount = 1
        objectAnimator.start()
    }

    internal fun fadeInAnimationOnView(view: View){
        val objectAnimator = ObjectAnimator.ofFloat(
            view,
            "alpha", 0.7f, 1f
        )
        objectAnimator.setDuration(200).interpolator = LinearInterpolator()
        objectAnimator.start()
    }

    fun applyLoopingAnimatedVectorDrawable(ivProgress: AppCompatImageView, context: Context?) {
        val animated =
            context?.let { AnimatedVectorDrawableCompat.create(it, R.drawable.payu_loader) }
        ivProgress.setImageDrawable(animated)
        if (animated != null) {
            animated.registerAnimationCallback(object : Animatable2Compat.AnimationCallback() {
                override fun onAnimationEnd(drawable: Drawable) {
                    animated.start()
                }
            })
            animated.start()
        }
    }
}