package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsEditVpaHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import org.json.JSONObject


class UpdateVpaBSFragment : BaseBottomSheetFragment() {

    private var data: PayUAccountDetail?= null
    private var bsEditVpaHandler: BsEditVpaHandler? = null
    private var tvHeaderSubtext: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.getParcelable(DATA)
        }
    }
    private fun initViews(view: View){
        tvHeaderSubtext = view.findViewById(R.id.tvHeaderSubtext)
        val context = view.context
        BottomSheetFooter(view)
        BottomSheetHeader(
            view,
            context.getString(R.string.payu_set_upi_id_header),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        tvHeaderSubtext?.text = context.getString(R.string.payu_set_upi_id_sub_header)
        tvHeaderSubtext?.visibility = View.VISIBLE

        bsEditVpaHandler = BsEditVpaHandler()
        bsEditVpaHandler?.init(
            view,
            context.getString(R.string.payu_set_upi_id_header)
        ) { vpa ->
            data?.let {
                PayUUtils.logKibanaEvents(
                    requireContext(),
                    eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                    eventData = JSONObject().apply {
                        put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_SET_UPI_ID_CONFIRM)
                        put(CLConstant.PAYU_CT_VPA, vpa)
                        put(CLConstant.PAYU_EVENT_TYPE,
                            upiFixedBottomSheetData?.ctFlowType
                                ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
                        )
                    }.toString(),
                    screenName = CLConstant.PAYU_CT_SCREEN_SETUP_UPI_ID,
                    name = CLConstant.PAYU_CT_SET_UPI_ID_CONFIRM
                )
                val map = HashMap<String, Any>().apply {
                    this[CLConstant.PAYU_CT_VPA] = vpa
                }
                AnalyticsUtils.logClevertapCTAClickedEvent(
                    requireContext(),
                    CLConstant.PAYU_CT_SET_UPI_ID_CONFIRM,
                    upiFixedBottomSheetData?.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION,
                    map, screenName = CLConstant.PAYU_CT_SCREEN_SETUP_UPI_ID
                )
                it.vpa = vpa
                upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.UPDATE_VPA_CONFIRM, it)
            }
        }
        initObservers()
    }

    private fun initObservers() {
        getCommonViewModel()?.vpaLiveData?.observe(viewLifecycleOwner) { event ->
            event?.getContentIfNotHandled()?.let { response ->
                when(response){
                    is NetworkResponse.Failure -> {
                        val errorResponse = response.errorData as? PayUUPIBoltResponse?
                        bsEditVpaHandler?.setErrorVisible(errorResponse?.message ?: "")
                    }
                    is NetworkResponse.Success -> {
                        BottomSheetStackManager.popBackStack()
                    }
                    else -> {

                    }
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }


    companion object {

        @JvmStatic
        fun newInstance(data: PayUAccountDetail, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            UpdateVpaBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }

    }
}