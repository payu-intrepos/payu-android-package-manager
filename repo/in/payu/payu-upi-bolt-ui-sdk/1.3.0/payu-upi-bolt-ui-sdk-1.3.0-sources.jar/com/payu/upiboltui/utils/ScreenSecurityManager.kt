package com.payu.upiboltui.utils

import android.view.Window
import android.view.WindowManager
import java.util.WeakHashMap

internal object ScreenSecurityManager {
    private val protectedWindows = WeakHashMap<Window, Int>()

    @Synchronized
    fun enable(window: Window?) {
        if (window == null) return
        val currentCount = protectedWindows[window] ?: 0
        if (currentCount == 0) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        protectedWindows[window] = currentCount + 1
    }

    @Synchronized
    fun disable(window: Window?) {
        if (window == null) return
        val currentCount = protectedWindows[window] ?: return
        if (currentCount <= 1) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            protectedWindows.remove(window)
        } else {
            protectedWindows[window] = currentCount - 1
        }
    }
}
