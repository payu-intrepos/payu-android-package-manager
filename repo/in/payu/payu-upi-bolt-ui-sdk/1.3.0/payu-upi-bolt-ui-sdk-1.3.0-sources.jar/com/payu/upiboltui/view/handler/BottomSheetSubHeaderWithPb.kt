package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.payu.upiboltui.R

class BottomSheetSubHeaderWithPb {

    private var ivVerifiedImage: ImageView? = null
    private var tvUpiWelcomeSubHeader: TextView? = null
    private var cpbProgressBar: ProgressBar? = null

    fun init(view: View, subHeader: String, isLoaderShow: Boolean = false, drawable: Int? = null) {
        tvUpiWelcomeSubHeader = view.findViewById(R.id.tvUpiWelcomeSubHeader)
        cpbProgressBar = view.findViewById(R.id.accountProgressBar)
        ivVerifiedImage = view.findViewById(R.id.ivVerifiedImage)
        tvUpiWelcomeSubHeader?.text = subHeader
        if (isLoaderShow) {
            ivVerifiedImage?.visibility = View.GONE
        } else {
            ivVerifiedImage?.visibility = View.VISIBLE
            cpbProgressBar?.visibility = View.INVISIBLE
            if (drawable != null) {
                ivVerifiedImage?.setImageResource(drawable)
            }

        }
    }
}