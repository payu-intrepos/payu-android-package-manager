package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.upiboltui.R
import com.payu.upiboltui.model.DisputeTypeModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.view.adapters.DisputeTypeListAdapter
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class RaiseDisputeTypeListBSFragment : BaseBottomSheetFragment() {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initViews(view: View) {
        BottomSheetHeader(
            view,
            view.context.getString(R.string.payu_select_dispute_type),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_dispute_type)
        (upiFixedBottomSheetData?.data as? DisputeTypeModel)?.run {
            recyclerView.adapter = DisputeTypeListAdapter(disputeTypeList) { item ->
                logCTAEvent(
                    CLConstant.PAYU_CT_DISPUTE_TYPE_SELECTION,
                    CLConstant.PAYU_CT_SCREEN_RAISE_DISPUTE,
                    type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
                txnHistory.disputeRc = item.disputeTypeCode
                upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.RAISE_DISPUTE_TYPE_LIST, txnHistory)
            }
        }
    }

    companion object {

        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            RaiseDisputeTypeListBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}