package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class TransactionDetailsBSFragment : BaseBottomSheetFragment() {
    private var data: PayUTransactionHistory? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.getParcelable(DATA)
        }
    }
    private fun initViews(view: View){
        val context = view.context
        val txnHistory = data as PayUTransactionHistory
        val accountSetup = view.findViewById<ConstraintLayout>(R.id.account_details)
        accountSetup.background = null
        BottomSheetHeader(
            view,
            header = context.getString(R.string.transaction_details),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        val btHeader = view.findViewById<ConstraintLayout>(R.id.btHeader)
        btHeader.background =
            ContextCompat.getDrawable(context, R.drawable.payu_rounded_corner_flat_f9fafe)

        accountSetup.findViewById<TextView>(R.id.tvBankNumber).text =
            txnHistory.debitAccount?.let {
                "${txnHistory.debitBankName} ${it.formatAccountNumber()}"
            }

        view.findViewById<TextView>(R.id.tvVpa).text = txnHistory.debitVpa

        view.findViewById<TextView>(R.id.tvTransactionBalance).text =
            context.getString(
                R.string.payu_rupees_symbol,
                PayUUtils.formatAmount(txnHistory.amount)
            )

        view.findViewById<TextView>(R.id.tvTransactionDate).text =
            txnHistory.dateTime?.let {
                PayUUtils.getTxnHistoryDisplayDate(context, it)
            }
        val tvTransId = view.findViewById<TextView>(R.id.tvTransactionId)
        tvTransId.text = txnHistory.txnId

        val copyImage = view.findViewById<ImageView>(R.id.copy_img)
        copyImage.setAvoidMultiClickListener {
            PayUUtils.logKibanaEvents(requireContext(), eventKey = PayUUpiConstant.PAYU_BUTTON_CLICKED, eventData = "CopyImage",
                eventType = AnalyticsUtils.EventType.Info)
            PayUAndroidUtils.copyToClipboard(context, tvTransId.text.toString())
            Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT)
                .show()
        }

        val statusImg = when (txnHistory.status) {
            PayUUpiConstant.PAYU_TRAN_STATUS_COMPLETE, PayUUpiConstant.PAYU_TRAN_STATUS_SUCCESS -> R.drawable.payu_transaction_success
            PayUUpiConstant.PAYU_TRAN_STATUS_PENDING -> R.drawable.payu_mobile_error_icon
            else -> R.drawable.payu_transaction_failure
        }
        val ivStatus = accountSetup.findViewById<ImageView>(R.id.ivStatus)
        ivStatus.setImageResource(statusImg)

        PayUAndroidUtils.setSpannableText(
            context,
            context.getString(R.string.payu_raise_dispute_text),
            context.getString(R.string.raise_dispute),
            view.findViewById(R.id.tvRaiseDisputeInfo)
        ) {
            val map = HashMap<String, Any>().apply {
                txnHistory.txnId?.let { this[CLConstant.PAYU_CT_TXN_ID] = "**${it.substring(it.length - 6, it.length)}" }
            }
            logCTAEvent(
                CLConstant.PAYU_CT_RAISE_DISPUTE,
                CLConstant.PAYU_CT_SCREEN_TXN_DETAIL,
                map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.RAISE_DISPUTE, txnHistory
            )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {
        @JvmStatic
        fun newInstance(data: PayUTransactionHistory, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            TransactionDetailsBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}