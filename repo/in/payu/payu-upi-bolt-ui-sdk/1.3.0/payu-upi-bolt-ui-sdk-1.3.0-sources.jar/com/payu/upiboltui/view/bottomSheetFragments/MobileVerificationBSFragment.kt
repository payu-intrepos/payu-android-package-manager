package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsSubmitButtonHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class MobileVerificationBSFragment : BaseBottomSheetFragment() {

    private var buttonHandler: BsSubmitButtonHandler? = null
    private var subText: TextView? = null
    private var tvResendOtp: TextView? = null
    private var progressBar: ProgressBar? = null
    private var imgView: ImageView? = null

    private fun initViews(view: View){
        val context = view.context
        subText = view.findViewById<TextView>(R.id.tvUpiWelcomeSubHeader)
        tvResendOtp = view.findViewById<TextView>(R.id.tv_resend_otp)
        progressBar = view.findViewById<ProgressBar>(R.id.accountProgressBar)
        imgView = view.findViewById<ImageView>(R.id.ivVerifiedImage)
        BottomSheetFooter(view)
        setHeader(context, view)

        subText?.text = context.getString(R.string.payu_verification_in_progress)
        buttonHandler = BsSubmitButtonHandler()
        buttonHandler?.init(
            view,
            payButtonText = context.getString(R.string.payu_continue),
            isClickable = false,
            upiBoltListener = upiFixedBottomSheetData?.upiBoltListener,
            screenType = UpiPluginAction.MOBILE_VERIFIED
        )
        getCommonViewModel()?.setStartTime()
        showLoader()
        tvResendOtp?.isVisible = false
        tvResendOtp?.setAvoidMultiClickListener {
            disableResendOTP()
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.DEVICE_BINDING_PROCEED,
                upiFixedBottomSheetData?.data
            )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun setHeader(context: Context, view: View) {
        val header = BottomSheetHeader(
            view,
            context.getString(R.string.payu_verifying_your_mobile_number),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        setBottomSheetCancelable(header)
        initObserver()
    }

    private fun initObserver() {
        getCommonViewModel()?.cancelTimerLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let {
                cancelTimer()
            }
        }

        getCommonViewModel()?.updateOtpVerifyMsgLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let { message ->
               updateSubText(message)
            }
        }

        getCommonViewModel()?.otpTimeoutLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let { timeout ->
                enableResendOTP()
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            MobileVerificationBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }

    private fun updateSubText(message: String) {
        showLoader()
        imgView?.setImageResource(R.drawable.payu_checked)
        subText?.text = message
    }

    private fun disableResendOTP() {
        showLoader()
        tvResendOtp?.run {
            isEnabled = false
            isVisible = true
            setTextColor(resources.getColor(R.color.payu_color_A6A6A6))
        }
    }

    private fun enableResendOTP() {
        hideLoader()
        subText?.text = getString(R.string.fetching_otp_failed)
        imgView?.setImageResource(R.drawable.payu_transaction_failure)
        tvResendOtp?.run {
            isVisible = true
            isEnabled = true
            setTextColor(resources.getColor(R.color.payu_color_E02020))
        }
    }

    private fun showLoader() {
        progressBar?.isVisible = true
        imgView?.visibility = View.INVISIBLE
    }

    private fun hideLoader() {
        progressBar?.isVisible = false
        imgView?.visibility = View.VISIBLE
    }
}