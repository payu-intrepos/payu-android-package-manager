package com.payu.upiboltui.view.fragments

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.KibanaDataInfo
import com.payu.upiboltui.model.RaiseDisputeModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.TransactionHistoryItemAdapter
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.TransactionHistoryViewModel
import java.util.Calendar
import java.util.Date


internal class TransactionHistoryFragment : BaseFragment() {

    private lateinit var ivBackIcon: ImageView
    private lateinit var rvTransactions: RecyclerView
    private lateinit var cvNoTransactionFound: CardView
    private lateinit var tvFromDate: TextView
    private lateinit var tvToDate: TextView
    private lateinit var btnSearchTransactions: TextView
    private lateinit var errorTitle: TextView
    private lateinit var errorMessage: TextView

    private lateinit var transactionHistoryViewModel: TransactionHistoryViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        ctScreenName = CLConstant.PAYU_CT_SCREEN_TXN_HISTORY
        return inflater.inflate(R.layout.fragment_transaction_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViewModel()
        initUI(view)
        initObservers()
    }

    private fun initViewModel() {
        transactionHistoryViewModel = ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application
            )
        )[TransactionHistoryViewModel::class.java]
    }

    private fun initObservers() {
        transactionHistoryViewModel.transactionList.observe(viewLifecycleOwner) { response ->
            response?.let {
                when (it) {
                    is NetworkResponse.Loading -> {
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        hideLoader()
                        hideBottomSheet()
                        setData(it.data)
                    }

                    is NetworkResponse.Failure -> {
                        hideLoader()
                        showErrorScreen()
                    }

                    is NetworkResponse.FailureWithAlert -> {
                        Toast.makeText(context, it.message, Toast.LENGTH_SHORT).show()
                    }

                    else -> {}
                }
            }

            transactionHistoryViewModel.hideRaiseDisputeLoaderLiveData.observe(viewLifecycleOwner) {
                if (it) {
                    getCommonViewModel()?.hideRaiseDisputeLoader()
                }
            }
        }

        transactionHistoryViewModel.showBottomSheetLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { sheetInfo ->
                showBottomSheet(sheetInfo)
            }
        }

        transactionHistoryViewModel.flowCompleteLiveData.observe(viewLifecycleOwner) {
            PayUAndroidUtils.removeFragment(requireActivity(), this)
        }

        transactionHistoryViewModel.hideLoaderLiveData.observe(viewLifecycleOwner) { hide ->
            if (hide) {
                hideLoader()
            } else {
                showLoader()
            }
        }
        transactionHistoryViewModel.hideBottomSheet.observe(viewLifecycleOwner) {
            hideBottomSheet(it)
        }

        transactionHistoryViewModel.logKibanaDataLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let {
                PayUUtils.logKibanaEvents(
                    requireContext(), it.eventKey, it.eventData,
                    eventType = AnalyticsUtils.EventType.Info,
                    eventSeverity = it.eventSeverity,
                    status = it.status,
                    code = it.code
                )
            }
        }
    }

    private fun initUI(view: View) {
        showLoader()
        BottomSheetFooter(view)
        cvNoTransactionFound = view.findViewById(R.id.cvNoTransactionFound)
        errorTitle = view.findViewById(R.id.error_title)
        errorMessage = view.findViewById(R.id.error_sub_title)
        rvTransactions = view.findViewById(R.id.rvTransactions)
        ivBackIcon = view.findViewById(R.id.ivBackIcon)
        tvFromDate = view.findViewById(R.id.tvFromDate)
        tvToDate = view.findViewById(R.id.tvToDate)
        btnSearchTransactions = view.findViewById(R.id.btnSearchTransactions)

        tvFromDate.text = transactionHistoryViewModel.getDisplayFromDate()
        tvToDate.text = transactionHistoryViewModel.getDisplayToDate()

        ivBackIcon.setAvoidMultiClickListener {
            activity?.onBackPressed()
        }

        tvFromDate.setAvoidMultiClickListener {
            showDatePicker(
                requireContext(), transactionHistoryViewModel.getFromDate(),
                maxDate = Date().time
            ) { year, month, day ->
                tvFromDate.text = "$day/${month + 1}/$year"
                transactionHistoryViewModel.setFromDate(year, month, day) {
                    tvToDate.text = getString(R.string.to_text)
                }
            }
        }

        tvToDate.setAvoidMultiClickListener {
            val maxDate = transactionHistoryViewModel.getToMaxDate()
            showDatePicker(
                requireContext(),
                transactionHistoryViewModel.getToDate(),
                transactionHistoryViewModel.getFromDate().time,
                maxDate
            ) { year, month, day ->
                tvToDate.text = "$day/${month + 1}/$year"
                transactionHistoryViewModel.setToDate(year, month, day)
            }
        }

        btnSearchTransactions.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_TXN_HISTORY_SEARCH,
                ctScreenName ?: "",
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            hideLoader()
            transactionHistoryViewModel.fetchTransactionHistory()
        }
    }

    private fun showErrorScreen() {
        cvNoTransactionFound.visibility = View.VISIBLE
        rvTransactions.visibility = View.GONE

        errorTitle.text = getString(R.string.payu_txn_history_error_title)
        errorMessage.text = getString(R.string.payu_txn_history_error_message)
    }

    private fun showEmptyDataScreen() {
        cvNoTransactionFound.visibility = View.VISIBLE
        rvTransactions.visibility = View.GONE

        errorTitle.text = getString(R.string.payu_no_txn_found)
        errorMessage.text = getString(R.string.payu_no_txn_found_description)
    }

    private fun setData(transHistory: List<PayUTransactionHistory>) {
        if (transHistory.isEmpty()) {
            showEmptyDataScreen()
        } else {
            cvNoTransactionFound.visibility = View.GONE
            rvTransactions.visibility = View.VISIBLE

            rvTransactions.adapter?.let { adapter ->
                (adapter as TransactionHistoryItemAdapter).updateData(transHistory)
            } ?: kotlin.run {
                rvTransactions.layoutManager =
                    LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
                val transactionsAdapter = TransactionHistoryItemAdapter(
                    transHistory,
                    onActionClick = { txnHistory ->
                        val length = txnHistory.txnId?.length ?: 0
                        val id = "**${txnHistory.txnId?.substring(length - 6, length)}"
                        val map = HashMap<String, Any>().apply {
                            this[CLConstant.PAYU_CT_TXN_ID] = id
                        }
                        logCTAEvent(
                            CLConstant.PAYU_CT_TXN_HISTORY_CELL,
                            ctScreenName ?: "",
                            map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                        )
                        transactionHistoryViewModel.showTransactionDetails(txnHistory)
                    }
                )
                rvTransactions.adapter = transactionsAdapter
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = TransactionHistoryFragment()
    }

    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        when (screenType) {
            UpiPluginAction.RAISE_DISPUTE -> {
                transactionHistoryViewModel.getDisputeTypeList(result as PayUTransactionHistory)
            }

            UpiPluginAction.RAISE_DISPUTE_CONFIRM -> {
                val disputeModel = result as RaiseDisputeModel
                disputeModel.txnHistory?.let {
                    transactionHistoryViewModel.raiseQuery(
                        it,
                        disputeModel.query
                    )
                }
            }

            UpiPluginAction.TRANSACTION_HISTORY -> {
                transactionHistoryViewModel.fetchTransactionHistory()
            }

            UpiPluginAction.RAISE_DISPUTE_TYPE_LIST -> {
                transactionHistoryViewModel.showRaiseDispute(result as PayUTransactionHistory)
            }

            else -> super.onClick(screenType, result)
        }
    }

    private fun showDatePicker(
        context: Context,
        selectedDate: Date? = null,
        minDate: Long? = null,
        maxDate: Long? = null,
        listener: (Int, Int, Int) -> Unit
    ) {
        val cal = Calendar.getInstance()
        selectedDate?.let { cal.time = it }
        val selectedYear = cal[Calendar.YEAR]
        val selectedMonth = cal[Calendar.MONTH]
        val selectedDay = cal[Calendar.DAY_OF_MONTH]
        val datePickerDialog = DatePickerDialog(
            context, { _, year, month, day ->
                listener.invoke(year, month, day)
            }, selectedYear, selectedMonth, selectedDay
        )
        datePickerDialog.datePicker.run {
            maxDate?.let { this.maxDate = maxDate }
            minDate?.let { this.minDate = minDate }
        }
        datePickerDialog.show()
    }

    override fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean
    ) {
        transactionHistoryViewModel.sendMerchantCallback(response, isSuccess, isUserCancelled)
    }

    override fun closeCurrentFragment(bottomSheet: FixedRoundedCornerBottomSheet?) {
        PayUAndroidUtils.removeFragment(requireActivity(), this)
        if(getCommonViewModel()?.getIsNavigationEnforced() == false) {
            showManageOptions()
        }
    }

    override fun callCancelTransactionApi() {
        transactionHistoryViewModel.callCancelTransactionApi()
    }
}