package com.payu.upiboltui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.PayUDisputeData
import com.payu.commonmodelssdk.model.response.PayUDisputeType
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.DisputeTypeModel
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUUtils
import org.json.JSONObject
import java.util.Date

internal class TransactionHistoryViewModel(application: Application) :
    HandshakeBaseViewModel(application) {

    private val _transactionList: MutableLiveData<NetworkResponse<List<PayUTransactionHistory>>> =
        MutableLiveData()
    val transactionList: LiveData<NetworkResponse<List<PayUTransactionHistory>>> = _transactionList

    private val hideRaiseDisputeLoaderMutableLiveData: MutableLiveData<Boolean> = MutableLiveData()
    val hideRaiseDisputeLoaderLiveData: LiveData<Boolean> = hideRaiseDisputeLoaderMutableLiveData

    private val dateSelectionRange = 15
    private var fromDate: Date = PayUUtils.addWeekToDate(Date(), -1)
    private var toDate: Date? = Date()
    private var isDateRangeChanged = true

    init {
        fetchTransactionHistory()
    }

    fun getFromDate() = fromDate
    fun getToDate() = toDate

    fun getDisplayFromDate(): String {
        return PayUUtils.getFormattedStringFromDate(fromDate, PayUUPIBoltUiConstant.PAYU_DD_MM_YYYY)
    }

    fun getDisplayToDate(): String {
        return toDate?.let {
            PayUUtils.getFormattedStringFromDate(it, PayUUPIBoltUiConstant.PAYU_DD_MM_YYYY)
        } ?: ""
    }

    fun setFromDate(year: Int, month: Int, day: Int, clearToDate: () -> Unit) {
        PayUUtils.getYearMonthDayFromDate(fromDate) { currentYear, currentMonth, currentDay ->
            if (currentYear == year && currentMonth == month && currentDay == day) {
                return@getYearMonthDayFromDate
            } else {
                isDateRangeChanged = true
            }
        }
        fromDate = PayUUtils.getDateFromYearMonthDay(year, month, day)
        val date = PayUUtils.addDaysToDate(fromDate, dateSelectionRange).time
        toDate?.let {
            if (it.time > date || it.time < fromDate.time) {
                toDate = null
                clearToDate.invoke()
            }
        }
    }

    fun setToDate(year: Int, month: Int, day: Int) {
        toDate?.let {
            PayUUtils.getYearMonthDayFromDate(it) { currentYear, currentMonth, currentDay ->
                if (currentYear == year && currentMonth == month && currentDay == day) {
                    return@getYearMonthDayFromDate
                } else {
                    isDateRangeChanged = true
                }
            }
        }
        toDate = PayUUtils.getDateFromYearMonthDay(year, month, day)
    }

    fun getToMaxDate(): Long {
        val currentDate = Date().time
        val date = PayUUtils.addDaysToDate(fromDate, dateSelectionRange).time
        return if (date < currentDate) date else currentDate
    }

    fun fetchTransactionHistory() {
        val startTime = System.currentTimeMillis()
        if (isDateRangeChanged.not()) return
        val context = getApplication<Application>()
        toDate?.let { it ->
            action = UpiPluginAction.TRANSACTION_HISTORY
            if (fromDate.time > it.time) {
                _transactionList.value =
                    NetworkResponse.FailureWithAlert(context.getString(R.string.from_date_greater_than_to_error))
            } else {
                logCTTxnHistoryEvent(
                    getApplication(), CLConstant.PAYU_CT_INITIATED,
                    from = fromDate.toString(), to = toDate.toString()
                )
                _transactionList.value = NetworkResponse.Loading()
                PayUUPIBoltUI.getCoreInstance()?.fetchTransactionHistory(
                    PayUUtils.getFormattedStringFromDate(
                        fromDate,
                        PayUUPIBoltUiConstant.PAYU_DD_MM_YYYY
                    ),
                    PayUUtils.getFormattedStringFromDate(it, PayUUPIBoltUiConstant.PAYU_DD_MM_YYYY),
                    object :
                        PayUUPIBoltCallBack {
                        override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                            (response.result as ArrayList<PayUTransactionHistory>).let { txnHistoryList ->
                                isDateRangeChanged = false
                                val sortedList = txnHistoryList.sortedByDescending { txn ->
                                    txn.dateTime?.let {
                                        PayUUtils.getTxnHistoryDate(it)
                                    }
                                }
                                logCTTxnHistoryEvent(
                                    getApplication(), CLConstant.PAYU_EVENT_SUCCESS, startTime,
                                    fromDate.toString(), toDate.toString(), sortedList.size
                                )
                                _transactionList.value =
                                    NetworkResponse.Success(
                                        sortedList
                                    )
                            }
                        }

                        override fun onPayUFailure(response: PayUUPIBoltResponse) {
                            logCTTxnHistoryEvent(
                                getApplication(), CLConstant.PAYU_EVENT_FAILURE, startTime,
                                fromDate.toString(), toDate.toString(), message = response.message,
                                code = response.code.toString()
                            )
                            handleErrorResponse(response)
                        }
                    }
                )
            }
        }
        if (toDate == null) {
            _transactionList.value =
                NetworkResponse.FailureWithAlert(context.getString(R.string.select_to_date_error))
        }
    }

    fun showRaiseDispute(tranHistory: PayUTransactionHistory) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.payu_raise_dispute_bottomsheet,
                UpiPluginAction.RAISE_DISPUTE,
                UpiPluginAction.RAISE_DISPUTE.name,
                tranHistory,
                isNewInstance = tranHistory.disputeRc == null
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun showTransactionDetails(txnHistory: PayUTransactionHistory) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.payu_txn_details_bottomsheet,
                UpiPluginAction.TRANSACTION_DETAILS,
                UpiPluginAction.TRANSACTION_DETAILS.name,
                txnHistory
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun getDisputeTypeList(tranHistory: PayUTransactionHistory) {
        val startTime = System.currentTimeMillis()
        PayUUtils.logKibanaEvents(
            getApplication(), eventKey = PayUUpiConstant.PAYU_ACTION_INITIATED, eventData = "getDisputeTypeList",
            eventType = AnalyticsUtils.EventType.Info
        )
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_DISPUTE_TYPES,
            CLConstant.PAYU_CT_INITIATED,
            type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
        hideLoaderMutableLiveData.value = false
        PayUUPIBoltUI.getCoreInstance()
            ?.fetchQueryTypeList(tranHistory.refid, object : PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    hideLoaderMutableLiveData.value = true
                    (response.result as? List<PayUDisputeType>)?.let {
                        logCTApiStatusEvent(
                            CLConstant.PAYU_CT_FETCH_DISPUTE_TYPES,
                            CLConstant.PAYU_EVENT_SUCCESS,
                            startTime,
                            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                            count = it.size
                        )
                        showDisputeTypeList(DisputeTypeModel(tranHistory, it))
                    } ?: kotlin.run {
                        logCTApiStatusEvent(
                            CLConstant.PAYU_CT_FETCH_DISPUTE_TYPES,
                            CLConstant.PAYU_EVENT_SUCCESS,
                            startTime,
                            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                            message = "No List Found"
                        )
                        showRaiseDispute(tranHistory)
                    }
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_DISPUTE_TYPES,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime,
                        CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                        message = response.message,
                        code = response.code.toString()
                    )
                    hideLoaderMutableLiveData.value = true
                    showRaiseDispute(tranHistory)
                }
            })
    }

    fun raiseQuery(tranHistory: PayUTransactionHistory, query: String?) {
        val startTime = System.currentTimeMillis()
        tranHistory.txnId?.let { tranid ->
            tranHistory.amount?.let { amount ->
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_RAISE_DISPUTE_STATUS,
                    CLConstant.PAYU_CT_INITIATED,
                    type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
                PayUUPIBoltUI.getCoreInstance()?.raiseQuery(
                    tranid,
                    tranHistory.refid,
                    amount.toDoubleOrNull() ?: 0.0,
                    query ?: "",
                    tranHistory.disputeRc,
                    callback = object : PayUUPIBoltCallBack {
                        override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_RAISE_DISPUTE_STATUS,
                                CLConstant.PAYU_EVENT_SUCCESS,
                                startTime,
                                CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                            )
                            showRaiseDisputeSuccess((response.result as? PayUDisputeData)?.ticketNo)
                        }

                        override fun onPayUFailure(response: PayUUPIBoltResponse) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_RAISE_DISPUTE_STATUS,
                                CLConstant.PAYU_EVENT_FAILURE,
                                startTime,
                                CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                                message = response.message,
                                code = response.code.toString()
                            )
                            handleErrorResponse(response)
                        }
                    }
                )
            }
        }
    }

    fun showRaiseDisputeSuccess(queryId: String?) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_raise_dispute_success_title),
            String.format(
                context.getString(R.string.payu_raise_dispute_success_message),
                queryId ?: ""
            ),
            context.getString(R.string.payu_okay).uppercase(),
            false
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            UpiPluginAction.GENERIC_INFO.name, model
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showRaiseDisputeError(message: String?, isQueryExists: Boolean) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(
                if (message.isNullOrEmpty())
                    R.string.payu_error_occurred
                else
                    R.string.payu_alert
            ),
            message ?: context.getString(R.string.payu_raise_dispute_failure_message),
            context.getString(
                if (isQueryExists)
                    R.string.payu_okay
                else
                    R.string.payu_try_again
            ),
            true
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            UpiPluginAction.GENERIC_INFO.name,
            model, isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun handleErrorResponse(error: PayUUPIBoltResponse) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(error)
        if (isDeviceBindingFailedHandled.not()) {
            when (error.responseType) {
                PayUResponseTypes.REQUEST_GET_TRANSACTION_HISTORY_V3 -> {
                    _transactionList.value = NetworkResponse.Failure(error.message)
                }

                PayUResponseTypes.REQUEST_GET_RAISE_QUERY_V3 -> {
                    hideRaiseDisputeLoaderMutableLiveData.value = true
                    showRaiseDisputeError(
                        error.message,
                        error.code == PayUResponseCodes.PAYU_QUERY_ALREADY_EXISTS_CODE
                    )
                }

                else -> super.handleErrorResponse(error, null)
            }
        }
    }


    override fun navigateAfterHandshake() {
        when (action) {
            UpiPluginAction.TRANSACTION_HISTORY -> {
                fetchTransactionHistory()
            }

            else -> {}
        }
    }

    private fun logCTTxnHistoryEvent(
        context: Context,
        status: String,
        startTime: Long = 0,
        from: String, to: String,
        count: Int = 0,
        message: String? = null,
        code: String? = null
    ) {
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_CT_FROM_DATE] = from
            this[CLConstant.PAYU_CT_TO_DATE] = to
            if (count > 0) {
                this[CLConstant.PAYU_CT_COUNT] = count
            }
            message?.let { this[CLConstant.PAYU_CT_MESSAGE] = it }
        }
        AnalyticsUtils.setCTLogsForUPIWithData(
            context, CLConstant.PAYU_CT_FETCH_TXN_HISTORY,
            map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT, status, startTime
        )
        PayUUtils.logKibanaEvents(
            context,
            CLConstant.PAYU_CT_FETCH_TXN_HISTORY,
            JSONObject().apply {
                map.forEach { entry ->
                    put(entry.key, entry.value)
                }
                put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT)
            }.toString(),
            status = status,
            eventType = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventType.Error else AnalyticsUtils.EventType.Info,
            eventSeverity = if (status == CLConstant.PAYU_EVENT_FAILURE) AnalyticsUtils.EventSeverity.High else AnalyticsUtils.EventSeverity.Low,
            code = code,
            time = System.currentTimeMillis() - startTime
        )
    }

    fun showDisputeTypeList(model: DisputeTypeModel) {
        AnalyticsUtils.logClevertapCTAClickedEvent(
            getApplication(),
            CLConstant.PAYU_CT_DISPUTE_TYPE_DROPDOWN,
            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
            screenName = CLConstant.PAYU_CT_SCREEN_RAISE_DISPUTE
        )
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.fragment_dispute_type_list,
                UpiPluginAction.RAISE_DISPUTE_TYPE_LIST,
                UpiPluginAction.RAISE_DISPUTE_TYPE_LIST.name,
                model,
                isNewInstance = true
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }
}