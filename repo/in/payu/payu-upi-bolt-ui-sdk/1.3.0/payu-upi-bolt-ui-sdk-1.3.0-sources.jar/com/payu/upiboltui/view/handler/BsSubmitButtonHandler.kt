package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener

internal class BsSubmitButtonHandler {

    private var payuButton: TextView? = null
    private var cpbProgressBarBtn: ProgressBar? = null
    private var buttonText: String? = null

    fun init(
        view: View,
        payButtonText: String,
        isClickable: Boolean = true,
        upiBoltListener: PayUUPIBoltOnClickListener?,
        screenType: UpiPluginAction,
        showProgress: Boolean = true,
        result: Any? = null,
        onButtonClickListenerForLogs: (() -> Unit)? = null
    ) {
        buttonText = payButtonText
        payuButton = view.findViewById(R.id.payuButton)
        cpbProgressBarBtn = view.findViewById(R.id.cpbProgressBarBtn)
        payuButton?.text = payButtonText
        if (isClickable) {
            payuButton?.setAvoidMultiClickListener {
                onButtonClickListenerForLogs?.invoke()
                if (showProgress) {
                    payuButton?.text = ""
                    cpbProgressBarBtn?.isVisible = true
                    payuButton?.isClickable = false
                }
                upiBoltListener?.onClick(screenType, result)
            }
        } else {
            payuButton?.background =
                ContextCompat.getDrawable(view.context, R.drawable.payu_rounded_corner_grey)
            payuButton?.isClickable = false
        }
    }

    fun hideProgressLoader() {
        payuButton?.text = buttonText
        cpbProgressBarBtn?.isVisible = false
        payuButton?.isClickable = true
    }
}