package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.PayUSimInfo
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class SimSelectionBottomSheet : BaseBottomSheetFragment() {

    private var selectedIndex = -1

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initViews(view: View) {
        val context = view.context
        BottomSheetHeader(
            view,
            context.getString(R.string.payu_select_sim),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val data = upiFixedBottomSheetData?.data as? List<PayUSimInfo>
        val items = data
            ?.sortedBy { it.slotIndex }
            ?.map { simInfo ->
                val carrier = simInfo.carrierName.orEmpty().trim()
                val number = PayUUtils.getDisplayMobileNumber(simInfo.mobileNumber)

                when {
                    carrier.isNotEmpty() && simInfo.isPhoneNoAvailable -> "$carrier - $number"
                    carrier.isNotEmpty() -> carrier
                    else -> number
                }
            }
            ?.toTypedArray()

        val radioButton1 = view.findViewById<RadioButton>(R.id.rb_sim1)
        radioButton1.text = items?.first()
        val radioButton2 = view.findViewById<RadioButton>(R.id.rb_sim2)
        radioButton2.text = items?.last()

        val radiogroup = view.findViewById<RadioGroup>(R.id.rg_sim)


        val btnLayout: ConstraintLayout = view.findViewById(R.id.btn_select_sim)
        val btnPay: TextView = btnLayout.findViewById(R.id.payuButton)
        btnLayout.isEnabled = false
        btnLayout.alpha = 0.5f
        btnPay.text = context.getString(R.string.proceed)
        radiogroup.setOnCheckedChangeListener { _, checkedId ->
            selectedIndex = if (checkedId == R.id.rb_sim1) 0 else 1
            btnLayout.isEnabled = true
            btnLayout.alpha = 1f
        }
        btnLayout.setAvoidMultiClickListener {
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.SIM_SELECTION, data?.get(selectedIndex))
        }
    }

    companion object {

        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            SimSelectionBottomSheet().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }

    }
}