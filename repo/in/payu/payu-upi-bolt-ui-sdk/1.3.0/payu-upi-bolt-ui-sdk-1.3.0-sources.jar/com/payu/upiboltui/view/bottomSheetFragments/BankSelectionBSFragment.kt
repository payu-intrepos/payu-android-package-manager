package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant.PAYU_UI_EVENT
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.creditCardBanksIinList
import com.payu.upiboltui.constants.topBanksIinMap
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.SharedPrefsUtils
import com.payu.upiboltui.view.adapters.UpiBankAdapter
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class BankSelectionBSFragment : BaseBottomSheetFragment() {

    private var bankData: ArrayList<PayUBankData> = arrayListOf()

    private var tvBankHeader: TextView? = null
    private var searchViewBankList: EditText? = null
    private var rvBank: RecyclerView? = null
    private var noDataLayout: CardView? = null
    private var noDataTitle: TextView? = null
    private var noDataSubTitle: TextView? = null
    private var noDataImg: ImageView? = null
    private var closeButton: ImageView? = null
    
    private fun initViews(view: View){
        val context = view.context
        BottomSheetHeader(
            view,
            view.context.getString(R.string.payu_select_a_bank),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        searchViewBankList = view.findViewById(R.id.searchViewBankList)
        noDataLayout = view.findViewById(R.id.cvNoTransactionFound)
        noDataTitle = view.findViewById(R.id.error_title)
        noDataSubTitle = view.findViewById(R.id.error_sub_title)
        noDataSubTitle?.isVisible = false
        noDataImg = view.findViewById(R.id.imageview1)
        searchViewBankList?.maxWidth = Int.MAX_VALUE
        rvBank = view.findViewById(R.id.rvBank)
        rvBank?.layoutManager =
            LinearLayoutManager(view.context, RecyclerView.VERTICAL, false)

        val groupedMap = bankData.groupBy { it.iin }
        val sortedBankDataList = bankData.sortedWith(compareBy { it.bankName })

        val topBankDataList = ArrayList<PayUBankData>()
        topBanksIinMap.forEach { topBank ->
            groupedMap[topBank.value]?.toList()?.let {
                topBankDataList.addAll(it)
            }
        }

        val combinedList = (topBankDataList + sortedBankDataList).distinctBy(PayUBankData::bankName).filter { data ->
            creditCardBanksIinList.contains(data.iin).not()
                    && (InternalConfig.config?.excludedBanksIINs
                ?.contains(data.iin)?.not() ?: true)
        }

        searchViewBankList?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(newText: CharSequence?, p1: Int, p2: Int, p3: Int) {
                (rvBank?.adapter as? UpiBankAdapter)?.getFilter()?.filter(newText)
            }

            override fun afterTextChanged(editable: Editable) {

            }

        })

        /*searchViewBankList?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                (rvBank?.adapter as? UpiBankAdapter)?.getFilter()?.filter(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                (rvBank?.adapter as? UpiBankAdapter)?.getFilter()?.filter(newText)
                return true
            }
        })*/

        if (combinedList.isNotEmpty()) {
            val upiBankListAdapter = UpiBankAdapter(combinedList, upiFixedBottomSheetData?.upiBoltListener) { isVisible, query ->
                rvBank?.isVisible = isVisible
                noDataLayout?.isVisible = isVisible.not()
                if(isVisible.not()) {
                    showNoDataScreen(view.context, query)
                }
            }
            rvBank?.adapter = upiBankListAdapter
            saveBankLogosInPreference(view.context, combinedList)
        } else {
            showNoDataScreen(view.context)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun showNoDataScreen(
        context: Context,
        searchQuery: String? = null
    ) {
        noDataLayout?.isVisible = true
        noDataTitle?.text = context.getString(
            R.string.payu_no_banks_found,
            if (searchQuery.isNullOrEmpty().not()) "with \"$searchQuery\"" else ""
        )
        noDataImg?.setImageResource(R.drawable.payu_netbanking)
    }

    private fun saveBankLogosInPreference(context: Context, combinedList: List<PayUBankData>) {
        val iinLogoMap = combinedList
            .filter { it.logo.isNullOrEmpty().not() }
            .associate { Pair(it.iin, it.logo) }
        SharedPrefsUtils.saveBankLogoUrl(context, iinLogoMap)
    }

    companion object {

        @JvmStatic
        fun newInstance(data: ArrayList<PayUBankData>, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            BankSelectionBSFragment().apply {
                this.bankData = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }

    }
}