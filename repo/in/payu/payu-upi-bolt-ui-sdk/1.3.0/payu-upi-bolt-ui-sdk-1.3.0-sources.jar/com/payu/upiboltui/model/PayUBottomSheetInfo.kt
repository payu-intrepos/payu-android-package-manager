package com.payu.upiboltui.model

internal data class PayUBottomSheetInfo(
    val layout: Int,
    val pluginAction: UpiPluginAction,
    val tag: String,
    val data: Any? = null,
    val onUserCancel: (() -> Unit)? = null,
    val showExitConfirmation: Boolean = false,
    val isNewInstance: Boolean = false,
    val ctFlowType: String? = null
)
