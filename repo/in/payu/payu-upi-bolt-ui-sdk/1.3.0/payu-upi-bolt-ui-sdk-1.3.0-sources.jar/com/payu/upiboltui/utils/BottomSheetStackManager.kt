package com.payu.upiboltui.utils

import android.os.Handler
import android.os.Looper
import androidx.fragment.app.FragmentActivity
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import java.util.Stack

internal object BottomSheetStackManager {

    private val backStack = Stack<FixedRoundedCornerBottomSheet>()

    fun addBottomSheet(
        activity: FragmentActivity,
        bottomSheet: FixedRoundedCornerBottomSheet,
        tag: String
    ) {
        bottomSheet.show(activity.supportFragmentManager, tag)
        backStack.push(bottomSheet)
    }

    fun replace(
        activity: FragmentActivity,
        bottomSheet: FixedRoundedCornerBottomSheet,
        tag: String
    ) {
        var bs: FixedRoundedCornerBottomSheet? = null
        if (!backStack.isEmpty()) {
            bs = backStack.pop()
        }
        addBottomSheet(activity, bottomSheet, tag)
        Handler(Looper.getMainLooper()).postDelayed({
            bs?.dismiss()
        }, 300)
    }

    fun popBackStack(untilTag: String? = null, inclusive: Boolean = false) {
        if (untilTag.isNullOrEmpty().not()) {
            val bottomSheet = if (inclusive) {
                popBottomSheet()
            } else {
                peekBottomSheet()
            }
            bottomSheet?.let {
                if (bottomSheet.getBSTag() != untilTag) {
                    popBackStack(untilTag, inclusive)
                }
            }
        } else {
            popBottomSheet()
        }
    }

    fun peekBottomSheet(): FixedRoundedCornerBottomSheet? {
        if (backStack.size > 0) {
            return backStack.peek()
        }
        return null
    }

    private fun popBottomSheet(): FixedRoundedCornerBottomSheet? {
        if (backStack.size > 0) {
            val bs = backStack.pop()
            bs.dismiss()
            return bs
        }
        return null
    }

    fun closeAllBottomSheets() {
        backStack.forEach {
            it.dialog?.cancel()
        }
    }

    fun getBackStackSize() = backStack.size
}