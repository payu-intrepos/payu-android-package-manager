package com.payu.upiboltui.view.adapters


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.IinLogoMap
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrlAsync
import com.payu.upiboltui.utils.SharedPrefsUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel


class LinkedAccountsAdapter(
    private var accountsData: List<LinkedAccountsUIModel>,
    val onOptionsClick: (account: PayUCustomerBankAccounts) -> Unit,
    val onSetPinClick: (account: PayUCustomerBankAccounts, holder: BankViewHolder) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    // Coroutine scope for image loading - uses SupervisorJob to prevent one failure from cancelling all
    private val imageLoadingScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.payu_linked_upi_account_items, parent, false)
        return BankViewHolder(view)
    }

    override fun onBindViewHolder(recyclerViewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = recyclerViewHolder as BankViewHolder
        val context = holder.itemView.context
        val account = accountsData[holder.adapterPosition].account

        // Cancel any previous image loading job for this view holder to prevent memory leaks
        holder.imageLoadingJob?.cancel()
        holder.imageLoadingJob = null

        val url = SharedPrefsUtils.getBankLogoUrl(
            context,
            account.bankAccounts.iin ?: ""
        )

        val logoUrl =
            if (url.isNullOrEmpty() && IinLogoMap.containsKey(account.bankAccounts.iin))
                IinLogoMap[account.bankAccounts.iin]
            else
                url

        // Load image asynchronously without blocking the RecyclerView
        holder.imageLoadingJob = holder.ivBankListItemIcon.loadImageUrlAsync(
            url = logoUrl,
            placeholder = R.drawable.payu_netbanking,
            scope = imageLoadingScope
        )

        holder.tvBankName.text = String.format(
            "%s - %s", account.bankName,
            account.bankAccounts.accountNo?.formatAccountNumber()
        )
        holder.tvAccountNumber.isVisible = account.bankAccounts.vpa.isNullOrEmpty().not()
        account.bankAccounts.vpa?.let {
            holder.tvAccountNumber.text =
                context.getString(R.string.payu_bolt_upi_id, account.bankAccounts.vpa)
        }

        if (account.bankAccounts.vpa.isNullOrEmpty()) {
            holder.payButton.text = context.getString(R.string.set_upi_id)
            holder.payButtonLayout.visibility = View.VISIBLE
        } else {
            if (account.bankAccounts.mbeba.equals(PayUUPIBoltUiConstant.PAYU_N)) {
                holder.payButton.text = context.getString(R.string.payu_set_upi_pin)
                holder.payButtonLayout.visibility = View.VISIBLE
            }
        }
        holder.ivBankListItemMore.setAvoidMultiClickListener {
            onOptionsClick.invoke(account)
        }

        holder.payButton.setAvoidMultiClickListener {
            onSetPinClick.invoke(account, holder)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        // Cancel image loading when view is recycled to prevent memory leaks
        (holder as? BankViewHolder)?.imageLoadingJob?.cancel()
        (holder as? BankViewHolder)?.imageLoadingJob = null
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        // Cancel the coroutine scope when adapter is detached to prevent memory leaks
        imageLoadingScope.cancel()
    }

    override fun getItemCount(): Int {
        return accountsData.size
    }

    inner class BankViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivBankListItemIcon: ImageView = itemView.findViewById(R.id.ivBankListItemIcon)
        var tvBankName: TextView = itemView.findViewById(R.id.tvBankName)
        var tvAccountNumber: TextView = itemView.findViewById(R.id.tvAccountNumber)
        var ivBankListItemMore: ImageView = itemView.findViewById(R.id.ivBankListItemMore)
        var payButtonLayout: ConstraintLayout = itemView.findViewById(R.id.payuUpiPinButton)
        var payButton: TextView = payButtonLayout.findViewById(R.id.payuButton)
        var cpbProgressBarBtn: ProgressBar = payButtonLayout.findViewById(R.id.cpbProgressBarBtn)
        
        // Track image loading job to cancel when view is recycled
        var imageLoadingJob: Job? = null
    }

    fun showPayButtonLoader(holder: BankViewHolder?) {
        holder?.payButton?.text = ""
        holder?.cpbProgressBarBtn?.isVisible = true
        holder?.payButtonLayout?.isClickable = false
    }

    fun hidePayButtonLoader(holder: BankViewHolder?) {
        holder?.cpbProgressBarBtn?.isVisible = false
        holder?.payButtonLayout?.isClickable = true
    }

}