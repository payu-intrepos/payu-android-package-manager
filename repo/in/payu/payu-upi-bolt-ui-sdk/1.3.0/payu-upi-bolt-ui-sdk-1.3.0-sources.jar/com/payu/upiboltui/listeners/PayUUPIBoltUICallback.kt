package com.payu.upiboltui.listeners

import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack

interface PayUUPIBoltUICallback: PayUUPIBoltCallBack {
    fun onPayUCancel(isTxnInitiated: Boolean)
}