package com.payu.upiboltui.constants

internal val topBanksIinMap = linkedMapOf<String, String>().apply {
    put("AXIS", "607153")
    put("HDFC", "607152")
    put("ICICI", "508534")
    put("KOTAK", "607420")
    put("SBI", "508548")
    put("BOB", "606985")
    put("UBI", "508500")
    put("PNB", "508568")
    put("CAN", "508532")
    put("BOI", "508505")
}

internal val creditCardBanksIinList = listOf<String>()
internal val IinLogoMap = linkedMapOf<String, String>().apply {
    put("607153", "https://www.axisbank.com/bank_logos/axis.png")
    put("607152", "https://www.axisbank.com/bank_logos/bank_hdfc.png")
    put("508534", "https://www.axisbank.com/bank_logos/ICICI_logo.png")
    put("607420", "https://www.axisbank.com/bank_logos/kotak.png")
    put("508548", "https://www.axisbank.com/bank_logos/sbi.png")
    put("175007", "https://www.axisbank.com/bank_logos/sbi.png")
    put("111100", "https://www.axisbank.com/bank_logos/sbi.png")
    put("180023", "https://www.axisbank.com/bank_logos/sbi.png")
    put("606985", "https://www.axisbank.com/bank_logos/bank_bob.png")
    put("508500", "https://www.axisbank.com/bank_logos/union_bank.png")
    put("508568", "https://www.axisbank.com/bank_logos/pnb.png")
    put("508532", "https://www.axisbank.com/bank_logos/canara.png")
    put("508505", "https://www.axisbank.com/bank_logos/bank_boi.png")
}

