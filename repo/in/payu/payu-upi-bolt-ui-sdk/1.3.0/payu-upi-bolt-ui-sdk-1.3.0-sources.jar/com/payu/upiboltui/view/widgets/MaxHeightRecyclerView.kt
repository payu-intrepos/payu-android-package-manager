package com.payu.upiboltui.view.widgets

import android.content.Context
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView

class MaxHeightRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    private var maxHeightPx = Int.MAX_VALUE

    fun setMaxHeightPx(height: Int) {
        maxHeightPx = height
        setHasFixedSize(true)
        setItemViewCacheSize(20)
        requestLayout()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxHeightSpec = MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST)
        super.onMeasure(widthSpec, maxHeightSpec)
    }
}
