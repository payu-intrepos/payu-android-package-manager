package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class DeRegisterAccountsBSFragment : BaseBottomSheetFragment() {

    private var btnCancel: TextView? = null
    private var btnConfirm: TextView? = null
    private var progress: ProgressBar? = null

    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        val btHeader = view.findViewById<ConstraintLayout>(R.id.btHeader)
        btHeader.background =
            ContextCompat.getDrawable(context, R.drawable.payu_rounded_corner_flat_f9fafe)


        val header = BottomSheetHeader(
            view,
            context.getString(R.string.payu_deregister_all_accounts),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        header.setCloseButtonVisibility(false)
        btnCancel = view.findViewById(R.id.btnCancel)
        btnConfirm = view.findViewById(R.id.btnConfirm)
        progress = view.findViewById(R.id.progressBarBtn)

        btnCancel?.setAvoidMultiClickListener {
            logCTClickEvent(CLConstant.PAYU_CT_DEREGISTER_CANCEL)
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CANCEL,
                false
            )
        }

        btnConfirm?.setAvoidMultiClickListener {
            logCTClickEvent(CLConstant.PAYU_CT_YES)
            progress?.visibility = View.VISIBLE
            btnConfirm?.text = ""
            btnConfirm?.isClickable = false
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS)
        }
        initObservers(context)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initObservers(context: Context) {
        getCommonViewModel()?.hideDeregisterAccountLoaderLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let {
                hideProgressLoader(context)
            }
        }
    }

    private fun hideProgressLoader(context: Context) {
        progress?.visibility = View.GONE
        btnConfirm?.text = context.getString(R.string.payu_confirm)
        btnConfirm?.isClickable = true
    }

    private fun logCTClickEvent(name: String) {
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_CT_SCREEN] = CLConstant.PAYU_CT_DEREGISTER_UPI_CONFIRM
        }
        logCTAEvent(
            name, CLConstant.PAYU_CT_SCREEN_DEREGISTER_UPI,
            map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
    }

    companion object {

        @JvmStatic
        fun newInstance(
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) = DeRegisterAccountsBSFragment().apply {
            this.upiFixedBottomSheetData = upiFixedBottomSheetData
        }

    }
}