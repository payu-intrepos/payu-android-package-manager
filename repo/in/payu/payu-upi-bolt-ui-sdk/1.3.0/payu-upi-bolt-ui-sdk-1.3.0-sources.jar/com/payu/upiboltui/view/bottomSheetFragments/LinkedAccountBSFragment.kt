package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PaymentManager
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.FetchLinkedAccountAdapter
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.view.widgets.MaxHeightRecyclerView
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.UpiFixedBottomSheetViewModel
import org.json.JSONObject


class LinkedAccountBSFragment : BaseBottomSheetFragment() {
    private var linkedAccountList: MutableList<LinkedAccountsUIModel>? = null
    private var fetchLinkedAccountAdapter: FetchLinkedAccountAdapter? = null
    private var recyclerView: MaxHeightRecyclerView? = null
    private var tvOtherBanks: TextView? = null
    private var progressBar: ProgressBar? = null
    private var rightImage: ImageView? = null
    private var otherBanksHolder: ConstraintLayout? = null
    private var currentSelectedBankAccount: LinkedAccountsUIModel? = null
    private lateinit var upiFixedBottomSheetViewModel: UpiFixedBottomSheetViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            linkedAccountList = it.getParcelableArrayList(DATA)
        }
    }

    private fun initViews(view: View) {
        recyclerView = view.findViewById(R.id.recyclerView)
        tvOtherBanks = view.findViewById<TextView>(R.id.tvOtherBanks)
        otherBanksHolder = view.findViewById<ConstraintLayout>(R.id.otherBankHolder)
        progressBar = view.findViewById(R.id.progress_bar)
        rightImage = view.findViewById(R.id.rightImage)
        val screenHeight = resources.displayMetrics.heightPixels
        val maxHeight = (screenHeight * 0.5).toInt()
        recyclerView?.setMaxHeightPx(maxHeight)

        val context = view.context
        BottomSheetFooter(view)
        val tvPaymentOption = view.findViewById<TextView>(R.id.tvPaymentOption)
        tvPaymentOption.text = context.getString(
            R.string.payu_account_info, linkedAccountList?.size
        )

        BottomSheetHeader(
            view,
            "Paying to ${InternalConfig.config?.merchantName}",
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        otherBanksHolder?.setAvoidMultiClickListener {
            PayUUtils.logKibanaEvents(
                context, CLConstant.PAYU_CT_CTA_CLICKED,
                JSONObject().apply {
                    put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_REPEAT)
                    put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_ADD_OTHER_BANK)
                }.toString(),
                eventType = AnalyticsUtils.EventType.Info,
                screenName = CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS,
                name = CLConstant.PAYU_CT_ADD_OTHER_BANK
            )
            AnalyticsUtils.logClevertapCTAClickedEvent(
                requireContext(), CLConstant.PAYU_CT_ADD_OTHER_BANK,
                CLConstant.PAYU_EVENT_TYPE_REPEAT,
                screenName = CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.BANK_SELECTION)
        }

        setRecyclerView(context, recyclerView, tvOtherBanks)
        initObservers()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViewModel()
        initViews(view)
    }

    private fun initViewModel() {
        upiFixedBottomSheetViewModel = ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application,
                PaymentManager()
            )
        )[UpiFixedBottomSheetViewModel::class.java]
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initObservers() {

        getCommonViewModel()?.vpaLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        updateSelectedAccountLoader(true)
                    }

                    is NetworkResponse.Success -> {
                        upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.LINKED_ACCOUNT)
                    }

                    is NetworkResponse.Failure -> {
                        updateSelectedAccountLoader(false)
                    }

                    else -> {}
                }
            }
        }

        getCommonViewModel()?.showBankListLoaderLiveData?.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let {
                if (it) {
                    updateProgressBarVisibility(true)
                } else {
                    // using handler as temporary fix for handling load time in showing banks list
                    Handler(Looper.getMainLooper()).postDelayed({
                        updateProgressBarVisibility(false)
                    }, 1000)
                }
            }
        }

        getCommonViewModel()?.showPayLoaderLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let { showLoader ->
                updateSelectedAccountLoader(showLoader)
            }
        }
    }

    private fun updateSelectedAccountLoader(showLoader: Boolean) {
        currentSelectedBankAccount?.let { acc ->
            acc.showProgressLoader = showLoader
            fetchLinkedAccountAdapter?.updateBankAccount(acc)
        }
    }

    private fun setRecyclerView(
        context: Context,
        recyclerView: RecyclerView?,
        tvOtherBanks: TextView?
    ) {
        recyclerView?.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        fetchLinkedAccountAdapter =
            linkedAccountList?.let {
                FetchLinkedAccountAdapter(
                    it,
                    InternalConfig.paymentParams?.amount,
                    onItemClick = { bankAccount ->
                        val eventName: String
                        currentSelectedBankAccount = bankAccount
                        if (bankAccount.account.bankAccounts.vpa.isNullOrEmpty()) {
                            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                                UpiPluginAction.UPDATE_VPA, bankAccount.account
                            )
                            eventName = CLConstant.PAYU_CT_SET_UPI_ID
                        } else if (bankAccount.account.bankAccounts.mbeba.equals(
                                PayUUPIBoltUiConstant.PAYU_N
                            )
                        ) {
                            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                                UpiPluginAction.M_PIN_SETUP, bankAccount.account
                            )
                            eventName = CLConstant.PAYU_CT_SET_MPIN
                        } else {
                            tvOtherBanks?.isClickable = false
                            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                                UpiPluginAction.PAY, bankAccount.account
                            )
                            eventName = CLConstant.PAYU_CT_PAY
                        }
                        val map = HashMap<String, Any>().apply {
                            bankAccount.account.bankAccounts.accountNo?.let { accNo ->
                                this[CLConstant.PAYU_CT_ACCOUNT] = accNo
                            }
                        }
                        AnalyticsUtils.logClevertapCTAClickedEvent(
                            requireContext(), eventName,
                            CLConstant.PAYU_EVENT_TYPE_REPEAT, map,
                            screenName = CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS
                        )
                        PayUUtils.logKibanaEvents(
                            requireContext(),
                            eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                            eventData = JSONObject().apply {
                                put(CLConstant.PAYU_CT_NAME, eventName)
                                put(
                                    CLConstant.PAYU_CT_ACCOUNT,
                                    bankAccount.account.bankAccounts.accountNo
                                )
                                put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_REPEAT)
                            }.toString(),
                            screenName = CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS,
                            name = eventName
                        )
                    }, onItemExpand = { account ->
                        upiFixedBottomSheetViewModel.logVpaStatus(account.account)
                        upiFixedBottomSheetViewModel.logMpinStatus(account.account)
                    })
            }
        recyclerView?.adapter = fetchLinkedAccountAdapter
    }

    private fun updateProgressBarVisibility(visible: Boolean) {
        otherBanksHolder?.isClickable = visible.not()
        progressBar?.isVisible = visible
        rightImage?.isVisible = visible.not()
        (recyclerView?.adapter as? FetchLinkedAccountAdapter)?.setViewCancelableOnLoading(visible.not())
    }

    companion object {
        @JvmStatic
        fun newInstance(
            data: MutableList<LinkedAccountsUIModel>,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            LinkedAccountBSFragment().apply {
                this.linkedAccountList = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}