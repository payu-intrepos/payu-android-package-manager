/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.upiboltui;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.upiboltui";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "1.3.0";
}
