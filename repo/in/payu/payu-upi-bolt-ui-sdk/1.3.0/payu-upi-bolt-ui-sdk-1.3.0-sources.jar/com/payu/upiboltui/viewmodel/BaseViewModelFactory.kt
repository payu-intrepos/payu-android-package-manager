package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.payu.upiboltui.utils.PaymentManager

class BaseViewModelFactory(
    private val mApplication: Application,
    private val paymentManager: PaymentManager? = null
) : ViewModelProvider.AndroidViewModelFactory(mApplication) {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {

        return when {
            modelClass.isAssignableFrom(UpiFixedBottomSheetViewModel::class.java) -> {
                UpiFixedBottomSheetViewModel(mApplication, paymentManager) as T
            }

            modelClass.isAssignableFrom(ManageAccountViewModel::class.java) -> {
                ManageAccountViewModel(mApplication) as T
            }

            modelClass.isAssignableFrom(QueryListViewModel::class.java) -> {
                QueryListViewModel(mApplication) as T
            }

            modelClass.isAssignableFrom(SetPinBaseViewModel::class.java) -> {
                SetPinBaseViewModel(mApplication) as T
            }

            modelClass.isAssignableFrom(TransactionHistoryViewModel::class.java) -> {
                return TransactionHistoryViewModel(mApplication) as T
            }

            modelClass.isAssignableFrom(UpiSetupViewModel::class.java) -> {
                return UpiSetupViewModel(mApplication, paymentManager) as T
            }

            modelClass.isAssignableFrom(CommonViewModel::class.java) -> {
                return CommonViewModel(mApplication) as T
            }


            else -> throw IllegalArgumentException("Unknown ViewModel class")
        }

    }

}