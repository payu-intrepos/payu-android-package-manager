package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.view.isVisible
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BottomSheetSubHeaderWithPb
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class CommonLoaderBSFragment : BaseBottomSheetFragment() {

    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        setHeader(context, view)
        val bottomSheetSubHeaderWithPb = BottomSheetSubHeaderWithPb()
        bottomSheetSubHeaderWithPb.init(view, context.getString(R.string.initiating), true)
        val btnLayout = view.findViewById<TextView>(R.id.payuButton)
        val btnLayoutMain = view.findViewById<View>(R.id.btnUpiSetup)
        btnLayout.isVisible = false
        btnLayoutMain.isVisible = false
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun setHeader(context: Context, view: View) {
        val header = BottomSheetHeader(
            view,
            context.getString(R.string.fetching_details),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        setBottomSheetCancelable(header)
        initObserver()
    }

    private fun initObserver() {
        getCommonViewModel()?.cancelTimerLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let {
                cancelTimer()
            }
        }
    }

    companion object {

        @JvmStatic
        fun newInstance(upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            CommonLoaderBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}