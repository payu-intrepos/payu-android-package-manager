package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener


class TransactionHistoryItemAdapter(
    private var txnHistoryData: List<PayUTransactionHistory>,
    private val onActionClick: (txnHistory: PayUTransactionHistory) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.payu_transaction_history_items, parent, false)
        return TransactionViewHolder(view)
    }

    override fun getItemCount() = txnHistoryData.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val transactionsViewHolder = holder as TransactionViewHolder
        val context = transactionsViewHolder.itemView.context

        val statusImg = when (txnHistoryData[position].status) {
            PayUUpiConstant.PAYU_TRAN_STATUS_COMPLETE,PayUUpiConstant.PAYU_TRAN_STATUS_SUCCESS -> R.drawable.payu_transaction_success
            PayUUpiConstant.PAYU_TRAN_STATUS_PENDING -> R.drawable.payu_mobile_error_icon
            else -> R.drawable.payu_transaction_failure
        }
        transactionsViewHolder.ivTransactionStatusImage.setImageResource(statusImg)

        val status = when (txnHistoryData[position].status) {
            PayUUpiConstant.PAYU_TRAN_STATUS_COMPLETE,PayUUpiConstant.PAYU_TRAN_STATUS_SUCCESS -> PayUUpiConstant.PAYU_SUCCESSFULLY_PAID
            PayUUpiConstant.PAYU_TRAN_STATUS_PENDING -> PayUUpiConstant.PAYU_PAYMENT_PENDING
            PayUUpiConstant.PAYU_TRAN_STATUS_FAILED -> PayUUpiConstant.PAYU_PAYMENT_FAILED
            PayUUpiConstant.PAYU_TRAN_STATUS_REJECTED -> PayUUpiConstant.PAYU_PAYMENT_REJECTED
            else -> PayUUpiConstant.PAYU_PAYMENT_DECLINED
        }
        transactionsViewHolder.tvTransactionStatus.text = status
        transactionsViewHolder.tvTransactionAmount.text =
            context.getString(
                R.string.payu_rupees_symbol, PayUUtils.formatAmount(txnHistoryData[position].amount)
            )

        transactionsViewHolder.tvTransactionDate.text = txnHistoryData[position].dateTime?.let {
            PayUUtils.getTxnHistoryDisplayDate(context, it)
        }
        transactionsViewHolder.itemView.setAvoidMultiClickListener {
            onActionClick.invoke(txnHistoryData[position])
        }
    }

    fun updateData(newData: List<PayUTransactionHistory>) {
        txnHistoryData = newData
        notifyDataSetChanged()
    }

    inner class TransactionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivTransactionStatusImage: ImageView =
            itemView.findViewById(R.id.ivTransactionStatusImage)
        var tvTransactionStatus: TextView = itemView.findViewById(R.id.tvTransactionStatus)
        var ivTransactionRightArrow: ImageView = itemView.findViewById(R.id.ivTransactionRightArrow)
        var tvTransactionAmount: TextView = itemView.findViewById(R.id.tvTransactionAmount)
        var tvTransactionDate: TextView = itemView.findViewById(R.id.tvTransactionDate)
    }
}