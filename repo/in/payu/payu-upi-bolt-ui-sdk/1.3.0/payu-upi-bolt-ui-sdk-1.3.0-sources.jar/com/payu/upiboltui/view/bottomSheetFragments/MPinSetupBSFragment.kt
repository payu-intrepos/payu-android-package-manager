package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PaymentManager
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BsPinSetupHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.UpiFixedBottomSheetViewModel
import org.json.JSONObject


class MPinSetupBSFragment : BaseBottomSheetFragment() {

    private var data: PayUCustomerBankAccounts? = null
    private var bsPinSetupHandler: BsPinSetupHandler?= null
    private fun getBottomSheetViewModel(): UpiFixedBottomSheetViewModel {
        return ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application,
                PaymentManager()
            )
        )[UpiFixedBottomSheetViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.getParcelable(DATA)
        }
    }
    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        val upiFixedBottomSheetViewModel = getBottomSheetViewModel()
        bsPinSetupHandler = BsPinSetupHandler()
        bsPinSetupHandler?.init(
            view,
            context,
            this,
            upiFixedBottomSheetData?.upiBoltListener
        ) { cardNumber, expiry ->
            (data)?.let {
                val map = HashMap<String, Any>().apply {
                    it.bankAccounts.accountNo?.let { accNo ->
                        this[CLConstant.PAYU_CT_ACCOUNT] = accNo
                    }
                }
                val flowType = upiFixedBottomSheetData?.ctFlowType ?: CLConstant.PAYU_EVENT_TYPE_REGISTRATION
                AnalyticsUtils.logClevertapCTAClickedEvent(
                    requireContext(),
                    CLConstant.PAYU_CT_SET_MPIN_CONFIRM,
                    flowType, map,
                    screenName = CLConstant.PAYU_CT_SCREEN_SET_MPIN
                )
                PayUUtils.logKibanaEvents(
                    requireContext(),
                    eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                    eventData = JSONObject().apply {
                        put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_SET_MPIN_CONFIRM)
                        put(CLConstant.PAYU_EVENT_TYPE, flowType)
                    }.toString(),
                    screenName = CLConstant.PAYU_CT_SCREEN_SET_MPIN,
                    name = CLConstant.PAYU_CT_SET_MPIN_CONFIRM
                )
                upiFixedBottomSheetViewModel.activateAccount(
                    it, cardNumber, expiry, upiFixedBottomSheetData?.upiBoltListener, flowType
                )
            }
        }
        initObservers()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initObservers(){
        getCommonViewModel()?.hideSetMPinBSLoaderLiveData?.observe(viewLifecycleOwner){
            it.getContentIfNotHandled()?.let {
                bsPinSetupHandler?.hideProgressLoader()
            }
        }
    }



    companion object {

        @JvmStatic
        fun newInstance(
            data: PayUCustomerBankAccounts,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) = MPinSetupBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }

    }
}