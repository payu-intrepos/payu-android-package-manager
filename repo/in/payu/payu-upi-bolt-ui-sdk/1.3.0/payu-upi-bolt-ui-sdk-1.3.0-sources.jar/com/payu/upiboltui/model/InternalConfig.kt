package com.payu.upiboltui.model

import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams
import com.payu.upiboltui.listeners.PayUUPIBoltUICallback

internal object InternalConfig {
    // init params - not to be cleared in deInit
    var config: PayUUPIBoltUIConfig? = null
    var appName: String? = null
    var refId: String? = null
    var bankHandle: String? = null
    var largestSuffixUsedForVpa = -1
    var isUserRegisteredEventLogged = false
    var isUserRegistrationStarted = false

    // non init params
    var paymentParams: PayUUPIBoltPaymentParams? = null
    var callback: PayUUPIBoltUICallback? = null
    var ctFlowType: String = CLConstant.PAYU_EVENT_TYPE_REGISTRATION
    fun clearNonInitParams() {
        paymentParams = null
        callback = null
        bankHandle = null
        isUserRegistrationStarted = false
    }

    fun clearAll() {
        clearNonInitParams()
        config = null
        appName = null
        refId = null
        largestSuffixUsedForVpa = -1
    }
}
