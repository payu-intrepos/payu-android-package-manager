package com.payu.upiboltui.model

import com.payu.commonmodelssdk.model.response.PayUTransactionHistory

internal data class RaiseDisputeModel(
    val txnHistory: PayUTransactionHistory?,
    val query: String
)
