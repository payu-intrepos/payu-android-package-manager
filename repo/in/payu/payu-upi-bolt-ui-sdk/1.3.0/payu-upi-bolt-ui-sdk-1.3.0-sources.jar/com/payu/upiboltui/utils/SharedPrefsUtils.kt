package com.payu.upiboltui.utils

import android.content.Context
import android.content.SharedPreferences
import com.payu.commonmodelssdk.constants.SharedPrefsConstants
import com.payu.upiboltui.BuildConfig
import org.json.JSONObject

internal object SharedPrefsUtils {

    fun saveBooleanConfig(context: Context, key: String, value: Boolean) {
        val editor = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG).edit()
        editor?.putBoolean(key, value)
        editor?.apply()
    }

    fun getBooleanConfig(context: Context, key: String): Boolean {
        val prefs = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG)
        return prefs.getBoolean(key, false)
    }

    fun saveIntConfig(context: Context, key: String, value: Int) {
        val editor = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG).edit()
        editor?.putInt(key, value)
        editor?.apply()
    }

    fun getIntConfig(context: Context, key: String): Int {
        val prefs = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG)
        return prefs.getInt(key, -1)
    }

    fun storePermissionRequestCount(context: Context) {
        val editor = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_PERMISSION).edit()
        val permissionCount = getPermissionRequestCount(context)
        editor?.putInt(SharedPrefsConstants.PERMISSION_COUNT, permissionCount + 1)
        editor?.apply()
    }

    fun getPermissionRequestCount(context: Context): Int {
        val sharedPreferences = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_PERMISSION)
        return sharedPreferences.getInt(SharedPrefsConstants.PERMISSION_COUNT, 0)
    }

    private fun getSharedPreference(context: Context, subFileName: String): SharedPreferences {
        val fileName = BuildConfig.LIBRARY_PACKAGE_NAME + subFileName
        return context.getSharedPreferences(fileName, Context.MODE_PRIVATE)
    }

    fun saveBankLogoUrl(context: Context, iinLogoMap: Map<String, String?>) {
        val prefs = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG)
        val jsonString = prefs.getString(SharedPrefsConstants.PAYU_BANK_LOGO_URL_JSON, null)
        val json = jsonString?.let { JSONObject(jsonString) } ?: JSONObject()
        iinLogoMap.keys.forEach { iin ->
            if (json.has(iin).not()) {
                json.put(iin, iinLogoMap[iin] ?: "")
            }
        }
        prefs.edit().putString(SharedPrefsConstants.PAYU_BANK_LOGO_URL_JSON, json.toString())
            .apply()
    }

    fun getBankLogoUrl(context: Context, iin: String): String? {
        if(iin.isEmpty())
            return null

        val prefs = getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG)
        val jsonString = prefs.getString(SharedPrefsConstants.PAYU_BANK_LOGO_URL_JSON, null)
        jsonString?.let {
            val json = JSONObject(jsonString)
            return json.optString(iin)
        }
        return null
    }

    fun clearPreference(context: Context) {
        getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_PERMISSION).edit()?.clear()?.apply()
        getSharedPreference(context, SharedPrefsConstants.PAYU_FILE_CONFIG).edit()?.clear()?.apply()
    }
}