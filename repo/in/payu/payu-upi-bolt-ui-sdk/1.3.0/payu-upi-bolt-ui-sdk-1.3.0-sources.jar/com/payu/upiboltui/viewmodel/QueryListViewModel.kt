package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event

internal class QueryListViewModel(application: Application):
    HandshakeBaseViewModel(application) {

    private val _queryList: MutableLiveData<NetworkResponse<List<PayUTransactionHistory>>> = MutableLiveData()
    val queryList: LiveData<NetworkResponse<List<PayUTransactionHistory>>> = _queryList

    private val disputeStatusMutableLiveData: MutableLiveData<Event<NetworkResponse<String>>> = MutableLiveData()
    val disputeStatusLiveData: LiveData<Event<NetworkResponse<String>>> = disputeStatusMutableLiveData

    init {
        fetchQueryList()
    }

    fun fetchQueryList() {
        val startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_DISPUTES, CLConstant.PAYU_CT_INITIATED,
            type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
        action = UpiPluginAction.RAISE_DISPUTE_LIST
        _queryList.value = NetworkResponse.Loading()
        PayUUPIBoltUI.getCoreInstance()?.fetchQueryList(object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                (response.result as ArrayList<PayUTransactionHistory>).let { txnHistoryList ->
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_DISPUTES, CLConstant.PAYU_EVENT_SUCCESS,
                        startTime, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                        count = txnHistoryList.size
                    )
                    _queryList.value = NetworkResponse.Success(txnHistoryList)
                }
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_FETCH_DISPUTES, CLConstant.PAYU_EVENT_FAILURE,
                    startTime, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                    message = response.message, code = response.code.toString()
                )
                handleErrorResponse(response)
            }
        })
    }

    fun checkDisputeStatus(txnHistory: PayUTransactionHistory) {
        txnHistory.txnId?.let { txnId ->
            val startTime = System.currentTimeMillis()
            logCTApiStatusEvent(
                CLConstant.PAYU_CT_FETCH_DISPUTE_STATUS,
                CLConstant.PAYU_CT_INITIATED,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            disputeStatusMutableLiveData.value = Event(NetworkResponse.Loading())
            PayUUPIBoltUI.getCoreInstance()?.checkDisputeStatus(txnId, object: PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    (response.result as PayUTransactionHistory).querystatus?.let {
                        if (it.isEmpty().not()) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_FETCH_DISPUTE_STATUS,
                                CLConstant.PAYU_EVENT_SUCCESS,
                                startTime,
                                CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                            )
                            disputeStatusMutableLiveData.value = Event(NetworkResponse.Success(it))
                        } else {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_FETCH_DISPUTE_STATUS,
                                CLConstant.PAYU_EVENT_FAILURE,
                                startTime,
                                CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                                message = "Empty status"
                            )
                            disputeStatusMutableLiveData.value = Event(NetworkResponse.Failure())
                        }
                    }
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_DISPUTE_STATUS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime,
                        CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                        message = response.message,
                        code = response.code.toString()
                    )
                    disputeStatusMutableLiveData.value = Event(NetworkResponse.Failure())
                }
            })
        }
    }

    fun handleErrorResponse(error: PayUUPIBoltResponse) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(error)
        if(isDeviceBindingFailedHandled.not()) {
            when (error.responseType) {
                PayUResponseTypes.REQUEST_LIST_QUERIES_V3 -> {
                    _queryList.value = NetworkResponse.Failure(error.message)
                }
                else -> super.handleErrorResponse(error, null)
            }
        }
    }

    override fun navigateAfterHandshake() {
        when (action) {
            UpiPluginAction.RAISE_DISPUTE_LIST -> {
                fetchQueryList()
            }

            else -> {}
        }
    }

}