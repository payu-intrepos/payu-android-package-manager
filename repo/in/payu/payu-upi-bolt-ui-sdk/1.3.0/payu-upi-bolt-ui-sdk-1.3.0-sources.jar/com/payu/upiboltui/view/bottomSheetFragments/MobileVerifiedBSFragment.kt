package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BottomSheetSubHeaderWithPb
import com.payu.upiboltui.view.handler.BsSubmitButtonHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class MobileVerifiedBSFragment : BaseBottomSheetFragment() {

    private var data: UpiPluginAction? = null
    private var buttonHandler: BsSubmitButtonHandler? = null


    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        BottomSheetHeader(
            view,
            context.getString(R.string.payu_mobile_number_verified),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )

        val bottomSheetSubHeaderWithPb = BottomSheetSubHeaderWithPb()
        bottomSheetSubHeaderWithPb.init(
            view,
            context.getString(
                R.string.payu_cust_mobile_number_verified,
                PayUUtils.getDisplayMobileNumber(InternalConfig.config?.getPhone() ?: "")
            ),
            drawable = R.drawable.payu_checked
        )
        val bsSubmitButtonHandler = BsSubmitButtonHandler()
        (data)?.let { nextAction ->
            bsSubmitButtonHandler.init(
                view,
                payButtonText = context.getString(R.string.payu_continue),
                upiBoltListener = upiFixedBottomSheetData?.upiBoltListener,
                screenType = nextAction,
                showProgress = PayUAndroidUtils.isInternetAvailable(context)
            )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    fun hideProgressLoader() = buttonHandler?.hideProgressLoader()

    companion object {

        @JvmStatic
        fun newInstance(data: UpiPluginAction, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            MobileVerifiedBSFragment().apply {
                this.data = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }

    }
}