package com.payu.upiboltui.utils

import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams
import com.payu.upiboltui.model.PayUUPIBoltUIConfig

object PayUValidateUtils {

    fun validateVPA(upi: String): Boolean {
        if (upi.isEmpty()) return false

        val onlyPhoneRegex = Regex("-?[0-9]+(\\.[0-9]+)?")
        if (upi.matches(onlyPhoneRegex)) return false

        val vpaRegex = Regex("^[0-9A-Za-z.-]{2,256}$")
        return upi.matches(vpaRegex)
    }

    private fun isValidPhoneNumber(phone: String) = phone.matches(Regex("^[5-9][0-9]{9,11}$"))

    private fun isValidEmail(email: String) = email.matches(Regex("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"))

    fun validatePayUPaymentParams(paymentParams: PayUUPIBoltPaymentParams?): Pair<Boolean, String> {
        val message = PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE
        paymentParams?.let {
            val formattedAmount = PayUUtils.formatAmount(it.amount)
            if (formattedAmount == null) {
                return Pair(false, message + PayUUpiConstant.PAYU_AMOUNT)
            }
            if ((it.amount?.toDoubleOrNull() ?: 0.0) > PayUUpiConstant.PAYU_MAX_AMOUNT) {
                return Pair(false, PayUResponseMessages.PAYU_MAX_AMOUNT_MESSAGE)
            }
            if (it.txnId.isNullOrEmpty()) return Pair(
                false,
                message + PayUUpiConstant.PAYU_UNQ_TXNID
            )
            if (it.productInfo.isNullOrEmpty()) return Pair(
                false,
                message + PayUUpiConstant.PAYU_PRODUCT_INFO
            )
            return Pair(true, "")
        }
        return Pair(false, message + PayUUpiConstant.PAYU_PAYMENT_PARAM)
    }

    fun validateSDKInitParams(uiSDKInitParams: PayUUPIBoltUIConfig?): Pair<Boolean, String> {
        val message = PayUResponseMessages.PAYU_MANDATORY_PARAM_MISSING_MESSAGE
        uiSDKInitParams?.run {
            if (merchantKey.isEmpty()) return Pair(
                false,
                message + PayUUpiConstant.PAYU_MERCHANT_KEY
            )
            else if (!isValidPhoneNumber(getPhone())) return Pair(
                false,
                message + PayUUpiConstant.PAYU_MOBILE
            )
            else if (merchantName.isEmpty()) return Pair(
                false,
                message + PayUUpiConstant.PAYU_MERCHANT_NAME
            )
            else if (isValidEmail(email).not()) return Pair(
                false, message + PayUUpiConstant.PAYU_EMAIL_ID
            )
            else if (pluginTypes.isEmpty()) return Pair(
                false, message + PayUUpiConstant.PAYU_PLUGIN_TYPES
            )
            else if (pluginTypes.firstOrNull() == PluginType.AXIS && isAxisDependencyAvailable().not()) {
                return Pair(
                    false,
                    "$message + ${PayUUpiConstant.PAYU_RUNTIME_DEPENDENCY} ${PluginType.AXIS.name}"
                )
            } else if ((pluginTypes.firstOrNull() == PluginType.HDFC || pluginTypes.firstOrNull() == PluginType.BHIM)
                && isHDFCDependencyAvailable().not()) {
                return Pair(
                    false,
                    "$message + ${PayUUpiConstant.PAYU_RUNTIME_DEPENDENCY} ${PluginType.HDFC.name}"
                )
            } else if (pluginTypes.firstOrNull() == PluginType.BHIM && issuingBanks.isNullOrEmpty()) {
                return Pair(
                    false,
                    "$message + ${PayUUpiConstant.PAYU_ISSUING_BANK}"
                )
            }

            else return Pair(true, "")
        }
        return Pair(false, message + PayUUpiConstant.PAYU_INIT_PARAM)
    }

    private fun matchRegex(input: String, regexPattern: String): Boolean {
        return input.isNotEmpty() && Regex(regexPattern).matches(input)
    }

    private fun isSdkAvailable(className: String?): Boolean {
        try {
            if (!className.isNullOrEmpty()) {
                val wrapperClassLoader = PayUValidateUtils::class.java.classLoader
                wrapperClassLoader?.loadClass(className)
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun isAxisDependencyAvailable() = isSdkAvailable(PayUUpiConstant.PAYU_OLIVE_SDK_PACKAGE)
            && isSdkAvailable(PayUUpiConstant.PAYU_AXIS_WRAPPER_SDK_PACKAGE)
            && isSdkAvailable(PayUUpiConstant.PAYU_NPCI_CL_SDK_PACKAGE)

    fun isHDFCDependencyAvailable() = isSdkAvailable(PayUUpiConstant.PAYU_HDFC_SDK_PACKAGE)
            && isSdkAvailable(PayUUpiConstant.PAYU_NPCI_CL_SDK_PACKAGE)

}