package com.payu.upiboltui.view.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.QueryListItemAdapter
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.QueryListViewModel


internal class QueryListFragment : BaseFragment() {

    private lateinit var ivBackIcon: ImageView
    private lateinit var ivNoQueryIcon: ImageView
    private lateinit var rvQueries: RecyclerView
    private lateinit var cvNoQueryFound: CardView
    private lateinit var tvNoQueryTitle: TextView
    private lateinit var tvNoQueryMsg: TextView
    private lateinit var queryListViewModel: QueryListViewModel

    private var selectedRefreshPosition = -1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        ctScreenName = CLConstant.PAYU_CT_SCREEN_VIEW_DISPUTES
        return inflater.inflate(R.layout.fragment_query_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI(view)
        initViewModelAndObservers()
    }

    private fun initViewModelAndObservers() {
        queryListViewModel = ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application
            )
        )[QueryListViewModel::class.java]

        queryListViewModel.queryList.observe(viewLifecycleOwner) { response ->
            response?.let { 
                when (it) {
                    is NetworkResponse.Loading -> {
                        showLoader()
                    }
                    is NetworkResponse.Success -> {
                        hideLoader()
                        hideBottomSheet()
                        setData(it.data)
                    }
                    is NetworkResponse.Failure -> {
                        hideLoader()
                        showNoQueriesLayout()
                    }
                    else -> {}
                }
            }
        }

        queryListViewModel.flowCompleteLiveData.observe(viewLifecycleOwner) {
            PayUAndroidUtils.removeFragment(requireActivity(), this)
        }

        queryListViewModel.hideLoaderLiveData.observe(viewLifecycleOwner) {
            hideLoader()
        }

        queryListViewModel.showBottomSheetLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { sheetInfo ->
                showBottomSheet(sheetInfo)
            }
        }
        queryListViewModel.hideBottomSheet.observe(viewLifecycleOwner) {
            hideBottomSheet(it)
        }

        queryListViewModel.logKibanaDataLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let {
                PayUUtils.logKibanaEvents(
                    requireContext(), it.eventKey, it.eventData,
                    eventType = AnalyticsUtils.EventType.Info,
                    eventSeverity = it.eventSeverity,
                    status = it.status,
                    code = it.code
                )
            }
        }

        queryListViewModel.disputeStatusLiveData.observe(viewLifecycleOwner) { event ->
            event?.getContentIfNotHandled()?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        rvQueries.adapter?.let {
                            if(selectedRefreshPosition != -1) {
                                (it as QueryListItemAdapter).updateLoadingStatus(true, selectedRefreshPosition)
                            }
                        }
                    }
                    is NetworkResponse.Success -> {
                        rvQueries.adapter?.let {
                            if(selectedRefreshPosition != -1) {
                                (it as QueryListItemAdapter).run {
                                    updateLoadingStatus(false, selectedRefreshPosition)
                                    updateDisputeStatus(response.data, selectedRefreshPosition)
                                }
                            }
                        }
                    }
                    else -> {
                        rvQueries.adapter?.let {
                            if(selectedRefreshPosition != -1) {
                                (it as QueryListItemAdapter).updateLoadingStatus(false, selectedRefreshPosition)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun initUI(view: View) {
        showLoader()
        BottomSheetFooter(view)
        cvNoQueryFound = view.findViewById(R.id.cvNoTransactionFound)
        tvNoQueryTitle = view.findViewById(R.id.error_title)
        ivNoQueryIcon = view.findViewById(R.id.imageview1)
        tvNoQueryMsg = view.findViewById(R.id.error_sub_title)
        rvQueries = view.findViewById(R.id.rvQueries)
        ivBackIcon = view.findViewById(R.id.ivBackIcon)

        ivBackIcon.setAvoidMultiClickListener {
            activity?.onBackPressed()
        }

    }

    private fun setData(queryHistory: List<PayUTransactionHistory>) {
        if (queryHistory.isEmpty()) {
            showNoQueriesLayout()
        } else {
            cvNoQueryFound.visibility = View.GONE
            rvQueries.visibility = View.VISIBLE

            rvQueries.adapter?.let { adapter ->
                (adapter as QueryListItemAdapter).updateData(queryHistory)
            } ?: kotlin.run {
                rvQueries.layoutManager =
                    LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
                val queriesAdapter = QueryListItemAdapter(
                    queryHistory
                ) { txnHistory, position ->
                    selectedRefreshPosition = position
                    queryListViewModel.checkDisputeStatus(txnHistory)
                }
                rvQueries.adapter = queriesAdapter
            }
        }
    }

    private fun showNoQueriesLayout() {
        cvNoQueryFound.visibility = View.VISIBLE
        rvQueries.visibility = View.GONE
        tvNoQueryTitle.text = getString(R.string.payu_no_concerns_raised)
        tvNoQueryMsg.text = getString(R.string.payu_no_query_found_description)
        ivNoQueryIcon.setImageResource(R.drawable.payu_empty_query_list)
    }

    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        when (screenType) {
            UpiPluginAction.RAISE_DISPUTE_LIST -> {
                queryListViewModel.fetchQueryList()
            }
            else -> super.onClick(screenType, result)
        }
    }

    override fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean
    ) {
        queryListViewModel.sendMerchantCallback(response, isSuccess, isUserCancelled)
    }

    companion object {
        @JvmStatic
        fun newInstance() = QueryListFragment()
    }

    override fun closeCurrentFragment(bottomSheet: FixedRoundedCornerBottomSheet?) {
        PayUAndroidUtils.removeFragment(requireActivity(), this)
        if(getCommonViewModel()?.getIsNavigationEnforced() == false) {
            showManageOptions()
        }
    }

    override fun callCancelTransactionApi() {
        queryListViewModel.callCancelTransactionApi()
    }
}