package com.payu.upiboltui.model

import android.os.Parcelable
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import kotlinx.parcelize.Parcelize

@Parcelize
data class ManageAccountModel(
    val account: PayUCustomerBankAccounts,
    val balance: Double? = null,
    val checkBalanceError: UpiPluginAction? = null,
    val errorMessage: String? = null
): Parcelable
