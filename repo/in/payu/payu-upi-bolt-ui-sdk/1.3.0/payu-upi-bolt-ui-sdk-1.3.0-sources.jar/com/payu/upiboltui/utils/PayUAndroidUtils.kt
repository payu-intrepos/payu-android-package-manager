package com.payu.upiboltui.utils

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.CountDownTimer
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant

internal object PayUAndroidUtils {

    fun getCountDownTimer(
        timeout: Long,
        interval: Long? = null,
        onTimerFinish: () -> Unit,
        onInterval: ((millisUntilFinished: Long) -> Unit)? = null
    ): CountDownTimer {
        return object : CountDownTimer(timeout, interval ?: timeout) {
            override fun onTick(millisUntilFinished: Long) {
                onInterval?.invoke(millisUntilFinished)
            }

            override fun onFinish() {
                onTimerFinish.invoke()
            }
        }
    }

    fun replaceFragment(activity: FragmentActivity, fragment: Fragment, tag: String) {
        val transaction = activity.supportFragmentManager.beginTransaction()
        transaction.replace(android.R.id.content, fragment, tag)
        transaction.commit()
    }

    fun removeFragment(activity: FragmentActivity, fragment: Fragment) {
        val transaction = activity.supportFragmentManager.beginTransaction()
        transaction.remove(fragment)
        transaction.commit()
    }

    fun isInternetAvailable(context: Context): Boolean {
        var result = false

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connectivityManager.activeNetwork ?: return false
            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
            result = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.run {
                connectivityManager.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_WIFI -> true
                        ConnectivityManager.TYPE_MOBILE -> true
                        ConnectivityManager.TYPE_ETHERNET -> true
                        else -> false
                    }

                }
            }
        }
        return result
    }

    fun copyToClipboard(context: Context, text: CharSequence) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("label", text)
        clipboard.setPrimaryClip(clip)
    }

    fun setSpannableText(
        context: Context, completeText: String, highLightedText: String,
        textView: TextView, onClickCallback: () -> Unit
    ) {
        val spannable: Spannable = SpannableString(completeText)
        val str = spannable.toString()
        val iStart = str.indexOf(highLightedText)
        val iEnd = iStart + highLightedText.length

        val ssText = SpannableString(spannable)
        val clickableSpan: ClickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                onClickCallback.invoke()
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
                ds.typeface = Typeface.DEFAULT_BOLD
                ds.color = context.resources.getColor(R.color.payu_color_053BC1)
            }
        }
        ssText.setSpan(clickableSpan, iStart, iEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        textView.text = ssText
        textView.movementMethod =
            LinkMovementMethod.getInstance()
        textView.highlightColor = Color.TRANSPARENT
        textView.findViewById<TextView>(R.id.tvRaiseDisputeInfo).isEnabled = true
    }

    fun hideSoftKeyboard(context: Context, view: View) {
        val inputMethodManager = context.getSystemService(
            Activity.INPUT_METHOD_SERVICE
        ) as InputMethodManager
        if (inputMethodManager.isAcceptingText) {
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }

    fun isLastFragmentShowing(manager: FragmentManager?): Boolean {
        return manager?.findFragmentByTag(PayUUPIBoltUiConstant.ROOT_FRAGMENT) != null
                || (BottomSheetStackManager.getBackStackSize()) > 1
    }
}

fun View.setAvoidMultiClickListener(onClickAction: () -> Unit) {
    this.setOnClickListener {
        if (MultipleClickHandler.isSafeOnClickListener()) {
            onClickAction.invoke()
        }
    }
}