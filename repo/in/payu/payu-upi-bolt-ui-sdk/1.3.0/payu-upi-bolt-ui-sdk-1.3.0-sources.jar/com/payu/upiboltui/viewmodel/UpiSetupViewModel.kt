package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PaymentManager

internal class UpiSetupViewModel(application: Application, private val paymentUtils: PaymentManager?) :
    SetPinBaseViewModel(application) {

    private val banksListMutableLiveData = MutableLiveData<Event<NetworkResponse<Any>>>()
    val banksListLiveData: LiveData<Event<NetworkResponse<Any>>> = banksListMutableLiveData

    private val showPayLoaderMutableLiveData: MutableLiveData<Event<Boolean>> = MutableLiveData()
    val showPayLoaderLiveData: LiveData<Event<Boolean>> = showPayLoaderMutableLiveData

    private val fetchBankListNetworkState: MutableLiveData<NetworkResponse<Any?>> =
        MutableLiveData()

    private var bankData: PayUBankData? = null
    private var account: PayUCustomerBankAccounts? = null
    private var isPayButtonVisible = false

    fun openPinSetScreen() {
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            account?.let {
                showBottomSheet.value =
                    Event(getPinSetScreenInfo(it, InternalConfig.ctFlowType))
            }
        } else {
            showNetworkErrorBtSheet()
        }
    }

    fun makePayment() {
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            account?.bankAccounts?.let {
                showPayLoaderMutableLiveData.value = Event(true)
                paymentUtils?.makePayment(getApplication(), it, object :
                    PayUUPIBoltCallBack {
                    override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                        showVerifyPaymentScreen(InternalConfig.ctFlowType)
                        verifyPayment()
                    }

                    override fun onPayUFailure(response: PayUUPIBoltResponse) {
                        handleErrorResponse(response)
                    }
                }, InternalConfig.ctFlowType)
            }
        } else {
            showNetworkErrorBtSheet()
        }
    }

    fun verifyPayment() {
        paymentUtils?.verifyPayment(getApplication(), object : PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                sendMerchantCallback(response, isSuccess = true, popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name)
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                handleErrorResponse(response)
            }
        }, ctFlowType = InternalConfig.ctFlowType)
    }

    fun fetchBankList(showProgress: Boolean = false) {
        startTime = System.currentTimeMillis()
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            if(fetchBankListNetworkState.value is NetworkResponse.Loading)
                return

            fetchBankListNetworkState.value = NetworkResponse.Loading()
            if (showProgress) {
                banksListMutableLiveData.value = Event(NetworkResponse.Loading())
            }
            logCTApiStatusEvent(
                CLConstant.PAYU_CT_FETCH_BANKS,
                CLConstant.PAYU_CT_INITIATED
            )
            PayUUPIBoltUI.getCoreInstance()?.fetchBankList(object:
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    fetchBankListNetworkState.value = NetworkResponse.Success(null)
                    response.result?.let {
                        logCTApiStatusEvent(
                            CLConstant.PAYU_CT_FETCH_BANKS,
                            CLConstant.PAYU_EVENT_SUCCESS,
                            startTime, (it as ArrayList<PayUBankData>).size
                        )
                        banksListMutableLiveData.value = Event(NetworkResponse.Success(it))
                    }
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    fetchBankListNetworkState.value = NetworkResponse.Failure()
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_BANKS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime, message = response.message,
                        code = response.code.toString()
                    )
                    handleErrorResponse(response)
                }
            })
        } else {
            showNetworkErrorBtSheet()
        }
    }

    private fun showBankListErrorScreen() {
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.upi_verifying_no_screen,
            UpiPluginAction.BANK_LIST_ERROR_SCREEN,
            UpiPluginAction.BANK_LIST_ERROR_SCREEN.name
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun setCurrentAccount(account: PayUCustomerBankAccounts) {
        this.account = account
    }

    fun getSelectedAccount() = account

    override fun navigateAfterHandshake() {
        when (action) {
            UpiPluginAction.FETCH_ACCOUNTS_IIN -> {
                bankData?.let {
                    fetchAccountsIin(it, InternalConfig.ctFlowType)
                }
            }
            else -> {}
        }
    }

    fun handleErrorResponse(response: PayUUPIBoltResponse) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(response)
        if(isDeviceBindingFailedHandled.not()) {
            when (response.responseType) {
                PayUResponseTypes.REQUEST_LIST_BANKS -> {
                    banksListMutableLiveData.value = Event(NetworkResponse.Failure(errorData = Any()))
                    showBankListErrorScreen()
                }

                PayUResponseTypes.REQUEST_PAY -> {
                    val isUserCancelled = response.code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE
                    if (isUserCancelled) {
                        cancelTxnAfterDelay(response, InternalConfig.ctFlowType)
                    } else {
                        response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                        sendMerchantCallback(
                            response, false,
                            popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name
                        )
                    }
                }

                PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS -> {
                    response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                    sendMerchantCallback(response, isSuccess = false, popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name)
                }

                else -> super.handleErrorResponse(response, null)
            }
        }
    }

    fun fetchAccountsIin() {
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            bankData?.let { fetchAccountsIin(it, InternalConfig.ctFlowType) }
        } else {
            showNetworkErrorBtSheet()
        }
    }

    fun getBankData() = bankData

    fun setBankData(bankData: PayUBankData) {
        this.bankData = bankData
    }

    override fun callCancelTransactionApi() {
        paymentUtils?.cancelVerify()
        val status = if (isPayButtonVisible)
            CLConstant.PAYU_CT_STATUS_REGISTERED
        else
            CLConstant.PAYU_CT_STATUS_NOT_REGISTERED
        logUserRegisteredEvent(
            status,
            if (status == CLConstant.PAYU_CT_STATUS_NOT_REGISTERED) {
                HashMap<String, String>().apply {
                    put(
                        CLConstant.PAYU_CT_UPI_ID_STATUS,
                        if (account?.bankAccounts?.vpa.isNullOrEmpty().not())
                            CLConstant.PAYU_CT_VPA_ALREADY_SET
                        else
                            CLConstant.PAYU_CT_VPA_NOT_SET
                    )
                    put(
                        CLConstant.PAYU_CT_MPIN_STATUS,
                        if (account?.bankAccounts?.mbeba == "Y")
                            CLConstant.PAYU_CT_MPIN_ALREADY_SET
                        else
                            CLConstant.PAYU_CT_MPIN_NOT_SET
                    )
                }
            } else null
        )
        super.callCancelTransactionApi()
    }

    fun logCTApiStatusEvent(
        eventName: String,
        status: String,
        startTime: Long = 0,
        count: Int = 0,
        message: String? = null,
        code: String? = null,
        additionalInfo: HashMap<String, String>? = null
    ) {
        logCTApiStatusEvent(
            eventName, status, startTime, InternalConfig.ctFlowType,
            count, message, code, additionalInfo
        )
    }

    fun setPayButtonVisible(visible: Boolean) {
        isPayButtonVisible = visible
    }

    fun findAccountByAccRefNum(accRefNumber: String): PayUCustomerBankAccounts? {
        return getAccountList()?.find { acc ->
            acc.bankAccounts.accRefNumber == accRefNumber
        }
    }

    internal fun isTpvAccount(account: PayUCustomerBankAccounts): Boolean {
        return PayUUPIBoltUI.getCoreInstance()?.getTpvFilteredAccountList(
            InternalConfig.paymentParams?.beneficiaryDetails,
            arrayListOf(account)
        ).isNullOrEmpty().not()
    }

}