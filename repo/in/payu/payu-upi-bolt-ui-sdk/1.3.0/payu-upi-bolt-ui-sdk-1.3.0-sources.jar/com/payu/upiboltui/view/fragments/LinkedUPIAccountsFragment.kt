package com.payu.upiboltui.view.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.Group
import androidx.core.view.isVisible
import androidx.core.view.marginEnd
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.model.SetMpinModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.LinkedAccountsAdapter
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.view.widgets.MaxHeightRecyclerView
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.ManageAccountViewModel
import org.json.JSONObject

internal class LinkedUPIAccountsFragment : BaseFragment() {

    private lateinit var rvBankListItem: MaxHeightRecyclerView
    private lateinit var tvAddNewBank: TextView
    private lateinit var cvNoBankAccount: CardView
    private lateinit var bankAccountListLayout: Group
    private lateinit var ivBackIcon: ImageView
    private lateinit var btnAddAccount: TextView

    private lateinit var manageAccountViewModel: ManageAccountViewModel
    private lateinit var linkedAccountsAdapter: LinkedAccountsAdapter
    private var startTime: Long = 0
    private lateinit var bankViewHolder: LinkedAccountsAdapter.BankViewHolder
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        ctScreenName = CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNTS
        return inflater.inflate(R.layout.fragment_linked_upi_accounts, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI(view)
        initViewModel()
    }



    private fun initViewModel() {
        manageAccountViewModel = ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application
            )
        )[ManageAccountViewModel::class.java]

        manageAccountViewModel.upiAccounts.observe(viewLifecycleOwner) {
            it?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        startTime = System.currentTimeMillis()
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        hideLoader()
                        hideBottomSheet()
                        setLinkedAccounts(response.data)
                    }

                    is NetworkResponse.Failure -> {
                        hideLoader()
                    }

                    else -> {}
                }
            }
        }

        manageAccountViewModel.bankList.observe(viewLifecycleOwner) {
            it?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        startTime = System.currentTimeMillis()
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        Handler(Looper.getMainLooper()).postDelayed({
                            hideLoader()
                        }, 1000)
                        manageAccountViewModel.showBanksListScreen(
                            response.data,
                            ctFlowType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                        )
                    }

                    is NetworkResponse.Failure -> {
                        hideLoader()
                    }

                    else -> {}
                }
            }
        }

        manageAccountViewModel.showBottomSheetLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { sheetInfo ->
                showBottomSheet(sheetInfo)
            }
        }

        manageAccountViewModel.deleteAccountLiveData.observe(viewLifecycleOwner) {
            it?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        hideLoader()
                        BottomSheetStackManager.popBackStack(
                            UpiPluginAction.MANAGE_ACCOUNT.name,
                            inclusive = true
                        )
                        manageAccountViewModel.fetchLinkedAccounts()
                    }

                    is NetworkResponse.Failure -> {
                        hideLoader()
                    }

                    else -> {}
                }
            }
        }
        manageAccountViewModel.vpaLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { response ->
                getCommonViewModel()?.setUpdateVpaState(response)
                when (response) {
                    is NetworkResponse.Loading -> {
                        linkedAccountsAdapter.showPayButtonLoader(bankViewHolder)
                    }

                    is NetworkResponse.Success -> {
                        linkedAccountsAdapter.hidePayButtonLoader(bankViewHolder)
                        manageAccountViewModel.fetchLinkedAccounts()
                    }

                    is NetworkResponse.Failure -> {
                        linkedAccountsAdapter.hidePayButtonLoader(bankViewHolder)
                    }

                    else -> {}
                }
            }
        }

        manageAccountViewModel.accountsListLiveData.observe(viewLifecycleOwner) {
            it?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        hideLoader()
                        manageAccountViewModel.fetchLinkedAccounts()
                    }

                    is NetworkResponse.Failure -> {
                        var bankName = ""
                        if (response.data is PayUBankData) {
                            var bankData = response.data as PayUBankData
                            bankName = bankData.bankName
                        }

                        hideLoader()
                        manageAccountViewModel.showFetchAccountsErrorScreen(bankName)
                    }

                    else -> {}
                }
            }
        }

        manageAccountViewModel.flowCompleteLiveData.observe(viewLifecycleOwner) {
            PayUAndroidUtils.removeFragment(requireActivity(), this)
            //   manageAccountViewModel.showManagementOptions2()
        }

        manageAccountViewModel.hideLoaderLiveData.observe(viewLifecycleOwner) {
            hideLoader()
        }
        manageAccountViewModel.hideBottomSheet.observe(viewLifecycleOwner) {
            hideBottomSheet(it)
        }

        manageAccountViewModel.logKibanaDataLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let {
                PayUUtils.logKibanaEvents(
                    requireContext(), it.eventKey, it.eventData,
                    eventType = AnalyticsUtils.EventType.Info,
                    eventSeverity = it.eventSeverity,
                    status = it.status,
                    code = it.code
                )
            }
        }
    }

    private fun setLinkedAccounts(bankAccountList: List<LinkedAccountsUIModel>) {
        if (bankAccountList.isEmpty()) {
            cvNoBankAccount.visibility = View.VISIBLE
            bankAccountListLayout.visibility = View.GONE

            btnAddAccount.setAvoidMultiClickListener {
                logAddAccountEvent()
                manageAccountViewModel.addBankAccount()
            }
        } else {
            cvNoBankAccount.visibility = View.GONE
            bankAccountListLayout.visibility = View.VISIBLE

            rvBankListItem.layoutManager =
                LinearLayoutManager(activity, RecyclerView.VERTICAL, false)

            tvAddNewBank.isVisible = true
            tvAddNewBank.setAvoidMultiClickListener {
                logAddAccountEvent()
                if (PayUAndroidUtils.isInternetAvailable(requireContext()))
                    manageAccountViewModel.addBankAccount()
                else {
                    manageAccountViewModel.showNetworkErrorBtSheet()
                }
            }

            linkedAccountsAdapter = LinkedAccountsAdapter(
                bankAccountList,
                onOptionsClick = { account ->
                    PayUUtils.logKibanaEvents(requireContext(), eventKey = PayUUpiConstant.PAYU_BUTTON_CLICKED, eventData = CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNT_OPTIONS,
                        eventType = AnalyticsUtils.EventType.Info)
                    logCTMoreOptionClicked(account)
                    manageAccountViewModel.showManagementScreen(account)
                }, onSetPinClick = { account, holder ->
                    var eventName: String? = null
                    if (account.bankAccounts.vpa.isNullOrEmpty()) {
                        eventName = CLConstant.PAYU_CT_SET_UPI_ID
                        bankViewHolder = holder
                        manageAccountViewModel.createVpa(account, isManualCreation = false)
                    } else if (account.bankAccounts.mbeba.equals(PayUUPIBoltUiConstant.PAYU_N)) {
                        eventName = CLConstant.PAYU_CT_SET_MPIN
                        PayUUtils.logKibanaEvents(requireContext(), eventKey = PayUUpiConstant.PAYU_BUTTON_CLICKED, eventData = eventName,
                            eventType = AnalyticsUtils.EventType.Info)
                        manageAccountViewModel.openPinSetScreen(account)
                    }
                    eventName?.let {
                        val map = HashMap<String, Any>().apply {
                            account.bankAccounts.accountNo.let { accNo ->
                                this[CLConstant.PAYU_CT_ACCOUNT] = accNo
                            }
                        }
                        AnalyticsUtils.logClevertapCTAClickedEvent(
                            requireContext(), eventName,
                            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT, map, ctScreenName
                        )
                        PayUUtils.logKibanaEvents(
                            requireContext(),
                            eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                            eventData = JSONObject().apply {
                                put(CLConstant.PAYU_CT_NAME, eventName)
                                put(CLConstant.PAYU_CT_ACCOUNT, account.bankAccounts.accountNo)
                                put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT)
                            }.toString(),
                            screenName = ctScreenName,
                            name = eventName
                        )
                    }
                }
            )

            rvBankListItem.adapter = linkedAccountsAdapter
        }
    }

    private fun initUI(view: View) {
        BottomSheetFooter(view)
        showLoader()
        cvNoBankAccount = view.findViewById(R.id.cv_no_bank_account)
        bankAccountListLayout = view.findViewById(R.id.bank_account_list_layout)
        ivBackIcon = view.findViewById(R.id.ivBackIcon)
        btnAddAccount = view.findViewById(R.id.btnAddAccount)
        rvBankListItem = view.findViewById(R.id.rvBankListItem)
        tvAddNewBank = view.findViewById(R.id.tvAddNewBank)
        val screenHeight = resources.displayMetrics.heightPixels
        val maxHeight = (screenHeight * 0.75).toInt()
        rvBankListItem.setMaxHeightPx(maxHeight)

        ivBackIcon.setAvoidMultiClickListener {
            activity?.onBackPressedDispatcher?.onBackPressed()
        }
    }

    private fun deleteAccountForManagementJourney(account: PayUCustomerBankAccounts) {
        manageAccountViewModel.removeAccount(account.bankAccounts)
    }

    companion object {
        @JvmStatic
        fun newInstance() = LinkedUPIAccountsFragment()
    }

    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        hideLoader()
        if (PayUAndroidUtils.isInternetAvailable(requireContext()) || screenType == UpiPluginAction.NETWORK_ERROR) {
            when (screenType) {
                UpiPluginAction.BANK_SELECTION_DONE -> {
                    hideBottomSheet()
                    val bank = result as PayUBankData
                    val map = HashMap<String, Any>().apply {
                        this[CLConstant.PAYU_CT_BANK_NAME] = bank.bankName
                        this[CLConstant.PAYU_CT_BANK_IIN] = bank.iin
                    }
                    logCTAEvent(
                        CLConstant.PAYU_CT_BANK_SELECTION,
                        ctScreenName ?: "",
                        map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                    )
                    manageAccountViewModel.fetchAccountsIin(bank, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT, PayUUpiConstant.ACCOUNT_LIST_REQUEST_TYPE_ADD_ACCOUNT)
                }

                UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION -> {
                    manageAccountViewModel.openDeleteAccountConfirmationScreen(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.DELETE_ACCOUNT -> {
                    hideBottomSheet()
                    deleteAccountForManagementJourney(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.CHECK_BALANCE -> {
                    showLoader()
                    manageAccountViewModel.checkBalance(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.CHANGE_PIN -> {
                    showLoader()
                    manageAccountViewModel.changeMpin(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.M_PIN_SETUP_STATUS -> {
                    val model = result as SetMpinModel
                    if (model.isPinSet) {
                        hideBottomSheet()

                        manageAccountViewModel.fetchLinkedAccounts()
                    } else {
                        getCommonViewModel()?.hideSetMPinBSLoader()
                        if (model.isUserCancelled.not()) {
                            manageAccountViewModel.showActivateAccountError(model.errorMessage ?: "")
                        }
                    }
                }

                UpiPluginAction.M_PIN_SETUP -> {
                    manageAccountViewModel.openPinSetScreen(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.LINKED_ACCOUNT -> {
                    manageAccountViewModel.fetchLinkedAccounts()
                }

                UpiPluginAction.BANK_SELECTION -> {
                    manageAccountViewModel.addBankAccount()
                }

                UpiPluginAction.MANAGE_ACCOUNT -> {
                    (result as? PayUCustomerBankAccounts?)?.let {
                        manageAccountViewModel.showManagementScreen(it)
                    } ?: BottomSheetStackManager.popBackStack()
                }

                UpiPluginAction.UPDATE_VPA_DONE -> {
                    hideBottomSheet()
                    manageAccountViewModel.fetchLinkedAccounts()
                }

                UpiPluginAction.GENERIC_INFO,
                UpiPluginAction.NETWORK_ERROR,
                UpiPluginAction.DELETE_ACCOUNT_CANCEL -> {
                    hideBottomSheet()
                }

                UpiPluginAction.UPDATE_VPA_CONFIRM -> {
                    manageAccountViewModel.updateVpa(result as PayUAccountDetail, isManualCreation = true)
                }

                UpiPluginAction.ADD_ACCOUNT_SELECTION -> {

                    if (isAccountExist(
                            manageAccountViewModel.getLinkedAccounts(),
                            (result as? PayUCustomerBankAccounts)
                        )
                    ) {
                        hideBottomSheet()
                        Toast.makeText(requireContext(), getString(R.string.account_already_added), Toast.LENGTH_LONG)
                            .show()
                    } else
                        manageAccountViewModel.addAccount(result as PayUCustomerBankAccounts)
                }

                else -> super.onClick(screenType, result)
            }
        } else {
            manageAccountViewModel.showNetworkErrorBtSheet()
        }
    }

    override fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean
    ) {
        manageAccountViewModel.sendMerchantCallback(response, isSuccess, isUserCancelled)
    }

    override fun closeCurrentFragment(bottomSheet: FixedRoundedCornerBottomSheet?) {
        PayUAndroidUtils.removeFragment(requireActivity(), this)
        if (getCommonViewModel()?.getIsNavigationEnforced() == false) {
            showManageOptions()
        }
    }

    override fun callCancelTransactionApi() {
        manageAccountViewModel.callCancelTransactionApi()
    }

    private fun logCTMoreOptionClicked(account: PayUCustomerBankAccounts) {
        val map = HashMap<String, Any>().apply {
            account.bankAccounts.accountNo?.let {
                this[CLConstant.PAYU_CT_ACCOUNT] = it
            }
        }
        logCTAEvent(
            CLConstant.PAYU_CT_MORE_BUTTON,
            ctScreenName ?: "",
            map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
        manageAccountViewModel.logVpaStatus(account)
        manageAccountViewModel.logMpinStatus(account)
    }

    private fun logAddAccountEvent() {
        PayUUtils.logKibanaEvents(
            requireContext(), CLConstant.PAYU_CT_CTA_CLICKED,
            JSONObject().apply {
                put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT)
                put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_ADD_BANKS)
            }.toString(),
            screenName = ctScreenName ?: "",
            name = CLConstant.PAYU_CT_ADD_BANKS
        )
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(), CLConstant.PAYU_CT_ADD_BANKS,
            CLConstant.PAYU_EVENT_TYPE_MANAGEMENT, screenName = ctScreenName
        )
    }

    private fun isAccountExist(
        accountList: ArrayList<PayUCustomerBankAccounts>?,
        account: PayUCustomerBankAccounts?
    ): Boolean {
        val selectedBankAccount = account?.bankAccounts
        return accountList?.any { accounts ->
            val listAccount = accounts.bankAccounts
            listAccount.accRefNumber == selectedBankAccount?.accRefNumber &&
                    listAccount.iin == selectedBankAccount.iin
        } ?: false

    }
}
