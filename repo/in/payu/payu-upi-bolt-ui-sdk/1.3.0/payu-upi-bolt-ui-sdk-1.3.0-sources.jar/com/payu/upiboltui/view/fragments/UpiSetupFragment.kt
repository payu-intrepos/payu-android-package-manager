package com.payu.upiboltui.view.fragments

import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant.PAYU_CLICK_ACTION
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.KibanaDataInfo
import com.payu.upiboltui.model.SetMpinModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrlAsync
import com.payu.upiboltui.utils.PayUUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import com.payu.upiboltui.utils.PaymentManager
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.BankSelectionAdapter
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.UpiSetupViewModel
import org.json.JSONObject


internal class UpiSetupFragment : BaseFragment(), BankSelectionAdapter.AccountListener {

    // Coroutine scope for image loading - will be cancelled when fragment view is destroyed
    private var imageLoadingScope: CoroutineScope? = null

    private var tvMobileNumberVerification: TextView? = null
    private var ivBankAccountSelection: ImageView? = null
    private var tvBankAccountSelection: TextView? = null
    private var ivUpiPinSetup: ImageView? = null
    private var tvUpiPinSetup: TextView? = null
    private var rvBankSelection: RecyclerView? = null
    private var tvBankNumber: TextView? = null
    private var ivStatus: ImageView? = null
    private var tvVpa: TextView? = null
    private var accountDetailsLayout: ConstraintLayout? = null
    private var setupButtonLayout: ConstraintLayout? = null
    private var payButtonLayout: ConstraintLayout? = null
    private var tvUpiPinNote: TextView? = null
    private var tvUpiPinText: TextView? = null
    private var accountProgressBar: ProgressBar? = null
    private var setupButton: TextView? = null
    private var payButton: TextView? = null
    private var cpbProgressBarBtn: ProgressBar? = null
    private var retryProgressBar: ProgressBar? = null
    private var accountLayout: ConstraintLayout? = null
    private var ivBackIcon: ImageView? = null
    private var bankLogo: ImageView? = null
    private var changeBankTv: TextView? = null
    private var tvBackPressMsg: TextView? = null
    private lateinit var upiSetupViewModel: UpiSetupViewModel
    private var selectedAccountIndex = 0
    private var tvUpiTpvError: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        ctScreenName = CLConstant.PAYU_CT_SCREEN_SETUP_UPI_SCREEN
        return inflater.inflate(R.layout.fragment_upi_setup_screen, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Initialize coroutine scope for image loading
        imageLoadingScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
        initViewModel()
        arguments?.getParcelable<PayUBankData>(PayUUPIBoltUiConstant.BANK_DATA)?.let {
            upiSetupViewModel.setBankData(it)
        }
        initUi(view)
        registerObserver()
        showBankAccountSelectionScreen()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Cancel image loading scope when view is destroyed to prevent memory leaks
        imageLoadingScope?.cancel()
        imageLoadingScope = null
    }


    private fun initUi(view: View) {
        accountLayout = view.findViewById(R.id.account_layout)
        tvMobileNumberVerification = view.findViewById(R.id.tvMobileNumberVerification)
        ivBankAccountSelection = view.findViewById(R.id.ivBankAccountSelection)
        tvBankAccountSelection = view.findViewById(R.id.tvBankAccountSelection)
        ivUpiPinSetup = view.findViewById(R.id.ivUpiPinSetup)
        tvUpiPinSetup = view.findViewById(R.id.tvUpiPinSetup)
        rvBankSelection = view.findViewById(R.id.rvAccountSelection)
        setupButtonLayout = view.findViewById(R.id.btnUpiSetup)
        payButtonLayout = view.findViewById(R.id.payuUpiPinButton)
        tvUpiPinNote = view.findViewById(R.id.tvUpiPinNote)
        tvUpiPinText = view.findViewById(R.id.tvUpiPinText)
        accountProgressBar = view.findViewById(R.id.accountProgressBar)
        accountDetailsLayout = view.findViewById(R.id.account_details)
        ivStatus = accountDetailsLayout?.findViewById(R.id.ivStatus)
        tvBankNumber = accountDetailsLayout?.findViewById(R.id.tvBankNumber)
        tvVpa = accountDetailsLayout?.findViewById(R.id.tvVpa)
        setupButton = setupButtonLayout?.findViewById(R.id.payuButton)
        payButton = payButtonLayout?.findViewById(R.id.payuButton)
        cpbProgressBarBtn = payButtonLayout?.findViewById(R.id.cpbProgressBarBtn)
        retryProgressBar = setupButtonLayout?.findViewById(R.id.cpbProgressBarBtn)
        bankLogo = accountDetailsLayout?.findViewById(R.id.ivBankLogo)
        ivBackIcon = view.findViewById(R.id.ivBackIcon)
        changeBankTv = view.findViewById(R.id.change_bank)
        tvBackPressMsg = view.findViewById(R.id.tvBackPressMsg)
        tvUpiTpvError = view.findViewById(R.id.tvUpiTpvError)
        BottomSheetFooter(view)
        changeBankTv?.run {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setAvoidMultiClickListener {
                logChangeBankEvent()
                tvUpiTpvError?.visibility = View.GONE
                upiSetupViewModel.fetchBankList(true)
            }
        }
        ivBackIcon?.setAvoidMultiClickListener {
            activity?.onBackPressed()
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(bankData: PayUBankData?): UpiSetupFragment {
            return UpiSetupFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(PayUUPIBoltUiConstant.BANK_DATA, bankData)
                }
            }
        }
    }

    private fun showBankAccountSelectionScreen() {
        var mobileToDisplay = InternalConfig.config?.getPhone()
        if (mobileToDisplay != null) {
            mobileToDisplay = PayUUtils.getDisplayMobileNumber(mobileToDisplay)
        }
        tvMobileNumberVerification?.text =
            getString(R.string.payu_has_been_verified, mobileToDisplay)
        val kibanaDataInfo = KibanaDataInfo(
            PayUUpiConstant.PAYU_SET_UPI,
            getString(R.string.payu_has_been_verified, mobileToDisplay)
        )
        upiSetupViewModel.logKibanaData(kibanaDataInfo)
        showFetchAccountText(getString(R.string.fetching_your_bank_account), true)
        accountDetailsLayout?.isVisible = false
        rvBankSelection?.isVisible = false
        hideSetupButton()
        hidePayButton()
        setPinTextAndImage(getString(R.string.payu_set_your_upi_pin), R.drawable.upi_setup_logo)
        setNotesVisibility(false)
        changeBankTv?.isVisible = false
        upiSetupViewModel.fetchAccountsIin()
    }

    private fun showFetchAccountText(text: String, showLoader: Boolean) {
        ivBankAccountSelection?.setImageResource(R.drawable.payu_bank_default_round)
        accountProgressBar?.isVisible = showLoader
        tvBankAccountSelection?.text = text
    }

    private fun setAccountFetchSuccess(text: String) {
        ivBankAccountSelection?.setImageResource(R.drawable.payu_checked)
        accountProgressBar?.isVisible = false
        tvBankAccountSelection?.text = text
    }

    private fun setAccountFetchFailure() {
        ivBankAccountSelection?.setImageResource(R.drawable.payu_deregister_error_icon)
        accountProgressBar?.isVisible = false
        tvBankAccountSelection?.text = getString(
            R.string.payu_account_fetch_error_message,
            upiSetupViewModel.getBankData()?.bankName
        )
        rvBankSelection?.isVisible = false
        accountDetailsLayout?.isVisible = false
        setPinTextAndImage(getString(R.string.payu_set_your_upi_pin), R.drawable.upi_setup_logo)
        hidePayButton()
        setNotesVisibility(false)
    }

    private fun setNotesVisibility(isVisible: Boolean) {
        tvUpiPinText?.isVisible = isVisible
        tvUpiPinNote?.isVisible = isVisible
    }

    private fun setAccountData(accountData: PayUAccountDetail?, showAccountChangeOption: Boolean) {
        tvBankAccountSelection?.text = getString(R.string.bank_account_upi_id_set)
        accountDetailsLayout?.isVisible = true
        tvBankNumber?.text = String.format(
            "%s %s",
            upiSetupViewModel.getBankData()?.bankName,
            accountData?.accountNo?.formatAccountNumber()
        )
        tvVpa?.text = getString(R.string.payu_bolt_upi_id, accountData?.vpa)
        ivStatus?.isVisible = false
        if (showAccountChangeOption) {
            ivStatus?.isVisible = true
            ivStatus?.setImageResource(R.drawable.payu_edit_icon)
        }
        ivStatus?.setAvoidMultiClickListener {
            accountDetailsLayout?.isVisible = false
            upiSetupViewModel.getAccountList()?.let {
                logCTAEvent(
                    CLConstant.PAYU_CT_ACCOUNT_CHANGE,
                    ctScreenName ?: "",
                    type = InternalConfig.ctFlowType
                )
                updateBankAccountSelectionScreen(it)
            }
        }

        // Load image asynchronously without blocking the UI thread
        bankLogo?.let { imageView ->
            val logoUrl = upiSetupViewModel.getBankData()?.logo
            imageLoadingScope?.let { scope ->
                imageView.loadImageUrlAsync(
                    url = logoUrl,
                    placeholder = R.drawable.payu_netbanking,
                    scope = scope
                )
            }
        }
    }

    private fun showSetupButton(text: String, onClickListener: () -> Unit) {
        setupButtonLayout?.isVisible = true
        hideSetupButtonLoader(text)
        setupButton?.setAvoidMultiClickListener {
            onClickListener.invoke()
        }
    }

    private fun hideSetupButton() {
        setupButtonLayout?.isVisible = false
    }

    private fun setPINAndButtonText(account: PayUCustomerBankAccounts) {
        account.bankAccounts.ifsc =
            account.bankAccounts.ifsc.ifEmpty {
                upiSetupViewModel.getBankData()?.ifsc.orEmpty()
            }
        val isTpvAccount = upiSetupViewModel.isTpvAccount(account)
        if (account.bankAccounts.vpa.isNullOrEmpty().not()) {
            if (account.bankAccounts.mbeba.equals(PayUUPIBoltUiConstant.MBEBA_Y)) {
                upiPinExistsScreen(isTpvAccount)
            } else {
                upiPinSetScreen(isTpvAccount)
            }
            upiSetupViewModel.logMpinStatus(account)
        } else {
            hidePayButton()
            setPinTextAndImage(getString(R.string.payu_set_your_upi_pin), R.drawable.upi_setup_logo)
        }
    }

    private fun showPayButton(text: String, onClickListener: () -> Unit) {
        payButtonLayout?.isVisible = true
        payButton?.isVisible = true
        payButton?.setAvoidMultiClickListener {
            payButtonLayout?.isEnabled = false
            payButton?.isEnabled = false
            onClickListener.invoke()
        }
        hidePayButtonLoader(text)
    }

    private fun showSetupButtonLoader() {
        setupButton?.text = ""
        retryProgressBar?.isVisible = true
        setupButtonLayout?.isClickable = false
        setupButton?.isClickable = false
    }

    private fun hideSetupButtonLoader(text: String) {
        setupButton?.text = text
        retryProgressBar?.isVisible = false
        setupButtonLayout?.isClickable = true
        setupButton?.isClickable = true
    }

    private fun showPayButtonLoader() {
        payButton?.text = ""
        cpbProgressBarBtn?.isVisible = true
        payButtonLayout?.isClickable = false
    }

    private fun hidePayButtonLoader(buttonText: String) {
        payButton?.text = buttonText
        cpbProgressBarBtn?.isVisible = false
        payButtonLayout?.isClickable = true
    }

    private fun hidePayButton() {
        payButtonLayout?.isVisible = false
    }

    private fun setPinTextAndImage(text: String, @DrawableRes imgRes: Int) {
        tvUpiPinSetup?.text = text
        ivUpiPinSetup?.setImageResource(imgRes)
    }

    private fun setAccountDetails(
        account: PayUCustomerBankAccounts,
        title: String,
        showAccountChangeOption: Boolean = false
    ) {
        rvBankSelection?.isVisible = false
        upiSetupViewModel.setCurrentAccount(account)
        setAccountFetchSuccess(title)
        if (account.bankAccounts.vpa.isNullOrEmpty()) {
            showSetupButton(getString(R.string.set_upi_id)) {
                logSetUPIIDEvent(account)
                upiSetupViewModel.createVpa(account, isManualCreation = false)
            }
        } else {
            setAccountData(account.bankAccounts, showAccountChangeOption)
            hideSetupButton()
        }
        upiSetupViewModel.logVpaStatus(account)
        setCTAnalyticsLogs(account)
        setPINAndButtonText(account)
    }

    private fun setCTAnalyticsLogs(account: PayUCustomerBankAccounts) {
        val eventData: HashMap<String, Any> = HashMap()
        eventData[CLConstant.PAYU_CT_BANK_IIN] = account.bankAccounts.iin
        eventData[CLConstant.PAYU_CT_ACCOUNT_NUMBER] = account.bankAccounts.accountNo

        logCTAEvent(
            CLConstant.PAYU_CT_ACCOUNT_SELECTED, ctScreenName ?: "",
            eventData, InternalConfig.ctFlowType
        )
    }

    private fun updateBankAccountSelectionScreen(accountList: List<PayUCustomerBankAccounts>) {
        if (accountList.isNotEmpty()) {
            val account = accountList[0]
            //          account.bankAccounts.mbeba = "N" // for testing pin set
            //            account.bankAccounts.vpa = "" // for testing set vpa

            if (accountList.size > 1) {
                setNotesVisibility(false)
                setupBankSelectionRV(accountList)
                showFetchAccountText(getString(R.string.select_bank_account_and_upi_id), false)
                onItemSelected(account, if (selectedAccountIndex < accountList.size) selectedAccountIndex else 0)
            } else {
                setAccountDetails(
                    account, getString(
                        R.string.bank_account_has_been_linked,
                        account.bankName,
                        account.bankAccounts.accountNo.formatAccountNumber()
                    )
                )
            }
            changeBankTv?.isVisible = true
        } else {
            setAccountFetchFailure()
            showSetupButton(getString(R.string.payu_retry_change_bank)) {
                logChangeBankEvent()
                upiSetupViewModel.fetchBankList()
            }
            changeBankTv?.isVisible = false
        }
    }

    private fun setupBankSelectionRV(accountList: List<PayUCustomerBankAccounts>) {
        rvBankSelection?.isVisible = true
        rvBankSelection?.adapter?.let {
            (it as BankSelectionAdapter).updateData(
                accountList, upiSetupViewModel.getBankData()?.bankName ?: "",
                upiSetupViewModel.getBankData()?.logo ?: ""
            )
        } ?: kotlin.run {
            rvBankSelection?.layoutManager =
                LinearLayoutManager(context, RecyclerView.VERTICAL, false)
            val bankSelectionAdapter = BankSelectionAdapter(
                accountList,
                this,
                selectedAccountIndex,
                upiSetupViewModel.getBankData()?.logo ?: "",
                upiSetupViewModel.getBankData()?.bankName ?: ""
            )
            rvBankSelection?.adapter = bankSelectionAdapter
        }
    }

    private fun upiPinExistsScreen(isTpvAccount: Boolean? = false) {
        setNotesVisibility(true)
        setPinTextAndImage(getString(R.string.upi_pin_already_set), R.drawable.payu_checked)
        showPayButton(
            "${getString(R.string.payu_continue_to_pay)} ${
                getString(
                    R.string.payu_rupees_symbol,
                    PayUUtils.formatAmount(InternalConfig.paymentParams?.amount)
                )
            }"
        ) {
            val kibanaDataInfo =
                KibanaDataInfo(
                    CLConstant.PAYU_CT_CTA_CLICKED,
                    JSONObject().apply {
                        put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_PAY)
                        put(
                            CLConstant.PAYU_CT_ACCOUNT,
                            upiSetupViewModel.getSelectedAccount()?.bankAccounts?.accountNo
                        )
                        put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
                    }.toString(),
                    screenName = ctScreenName,
                    name = CLConstant.PAYU_CT_PAY
                )
            upiSetupViewModel.logKibanaData(kibanaDataInfo)
            AnalyticsUtils.logClevertapCTAClickedEvent(
                requireContext(),
                CLConstant.PAYU_CT_PAY,
                InternalConfig.ctFlowType,
                screenName = ctScreenName ?: ""
            )
            upiSetupViewModel.logUserRegisteredEvent(CLConstant.PAYU_CT_STATUS_REGISTERED)
            upiSetupViewModel.makePayment()
        }
        showTpvError(isTpvAccount)
        upiSetupViewModel.setPayButtonVisible(true)
    }

    private fun upiPinSetScreen(isTpvAccount: Boolean? = false) {
        setPinTextAndImage(getString(R.string.payu_set_your_upi_pin), R.drawable.upi_setup_logo)
        setNotesVisibility(false)
        showPayButton(getString(R.string.payu_continue)) {
            val map = HashMap<String, Any>().apply {
                upiSetupViewModel.getSelectedAccount()?.let {
                    put(CLConstant.PAYU_CT_ACCOUNT, it)
                }
            }
            logCTAEvent(
                CLConstant.PAYU_CT_SET_MPIN,
                ctScreenName ?: "",
                map, InternalConfig.ctFlowType
            )
            upiSetupViewModel.openPinSetScreen()
        }
        showTpvError(isTpvAccount)
    }

    private fun initViewModel() {
        upiSetupViewModel = ViewModelProvider(
            this,
            BaseViewModelFactory(
                requireActivity().application,
                PaymentManager()
            )
        )[UpiSetupViewModel::class.java]
    }

    private fun registerObserver() {
        upiSetupViewModel.accountsListLiveData.observe(viewLifecycleOwner) {
            it?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {}

                    is NetworkResponse.Success -> {
                        hideBottomSheet()
                        updateBankAccountSelectionScreen(response.data)
                    }

                    is NetworkResponse.Failure -> {
                        hideBottomSheet()
                        setAccountFetchFailure()
                        showSetupButton(getString(R.string.payu_retry_change_bank)) {
                            logChangeBankEvent()
                            upiSetupViewModel.fetchBankList()
                        }
                        changeBankTv?.isVisible = false
                    }

                    else -> {}
                }
            }
        }

        upiSetupViewModel.showBottomSheetLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { sheetInfo ->
                showBottomSheet(sheetInfo)
            }
        }

        upiSetupViewModel.flowCompleteLiveData.observe(viewLifecycleOwner) {
            PayUAndroidUtils.removeFragment(requireActivity(), this)
        }

        upiSetupViewModel.banksListLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { response ->
                when (response) {
                    is NetworkResponse.Loading -> {
                        showLoader()
                    }

                    is NetworkResponse.Success -> {
                        // using handler as temporary fix for handling load time in showing banks list
                        Handler(Looper.getMainLooper()).postDelayed({
                            hideLoader()
                            if (changeBankTv?.isVisible == false) {
                                showSetupButton(getString(R.string.payu_retry_change_bank)) {
                                    logChangeBankEvent()
                                    upiSetupViewModel.fetchBankList()
                                }
                            }
                        }, 1000)
                        upiSetupViewModel.showBanksListScreen(
                            response.data as ArrayList<PayUBankData>,
                            ctFlowType = InternalConfig.ctFlowType
                        )
                    }

                    is NetworkResponse.Failure -> {
                        hideLoader()
                        BottomSheetStackManager.popBackStack()
                    }

                    else -> {}
                }
            }
        }
        upiSetupViewModel.vpaLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let { response ->
                getCommonViewModel()?.setUpdateVpaState(response)
                when (response) {
                    is NetworkResponse.Success -> {
                        (response.data as? List<PayUCustomerBankAccounts>?)?.let { resp ->
                            val account =
                                upiSetupViewModel.findAccountByAccRefNum(resp[0].bankAccounts.accRefNumber)
                            account?.let {
                                it.bankAccounts.vpa = resp[0].bankAccounts.vpa
                            }
                            upiSetupViewModel.getAccountList()?.let {
                                updateBankAccountSelectionScreen(it)
                            }
                        }
                    }
                    is NetworkResponse.Failure -> {
                        hideSetupButtonLoader(getString(R.string.set_upi_id))
                    }
                    is NetworkResponse.Loading -> {
                        showSetupButtonLoader()
                    }
                    else -> {}
                }
            }
        }
        upiSetupViewModel.logKibanaDataLiveData.observe(viewLifecycleOwner) { event ->
            event.getContentIfNotHandled()?.let {
                PayUUtils.logKibanaEvents(
                    requireContext(), it.eventKey, it.eventData,
                    eventType = AnalyticsUtils.EventType.Info,
                    eventSeverity = it.eventSeverity,
                    screenName = it.screenName,
                    status = it.status,
                    code = it.code,
                    name = it.name
                )
            }
        }

        upiSetupViewModel.hideBottomSheet.observe(viewLifecycleOwner) {
            hideBottomSheet(it)
        }

        upiSetupViewModel.showPayLoaderLiveData.observe(viewLifecycleOwner) { event ->
            event?.getContentIfNotHandled()?.let { showLoader ->
                if (showLoader) {
                    showPayButtonLoader()
                } else {
                    hidePayButtonLoader(
                        "${getString(R.string.payu_continue_to_pay)} ${
                            getString(
                                R.string.payu_rupees_symbol,
                                PayUUtils.formatAmount(InternalConfig.paymentParams?.amount)
                            )
                        }"
                    )
                }
            }
        }
    }


    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        if (PayUAndroidUtils.isInternetAvailable(requireContext())
            || screenType == UpiPluginAction.NETWORK_ERROR
            || screenType == UpiPluginAction.CANCEL_CONFIRMATION
            || screenType == UpiPluginAction.CANCEL_CONFIRMATION_DONE
        ) {
            PayUUtils.logKibanaEvents(
                requireContext(), eventKey = PAYU_CLICK_ACTION, eventData = "" + screenType?.name,
                eventType = AnalyticsUtils.EventType.Info
            )
            when (screenType) {
                UpiPluginAction.UPDATE_VPA_DONE -> {
                    val kibanaDataInfo =
                        KibanaDataInfo(
                            PayUUpiConstant.PAYU_SET_UPI_ID,
                            PayUUpiConstant.UPDATE_VPA_DONE
                        )
                    upiSetupViewModel.logKibanaData(kibanaDataInfo)
                    hideBottomSheet()
                    showBankAccountSelectionScreen()
                }

                UpiPluginAction.UPDATE_VPA_CONFIRM -> {
                    upiSetupViewModel.updateVpa(
                        result as PayUAccountDetail,
                        isManualCreation = true
                    )
                }

                UpiPluginAction.M_PIN_SETUP_STATUS -> {
                    val model = result as SetMpinModel
                    if (model.isPinSet) {
                        hideBottomSheet()
                        val account =
                            upiSetupViewModel.findAccountByAccRefNum(model.account.bankAccounts.accRefNumber)
                        account?.let {
                            it.bankAccounts.mbeba = model.account.bankAccounts.mbeba
                            if (it.bankAccounts.formatType.isEmpty()
                                && model.account.bankAccounts.formatType.isEmpty().not()) {
                                it.bankAccounts.formatType = model.account.bankAccounts.formatType
                            }
                        }
                        upiSetupViewModel.getAccountList()?.let {
                            updateBankAccountSelectionScreen(it)
                        }
                    } else {
                        getCommonViewModel()?.hideSetMPinBSLoader()
                        if (model.isUserCancelled.not()) {
                            upiSetupViewModel.showActivateAccountError(model.errorMessage ?: "")
                        }
                    }
                }

                UpiPluginAction.M_PIN_SETUP -> {
                    upiSetupViewModel.openPinSetScreen()
                }

                UpiPluginAction.BANK_SELECTION_DONE -> {
                    hideBottomSheet()
                    (result as? PayUBankData)?.let {
                        val map = HashMap<String, Any>().apply {
                            this[CLConstant.PAYU_CT_BANK_NAME] = it.bankName
                            this[CLConstant.PAYU_CT_BANK_IIN] = it.iin
                        }
                        logCTAEvent(
                            CLConstant.PAYU_CT_BANK_SELECTION,
                            ctScreenName ?: "",
                            map, InternalConfig.ctFlowType
                        )
                        upiSetupViewModel.setBankData(it)
                    }
                    showBankAccountSelectionScreen()
                }

                UpiPluginAction.FETCH_ACCOUNTS_IIN -> {
                    showBankAccountSelectionScreen()
                }

                else -> super.onClick(screenType, result)
            }
        } else {
            screenType?.let { upiSetupViewModel.showNetworkErrorBtSheet() }
        }
    }

    override fun sendMerchantCallback(
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean
    ) {
        upiSetupViewModel.sendMerchantCallback(response, isSuccess, isUserCancelled)
    }

    override fun onItemSelected(account: PayUCustomerBankAccounts, index: Int) {
        selectedAccountIndex = index
        upiSetupViewModel.setCurrentAccount(account)
        setCTAnalyticsLogs(account)
        if (account.bankAccounts.vpa.isNullOrEmpty()) {
            showSetupButton(getString(R.string.set_upi_id)) {
                logSetUPIIDEvent(account)
                upiSetupViewModel.createVpa(account, isManualCreation = false)
            }
        } else {
            showSetupButton(getString(R.string.payu_continue)) {
                setAccountDetails(account, getString(R.string.payu_account_and_vpa_set), true)
            }
        }
        hidePayButton()
        setPinTextAndImage(getString(R.string.payu_set_your_upi_pin), R.drawable.upi_setup_logo)
    }

    override fun closeCurrentFragment(bottomSheet: FixedRoundedCornerBottomSheet?) {
        upiSetupViewModel.showCancelConfirmationScreen(InternalConfig.ctFlowType, bottomSheet)
    }

    override fun callCancelTransactionApi() {
        upiSetupViewModel.callCancelTransactionApi()
    }

    private fun logSetUPIIDEvent(account: PayUCustomerBankAccounts) {
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_CT_ACCOUNT] = account.bankAccounts.accountNo
        }
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(), CLConstant.PAYU_CT_SET_UPI_ID,
            InternalConfig.ctFlowType, map, screenName = ctScreenName
        )
        val kibanaDataInfo =
            KibanaDataInfo(
                eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                eventData = JSONObject().apply {
                    put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_SET_UPI_ID)
                    put(CLConstant.PAYU_CT_ACCOUNT, account.bankAccounts.accountNo)
                    put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
                }.toString(),
                screenName = ctScreenName,
                name = CLConstant.PAYU_CT_SET_UPI_ID
            )
        upiSetupViewModel.logKibanaData(kibanaDataInfo)
    }

    private fun logChangeBankEvent() {
        val kibanaDataInfo =
            KibanaDataInfo(
                eventKey = CLConstant.PAYU_CT_CTA_CLICKED,
                eventData = JSONObject().apply {
                    put(CLConstant.PAYU_CT_NAME, CLConstant.PAYU_CT_CHANGE_BANK)
                    put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
                }.toString(),
                screenName = ctScreenName,
                name = CLConstant.PAYU_CT_CHANGE_BANK
            )
        upiSetupViewModel.logKibanaData(kibanaDataInfo)
        AnalyticsUtils.logClevertapCTAClickedEvent(
            requireContext(),
            CLConstant.PAYU_CT_CHANGE_BANK,
            InternalConfig.ctFlowType, screenName = ctScreenName
        )
    }

    private fun showTpvError(isTpvAccount: Boolean?) {
        if (InternalConfig.paymentParams?.beneficiaryDetails.isNullOrEmpty()
                .not() && isTpvAccount == false
        ) {
            tvUpiTpvError?.visibility = View.VISIBLE
            payButton?.isEnabled = false
            payButtonLayout?.alpha = 0.7f
        } else {
            tvUpiTpvError?.visibility = View.GONE
            payButton?.isEnabled = true
            payButtonLayout?.alpha = 1f
        }
    }
}