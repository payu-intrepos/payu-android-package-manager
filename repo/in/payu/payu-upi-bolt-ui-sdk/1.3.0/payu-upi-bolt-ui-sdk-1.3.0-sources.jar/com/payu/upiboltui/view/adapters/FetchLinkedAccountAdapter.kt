package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.IinLogoMap
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrlAsync
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.SharedPrefsUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel


class FetchLinkedAccountAdapter(
    var data: MutableList<LinkedAccountsUIModel>,
    val amount: String?,
    private val onItemClick: (bankAccount: LinkedAccountsUIModel) -> Unit,
    private val onItemExpand: (bankAccount: LinkedAccountsUIModel) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var currentPos = 0
    private var isLayoutClickable = true
    
    // Coroutine scope for image loading - uses SupervisorJob to prevent one failure from cancelling all
    private val imageLoadingScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.payu_linked_bank_accounts_item, parent, false)
        return LinkedAccountsViewHolder(view)
    }

    override fun onBindViewHolder(recyclerViewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = recyclerViewHolder as LinkedAccountsViewHolder
        val bankData = data
        val context = holder.itemView.context
        val account = bankData[holder.adapterPosition].account

        // Cancel any previous image loading job for this view holder to prevent memory leaks
        holder.imageLoadingJob?.cancel()
        holder.imageLoadingJob = null

        val url = SharedPrefsUtils.getBankLogoUrl(
            context,
            account.bankAccounts.iin ?: ""
        )

        val logoUrl =
            if (url.isNullOrEmpty() && IinLogoMap.containsKey(account.bankAccounts.iin))
                IinLogoMap[account.bankAccounts.iin]
            else
                url

        // Load image asynchronously without blocking the RecyclerView
        holder.imageLoadingJob = holder.ivBankLogo.loadImageUrlAsync(
            url = logoUrl,
            placeholder = R.drawable.payu_netbanking,
            scope = imageLoadingScope
        )

        holder.tvBankName.text = String.format(
            "%s - %s",
            account.bankName,
            account.bankAccounts.accountNo?.formatAccountNumber()
        )

        holder.tvAccountNumber.isVisible = account.bankAccounts.vpa.isNullOrEmpty().not()
        val isVpaSet = account.bankAccounts.vpa.isNullOrEmpty().not()
        if (isVpaSet) {
            holder.tvAccountNumber.text =
                context.getString(R.string.payu_bolt_upi_id, account.bankAccounts.vpa)
        }

        val isMpinSet = account.bankAccounts.mbeba.equals(PayUUPIBoltUiConstant.MBEBA_Y)
        holder.btnPay.text = if (isVpaSet.not()) {
            context.getString(R.string.set_upi_id)
        } else if (isMpinSet.not()) {
            context.getString(R.string.set_m_pin)
        } else {
            "${context.getString(R.string.payu_continue_to_pay)} ${
                context.getString(
                    R.string.payu_rupees_symbol,
                    PayUUtils.formatAmount(amount)
                )
            }"
        }

        holder.itemView.setAvoidMultiClickListener {
            if (currentPos != holder.adapterPosition) {
                val prev = currentPos
                currentPos = holder.adapterPosition
                notifyItemChanged(prev, false)
                notifyItemChanged(currentPos, true)
            }
        }
        setExpandedView(holder, currentPos == holder.adapterPosition, holder.adapterPosition)

        holder.btnPay.setAvoidMultiClickListener {
            onItemClick.invoke(bankData[holder.adapterPosition])
        }

        if (bankData[holder.adapterPosition].showProgressLoader) {
                holder.progressLoader.isVisible = true
                holder.btnPay.text = ""
                holder.btnPay.isEnabled = false
                holder.itemView.isClickable = false
        }
        holder.itemView.isClickable = isLayoutClickable
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isNotEmpty()) {
            if (payloads[0] is Boolean) {
                setExpandedView(
                    holder as LinkedAccountsViewHolder,
                    payloads[0] as Boolean, position
                )
            }
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        // Cancel image loading when view is recycled to prevent memory leaks
        (holder as? LinkedAccountsViewHolder)?.imageLoadingJob?.cancel()
        (holder as? LinkedAccountsViewHolder)?.imageLoadingJob = null
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        // Cancel the coroutine scope when adapter is detached to prevent memory leaks
        imageLoadingScope.cancel()
    }

    override fun getItemCount(): Int {
        return data.size
    }

    fun setViewCancelableOnLoading(isClickable: Boolean) {
        isLayoutClickable = isClickable
        notifyDataSetChanged()
    }

    fun updateBankAccount(bankAccount: LinkedAccountsUIModel) {
        val index = data.indexOf(bankAccount)
        data[index] = bankAccount
        notifyItemChanged(index)
    }

    private fun setExpandedView(
        holder: LinkedAccountsViewHolder,
        isExpanded: Boolean,
        position: Int
    ) {
        if (isExpanded) {
            holder.mainLayout.background =
                AppCompatResources.getDrawable(
                    holder.itemView.context, R.drawable.payu_rounded_corner_b7c8e5_with_stroke
                )
            holder.btnPayLayout.visibility = View.VISIBLE
            holder.ivRightArrow.isVisible = false
            if (data[position].isExpanded.not()) {
                onItemExpand.invoke(data[position])
                data[position].isExpanded = true
            }
        } else {
            holder.mainLayout.background = null
            holder.btnPayLayout.visibility = View.GONE
            holder.ivRightArrow.isVisible = true
            data[position].isExpanded = false
        }
    }

    inner class LinkedAccountsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvBankName: TextView = itemView.findViewById(R.id.tvBankName)
        var tvAccountNumber: TextView = itemView.findViewById(R.id.tvAccountNumber)
        var btnPayLayout: ConstraintLayout = itemView.findViewById(R.id.btnPay)
        var mainLayout: ConstraintLayout = itemView.findViewById(R.id.mainLayout)
        val btnPay: TextView = btnPayLayout.findViewById(R.id.payuButton)
        var ivBankLogo: ImageView = itemView.findViewById(R.id.ivBankLogo)
        var ivRightArrow: ImageView = itemView.findViewById(R.id.ivRightArrow)
        val progressLoader: ProgressBar = btnPayLayout.findViewById(R.id.cpbProgressBarBtn)
        
        // Track image loading job to cancel when view is recycled
        var imageLoadingJob: Job? = null
    }

}