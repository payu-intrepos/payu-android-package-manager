package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BsSubHeaderIvHandler
import com.payu.upiboltui.view.handler.BsSubmitButtonHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class DeleteAccountConfirmationBSFragment : BaseBottomSheetFragment() {
    private var data: PayUCustomerBankAccounts? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.getParcelable(DATA)
        }
    }

    private fun initViews(view: View) {
        BottomSheetFooter(view)
        val context = view.context
        val account = data as PayUCustomerBankAccounts
        val layoutPaymentInfo: ConstraintLayout = view.findViewById(R.id.layout_payment_info)
        val layoutSecurityInfo: ConstraintLayout = view.findViewById(R.id.layout_security_info)

        BottomSheetHeader(
            view,
            context.getString(R.string.payu_delete_account),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        val bsSubHeaderIvHandler = BsSubHeaderIvHandler()
        bsSubHeaderIvHandler.init(
            layoutPaymentInfo,
            null,
            context.getString(R.string.payu_delete_account_message)
        )
        val tvUpiSubHeader =
            layoutPaymentInfo.findViewById<TextView>(R.id.tvBankName)
        tvUpiSubHeader.textSize = 16f
        layoutSecurityInfo.visibility = View.GONE

        val payuBackButton = view.findViewById<TextView>(R.id.payuBackButton)
        payuBackButton.visibility = View.VISIBLE
        payuBackButton.text = context.getString(R.string.payu_cancel)
        payuBackButton.isAllCaps = true
        payuBackButton.background = null

        val bottomEmptyView = view.findViewById<View>(R.id.view2)
        bottomEmptyView.visibility = View.VISIBLE

        payuBackButton.setAvoidMultiClickListener {
            logCTAEvent(
                CLConstant.PAYU_CT_DELETE_ACCOUNT_CANCEL,
                CLConstant.PAYU_CT_SCREEN_DELETE_ACCOUNT,
                type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
            )
            upiFixedBottomSheetData?.upiBoltListener?.onClick(
                UpiPluginAction.DELETE_ACCOUNT_CANCEL,
                account
            )
        }

        val bsSubmitButtonHandler = BsSubmitButtonHandler()
        bsSubmitButtonHandler.init(
            view,
            payButtonText = context.getString(R.string.payu_confirm),
            upiBoltListener = upiFixedBottomSheetData?.upiBoltListener,
            screenType = UpiPluginAction.DELETE_ACCOUNT,
            result = account,
            onButtonClickListenerForLogs = {
                logCTAEvent(
                    CLConstant.PAYU_CT_DELETE_ACCOUNT_CONFIRM,
                    CLConstant.PAYU_CT_SCREEN_DELETE_ACCOUNT,
                    type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
            }
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {
        @JvmStatic
        fun newInstance(
            data: PayUCustomerBankAccounts,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            DeleteAccountConfirmationBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}