package com.payu.upiboltui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.constants.SharedPrefsConstants
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.model.PayUSimInfo
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.constants.payUEventScreenMap
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.KibanaDataInfo
import com.payu.upiboltui.model.ManagementScreenType
import com.payu.upiboltui.model.SetMpinModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PaymentManager
import com.payu.upiboltui.utils.SharedPrefsUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.fragments.LinkedUPIAccountsFragment
import com.payu.upiboltui.view.fragments.QueryListFragment
import com.payu.upiboltui.view.fragments.TransactionHistoryFragment
import com.payu.upiboltui.view.fragments.UpiSetupFragment
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import com.payu.upiboltui.viewmodel.BaseViewModelFactory
import com.payu.upiboltui.viewmodel.CommonViewModel
import com.payu.upiboltui.viewmodel.UpiFixedBottomSheetViewModel
import org.json.JSONObject

class UPIBoltUiHandler(private val activity: FragmentActivity) : PayUUPIBoltOnClickListener {

    private lateinit var upiFixedBottomSheetViewModel: UpiFixedBottomSheetViewModel
    private var commonViewModel: CommonViewModel? = null

    private var simSelectionAlertDialog: AlertDialog? = null

    init {
        initViewModel()
        registerObserver()
    }

    private fun registerObserver() {
        upiFixedBottomSheetViewModel.showBottomSheetLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let { info ->
                val upiFixedBottomSheetData =
                    UpiFixedBottomSheetData(
                        info.pluginAction,
                        upiBoltListener = this,
                        data = info.data, onClose = info.onUserCancel,
                        showExitConfirmation = info.showExitConfirmation,
                        layoutId = info.layout, tag = info.tag, isNewInstance = info.isNewInstance,
                        ctFlowType = info.ctFlowType
                    )

                val fragment = commonViewModel?.getFragment(
                    upiFixedBottomSheetData = upiFixedBottomSheetData
                )
                if (fragment != null) {
                    if (upiFixedBottomSheetData.isNewInstance)
                        BottomSheetStackManager.addBottomSheet(
                            activity,
                            fragment,
                            upiFixedBottomSheetData.tag ?: ""
                        )
                    else
                        BottomSheetStackManager.replace(
                            activity,
                            fragment,
                            upiFixedBottomSheetData.tag ?: ""
                        )
                }
            }
        }

        upiFixedBottomSheetViewModel.hideBottomSheet.observe(activity) {
            BottomSheetStackManager.popBackStack(it, true)
        }

        upiFixedBottomSheetViewModel.showSettingErrorLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                launchDeviceSettings()
            }
        }

        upiFixedBottomSheetViewModel.deregisterLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let { response ->
                when (response) {
                    is NetworkResponse.Success -> {
                        val payUUPIResponse = PayUUPIBoltResponse(
                            PayUResponseTypes.REQUEST_MANAGE,
                            response.data.code,
                            activity.getString(R.string.de_registration_success_message)
                        )
                        upiFixedBottomSheetViewModel.sendMerchantCallback(
                            payUUPIResponse,
                            isSuccess = true,
                            popBackStackUntil = UpiPluginAction.MANAGEMENT_OPTIONS.name
                        )
                        InternalConfig.clearNonInitParams()
                    }

                    else -> {}
                }
            }
        }

        upiFixedBottomSheetViewModel.requestPermissionLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                grantPerMission()
            }
        }

        upiFixedBottomSheetViewModel.logKibanaDataLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                PayUUtils.logKibanaEvents(
                    activity, it.eventKey, it.eventData,
                    eventType = AnalyticsUtils.EventType.Info,
                    eventSeverity = it.eventSeverity,
                    status = it.status,
                    code = it.code
                )
            }
        }

        upiFixedBottomSheetViewModel.hideDeregisterAccountLoaderLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                commonViewModel?.hideDeregisterAccountLoader()
            }
        }

        upiFixedBottomSheetViewModel.showFetchLinkedAccountsLoaderLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                commonViewModel?.setLoaderForFetchLinkedAccounts(it)
            }
        }

        upiFixedBottomSheetViewModel.showBankListLoaderLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                commonViewModel?.setLoaderForFetchBankList(it)
            }
        }

        upiFixedBottomSheetViewModel.showPayLoaderLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                commonViewModel?.setPayLoader(it)
            }
        }

        upiFixedBottomSheetViewModel.handleNavLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                onClick(it)
            }
        }

        upiFixedBottomSheetViewModel.vpaLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let {
                commonViewModel?.setUpdateVpaState(it)
            }
        }

        upiFixedBottomSheetViewModel.otpVerifyMsgLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let { msg ->
                commonViewModel?.showOtpListenStarted(msg)
            }
        }

        upiFixedBottomSheetViewModel.otpTimeoutLiveData.observe(activity) { event ->
            event.getContentIfNotHandled()?.let { timeout ->
                commonViewModel?.otpTimeout(timeout)
            }
        }
    }

    private fun launchDeviceSettings() {
        BottomSheetStackManager.popBackStack()
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        with(intent) {
            data = Uri.fromParts("package", activity.packageName, null)
            addCategory(Intent.CATEGORY_DEFAULT)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        logPermissionCTEvent(CLConstant.PAYU_CT_PERMISSION_SETTINGS)
        activity.startActivity(intent)
    }

    fun isUPIBoltAvailable(
        isTransactionFlow: Boolean = false,
        callback: (PayUUPIBoltResponse) -> Unit
    ) {
        AnalyticsUtils.setCTLogsForUPIWithData(activity, CLConstant.PAYU_CT_PG_DETAILS_METHOD_CALLED)
        upiFixedBottomSheetViewModel.isUpiBoltAvailable(isTransactionFlow, callback)
    }

    internal fun launchRegisterAndPay() {
        upiFixedBottomSheetViewModel.updateNextAction(UpiPluginAction.LINKED_ACCOUNT)
        InternalConfig.ctFlowType = upiFixedBottomSheetViewModel.getCTFlowType()
        PayUUtils.logKibanaEvents(
            activity, CLConstant.PAYU_CT_REGISTER_AND_PAY_CALLED,
            JSONObject().apply {
                put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
            }.toString()
        )
        AnalyticsUtils.setCTLogsForUPIWithData(activity, CLConstant.PAYU_CT_REGISTER_AND_PAY_CALLED)
        commonViewModel?.setIsNavigationEnforced(false)
        initHandshake(UpiPluginAction.LINKED_ACCOUNT)
    }

    private fun launchManagementOptions() {
        upiFixedBottomSheetViewModel.updateNextAction(UpiPluginAction.MANAGEMENT_OPTIONS)
        InternalConfig.ctFlowType = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        PayUUtils.logKibanaEvents(
            activity, CLConstant.PAYU_CT_MANAGEMENT_CALLED,
            JSONObject().apply {
                put(CLConstant.PAYU_EVENT_TYPE, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT)
            }.toString()
        )
        AnalyticsUtils.setCTLogsForUPIWithData(activity, CLConstant.PAYU_CT_MANAGEMENT_CALLED)
        commonViewModel?.setIsNavigationEnforced(false)
        initHandshake(UpiPluginAction.MANAGEMENT_OPTIONS)
    }

    internal fun launchManagementOptions(managementScreenType: ManagementScreenType) {
        val isRegistered = upiFixedBottomSheetViewModel.getRegisteredMobileNumber()
        val upiPluginAction =
            commonViewModel?.getUpiPluginActionForManagementScreenType(managementScreenType)
        upiPluginAction?.let {
            commonViewModel?.setIsNavigationEnforced(true)
            if (UpiPluginAction.MANAGEMENT_OPTIONS == upiPluginAction) {
                launchManagementOptions()
                return
            }
            if (upiPluginAction == UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CONFIRMATION && isRegistered.isNullOrEmpty()) {
                val error = PayUUPIBoltResponse(
                    responseType = PayUResponseTypes.REQUEST_MANAGE,
                    code = PayUResponseCodes.PAYU_INITIATE_PAY_FAILED,
                    message = PayUResponseMessages.PAYU_USER_IS_NOT_REGISTERED
                )
                InternalConfig.callback?.onPayUFailure(error)
                return
            }
            upiFixedBottomSheetViewModel.updateNextAction(upiPluginAction)
            initHandshake(upiPluginAction)
        }
    }

    internal fun showManageOptionsUI() {
        upiFixedBottomSheetViewModel.showManagementOptions()
    }

    private fun initHandshake(nextAction: UpiPluginAction) {
        val isRegistered = SharedPrefsUtils.getBooleanConfig(
            activity, SharedPrefsConstants.PAYU_IS_REGISTERED
        )
        if (isRegistered.not() && nextAction == UpiPluginAction.LINKED_ACCOUNT) { // Welcome screen should show only for registration flow
            upiFixedBottomSheetViewModel.updateSmsConsent(true)
            upiFixedBottomSheetViewModel.initUPISetUpScreen(
                UpiPluginAction.WELCOME_SCREEN_DONE, isNewInstance = true
            )
        } else {
            upiFixedBottomSheetViewModel.isUpiBoltAvailable {}
        }
    }

    private fun fetchBankList(isNewInstance: Boolean) {
        upiFixedBottomSheetViewModel.fetchBankList(isNewInstance)
    }

    internal fun deregisterAllAccountsConfirmation() {
        upiFixedBottomSheetViewModel.showDeregisterAllAccountsConfirmation()
    }

    private fun deregisterAllAccounts() {
        upiFixedBottomSheetViewModel.deregisterAllAccounts()
    }

    private fun initViewModel() {
        upiFixedBottomSheetViewModel = ViewModelProvider(
            activity,
            BaseViewModelFactory(
                activity.application,
                PaymentManager()
            )
        )[UpiFixedBottomSheetViewModel::class.java]

        commonViewModel = ViewModelProvider(
            activity,
            BaseViewModelFactory(
                activity.application,
            )
        )[CommonViewModel::class.java]
    }

    override fun onClick(screenType: UpiPluginAction?, result: Any?) {
        if (PayUAndroidUtils.isInternetAvailable(activity)
            || screenType == UpiPluginAction.NETWORK_ERROR
            || screenType == UpiPluginAction.CANCEL_CONFIRMATION) {

            when (screenType) {
                UpiPluginAction.WELCOME_SCREEN_DONE, UpiPluginAction.UPI_BOLT_AVAILABLE -> {
                    upiFixedBottomSheetViewModel.isUpiBoltAvailable(result as? Boolean ?: true) {}
                }

                UpiPluginAction.REQUEST_PERMISSION -> {
                    grantPerMission()
                }

                UpiPluginAction.MOBILE_VERIFICATION -> {
                    upiFixedBottomSheetViewModel.checkDeviceBindingStatus(result as PayUSimInfo)
                }

                UpiPluginAction.MANAGEMENT_OPTIONS -> {
                    upiFixedBottomSheetViewModel.showManagementOptions()
                }

                UpiPluginAction.LINKED_ACCOUNT -> {
                    upiFixedBottomSheetViewModel.fetchLinkedAccounts()
                }

                UpiPluginAction.UPDATE_VPA_DONE -> {
                    BottomSheetStackManager.popBackStack()
                    upiFixedBottomSheetViewModel.fetchLinkedAccounts()
                }

                UpiPluginAction.BANK_SELECTION, UpiPluginAction.BANK_LIST_ERROR_SCREEN -> {
                    fetchBankList((result as? Boolean) ?: true)
                }

                UpiPluginAction.BANK_SELECTION_DONE -> {
                    (result as? PayUBankData)?.let {
                        val map = HashMap<String, Any>().apply {
                            this[CLConstant.PAYU_CT_BANK_NAME] = it.bankName
                            this[CLConstant.PAYU_CT_BANK_IIN] = it.iin
                        }
                        logCTAEvent(
                            CLConstant.PAYU_CT_BANK_SELECTION,
                            CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS, map,
                            InternalConfig.ctFlowType
                        )
                    }
                    BottomSheetStackManager.popBackStack(UpiPluginAction.LINKED_ACCOUNT.name, true)
                    PayUAndroidUtils.replaceFragment(
                        activity, UpiSetupFragment.newInstance(result as? PayUBankData),
                        PayUUPIBoltUiConstant.ROOT_FRAGMENT
                    )
                }

                UpiPluginAction.PAY -> {
                    upiFixedBottomSheetViewModel.showVerifyPaymentScreen(CLConstant.PAYU_EVENT_TYPE_REPEAT)
                    upiFixedBottomSheetViewModel.makePayment(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS -> {
                    deregisterAllAccounts()
                }

                UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CONFIRMATION -> {
                    deregisterAllAccountsConfirmation()
                }

                UpiPluginAction.TRANSACTION_HISTORY -> {
                    BottomSheetStackManager.popBackStack()
                    PayUAndroidUtils.replaceFragment(
                        activity, TransactionHistoryFragment.newInstance(),
                        PayUUPIBoltUiConstant.ROOT_FRAGMENT
                    )
                }

                UpiPluginAction.MANAGE_ACCOUNT -> {
                    BottomSheetStackManager.popBackStack()
                    PayUAndroidUtils.replaceFragment(
                        activity, LinkedUPIAccountsFragment.newInstance(),
                        PayUUPIBoltUiConstant.ROOT_FRAGMENT
                    )
                }

                UpiPluginAction.RAISE_DISPUTE_LIST -> {
                    BottomSheetStackManager.popBackStack()
                    PayUAndroidUtils.replaceFragment(
                        activity, QueryListFragment.newInstance(),
                        PayUUPIBoltUiConstant.ROOT_FRAGMENT
                    )
                }

                UpiPluginAction.DEVICE_BINDING_FAILED -> {
                    val response = (result as? PayUUPIBoltResponse) ?: PayUUPIBoltResponse(
                        PayUResponseTypes.REQUEST_TRANSACTION,
                        PayUResponseCodes.PAYU_DEVICE_BINDING_FAILED,
                        PayUResponseMessages.PAYU_DEVICE_BINDING_FAILED_MESSAGE
                    )
                    upiFixedBottomSheetViewModel.sendMerchantCallback(response, false)
                }

                UpiPluginAction.DEVICE_BINDING_PROCEED -> {
                    PayUUPIBoltUI.getCoreInstance()?.clearData()
                    val simInfo = result as? PayUSimInfo
                    if (simInfo != null) {
                        upiFixedBottomSheetViewModel.prepareHandShakeData(simInfo, false)
                    } else {
                        upiFixedBottomSheetViewModel.sendMerchantCallback(
                            PayUUPIBoltResponse(
                                PayUResponseTypes.REQUEST_TRANSACTION,
                                PayUResponseCodes.PAYU_SIM_INFO_NOT_AVAILABLE,
                                PayUResponseMessages.PAYU_SIM_INFO_NOT_AVAILABLE_MESSAGE
                            ),
                            false
                        )
                    }
                }


                UpiPluginAction.M_PIN_SETUP -> {
                    upiFixedBottomSheetViewModel.openPinSetScreen(result as PayUCustomerBankAccounts)
                }

                UpiPluginAction.M_PIN_SETUP_STATUS -> {
                    val model = result as SetMpinModel
                    if (model.isPinSet) {
                        BottomSheetStackManager.popBackStack()
                        upiFixedBottomSheetViewModel.fetchLinkedAccounts()
                    } else {
                        commonViewModel?.hideSetMPinBSLoader()
                        if (model.isUserCancelled.not()) {
                            upiFixedBottomSheetViewModel.showActivateAccountError(model.errorMessage ?: "")
                        }
                    }
                }

                UpiPluginAction.UPDATE_VPA -> {
                    upiFixedBottomSheetViewModel.createVpa(result as PayUCustomerBankAccounts, isManualCreation = false)
                }

                UpiPluginAction.CANCEL_CONFIRMATION -> {
                    upiFixedBottomSheetViewModel.showCancelConfirmationScreen(
                        InternalConfig.ctFlowType,
                        result as? FixedRoundedCornerBottomSheet
                    )
                }

                UpiPluginAction.CANCEL_CONFIRMATION_DONE -> {
                    simSelectionAlertDialog?.cancel()
                    upiFixedBottomSheetViewModel.callCancelTransactionApi()
                }

                UpiPluginAction.NETWORK_ERROR,
                UpiPluginAction.GENERIC_INFO,
                UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS_CANCEL -> {
                    if(commonViewModel?.getIsNavigationEnforced() == true) {
                        BottomSheetStackManager.closeAllBottomSheets()
                        showManageOptionsUI()
                    } else {
                        BottomSheetStackManager.popBackStack()
                    }
                }

                UpiPluginAction.SIM_SELECTION -> {
                    val info = result as PayUSimInfo
                    val map = HashMap<String, Any>().apply {
                        this[CLConstant.PAYU_CT_SELECTED_SIM] =
                            PayUUtils.getMaskedMobileNumber(info.mobileNumber)
                    }
                    logCTAEvent(
                        CLConstant.PAYU_CT_SCREEN_SIM_SELECTION,
                        payUEventScreenMap[screenType], map
                    )
                    upiFixedBottomSheetViewModel.checkDeviceBindingStatus(info)
                }

                UpiPluginAction.UPDATE_VPA_CONFIRM -> {
                    upiFixedBottomSheetViewModel.updateVpa(result as PayUAccountDetail, isManualCreation = true)
                }

                UpiPluginAction.UPDATE_VPA_CONFIRM -> {
                    upiFixedBottomSheetViewModel.updateVpa(result as PayUAccountDetail)
                }

                else -> {}
            }
        } else {
            screenType?.let { upiFixedBottomSheetViewModel.showNetworkErrorBtSheet() }
        }
    }

    private fun grantPerMission() {
        activity.let { activity ->
            if (shouldShowSettingDialog()) {
                val bottomSheet = BottomSheetStackManager.peekBottomSheet()
                logPermissionCTEvent(CLConstant.PAYU_CT_INITIATED)
                bottomSheet?.requestPermission(
                    PayUUpiConstant.PERMISSIONS.keys.toTypedArray(),
                    { resultMap ->
                        val allGranted = resultMap.keys.fold(true) { accumulator, key ->
                            val value = resultMap[key]
                            logPermissionCTEvent(
                                if (value == true)
                                    CLConstant.PAYU_CT_GRANTED
                                else
                                    CLConstant.PAYU_CT_DENIED,
                                key
                            )
                            accumulator && (
                                    if (PayUUpiConstant.PERMISSIONS[key] == true) // if mandatory permission
                                        value == true
                                    else
                                        true
                                    )
                        }
                        if (allGranted) {
                            proceedAfterPermissionGranted()
                        } else {
                            closeAfterPermissionDenied()
                        }
                    }, {
                    if (PayUUPIBoltUI.getCoreInstance()?.hasPermissions() == true) {
                        proceedAfterPermissionGranted()
                    } else {
                        closeAfterPermissionDenied()
                    }
                })
                SharedPrefsUtils.storePermissionRequestCount(activity)
            } else {
                launchDeviceSettings()
                Toast.makeText(
                    activity, activity.getString(R.string.payu_permission_attempts_exceeded),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun proceedAfterPermissionGranted() {
        upiFixedBottomSheetViewModel.startHandshake()
    }

    private fun closeAfterPermissionDenied() {
        val response = PayUUPIBoltResponse(
            upiFixedBottomSheetViewModel.getResponseType(),
            PayUResponseCodes.PERMISSION_MISSING_ERROR_CODE,
            PayUResponseMessages.PAYU_PERMISSION_ERROR_MESSAGE
        )
        upiFixedBottomSheetViewModel.sendMerchantCallback(
            response,
            isSuccess = false
        )
    }

    private fun shouldShowSettingDialog(): Boolean {
        val permissionsCount = SharedPrefsUtils.getPermissionRequestCount(activity)
        return permissionsCount < SharedPrefsConstants.MAX_PERMISSION_REQUEST_COUNT
    }

    private fun logPermissionCTEvent(status: String, permission: String? = null) {
        val map = HashMap<String, Any>().apply {
            permission?.let {
                this[CLConstant.PAYU_EVENT_TYPE] = permission
                this[CLConstant.PAYU_EVENT_TYPE] = InternalConfig.ctFlowType
            }
        }
        AnalyticsUtils.setCTLogsForUPIWithData(activity, CLConstant.PAYU_CT_DEVICE_PERMISSION, map, status = status)
        val kibanaDataInfo =
            KibanaDataInfo(
                CLConstant.PAYU_CT_DEVICE_PERMISSION,
                JSONObject().apply {
                    put(CLConstant.PAYU_EVENT_TYPE, permission)
                    put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
                }.toString(),
                eventType = if (status == CLConstant.PAYU_CT_DENIED) AnalyticsUtils.EventType.Error else AnalyticsUtils.EventType.Info,
                eventSeverity = if (status == CLConstant.PAYU_CT_DENIED) AnalyticsUtils.EventSeverity.High else AnalyticsUtils.EventSeverity.Low,
                status = status
            )
        upiFixedBottomSheetViewModel.logKibanaData(kibanaDataInfo)
    }

    private fun logCTAEvent(
        name: String,
        screenName: String?,
        map: HashMap<String, Any>,
        ctFlowType: String = InternalConfig.ctFlowType
    ) {
        PayUUtils.logKibanaEvents(
            activity, CLConstant.PAYU_CT_CTA_CLICKED,
            JSONObject().apply {
                map.forEach { entry ->
                    put(entry.key, entry.value)
                }
                put(CLConstant.PAYU_EVENT_TYPE, ctFlowType)
                put(CLConstant.PAYU_CT_NAME, name)
            }.toString(),
            screenName = screenName,
            name = name
        )
        AnalyticsUtils.logClevertapCTAClickedEvent(
            activity, name, ctFlowType, map, screenName
        )
    }
}