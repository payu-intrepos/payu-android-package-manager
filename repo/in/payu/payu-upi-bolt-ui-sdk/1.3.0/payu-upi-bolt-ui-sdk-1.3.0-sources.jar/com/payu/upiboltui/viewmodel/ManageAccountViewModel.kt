package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.model.ManageAccountModel
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUAndroidUtils

internal class ManageAccountViewModel(application: Application):
    SetPinBaseViewModel(application), PayUUPIBoltCallBack {

    private var _upiAccounts: MutableLiveData<NetworkResponse<List<LinkedAccountsUIModel>>> = MutableLiveData()
    var upiAccounts: LiveData<NetworkResponse<List<LinkedAccountsUIModel>>> = _upiAccounts

    private var _bankList: MutableLiveData<NetworkResponse<ArrayList<PayUBankData>>> = MutableLiveData()
    var bankList: LiveData<NetworkResponse<ArrayList<PayUBankData>>> = _bankList

    private var deleteAccountMutableLiveData: MutableLiveData<NetworkResponse<Any>> = MutableLiveData()
    var deleteAccountLiveData: LiveData<NetworkResponse<Any>> = deleteAccountMutableLiveData

    private var selectedAccount: PayUCustomerBankAccounts? = null

    init {
        fetchLinkedAccounts()
    }

    fun fetchLinkedAccounts() {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS,
            CLConstant.PAYU_CT_INITIATED
        )
        action = UpiPluginAction.LINKED_ACCOUNT
        _upiAccounts.value = NetworkResponse.Loading()
        PayUUPIBoltUI.getCoreInstance()?.fetchLinkedAccounts(
            callback = this
        )
    }

    fun addBankAccount() {
        startTime = System.currentTimeMillis()
        action = UpiPluginAction.BANK_SELECTION
        _bankList.value = NetworkResponse.Loading()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_BANKS,
            CLConstant.PAYU_CT_INITIATED
        )
        PayUUPIBoltUI.getCoreInstance()?.fetchBankList(this)
    }

    fun removeAccount(account: PayUAccountDetail) {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_DELETE_ACCOUNT_STATUS,
            CLConstant.PAYU_CT_INITIATED
        )
        action = UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION
        deleteAccountMutableLiveData.value = NetworkResponse.Loading()
        PayUUPIBoltUI.getCoreInstance()?.removeAccount(account, this)
    }

    fun showManagementScreen(
        account: PayUCustomerBankAccounts,
        balance: Double? = null,
        checkBalanceError: UpiPluginAction? = null,
        errorMessage: String? = null
    ) {
        selectedAccount = account
        val model = ManageAccountModel(account, balance, checkBalanceError, errorMessage)
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_sms_info_screen,
                UpiPluginAction.MANAGE_ACCOUNT,
                UpiPluginAction.MANAGE_ACCOUNT.name,
                model
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showDeleteAccountErrorScreen(message: String?) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_error_occurred),
            message ?: context.getString(R.string.payu_delete_account_error_message),
            context.getString(R.string.payu_try_again),
            true
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            "", model, isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun showFetchAccountsErrorScreen(bankName : String? = null) {
        val context = getApplication<Application>()
        var errorMsg = context.getString(R.string.payu_fetch_accounts_error_message)
        if(!bankName.isNullOrEmpty()){
            errorMsg = context.getString(R.string.payu_account_fetch_error_message,bankName)
        }
        val model = GenericInfoModel(
            context.getString(R.string.payu_error_occurred),
            errorMsg,
            context.getString(R.string.payu_try_again),
            true,
            UpiPluginAction.BANK_SELECTION
        )
        showGenericInfoScreen(model)
    }

    private fun showChangePinErrorScreen(errorMessage: String) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_error_occurred),
            errorMessage,
            context.getString(R.string.payu_try_again),
            true
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            "", model, isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showChangePinSuccessScreen() {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_success),
            context.getString(R.string.payu_change_pin_success_message),
            context.getString(R.string.payu_okay),
            false
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            "", model, isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showAccountDeleteSuccessScreen() {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_success),
            context.getString(R.string.payu_delete_account_success_message),
            context.getString(R.string.payu_okay),
            false
        )
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            "", model, isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun checkBalance(account: PayUCustomerBankAccounts) {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_CHECK_BALANCE_STATUS,
            CLConstant.PAYU_CT_INITIATED
        )
        action = UpiPluginAction.MANAGE_ACCOUNT // this action is for showing manage accounts after device binding in case binding breaks
        PayUUPIBoltUI.getCoreInstance()?.checkBalance(account.bankAccounts, this)
    }

    fun changeMpin(account: PayUCustomerBankAccounts) {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_CHANGE_MPIN_STATUS,
            CLConstant.PAYU_CT_INITIATED
        )
        action = UpiPluginAction.MANAGE_ACCOUNT // this action is for showing manage accounts after device binding in case binding breaks
        PayUUPIBoltUI.getCoreInstance()?.changeMPIN(account.bankAccounts, this)
    }

    fun openPinSetScreen(account: PayUCustomerBankAccounts) {
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            showBottomSheet.value =
                Event(getPinSetScreenInfo(account, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT))
        } else {
            showNetworkErrorBtSheet()
        }
    }

    fun openDeleteAccountConfirmationScreen(account: PayUCustomerBankAccounts) {
        selectedAccount = account
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.delete_account_confirmation_screen,
                UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION,
                UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION.name,
                account, isNewInstance = true
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    override fun onPayUSuccess(response: PayUUPIBoltResponse) {
        when (response.responseType) {
            PayUResponseTypes.REQUEST_ALL_ACCOUNTS_V3 -> {
                (response.result as? ArrayList<PayUCustomerBankAccounts>
                    ?: arrayListOf()).let { accounts ->
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS,
                        CLConstant.PAYU_EVENT_SUCCESS,
                        startTime, accounts.size
                    )
                    linkedAccounts = accounts
                    findLargestSuffixUsedInGivenBankAccountsVpa(linkedAccounts)
                    _upiAccounts.value =
                        NetworkResponse.Success(accounts.map { LinkedAccountsUIModel(it) })
                }
            }
            PayUResponseTypes.REQUEST_LIST_BANKS -> {
                val list = response.result as? ArrayList<PayUBankData> ?: arrayListOf()
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_FETCH_BANKS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime, count = list.size
                )
                _bankList.value = NetworkResponse.Success(list)
            }
            PayUResponseTypes.REQUEST_GET_ACCOUNT_REMOVE_V3 -> {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_DELETE_ACCOUNT_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime
                )
                deleteAccountMutableLiveData.value = NetworkResponse.Success(Any())
                showAccountDeleteSuccessScreen()
            }
            PayUResponseTypes.REQUEST_GET_BALANCE -> {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CHECK_BALANCE_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime
                )
                hideLoaderMutableLiveData.value = true
                selectedAccount?.let {
                    showManagementScreen(it, response.result as Double)
                }
            }
            PayUResponseTypes.REQUEST_GET_CHANGE_MPIN -> {
                hideLoaderMutableLiveData.value = true
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_CHANGE_MPIN_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime
                )
                showChangePinSuccessScreen()
            }
        }
    }

    override fun onPayUFailure(response: PayUUPIBoltResponse) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(response)
        if(isDeviceBindingFailedHandled.not()) {
            when (response.responseType) {
                PayUResponseTypes.REQUEST_ALL_ACCOUNTS_V3 -> {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS, CLConstant.PAYU_EVENT_FAILURE,
                        startTime, message = response.message, code = response.code.toString()
                    )
                    _upiAccounts.value = NetworkResponse.Failure(response.message)
                }

                PayUResponseTypes.REQUEST_LIST_BANKS -> {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_BANKS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime, message = response.message, code = response.code.toString()
                    )
                    _bankList.value = NetworkResponse.Failure(response.message)
                }

                PayUResponseTypes.REQUEST_GET_ACCOUNT_REMOVE_V3 -> {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_DELETE_ACCOUNT_STATUS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime, message = response.message, code = response.code.toString()
                    )
                    deleteAccountMutableLiveData.value = NetworkResponse.Failure(response.message)
                    showDeleteAccountErrorScreen(response.message)
                }

                PayUResponseTypes.REQUEST_GET_BALANCE -> {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_CHECK_BALANCE_STATUS,
                        getFailureStatus(response.code),
                        startTime, message = response.message, code = response.code.toString()
                    )
                    hideLoaderMutableLiveData.value = true
                    if (response.code != PayUResponseCodes.PAYU_USER_CANCELLED_CODE) {
                        selectedAccount?.let {
                            showManagementScreen(
                                it, checkBalanceError = UpiPluginAction.CHECK_BALANCE_ERROR,
                                errorMessage = getValidErrorMessage(
                                    response.message,
                                    getApplication<Application>().getString(R.string.payu_check_balance_error)
                                )
                            )
                        }
                    }
                }

                PayUResponseTypes.REQUEST_GET_CHANGE_MPIN -> {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_CHANGE_MPIN_STATUS,
                        getFailureStatus(response.code),
                        startTime, message = response.message, code = response.code.toString()
                    )
                    hideLoaderMutableLiveData.value = true
                    if (response.code != PayUResponseCodes.PAYU_USER_CANCELLED_CODE) {
                        showChangePinErrorScreen(
                            getValidErrorMessage(
                                response.message,
                                getApplication<Application>().getString(R.string.payu_change_pin_error_message)
                            )
                        )
                    }
                }

                else -> {
                    handleErrorResponse(response)
                }
            }
        }
    }

    override fun navigateAfterHandshake() {
        when (action) {
            UpiPluginAction.LINKED_ACCOUNT -> {
                fetchLinkedAccounts()
            }
            UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION -> {
                selectedAccount?.let { openDeleteAccountConfirmationScreen(it) }
            }
            UpiPluginAction.MANAGE_ACCOUNT -> {
                selectedAccount?.let { showManagementScreen(it) }
            }
            UpiPluginAction.BANK_SELECTION, UpiPluginAction.FETCH_ACCOUNTS_IIN -> {
                addBankAccount()
            }
            else -> {}
        }
    }

    private fun isAccountsAlreadyAdded(accounts: List<PayUCustomerBankAccounts>): Boolean {
        if ((linkedAccounts?.size ?: 0) > accounts.size)
            return false
        return linkedAccounts?.filter { existingAccount ->
            accounts.find { it.bankAccounts.iin == existingAccount.bankAccounts.iin } != null
        }?.toList()?.size == accounts.size
    }

    private fun logCTApiStatusEvent(
        eventName: String,
        status: String,
        startTime: Long = 0,
        count: Int = 0,
        message: String? = null,
        code: String? = null
    ) {
        logCTApiStatusEvent(
            eventName, status, startTime, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
            count, message, code
        )
    }

    private fun getFailureStatus(code: Int): String {
        return if (code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE)
            CLConstant.PAYU_EVENT_CANCELLED
        else
            CLConstant.PAYU_EVENT_FAILURE
    }

    internal fun getLinkedAccounts(): ArrayList<PayUCustomerBankAccounts>?{
        return linkedAccounts
    }
}