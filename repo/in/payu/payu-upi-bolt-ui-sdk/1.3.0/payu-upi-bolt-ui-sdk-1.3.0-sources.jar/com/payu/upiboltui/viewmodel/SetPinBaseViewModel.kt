package com.payu.upiboltui.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.constants.SharedPrefsConstants
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import com.payu.commonmodelssdk.model.response.FetchAccountsIInResponse
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.model.AddAccountSelectionModel
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.InternalConfig.largestSuffixUsedForVpa
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PayUUtils.formatMobileNumberForVpa
import com.payu.upiboltui.utils.SharedPrefsUtils
import org.json.JSONObject

internal open class SetPinBaseViewModel(application: Application) :
    HandshakeBaseViewModel(application) {

    private var accountsListMutableLiveData: MutableLiveData<NetworkResponse<List<PayUCustomerBankAccounts>>> =
        MutableLiveData()
    val accountsListLiveData: LiveData<NetworkResponse<List<PayUCustomerBankAccounts>>> =
        accountsListMutableLiveData

    private val vpaMutableLiveData = MutableLiveData<Event<NetworkResponse<Any>>>()
    val vpaLiveData: LiveData<Event<NetworkResponse<Any>>> = vpaMutableLiveData

    private var accountList: List<PayUCustomerBankAccounts>? = null
    protected var startTime: Long = 0
    private var accountSuffix: Int? = null
    private var updateVpaTryCount: Int = -1
    fun getPinSetScreenInfo(data: PayUCustomerBankAccounts, flowType: String): PayUBottomSheetInfo {
        return PayUBottomSheetInfo(
            R.layout.fragment_mpin_setup_btsheet,
            UpiPluginAction.M_PIN_SETUP,
            UpiPluginAction.M_PIN_SETUP.name, data, isNewInstance = true,
            ctFlowType = flowType
        )
    }

    fun showActivateAccountError(message: String) {
        showBottomSheet.value = Event(getActivateAccountErrorInfo(message))
    }

    private fun getActivateAccountErrorInfo(message: String): PayUBottomSheetInfo {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.pay_activate_account_error_title),
            message,
            context.getString(R.string.payu_try_again),
            true
        )
        return PayUBottomSheetInfo(
            R.layout.generic_info_bottomsheet,
            UpiPluginAction.GENERIC_INFO,
            UpiPluginAction.GENERIC_INFO.name, model, isNewInstance = true
        )
    }

    private fun openEditVpaScreen(account: PayUAccountDetail) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.fragment_upiedit_btsheet,
                UpiPluginAction.UPDATE_VPA,
                UpiPluginAction.UPDATE_VPA.name,
                account,
                isNewInstance = true,
                ctFlowType = InternalConfig.ctFlowType
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun createVpa(account: PayUCustomerBankAccounts, isManualCreation: Boolean = false) {
        if (PayUAndroidUtils.isInternetAvailable(getApplication())) {
            resetAutoVpaTrackingFlags()
            createVpa(account.bankAccounts, isManualCreation)
        } else {
            showNetworkErrorBtSheet()
        }
    }

    private fun createVpa(account: PayUAccountDetail, isManualCreation: Boolean = false) {
        if (updateVpaTryCount != -1 && updateVpaTryCount > 3) {
            resetAutoVpaTrackingFlags()
            openEditVpaScreen(account)
        } else updateVpa(account, isManualCreation)
    }


    fun fetchAccountsIin(bankData: PayUBankData, ctFlowType: String, mRequestType : String=PayUUpiConstant.ACCOUNT_LIST_REQUEST_TYPE_REGISTRATION) {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_ACCOUNTS,
            CLConstant.PAYU_CT_INITIATED,
            type = ctFlowType
        )
        action = UpiPluginAction.FETCH_ACCOUNTS_IIN
        accountsListMutableLiveData.value = NetworkResponse.Loading()
        val requestType = if (InternalConfig.config?.pluginTypes?.first() == PluginType.HDFC) {
            mRequestType
        } else null
        PayUUPIBoltUI.getCoreInstance()?.fetchAccountsWithIin(
            bankData.iin,
            bankData.bankName,
            bankData.bankCode,
            requestType = requestType,
            isCCTxnEnabled = bankData.isCreditSupported,
            bankId = bankData.bankId,
            callback = object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    (response.result as? FetchAccountsIInResponse)?.let { resp ->
                        logFetchAccountsEvent(
                            bankData, CLConstant.PAYU_EVENT_SUCCESS, ctFlowType,
                            resp.accounts?.size ?: 0
                        )
                        if (resp.accounts.isNullOrEmpty().not()) {
                            if (mRequestType == PayUUpiConstant.ACCOUNT_LIST_REQUEST_TYPE_REGISTRATION
                                || resp.accountsAddedToVpa) {
                                accountList = resp.accounts
                                accountsListMutableLiveData.value = NetworkResponse.Success(resp.accounts!!)
                                SharedPrefsUtils.saveBooleanConfig(
                                    getApplication(), SharedPrefsConstants.PAYU_IS_REGISTERED, true
                                )
                            } else {
                                hideLoaderMutableLiveData.value = true
                                showAddAccountSelectionScreen(
                                    AddAccountSelectionModel(resp.accounts!!, bankData)
                                )
                            }
                        } else {
                            handleErrorResponse(response, bankData)
                        }
                    }
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logFetchAccountsEvent(
                        bankData, CLConstant.PAYU_EVENT_FAILURE, ctFlowType,
                        message = response.message, code = response.code.toString()
                    )
                    handleErrorResponse(response, bankData)
                }
            }
        )
    }

    override fun handleErrorResponse(error: PayUUPIBoltResponse, data: Any?) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(error)
        if (isDeviceBindingFailedHandled.not()) {
            when (error.responseType) {
                PayUResponseTypes.REQUEST_FETCH_ACCOUNT_V3 -> {
                    accountsListMutableLiveData.value =
                        NetworkResponse.Failure(errorData = error, data = data)
                }

                PayUResponseTypes.REQUEST_SAVE_ACCOUNT_V3 -> {
                    vpaMutableLiveData.value =
                        Event(NetworkResponse.Failure(errorData = error, data = data))
                }

                PayUResponseTypes.REQUEST_ADD_ACCOUNT -> {
                    hideLoaderMutableLiveData.value = true
                    showAddAccountErrorScreen()
                }

                else -> {
                    super.handleErrorResponse(error, data)
                }
            }
        }
    }

    fun getAccountList(): List<PayUCustomerBankAccounts>? {
        return accountList
    }

    private fun findPrefixValueToAppendToVpa() {
        val largestSuffixUsedForVpa = largestSuffixUsedForVpa
        if (largestSuffixUsedForVpa != -1 && accountSuffix == null) {
            accountSuffix = largestSuffixUsedForVpa
        }
        findLargestSuffixUsedInGivenBankAccountsVpa(accountList)
    }

    fun findLargestSuffixUsedInGivenBankAccountsVpa(accountList: List<PayUCustomerBankAccounts>?) {
        var accountSuffix = accountSuffix
        accountList?.forEach { bank ->
            bank.bankAccounts.vpa?.let { vpa ->
                if (vpa.isNotEmpty()) {
                    if (vpa.contains("-")) {
                        val handleIndex = vpa.indexOf("@")
                        var handle = ""
                        if (handleIndex != -1) {
                            handle = vpa.substring(handleIndex, vpa.lastIndex+1)
                        }
                        val suffix = vpa.substringAfterLast("-").replace(handle, "")
                        if (suffix != vpa) {
                            try {
                                val currSuffix = suffix.toInt()
                                if (currSuffix > (accountSuffix ?: -1))
                                    accountSuffix = currSuffix
                            } catch (_: NumberFormatException) {

                            }
                        }
                    }
                }
            }
        }
        this.accountSuffix = accountSuffix
        this.accountSuffix?.let {
            largestSuffixUsedForVpa = it
        }
    }

    private fun resetAutoVpaTrackingFlags() {
        updateVpaTryCount = -1
        accountSuffix = null
    }

    private fun removeOldSuffixInVpaAndAttachNewSuffix(vpa: String, accountSuffix: Int): String {
            val handleIndex = vpa.indexOf("@")
            var handle = ""
            if (handleIndex != -1) {
                handle = vpa.substring(handleIndex, vpa.lastIndex + 1)
            }
            val newVpa = vpa.replace(handle, "")
            if (newVpa.contains("-")) {
                val oldSuffix = "-" + newVpa.substringAfterLast("-")
                val validBaseVpa = newVpa.replace(oldSuffix, "")
                accountSuffix.let {
                    return validBaseVpa + "-" + (accountSuffix + 1)
                }
            } else {
                return newVpa + "-" + (accountSuffix.plus(1))
            }
    }

    fun updateVpa(
        accounts: PayUAccountDetail,
        isManualCreation: Boolean = false
    ) {
        action = UpiPluginAction.UPDATE_VPA
        startTime = System.currentTimeMillis()
        logCTUpdateVPAEvent(CLConstant.PAYU_CT_INITIATED, isManualCreation.not())
        var newVpa = ""
        if (isManualCreation.not()) {
            newVpa = if (accounts.vpa.isNullOrEmpty()) {
                InternalConfig.config?.getPhone()?.let { formatMobileNumberForVpa(it) } ?: ""
            } else
                accounts.vpa!!
            findPrefixValueToAppendToVpa()
            accountSuffix?.let {
                newVpa = removeOldSuffixInVpaAndAttachNewSuffix(newVpa, it)
            }
        }
        vpaMutableLiveData.value = Event(NetworkResponse.Loading())
        PayUUPIBoltUI.getCoreInstance()?.setVPA(newVpa, accounts, object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                logCTUpdateVPAEvent(CLConstant.PAYU_EVENT_SUCCESS, isManualCreation.not())
                resetAutoVpaTrackingFlags()
                response.result?.let {
                    if (isManualCreation.not()) {
                        accountSuffix?.let {
                            largestSuffixUsedForVpa = it
                        }
                    }
                    vpaMutableLiveData.value = Event(NetworkResponse.Success(it))
                }
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                if (response.code == 1 && isManualCreation.not()) {
                    updateVpaTryCount++
                    accountSuffix = if (accountSuffix == null) 1 else (accountSuffix ?: 1) + 1
                    logCTUpdateVPAEvent(
                        CLConstant.PAYU_CT_UPI_ID_TAKEN,
                        isManualCreation.not(),
                        response.code.toString()
                    )
                    createVpa(accounts)
                } else {
                    resetAutoVpaTrackingFlags()
                    logCTUpdateVPAEvent(
                        CLConstant.PAYU_EVENT_FAILURE,
                        isManualCreation.not(),
                        response.code.toString()
                    )
                    if (isManualCreation.not())
                        openEditVpaScreen(accounts)
                    handleErrorResponse(error = response)
                }
            }
        })
    }

    private fun logCTUpdateVPAEvent(status: String, isAuto: Boolean, code: String? = null) {
        val mode = if (isAuto)
            CLConstant.PAYU_CT_MODE_AUTO
        else
            CLConstant.PAYU_CT_MODE_MANUAL
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_EVENT_STATUS] = status
            this[CLConstant.PAYU_CT_MODE] = mode
        }
        AnalyticsUtils.setCTLogsForUPIWithData(
            getApplication(),
            CLConstant.PAYU_CT_UPI_ID_STATUS, map, type = InternalConfig.ctFlowType
        )
        PayUUtils.logKibanaEvents(
            getApplication(),
            eventKey = CLConstant.PAYU_CT_UPI_ID_STATUS,
            eventData = JSONObject().apply {
                put(CLConstant.PAYU_CT_MODE, mode)
                put(CLConstant.PAYU_EVENT_TYPE, InternalConfig.ctFlowType)
            }.toString(),
            eventType = code?.let { AnalyticsUtils.EventType.Error } ?: AnalyticsUtils.EventType.Info,
            eventSeverity = code?.let { AnalyticsUtils.EventSeverity.High } ?: AnalyticsUtils.EventSeverity.Low,
            status = status,
            code = code,
            time = System.currentTimeMillis() - startTime
        )
    }

    private fun logFetchAccountsEvent(
        bankData: PayUBankData,
        status: String,
        ctFlowType: String,
        count: Int = 0,
        message: String? = null,
        code: String? = null
    ) {
        val map = HashMap<String, Any>().apply {
            this[CLConstant.PAYU_CT_BANK_NAME] = bankData.bankName
            this[CLConstant.PAYU_CT_BANK_IIN] = bankData.iin
            if (count > 0) {
                this[CLConstant.PAYU_CT_COUNT] = count
            }
        }
        AnalyticsUtils.setCTLogsForUPIWithData(
            getApplication(),
            CLConstant.PAYU_CT_FETCH_ACCOUNTS, map,
            type = ctFlowType,
            status = status
        )
        PayUUtils.logKibanaEvents(
            getApplication(),
            CLConstant.PAYU_CT_FETCH_ACCOUNTS,
            JSONObject().apply {
                map.forEach { entry ->
                    put(entry.key, entry.value)
                }
                message?.let {
                    put(CLConstant.PAYU_CT_MESSAGE, it)
                }
                put(CLConstant.PAYU_EVENT_TYPE, ctFlowType)
            }.toString(),
            eventType = code?.let { AnalyticsUtils.EventType.Error } ?: AnalyticsUtils.EventType.Info,
            eventSeverity = code?.let { AnalyticsUtils.EventSeverity.High } ?: AnalyticsUtils.EventSeverity.Low,
            status = status,
            code = code,
            time = System.currentTimeMillis() - startTime
        )
    }

    fun addAccount(account: PayUCustomerBankAccounts) {
        val addAccountStartTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_ADD_ACCOUNT_STATUS,
            CLConstant.PAYU_CT_INITIATED,
            type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
        PayUUPIBoltUI.getCoreInstance()?.addAccount(account.bankAccounts, object : PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_ADD_ACCOUNT_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    addAccountStartTime,
                    CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
                accountsListMutableLiveData.value = NetworkResponse.Success(arrayListOf())
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_ADD_ACCOUNT_STATUS,
                    CLConstant.PAYU_EVENT_FAILURE,
                    addAccountStartTime,
                    CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                    message = response.message,
                    code = response.code.toString()
                )
                handleErrorResponse(response)
            }
        })
    }

    private fun showAddAccountSelectionScreen(data: AddAccountSelectionModel) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.fragment_add_account_selection,
                UpiPluginAction.ADD_ACCOUNT_SELECTION,
                UpiPluginAction.ADD_ACCOUNT_SELECTION.name,
                data
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showAddAccountErrorScreen() {
        val context = getApplication<Application>()
        var errorMsg = context.getString(R.string.payu_add_account_error_message)
        val model = GenericInfoModel(
            context.getString(R.string.payu_error_occurred),
            errorMsg,
            context.getString(R.string.payu_try_again),
            true,
            UpiPluginAction.BANK_SELECTION
        )
        showGenericInfoScreen(model)
    }
}