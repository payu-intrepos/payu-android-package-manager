package com.payu.upiboltui.model

import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts

internal data class SetMpinModel(
    val account: PayUCustomerBankAccounts,
    val isPinSet: Boolean,
    val isUserCancelled: Boolean = false,
    val errorMessage: String? = null
)
