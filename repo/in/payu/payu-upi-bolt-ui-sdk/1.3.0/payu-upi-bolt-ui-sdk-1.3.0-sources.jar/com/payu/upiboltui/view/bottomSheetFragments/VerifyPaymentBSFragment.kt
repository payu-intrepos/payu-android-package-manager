package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.AnimatorUtil
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class VerifyPaymentBSFragment : BaseBottomSheetFragment() {
    private var isCancellingTxn: Boolean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            isCancellingTxn = it.getBoolean(DATA)
        }
    }
    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        val ivProgress = view.findViewById<AppCompatImageView>(R.id.upi_payu_loader)
        val header = BottomSheetHeader(
            view, "",
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener,
            showExitConfirmation = upiFixedBottomSheetData?.showExitConfirmation == true
        )
        ivProgress?.let {
            AnimatorUtil.applyLoopingAnimatedVectorDrawable(it, context)
        }
        val tvSubtext1 = view.findViewById<TextView>(R.id.tvSubtext1)
        val tvSubtext2 = view.findViewById<TextView>(R.id.tvSubtext2)
        tvSubtext1.text = context.getString(R.string.please_wait)
        tvSubtext2.text = context.getString(
            if(isCancellingTxn == true)
                R.string.payu_cancelling_txn
            else
                R.string.payu_processing_your_payment
        )

        setBottomSheetCancelable(header)
        upiFixedBottomSheetData?.upiBoltListener?.onClick(UpiPluginAction.VERIFY_PAYMENT)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {

        @JvmStatic
        fun newInstance(isCancellingTxn: Boolean, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            VerifyPaymentBSFragment().apply {
                arguments = Bundle().apply {
                    putBoolean(DATA, isCancellingTxn)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}