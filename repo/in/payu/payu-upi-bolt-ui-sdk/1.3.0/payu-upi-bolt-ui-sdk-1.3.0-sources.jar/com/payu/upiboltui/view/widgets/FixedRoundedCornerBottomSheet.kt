package com.payu.upiboltui.view.widgets


import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.ComponentDialog
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.payu.upiboltui.R
import com.payu.upiboltui.listeners.BottomSheetListener
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.utils.AnimatorUtil
import com.payu.upiboltui.utils.BottomSheetStackManager
import com.payu.upiboltui.utils.ScreenSecurityManager


open class FixedRoundedCornerBottomSheet :
    BottomSheetDialogFragment() {

    var bottomSheetListener: BottomSheetListener? = null
    private var layoutId: Int? = null
    private var tag: String? = null
    private var shouldProtect: Boolean = true


    override fun getTheme(): Int = R.style.PayU_BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.setCanceledOnTouchOutside(false)
        AnimatorUtil.moveViewOnYaxis(dialog)
        dialog.behavior.apply {
            isHideable = false
        }
        return dialog
    }

    fun getListener() = bottomSheetListener
    fun getLayoutId() = layoutId ?: arguments?.getInt("layoutId")

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (bottomSheetListener == null && context is BottomSheetListener) {
            this.bottomSheetListener = context
            shouldProtect =
                InternalConfig.config?.shouldProtectScreen(requireActivity().applicationContext) == true
        }
        registerPermissionResultCallback()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            layoutId = it.getInt("layoutId")
        }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return layoutId?.let { inflater.inflate(it, container, false) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bottomSheetListener?.getInflatedView(view, this)
        (dialog as? ComponentDialog)?.onBackPressedDispatcher?.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    bottomSheetListener?.handleBottomSheetBackPress()
                }
            })
        isCancelable = false
    }

    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
        bottomSheetListener?.handleBottomSheetClose()
        BottomSheetStackManager.popBackStack()
    }

    private var resultLauncher: ActivityResultLauncher<Array<String>>? = null
    private var callback: ActivityResultCallback<Map<String, Boolean>>? = null
    private var onPermissionDialogDismiss: (() -> Unit)? = null
    private var isPermissionRequested = false

    private fun registerPermissionResultCallback() {
        resultLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                isPermissionRequested = false
                callback?.onActivityResult(it)
            }
    }

    fun requestPermission(
        permissions: Array<String>,
        callback: ActivityResultCallback<Map<String, Boolean>>, onPermissionDialogDismiss: () -> Unit
    ) {
        this.callback = callback
        this.onPermissionDialogDismiss = onPermissionDialogDismiss
        isPermissionRequested = true
        resultLauncher?.launch(permissions)
    }

    override fun onDestroy() {
        super.onDestroy()
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED)
    }

    fun getBSTag() = tag

    override fun show(manager: FragmentManager, tag: String?) {
        this.tag = tag
        super.show(manager, tag)
    }

    override fun onStart() {
        super.onStart()
        if (shouldProtect) {
            ScreenSecurityManager.enable(dialog?.window)
        }
        dialog?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        dialog?.window?.setDimAmount(.9f)
    }

    override fun onStop() {
        if (shouldProtect) {
            ScreenSecurityManager.disable(dialog?.window)
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (isPermissionRequested) {
            onPermissionDialogDismiss?.invoke()
            isPermissionRequested = false
        }
    }

}
