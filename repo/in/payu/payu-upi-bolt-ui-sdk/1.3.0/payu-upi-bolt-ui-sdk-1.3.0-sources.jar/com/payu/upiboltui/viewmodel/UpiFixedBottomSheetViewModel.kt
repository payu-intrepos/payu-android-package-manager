package com.payu.upiboltui.viewmodel

import com.payu.commonmodelssdk.listeners.PayUUPIBoltCallBack
import android.app.Application
import android.os.Handler
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUResponseCodes
import com.payu.commonmodelssdk.constants.PayUResponseMessages
import com.payu.commonmodelssdk.constants.PayUResponseTypes
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.constants.SharedPrefsConstants
import com.payu.commonmodelssdk.enums.NetworkResponse
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.model.PgDetails
import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.LinkedAccountsUIModel
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.SetMpinModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.Event
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.PaymentManager
import com.payu.upiboltui.utils.SharedPrefsUtils

internal class UpiFixedBottomSheetViewModel(
    application: Application,
    private val paymentUtils: PaymentManager? = null
) : SetPinBaseViewModel(application) {

    private val deregisterMutableLiveData =
        MutableLiveData<Event<NetworkResponse<PayUUPIBoltResponse>>>()
    val deregisterLiveData: LiveData<Event<NetworkResponse<PayUUPIBoltResponse>>> =
        deregisterMutableLiveData

    private val hideDeregisterAccountLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val hideDeregisterAccountLoaderLiveData: LiveData<Event<Boolean>> =
        hideDeregisterAccountLoaderMutableLiveData

    private val showFetchLinkedAccountsLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showFetchLinkedAccountsLoaderLiveData: LiveData<Event<Boolean>> =
        showFetchLinkedAccountsLoaderMutableLiveData

    private val showBankListLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showBankListLoaderLiveData: LiveData<Event<Boolean>> =
        showBankListLoaderMutableLiveData

    private val showPayLoaderMutableLiveData: MutableLiveData<Event<Boolean>> =
        MutableLiveData()
    val showPayLoaderLiveData: LiveData<Event<Boolean>> =
        showPayLoaderMutableLiveData

    private val handleNavMutableLiveData: MutableLiveData<Event<UpiPluginAction?>> =
        MutableLiveData()
    val handleNavLiveData: LiveData<Event<UpiPluginAction?>> =
        handleNavMutableLiveData

    internal fun showLinkedAccountScreen(accountList: List<LinkedAccountsUIModel>) {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_account_linked_bottomsheet,
                UpiPluginAction.LINKED_ACCOUNT,
                UpiPluginAction.LINKED_ACCOUNT.name,
                accountList
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    fun showManagementOptions() {
        val payUBottomSheetInfo =
            PayUBottomSheetInfo(
                R.layout.upi_sms_info_screen,
                UpiPluginAction.MANAGEMENT_OPTIONS,
                UpiPluginAction.MANAGEMENT_OPTIONS.name
            )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showBankListErrorScreen(isNewInstance: Boolean = false) {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_could_not_fetch_bank_list),
            context.getString(R.string.bank_list_error_message),
            context.getString(R.string.payu_try_again),
            isErrorImgVisible = true,
            if (isNewInstance)
                UpiPluginAction.GENERIC_INFO
            else
                UpiPluginAction.BANK_SELECTION,
            retryData = isNewInstance,
            showProgress = true
        )
        showGenericInfoScreen(model, isNewInstance = isNewInstance)
    }

    private fun showLinkedAccountsListErrorScreen() {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_could_not_fetch_account_list),
            context.getString(R.string.account_list_error_message),
            context.getString(R.string.payu_try_again),
            isErrorImgVisible = true,
            UpiPluginAction.LINKED_ACCOUNT,
            showProgress = true
        )
        showGenericInfoScreen(model)
    }

    internal fun showDeregisterAllAccountsConfirmation() {
        val payUBottomSheetInfo = PayUBottomSheetInfo(
            R.layout.deregister_all_accounts_confirmation,
            UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS,
            UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS.name,
            isNewInstance = true
        )
        showBottomSheet.value = Event(payUBottomSheetInfo)
    }

    private fun showDeregisterAllAccountsFailed() {
        val context = getApplication<Application>()
        val model = GenericInfoModel(
            context.getString(R.string.payu_could_not_deregister),
            context.getString(R.string.payu_deregister_error_description),
            context.getString(R.string.payu_try_again),
            isErrorImgVisible = true
        )
        showGenericInfoScreen(model, isNewInstance = true)
    }

    fun openPinSetScreen(data: PayUCustomerBankAccounts) {
        showBottomSheet.value = Event(getPinSetScreenInfo(data, CLConstant.PAYU_EVENT_TYPE_REPEAT))
    }

    internal fun fetchBankList(isNewInstance: Boolean) {
        startTime = System.currentTimeMillis()
        action = UpiPluginAction.BANK_SELECTION
        showBankListLoaderMutableLiveData.value = Event(true)
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_BANKS,
            CLConstant.PAYU_CT_INITIATED,
            ctFlowType = InternalConfig.ctFlowType
        )
        PayUUPIBoltUI.getCoreInstance()?.fetchBankList(object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                (response.result as? ArrayList<PayUBankData>)?.let { list ->
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_BANKS,
                        CLConstant.PAYU_EVENT_SUCCESS,
                        startTime,
                        list.size,
                        ctFlowType = InternalConfig.ctFlowType
                    )
                    showBanksListScreen(list, isNewInstance,
                        ctFlowType = InternalConfig.ctFlowType)
                } ?: run {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_FETCH_BANKS,
                        CLConstant.PAYU_EVENT_FAILURE,
                        startTime,
                        message = PayUResponseMessages.PAYU_INVALID_RESPONSE_MESSAGE,
                        code = PayUResponseCodes.PAYU_FAILED_STATUS.toString(),
                        ctFlowType = InternalConfig.ctFlowType
                    )
                    handleErrorResponse(response, isNewInstance)
                }
                showBankListLoaderMutableLiveData.value = Event(false)
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_FETCH_BANKS,
                    CLConstant.PAYU_EVENT_FAILURE,
                    startTime,
                    message = response.message,
                    code = response.code.toString(),
                    ctFlowType = InternalConfig.ctFlowType
                )
                showBankListLoaderMutableLiveData.value = Event(false)
                handleErrorResponse(response, isNewInstance)
            }
        })
    }

    internal fun fetchLinkedAccounts() {
        startTime = System.currentTimeMillis()
        action = UpiPluginAction.LINKED_ACCOUNT
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS,
            CLConstant.PAYU_CT_INITIATED
        )
        showFetchLinkedAccountsLoaderMutableLiveData.value = Event(true)
        PayUUPIBoltUI.getCoreInstance()?.fetchLinkedAccounts(
            payUBeneficiaryDetail = InternalConfig.paymentParams?.beneficiaryDetails,
            callback = object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    linkedAccounts = response.result as? ArrayList<PayUCustomerBankAccounts>
                    if ((linkedAccounts?.size ?: 0) > 0) {
                        logUserRegisteredEvent(CLConstant.PAYU_CT_STATUS_REGISTERED)
                        InternalConfig.ctFlowType = CLConstant.PAYU_EVENT_TYPE_REPEAT
                    }
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS,
                    CLConstant.PAYU_EVENT_SUCCESS,
                    startTime, count = linkedAccounts?.size ?: 0
                )
                findLargestSuffixUsedInGivenBankAccountsVpa(linkedAccounts)
                if (linkedAccounts.isNullOrEmpty()) {
                    fetchBankList(false)
                } else {
                    SharedPrefsUtils.saveBooleanConfig(
                        getApplication(), SharedPrefsConstants.PAYU_IS_REGISTERED, true
                    )
                    linkedAccounts?.let { accounts ->
                        showFetchLinkedAccountsLoaderMutableLiveData.value = Event(false)
                        showLinkedAccountScreen(accounts.map { LinkedAccountsUIModel(it) })
                    }
                }
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                showFetchLinkedAccountsLoaderMutableLiveData.value = Event(false)
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_FETCH_LINKED_ACCOUNTS,
                    CLConstant.PAYU_EVENT_FAILURE,
                    startTime, message = response.message, code = response.code.toString()
                )
                handleErrorResponse(response)
            }
        })
    }

    internal fun makePayment(accountData: PayUCustomerBankAccounts) {
        action =
            UpiPluginAction.LINKED_ACCOUNT // this action is for showing linked accounts after device binding in case binding breaks
        showPayLoaderMutableLiveData.value = Event(true)
        paymentUtils?.makePayment(getApplication(), accountData.bankAccounts, object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                verifyPayment()
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                handleErrorResponse(response)
            }
        }, CLConstant.PAYU_EVENT_TYPE_REPEAT)
    }

    internal fun verifyPayment() {
        action = UpiPluginAction.LINKED_ACCOUNT
        paymentUtils?.verifyPayment(getApplication(), object : PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                sendMerchantCallback(
                    response,
                    true,
                    popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name
                )
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                handleErrorResponse(response)
            }
        }, ctFlowType = CLConstant.PAYU_EVENT_TYPE_REPEAT)
    }

    internal fun activateAccount(
        accounts: PayUCustomerBankAccounts,
        cardNumber: String,
        expiry: String,
        upiBoltListener: PayUUPIBoltOnClickListener?,
        ctFlowType: String
    ) {
        startTime = System.currentTimeMillis()
        val context = getApplication<Application>()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_MPIN_STATUS, CLConstant.PAYU_CT_INITIATED, type = ctFlowType
        )
        action = UpiPluginAction.M_PIN_SETUP
        PayUUPIBoltUI.getCoreInstance()
            ?.setMPIN(accounts.bankAccounts, cardNumber, expiry, object :
                PayUUPIBoltCallBack {
                override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_MPIN_STATUS, CLConstant.PAYU_EVENT_SUCCESS, startTime, ctFlowType
                    )
                    val model = SetMpinModel(accounts, true)
                    upiBoltListener?.onClick(UpiPluginAction.M_PIN_SETUP_STATUS, model)
                    // Todo: the toast will be replaced by bottom sheet in later releases
                    Toast.makeText(context, context.getString(R.string.payu_set_pin_success_message), Toast.LENGTH_SHORT).show()
                }

                override fun onPayUFailure(response: PayUUPIBoltResponse) {
                    logCTApiStatusEvent(
                        CLConstant.PAYU_CT_MPIN_STATUS,
                        if (response.code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE)
                            CLConstant.PAYU_EVENT_CANCELLED
                        else
                            CLConstant.PAYU_EVENT_FAILURE,
                        startTime, ctFlowType,
                        message = response.message, code = response.code.toString()
                    )
                    val message = getValidErrorMessage(
                        response.message,
                        context.getString(R.string.pay_activate_account_error_message)
                    )
                    val model = SetMpinModel(
                        accounts,
                        false,
                        response.code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE,
                        errorMessage = message
                    )
                    upiBoltListener?.onClick(UpiPluginAction.M_PIN_SETUP_STATUS, model)
                    handleErrorResponse(response)
                }
            })
    }

    internal fun deregisterAllAccounts() {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_DEREGISTER_UPI_STATUS,
            CLConstant.PAYU_CT_INITIATED,
            type = CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
        )
        action = UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS
        PayUUPIBoltUI.getCoreInstance()?.deregister(object :
            PayUUPIBoltCallBack {
            override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_DEREGISTER_UPI_STATUS,
                    CLConstant.PAYU_EVENT_SUCCESS, startTime,
                    CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
                deregisterMutableLiveData.value = Event(NetworkResponse.Success(response))
            }

            override fun onPayUFailure(response: PayUUPIBoltResponse) {
                logCTApiStatusEvent(
                    CLConstant.PAYU_CT_DEREGISTER_UPI_STATUS,
                    CLConstant.PAYU_EVENT_FAILURE, startTime,
                    CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
                    message = response.message, code = response.code.toString()
                )
                handleErrorResponse(response)
            }
        })
    }

    fun isUpiBoltAvailable(
        isTransactionFlow: Boolean = true,
        callback: (PayUUPIBoltResponse) -> Unit
    ) {
        startTime = System.currentTimeMillis()
        logCTApiStatusEvent(
            CLConstant.PAYU_CT_PG_DETAILS_STATUS,
            CLConstant.PAYU_CT_INITIATED
        )
        val sdkInitParams = InternalConfig.config
        if (sdkInitParams != null) {
            if (isTransactionFlow) {
                showCommonBSLoaderScreen()
            }
            Handler(getApplication<Application>().mainLooper).post {
                PayUUPIBoltUI.getCoreInstance()
                    ?.isUpiBoltEnabled(object : PayUUPIBoltCallBack {
                        override fun onPayUSuccess(response: PayUUPIBoltResponse) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_PG_DETAILS_STATUS,
                                CLConstant.PAYU_EVENT_SUCCESS, startTime
                            )
                            InternalConfig.bankHandle = (response.result as? PgDetails)?.run {
                                if (InternalConfig.config?.pluginTypes?.get(0) == PluginType.BHIM) {
                                    bhimBankHandle
                                } else {
                                    bankHandle
                                }
                            }
                            if (isTransactionFlow) {
                                ensureHandshake()
                            } else {
                                callback.invoke(response)
                            }
                        }

                        override fun onPayUFailure(response: PayUUPIBoltResponse) {
                            logCTApiStatusEvent(
                                CLConstant.PAYU_CT_PG_DETAILS_STATUS,
                                CLConstant.PAYU_EVENT_FAILURE, startTime,
                                message = response.message, code = response.code.toString()
                            )
                            if (isTransactionFlow) {
                                if (response.code == PayUResponseCodes.PAYU_FAILED_STATUS
                                    || response.code == PayUResponseCodes.HASH_NOT_RECEIVED_CODE
                                    || response.code == PayUResponseCodes.PAYU_UPI_BOLT_NOT_SUPPORTED_CODE
                                ) {
                                    response.responseType = getResponseType()
                                    callback.invoke(response)
                                } else {
                                    showApiFailureBottomSheet(
                                        UpiPluginAction.UPI_BOLT_AVAILABLE,
                                        true
                                    )
                                }
                            } else {
                                callback.invoke(response)
                            }
                        }
                    })
            }
        }
    }


    override fun handleErrorResponse(error: PayUUPIBoltResponse, data: Any?) {
        val isDeviceBindingFailedHandled = handleDeviceBindingFailed(error)
        if (isDeviceBindingFailedHandled.not()) {
            when (error.responseType) {
                PayUResponseTypes.REQUEST_LIST_BANKS -> {
                    showBankListErrorScreen(data as Boolean)
                }

                PayUResponseTypes.REQUEST_ALL_ACCOUNTS_V3 -> {
                    showLinkedAccountsListErrorScreen()
                }

                PayUResponseTypes.REQUEST_PAY -> {
                    val isUserCancelled =
                        error.code == PayUResponseCodes.PAYU_USER_CANCELLED_CODE
                    if (isUserCancelled) {
                        cancelTxnAfterDelay(error, CLConstant.PAYU_EVENT_TYPE_REPEAT)
                    } else {
                        error.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                        sendMerchantCallback(
                            error,
                            false,
                            popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name
                        )
                    }
                }

                PayUResponseTypes.REQUEST_CHECK_PAYMENT_STATUS -> {
                    error.responseType = PayUResponseTypes.REQUEST_TRANSACTION
                    sendMerchantCallback(
                        error,
                        false,
                        popBackStackUntil = UpiPluginAction.VERIFY_PAYMENT.name
                    )
                }

                PayUResponseTypes.REQUEST_GET_ACCOUNT_REMOVE_V3 -> {
                    hideDeregisterAccountLoaderMutableLiveData.value = Event(true)
                    showDeregisterAllAccountsFailed()
                }

                else -> {
                    super.handleErrorResponse(error, data)
                }
            }
        }
    }

    /*
    This function will be used to retain the user after manually cancelling the tramsaction befpre entering the upi pin and to return him back to linked bank account bottomsheet screen.
    */
    private fun cancelTxnVerification(response: PayUUPIBoltResponse) {
        PayUUtils.logKibanaEvents(
            getApplication(),
            eventKey = PayUUpiConstant.PAYU_ACTION_INITIATED,
            eventData = "USER_CANCELLED_TXN",
            eventType = AnalyticsUtils.EventType.Info
        )
        response.responseType = PayUResponseTypes.REQUEST_TRANSACTION
        response.result = true
        paymentUtils?.cancelVerify()
        showPayLoaderMutableLiveData.value = Event(false)
    }

    override fun navigateAfterHandshake() {
        when (action) {
            UpiPluginAction.LINKED_ACCOUNT -> {
                fetchLinkedAccounts()
            }

            UpiPluginAction.MANAGEMENT_OPTIONS, UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS -> {
                showManagementOptions()
            }

            UpiPluginAction.BANK_SELECTION -> {
                fetchBankList(false)
            }

            else -> {
                handleNavMutableLiveData.value = Event(action)
            }
        }
    }

    fun updateSmsConsent(hasShown: Boolean) {
        hasSmsConsentShown = hasShown
    }

    fun updateNextAction(nextAction: UpiPluginAction) {
        action = nextAction
    }

    override fun callCancelTransactionApi() {
        paymentUtils?.cancelVerify()
        super.callCancelTransactionApi()
    }

    private fun logCTApiStatusEvent(
        eventName: String,
        status: String,
        startTime: Long = 0,
        count: Int = 0,
        message: String? = null,
        code: String? = null,
        ctFlowType: String = InternalConfig.ctFlowType
    ) {
        logCTApiStatusEvent(
            eventName, status, startTime, ctFlowType, count, message, code
        )
    }
}