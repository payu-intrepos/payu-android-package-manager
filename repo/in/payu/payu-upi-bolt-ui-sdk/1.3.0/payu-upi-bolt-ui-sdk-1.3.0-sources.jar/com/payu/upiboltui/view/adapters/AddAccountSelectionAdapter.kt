package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrl
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.adapters.BankSelectionAdapter.ViewHolder

class AddAccountSelectionAdapter(
    private var logoUrl: String,
    private var bankName: String,
    private val items: List<PayUCustomerBankAccounts>
) : RecyclerView.Adapter<AddAccountSelectionAdapter.SelectAccountViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectAccountViewHolder {
        return SelectAccountViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.bank_account_detail_ui, parent, false)
        )
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: SelectAccountViewHolder, position: Int) {
        holder.tvBankNumber.text = String.format(
            "%s %s", bankName,
            items[position].bankAccounts.accountNo.formatAccountNumber()
        )
        updateSelectedState(holder, selectedIndex == position)
        holder.tvVpa.text = items[position].bankAccounts.vpa
        holder.ivBankLogo.loadImageUrl(logoUrl, R.drawable.payu_netbanking)
        holder.tvVpa.visibility = View.GONE

    }

    override fun onBindViewHolder(
        holder: SelectAccountViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isNotEmpty() && payloads[0] is Boolean) {
            updateSelectedState(holder, payloads[0] as Boolean)
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    private fun updateSelectedState(holder: SelectAccountViewHolder, isSelected: Boolean) {
        if (isSelected) {
            holder.ivSelection.setImageResource(R.drawable.payu_circle_selected)
        } else {
            holder.ivSelection.setImageResource(R.drawable.payu_circle_unselected)
        }
    }
    private var selectedIndex = 0

    fun getSelectedItem(): PayUCustomerBankAccounts? {
        return items.getOrNull(selectedIndex)
    }

    fun getSelectedIndex(): Int = selectedIndex



    inner class SelectAccountViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private var accountDetails: ConstraintLayout = itemView.findViewById(R.id.clBankItem)
        var tvBankNumber: TextView = accountDetails.findViewById(R.id.tvBankNumber)
        var tvVpa: TextView = accountDetails.findViewById(R.id.tvVpa)
        var ivSelection: ImageView = accountDetails.findViewById(R.id.ivStatus)
        var ivBankLogo: ImageView = accountDetails.findViewById(R.id.ivBankLogo)

        init {
            ivSelection.setOnClickListener {
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION && selectedIndex != pos) {
                    val prev = selectedIndex
                    selectedIndex = pos

                    notifyItemChanged(prev, false)
                    notifyItemChanged(selectedIndex, true)
                }
            }
        }

    }
}