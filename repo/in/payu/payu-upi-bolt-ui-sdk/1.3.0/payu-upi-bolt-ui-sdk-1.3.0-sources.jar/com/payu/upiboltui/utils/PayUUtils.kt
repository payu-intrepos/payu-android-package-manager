package com.payu.upiboltui.utils

import android.content.Context
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.PayUUPIBoltUI
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.model.InternalConfig
import com.payu.upiboltui.model.PayUBottomSheetInfo
import com.payu.upiboltui.model.PayUUPIBoltUIConfig
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet
import org.json.JSONObject
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


internal object PayUUtils {

    fun convertStringDateToFormat(
        inputDate: String,
        outputDateFormat: String,
        inputDateFormat: String = PayUUPIBoltUiConstant.PAYU_TIME
    ): String {
        val inputFormat = SimpleDateFormat(inputDateFormat, Locale.getDefault())
        val outputFormat = SimpleDateFormat(outputDateFormat, Locale.getDefault())
        return try {
            synchronized(this) {
                val date = inputFormat.parse(inputDate)
                date?.let { outputFormat.format(date) } ?: ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun getTxnHistoryDate(dateString: String): Date? {
        val inputFormat = SimpleDateFormat(PayUUPIBoltUiConstant.PAYU_TIME, Locale.getDefault())
        return try {
            inputFormat.parse(dateString)
        } catch (e: Exception) {
            return null
        }
    }

    fun getDateFromFormattedString(dateString: String, format: String): Date? {
        val inputFormat = SimpleDateFormat(format, Locale.getDefault())
        return try {
            inputFormat.parse(dateString)
        } catch (e: Exception) {
            return null
        }
    }

    fun getCurrentDateWithoutTime(): Date? {
        return try {
            val calendar = Calendar.getInstance(Locale.getDefault())
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            calendar.time
        } catch (ex: Exception) {
            null
        }
    }

    fun getDateFromYearMonthDay(year: Int, month: Int, day: Int): Date {
        val cal = Calendar.getInstance()
        cal.set(year, month, day, 0, 0)
        return cal.time
    }

    fun getYearMonthDayFromDate(date: Date, getFields: (year: Int, month: Int, day: Int) -> Unit) {
        val cal = Calendar.getInstance()
        cal.time = date
        return getFields.invoke(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DATE)
        )
    }

    fun addWeekToDate(date: Date, weeks: Int): Date {
        val calender = Calendar.getInstance()
        calender.time = date
        calender.add(Calendar.WEEK_OF_YEAR, weeks)
        return calender.time
    }

    fun getFormattedStringFromDate(date: Date, inputFormat: String): String {
        return try {
            val dateFormat = SimpleDateFormat(inputFormat, Locale.getDefault())
            dateFormat.format(date)
        } catch (ex: Exception) {
            ""
        }
    }


    fun sendMerchantCallback(
        context: Context,
        response: PayUUPIBoltResponse,
        isSuccess: Boolean,
        isUserCancelled: Boolean = false,
        flowType: String
    ) {
        val status: String
        when {
            isSuccess -> {
                InternalConfig.callback?.onPayUSuccess(response)
                status = CLConstant.PAYU_CT_CLOSED_WITH_SUCCESS
            }
            isUserCancelled -> {
                InternalConfig.callback?.onPayUCancel(
                    response.result as? Boolean ?: false
                )
                status = CLConstant.PAYU_CT_CLOSED_WITH_CANCEL
            }
            else -> {
                InternalConfig.callback?.onPayUFailure(response)
                status = CLConstant.PAYU_CT_CLOSED_WITH_FAILURE
            }
        }
        PayUUPIBoltUI.getCoreInstance()?.clearCache()
        InternalConfig.clearNonInitParams()
        logKibanaEvents(
            context,
            CLConstant.PAYU_CT_SDK_STATE,
            JSONObject().apply {
                response.message?.let {
                    put(CLConstant.PAYU_CT_MESSAGE, it)
                }
                put(CLConstant.PAYU_EVENT_TYPE, flowType)
            }.toString(),
            eventType = if (isSuccess || isUserCancelled) AnalyticsUtils.EventType.Info else AnalyticsUtils.EventType.Error,
            eventSeverity = if (isSuccess || isUserCancelled) AnalyticsUtils.EventSeverity.Low else AnalyticsUtils.EventSeverity.High,
            status = status,
            code = response.code.toString()
        )
        AnalyticsUtils.setCTLogsForUPIWithData(
            context,
            CLConstant.PAYU_CT_SDK_STATE,
            status = status
        )
    }

    fun getCancelConfirmationBSInfo(
        context: Context,
        ctFlowType: String,
        fixedRoundedCornerBottomSheet: FixedRoundedCornerBottomSheet? = null
    ): PayUBottomSheetInfo {
        val model = GenericInfoModel(
            context.getString(
                if (ctFlowType == CLConstant.PAYU_EVENT_TYPE_MANAGEMENT)
                    R.string.do_you_want_to_exit
                else
                    R.string.do_you_want_to_cancel_payment
            ), "",
            context.getString(R.string.payu_yes),
            false,
            parentBs = fixedRoundedCornerBottomSheet,
            negativeBtnText = context.getString(R.string.payu_no)
        )
        return PayUBottomSheetInfo(
            R.layout.generic_cancel_bottomsheet,
            UpiPluginAction.CANCEL_CONFIRMATION,
            UpiPluginAction.CANCEL_CONFIRMATION.name, model, isNewInstance = true,
            ctFlowType = ctFlowType
        )
    }

    fun addDaysToDate(date: Date, days: Int): Date {
        val calender = Calendar.getInstance()
        calender.time = date
        calender.add(Calendar.DAY_OF_YEAR, days)
        return calender.time
    }

    fun logKibanaEvents(
        context: Context,
        eventKey: String,
        eventData: String,
        eventType: AnalyticsUtils.EventType = AnalyticsUtils.EventType.Info,
        eventSeverity: AnalyticsUtils.EventSeverity = AnalyticsUtils.EventSeverity.Low,
        screenName: String? = null,
        status: String? = null,
        code: String? = null,
        amount: String? = null,
        time: Long? = null,
        txnId: String? = null,
        name: String? = null
    ) {
        AnalyticsUtils.logEventNameForKibana(
            context = context,
            eventName = "${PayUUpiConstant.PAYU_BOLT_UI_API}$eventKey",
            eventData = eventData,
            txnId = txnId,
            timeDiff = time,
            status = status,
            code = code,
            screenName = screenName,
            eventType = eventType,
            eventSeverity = eventSeverity,
            amount = amount?.toDouble(),
            sdkName = PayUUpiConstant.PAYU_BOLT_UI_SDK_NAME,
            name = name
        )
    }

    internal fun prepareAccountJson(account: PayUCustomerBankAccounts): JSONObject {
        val jsonObject = JSONObject()
        jsonObject.put(PayUUpiConstant.PAYU_MASKED_ACT_NUMBER, account.bankAccounts.accountNo)
        jsonObject.put(PayUUpiConstant.PAYU_VPA, account.bankAccounts.vpa)
        jsonObject.put(PayUUpiConstant.PAYU_AEBA, account.bankAccounts.aeba)
        jsonObject.put(PayUUpiConstant.PAYU_MBEBA, account.bankAccounts.mbeba)
        jsonObject.put(PayUUpiConstant.VERIFY_STATUS, account.bankAccounts.status)
        jsonObject.put(PayUUpiConstant.PAYU_TYPE, account.bankAccounts.type)
        return jsonObject
    }

    internal fun prepareInitParamsJson(uiSDKInitParams: PayUUPIBoltUIConfig?): JSONObject {
        val jsonObject = JSONObject()
        jsonObject.put(PayUUpiConstant.PAYU_MERCHANT_NAME, uiSDKInitParams?.merchantKey)
        jsonObject.put(PayUUpiConstant.PAYU_MERCHANT_KEY, uiSDKInitParams?.merchantKey)
        jsonObject.put(
            PayUUpiConstant.PAYU_MOBILE,
            getMaskedMobileNumber(uiSDKInitParams?.getPhone() ?: "")
        )
        jsonObject.put(PayUUpiConstant.PAYU_EMAIL_ID, uiSDKInitParams?.email)
        if (uiSDKInitParams?.pluginTypes?.isEmpty() == false) {
            jsonObject.put(PayUUpiConstant.PAYU_PLUGIN_TYPE, uiSDKInitParams.pluginTypes.first())
        }
        jsonObject.put(PayUUpiConstant.PAYU_IS_PROD, uiSDKInitParams?.isProduction)
        return jsonObject
    }

    fun getDisplayMobileNumber(mobile: String): String {
        if (mobile.length == 10) {
            return "+91$mobile"
        } else if (mobile.startsWith("91")) {
            return "+$mobile"
        } else if (mobile.startsWith("+")) {
            return mobile
        }
        return mobile
    }

    fun formatMobileNumber(s: String): String {
        val mobile = s.replace(" ", "").trim()
        if (mobile.length == 10) {
            return "91$mobile"
        } else if (mobile.startsWith("+")) {
            return mobile.substringAfter("+")
        }
        return mobile
    }

    fun formatAmount(amount: String?): String? {
        if (amount.isNullOrEmpty()) return null
        return try {
            val format = DecimalFormat("#,##,##0.##").apply {
                roundingMode = RoundingMode.UP
            }
            format.format(amount.toDouble())
        } catch (ex: Exception) {
            null
        }
    }

    fun formatMobileNumberForVpa(s: String): String {
        var mobile = s.replace(" ", "").trim()
        if (mobile.length > 12 && mobile.startsWith("+")) {
            mobile = mobile.substringAfter("+91")
        } else if (mobile.startsWith("+")) {
            mobile = mobile.substringAfter("+")
        } else if (mobile.length == 12) {
            mobile = mobile.substringAfter("91")
        }
        return mobile
    }

    fun isSdkAvailable(className: String?): Boolean {
        try {
            if (!className.isNullOrEmpty()) {
                val wrapperClassLoader = PayUUtils::class.java.classLoader
                wrapperClassLoader?.loadClass(className)
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun isOliveSDKAvailable() = isSdkAvailable("com.olive.upi.OliveUpiManager")

    fun getMaskedMobileNumber(number : String) : String{
        val regex = ".*\\d(?=\\d{4})".toRegex()
        return number.replace(regex,"*")
    }

    fun getTxnHistoryDisplayDate(context: Context, date: String): String {
        val txnDate = getDateFromFormattedString(date, PayUUPIBoltUiConstant.PAYU_DD_MM_YYYY)
        val txnDateTime = txnDate?.time
        val currentTime = getCurrentDateWithoutTime()?.time
        return if (currentTime == txnDateTime) {
            txnDate?.let {
                "${context.getString(R.string.payu_today)} | ${
                    convertStringDateToFormat(
                        date, PayUUPIBoltUiConstant.PAYU_DATE_TIME_TXN_HISTORY
                    ).split("|")[1].trim()
                }"
            } ?: run {
                convertStringDateToFormat(
                    date, PayUUPIBoltUiConstant.PAYU_DATE_TIME_TXN_HISTORY
                )
            }
        } else {
            convertStringDateToFormat(
                date, PayUUPIBoltUiConstant.PAYU_DATE_TIME_TXN_HISTORY
            )
        }
    }

    fun isOnlyBhimPgSelected(): Boolean {
        return InternalConfig.config?.pluginTypes?.let {
            it.size == 1 && it[0] == PluginType.BHIM
        } ?: run { false }
    }

}