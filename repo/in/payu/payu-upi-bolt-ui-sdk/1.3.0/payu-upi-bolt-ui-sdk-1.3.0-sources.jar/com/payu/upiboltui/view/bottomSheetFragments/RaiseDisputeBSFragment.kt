package com.payu.upiboltui.view.bottomSheetFragments

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant
import com.payu.upiboltui.constants.PayUUPIBoltUiConstant.DATA
import com.payu.upiboltui.model.RaiseDisputeModel
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class RaiseDisputeBSFragment : BaseBottomSheetFragment() {
    private var data: PayUTransactionHistory? = null

    private var btn: TextView? = null
    private var progress: ProgressBar? = null
    private var btnUpiSetup: ConstraintLayout? = null
    private var tvHeaderSubtext: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            data = it.getParcelable(DATA)
        }
    }

    private fun initViews(view: View) {
        val context = view.context
        BottomSheetFooter(view)
        BottomSheetHeader(
            view,
            header = context.getString(
                R.string.payu_rupees_symbol,
                PayUUtils.formatAmount(data?.amount)
            ),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        btnUpiSetup = view.findViewById(R.id.btnUpiSetup)
        btn = btnUpiSetup?.findViewById(R.id.payuButton)
        btn?.text = context.getString(R.string.payu_confirm)
        progress = btnUpiSetup?.findViewById(R.id.cpbProgressBarBtn)
        val tvError: TextView = view.findViewById(R.id.tvQueryError)
        val etQuery = view.findViewById<EditText>(R.id.etQuery)
        tvHeaderSubtext = view.findViewById(R.id.tvHeaderSubtext)
        btnUpiSetup?.setAvoidMultiClickListener {
            val query = etQuery.text.toString()
            if (query.trim().isEmpty()) {
                tvError.isVisible = true
                tvError.text = context.getString(R.string.empty_dispute_error)
            } else {
                val map = HashMap<String, Any>().apply {
                    data?.txnId?.let { this[CLConstant.PAYU_CT_TXN_ID] = "**${it.substring(it.length - 6, it.length)}" }
                }
                logCTAEvent(
                    CLConstant.PAYU_CT_RAISE_DISPUTE_SUBMIT,
                    CLConstant.PAYU_CT_SCREEN_RAISE_DISPUTE,
                    map, CLConstant.PAYU_EVENT_TYPE_MANAGEMENT
                )
                progress?.isVisible = true
                btn?.text = ""
                btnUpiSetup?.isClickable = false
                upiFixedBottomSheetData?.upiBoltListener?.onClick(
                    UpiPluginAction.RAISE_DISPUTE_CONFIRM,
                    RaiseDisputeModel(data, query)
                )
            }
        }

        etQuery.doAfterTextChanged {
            tvError.isVisible = false
        }

        val subHeader = data?.dateTime?.let {
            PayUUtils.getTxnHistoryDisplayDate(
                requireContext(),it
            )
        }
        if (!subHeader.isNullOrEmpty()) {
            tvHeaderSubtext?.text = subHeader
            tvHeaderSubtext?.visibility = View.VISIBLE
        } else
            tvHeaderSubtext?.visibility = View.GONE
        initObservers(context)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    private fun initObservers(context: Context) {
        getCommonViewModel()?.hideRaiseDisputeLoaderLiveData?.observe(viewLifecycleOwner) {
            it.getContentIfNotHandled()?.let {
                hideProgressLoader(context)
            }
        }
    }

    private fun hideProgressLoader(context: Context) {
        progress?.isVisible = false
        btn?.text = context.getString(R.string.payu_confirm)
        btnUpiSetup?.isClickable = true
    }

    companion object {
        @JvmStatic
        fun newInstance(data: PayUTransactionHistory, upiFixedBottomSheetData: UpiFixedBottomSheetData) =
            RaiseDisputeBSFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(DATA, data)
                }
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}