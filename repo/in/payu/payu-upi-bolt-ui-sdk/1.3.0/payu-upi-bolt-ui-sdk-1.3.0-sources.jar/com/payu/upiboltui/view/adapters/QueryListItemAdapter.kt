package com.payu.upiboltui.view.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.response.PayUTransactionHistory
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.setAvoidMultiClickListener

class QueryListItemAdapter(
    private var queryHistoryData: List<PayUTransactionHistory>,
    private val onRefreshStatus: (history: PayUTransactionHistory, position: Int) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.payu_querylist_items, parent, false)
        return QueryViewHolder(view)
    }

    override fun getItemCount() = queryHistoryData.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val queryViewHolder = holder as QueryViewHolder
        val context = queryViewHolder.itemView.context

        queryViewHolder.tvQueryTitle.text = context.getString(
            R.string.issue_with_the_payment_of_rs,
            queryHistoryData[position].amount
        )
        queryHistoryData[position].querystatus?.let { status ->
            setQueryStatus(context, queryViewHolder, status)
        }
        queryViewHolder.tvQueryDate.text = queryHistoryData[position].querydate ?: ""
        queryViewHolder.tvTransactionId.text =
            context.getString(R.string.txn_id, queryHistoryData[position].txnId)
        queryViewHolder.tvTicketId.text =
            context.getString(R.string.ticket_id, queryHistoryData[position].queryId)
    }

    private fun setQueryStatus(context: Context, queryViewHolder: QueryViewHolder, status: String) {
        when (status.lowercase()) {
            (PayUUpiConstant.QUERY_STATUS_OPEN).lowercase(),
            (PayUUpiConstant.QUERY_STATUS_O).lowercase(),
            PayUUpiConstant.QUERY_STATUS_INITIATED.lowercase() -> {
                queryViewHolder.tvQueryStatus.text = context.getString(R.string.payu_pending)
                queryViewHolder.tvQueryStatus.setTextColor(
                    ContextCompat.getColor(context, R.color.payu_color_FFAB00)
                )
                queryViewHolder.tvQueryStatus.background =
                    context.getDrawable(R.drawable.payu_rounded_corner_fff7e5)
                queryViewHolder.tvRefreshStatus.isVisible = true
            }

            (PayUUpiConstant.QUERY_STATUS_CLOSED).lowercase(),
            (PayUUpiConstant.QUERY_STATUS_C).lowercase() -> {
                queryViewHolder.tvQueryStatus.text = context.getString(R.string.payu_closed)
                queryViewHolder.tvQueryStatus.setTextColor(
                    ContextCompat.getColor(context, R.color.payu_color_128242)
                )
                queryViewHolder.tvQueryStatus.background =
                    context.getDrawable(R.drawable.payu_rounded_corner_e7f2ec)
                queryViewHolder.tvRefreshStatus.isVisible = false
            }

            else -> {
                queryViewHolder.tvQueryStatus.text = context.getString(R.string.payu_pending)
                queryViewHolder.tvQueryStatus.setTextColor(
                    ContextCompat.getColor(context, R.color.payu_color_FFAB00)
                )
                queryViewHolder.tvQueryStatus.background =
                    context.getDrawable(R.drawable.payu_rounded_corner_fff7e5)
                queryViewHolder.tvRefreshStatus.isVisible = true
            }
        }
    }

    fun updateData(newData: List<PayUTransactionHistory>) {
        queryHistoryData = newData
        notifyDataSetChanged()
    }

    fun updateLoadingStatus(isLoading: Boolean, position: Int) {
        notifyItemChanged(position, HashMap<String, Boolean>().apply {
            put("isLoading", isLoading)
        })
    }

    fun updateDisputeStatus(status: String, position: Int) {
        notifyItemChanged(position, HashMap<String, String>().apply {
            put("disputeStatus", status)
        })
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isNotEmpty()) {
            payloads.forEach { payload ->
                val map = payload as? HashMap<*, *>
                val isLoading = map?.get("isLoading") as? Boolean?
                isLoading?.let {
                    (holder as QueryViewHolder).refreshProgress.isVisible = isLoading
                    holder.tvRefreshStatus.isVisible = isLoading.not()
                }
                val disputeStatus = map?.get("disputeStatus") as? String?
                disputeStatus?.let { status ->
                    (holder as QueryViewHolder).run {
                        setQueryStatus(itemView.context, holder, status)
                        tvRefreshStatus.isVisible =
                            (status.lowercase() == PayUUpiConstant.QUERY_STATUS_CLOSED.lowercase() ||
                                    status.lowercase() == PayUUpiConstant.QUERY_STATUS_C.lowercase()).not()
                    }
                }
            }
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    inner class QueryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvQueryTitle: TextView = itemView.findViewById(R.id.tvQueryTitle)
        var tvQueryStatus: TextView = itemView.findViewById(R.id.tvQueryStatus)
        var tvQueryDate: TextView = itemView.findViewById(R.id.tvQueryDate)
        var tvTransactionId: TextView = itemView.findViewById(R.id.tvTxnId)
        var tvTicketId: TextView = itemView.findViewById(R.id.tvTicketId)
        val tvRefreshStatus: TextView = itemView.findViewById(R.id.tvRefreshStatus)
        val refreshProgress: ProgressBar = itemView.findViewById(R.id.refreshProgressBar)

        init {
            tvRefreshStatus.setAvoidMultiClickListener {
                onRefreshStatus.invoke(queryHistoryData[adapterPosition], adapterPosition)
            }
        }
    }
}