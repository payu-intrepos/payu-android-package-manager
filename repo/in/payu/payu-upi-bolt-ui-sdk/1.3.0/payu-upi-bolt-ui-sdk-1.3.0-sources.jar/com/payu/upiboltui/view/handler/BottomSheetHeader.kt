package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.listeners.PayUUPIBoltOnClickListener
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUAndroidUtils
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class BottomSheetHeader(
    view: View,
    header: String? = null,
    private val bottomSheet: FixedRoundedCornerBottomSheet,
    boltListener : PayUUPIBoltOnClickListener?,
    showExitConfirmation: Boolean = false,
    isErrorImgVisible: Boolean = false,
    showBhimGradientOnHeader: Boolean = true
) {

    private var ivClose: ImageView? = null
    private var tvHeader: TextView? = null

    init {
        val context = view.context
        ivClose = view.findViewById(R.id.ivClose)
        tvHeader = view.findViewById(R.id.tvHeader)
        val headerLayout = view.findViewById<ConstraintLayout>(R.id.btHeader)
        val showBhimGradient = showBhimGradientOnHeader && isErrorImgVisible.not() && PayUUtils.isOnlyBhimPgSelected()
        headerLayout?.background = if (showBhimGradient) {
            AppCompatResources.getDrawable(context, R.drawable.payu_rounded_corner_bhim_gradient)
        } else {
            AppCompatResources.getDrawable(context, R.drawable.payu_rounded_corner_f9fafe)
        }

        if (!header.isNullOrEmpty())
            tvHeader?.text = header

       ivClose?.setAvoidMultiClickListener {
           AnalyticsUtils.logClevertapCTAClickedEvent(
               context,
               CLConstant.PAYU_CT_CROSS,
               CLConstant.PAYU_EVENT_TYPE_MANAGEMENT,
               screenName = header
           )
           if(PayUAndroidUtils.isLastFragmentShowing(bottomSheet.activity?.supportFragmentManager).not() || showExitConfirmation) {
               boltListener?.onClick(UpiPluginAction.CANCEL_CONFIRMATION, bottomSheet)
           } else {
               bottomSheet.dialog?.cancel()
           }
       }

        if(isErrorImgVisible.not()) {
            tvHeader?.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
        }
    }

    fun setCloseButtonVisibility(show: Boolean) {
        ivClose?.visibility = if (show)
            View.VISIBLE
        else
            View.INVISIBLE
    }
}