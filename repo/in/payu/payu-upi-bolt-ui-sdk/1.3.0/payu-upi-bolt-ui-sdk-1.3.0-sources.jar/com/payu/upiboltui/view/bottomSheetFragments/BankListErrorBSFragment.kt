package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.UpiPluginAction
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetFooter
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.handler.BottomSheetSubHeaderWithPb
import com.payu.upiboltui.view.handler.BsSubmitButtonHandler
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet

class BankListErrorBSFragment : BaseBottomSheetFragment() {

    private fun initViews(view: View){
        val context = view.context
        BottomSheetFooter(view)
        BottomSheetHeader(
            view,
            context.getString(R.string.payu_mobile_number_verification),
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener
        )
        val bottomSheetSubHeaderWithPb = BottomSheetSubHeaderWithPb()
        bottomSheetSubHeaderWithPb.init(
            view,
            context.getString(R.string.payu_could_not_fetch_bank_list),
            drawable = R.drawable.payu_mobile_error_icon
        )
        val bsSubmitButtonHandler = BsSubmitButtonHandler()
        bsSubmitButtonHandler.init(
            view,
            payButtonText = context.getString(R.string.payu_try_again),
            upiBoltListener = upiFixedBottomSheetData?.upiBoltListener,
            screenType = UpiPluginAction.BANK_SELECTION
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {
        @JvmStatic
        fun newInstance(upiFixedBottomSheetHandler: UpiFixedBottomSheetData) =
            BankListErrorBSFragment().apply {
                this.upiFixedBottomSheetData = upiFixedBottomSheetHandler
            }
    }
}