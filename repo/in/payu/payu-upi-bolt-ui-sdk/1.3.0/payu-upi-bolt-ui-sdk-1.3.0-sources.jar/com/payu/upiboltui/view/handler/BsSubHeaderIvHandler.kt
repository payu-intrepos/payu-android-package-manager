package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.payu.upiboltui.R

class BsSubHeaderIvHandler {

    private var ivCircularBackground: ImageView? = null
    private var tvUpiSubHeader: TextView ? = null

    fun init(view: View,drawable: Int?,message: String){
        ivCircularBackground = view.findViewById(R.id.ivBankLogo)
        tvUpiSubHeader = view.findViewById(R.id.tvBankName)
        if(drawable == null) {
            ivCircularBackground?.visibility = View.GONE
        } else {
            ivCircularBackground?.visibility = View.VISIBLE
            ivCircularBackground?.setImageResource(drawable)
        }
        tvUpiSubHeader?.text = message

    }
}