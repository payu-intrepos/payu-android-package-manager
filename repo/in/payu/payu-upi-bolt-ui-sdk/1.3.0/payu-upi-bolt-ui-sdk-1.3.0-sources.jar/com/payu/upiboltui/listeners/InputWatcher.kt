package com.payu.upiboltui.listeners

interface InputWatcher {
    fun onInputReceived(input: String, inputType: Int)
}