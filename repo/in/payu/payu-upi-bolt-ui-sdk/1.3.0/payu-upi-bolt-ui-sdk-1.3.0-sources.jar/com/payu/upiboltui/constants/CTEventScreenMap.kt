package com.payu.upiboltui.constants

import com.payu.commonmodelssdk.constants.CLConstant
import com.payu.upiboltui.model.UpiPluginAction

val payUEventScreenMap = HashMap<UpiPluginAction, String>().apply {
    put(UpiPluginAction.LINKED_ACCOUNT, CLConstant.PAYU_CT_SCREEN_LINKED_ACCOUNTS)
    put(UpiPluginAction.MANAGE_ACCOUNT, CLConstant.PAYU_CT_SCREEN_MANAGE_ACCOUNT_OPTIONS)
    put(UpiPluginAction.DELETE_ACCOUNT_CONFIRMATION, CLConstant.PAYU_CT_SCREEN_DELETE_ACCOUNT)
    put(UpiPluginAction.MANAGEMENT_OPTIONS, CLConstant.PAYU_CT_SCREEN_MANAGEMENT)
    put(UpiPluginAction.RAISE_DISPUTE, CLConstant.PAYU_CT_SCREEN_RAISE_DISPUTE)
    put(UpiPluginAction.TRANSACTION_DETAILS, CLConstant.PAYU_CT_SCREEN_TXN_DETAIL)
    put(UpiPluginAction.WELCOME_SCREEN, CLConstant.PAYU_CT_SCREEN_WELCOME)
    put(UpiPluginAction.BANK_SELECTION, CLConstant.PAYU_CT_SCREEN_BANK_LIST)
    put(UpiPluginAction.BANK_SELECTION_DONE, CLConstant.PAYU_CT_SCREEN_BANK_LIST)
    put(UpiPluginAction.UPDATE_VPA, CLConstant.PAYU_CT_SCREEN_SETUP_UPI_ID)
    put(UpiPluginAction.M_PIN_SETUP, CLConstant.PAYU_CT_SCREEN_SET_MPIN)
    put(UpiPluginAction.DE_REGISTER_ALL_ACCOUNTS, CLConstant.PAYU_CT_SCREEN_DEREGISTER_UPI)

    put(UpiPluginAction.VERIFY_PAYMENT, CLConstant.PAYU_CT_SCREEN_PAYMENT_VERIFICATION)
    put(UpiPluginAction.CANCEL_CONFIRMATION, CLConstant.PAYU_CT_SCREEN_CANCEL_CONFIRMATION)
    put(UpiPluginAction.SIM_SELECTION, CLConstant.PAYU_CT_SCREEN_SIM_SELECTION)
}