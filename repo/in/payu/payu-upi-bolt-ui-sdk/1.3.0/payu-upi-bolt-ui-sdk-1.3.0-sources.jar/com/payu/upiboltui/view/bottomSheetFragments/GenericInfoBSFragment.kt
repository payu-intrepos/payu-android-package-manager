package com.payu.upiboltui.view.bottomSheetFragments

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.upibolt.utils.AnalyticsUtils
import com.payu.upiboltui.R
import com.payu.upiboltui.model.GenericInfoModel
import com.payu.upiboltui.utils.PayUUtils
import com.payu.upiboltui.utils.setAvoidMultiClickListener
import com.payu.upiboltui.view.bottomSheetFragments.base.BaseBottomSheetFragment
import com.payu.upiboltui.view.bottomSheetFragments.base.UpiFixedBottomSheetData
import com.payu.upiboltui.view.handler.BottomSheetHeader
import com.payu.upiboltui.view.widgets.FixedRoundedCornerBottomSheet


class GenericInfoBSFragment : BaseBottomSheetFragment() {
    private var data: GenericInfoModel? = null
    private var btnAction: TextView? = null
    private var progressBar: ProgressBar? = null
    private var tvHeaderSubtext: TextView? = null

    private fun initViews(view: View){
        val header = BottomSheetHeader(
            view,
            header = data?.title,
            bottomSheet = this,
            boltListener = upiFixedBottomSheetData?.upiBoltListener,
            isErrorImgVisible = data?.isErrorImgVisible == true
        )
        val btnLayout: ConstraintLayout = view.findViewById(R.id.btnAction)
        btnAction = btnLayout.findViewById(R.id.payuButton)
        progressBar = btnLayout.findViewById(R.id.cpbProgressBarBtn)
        val btnCancel: TextView = view.findViewById(R.id.btnCancel)
        tvHeaderSubtext = view.findViewById(R.id.tvHeaderSubtext)

        btnAction?.text = data?.buttonText
        btnAction?.setAvoidMultiClickListener {
            if (data?.showProgress == true) {
                btnAction?.text = ""
                btnAction?.isClickable = false
                progressBar?.isVisible = true
            }
            upiFixedBottomSheetData?.upiBoltListener?.onClick(data?.nextAction, data?.retryData)
        }

        btnCancel.isVisible = data?.negativeBtnText.isNullOrEmpty().not()
        data?.negativeBtnText?.let {
            btnCancel.text = it
            btnCancel.setAvoidMultiClickListener {
                upiFixedBottomSheetData?.upiBoltListener?.onClick(
                    data?.negativeBtnAction,
                    data?.retryData
                )
            }
        }

        header.setCloseButtonVisibility(data?.isCancelable == true)

        if (!data?.message.isNullOrEmpty()) {
            tvHeaderSubtext?.text = data?.message
            tvHeaderSubtext?.visibility = View.VISIBLE
        } else
            tvHeaderSubtext?.visibility = View.GONE
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    override fun getInflatedView(
        view: View,
        roundedCornerBottomSheet: FixedRoundedCornerBottomSheet
    ) {
        super.getInflatedView(view, roundedCornerBottomSheet)
        initViews(view)
    }

    companion object {

        @JvmStatic
        fun newInstance(
            data: GenericInfoModel,
            upiFixedBottomSheetData: UpiFixedBottomSheetData
        ) =
            GenericInfoBSFragment().apply {
                this.data = data
                this.upiFixedBottomSheetData = upiFixedBottomSheetData
            }
    }
}