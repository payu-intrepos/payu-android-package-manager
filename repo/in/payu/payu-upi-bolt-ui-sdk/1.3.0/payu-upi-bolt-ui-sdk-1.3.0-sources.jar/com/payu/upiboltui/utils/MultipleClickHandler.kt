package com.payu.upiboltui.utils

class MultipleClickHandler {
    companion object {
        private var elapsedLastClickTime: Long = 0
        fun isSafeOnClickListener(timeToCompare: Long = 1000): Boolean {
            if ((System.currentTimeMillis() - elapsedLastClickTime) < timeToCompare) {
                return false
            }
            elapsedLastClickTime = System.currentTimeMillis()
            return true
        }
    }
}