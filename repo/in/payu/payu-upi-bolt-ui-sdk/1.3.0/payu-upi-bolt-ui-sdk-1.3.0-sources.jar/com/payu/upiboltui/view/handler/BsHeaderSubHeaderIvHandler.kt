package com.payu.upiboltui.view.handler

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.payu.upiboltui.R

class BsHeaderSubHeaderIvHandler {

    private var ivCircularBackground: ImageView? = null
    private var tvUpiWelcomeHeader: TextView? = null
    private var tvUpiSubWelcomeHeader: TextView? = null
    private var ivRightArrow: ImageView? = null

    fun init(view: View, drawable: Int, header: String, subHeader: String? = null, showRightArrow: Boolean = false) {
        ivCircularBackground = view.findViewById(R.id.ivBankLogo)
        tvUpiWelcomeHeader = view.findViewById(R.id.tvBankName)
        tvUpiSubWelcomeHeader = view.findViewById(R.id.tvUpiSubWelcomeHeader)
        ivRightArrow = view.findViewById(R.id.ivRightArrow)
        ivCircularBackground?.setImageResource(drawable)
        tvUpiWelcomeHeader?.text = header
        if (!subHeader.isNullOrEmpty())
            tvUpiSubWelcomeHeader?.text = subHeader
        else tvUpiSubWelcomeHeader?.visibility = View.GONE

        if(showRightArrow)
            ivRightArrow?.visibility = View.VISIBLE
        else
            ivRightArrow?.visibility = View.GONE
    }
}