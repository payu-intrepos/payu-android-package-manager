package com.payu.upiboltui.model

import android.content.Context
import com.payu.commonmodelssdk.enums.PluginType
import com.payu.upiboltui.utils.PayUUtils

data class PayUUPIBoltUIConfig(
    var merchantName: String,
    var merchantKey: String,
    private var phone: String,
    var email: String,
    val requestId : String,
    val pluginTypes: List<PluginType>,
    var isProduction: Boolean = true,
    var isProtectedScreen: Boolean = true,
    val excludedBanksIINs: List<String>? = null,
    val issuingBanks: List<String>? = null
) {
    fun getPhone() = PayUUtils.formatMobileNumber(phone)
    fun setPhone(phone: String) { this.phone = phone }
    fun shouldProtectScreen(context: Context) =
        if (isReleaseBuild(context)) isProtectedScreen else true

    private fun isReleaseBuild(context: Context): Boolean {
        return try {
            val clazz = Class.forName("${context.packageName}.BuildConfig")
            val buildType = clazz.getField("BUILD_TYPE").get(null) as String
            buildType == "release"
        } catch (_: Exception) {
            true // safe default — treat unknown as release
        }
    }
}
