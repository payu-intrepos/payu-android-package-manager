package com.payu.upiboltui.model

import com.payu.commonmodelssdk.model.response.PayUBankData
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts

data class AddAccountSelectionModel(
    val accounts: List<PayUCustomerBankAccounts>,
    val bank: PayUBankData
)