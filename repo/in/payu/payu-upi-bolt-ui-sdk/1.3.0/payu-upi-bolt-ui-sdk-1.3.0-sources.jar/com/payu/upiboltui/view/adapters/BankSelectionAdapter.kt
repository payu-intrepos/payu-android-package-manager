package com.payu.upiboltui.view.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import com.payu.upiboltui.R
import com.payu.upiboltui.utils.PayUExtensions.formatAccountNumber
import com.payu.upiboltui.utils.PayUExtensions.loadImageUrl
import com.payu.upiboltui.utils.setAvoidMultiClickListener

class BankSelectionAdapter(
    var accountList: List<PayUCustomerBankAccounts>,
    val accountListener: AccountListener,
    var selectedIndex: Int,
    private var logoUrl: String,
    private var bankName: String
) : RecyclerView.Adapter<BankSelectionAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view: View = inflater.inflate(R.layout.bank_selection_adapter_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val context = holder.itemView.context
        updateSelectedState(holder, selectedIndex == position)
        holder.tvBankNumber.text = String.format(
            "%s %s", bankName,
            accountList[position].bankAccounts.accountNo?.formatAccountNumber()
        )
        holder.tvVpa.text =
            context.getString(R.string.payu_bolt_upi_id, accountList[position].bankAccounts.vpa)
        holder.ivBankLogo.loadImageUrl(logoUrl, R.drawable.payu_netbanking)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads[0] is Boolean) {
            updateSelectedState(holder, payloads[0] as Boolean)
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    private fun updateSelectedState(holder: ViewHolder, isSelected: Boolean) {
        if (isSelected) {
            holder.ivSelection.setImageResource(R.drawable.payu_circle_selected)
        } else {
            holder.ivSelection.setImageResource(R.drawable.payu_circle_unselected)
        }
    }

    override fun getItemCount(): Int {
        return accountList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private var accountDetails: ConstraintLayout = itemView.findViewById(R.id.account_details)
        var tvBankNumber: TextView = accountDetails.findViewById(R.id.tvBankNumber)
        var tvVpa: TextView = accountDetails.findViewById(R.id.tvVpa)
        var ivSelection: ImageView = accountDetails.findViewById(R.id.ivStatus)
        var ivBankLogo: ImageView = accountDetails.findViewById(R.id.ivBankLogo)

        init {
            accountDetails.setAvoidMultiClickListener {
                if (selectedIndex != adapterPosition) {
                    val prev = selectedIndex
                    selectedIndex = adapterPosition
                    accountListener.onItemSelected(accountList[adapterPosition], adapterPosition)
                    notifyItemChanged(prev, false)
                    notifyItemChanged(selectedIndex, true)
                }
            }
        }
    }

    fun updateData(data: List<PayUCustomerBankAccounts>, bankName: String, logo: String) {
        this.bankName = bankName
        logoUrl = logo
        accountList = data
        notifyDataSetChanged()
    }

    interface AccountListener {
        fun onItemSelected(account: PayUCustomerBankAccounts, index: Int)
    }
}