package com.payu.upiboltui.model

import android.os.Parcelable
import com.payu.commonmodelssdk.model.response.PayUCustomerBankAccounts
import kotlinx.parcelize.Parcelize

@Parcelize
data class LinkedAccountsUIModel(
    val account: PayUCustomerBankAccounts,
    var showProgressLoader: Boolean = false,
    var isExpanded: Boolean = false
): Parcelable
