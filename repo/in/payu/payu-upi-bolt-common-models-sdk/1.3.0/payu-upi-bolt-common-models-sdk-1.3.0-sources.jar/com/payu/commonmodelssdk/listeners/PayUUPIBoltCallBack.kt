package com.payu.commonmodelssdk.listeners

import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse


/**
 * PayUUPIProCallBack  class for callBack to merchant
 * */
 interface PayUUPIBoltCallBack {

     fun onPayUSuccess(response: PayUUPIBoltResponse)
     fun onPayUFailure(response: PayUUPIBoltResponse)
}