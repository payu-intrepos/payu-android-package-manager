package com.payu.commonmodelssdk.constants

object PayUErrors {

    const val UDF_POSTIX: String = " should not be null, it can be empty or string"
    const val MANDATORY_PARAM_PREIX: String = "Mandatory param "
    const val IS_MISSING_POSTIX: String = " is missing"

    const val NO_ERROR: Int = 0
    const val MISSING_PARAMETER_EXCEPTION: Int = 5001
    const val NUMBER_FORMAT_EXCEPTION: Int = 5002
    const val INVALID_AMOUNT_EXCEPTION: Int = 5003
    const val INVALID_VPA: Int = 5022

    const val MANDATORY_PARAM_KEY_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "key" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_HASH_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "hash" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_TXNID_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "txnid" + IS_MISSING_POSTIX

    const val MANDATORY_PARAM_FIRST_NAME_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "firstname" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_EMAIL_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "email" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_PRODUCT_INFO_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "product info" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_SURL_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "surl" + IS_MISSING_POSTIX
    const val MANDATORY_PARAM_FURL_IS_MISSING: String =
        MANDATORY_PARAM_PREIX + "furl" + IS_MISSING_POSTIX

    const val USER_CREDENTIALS_NOT_FOUND: String =
        "User credentials is missing!"

    const val INVALID_AMOUNT: String = "Amount should be a Double value example 5.00"

    const val INVALID_UDF1: String = "UDF1$UDF_POSTIX"
    const val INVALID_UDF2: String = "UDF2$UDF_POSTIX"
    const val INVALID_UDF3: String = "UDF3$UDF_POSTIX"
    const val INVALID_UDF4: String = "UDF4$UDF_POSTIX"
    const val INVALID_UDF5: String = "UDF5$UDF_POSTIX"


    const val VPA_NULL: String = "virtual address is null"
    const val VPA_EMPTY: String = "virtual address is empty"
    const val VPA_GREATER: String = "virtual address length should be less then 50 charaters"
    const val INVALID_VPA_MESSAGE: String = "INVALID VPA"

}