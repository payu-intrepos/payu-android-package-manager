package com.payu.commonmodelssdk.enums

enum class PluginType(val pluginName: String) {
    AXIS("AXIS"),
    HDFC("HDFC"),
    BHIM("BHIM")
}