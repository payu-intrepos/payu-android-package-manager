package com.payu.commonmodelssdk.model.response

data class FetchAccountsIInResponse(
    val accounts: List<PayUCustomerBankAccounts>?,
    val accountsAddedToVpa: Boolean
)
