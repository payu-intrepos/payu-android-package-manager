package com.payu.commonmodelssdk.model.request


class PayUBeneficiaryDetail(builder: Builder) {

    var accountNumber: String? = null
        private set

    var ifsc: String? = null
        private set


    init {
        this.accountNumber = builder.accountNumber
        this.ifsc = builder.ifsc
    }

    class Builder {
        internal var accountNumber: String? = null
        internal var ifsc: String? = null


        fun setIfsc(ifsc: String): Builder {
            this.ifsc = ifsc
            return this
        }

        fun setAccountNumber(accountNumber: String): Builder {
            this.accountNumber = accountNumber
            return this
        }



        fun build(): PayUBeneficiaryDetail {
            return PayUBeneficiaryDetail(this)
        }
    }


}