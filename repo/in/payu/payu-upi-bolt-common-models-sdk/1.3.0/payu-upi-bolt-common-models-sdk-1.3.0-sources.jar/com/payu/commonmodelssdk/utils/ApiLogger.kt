package com.payu.commonmodelssdk.utils

import android.util.Log

/**
 * Lightweight utility to log API requests and responses to Logcat in a consistent,
 * easy-to-filter way. All logs are emitted under the same tag so developers can filter
 * on `PAYU_API_LOG` to see the full network trace.
 *
 * Usage (adb logcat / Android Studio filter): `tag:PAYU_API_LOG`
 *
 * Kept dependency-free intentionally so it can be used by every SDK module without
 * forcing an OkHttp dependency on `commonmodelssdk`.
 */
object ApiLogger {

    const val TAG = "PAYU_API_LOG"

    private const val LOGCAT_LINE_CHUNK_SIZE = 4000

    fun logRequest(
        apiName: String,
        method: String,
        url: String,
        headers: Map<String, String>?,
        body: String?
    ) {
        try {
            val sb = StringBuilder()
            sb.append("\n----------- REQUEST -----------")
            sb.append("\nAPI       : ").append(apiName)
            sb.append("\nMETHOD    : ").append(method)
            sb.append("\nURL       : ").append(url)
            sb.append("\nHEADERS   : ").append(maskHeaders(headers))
            sb.append("\nBODY      : ").append(body ?: "")
            sb.append("\n-------------------------------")
            chunkedLog(sb.toString())
        } catch (e: Exception) {
            Log.d(TAG, "logRequest failed: ${e.message}")
        }
    }

    fun logResponse(
        apiName: String,
        url: String,
        statusCode: Int,
        durationMs: Long,
        responseBody: String?
    ) {
        try {
            val sb = StringBuilder()
            sb.append("\n----------- RESPONSE ----------")
            sb.append("\nAPI       : ").append(apiName)
            sb.append("\nURL       : ").append(url)
            sb.append("\nSTATUS    : ").append(statusCode)
            sb.append("\nDURATION  : ").append(durationMs).append(" ms")
            sb.append("\nBODY      : ").append(responseBody ?: "")
            sb.append("\n-------------------------------")
            chunkedLog(sb.toString())
        } catch (e: Exception) {
            Log.d(TAG, "logResponse failed: ${e.message}")
        }
    }

    fun logFailure(
        apiName: String,
        url: String,
        durationMs: Long,
        throwable: Throwable
    ) {
        try {
            val sb = StringBuilder()
            sb.append("\n----------- FAILURE -----------")
            sb.append("\nAPI       : ").append(apiName)
            sb.append("\nURL       : ").append(url)
            sb.append("\nDURATION  : ").append(durationMs).append(" ms")
            sb.append("\nERROR     : ").append(throwable.javaClass.simpleName)
                .append(" - ").append(throwable.message)
            sb.append("\n-------------------------------")
            Log.e(TAG, sb.toString(), throwable)
        } catch (e: Exception) {
            Log.d(TAG, "logFailure failed: ${e.message}")
        }
    }

    /** Mask sensitive header values such as Authorization / bearer tokens. */
    private fun maskHeaders(headers: Map<String, String>?): String {
        if (headers.isNullOrEmpty()) return "{}"
        return headers.entries.joinToString(prefix = "{", postfix = "}") { (k, v) ->
            "$k=$v"
        }
    }

    private fun mask(value: String?): String {
        if (value.isNullOrEmpty()) return ""
        if (value.length <= 8) return "****"
        return value.take(4) + "****" + value.takeLast(4)
    }

    /** Logcat has a ~4K per-line limit; split long strings into chunks so nothing is lost. */
    private fun chunkedLog(message: String) {
        var i = 0
        while (i < message.length) {
            val end = minOf(i + LOGCAT_LINE_CHUNK_SIZE, message.length)
            Log.d(TAG, message.substring(i, end))
            i = end
        }
    }
}
