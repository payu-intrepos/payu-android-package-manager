package com.payu.commonmodelssdk.model.request


class CheckStatus private constructor(
    var tranId: String? = null,
    var rrn: String? = null,
    var orderId: String? = null,
    var udir: String? = null,
    var mobileNumber: String? = null,
    var initiatedBy: String? = null,
    var subtype: String? = null
) {

    data class Builder(
        var tranId: String? = null,
        var rrn: String? = null,
        var orderId: String? = null,
        var udir: String? = null,
        var mobileNumber: String? = null,
        var initiatedBy: String? = null,
        var subtype: String? = null  ) {
        fun tranId(tranId: String) = apply { this.tranId = tranId }
        fun rrn(rrn: String) = apply { this.rrn = rrn }
        fun orderId(orderId: String) = apply { this.orderId = orderId }
        fun udir(udir: String) = apply { this.udir = udir }
        fun mobileNumber(mobileNumber: String) = apply { this.mobileNumber = mobileNumber }
        fun initiatedBy(initiatedBy: String) = apply { this.initiatedBy = initiatedBy }
        fun subtype(subtype: String) = apply { this.subtype = subtype }
        fun build() = CheckStatus( tranId, rrn, orderId, udir, mobileNumber, initiatedBy, subtype)
    }
}
