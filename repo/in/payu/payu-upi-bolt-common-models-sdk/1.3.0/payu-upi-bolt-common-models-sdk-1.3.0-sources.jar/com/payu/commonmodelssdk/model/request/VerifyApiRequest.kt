package com.payu.commonmodelssdk.model.request

import android.content.Context

/**
 * VerifyApiRequest class to get request data from merchant
 * */

data class VerifyApiRequest(
    var context: Context,
    var merchantKey: String?,
    var txnId: String,
    var verifyPaymentHash: String? = null
)
