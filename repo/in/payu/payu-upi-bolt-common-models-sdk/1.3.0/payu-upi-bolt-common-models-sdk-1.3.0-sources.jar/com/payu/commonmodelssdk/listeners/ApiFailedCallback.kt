package com.payu.commonmodelssdk.listeners

import com.payu.commonmodelssdk.model.response.PayUUPIBoltResponse

interface ApiFailedCallback {
    fun onApiFailed(response: PayUUPIBoltResponse, retryCallback: ApiRetryCallback, apiCount: Int)
}

interface ApiRetryCallback {
    fun retry(shouldRetry: Boolean)
}

