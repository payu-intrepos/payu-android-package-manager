package com.payu.commonmodelssdk.model.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class PayUBankData(
    var bankName: String,
    var iin: String,
    var ifsc: String?,
    var logo: String?,
    var bankCode: String? = null,
    var bankId: String? = null,
    var isCreditSupported: Boolean = false,
    var isUPICreditLineSupported: Boolean = false
) : Parcelable