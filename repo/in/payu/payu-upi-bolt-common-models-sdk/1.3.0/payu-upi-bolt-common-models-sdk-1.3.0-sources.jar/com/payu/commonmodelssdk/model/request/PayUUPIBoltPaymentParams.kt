package com.payu.commonmodelssdk.model.request

import com.payu.commonmodelssdk.constants.KibanaConstants
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import org.json.JSONArray
import org.json.JSONObject
import java.util.HashMap

class PayUUPIBoltPaymentParams private constructor(
    var amount: String? = null,
    var tranType: String? = null,
    var refUrl: String? = null,
    var txnId: String? = null,
    var refCategory: String? = null,
    var initMode: String? = null,
    var purpose: String? = null,
    var productInfo: String? = null,
    var firstName: String? = null,
    var surl: String? = null,
    var furl: String? = null,
    var udf1: String? = null,
    var udf2: String? = "",
    var udf3: String? = "",
    var udf4: String? = "",
    var udf5: String? = "",
    var userCredentials: String? = "",
    var isCCTxnEnabled: Boolean? = false,
    var splitPaymentDetails: String? = null,
    var accountDetail: PayUAccountDetail? = null,
    var additionalParams: HashMap<String, Any?>? = hashMapOf(),
    var mcc: String? = null,
    var beneficiaryDetails: List<PayUBeneficiaryDetail>? = null
) {


    data class Builder(
        var amount: String? = null,
        var tranType: String? = null,
        var refUrl: String? = null,
        var txnId: String? = null,
        var refCategory: String? = null,
        var initMode: String? = null,
        var purpose: String? = null,
        var productInfo: String? = null,
        var firstName: String? = null,
        var surl: String? = null,
        var furl: String? = null,
        var udf1: String? = null,
        var udf2: String? = "",
        var udf3: String? = "",
        var udf4: String? = "",
        var udf5: String? = "",
        var userCredentials: String? = "",
        var isCCTxnEnabled: Boolean? = false,
        var accountDetail: PayUAccountDetail? = null,
        var additionalParams: HashMap<String, Any?>? = HashMap(),
        var mcc: String? = null,
        var beneficiaryDetails: List<PayUBeneficiaryDetail>? = null
    ) {
        fun amount(amount: String?) = apply { this.amount = amount }

        fun tranType(tranType: String?) = apply { this.tranType = tranType }
        fun refUrl(refUrl: String?) = apply { this.refUrl = refUrl }
        fun txnId(txnId: String?) = apply { this.txnId = txnId }
        fun refCategory(refCategory: String?) = apply { this.refCategory = refCategory }
        fun initMode(initMode: String?) = apply { this.initMode = initMode }
        fun purpose(purpose: String?) = apply { this.purpose = purpose }
        fun productInfo(productInfo: String?) = apply { this.productInfo = productInfo }
        fun firstName(firstName: String?) = apply { this.firstName = firstName }
        fun surl(surl: String?) = apply { this.surl = surl }
        fun furl(furl: String?) = apply { this.furl = furl }
        fun udf1(udf1: String?) = apply { this.udf1 = udf1 }
        fun udf2(udf2: String?) = apply { this.udf2 = udf2 }
        fun udf3(udf3: String?) = apply { this.udf3 = udf3 }
        fun udf4(udf4: String?) = apply { this.udf4 = udf4 }
        fun udf5(udf5: String?) = apply { this.udf5 = udf5 }
        fun userCredentials(userCredentials: String?) = apply { this.userCredentials = userCredentials }
        fun isCCTxnEnabled(isCCTxnEnabled: Boolean?) = apply { this.isCCTxnEnabled = isCCTxnEnabled }
        fun setAccountDetail(accountDetail: PayUAccountDetail?) = apply { this.accountDetail = accountDetail }
        fun setAdditionalParams(additionalParams: HashMap<String, Any?>?) = apply { this.additionalParams = additionalParams }
        fun setMcc(mcc: String?) = apply { this.mcc = mcc }
        fun setBeneficiaryDetails(beneficiaryDetails: List<PayUBeneficiaryDetail>) =
            apply { this.beneficiaryDetails = beneficiaryDetails }

        fun build() = PayUUPIBoltPaymentParams(
            amount,
            tranType,
            refUrl,
            txnId,
            refCategory,
            initMode,
            purpose,
            productInfo,
            firstName,
            surl,
            furl,
            udf1,
            udf2,
            udf3,
            udf4,
            udf5,
            userCredentials,
            isCCTxnEnabled,
            accountDetail = accountDetail,
            additionalParams = additionalParams,
            mcc = mcc,
            beneficiaryDetails = beneficiaryDetails
        )
    }
    
    /**
     * Converts all parameters in this class to a JSONObject
     * @param isMask If true, masks sensitive parameters from maskedList
     * @param shouldExclude If true, excludes parameters from excludeList
     * @return JSONObject containing all non-null parameters
     */
    fun toJsonObject(isMask: Boolean = false, shouldExclude: Boolean = false): JSONObject {
        val jsonObject = JSONObject()
        val maskedList = KibanaConstants.maskedList
        val excludeList = KibanaConstants.excludeList
        
        // Add simple string fields
        amount?.let { jsonObject.put(KibanaConstants.AMOUNT, it) }
        tranType?.let { jsonObject.put(KibanaConstants.TRAN_TYPE, it) }
        refUrl?.let { jsonObject.put(KibanaConstants.REF_URL, it) }
        txnId?.let { jsonObject.put(KibanaConstants.TXN_ID, it) }
        refCategory?.let { jsonObject.put(KibanaConstants.REF_CATEGORY, it) }
        initMode?.let { jsonObject.put(KibanaConstants.INIT_MODE, it) }
        purpose?.let { jsonObject.put(KibanaConstants.PURPOSE, it) }
        productInfo?.let { jsonObject.put(KibanaConstants.PRODUCT_INFO, it) }
        firstName?.let { jsonObject.put(KibanaConstants.FIRST_NAME, it) }
        surl?.let { jsonObject.put(KibanaConstants.SURL, it) }
        furl?.let { jsonObject.put(KibanaConstants.FURL, it) }
        udf1?.let { jsonObject.put(KibanaConstants.UDF1, it) }
        udf2?.let { jsonObject.put(KibanaConstants.UDF2, it) }
        udf3?.let { jsonObject.put(KibanaConstants.UDF3, it) }
        udf4?.let { jsonObject.put(KibanaConstants.UDF4, it) }
        udf5?.let { jsonObject.put(KibanaConstants.UDF5, it) }
        userCredentials?.let { jsonObject.put(KibanaConstants.USER_CREDENTIALS, it) }
        splitPaymentDetails?.let { jsonObject.put(KibanaConstants.SPLIT_PAYMENT_DETAILS, it) }
        // Exclude mcc if in excludeList and shouldExclude is true
        mcc?.let { 
            if (!shouldExclude || !excludeList.contains(KibanaConstants.MCC)) {
                jsonObject.put(KibanaConstants.MCC, it)
            }
        }
        
        // Add boolean field
        isCCTxnEnabled?.let { jsonObject.put(KibanaConstants.IS_CC_TXN_ENABLED, it) }
        // Add accountDetail as JSONObject
        accountDetail?.let { account ->
            val accountJson = JSONObject()
            // Exclude name if in excludeList and shouldExclude is true
            if (!shouldExclude || !excludeList.contains(KibanaConstants.NAME)) {
                accountJson.put(KibanaConstants.NAME, account.name)
            }
            val accRefNumberValue = if (isMask && maskedList.contains(KibanaConstants.ACC_REF_NUMBER)) {
                KibanaConstants.maskValue(account.accRefNumber)
            } else {
                account.accRefNumber
            }
            accountJson.put(KibanaConstants.ACC_REF_NUMBER, accRefNumberValue)
            accountJson.put(KibanaConstants.IFSC, account.ifsc)
            val accountNoValue = if (isMask && maskedList.contains(KibanaConstants.ACCOUNT_NO)) {
                KibanaConstants.maskValue(account.accountNo)
            } else {
                account.accountNo
            }
            accountJson.put(KibanaConstants.ACCOUNT_NO, accountNoValue)
            accountJson.put(KibanaConstants.TYPE, account.type)
            account.vpa?.let { vpa ->
                val vpaValue = if (isMask && maskedList.contains(KibanaConstants.VPA)) {
                    KibanaConstants.maskValue(vpa)
                } else {
                    vpa
                }
                accountJson.put(KibanaConstants.VPA, vpaValue)
            }
            accountJson.put(KibanaConstants.IIN, account.iin)
            account.mmid?.let { accountJson.put(KibanaConstants.MMID, it) }
            accountJson.put(KibanaConstants.AEBA, account.aeba)
            accountJson.put(KibanaConstants.MBEBA, account.mbeba)
            account.dLength?.let { accountJson.put(KibanaConstants.D_LENGTH, it) }
            account.dType?.let { accountJson.put(KibanaConstants.D_TYPE, it) }
            // Exclude balance if in excludeList and shouldExclude is true
            account.balance?.let { 
                if (!shouldExclude || !excludeList.contains(KibanaConstants.BALANCE)) {
                    accountJson.put(KibanaConstants.BALANCE, it)
                }
            }
            account.balTime?.let { accountJson.put(KibanaConstants.BAL_TIME, it) }
            account.status?.let { accountJson.put(KibanaConstants.STATUS, it) }
            account.bankCode?.let { accountJson.put(KibanaConstants.BANK_CODE, it) }
            accountJson.put(KibanaConstants.FORMAT_TYPE, account.formatType)
            account.atmdLength?.let { accountJson.put(KibanaConstants.ATMD_LENGTH, it) }
            account.bankName?.let { accountJson.put(KibanaConstants.BANK_NAME, it) }
            account.otpdType?.let { accountJson.put(KibanaConstants.OTPD_TYPE, it) }
            account.otpdLength?.let { accountJson.put(KibanaConstants.OTPD_LENGTH, it) }
            account.bankId?.let { accountJson.put(KibanaConstants.BANK_ID, it) }
            account.aepsFlag?.let { accountJson.put(KibanaConstants.AEPS_FLAG, it) }
            account.refUrl?.let { accountJson.put(KibanaConstants.REF_URL, it) }
            account.fullAccountNo?.let { accountJson.put(KibanaConstants.FULL_ACCOUNT_NO, it) }
            jsonObject.put(KibanaConstants.ACCOUNT_DETAIL, accountJson)
        }
        
        // Add beneficiaryDetails as JSONArray
        beneficiaryDetails?.let { beneficiaries ->
            val beneficiaryArray = JSONArray()
            for (beneficiary in beneficiaries) {
                val beneficiaryJson = JSONObject()
                beneficiary.accountNumber?.let { accountNumber ->
                    val accountNumberValue = if (isMask && maskedList.contains(KibanaConstants.ACCOUNT_NUMBER)) {
                        KibanaConstants.maskValue(accountNumber)
                    } else {
                        accountNumber
                    }
                    beneficiaryJson.put(KibanaConstants.ACCOUNT_NUMBER, accountNumberValue)
                }
                beneficiary.ifsc?.let { beneficiaryJson.put(KibanaConstants.IFSC, it) }
                beneficiaryArray.put(beneficiaryJson)
            }
            jsonObject.put(KibanaConstants.BENEFICIARY_DETAILS, beneficiaryArray)
        }
        
        // Add additionalParams
        additionalParams?.let { params ->
            for ((key, value) in params) {
                // Skip if key is in excludeList and shouldExclude is true
                if (shouldExclude && excludeList.contains(key)) {
                    continue
                }
                val finalValue = when {
                    value == null -> JSONObject.NULL
                    isMask && maskedList.contains(key) && value is String -> KibanaConstants.maskValue(value)
                    value is String -> value
                    value is Number -> value
                    value is Boolean -> value
                    value is JSONObject -> value
                    value is JSONArray -> value
                    else -> value.toString()
                }
                jsonObject.put(key, finalValue)
            }
        }
        
        return jsonObject
    }
}