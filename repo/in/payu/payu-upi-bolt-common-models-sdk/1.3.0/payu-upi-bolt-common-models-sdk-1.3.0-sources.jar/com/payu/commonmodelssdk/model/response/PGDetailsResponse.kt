package com.payu.commonmodelssdk.model.response

import com.payu.commonmodelssdk.model.PgDetails

data class PGDetailsResponse(
    val message: String,
    val result: HashMap<String, PgDetailsResult>,
    val status: Int
)