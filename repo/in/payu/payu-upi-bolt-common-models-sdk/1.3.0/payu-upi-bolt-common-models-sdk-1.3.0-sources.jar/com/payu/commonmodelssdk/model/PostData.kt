package com.payu.commonmodelssdk.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PostData(val status: String?, val result: String?, val code: Int) : Parcelable
