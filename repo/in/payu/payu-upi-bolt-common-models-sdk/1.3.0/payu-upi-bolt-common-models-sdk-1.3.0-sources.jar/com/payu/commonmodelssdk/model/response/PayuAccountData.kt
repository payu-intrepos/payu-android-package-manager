package com.payu.commonmodelssdk.model.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class PayUAccountDetail(
   var name: String,
   var accRefNumber: String, // accId
   var ifsc: String,
   var accountNo: String, // accNo
   var type: String,
   var vpa: String? = null,
   var iin: String,
   var mmid: String? = null,
   var aeba: String,
   var mbeba: String,
   var dLength: String? = null, // crdLength
   var dType: String? = null, // crdType
   var balance: String? = null,
   var balTime: String? = null,
   var status: String? = null,
   var bankCode: String? = null,
   var formatType: String,
   var atmdLength: String? = null,
   var bankName: String? = null,
   var otpdType: String? = null,
   var otpdLength: String? = null,
   var bankId: String? = null,
   var aepsFlag: String? = null,
   var refUrl: String? = null,
   var fullAccountNo: String? = null
) : Parcelable