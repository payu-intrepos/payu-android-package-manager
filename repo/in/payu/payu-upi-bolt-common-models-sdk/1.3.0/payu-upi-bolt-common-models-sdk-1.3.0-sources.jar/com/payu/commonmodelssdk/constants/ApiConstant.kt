package com.payu.commonmodelssdk.constants

object ApiConstant {
    const val SDK_RESPONSE_STATUS_CODE_1 = 1
    const val TXN_S2S_FLOW_VALUE = "2"
    const val PAYMENT_POST_DATA_ERROR = "ERROR"
    const val TXN_S2S_FLOW = "txn_s2s_flow"
    const val REQUEST_BODY_CANNOT_BE_NULL = "Request body missing"
    const val REST_API_PATH_CANNOT_BE_NULL = "API endpoint path missing"
    const val PAYU_PROD_PAYMENT_URL = "https://secure.payu.in/_payment"
    const val PAYU_TEST_PAYMENT_URL = "https://test.payu.in/_payment"
    const val PAYU_APPLICATION_URL_ENCODED = "application/x-www-form-urlencoded"
    const val PAYU_APPLICATION_JSON = "application/json"
    const val PAYU_CONTENT_TYPE = "Content-Type"
    const val PAYU_POST = "Post"
    const val PAYU_ACCEPT = "Accept"
    const val SOMETHING_WENT_WRONG_ERROR_MESSAGE = "Something went wrong"
    const val ERROR: String = "ERROR"
    const val SUCCESS: String = "SUCCESS"
    const val BANK_CODE: String = "bankcode"
    const val MAX_VPA_SIZE: Int = 50
    const val PG: String = "pg"
    const val PAYU_VPA = "VPA"
    const val INVALID_VPA = "Invalid VPA"
}