package com.payu.commonmodelssdk.constants

object SharedPrefsConstants {

    const val PERMISSION_COUNT = "permission_count"
    const val MAX_PERMISSION_REQUEST_COUNT = 2

    const val PAYU_FILE_PERMISSION = "_permission"
    const val PAYU_FILE_CONFIG = "_config"

    const val PAYU_IS_REGISTERED = "isRegistered"
    const val PAYU_BANK_LOGO_URL_JSON = "logo_url_json"
}