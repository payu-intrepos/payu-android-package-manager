package com.payu.commonmodelssdk.model.response

data class PayUDisputeType(
    val disputeTypeCode: String,
    val disputeTypeDesc: String
)
