package com.payu.commonmodelssdk.listeners

/**
 * PayUAsyncTaskResponse class for HttpApiCall callback
 * */
interface PayUAsyncTaskResponse {
    fun onSuccess(response: Any)
    fun onFailure(errorCode: Int, errorMessage: String)
}