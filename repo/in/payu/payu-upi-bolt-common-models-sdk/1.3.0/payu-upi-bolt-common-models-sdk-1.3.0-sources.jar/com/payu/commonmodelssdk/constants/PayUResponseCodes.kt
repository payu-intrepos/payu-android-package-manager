package com.payu.commonmodelssdk.constants

object PayUResponseCodes {

    const val PAYU_TRANSACTION_TIMEOUT_CODE = 100
    const val HASH_NOT_RECEIVED_CODE = 101
    const val PAYU_RUNTIME_ERROR = 102
    const val PAYU_HANDSHAKE_FAILED = 103
    const val PAYU_UPI_BOLT_NOT_SUPPORTED_CODE = 104
    const val PAYU_DEVICE_NOT_SUPPORTED_CODE = 105
    const val PERMISSION_MISSING_ERROR_CODE = 106
    const val PAYU_SIM_INFO_NOT_AVAILABLE = 107
    const val PAYU_DEVICE_BINDING_FAILED = 108
    const val PAYU_INITIATE_PAY_FAILED = 109
    const val PAYU_QUERY_ALREADY_EXISTS_CODE = 110
    const val PAYU_MOBILE_NUMBER_MISMATCHED = 111

    // UPI error codes
    const val PAYU_DEVICE_FINGERPRINT_MISMATCHED = 66
    const val PAYU_DEVICE_REGISTRATION_FAILED = 63

    const val PAYU_SUCCESS_STATUS = 0
    const val PAYU_FAILED_STATUS = 1
    const val PAYU_USER_CANCELLED_CODE = 2
}

object PayUResponseMessages {
    const val PAYU_PERMISSION_ERROR_MESSAGE = "SMS and Phone permission not granted"
    const val PAYU_SMS_PERMISSION_ERROR_MESSAGE = "SMS permission not granted"
    const val PAYU_PIN_NOT_SET = "Please set your mPIN"
    const val PAYU_UPI_ID_NOT_SET = "Please set your UPI ID"
    const val PAYU_SDK_INITIALIZED_ERROR_MESSAGE = "SDK Not initialized"
    const val HASH_NOT_RECEIVED = "Hash is missing"
    const val PAYU_DEVICE_NOT_SUPPORTED = "Device not supported for UPI Bolt"
    const val PAYU_SIM_INFO_NOT_AVAILABLE_MESSAGE = "No active sim found in device"
    const val PAYU_UPI_BOLT_NOT_SUPPORTED = "UPI Bolt not supported"
    const val PAYU_MANDATORY_PARAM_MISSING_MESSAGE = "Mandatory param missing "
    const val PAYU_FAILURE_RESPONSE_NULL_MESSAGE = "RESPONSE IS NULL"
    const val PAYU_INVALID_RESPONSE_MESSAGE = "Invalid Api Response"
    const val PAYU_AUTH_TOKEN_INVALID_MESSAGE = "AuthToken is invalid"
    const val PAYU_SMS_VERIFICATION_FAILED: String = "SMS verification failed"
    const val PAYU_MOBILE_NUMBER_NOT_EXISTS_MESSAGE = "Mobile number invalid"
    const val PAYU_DEVICE_BINDING_FAILED_MESSAGE = "Device binding not exists"
    const val PAYU_USER_CANCELLED_MESSAGE = "User has cancelled transaction"
    const val PAYU_TRANSACTION_TIMEOUT_MESSAGE = "Transaction timeout"
    const val PAYU_SUCCESS_MESSAGE = "SUCCESS"
    const val RUNTIME_ERROR_MESSAGE = "Something went wrong, please try again"
    const val PAYU_AUTH_TOKEN_EXPIRE_MESSAGE = "AuthToken has expired"
    const val PAYU_INCORRECT_HASH_MESSAGE = "Incorrect Hash"
    const val PAYU_HANDSHAKE_FAILED_MESSAGE = "Handshake failed"
    const val PAYU_INVALID_BALANCE_VALUE = "Invalid Balance value"
    const val PAYU_MAX_AMOUNT_MESSAGE = "Amount cannot be greater than 100,000"
    const val PAYU_USER_IS_NOT_REGISTERED = "User is not registered"
    const val PAYU_LIMIT_EXHAUSTED_MESSAGE = "exhausted"
    const val PAYU_DEVICE_BINDING_TIMEOUT_MESSAGE = "Device binding timeout"
    const val PAYU_AIRPLANE_MODE_ON_ERROR_MESSAGE = "Airplane mode in on"
    const val PAYU_APP_IN_BACKGROUND_ERROR = "App moved to background"
    const val PAYU_INVALID_DISPUTE_TYPE_ERROR = "Invalid dispute type"
    const val PAYU_CL_SERVICE_DISCONNECTED = "CL service disconnected"
    const val PAYU_SMS_RETRIEVAL_FAILED = "Failed to read OTP"
    const val PAYU_SMS_SENDER_NOT_MATCHED = "OTP sender did not match"
    const val PAYU_METHOD_NOT_SUPPORTED = "Method not supported"
    const val PAYU_MOBILE_NUMBER_MISMATCHED = "Mobile number Mismatch"

}

object KibanaEvents {

    // keys
    const val PAYU_EVENT_KEY = "event_key"
    const val PAYU_EVENT_VALUE = "event_value"
    const val PAYU_EVENT_SEVERITY = "event_severity"
    const val PAYU_EVENT_TYPE = "event_type"
    const val PAYU_EVENT_REFERENCE_ID = "reference_id"
    const val PAYU_SDK_BOLT_APPLICATION_PACKAGE = "application_package"
    const val TXN_ID = "txn_id"
    const val PAYU_TIMESTAMP = "ts"
    const val PAYU_SDK_BOLT_APPLICATION_VERSION = "application_version"
    const val LOGGING_SDK = "logging_sdk"
    const val PAYU_SDK_VERSION = "sdk_version"
    const val PAYU_SDK_NAME = "sdk_name"
    const val PAYU_MERCHANT_KEY = "merchant_key"
    const val PAYU_SDK_BOLT_REF_ID = "ref_id"
    const val PAYU_DEVICE_DETAILS = "device_details"
    const val PAYU_SDK_REF_TYPE = "sdk_ref_type"
    const val PAYU_CODE = "code"
    const val PAYU_EVENTS_INDEX = "event_Index"
    const val PAYU_STATUS = "status"
    const val PAYU_EVENT_PLATFORM = "platform"
    const val PAYU_EVENT_TIME = "event_time"
    const val PAYU_SCREEN_NAME = "screen_name"
    const val PAYU_AMT = "amt"
    const val PAYU_PLUGIN_TYPE = "plugin_type"
    const val PAYU_EVENT_UNKNOWN = "unknown"
    const val PAYU_NAME = "name"

    // key names
    const val PAYU_SDK_RESET = "sdkPayUBoltReset"
    const val PAYU_INIT_PAYMENT = "initPayment"
    const val PAYU_REQUEST_PAYMENT_HASH = "requestPaymentHash"
    const val PAYU_PAYMENT_HASH_RECEIVED = "paymentHashReceived"
    const val PAYU_INIT_PAYMENT_RESPONSE = "initPaymentResponse"
    const val PAYU_REQUEST_VERIFY_PAYMENT_HASH = "requestVerifyPaymentHash"
    const val PAYU_VERIFY_PAYMENT_HASH_RECEIVED = "verifyPaymentHashReceived"
    const val PAYU_REQUEST_PG_DETAILS_HASH = "requestPgDetailsHash"
    const val PAYU_PG_DETAILS_HASH_RECEIVED = "pgDetailsHashReceived"

}