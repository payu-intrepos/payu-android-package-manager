package com.payu.commonmodelssdk.model.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class PayUCustomerBankAccounts(var bankName: String? = null, var bankCode: String? = null, var bankAccounts: PayUAccountDetail) :
    Parcelable