package com.payu.commonmodelssdk.constants

object PayUResponseTypes {
    const val REQUEST_UPI_BOLT = 100
    const val REQUEST_SIM_INFO = 101
    const val REQUEST_ACCOUNT_MOBILE_REG = 102
    const val REQUEST_PAY = 103
    const val REQUEST_GET_BALANCE = 104
    const val REQUEST_LIST_BANKS = 105
    const val REQUEST_GET_CHANGE_MPIN = 106
    const val REQUEST_SDK_HANDSHAKE =  107
    const val REQUEST_SAVE_VPA_V3 = 108
    const val REQUEST_GET_TRANSACTION_HISTORY_V3 = 109
    const val REQUEST_GET_RAISE_QUERY_V3 = 110
    const val REQUEST_LIST_QUERIES_V3 = 111
    const val REQUEST_GET_CUSTOMER_deregister_V3 = 112
    const val REQUEST_FETCH_ACCOUNT_V3 = 113
    const val REQUEST_GET_VPA_V3 = 114
    const val REQUEST_GET_VPA_REMOVE_V3 = 115
    const val REQUEST_ALL_ACCOUNTS_V3 = 116
    const val REQUEST_SAVE_ACCOUNT_V3 = 117
    const val REQUEST_GET_ACCOUNT_REMOVE_V3 = 118
    const val REQUEST_GET_PROFilE_VPA_V3 = 119
    const val REQUEST_CHECK_PAYMENT_STATUS = 120
    const val REQUEST_QUERY_TYPE_LIST = 131
    const val REQUEST_ADD_ACCOUNT = 132
    const val REQUEST_CHECK_DISPUTE_STATUS = 133
    const val REQUEST_VALIDATE_OTP = 134

    const val CHECK_DEVICE_BINDING_STATUS = 121
    const val PAYU_SHOW_SETTING = 122
    const val DEFAULT_FAILURE = 123

    const val REQUEST_TRANSACTION = 124
    const val REQUEST_MANAGE = 125
    const val REQUEST_CANCEL_TRANSACTION = 126


    //TODO will remove when axis reqType fix
    const val PAYU_CALLBACK_KEY = 127
    const val REQUEST_INIT_UPI_BOLT = 128

    // Axis codes for error handling
    const val CHANGE_PIN_USER_CANCELLED = 3
    const val CHECK_BALANCE_USER_CANCELLED = 1
    const val RESET_PIN_USER_CANCELLED = 2
    const val PAY_USER_CANCELLED = 5
    const val UPDATE_DEVICE_STATUS = 128
    const val REQUEST_NPCI_TOKEN = 129
    const val REQUEST_NPCI_LIST_KEYS = 130

}