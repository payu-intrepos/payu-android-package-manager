package com.payu.commonmodelssdk.model.request

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
 data class PayUUPIParams(
   var key: String?,
   var vpa: String? = null,
   var email: String? = null,
   var phone: String? = null,
   var hash: String? = null,
   var bankCode: String? = null,// given by payu.
   var sdkPlatformData: String? = null,
   var userAgent: String? = null,
   var notifyURL: String? = null,
   var cancelReturnUrl: String? = null,
   var params: @RawValue PayUUPIBoltPaymentParams?=null // @RawValue becoz it is not Parcelable class
) : Parcelable