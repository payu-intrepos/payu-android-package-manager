package com.payu.commonmodelssdk.enums

enum class UpiHashCommand(val hashName: String) {
    PaymentHash("payment_source"),
    HDFCAuthToken("hdfc_auth_token"),
    PgDetails("pg_details"),
    VerifyPayment("verify_payment")

}