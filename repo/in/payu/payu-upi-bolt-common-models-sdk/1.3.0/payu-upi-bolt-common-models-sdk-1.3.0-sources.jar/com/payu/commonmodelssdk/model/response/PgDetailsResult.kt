package com.payu.commonmodelssdk.model.response

import com.payu.commonmodelssdk.model.PgDetails

data class PgDetailsResult(
    val pgDetails: HashMap<String, PgDetails>,
    val pgId: Int
)