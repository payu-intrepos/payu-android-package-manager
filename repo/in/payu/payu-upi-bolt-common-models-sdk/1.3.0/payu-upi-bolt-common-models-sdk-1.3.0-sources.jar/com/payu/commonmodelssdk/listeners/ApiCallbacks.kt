package com.payu.commonmodelssdk.listeners

/**
 * ApiCallbacks  class for all api call
 * */
interface ApiCallbacks {
    fun callApi(params: Any, isProd: Boolean = true, callback: ApiBaseCallback)
}