package com.payu.commonmodelssdk.model.response

data class PayUDisputeData(
    val actionType: String? = null,
    val disputeType: String? = null,
    val onBehalfOf: String? = null,
    val orgRrn: String? = null,
    val orgTxnDate: String? = null,
    val orgTxnId: String? = null,
    val rrn: String? = null,
    val txnId: String? = null,
    val userMsg: String? = null,
    val crn: String? = null,
    val expectedResolDate: String? = null,
    val ticketNo: String? = null
)
