package com.payu.commonmodelssdk.model

import com.payu.commonmodelssdk.constants.ApiConstant

/**
 * PayUNetworkData  class for all api calls request
 * */

data class PayUNetworkData(
    var url: String,
    var postRequest: String? = null,
    var getRequest: HashMap<String, Any>? = null,
    var headerMap: HashMap<String, String>? = null,
    var contentType: String = com.payu.commonmodelssdk.constants.ApiConstant.PAYU_APPLICATION_URL_ENCODED
)