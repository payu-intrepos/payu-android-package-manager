package com.payu.commonmodelssdk.model

/**
 * SimInfo  class to return simInfo to merchant
 * */
data class PayUSimInfo(
    var mobileNumber: String,
    val slotIndex: String?,
    val subscriberId: String,
    val carrierName: String?,
    val isPhoneNoAvailable: Boolean = true
)