package com.payu.commonmodelssdk.model.request

import android.content.Context

/**
 * VerifyApiRequest class to get request data from merchant
 * */

data class CancelApiRequest(
    var token: String,
    var url: String
)
