package com.payu.commonmodelssdk.model


data class PgDetails(
    var pgName: String,
    var pgId: String,
    var merchChanId: String,
    var mcc: String,
    var merchId: String,
    var mKey: String,
    var pluginKey: String?,
    val bankHandle: String?,
    val bhimBankHandle: String?,
    val isCCTxnEnabled: Boolean? = false
)