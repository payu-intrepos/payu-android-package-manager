package com.payu.commonmodelssdk.model.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
class PayUUPIBoltResponse(var responseType: Int, var code: Int, var message: String? = null, var result: @RawValue Any? = null,var referenceId: String? = null) : Parcelable