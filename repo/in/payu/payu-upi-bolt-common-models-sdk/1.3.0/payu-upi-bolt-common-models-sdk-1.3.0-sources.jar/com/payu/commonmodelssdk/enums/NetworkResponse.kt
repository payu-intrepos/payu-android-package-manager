package com.payu.commonmodelssdk.enums

sealed class NetworkResponse<T> {
    class Loading<T>(
        val data: Any? = null
    ) : NetworkResponse<T>()

    data class Success<T>(
        val data: T
    ) : NetworkResponse<T>()

    data class Failure<T>(
        val error: String? = null,
        val errorData: Any? = null,
        val data: Any? = null
    ) : NetworkResponse<T>()

    data class FailureWithAlert<T>(
        val message: String
    ) : NetworkResponse<T>()
}