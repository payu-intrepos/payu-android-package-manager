package com.payu.commonmodelssdk.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * PgDetailsRequest class for pg details api request
 * */
@Parcelize
class PgDetailsRequest(var merchantKey: String, var pg: String, var hash: String? = null) :
    Parcelable