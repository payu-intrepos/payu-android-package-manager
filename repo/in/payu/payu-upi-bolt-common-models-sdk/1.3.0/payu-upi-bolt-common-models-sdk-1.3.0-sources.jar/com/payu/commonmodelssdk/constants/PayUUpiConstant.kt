package com.payu.commonmodelssdk.constants

import android.Manifest

object PayUUpiConstant {

    const val PAYU_AUTH_TOKEN = "merchantauthtoken"
    const val APPLICATION_JSON = "application/json"
    const val APPLICATION_FORM_URL_ENCODED = "application/x-www-form-urlencoded"
    const val AXIS_UAT_URL = "https://upiuat.axisbank.co.in/v1/v2/sdk/servertoken"
    const val AXIS_PROD_URL = "https://pingupi.axisbank.co.in/v1/v2/sdk/servertoken"
    const val PAYU_VERIFY_PAYMENT_URL = "https://info.payu.in/sdk/transaction"
    const val PAYU_VERIFY_UAT_PAYMENT_URL = "https://test.payu.in/sdk/transaction"
    const val PAYU_AUTH_TOKEN_PROD_URL = "https://api.payu.in/upi-plugin/v1/token"
    const val PAYU_AUTH_TOKEN_TEST_URL = "https://apitest.payu.in/upi-plugin/v1/token"
    const val PAYU_PG_DETAILS_PROD_URL = "https://info.payu.in/payment-mode/v1/sdk-plugin"
    const val PAYU_PG_DETAILS_UAT_URL = "https://test.payu.in/payment-mode/v1/sdk-plugin"
    const val PAYU_DATA = "data"

    const val PAYU_CHECKSUM = "merchChecksum"
    const val PAYU_MERCHID = "merchId"
    const val PAYU_MERCHANID = "merchChanId"
    const val PAYU_ASK_PERMISSION = -2
    const val PAYU_SHOW_SETTING = -1
    const val PAYU_SUB_MERCHNANID = "submerchantid"
    const val PAYU_UNQ_CUSTID = "unqCustId"
    const val PAYU_MOBILE = "mobilenumber"
    const val PAYU_SUBSCRIPTION_ID = "subscription id"
    const val PAYU_UNQ_TXNID = "unqTxnId"
    const val PAYU_AES_TRANSFORMATION = "AES/CBC/PKCS5Padding"
    const val PAYU_AES_ALGO = "AES"
    const val PAYU_SHA256 = "SHA-256"
    const val PAYU_UTF8 = "UTF-8"

    const val PAYU_TIME_STAMP = "timestamp"


    const val KEY = "key"
    const val HASH = "hash"
    const val VAR1 = "var1"
    const val COMMAND = "command"
    const val PAYU_VALUE_Y = "Y"

    const val PAYU_MODE = "mode"
    const val PAYU_PG = "pg"

    const val PAYU_UPI = "UPI"
    const val PAYU_RESULT = "result"
    const val PAYU_PG_ID = "pgId"
    const val PAYU_MCC = "mcc"

    const val PAYU_GET = "GET"
    const val PAYU_MCC_CODE = "mcccode"

    const val DATE = "Date"
    const val DIGEST = "digest"
    const val AUTHORIZATION = "authorization"
    const val DEVICE_INFO = "DeviceInfo"
    const val AUTH_HEADER_PARAM_1 = "hmac username=\""
    const val AUTH_HEADER_PARAM_2 =
        "\", algorithm=\"sha512\", headers=\"date\", signature=\""

    const val PREF_KEY_MOBILE = "mobile"
    const val PREF_KEY_SUBSCRIPTION_ID = "subscription_id"
    const val PREF_KEY_CARRIER = "carrier"
    const val trueString = "true"

    const val V2_API_TIME_FORMATE = "\"EEE, dd MMM yyyy HH:mm:ss 'GMT'\""
    const val SIGNINGSTRING_DIGEST = "\ndigest: "
    const val DEFAULT = "default"
    const val PAYU_UD_ID = "udid"
    const val PAYU_IMEI = "imei"

    const val PAYU_EVENT_KEY_PLUGIN_TRANSACTION = "payu_upi_plugin_sdk_transaction"

    const val PAYU_MERCHANT_KEY = "merchant_key"

    const val PAYU_EVENT_SUCCESS = "Success"
    const val PAYU_EVENT_FAILURE = "Failure"
    const val PAYU_EVENT_REFERENCE_ID = "referenceId"
    const val HIGH = "High"
    const val LOW = "Low"
    const val ERROR = "Error"
    const val INFO = "Info"
    const val ANDROID = "Android"

    const val PAYU_SDK_BOLT_TAG = "PayU SDK Upi Bolt"
    const val DD_MM_YY_HH_MM_SS_Z_DATE_FORMAT = "dd/MM/yyyy hh:mm:ss.SSSZ a"
    const val DD_MM_YY_HH_MM_SS_DATE_FORMAT = "dd/MM/yyyy hh:mm:ss aa"
    const val PAYU_TIME = "dd/MM/yyyy hh:mm:ss a"
    const val PAYU_TIME_QUERY = "dd/MM/yyyy hh:mm:ss"
    const val PAYU_TIME_DISPUTE = "MMM d, yyyy, h:mm:ss a"
    const val PAYU_SDK_BOLT_REF_ID = "refId"
    const val PAYU_SIM_INFO = "_simInfo"
    const val PREF_KEY_SLOT_INDEX = "slotIndex"
    const val PAYU_SLOT_SIZE = "slotsSize"
    const val PAYU_POST = "Post"
    const val PAYU_PATCH = "Patch"
    const val PAYU_DELETE = "DELETE"

    const val ACCOUNT_LIST_REQUEST_TYPE_REGISTRATION = "R"
    const val ACCOUNT_LIST_REQUEST_TYPE_ADD_ACCOUNT = "A"
    const val ACCOUNT_LIST_REQUEST_TYPE_ALL_EXIST_ACCOUNT = "E"

    const val PG_DETAIL_TYPE_IN_APP = "INAPP"
    const val PG_DETAIL_TYPE_UPI = "UPI"
    const val PG_DETAIL_TYPE_INTENT = "INTENT"
    const val PG_DETAIL_TYPE_DEFAULT = "default"
    const val PAYU_EMAIL_ID = "emailId"
    const val PAYU_PLUGIN_TYPES = "plugInTypes"
    const val PAYU_REQUEST_ID= "requestID"
    const val PAYU_RUNTIME_DEPENDENCY = "runtime dependency"
    const val PAYU_ISSUING_BANK = "issuing bank"


    const val PAYU_HASH_TYPE = "hash_type"
    const val PAYU_HASH_TYPE_SHA_512 = "hash_type_sha_512"
    const val PAYU_HASH_TYPE_HMAC_256 = "hash_type_hmac_256"

    const val API_TIMEOUT: Long = 60 // seconds
    const val BINDING_TIMEOUT_MILLIS: Long = 1000 * API_TIMEOUT

    const val HASH_TIMOUT_COUNT = 5
    const val CHECK_STATUS_TIMEOUT: Long = 60 * 1000
    const val CHECK_STATUS_TIME_INTERVAL: Long = 5000
    const val VERIFY_STATUS_API_TIMEOUT: Long = 4 //in Second

    const val VERIFY_STATUS_PENDING = "pending"
    const val VERIFY_STATUS_SUCCESS = "success"
    const val VERIFY_STATUS_FAILURE = "failure"
    const val VERIFY_STATUS = "status"
    const val VERIFY_TXN_DETAILS = "transaction_details"

    const val PAYU_CARRIER_NO_SERVICE = "NO SERVICE"
    const val PAYU_CARRIER_NO_SERVICES = "NO SERVICES"


    const val AXIS_SUCCESS_STATUS = "00"
    const val AXIS_SESSION_EXPIRE  = "401"
    const val AXIS_TOKEN_EXPIRE  = "91"
    const val AXIS_USER_ABORTED_CODE = "10002"
    const val AXIS_QUERY_EXISTS_CODE = "02"
    const val AXIS_TRANSACTION_TYPE_P2M = "P2M"
    const val AXIS_INIT_MODE = "00"
    const val AXIS_REF_CATEGORY = "00"
    const val AXIS_PURPOSE = "00"
    const val CANCEL_API_TOKEN = "token"
    const val CANCEL_API_ACTION = "action"
    const val CANCEL_API_ACTION_VALUE = "CancelTxn"
    const val CANCEL_API_FAILURE_REASON = "failure_reason"
    const val CANCEL_API_FAILURE_REASON_VALUE = "Cancel"

    val PERMISSIONS = mapOf(
        Pair(Manifest.permission.SEND_SMS, true),
        Pair(Manifest.permission.READ_PHONE_STATE, true),
        Pair(Manifest.permission.READ_PHONE_NUMBERS, true),
        Pair(Manifest.permission.ACCESS_NETWORK_STATE, true),
        Pair(Manifest.permission.ACCESS_FINE_LOCATION, false),
        Pair(Manifest.permission.ACCESS_COARSE_LOCATION, false)
    )

    const val RES_PARAM_MESSAGE = "message"
    const val RES_PARAM_MSG = "msg"
    const val RES_PARAM_RESULT = "result"
    const val RES_PARAM_STATUS = "status"
    const val RES_PARAM_GUID = "guid"

    const val PAYU_INIT_PARAM = "PayUUPIBoltUIConfig"
    const val PAYU_PAYMENT_PARAM = "PayUUPIBoltPaymentParams"

    const val SDK_PAYU_REQUEST = "SDK_PAYU_Request"
    const val AXIS_PAYU_REQUEST = "AXIS_PAYU_Request"
    const val PLUGIN_CORE_REQUEST = "SDK_CORE_PAYU_Request"
    const val PLUGIN_CORE_RESPONSE = "SDK_CORE_PAYU_Response"
    const val SDK_PAYU_URL = "URL: "
    const val SDK_PAYU_BODY = "Body: "
    const val SDK_HTTP_METHOD = "HttpMethod:"
    const val PAYU_AXIS_API = "PAYU_Bolt_AXIS_API:"
    const val PAYU_API = "PAYU_Bolt_API:"
    const val PAYU_BOLT_UI_API = "PAYU_BoltUI:"
    const val PAYU_BOLT_CORE_API = "PAYU_Bolt_Core_API:"

    const val PAYU_BOLT_UI_SDK_NAME = "PayUUPIBoltUIKit"
    const val PAYU_BOLT_SDK_NAME = "PayUUPIBoltKit"
    const val PAYU_BOLT_CORE_SDK_NAME = "PayUUPIBoltCoreKit"
    const val PAYU_SDK_TIME = "sdkTime"

    const val PAYU_SDK_ERROR = "SDK_PAYU_ERROR"
    const val PAYU_AXIS_ERROR = "AXIS_SDK_ERROR"
    const val PAYU_SDK_ = "SDK_PAYU"
    const val AXIS_SDK = "SDK_AXIS"

    const val PAYU_SDK_RESPONSE = "SDK_PAYU_Response"
    const val AXIS_SDK_RESPONSE = "SDK_AXIS_Response"
    const val PAYU_API_ERROR = "API_PAYU_ERROR"

    // method name
    const val PAYU_IS_UPI_BOLT_AVAILABLE = "isUpiBoltEnabled"
    const val PAYU_GET_SIM_INFO = "getSubscriberInfo"
    const val PAYU_CHECK_DEVICE_STATUS = "checkDeviceStatus"
    const val PAYU_CHECK_DEVICE_BINDING_STATUS = "checkDeviceBindingStatus"
    const val PAYU_REQUEST_LIST_BANKS = "fetchBankList"
    const val PAYU_FETCH_ACCOUNTS_IIN = "fetchAccountsIIN"
    const val PAYU_LINKED_ACCOUNTS = "fetchLinkedAccounts"
    const val PAYU_CHECK_BALANCE= "checkBalance"
    const val PAYU_SET_MPIN = "setMPIN"
    const val PAYU_REMOVE_ACCOUNT = "removeAccount"
    const val PAYU_DEREGISTER_ACCOUNTS = "deregister"
    const val PAYU_REQUEST_GET_CHANGE_MPIN = "changeMPIN"
    const val PAYU_REQUEST_SET_VPA = "setVPA"
    const val PAYU_REQUEST_GET_VPA_PROFILE = "fetchVPAProfile"
    const val PAYU_REQUEST_SAVE_VPA = "saveVPA"
    const val PAYU_REQUEST_DELETE_VPA = "deleteVPA"
    const val PAYU_REQUEST_REGISTERED_VPA = "fetchRegisteredVPAList"
    const val PAYU_REQUEST_PAY = "pay"
    const val PAYU_REQUEST_CHECK_STATUS = "checkTransactionStatus"
    const val PAYU_REQUEST_RAISE_QUERY = "raiseQuery"
    const val PAYU_REQUEST_QUERY_LIST = "fetchQueryList"
    const val PAYU_REQUEST_TXN_HISTORY = "fetchTransactionHistory"
    const val PAYU_REQUEST_UNKNOWN = "requestUnknown"
    const val PAYU_REQUEST_QUERY_TYPE_LIST = "fetchQueryTypeList"
    const val PAYU_REQUEST_ADD_ACCOUNT = "addAccount"
    const val PAYU_RE_VERIFY_SERVER_GEN_ID = "reVerifyServerGenId"
    const val PAYU_VALIDATE_OTP = "validateOtp"
    const val AXIS_REQUEST_TYPE = "axis_request_type"
    const val PAYU_BANK_LIST_SIZE = "bank_list_size "
    const val PAYU_QUERY_LIST_SIZE = "query_list_size: "
    const val PAYU_TXN_LIST_SIZE = "txn_list_size: "
    const val PAYU_NPCI_TOKEN = "npciToken"
    const val PAYU_LIST_KEYS = "listKeys"
    const val PAYU_QUERY_TYPE_LIST_SIZE = "query_type_list_size: "

    const val PAYU_BANK_ACCOUNTS = "bankAccounts"
    const val PAYU_ACCOUNTS_ADDED_TO_VPA = "accountsAddedToVpa"
    const val PAYU_ACCOUNTS = "accounts"
    const val PAYU_AEPS_FLAG = "aepsFlag"
    const val PAYU_REF_URL = "refUrl"
    const val PAYU_AEBA = "aeba"
    const val PAYU_MASKED_ACT_NUMBER = "maskedAccountNumber"
    const val PAYU_MBEBA = "mbeba"
    const val PAYU_VPA = "vpa"
    const val PAYU_TYPE = "type"
    const val PAYU_IIN = "iin"
    const val PAYU_MASKED_CARD_NUMBER = "maskedCardNumber"
    const val PAYU_BANK_ID = "bankId"
    const val PAYU_BANK_NAME = "bankName"
    const val PAYU_BANK_CODE = "bankCode"
    const val PAYU_IS_CC_TXN_ENABLED = "isCCTxnEnabled"
    const val PAYU_REQUEST_TYPE = "requestType"
    const val PAYU_NICK_NAME = "nickName"
    const val PAYU_FROM_DATE = "from_date"
    const val PAYU_TO_DATE = "to_date"
    const val PAYU_TXN_ID = "txnId"
    const val PAYU_AMOUNT = "amount"
    const val PAYU_QUERY = "query"
    const val PAYU_BENE_VPA = "beneVpa"
    const val PAYU_PRODUCT_INFO = "productInfo"
    const val PAYU_MERCHANT_VPA = "merchantVpa"
    const val PAYU_CUST_NAME = "custName"
    const val PAYU_CARRIER_NAME = "carrierName"
    const val PAYU_IS_PROD = "isProd"
    const val PAYU_APP_ID = "appId"
    const val PAYU_HANDSHAKE = "handshake"
    const val PAYU_STARTED = "started"
    const val PAYU_COMPLETED = "completed"
    const val PAYU_FAILED = "failed"
    const val PAYU_WELCOME = "welcome"
    const val PAYU_PERMISSION = "permission"
    const val PAYU_YES = "yes"
    const val PAYU_NO = "no"
    const val PAYU_PERMISSION_GRANTED = "permissionGranted"
    const val PAYU_PERMISSION_DENIED = "permissionDenied"
    const val PAYU_MOB_VERIFICATION = "prepareHandShakeData"
    const val PAYU_BANK_SELECTED = "bankSelected"
    const val PAYU_SET_UPI = "showBankAccountSelectionScreen"
    const val PAYU_ACCOUNT_SELECTED ="accountSelected"
    const val PAYU_SET_UPI_ID = "setAccountDetails"
    const val PAYU_PAYMENT_STATUS = "verifyPayment"
    const val PAYU_LINKED_ACCOUNT_SELECTED = "linkedAccountSelected"
    const val PAYU_LINKED_PAY = "linkedPay"
    const val PAYU_ADD_ANOTHER_ACT = "addAnotherAccount"
    const val PAYU_MERCHANT_NAME = "merchantName"
    const val PAYU_PLUGIN_TYPE = " pluginType"
    const val PAYU_SDK_INIT = "sdkPayUBoltInit"
    const val PAYU_DEVICE_BINDING_RESET = "checkDeviceBindingStatus"
    const val PAYU_DEVICE_BINDING_STATUS = "deviceBindingStatus"
    const val SDK_PAYU_VALUE = "SDK_PAYU_VALUE: "
    const val PAYU_GRANTED = "granted"
    const val PAYU_REQUESTED = "requested"
    const val PAYU_DENIED = "denied"
    const val PAYU_CHECKING = "checking"
    const val PAYU_MANAGE_ACCOUNT_SELECTED ="manageAccountSelected"

    const val TEZ: String = "TEZ"
    const val TEZOMNI: String = "TEZOMNI"
    const val VPA_PHONE: String = "vpa_phone"
    const val UPI_USER_AGENT: String = "User-Agent"
    const val UPI_INTENT: String = "INTENT"
    const val DEVICE_TYPE: String = "device_type"

    const val PLATFORM_KEY: String = "platform"
    const val PLATFORM_VALUE: String = "android"
    const val SDK_PLATFORM_KEY: String = "sdk_platform"
    const val NAME_KEY: String = "name"
    const val TXNID: String = "txnid"
    const val SESSION_ID: String = "sessionId"
    const val AMOUNT: String = "amount"
    const val PRODUCT_INFO: String = "productinfo"
    const val FIRST_NAME: String = "firstname"
    const val BENEFICIARY_ACCOUNT_NUMBER: String = "beneficiaryAccountNumber"
    const val BENEFICIARY_IFSC = "beneficiaryIfsc"
    const val IFSC_CODE: String = "ifscCode"
    const val BENEFICIARY_DETAILS: String = "beneficiarydetail"
    const val TPV: String = "TPV"
    const val API_VERSION: String = "api_version"
    const val EMAIL: String = "email"
    const val SURL: String = "surl"
    const val FURL: String = "furl"
    const val UDF1: String = "udf1"
    const val UDF2: String = "udf2"
    const val UDF3: String = "udf3"
    const val UDF4: String = "udf4"
    const val UDF5: String = "udf5"
    const val PHONE: String = "phone"
    const val LASTNAME: String = "lastname"
    const val ADDRESS1: String = "address1"
    const val ADDRESS2: String = "address2"
    const val CITY: String = "city"
    const val STATE: String = "state"
    const val COUNTRY: String = "country"
    const val ZIPCODE: String = "zipcode"
    const val USER_CREDENTIALS: String = "user_credentials"
    const val SPLIT_REQUEST: String = "splitRequest"
    const val HASH_STRING: String = "hashString"
    const val HASH_NAME: String = "hashName"

    const val PAYU_UI_HANDLER = "payu_ui_handler_button_click"
    const val PAYU_HANDSHAKE_TXNID = "payu_handshake_generated_txnid"
    const val PAYU_TXNID_PREFIX = "payUinit_"
    const val PAYU_PERMISSION_SETTING_SCREEN = "redirect to permission settings screen"
    const val PAYU_ADD_ANOTHER_ACT_VALUE = "user clicked on other banks"
    const val PAYU_SET_UPI_PIN_ALREADY_EXISTS = "upi pin already exists"
    const val PAYU_SET_UPI_PIN_NOT_EXISTS = "upi pin not exists"
    const val PAYU_VPA_ALREADY_EXISTS = "vpa already exists"
    const val PAYU_VPA_OPEN_EDIT = "open edit vpa"
    const val PAYU_DEVICE_BINDING_STATUS_CHECK = "device binding status check initiated"
    const val PAYU_SET_UPI_PIN = "setMpin"
    const val PAYU_MAKE_PAYMENT = "makePayment"
    const val PAYU_MAKE_PAYMENT_ON_UPI_PIN_SCREEN = "on upi pin exists screen"
    const val UPDATE_VPA_DONE = "update vpa done"
    const val PAYU_M_PIN_SETUP_COMPLETED = "mpin setup completed"
    const val PAYU_M_PIN_SETUP_FAILED = "mpin setup failed"
    const val WELCOME_SCREEN_UPI_BOLT_UI = "welcome screen upi bolt ui"
    const val PAYU_BANK_LIST = "fetchBankList"


    val PAYMENT_PARAMS_ARRAY = arrayListOf(KEY, TXNID, AMOUNT,
        PRODUCT_INFO,
        FIRST_NAME,
        EMAIL,
        SURL,
        FURL,
        HASH,
        UDF1,
        UDF2,
        UDF3,
        UDF4,
        UDF5,
        BENEFICIARY_ACCOUNT_NUMBER,
        USER_CREDENTIALS
    )

    const val PAYU_MAX_AMOUNT = 100000.0

    const val QUERY_STATUS_INITIATED = "Initiated"
    const val QUERY_STATUS_OPEN = "Open"
    const val QUERY_STATUS_O = "O"
    const val QUERY_STATUS_CLOSED = "Closed"
    const val QUERY_STATUS_C = "C"
    const val PAYU_TRAN_STATUS_COMPLETE = "C"
    const val PAYU_TRAN_STATUS_SUCCESS = "S"
    const val PAYU_TRAN_STATUS_FAILED = "F"
    const val PAYU_TRAN_STATUS_PENDING = "P"
    const val PAYU_TRAN_STATUS_REJECTED = "R"
    const val PAYU_TRAN_STATUS_DECLINE = "D"
    const val PAYU_SUCCESSFULLY_PAID = "Successful"
    const val PAYU_PAYMENT_FAILED = "Failed"
    const val PAYU_PAYMENT_PENDING = "Pending"
    const val PAYU_PAYMENT_REJECTED = "Rejected"
    const val PAYU_PAYMENT_DECLINED = "Declined"
    const val PAYU_TRANSACTION_STATUS = "TRANSACTION_STATUS"
    const val PAYU_PAYEE = "PAYEE"


    const val PAYU_SHOW_BOTTOMSHEET = "boltSheetOpened"
    const val PAYU_UI_EVENT_SUCCESS = "uiEventSuccess"
    const val PAYU_VIEW_INITIATED = "viewInitiated"
    const val PAYU_BANK_SEARCH_FILTER = "bankSearchFilter"
    const val PAYU_BUTTON_CLICKED = "boltCTAClicked"
    const val PAYU_UI_EVENT_FAILURE = "uiEventFailure"
    const val PAYU_UI_EVENT_LOADING = "uiEventLoading"
    const val PAYU_UI_EVENT = "uiEvent"
    const val PAYU_SHOW_LOADER = "showLoader"
    const val PAYU_HIDE_LOADER = "hideLoader"
    const val PAYU_UI_ERROR = "uiError"
    const val PAYU_BANK_LIST_NO_DATA_SCREEN = "bank list no data screen"
    const val PAYU_CLICK_ACTION = "clickAction"
    const val PAYU_GET_FRAGMENT = "getFragment"
    const val PAYU_ACTION_INITIATED = "actionInitiated"
    const val PAYU_CALLBACK_SUCCESS = "callbackSuccess"
    const val PAYU_CALLBACK_FAILURE = "callbackFailure"
    const val PAYU_GET_SUBSCRIBER_INFO = "getSubscriberInfo"
    const val PAYU_UPDATE_VPA = "updateVPA"
    const val PAYU_EVENT_SEND_CALLBACK = "sendMerchantCallback"

    const val PAYU_OLIVE_SDK_PACKAGE = "com.olive.upi.OliveUpiManager"
    const val PAYU_HDFC_SDK_PACKAGE = "com.payu.upiboltcore.PayUUPIPlugin"
    const val PAYU_AXIS_WRAPPER_SDK_PACKAGE = "com.payu.upiboltaxiswrapper.Test"
    const val PAYU_NPCI_CL_SDK_PACKAGE = "org.npci.upi.security.services.CLServices"


    const val PAYU_CANCEL_CONFIRMATION_YES = "Cancel Confirmation - Yes"
    const val PAYU_CANCEL_CONFIRMATION_NO = "Cancel Confirmation - NO"
    const val PAYU_DE_REGISTER_CONFIRMATION_YES = "Deregister Confirmation - Yes"
    const val PAYU_DE_REGISTER_CONFIRMATION_NO = "Deregister Confirmation - NO"
    const val PAYU_GENERIC_CONFIRMATION_YES = "Generic Confirmation - Yes"
    const val PAYU_GENERIC_CONFIRMATION_NO = "Generic Confirmation - NO"

    const val PAYU_NAME = "name"
    const val PAYU_ACC_REF_NUMBER = "accRefNumber"
    const val PAYU_IFSC = "ifsc"
    const val PAYU_D_LENGTH = "dLength"
    const val PAYU_D_TYPE = "dType"
    const val PAYU_ATM_D_LENGTH = "atmdLength"
    const val PAYU_FORMAT_TYPE = "formatType"
    const val PAYU_OTP_D_LENGTH = "otpdLength"
    const val PAYU_OTP_D_TYPE = "otpdType"
    const val PAYU_STATUS = "status"
    const val PAYU_MASKED_ACCNUMBER = "maskedAccnumber"
    const val PAYU_ATMPIN_FORMAT = "atmpinFormat"
    const val PAYU_ATMPIN_LENGTH = "atmpinlength"
    const val PAYU_OTP_LENGTH = "otpLength"
    const val PAYU_OTP_FORMAT = "otpFormat"
    const val PAYU_MMID = "mmid"
    const val PAYU_BALANCE = "balance"
    const val PAYU_BAL_TIME = "balTime"
    const val PAYU_CODE = "code"
    const val PAYU_RESPONSE_TYPE = "responseType"
    const val PAYU_TXN_ACCOUNT_TYPE = "txnAccountType"
    const val PAYU_EXPIRY = "expiry"
    const val PAYU_CARD_MASK_REGEX = "(?<!^..).(?=.{3})"

    const val PAYU_VERIFY_PAYMENT = "verifyPayment"
    const val PAYU_AXIS_AUTH_TOKEN = "authToken"
    const val PAYU_CANCEL_TXN = "cancelTransaction"

    const val PAYU_ACCOUNT_TYPE_CREDIT = "CREDIT"
    const val PAYU_ACCOUNT_TYPE_SAVINGS = "SAVINGS"
    const val PAYU_ACCOUNT_TYPE_CURRENT = "CURRENT"
    const val PAYU_TXN_REF_ID = "txnRefId"
    const val PAYU_OTP_READ_TIMEOUT_SECONDS = 60
    const val TPV_API_VERSION_VALUE: String = "6"
    const val TPV_BANK_CODE = "INAPPTPV"

    const val PAYU_FULL_ACT_NO = "fullAccountNo"

    const val VERSION_KEY = "version"
    const val ANALYTICS_DATA = "analyticsData"

    const val PAYU_ON_RECEIVE_OTP = "OnOTPReceived"
    const val PAYU_ACCOUNT_NO = "accountNumber"

}