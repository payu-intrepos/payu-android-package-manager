package com.payu.commonmodelssdk.model.request

class BeneficiaryVpaDetails private constructor(
    var vpa: String? = null,
    var name: String? = null,
    var nickname: String? = null,
    var cmid: String? = null
) {
    data class Builder(
        var vpa: String? = null,
        var name: String? = null,
        var nickname: String? = null,
        var cmid: String? = null
    ) {
        fun vpa(vpa: String) = apply { this.vpa = vpa }
        fun name(name: String) = apply { this.name = name }
        fun nickname(nickname: String) = apply { this.nickname = nickname }
        fun cmid(cmid: String) = apply { this.cmid = cmid }
        fun build() = BeneficiaryVpaDetails(vpa, name, nickname, cmid)
    }
}