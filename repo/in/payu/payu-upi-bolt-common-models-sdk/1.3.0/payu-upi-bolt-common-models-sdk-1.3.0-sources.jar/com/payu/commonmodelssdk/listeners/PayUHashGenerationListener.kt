package com.payu.commonmodelssdk.listeners

interface PayUHashGeneratedListener {
    fun onHashGenerated(map: HashMap<String, String?>)
}

interface PayUHashGenerationListener {

    fun generateHash(
        map: HashMap<String, String>,
        hashGeneratedListener: PayUHashGeneratedListener
    )
}