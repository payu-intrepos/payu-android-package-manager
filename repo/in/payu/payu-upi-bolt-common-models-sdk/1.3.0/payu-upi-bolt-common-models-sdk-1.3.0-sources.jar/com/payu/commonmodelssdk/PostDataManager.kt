package com.payu.commonmodelssdk

import com.payu.commonmodelssdk.constants.ApiConstant
import com.payu.commonmodelssdk.constants.PayUErrors
import com.payu.commonmodelssdk.constants.PayUUpiConstant
import com.payu.commonmodelssdk.model.PostData
import com.payu.commonmodelssdk.model.request.PayUUPIBoltPaymentParams
import com.payu.commonmodelssdk.model.request.PayUUPIParams
import com.payu.commonmodelssdk.model.response.PayUAccountDetail
import org.json.JSONArray
import java.io.UnsupportedEncodingException
import java.net.URLEncoder
import java.util.regex.Pattern

object PostDataManager {

    private fun getReturnData(
        code: Int,
        status: String?,
        result: String?
    ): PostData {
        val postData = PostData(status, result, code)
        return postData
    }

    private fun getReturnData(code: Int, result: String?): PostData {
        return getReturnData(code, ApiConstant.ERROR, result)
    }

    fun getPaymentPOstParams(mPaymentParams: PayUUPIParams, paymentMode: String): PostData {
        // lets set the default Parameters
        // device_type is mandatory, With out this flag SDK or CB can not receive payuPostData (ie: onPayuSuccess or onPayuFailure js callback from payu server)
        val post = StringBuffer()
        post.append(concatParams(PayUUpiConstant.DEVICE_TYPE, "1", true))
        if (!mPaymentParams.sdkPlatformData.isNullOrEmpty()) {
            val sdkPlatformJsonString = JSONArray(mPaymentParams.sdkPlatformData).toString()
            post.append(
                concatParams(
                    PayUUpiConstant.SDK_PLATFORM_KEY,
                    sdkPlatformJsonString,
                    false
                )
            )
        }


        // lets begin with the mandatory default params.
        // TODO apply the validation according to the pg, payment mode!
        for (i in PayUUpiConstant.PAYMENT_PARAMS_ARRAY.indices) {
            when (PayUUpiConstant.PAYMENT_PARAMS_ARRAY[i]) {
                PayUUpiConstant.KEY -> {
                    if (mPaymentParams.key.isNullOrEmpty()) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_KEY_IS_MISSING
                    )
                    post.append(concatParams(PayUUpiConstant.KEY, mPaymentParams.key, true))
                }

                PayUUpiConstant.TXNID -> {
                    if (mPaymentParams.params?.txnId.isNullOrEmpty()) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_TXNID_IS_MISSING
                    )
                    post.append(concatParams(PayUUpiConstant.TXNID, mPaymentParams.params?.txnId, true))
                }

                PayUUpiConstant.AMOUNT -> {
                    try { // this will take care of null check also!
                        mPaymentParams.params?.amount?.toDouble()
                    } catch (e: NumberFormatException) {
                        return getReturnData(
                            PayUErrors.NUMBER_FORMAT_EXCEPTION,
                            PayUErrors.INVALID_AMOUNT
                        )
                    } catch (e: Exception) {
                        return getReturnData(
                            PayUErrors.INVALID_AMOUNT_EXCEPTION,
                            PayUErrors.INVALID_AMOUNT
                        )
                    }
                    post.append(
                        concatParams(
                            PayUUpiConstant.AMOUNT,
                            mPaymentParams.params?.amount,
                            true
                        )
                    )
                }

                PayUUpiConstant.PRODUCT_INFO -> {
                    if (mPaymentParams.params?.productInfo.isNullOrEmpty()) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_PRODUCT_INFO_IS_MISSING
                    )
                    post.append(
                        concatParams(
                            PayUUpiConstant.PRODUCT_INFO,
                            mPaymentParams.params?.productInfo,
                            true
                        )
                    )
                }

                PayUUpiConstant.FIRST_NAME -> {
                    if (mPaymentParams.params?.firstName == null) // empty string is allowed
                        return getReturnData(PayUErrors.MANDATORY_PARAM_FIRST_NAME_IS_MISSING)
                    post.append(
                        concatParams(
                            PayUUpiConstant.FIRST_NAME,
                            mPaymentParams.params?.firstName,
                            true
                        )
                    )
                }

                PayUUpiConstant.EMAIL -> {
                    if (mPaymentParams.email == null) return getReturnData(PayUErrors.MANDATORY_PARAM_EMAIL_IS_MISSING)
                    post.append(concatParams(PayUUpiConstant.EMAIL, mPaymentParams.email, true))
                }

                PayUUpiConstant.SURL -> {
                    if (mPaymentParams.params?.surl.isNullOrEmpty()) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_SURL_IS_MISSING
                    )
                    post.append(concatParams(PayUUpiConstant.SURL, mPaymentParams.params?.surl, true))
                }

                PayUUpiConstant.FURL -> {
                    if (mPaymentParams.params?.furl.isNullOrEmpty()) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_FURL_IS_MISSING
                    )
                    post.append(concatParams(PayUUpiConstant.FURL, mPaymentParams.params?.furl, true))
                }

                PayUUpiConstant.HASH -> {
                    if (mPaymentParams.hash?.isEmpty() == true) return getReturnData(
                        PayUErrors.MANDATORY_PARAM_HASH_IS_MISSING
                    )
                    post.append(concatParams(PayUUpiConstant.HASH, mPaymentParams.hash, true))
                }

                PayUUpiConstant.UDF1 -> {
                    if (mPaymentParams.params?.udf1 == null) return getReturnData(PayUErrors.INVALID_UDF1)
                    post.append(concatParams(PayUUpiConstant.UDF1, mPaymentParams.params?.udf1, true))
                }

                PayUUpiConstant.UDF2 -> {
                    if (mPaymentParams.params?.udf2 == null) return getReturnData(PayUErrors.INVALID_UDF2)
                    post.append(concatParams(PayUUpiConstant.UDF2, mPaymentParams.params?.udf2, true))
                }

                PayUUpiConstant.UDF3 -> {
                    if (mPaymentParams.params?.udf3 == null) return getReturnData(PayUErrors.INVALID_UDF3)
                    post.append(concatParams(PayUUpiConstant.UDF3, mPaymentParams.params?.udf3, true))
                }

                PayUUpiConstant.UDF4 -> {
                    if (mPaymentParams.params?.udf4 == null) return getReturnData(PayUErrors.INVALID_UDF4)
                    post.append(concatParams(PayUUpiConstant.UDF4, mPaymentParams.params?.udf4, true))
                }

                PayUUpiConstant.UDF5 -> {
                    if (mPaymentParams.params?.udf5 == null) return getReturnData(PayUErrors.INVALID_UDF5)
                    post.append(concatParams(PayUUpiConstant.UDF5, mPaymentParams.params?.udf5, true))
                }

                PayUUpiConstant.USER_CREDENTIALS -> {
                    if (mPaymentParams.params?.userCredentials == null) return getReturnData(PayUErrors.USER_CREDENTIALS_NOT_FOUND)
                    post.append(
                        concatParams(
                            PayUUpiConstant.USER_CREDENTIALS,
                            mPaymentParams.params?.userCredentials, true
                        )
                    )
                }
            }
        }
        if (mPaymentParams.phone != null) {
            post.append(concatParams(PayUUpiConstant.PHONE, mPaymentParams.phone, true))
        }

        if (isValidBeneficiary(mPaymentParams.params)) {
            val payUAccountDetail = mPaymentParams.params?.accountDetail
            val beneficiarydetail = getPayUBeneficiaryDetails(payUAccountDetail)
            post.append(
                concatParams(
                    PayUUpiConstant.BENEFICIARY_DETAILS,
                    beneficiarydetail.toString(),
                    true
                )
            )
            post.append(
                concatParams(
                    PayUUpiConstant.API_VERSION,
                    PayUUpiConstant.TPV_API_VERSION_VALUE,
                    true
                )
            )
        }

        post.append(
            concatParams(
                PayUUpiConstant.SPLIT_REQUEST,
                getParamValue(mPaymentParams.params?.splitPaymentDetails),
                true
            )
        )

        post.append(
            concatParams(
                ApiConstant.BANK_CODE,
                mPaymentParams.bankCode,
                true
            )
        )
        post.append(concatParams(ApiConstant.PG, PayUUpiConstant.PAYU_UPI, true))

        when (paymentMode) {
            PayUUpiConstant.PAYU_UPI -> {
                // Virtual address Check (vpa check)
                // 1)Vpa length should be less than or equal to 50
                // 2)It can be alphanumeric and can contain a dot(.).
                // 3)It should contain a @

                // NULL Check for Virtual address
                if (mPaymentParams.vpa == null) return getReturnData(
                    PayUErrors.INVALID_VPA,
                    PayUErrors.VPA_NULL
                )
                else if (mPaymentParams.vpa?.trim()?.isEmpty() == true) return getReturnData(
                    PayUErrors.INVALID_VPA,
                    PayUErrors.VPA_EMPTY
                )
                else if (mPaymentParams.vpa != null && mPaymentParams.vpa?.trim()?.length!! > ApiConstant.MAX_VPA_SIZE) return getReturnData(
                    PayUErrors.INVALID_VPA, PayUErrors.VPA_GREATER
                ) else {
                    val userVirtualAddress: String = mPaymentParams.vpa?.trim().toString()
                    // Pattern pattern = Pattern.compile("^([A-Za-z0-9\\.])+\\@[A-Za-z0-9]+$"); //Vpa name can be alphanumeric and can contain a dot(.) preceded by @. After '@' only alphanumeric is allowed.
                    val pattern = Pattern.compile(".+@.+")
                    val matcher = pattern.matcher(userVirtualAddress)
                    if (!matcher.matches()) {
                        return getReturnData(PayUErrors.INVALID_VPA, PayUErrors.INVALID_VPA_MESSAGE)
                    }
                }
                post.append(
                    concatParams(
                        ApiConstant.PAYU_VPA,
                        mPaymentParams.vpa?.trim { it <= ' ' },
                        true
                    )
                )
                return getReturnData(
                    PayUErrors.NO_ERROR,
                    ApiConstant.SUCCESS,
                    trimAmpersand(post.toString())
                )
            }

            PayUUpiConstant.TEZOMNI -> {
                post.append(
                    concatParams(
                        PayUUpiConstant.VPA_PHONE,
                        mPaymentParams.phone?.trim { it <= ' ' },
                        true
                    )
                )
                return getReturnData(
                    PayUErrors.NO_ERROR,
                    ApiConstant.SUCCESS,
                    trimAmpersand(post.toString())
                )
            }

            PayUUpiConstant.UPI_INTENT, PayUUpiConstant.PG_DETAIL_TYPE_IN_APP -> {
                post.append(
                    concatParams(
                        PayUUpiConstant.UPI_USER_AGENT,
                        mPaymentParams.userAgent, false
                    )
                )
                return getReturnData(
                    PayUErrors.NO_ERROR,
                    ApiConstant.SUCCESS,
                    trimAmpersand(post.toString())
                )

            }


        }
        return PostData("", "", 0)
    }

     fun getPayUBeneficiaryDetails(payUAccountDetail: PayUAccountDetail?): StringBuilder {
        val beneficiarydetail = StringBuilder()
        beneficiarydetail.append("{")
        beneficiarydetail.append(
            appendKeyValueToStingBuilder(
                PayUUpiConstant.BENEFICIARY_ACCOUNT_NUMBER,
                payUAccountDetail?.fullAccountNo ?: ""
            )
        )
        beneficiarydetail.append(
            appendKeyValueToStingBuilder(
                PayUUpiConstant.IFSC_CODE,
                payUAccountDetail?.ifsc ?: ""
            )
        )
        beneficiarydetail.deleteCharAt(beneficiarydetail.length - 1)
        beneficiarydetail.append("}")
        return beneficiarydetail
    }


    private fun encodeValue(value: String): String? {
        val encodedValue: String? = try {
            URLEncoder.encode(value, "Utf-8")
        } catch (e: UnsupportedEncodingException) {
            value
        }
        return encodedValue
    }

    /**
     * just to make our life easier, lets define a function
     * concat two strings with equal sign and add an ampersand at the end
     *
     * @param key   example txnId
     * @param value example payu12345
     * @param shouldEncode
     * @return concatenated String
     */
    private fun concatParams(key: String, value: String?, shouldEncode: Boolean): String {
        var returnValue = value
        if (shouldEncode) returnValue = encodeValue(value!!)
        return "$key=$returnValue&"
    }

    /**
     * This method is used to trim the leading Ampersand sign
     *
     * @param data , should be concatenated data with equal sign and ampersand.
     * @return example txnId=payu12345
     */
    private fun trimAmpersand(data: String): String {
        return if (data[data.length - 1] == '&') data.substring(0, data.length - 1) else data
    }

    /**
     * @param result result it the result of your PostData
     * @return PostData object.
     */
    private fun getReturnData(result: String?): PostData {
        return getReturnData(PayUErrors.MISSING_PARAMETER_EXCEPTION, ApiConstant.ERROR, result)
    }

    private fun getParamValue(key: String?): String {
        return if (key != null) concatParams(
            PayUUpiConstant.LASTNAME,
            key,
            true
        ) else ""
    }

    private fun isValidBeneficiary(payUUPIBoltPaymentParams: PayUUPIBoltPaymentParams?): Boolean {
        return payUUPIBoltPaymentParams?.beneficiaryDetails != null && !payUUPIBoltPaymentParams.accountDetail?.fullAccountNo.isNullOrBlank() && !payUUPIBoltPaymentParams.accountDetail?.ifsc.isNullOrBlank()
    }

    private fun appendKeyValueToStingBuilder(key: String, value: Any): String {
        return "\"$key\":\"$value\","
    }
}