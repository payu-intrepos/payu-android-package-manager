package com.payu.commonmodelssdk.listeners

/**
 * callback class for Api used
 * */
interface ApiBaseCallback {

    fun onApiSuccess(response: Any)
    fun onApiError(errorCode: Int, errorMessage: String)
}