package com.payu.commonmodelssdk.constants

object KibanaConstants {

    const val SMS_VERIFICATION_DONE = "SMS verification done"
    const val ACCOUNTS_COUNT = "Accounts list count - "
    const val BANK_LIST_COUNT = "Bank list count - "
    const val DISPUTE_LIST_COUNT = "Dispute list count - "
    const val PAYMENT_SUCCESS = "Payment successful by "
    const val TXN_HISTORY_COUNT = "Txn history count - "
    const val DISPUTE_TYPE_LIST_COUNT = "dispute type list count - "
    const val NPCI_TOKEN_GENERATED = "NPCI token generated"
    const val LIST_KEYS_FETCHED = "List keys fetched successfully"
    const val BANK_CODE = "bankCode"
    const val UPI_TXN_REF_NO = "upiTxnRefNo"
    const val REQUEST_TYPE = "requestType"
    const val ACCOUNT_NO = "accountNo"
    const val VPA = "vpa"
    const val MERCHANT_ID = "mId"
    const val PAYEE_VPA = "payeeVpa"
    const val PAYER_VPA = "payerVpa"
    const val PAYER_ACC_NO = "payerAccNo"
    const val NPCI_TXN_ID = "npciTxnId"
    const val OTP_TXN_ID = "otpTxnId"
    const val EVENT_NAME_INITIATE_MPIN = "initiateMpin"
    const val EVENT_NAME_SET_PIN = "setMpin"
    const val CARD_NO = "cardNo"
    const val EXPIRY = "expiry"
    const val TXN_ID = "txnId"
    const val REF_ID = "refId"
    const val QUERY = "query"
    const val QUERY_TYPE = "queryType"
    const val MCC = "mcc"
    const val START_DATE = "startDate"
    const val END_DATE = "endDate"
    const val NPCI_TOKEN = "npciToken"
    const val ISSUING_BANKS = "issuingBanks"
    const val IIN = "iin"
    const val BANK_ID = "bankId"
    const val ACCOUNT_TYPE = "accountType"
    const val AMOUNT = "amount"
    const val ACCOUNT_INFO = "accountInfo"

    // Payment params JSON keys
    const val TRAN_TYPE = "tranType"
    const val REF_URL = "refUrl"
    const val REF_CATEGORY = "refCategory"
    const val INIT_MODE = "initMode"
    const val PURPOSE = "purpose"
    const val PRODUCT_INFO = "productInfo"
    const val FIRST_NAME = "firstName"
    const val SURL = "surl"
    const val FURL = "furl"
    const val UDF1 = "udf1"
    const val UDF2 = "udf2"
    const val UDF3 = "udf3"
    const val UDF4 = "udf4"
    const val UDF5 = "udf5"
    const val USER_CREDENTIALS = "userCredentials"
    const val SPLIT_PAYMENT_DETAILS = "splitPaymentDetails"
    const val IS_CC_TXN_ENABLED = "isCCTxnEnabled"
    const val ACCOUNT_DETAIL = "accountDetail"
    const val BENEFICIARY_DETAILS = "beneficiaryDetails"
    
    // Account detail JSON keys
    const val NAME = "name"
    const val ACC_REF_NUMBER = "accRefNumber"
    const val IFSC = "ifsc"
    const val TYPE = "type"
    const val MMID = "mmid"
    const val AEBA = "aeba"
    const val MBEBA = "mbeba"
    const val D_LENGTH = "dLength"
    const val D_TYPE = "dType"
    const val BALANCE = "balance"
    const val BAL_TIME = "balTime"
    const val STATUS = "status"
    const val FORMAT_TYPE = "formatType"
    const val ATMD_LENGTH = "atmdLength"
    const val BANK_NAME = "bankName"
    const val OTPD_TYPE = "otpdType"
    const val OTPD_LENGTH = "otpdLength"
    const val AEPS_FLAG = "aepsFlag"
    const val FULL_ACCOUNT_NO = "fullAccountNo"
    const val ACCOUNT_NUMBER = "accountNumber"

    const val PAYU_BOLT_REGISTER_METHOD = "boltRegisterAndPayMethodCalled"

    /**
     * List of parameter names that should be masked when isMask is true
     */
    internal val maskedList = listOf(
        "mobileNumber",
        "phone",
        "mobileNo",
        "accountNo",
        "accountId",
        "accRefNumber",
        "accountNumber",
        "unqCustId",
        "vpa",
        "merchantauthtoken",
        "virtualAddress"
    )

    /**
     * List of parameter names that should be excluded from JSON output
     */
    internal val excludeList = listOf(
        "merchId",
        "merchChanId",
        "balance",
        "bal",
        "otp",
        "mpin",
        "email",
        "hash",
        "checkSum",
        "atmpinFormat",
        "merchantchannelid",
        "customerId",
        "mcc",
        "submerchantid",
        "merchantId",
        "merchantvpa",
        "name"
    )

    /**
     * Masks half of the characters in a string
     * @param value The string to mask
     * @return Masked string with half characters replaced by '*'
     */
    internal fun maskValue(value: String): String {
        if (value.isEmpty()) return value
        val length = value.length
        val maskLength = length / 2
        val maskedPart = "*".repeat(maskLength)
        return maskedPart + value.substring(maskLength)
    }
}