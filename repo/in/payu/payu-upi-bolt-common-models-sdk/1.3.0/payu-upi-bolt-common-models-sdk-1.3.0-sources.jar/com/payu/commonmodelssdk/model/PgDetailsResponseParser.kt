package com.payu.commonmodelssdk.model

import com.payu.commonmodelssdk.model.response.PGDetailsResponse
import com.payu.commonmodelssdk.model.response.PgDetailsResult
import org.json.JSONObject

class PgDetailsResponseParser {
    companion object {

        fun getPgDetailsResponseFromJSON(mKey: String, jsonObject: JSONObject): PGDetailsResponse {
            val message = jsonObject.optString("message")
            val status = jsonObject.optInt("status")
            val result = jsonObject.getJSONObject("result")
            val map = HashMap<String, PgDetailsResult>()
            val iterator = result.keys()
            while (iterator.hasNext()) {
                val key = iterator.next()
                val json = result.optJSONObject(key)
                json?.let {
                    val value =
                        getPgDetailsResultFromJSON(
                            mKey,
                            key,
                            it
                        )
                    map[key] = value
                }
            }
            return PGDetailsResponse(message, map, status)
        }

        private fun getPgDetailsFromJSON(
            mKey: String,
            pgName: String,
            pgId: Int,
            pluginKey: String?,
            bankHandle: String?,
            jsonObject: JSONObject,
            bhimBankHandle: String?,
            isCCTxnEnabled: Boolean? = false
        ): PgDetails {
            val mid = if (jsonObject.optString("merchId").isNullOrEmpty().not())
                jsonObject.optString("merchId")
            else
                jsonObject.optString("pgMerchantId")
            return PgDetails(
                pgName, pgId.toString(),
                jsonObject.optString("merchChanId"),
                jsonObject.optString("mcc"),
                mid,
                mKey,
                pluginKey,
                bankHandle,
                bhimBankHandle,
                isCCTxnEnabled
            )
        }


        private fun getPgDetailsResultFromJSON(
            mKey: String,
            pgName: String,
            jsonObject: JSONObject
        ): PgDetailsResult {
            val pgId = jsonObject.optInt("pgId")
            val pluginKey = jsonObject.optString("pluginKey").let {
                if(it.isEmpty() || it == "null") "" else it
            }
            val pgDetailsJson = jsonObject.getJSONObject("pgDetails")
            val bankHandle = jsonObject.optString("bankHandle")
            val bhimBankHandle = jsonObject.optString("bhimBankHandle")
            val isCCTxnEnabled = jsonObject.optBoolean("isCCTxnEnabled",false)
            val map = HashMap<String, PgDetails>()
            val iterator = pgDetailsJson.keys()
            while (iterator.hasNext()) {
                val key = iterator.next()
                val json = pgDetailsJson.optJSONObject(key)
                json?.let {
                    val value = getPgDetailsFromJSON(
                        mKey, pgName, pgId, pluginKey, bankHandle, it, bhimBankHandle, isCCTxnEnabled
                    )
                    map[key] = value
                }
            }
            return PgDetailsResult(map, pgId)
        }
    }

}
