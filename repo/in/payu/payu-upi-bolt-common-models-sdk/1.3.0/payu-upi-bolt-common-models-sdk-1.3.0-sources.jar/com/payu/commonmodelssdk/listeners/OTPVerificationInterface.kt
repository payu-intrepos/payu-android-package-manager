package com.payu.commonmodelssdk.listeners

interface OTPVerificationInterface {

    fun onOTPListenerStarted()
    fun onTimeElapsed()
    fun onOTPReceived()
}
