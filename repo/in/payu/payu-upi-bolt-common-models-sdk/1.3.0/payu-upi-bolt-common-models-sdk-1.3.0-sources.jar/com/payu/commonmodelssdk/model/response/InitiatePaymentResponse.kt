package com.payu.commonmodelssdk.model.response

import android.net.Uri
import org.json.JSONObject

data class InitiatePaymentResponse(
    val merchantName: String,
    val merchantVpa: String,
    val referenceId: String,
    var returnUrl: String?,
    var token: String?,
    val sdkUpiPushExpiry: Int,
    var txnAmount: String?,
    var tid: String? = null
) {

    companion object {
        private const val MERCHANT_NAME = "merchantName"
        private const val MERCHANT_VPA = "merchantVpa"
        private const val REFERENCE_ID = "referenceId"
        private const val RETURN_URL = "returnUrl"
        private const val TOKEN = "token"
        private const val SDK_UPI_PUSH_EXPIRY = "sdkUpiPushExpiry"
        private const val TXN_AMOUNT = "amount"
        private const val INTENT_URI_DATA ="intentURIData"
        private const val TID = "tid"


        fun getInitiatePaymentResponse(response: String): InitiatePaymentResponse {
            val jsonObject = JSONObject(response)
            val intentURIData = jsonObject.optString(INTENT_URI_DATA)
            val tid = getTid(intentURIData)
            return InitiatePaymentResponse(
                jsonObject.optString(MERCHANT_NAME), jsonObject.optString(MERCHANT_VPA),
                jsonObject.optString(REFERENCE_ID), jsonObject.optString(RETURN_URL),
                jsonObject.optString(TOKEN), jsonObject.optInt(SDK_UPI_PUSH_EXPIRY),
                jsonObject.optString(TXN_AMOUNT), tid = tid
            )
        }

        fun getTid(data: String?): String? {
            if (data.isNullOrBlank()) return null
            return try {
                // Extract query string part
                val queryString = if (data.contains("?")) {
                    data.substring(data.indexOf("?") + 1)
                } else if (data.startsWith("?")) {
                    data.substring(1)
                } else {
                    data
                }

                // Split by & and find the parameter
                val params = queryString.split("&")
                for (param in params) {
                    val keyValue = param.split("=", limit = 2)
                    if (keyValue.size == 2 && keyValue[0] == TID) {
                        return keyValue[1]
                    }
                }
                null
            } catch (ex: Exception) {
                null
            }
        }
    }
}