/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.payu.upiboltaxiswrapper;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.payu.upiboltaxiswrapper";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "0.0.2";
  // Field from build type: release
  public static final String sslHash = "sha256/LDnx1Q1Yuby7tiGySCC4KSSOQN6nINHdarA8hWziW1Q=";
}
