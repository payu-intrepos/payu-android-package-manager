package com.payu.upiboltaxiswrapper

/*
    This is a test class to check availability of this SDK
 */
internal class Test {
}